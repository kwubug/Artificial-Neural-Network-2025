import collections
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bipolar_sigmoid, sigmoid_derivative, bipolar_sigmoid_derivative
from ..utils import newton_method_update, compute_numerical_hessian


class NewtonMlpAlgorithm(PredictiveAlgorithm):
    """使用牛顿法的多层感知机算法"""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 test_ratio=0.3, network_shape=None,
                 activation_function='sigmoid', newton_update_frequency=5):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        self.activation_function = activation_function
        self.newton_update_frequency = newton_update_frequency  # 每多少次迭代使用一次牛顿法
        self.iteration_count = 0

        # 默认网络形状为 (2 * 5)
        self.network_shape = network_shape if network_shape else (5, 5)

        # 存储梯度信息用于牛顿法
        self._gradients = collections.defaultdict(lambda: np.zeros(1))
        self._hessians = collections.defaultdict(lambda: np.eye(1))

    def _iterate(self):
        """执行一次训练迭代"""
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
        
        # 计算梯度
        self._compute_gradients(deltas)
        
        # 每newton_update_frequency次迭代使用一次牛顿法，其他时候使用梯度下降
        if self.iteration_count % self.newton_update_frequency == 0:
            self._adjust_weights_with_newton()
        else:
            self._adjust_weights_with_gradient(deltas)
        
        self.iteration_count += 1

    def _initialize_neurons(self):
        """初始化神经元网络"""
        if self.activation_function == 'bipolar_sigmoid':
            activation_func = bipolar_sigmoid
        else:
            activation_func = sigmoid
            
        self._neurons = tuple((Perceptron(activation_func),) * size
                              for size in list(self.network_shape) + [1])

    def _feed_forward(self, data):
        """前向传播"""
        if not hasattr(self, '_neurons') or not self._neurons:
            self._initialize_neurons()
            
        # 确保神经元有数据输入
        for neuron in self._neurons[0]:
            neuron.data = data  # 这会自动初始化权重
            
        results = []
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
            else:
                results = get_layer_results(layer, results)
        
        # 确保返回单个数值而不是数组
        if isinstance(results, (list, np.ndarray)) and len(results) == 1:
            return float(results[0])
        elif isinstance(results, (list, np.ndarray)) and len(results) > 0:
            return float(results[0])  # 对于多输出，返回第一个
        else:
            return 0.0  # 默认值

    def _pass_backward(self, expect, result):
        """反向传播计算误差"""
        deltas = {}

        # 输出层误差计算
        if self.activation_function == 'bipolar_sigmoid':
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * bipolar_sigmoid_derivative(result))
        else:
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * sigmoid_derivative(result))

        # 隐藏层误差反向传播
        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                if self.activation_function == 'bipolar_sigmoid':
                    deltas[neuron] = (
                        sum(deltas[n] * n.synaptic_weight[neuron_idx]
                            for n in self._neurons[layer_idx + 1])
                        * bipolar_sigmoid_derivative(neuron.result)
                    )
                else:
                    deltas[neuron] = (
                        sum(deltas[n] * n.synaptic_weight[neuron_idx]
                            for n in self._neurons[layer_idx + 1])
                        * sigmoid_derivative(neuron.result)
                    )
        return deltas

    def _compute_gradients(self, deltas):
        """计算梯度用于牛顿法"""
        for neuron in deltas:
            # 计算当前梯度
            current_gradient = self.current_learning_rate * deltas[neuron] * neuron.data
            
            # 更新梯度信息（指数加权平均）
            self._gradients[neuron] = 0.9 * self._gradients[neuron] + 0.1 * current_gradient

    def _adjust_weights_with_gradient(self, deltas):
        """使用梯度下降法调整权重"""
        for neuron in deltas:
            gradient = self.current_learning_rate * deltas[neuron] * neuron.data
            neuron.synaptic_weight += gradient

    def _adjust_weights_with_newton(self):
        """使用简化的牛顿法调整权重"""
        for neuron in self._gradients:
            if len(neuron.synaptic_weight) > 1:  # 避免对单个权重的神经元使用牛顿法
                try:
                    # 简化的牛顿法：使用自适应学习率
                    gradient = self._gradients[neuron]
                    current_weights = neuron.synaptic_weight.copy()
                    
                    # 计算梯度大小
                    gradient_norm = np.linalg.norm(gradient)
                    
                    if gradient_norm < 1e-8:  # 梯度太小，跳过更新
                        continue
                    
                    # 自适应学习率：根据梯度大小调整
                    # 梯度越大，学习率越小（牛顿法的思想）
                    adaptive_learning_rate = self.current_learning_rate / (1 + gradient_norm)
                    
                    # 应用牛顿法思想的自适应更新
                    newton_update = gradient * adaptive_learning_rate
                    
                    # 限制更新步长
                    max_step = 0.5
                    update_norm = np.linalg.norm(newton_update)
                    if update_norm > max_step:
                        newton_update = newton_update * max_step / update_norm
                    
                    # 应用更新
                    neuron.synaptic_weight -= newton_update
                    
                except (np.linalg.LinAlgError, ValueError, ZeroDivisionError):
                    # 如果牛顿法失败，回退到梯度下降
                    neuron.synaptic_weight += self._gradients[neuron] * self.current_learning_rate

    def _correct_rate(self, dataset):
        """计算正确率"""
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """归一化期望输出"""
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))


def get_layer_results(layer, data):
    """获取一层神经元的输出结果"""
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)