"""
OLS (Orthogonal Least Squares) for RBF Network Center Selection

Based on RBFN structure, but uses OLS forward selection instead of K-means.
"""
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import RbfNeuron
from ..utils import gaussian


class OlsRbfnAlgorithm(PredictiveAlgorithm):
    """
    RBF神经网络的OLS算法 - 完全基于RBFN结构
    
    与RBFN的唯一区别：使用OLS前向选择代替K-means聚类
    """
    
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 acceptable_range=0.5, initial_learning_rate=0.8,
                 search_iteration_constant=10000, max_centers=10,
                 err_threshold=0.01, test_ratio=0.3, sigma=1.0):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.acceptable_range = acceptable_range
        self.max_centers = max_centers
        self.err_threshold = err_threshold
        self.sigma = sigma
        
        # OLS特有的历史记录
        self.selected_centers = []
        self.err_history = []
        self.center_selection_history = []

    def _iterate(self):
        """单次迭代 - 与RBFN完全相同"""
        result = self._feed_forward(self.current_data[:-1])
        self._adjust_neurons(result)

    def _initialize_neurons(self):
        """使用OLS前向选择算法初始化RBF中心 - 这是与RBFN的唯一区别"""
        print("\n🎯 开始OLS中心选择...")
        
        # 准备候选中心（从训练数据中选择）
        candidate_centers = self.training_dataset[:, :-1]
        target = self.training_dataset[:, -1:]
        N = len(self.training_dataset)
        M = len(candidate_centers)
        
        # 限制候选数量
        if M > self.max_centers * 3:
            indices = np.random.choice(M, self.max_centers * 3, replace=False)
            candidate_centers = candidate_centers[indices]
            M = len(candidate_centers)
        
        # 确保sigma有效
        sigma = max(self.sigma, 0.1)
        
        # 计算设计矩阵 H (N x M)
        H = np.zeros((N, M))
        for i in range(N):
            for j in range(M):
                H[i, j] = gaussian(self.training_dataset[i, :-1], 
                                  candidate_centers[j], 
                                  sigma)
        
        # OLS前向选择
        selected_indices = []
        U = H.copy()
        err_list = []
        
        for step in range(min(self.max_centers, M)):
            if step > 0:
                # Gram-Schmidt正交化
                for j in range(M):
                    if j not in selected_indices:
                        u_j = H[:, j].copy()
                        for idx in selected_indices:
                            alpha = np.dot(U[:, idx], H[:, j]) / (np.dot(U[:, idx], U[:, idx]) + 1e-10)
                            u_j = u_j - alpha * U[:, idx]
                        U[:, j] = u_j
            
            # 计算ERR
            err_values = np.zeros(M)
            for j in range(M):
                if j not in selected_indices:
                    u_j = U[:, j]
                    numerator = np.dot(u_j, target.flatten()) ** 2
                    denominator = np.dot(u_j, u_j) * np.dot(target.flatten(), target.flatten())
                    if denominator > 1e-10:
                        err_values[j] = numerator / denominator
            
            # 选择ERR最大的中心
            best_idx = np.argmax(err_values)
            best_err = err_values[best_idx]
            
            # 如果ERR太小，停止
            if best_err < self.err_threshold:
                print(f"  步骤 {step+1}: ERR={best_err:.6f} < 阈值，停止选择")
                break
            
            selected_indices.append(best_idx)
            err_list.append(best_err)
            
            print(f"  步骤 {step+1}: 选择中心 #{best_idx}, ERR={best_err:.6f}")
            
            # 记录历史
            self.center_selection_history.append({
                'step': step + 1,
                'center_idx': int(best_idx),
                'center': candidate_centers[best_idx].tolist(),
                'err': float(best_err)
            })
        
        self.err_history = err_list
        self.selected_centers = [candidate_centers[idx] for idx in selected_indices]
        
        print(f"✅ OLS选择完成! 共 {len(selected_indices)} 个中心")
        
        # 创建神经元 - 与RBFN结构相同
        # 先创建RBF中心神经元
        self._neurons = []
        for center in self.selected_centers:
            neuron = RbfNeuron(center, sigma)
            self._neurons.append(neuron)
        
        # 添加阈值神经元（偏置）
        self._neurons.insert(0, RbfNeuron(is_threshold=True))
        
        # 使用最小二乘法初始化权重
        self._initialize_weights_by_least_squares()
        
        print(f"✅ 权重初始化完成")

    def _initialize_weights_by_least_squares(self):
        """使用最小二乘法初始化权重"""
        N = len(self.training_dataset)
        M = len(self._neurons)
        
        # 构建设计矩阵 Φ (N x M)
        Phi = np.ones((N, M))
        
        for i in range(N):
            for j in range(1, M):  # 跳过阈值神经元（第0个）
                neuron = self._neurons[j]
                neuron.data = self.training_dataset[i, :-1]
                Phi[i, j] = neuron.activation_function(
                    neuron.data, neuron.mean, neuron.standard_deviation
                )
        
        # 目标输出
        target = self.training_dataset[:, -1:]
        
        # 最小二乘解：w = (Φ^T Φ)^{-1} Φ^T y
        try:
            PhiT_Phi = np.dot(Phi.T, Phi)
            PhiT_y = np.dot(Phi.T, target)
            # 添加小的正则项避免奇异
            reg = 1e-6 * np.eye(PhiT_Phi.shape[0])
            weights = np.linalg.solve(PhiT_Phi + reg, PhiT_y)
            
            # 设置权重
            for j in range(M):
                w = float(weights[j])
                if np.isfinite(w):
                    self._neurons[j].synaptic_weight = w
                else:
                    self._neurons[j].synaptic_weight = 0.0
                    
        except np.linalg.LinAlgError:
            print("⚠️  矩阵奇异，使用伪逆")
            weights = np.linalg.lstsq(Phi, target, rcond=None)[0]
            for j in range(M):
                w = float(weights[j])
                if np.isfinite(w):
                    self._neurons[j].synaptic_weight = w
                else:
                    self._neurons[j].synaptic_weight = 0.0

    def _feed_forward(self, data):
        """前向传播 - 与RBFN完全相同"""
        for neuron in self._neurons:
            neuron.data = data
        return sum(neuron.result for neuron in self._neurons)

    def _adjust_neurons(self, output):
        """调整神经元 - 与RBFN完全相同"""
        expect = self.current_data[-1]
        for neuron in self._neurons:
            new_synaptic_weight_diff = self._get_synaptic_weight_diff(
                output, expect, neuron
            )
            if not neuron.is_threshold and neuron.standard_deviation != 0:
                data_mean_diff = neuron.data - neuron.mean
                new_mean = (neuron.mean
                            + new_synaptic_weight_diff
                            * neuron.synaptic_weight
                            * data_mean_diff
                            / neuron.standard_deviation**2)
                new_standard_deviation = (neuron.standard_deviation
                                          + new_synaptic_weight_diff
                                          * neuron.synaptic_weight
                                          * data_mean_diff.dot(data_mean_diff)
                                          / neuron.standard_deviation**3)
                neuron.mean, neuron.standard_deviation = new_mean, new_standard_deviation
            neuron.synaptic_weight += new_synaptic_weight_diff

    def _get_synaptic_weight_diff(self, output, expect, neuron):
        """计算权重变化 - 与RBFN完全相同"""
        if neuron.is_threshold:
            return self.current_learning_rate * (expect - output)
        return self.current_learning_rate * (expect - output) * neuron.activation_function(
            neuron.data, neuron.mean, neuron.standard_deviation
        )

    def _correct_rate(self, dataset):
        """计算准确率 - 与RBFN完全相同"""
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            if data[-1] - self.acceptable_range < result < data[-1] + self.acceptable_range:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)
