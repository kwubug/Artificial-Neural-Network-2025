import numpy as np
import matplotlib.pyplot as plt

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class OLSVisualizer:
    def __init__(self):
        # 手动生成示例数据
        np.random.seed(42)
        self.X = np.linspace(0, 10, 20)
        self.y = 2 * self.X + 1 + np.random.normal(0, 2, size=self.X.shape)

        # OLS参数
        self.theta_0 = 0  # 截距
        self.theta_1 = 0  # 斜率
        self.history = []  # 记录参数历史

        # 计算最优解（解析解）
        self.optimal_theta_1 = np.sum((self.X - np.mean(self.X)) * (self.y - np.mean(self.y))) / \
                               np.sum((self.X - np.mean(self.X)) ** 2)
        self.optimal_theta_0 = np.mean(self.y) - self.optimal_theta_1 * np.mean(self.X)

    def compute_cost(self, theta_0, theta_1):
        """计算均方误差成本函数"""
        y_pred = theta_0 + theta_1 * self.X
        cost = np.mean((self.y - y_pred) ** 2) / 2
        return cost

    def gradient_descent_step(self, learning_rate=0.01):
        """执行一次梯度下降步骤"""
        # 计算预测值
        y_pred = self.theta_0 + self.theta_1 * self.X

        # 计算梯度
        grad_theta_0 = np.mean(y_pred - self.y)
        grad_theta_1 = np.mean((y_pred - self.y) * self.X)

        # 更新参数
        self.theta_0 -= learning_rate * grad_theta_0
        self.theta_1 -= learning_rate * grad_theta_1

        # 记录历史
        self.history.append((self.theta_0, self.theta_1, self.compute_cost(self.theta_0, self.theta_1)))

    def plot_data_and_line(self, ax, theta_0, theta_1, title):
        """绘制数据点和拟合直线"""
        ax.clear()
        ax.scatter(self.X, self.y, color='blue', alpha=0.6, label='数据点')
        x_line = np.linspace(np.min(self.X), np.max(self.X), 100)
        y_line = theta_0 + theta_1 * x_line
        ax.plot(x_line, y_line, color='red', linewidth=2, label=f'拟合线: y = {theta_0:.2f} + {theta_1:.2f}x')

        # 绘制最优解线
        y_optimal = self.optimal_theta_0 + self.optimal_theta_1 * x_line
        ax.plot(x_line, y_optimal, color='green', linestyle='--', linewidth=1, label='最优解')

        ax.set_xlabel('X')
        ax.set_ylabel('y')
        ax.set_title(title)
        ax.legend()
        ax.grid(True, alpha=0.3)

    def visualize_ols_process(self):
        """可视化OLS学习过程"""
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('OLS算法可视化演示', fontsize=16, fontweight='bold')

        # 初始化参数
        self.theta_0 = 0
        self.theta_1 = 0
        self.history = []

        # 绘制初始状态
        self.plot_data_and_line(ax1, self.theta_0, self.theta_1, '初始状态')

        # 执行多次梯度下降
        costs = []
        for i in range(100):
            self.gradient_descent_step(learning_rate=0.01)
            costs.append(self.history[-1][2])

            # 每10步更新一次可视化
            if i % 10 == 0 or i == 99:
                self.plot_data_and_line(
                    ax1,
                    self.theta_0,
                    self.theta_1,
                    f'迭代 {i + 1} 次后'
                )

                # 绘制成本函数变化
                ax2.clear()
                iterations = range(len(costs))
                ax2.plot(iterations, costs, 'b-', linewidth=2)
                ax2.set_xlabel('迭代次数')
                ax2.set_ylabel('成本函数值')
                ax2.set_title('成本函数随迭代的变化')
                ax2.grid(True, alpha=0.3)

                # 绘制参数空间等高线
                self.plot_parameter_space(ax3)

                # 绘制3D成本函数
                self.plot_3d_cost_function(ax4)

                plt.pause(0.1)

        plt.show()

    def plot_parameter_space(self, ax):
        """绘制参数空间等高线图"""
        theta_0_range = np.linspace(self.optimal_theta_0 - 10, self.optimal_theta_0 + 10, 50)
        theta_1_range = np.linspace(self.optimal_theta_1 - 5, self.optimal_theta_1 + 5, 50)
        Theta_0, Theta_1 = np.meshgrid(theta_0_range, theta_1_range)

        # 计算每个点的成本
        Cost = np.zeros_like(Theta_0)
        for i in range(Theta_0.shape[0]):
            for j in range(Theta_0.shape[1]):
                Cost[i, j] = self.compute_cost(Theta_0[i, j], Theta_1[i, j])

        # 绘制等高线
        contour = ax.contour(Theta_0, Theta_1, Cost, levels=20, alpha=0.6)
        ax.clabel(contour, inline=True, fontsize=8)

        # 绘制最优解
        ax.plot(self.optimal_theta_0, self.optimal_theta_1, 'r*', markersize=15, label='最优解')

        # 绘制参数轨迹
        if len(self.history) > 1:
            theta_0_hist = [h[0] for h in self.history]
            theta_1_hist = [h[1] for h in self.history]
            ax.plot(theta_0_hist, theta_1_hist, 'b-o', markersize=4, alpha=0.7, label='参数轨迹')
            ax.plot(theta_0_hist[-1], theta_1_hist[-1], 'go', markersize=8, label='当前参数')

        ax.set_xlabel('θ₀ (截距)')
        ax.set_ylabel('θ₁ (斜率)')
        ax.set_title('参数空间等高线图')
        ax.legend()
        ax.grid(True, alpha=0.3)

    def plot_3d_cost_function(self, ax):
        """绘制3D成本函数图"""
        from mpl_toolkits.mplot3d import Axes3D

        # 创建3D子图
        ax = plt.subplot(2, 2, 4, projection='3d')

        theta_0_range = np.linspace(self.optimal_theta_0 - 10, self.optimal_theta_0 + 10, 30)
        theta_1_range = np.linspace(self.optimal_theta_1 - 5, self.optimal_theta_1 + 5, 30)
        Theta_0, Theta_1 = np.meshgrid(theta_0_range, theta_1_range)

        # 计算每个点的成本
        Cost = np.zeros_like(Theta_0)
        for i in range(Theta_0.shape[0]):
            for j in range(Theta_0.shape[1]):
                Cost[i, j] = self.compute_cost(Theta_0[i, j], Theta_1[i, j])

        # 绘制3D表面
        surf = ax.plot_surface(Theta_0, Theta_1, Cost, cmap='viridis', alpha=0.7)

        # 绘制最优解
        ax.scatter([self.optimal_theta_0], [self.optimal_theta_1],
                   [self.compute_cost(self.optimal_theta_0, self.optimal_theta_1)],
                   color='red', s=100, label='最优解')

        # 绘制参数轨迹
        if len(self.history) > 1:
            theta_0_hist = [h[0] for h in self.history]
            theta_1_hist = [h[1] for h in self.history]
            cost_hist = [h[2] for h in self.history]
            ax.plot(theta_0_hist, theta_1_hist, cost_hist, 'b-o', markersize=4, alpha=0.7)
            ax.scatter([theta_0_hist[-1]], [theta_1_hist[-1]], [cost_hist[-1]],
                       color='green', s=50, label='当前参数')

        ax.set_xlabel('θ₀ (截距)')
        ax.set_ylabel('θ₁ (斜率)')
        ax.set_zlabel('成本')
        ax.set_title('3D成本函数图')


def main():
    # 创建可视化对象
    ols_viz = OLSVisualizer()

    # 显示解析解
    print("OLS解析解:")
    print(f"θ₀ (截距): {ols_viz.optimal_theta_0:.4f}")
    print(f"θ₁ (斜率): {ols_viz.optimal_theta_1:.4f}")

    # 运行可视化
    ols_viz.visualize_ols_process()


if __name__ == "__main__":
    main()
