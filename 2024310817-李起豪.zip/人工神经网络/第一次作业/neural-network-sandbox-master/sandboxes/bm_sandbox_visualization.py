"""
沙箱式可视化：三个神经元的Boltzmann Machine (BM) 运行过程。

参考第一次作业中的沙箱代码结构，将算法逻辑、可视化与结果导出解耦：
1. `BoltzmannMachine` 负责网络能量、状态更新；
2. `SandboxRunner` 负责调度采样、记录指标；
3. `SandboxVisualizer` 完成结果绘图并输出摘要文件。

产出：
  - `bm_energy_trajectory.png`：能量随迭代变化图；
  - `bm_state_distribution.png`：热平衡状态分布；
  - `bm_summary.txt`：关键统计信息。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np


np.random.seed(2025)
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial"]
plt.rcParams["axes.unicode_minus"] = False


@dataclass(frozen=True)
class BMConfig:
    steps: int = 6000
    burn_in: int = 800
    beta_min: float = 0.6
    beta_max: float = 1.4
    initial_state: Tuple[int, int, int] = (0, 1, 0)


class BoltzmannMachine:
    """三个神经元的完全连接BM，采用二值(0/1)表示。"""

    def __init__(self, weights: np.ndarray, biases: np.ndarray) -> None:
        self.weights = np.array(weights, dtype=np.float64)
        self.biases = np.array(biases, dtype=np.float64)
        if self.weights.shape[0] != self.weights.shape[1]:
            raise ValueError("权重矩阵必须为方阵")
        if self.weights.shape[0] != self.biases.size:
            raise ValueError("权重矩阵与偏置维度不匹配")
        if not np.allclose(self.weights, self.weights.T, atol=1e-10):
            raise ValueError("权重矩阵必须对称")
        np.fill_diagonal(self.weights, 0.0)
        self.n_units = self.biases.size

    def energy(self, state: np.ndarray) -> float:
        return -0.5 * state @ self.weights @ state - self.biases @ state

    def _sample_single(self, state: np.ndarray, idx: int, beta: float) -> None:
        total_input = self.weights[idx] @ state + self.biases[idx]
        prob_on = 1.0 / (1.0 + np.exp(-beta * total_input))
        state[idx] = 1 if np.random.rand() < prob_on else 0

    def gibbs_step(self, state: np.ndarray, beta: float) -> np.ndarray:
        updated = state.copy()
        for idx in np.random.permutation(self.n_units):
            self._sample_single(updated, idx, beta)
        return updated


class SandboxRunner:
    """管理BM采样流程并记录状态轨迹、能量与β值。"""

    def __init__(self, bm: BoltzmannMachine, config: BMConfig) -> None:
        self.bm = bm
        self.config = config

    def _beta_schedule(self) -> np.ndarray:
        return np.linspace(self.config.beta_min, self.config.beta_max, self.config.steps)

    def run(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        state = np.array(self.config.initial_state, dtype=np.float64)
        betas = self._beta_schedule()
        states: List[np.ndarray] = []
        energies: List[float] = []

        for beta in betas:
            state = self.bm.gibbs_step(state, beta)
            states.append(state.copy())
            energies.append(self.bm.energy(state))

        return np.vstack(states), np.asarray(energies), betas


class SandboxVisualizer:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _state_to_str(state: np.ndarray) -> str:
        return "".join(str(bit) for bit in state.astype(int))

    def analyze_distribution(
        self,
        states: np.ndarray,
        config: BMConfig,
    ) -> Tuple[str, float, List[Tuple[str, float]], Dict[str, float]]:
        effective_states = states[config.burn_in :]
        counts: Dict[str, int] = {}
        for state in effective_states:
            key = self._state_to_str(state)
            counts[key] = counts.get(key, 0) + 1
        total = effective_states.shape[0]
        distribution = sorted(
            ((state, count / total) for state, count in counts.items()),
            key=lambda item: item[1],
            reverse=True,
        )
        top_state, top_prob = distribution[0]
        return top_state, top_prob, distribution, {state: prob for state, prob in distribution}

    def plot_energy(
        self,
        energies: np.ndarray,
        config: BMConfig,
    ) -> Path:
        fig, ax = plt.subplots(figsize=(7, 4))
        iterations = np.arange(1, energies.size + 1)
        ax.plot(iterations, energies, color="tab:blue", linewidth=1.2, label="能量")
        ax.axvline(config.burn_in, color="tab:orange", linestyle="--", linewidth=1.0, label="Burn-in")
        ax.set_xlabel("迭代步")
        ax.set_ylabel("能量")
        ax.set_title("BM能量轨迹")
        ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
        ax.legend(loc="upper right")
        fig.tight_layout()
        path = self.output_dir / "bm_energy_trajectory.png"
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        return path

    def plot_distribution(
        self,
        distribution: List[Tuple[str, float]],
    ) -> Path:
        labels = [item[0] for item in distribution]
        probs = [item[1] for item in distribution]
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.bar(np.arange(len(labels)), probs, color="tab:green")
        ax.set_xticks(np.arange(len(labels)))
        ax.set_xticklabels(labels)
        ax.set_xlabel("状态 (二进制)")
        ax.set_ylabel("概率")
        ax.set_title("热平衡状态分布")
        ax.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
        fig.tight_layout()
        path = self.output_dir / "bm_state_distribution.png"
        fig.savefig(path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        return path

    def export_summary(
        self,
        config: BMConfig,
        top_state: str,
        top_prob: float,
        distribution_map: Dict[str, float],
        energies: np.ndarray,
    ) -> Path:
        summary = [
            "BM沙箱可视化结果摘要",
            f"总迭代步数: {config.steps}",
            f"Burn-in步数: {config.burn_in}",
            f"β范围: [{config.beta_min:.2f}, {config.beta_max:.2f}]",
            f"最可能状态: {top_state} (概率 {top_prob:.4f})",
            f"Burn-in后能量均值: {np.mean(energies[config.burn_in:]):.4f}",
            "状态概率：",
        ]
        summary.extend(
            f"  {state}: {prob:.4f}" for state, prob in distribution_map.items()
        )
        path = self.output_dir / "bm_summary.txt"
        path.write_text("\n".join(summary), encoding="utf-8")
        return path


def main() -> None:
    config = BMConfig()
    weights = np.array(
        [
            [0.0, 0.9, -0.7],
            [0.9, 0.0, 0.5],
            [-0.7, 0.5, 0.0],
        ]
    )
    biases = np.array([-0.3, 0.25, 0.05])

    bm = BoltzmannMachine(weights=weights, biases=biases)
    runner = SandboxRunner(bm=bm, config=config)
    states, energies, _ = runner.run()

    visualizer = SandboxVisualizer(output_dir=Path(__file__).parent)
    top_state, top_prob, distribution, distribution_map = visualizer.analyze_distribution(
        states=states, config=config
    )
    visualizer.plot_energy(energies=energies, config=config)
    visualizer.plot_distribution(distribution=distribution)
    visualizer.export_summary(
        config=config,
        top_state=top_state,
        top_prob=top_prob,
        distribution_map=distribution_map,
        energies=energies,
    )

    print(f"BM沙箱完成：最可能状态 {top_state}, 概率 {top_prob:.4f}")


if __name__ == "__main__":
    main()


