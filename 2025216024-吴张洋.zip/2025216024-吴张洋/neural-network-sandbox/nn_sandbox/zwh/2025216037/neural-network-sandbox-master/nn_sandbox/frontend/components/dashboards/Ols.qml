import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'OLS'

    property int lastPlottedIteration: 0
    property int targetMaxPoints: 1200
    property bool bridgeReady: typeof olsBridge !== 'undefined' && olsBridge !== null
    
    Component.onCompleted: {
        console.log("OLS Page loaded")
        console.log("olsBridge exists:", typeof olsBridge !== 'undefined')
        if (typeof olsBridge !== 'undefined') {
            console.log("olsBridge is null:", olsBridge === null)
        }
    }
    
    function computeStride() {
        if (!bridgeReady || !olsBridge.training_dataset)
            return 1
        const trainLen = olsBridge.training_dataset.length || 1
        const totalIters = Math.max(1, totalEpoches.value * trainLen)
        return Math.max(1, Math.floor(totalIters / targetMaxPoints))
    }
    
    Timer {
        id: uiTimer
        interval: 50
        repeat: true
        running: false
        onTriggered: {
            if (!bridgeReady)
                return
            const stride = computeStride()
            const nextIter = Math.min(olsBridge.current_iterations, lastPlottedIteration + stride)
            if (nextIter <= lastPlottedIteration)
                return
            regressionChart.updateLine()
            lastPlottedIteration = nextIter
        }
    }

    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: bridgeReady ? Object.keys(olsBridge.dataset_dict) : []
                enabled: bridgeReady ? olsBridge.has_finished : false
                onActivated: {
                    if (!bridgeReady) return
                    olsBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                    regressionChart.updateLine()
                }
                Component.onCompleted: {
                    if (!bridgeReady) return
                    olsBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                    regressionChart.updateLine()
                }
            }
        }

        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label { text: 'Total Training Epoches'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: totalEpoches
                    enabled: bridgeReady ? olsBridge.has_finished : false
                    editable: true
                    value: 20
                    to: 999999
                    onValueChanged: { if (bridgeReady) olsBridge.total_epoches = value }
                    Component.onCompleted: { if (bridgeReady) olsBridge.total_epoches = value }
                    Layout.fillWidth: true
                }

                Label { text: 'Initial Learning Rate'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bridgeReady ? olsBridge.has_finished : false
                    editable: true
                    value: 0.1 * 100
                    onValueChanged: { if (bridgeReady) olsBridge.initial_learning_rate = value / 100 }
                    Component.onCompleted: { if (bridgeReady) olsBridge.initial_learning_rate = value / 100 }
                    Layout.fillWidth: true
                }

                Label { text: 'Search Iteration Constant'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: bridgeReady ? olsBridge.has_finished : false
                    editable: true
                    value: 1000
                    to: 999999
                    onValueChanged: { if (bridgeReady) olsBridge.search_iteration_constant = value }
                    Component.onCompleted: { if (bridgeReady) olsBridge.search_iteration_constant = value }
                    Layout.fillWidth: true
                }

                Label { text: 'Test-Train Ratio'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bridgeReady ? olsBridge.has_finished : false
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: { if (bridgeReady) olsBridge.test_ratio = value / 100 }
                    Component.onCompleted: { if (bridgeReady) olsBridge.test_ratio = value / 100 }
                    Layout.fillWidth: true
                }

                Label { text: 'UI Refresh Interval'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bridgeReady ? olsBridge.has_finished : false
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: { if (bridgeReady) olsBridge.ui_refresh_interval = value / 100 }
                    Component.onCompleted: { if (bridgeReady) olsBridge.ui_refresh_interval = value / 100 }
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                visible: bridgeReady

                ExecutionControls {
                    startButton.enabled: bridgeReady ? olsBridge.has_finished : false
                    startButton.onClicked: {
                        if (!bridgeReady) return
                        olsBridge.start_ols_algorithm()
                        dataChart.clear()
                        if (olsBridge.training_dataset)
                            dataChart.updateTrainingDataset(olsBridge.training_dataset)
                        if (olsBridge.testing_dataset)
                            dataChart.updateTestingDataset(olsBridge.testing_dataset)
                        regressionChart.updateLine()
                        lastPlottedIteration = 0
                        uiTimer.start()
                    }
                    stopButton.enabled: bridgeReady ? !olsBridge.has_finished : false
                    stopButton.onClicked: { if (bridgeReady) olsBridge.stop_ols_algorithm() }
                    progressBar.value: (bridgeReady && olsBridge.training_dataset && olsBridge.training_dataset.length > 0) ? 
                        (olsBridge.current_iterations + 1) / (totalEpoches.value * olsBridge.training_dataset.length) : 0
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: 'Current Training Epoch'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: {
                        if (!bridgeReady || !olsBridge.training_dataset || olsBridge.training_dataset.length === 0)
                            return '1'
                        const epoch = Math.floor(olsBridge.current_iterations / olsBridge.training_dataset.length) + 1
                        return isNaN(epoch) ? '1' : epoch.toString()
                    }
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label { text: 'Current Training Iteration'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: bridgeReady ? (olsBridge.current_iterations + 1).toString() : '0'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label { text: 'Current Learning Rate'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: bridgeReady ? olsBridge.current_learning_rate.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true 
                }

                Label { text: 'R² (Training)'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: bridgeReady ? olsBridge.r2_training.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true 
                }

                Label { text: 'R² (Testing)'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: bridgeReady ? olsBridge.r2_testing.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true 
                }

                Label { text: 'Coefficient a'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: bridgeReady ? olsBridge.a.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true 
                }

                Label { text: 'Intercept b'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: bridgeReady ? olsBridge.b.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true 
                }
            }
        }
    }

    ColumnLayout {
        visible: bridgeReady
        
        DataChart {
            id: dataChart
            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true
        }

        ChartView {
            id: regressionChart
            Layout.fillWidth: true
            Layout.fillHeight: true
            antialiasing: true
            legend.visible: false
            ValueAxis { id: rx; min: dataChart.xAxis ? dataChart.xAxis.min : 0; max: dataChart.xAxis ? dataChart.xAxis.max : 1 }
            ValueAxis { id: ry; min: dataChart.yAxis ? dataChart.yAxis.min : 0; max: dataChart.yAxis ? dataChart.yAxis.max : 1 }

            property var line: null

            function updateLine() {
                if (!bridgeReady)
                    return
                removeAllSeries()
                line = createSeries(ChartView.SeriesTypeLine, 'OLS', rx, ry)
                line.useOpenGL = true
                const x1 = rx.min
                const x2 = rx.max
                const y1 = olsBridge.a * x1 + olsBridge.b
                const y2 = olsBridge.a * x2 + olsBridge.b
                line.append(x1, y1)
                line.append(x2, y2)
            }
        }
    }

    Connections {
        target: bridgeReady ? olsBridge : null
        enabled: bridgeReady
        
        function onHasFinishedChanged() {
            if (!bridgeReady) return
            regressionChart.updateLine()
            if (olsBridge.has_finished) {
                uiTimer.stop()
            } else {
                lastPlottedIteration = 0
                uiTimer.start()
            }
        }
        
        function onAChanged() { 
            if (bridgeReady) regressionChart.updateLine() 
        }
        
        function onBChanged() { 
            if (bridgeReady) regressionChart.updateLine() 
        }
        
        function onTrainingDatasetChanged() {
            if (!bridgeReady) return
            dataChart.clear()
            if (olsBridge.training_dataset)
                dataChart.updateTrainingDataset(olsBridge.training_dataset)
            regressionChart.updateLine()
        }
        
        function onTestingDatasetChanged() {
            if (!bridgeReady) return
            if (olsBridge.testing_dataset)
                dataChart.updateTestingDataset(olsBridge.testing_dataset)
            regressionChart.updateLine()
        }
    }
}