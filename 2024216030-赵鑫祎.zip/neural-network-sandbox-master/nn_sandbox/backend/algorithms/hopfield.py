# -*- coding: utf-8 -*-
"""
A robust, visualization-friendly implementation of a Hopfield network, using -1/1 bipolar encoding.
"""
import numpy as np

class HopfieldNetwork:
    """
    A discrete Hopfield network implementation.

    This network stores and retrieves patterns using a bipolar representation (-1, 1).
    The weights are trained using the Hebbian learning rule. The network can be updated
    synchronously or asynchronously until it converges to a stable state (an attractor).
    """

    def __init__(self, num_neurons):
        """
        Initializes the Hopfield network.

        Args:
            num_neurons (int): The number of neurons in the network, corresponding to the
                               flattened length of the patterns.
        """
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))
        self.state = np.zeros(num_neurons)

    def train(self, patterns):
        """
        Trains the network on a set of patterns using the Hebbian rule.

        The weight matrix is calculated as the outer product of the patterns. The diagonal
        of the weight matrix is set to zero to prevent self-connections.

        Args:
            patterns (list of np.ndarray): A list of 1D bipolar patterns to be stored.
        """
        if not patterns:
            return

        # Normalize weights by the number of patterns
        rho = np.sum([np.outer(p, p) for p in patterns], axis=0)
        self.weights = rho / self.num_neurons
        np.fill_diagonal(self.weights, 0)

    def set_initial_state(self, pattern):
        """
        Sets the initial state of the network.

        Args:
            pattern (np.ndarray): The 1D bipolar pattern to set as the initial state.
        """
        self.state = np.copy(pattern)

    def update_asynchronous(self):
        """
        Performs a single asynchronous update step.

        A random neuron is selected, and its state is updated based on the weighted sum
        of the inputs from other neurons.

        Returns:
            int: The index of the updated neuron.
        """
        neuron_idx = np.random.randint(0, self.num_neurons)
        activation = np.dot(self.weights[neuron_idx, :], self.state)
        
        # Update rule: state becomes 1 if activation >= 0, else -1
        self.state[neuron_idx] = 1 if activation >= 0 else -1
        
        return neuron_idx

    def update_synchronous(self):
        """
        Performs a full synchronous update of the network state.

        All neurons are updated simultaneously based on the previous state.

        Returns:
            np.ndarray: The new state of the network.
        """
        new_state = np.sign(np.dot(self.weights, self.state))
        # Handle the case where the sign is 0
        new_state[new_state == 0] = 1
        self.state = new_state
        return self.state

    def run_to_convergence(self, max_iter=100):
        """
        Runs the network asynchronously until it reaches a stable state or max_iter.

        Args:
            max_iter (int): The maximum number of iterations to prevent infinite loops.

        Returns:
            list: A history of states from the initial state to the final stable state.
        """
        history = [np.copy(self.state)]
        for _ in range(max_iter):
            self.update_asynchronous()
            current_state = np.copy(self.state)
            # If the state has not changed from the previous state, it has converged
            if np.array_equal(current_state, history[-1]):
                break
            history.append(current_state)
        return history

    def calculate_energy(self, state=None):
        """
        Calculates the Lyapunov energy of the network for a given state.

        The energy function is defined as E = -0.5 * Σ(i,j) w_ij * s_i * s_j.

        Args:
            state (np.ndarray, optional): The state for which to calculate the energy.
                                          If None, the current network state is used.

        Returns:
            float: The energy of the network.
        """
        if state is None:
            state = self.state
        
        return -0.5 * np.sum(self.weights * np.outer(state, state))

    def get_current_state(self):
        """
        Returns the current state of the network.

        Returns:
            np.ndarray: The current 1D bipolar state vector.
        """
        return self.state