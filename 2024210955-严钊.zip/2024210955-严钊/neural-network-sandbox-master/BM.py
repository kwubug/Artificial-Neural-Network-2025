import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, FancyArrow
import random
from math import exp


class BoltzmannMachine:
    def __init__(self, n_neurons, weights=None, biases=None):
        self.n_neurons = n_neurons
        self.temperature = 5.0
        self.initial_temperature = 5.0

        # Initialize weights and biases
        if weights is None:
            self.weights = np.random.uniform(-1, 1, (n_neurons, n_neurons))
            np.fill_diagonal(self.weights, 0)  # No self-connections
        else:
            self.weights = weights

        if biases is None:
            self.biases = np.random.uniform(-1, 1, n_neurons)
        else:
            self.biases = biases

        # Animation data
        self.states_history = []
        self.energy_history = []
        self.temperature_history = []
        self.probability_history = []

    def energy(self, state):
        """Calculate energy of the current state"""
        energy = 0
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                if i != j:
                    energy -= self.weights[i, j] * state[i] * state[j]
            energy -= self.biases[i] * state[i]
        return energy

    def probability_flip(self, neuron_idx, state):
        """Calculate probability of flipping a neuron"""
        local_field = 0
        for j in range(self.n_neurons):
            if j != neuron_idx:
                local_field += self.weights[neuron_idx, j] * state[j]
        local_field += self.biases[neuron_idx]

        delta_energy = 2 * state[neuron_idx] * local_field
        probability = 1 / (1 + exp(delta_energy / self.temperature))
        return probability

    def update_step(self, state):
        """Perform one update step"""
        new_state = state.copy()
        neuron_idx = random.randint(0, self.n_neurons - 1)

        prob_flip = self.probability_flip(neuron_idx, state)

        # Decide whether to flip
        if random.random() < prob_flip:
            new_state[neuron_idx] = -new_state[neuron_idx]

        return new_state, neuron_idx, prob_flip

    def run_animated(self, initial_state, max_iterations=100, cooling_rate=0.95):
        """Run BM with animation data collection"""
        state = initial_state.copy()

        # Record initial state
        self.states_history.append(state.copy())
        self.energy_history.append(self.energy(state))
        self.temperature_history.append(self.temperature)
        self.probability_history.append(0.5)  # Initial probability

        for iteration in range(max_iterations):
            new_state, neuron_idx, prob_flip = self.update_step(state)

            # Record data
            self.states_history.append(new_state.copy())
            self.energy_history.append(self.energy(new_state))
            self.temperature_history.append(self.temperature)
            self.probability_history.append(prob_flip)

            state = new_state

            # Cooling
            self.temperature = self.initial_temperature * cooling_rate ** iteration

            # Early termination if temperature is very low
            if self.temperature < 0.1:
                break

        return state


def create_boltzmann_animation():
    """Create Boltzmann Machine animation with 3 neurons"""

    # Define network parameters for 3 neurons
    weights = np.array([
        [0.0, 0.8, -0.5],
        [0.8, 0.0, 0.6],
        [-0.5, 0.6, 0.0]
    ])

    biases = np.array([0.2, -0.3, 0.1])

    # Create Boltzmann Machine
    bm = BoltzmannMachine(3, weights=weights, biases=biases)

    # Initial state (random)
    initial_state = np.array([1, -1, 1])  # Start with fixed state for reproducibility

    # Run simulation
    final_state = bm.run_animated(initial_state, max_iterations=80, cooling_rate=0.96)

    # Create animation figure
    fig = plt.figure(figsize=(16, 10))

    # Create subplots using GridSpec for better layout
    gs = plt.GridSpec(3, 3, figure=fig)

    # Network visualization
    ax_network = fig.add_subplot(gs[0:2, 0:2])
    # Energy plot
    ax_energy = fig.add_subplot(gs[0, 2])
    # Temperature plot
    ax_temp = fig.add_subplot(gs[1, 2])
    # Probability plot
    ax_prob = fig.add_subplot(gs[2, 0])
    # State history
    ax_state = fig.add_subplot(gs[2, 1:])

    # Set up network visualization
    neuron_positions = {
        0: (2, 3),
        1: (4, 3),
        2: (3, 1)
    }

    # Colors for neurons
    active_color = 'red'
    inactive_color = 'blue'

    # Initialize network elements
    neurons = []
    connections = []
    state_texts = []
    weight_texts = []

    # Draw connections first (so they are behind neurons)
    for i in range(3):
        for j in range(i + 1, 3):
            x1, y1 = neuron_positions[i]
            x2, y2 = neuron_positions[j]

            # Connection line
            connection, = ax_network.plot([x1, x2], [y1, y2], 'gray', linewidth=2, alpha=0.6)
            connections.append(connection)

            # Weight text
            mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
            weight_text = ax_network.text(mid_x, mid_y, f'w={weights[i, j]:.1f}',
                                          ha='center', va='center', fontsize=9,
                                          bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))
            weight_texts.append(weight_text)

    # Draw neurons
    for i in range(3):
        x, y = neuron_positions[i]
        color = active_color if initial_state[i] == 1 else inactive_color
        neuron = Circle((x, y), 0.3, facecolor=color, edgecolor='black', linewidth=2)
        ax_network.add_patch(neuron)
        neurons.append(neuron)

        # Bias text
        ax_network.text(x, y - 0.5, f'b={biases[i]:.1f}', ha='center', va='center', fontsize=9)

        # State text
        state_text = ax_network.text(x, y + 0.5, f'State: {initial_state[i]}',
                                     ha='center', va='center', fontsize=10, fontweight='bold')
        state_texts.append(state_text)

    # Setup network plot
    ax_network.set_xlim(1, 5)
    ax_network.set_ylim(0, 4)
    ax_network.set_aspect('equal')
    ax_network.set_title('Boltzmann Machine - 3 Neurons', fontsize=14, fontweight='bold')
    ax_network.axis('off')

    # Add legend
    ax_network.plot([], [], 'o', color=active_color, markersize=10, label='Active (+1)')
    ax_network.plot([], [], 'o', color=inactive_color, markersize=10, label='Inactive (-1)')
    ax_network.legend(loc='upper left', bbox_to_anchor=(0, 1))

    # Energy plot setup
    energy_line, = ax_energy.plot([], [], 'b-', linewidth=2, label='Energy')
    ax_energy.set_xlim(0, len(bm.energy_history))
    ax_energy.set_ylim(min(bm.energy_history) - 0.5, max(bm.energy_history) + 0.5)
    ax_energy.set_xlabel('Iteration')
    ax_energy.set_ylabel('Energy')
    ax_energy.set_title('Energy Evolution')
    ax_energy.legend()
    ax_energy.grid(True, alpha=0.3)

    # Temperature plot setup
    temp_line, = ax_temp.plot([], [], 'r-', linewidth=2, label='Temperature')
    ax_temp.set_xlim(0, len(bm.temperature_history))
    ax_temp.set_ylim(0, bm.initial_temperature + 1)
    ax_temp.set_xlabel('Iteration')
    ax_temp.set_ylabel('Temperature')
    ax_temp.set_title('Temperature Cooling')
    ax_temp.legend()
    ax_temp.grid(True, alpha=0.3)

    # Probability plot setup
    prob_line, = ax_prob.plot([], [], 'g-', linewidth=2, label='Flip Probability')
    ax_prob.set_xlim(0, len(bm.probability_history))
    ax_prob.set_ylim(0, 1)
    ax_prob.set_xlabel('Iteration')
    ax_prob.set_ylabel('Probability')
    ax_prob.set_title('Neuron Flip Probability')
    ax_prob.legend()
    ax_prob.grid(True, alpha=0.3)

    # State history plot setup
    state_lines = []
    colors = ['red', 'blue', 'green']
    labels = ['Neuron 0', 'Neuron 1', 'Neuron 2']
    for i in range(3):
        line, = ax_state.plot([], [], color=colors[i], linewidth=2, label=labels[i])
        state_lines.append(line)

    ax_state.set_xlim(0, len(bm.states_history))
    ax_state.set_ylim(-1.5, 1.5)
    ax_state.set_xlabel('Iteration')
    ax_state.set_ylabel('State')
    ax_state.set_title('Neuron States Over Time')
    ax_state.legend()
    ax_state.grid(True, alpha=0.3)
    ax_state.set_yticks([-1, 1])
    ax_state.set_yticklabels(['-1 (Inactive)', '+1 (Active)'])

    # Information text
    info_text = fig.text(0.5, 0.01, '', ha='center', fontsize=11,
                         bbox=dict(boxstyle="round,pad=0.5", facecolor="lightblue"))

    # Equilibrium detection
    equilibrium_text = fig.text(0.85, 0.95, '', ha='center', fontsize=12,
                                bbox=dict(boxstyle="round,pad=0.5", facecolor="yellow"),
                                fontweight='bold')

    def animate(frame):
        if frame >= len(bm.states_history):
            frame = len(bm.states_history) - 1

        current_state = bm.states_history[frame]
        current_energy = bm.energy_history[frame]
        current_temp = bm.temperature_history[frame]
        current_prob = bm.probability_history[frame]

        # Update neurons
        for i in range(3):
            color = active_color if current_state[i] == 1 else inactive_color
            neurons[i].set_facecolor(color)
            state_texts[i].set_text(f'State: {current_state[i]}')

        # Update energy plot
        x_data = list(range(frame + 1))
        energy_line.set_data(x_data, bm.energy_history[:frame + 1])

        # Update temperature plot
        temp_line.set_data(x_data, bm.temperature_history[:frame + 1])

        # Update probability plot
        prob_line.set_data(x_data, bm.probability_history[:frame + 1])

        # Update state history
        for i in range(3):
            state_data = [bm.states_history[j][i] for j in range(frame + 1)]
            state_lines[i].set_data(x_data, state_data)

        # Update information text
        info_text.set_text(f'Iteration: {frame}/{len(bm.states_history) - 1} | '
                           f'Energy: {current_energy:.3f} | '
                           f'Temperature: {current_temp:.3f} | '
                           f'Flip Probability: {current_prob:.3f}')

        # Check for thermal equilibrium (last 10 iterations have small changes)
        if frame >= 10:
            recent_energy_changes = np.abs(np.diff(bm.energy_history[max(0, frame - 9):frame + 1]))
            energy_stable = np.mean(recent_energy_changes) < 0.1

            recent_state_changes = 0
            for i in range(max(1, frame - 9), frame + 1):
                if not np.array_equal(bm.states_history[i], bm.states_history[i - 1]):
                    recent_state_changes += 1

            state_stable = recent_state_changes <= 2  # At most 2 changes in last 10 iterations

            if energy_stable and state_stable and current_temp < 0.5:
                equilibrium_text.set_text('THERMAL EQUILIBRIUM\nREACHED!')
                equilibrium_text.set_bbox(dict(boxstyle="round,pad=0.5", facecolor="lightgreen"))
            else:
                equilibrium_text.set_text('Searching for\nEquilibrium...')
                equilibrium_text.set_bbox(dict(boxstyle="round,pad=0.5", facecolor="yellow"))

        return (neurons + [energy_line, temp_line, prob_line] +
                state_lines + state_texts + [info_text, equilibrium_text])

    # Create animation
    anim = animation.FuncAnimation(
        fig, animate, frames=len(bm.states_history),
        interval=400, blit=False, repeat=True
    )

    plt.tight_layout()
    plt.subplots_adjust(bottom=0.1)
    plt.show()

    # Print final results
    print("=" * 60)
    print("BOLTZMANN MACHINE SIMULATION RESULTS")
    print("=" * 60)
    print(f"Final State: {final_state}")
    print(f"Final Energy: {bm.energy_history[-1]:.4f}")
    print(f"Final Temperature: {bm.temperature_history[-1]:.4f}")
    print(f"Total Iterations: {len(bm.states_history)}")
    print("\nNetwork Parameters:")
    print(f"Weights:\n{weights}")
    print(f"Biases: {biases}")

    # Check if thermal equilibrium was reached
    if len(bm.states_history) >= 10:
        last_10_energies = bm.energy_history[-10:]
        energy_variance = np.var(last_10_energies)
        if energy_variance < 0.1:
            print("\n✓ THERMAL EQUILIBRIUM ACHIEVED!")
            print(f"  Energy variance in last 10 iterations: {energy_variance:.6f}")
        else:
            print("\n⚠ Still searching for equilibrium...")
            print(f"  Energy variance in last 10 iterations: {energy_variance:.6f}")

    return anim, bm, final_state


# Run the animation
print("Creating 3-Neuron Boltzmann Machine Animation...")
anim, bm, final_state = create_boltzmann_animation()

# Optional: Save animation
# anim.save('boltzmann_machine_animation.gif', writer='pillow', fps=3, dpi=100)

print("\nAnimation completed!")