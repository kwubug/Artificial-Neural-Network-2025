import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
                             QWidget, QPushButton, QLabel, QDoubleSpinBox, QSpinBox,
                             QComboBox, QGroupBox, QGridLayout, QSlider, QCheckBox,
                             QTextEdit, QSplitter, QFrame)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont
import time

# 设置matplotlib中文字体
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
matplotlib.rcParams['font.size'] = 10

# 尝试设置中文字体
try:
    import matplotlib.font_manager as fm
    # 获取系统中可用的中文字体
    chinese_fonts = []
    for font in fm.fontManager.ttflist:
        if 'SimHei' in font.name or 'Microsoft YaHei' in font.name or 'SimSun' in font.name:
            chinese_fonts.append(font.name)
    
    if chinese_fonts:
        matplotlib.rcParams['font.sans-serif'] = chinese_fonts + ['DejaVu Sans']
except:
    pass

class OptimizationAlgorithm:
    """优化算法基类"""
    
    def __init__(self, objective_func, gradient_func, hessian_func=None):
        self.objective_func = objective_func
        self.gradient_func = gradient_func
        self.hessian_func = hessian_func
        self.path = []
        self.function_values = []
    
    def optimize(self, x0, max_iter=100, tolerance=1e-6, **kwargs):
        """执行优化算法"""
        raise NotImplementedError("子类必须实现optimize方法")

class GradientDescent(OptimizationAlgorithm):
    """标准梯度下降法"""
    
    def optimize(self, x0, max_iter=100, tolerance=1e-6, learning_rate=0.01):
        self.path = [x0.copy()]
        self.function_values = [self.objective_func(x0)]
        
        x = x0.copy()
        # 设置边界约束
        x_bounds = [-3.0, 4.0]
        y_bounds = [-2.0, 5.0]
        
        for i in range(max_iter):
            grad = self.gradient_func(x)
            x_new = x - learning_rate * grad
            
            # 应用边界约束
            x_new[0] = np.clip(x_new[0], x_bounds[0], x_bounds[1])
            x_new[1] = np.clip(x_new[1], y_bounds[0], y_bounds[1])
            
            self.path.append(x_new.copy())
            self.function_values.append(self.objective_func(x_new))
            
            # 只在步长较大时添加中间点，减少路径长度
            step_size = np.linalg.norm(x_new - x)
            if step_size > 0.1 and i < max_iter - 1 and len(self.path) < 50:  # 限制路径长度
                mid_point = (x + x_new) / 2
                mid_point[0] = np.clip(mid_point[0], x_bounds[0], x_bounds[1])
                mid_point[1] = np.clip(mid_point[1], y_bounds[0], y_bounds[1])
                self.path.append(mid_point.copy())
                self.function_values.append(self.objective_func(mid_point))
            
            if np.linalg.norm(x_new - x) < tolerance:
                break
            x = x_new
        
        return x, len(self.path)

class NewtonMethod(OptimizationAlgorithm):
    """牛顿法"""
    
    def optimize(self, x0, max_iter=100, tolerance=1e-6, damping=1e-6):
        self.path = [x0.copy()]
        self.function_values = [self.objective_func(x0)]
        
        x = x0.copy()
        # 设置边界约束
        x_bounds = [-3.0, 4.0]
        y_bounds = [-2.0, 5.0]
        
        for i in range(max_iter):
            grad = self.gradient_func(x)
            hess = self.hessian_func(x)
            
            # 添加阻尼项避免奇异矩阵
            hess_reg = hess + damping * np.eye(len(x))
            
            try:
                # 求解牛顿方程: H * p = -g
                p = np.linalg.solve(hess_reg, -grad)
                x_new = x + p
            except np.linalg.LinAlgError:
                # 如果矩阵奇异，使用梯度下降
                x_new = x - 0.01 * grad
            
            # 应用边界约束
            x_new[0] = np.clip(x_new[0], x_bounds[0], x_bounds[1])
            x_new[1] = np.clip(x_new[1], y_bounds[0], y_bounds[1])
            
            self.path.append(x_new.copy())
            self.function_values.append(self.objective_func(x_new))
            
            # 只在步长较大时添加中间点，减少路径长度
            step_size = np.linalg.norm(x_new - x)
            if step_size > 0.1 and i < max_iter - 1 and len(self.path) < 50:  # 限制路径长度
                mid_point = (x + x_new) / 2
                mid_point[0] = np.clip(mid_point[0], x_bounds[0], x_bounds[1])
                mid_point[1] = np.clip(mid_point[1], y_bounds[0], y_bounds[1])
                self.path.append(mid_point.copy())
                self.function_values.append(self.objective_func(mid_point))
            
            if np.linalg.norm(x_new - x) < tolerance:
                break
            x = x_new
        
        return x, len(self.path)

class ConjugateGradient(OptimizationAlgorithm):
    """共轭梯度法"""
    
    def optimize(self, x0, max_iter=100, tolerance=1e-6):
        self.path = [x0.copy()]
        self.function_values = [self.objective_func(x0)]
        
        x = x0.copy()
        grad = self.gradient_func(x)
        d = -grad  # 初始搜索方向
        
        # 设置边界约束
        x_bounds = [-3.0, 4.0]
        y_bounds = [-2.0, 5.0]
        
        for i in range(max_iter):
            # 自适应线搜索
            alpha = 0.01
            x_new = x + alpha * d
            
            # 应用边界约束
            x_new[0] = np.clip(x_new[0], x_bounds[0], x_bounds[1])
            x_new[1] = np.clip(x_new[1], y_bounds[0], y_bounds[1])
            
            # 检查数值稳定性
            if np.any(np.isnan(x_new)) or np.any(np.isinf(x_new)):
                break
                
            grad_new = self.gradient_func(x_new)
            
            # 检查梯度数值稳定性
            if np.any(np.isnan(grad_new)) or np.any(np.isinf(grad_new)):
                break
            
            # 计算共轭梯度参数（Polak-Ribiere公式）
            grad_dot = np.dot(grad, grad)
            if grad_dot < 1e-12:  # 避免除零
                beta = 0
            else:
                beta = max(0, np.dot(grad_new, grad_new - grad) / grad_dot)
            
            # 更新搜索方向
            d = -grad_new + beta * d
            
            # 检查搜索方向
            if np.any(np.isnan(d)) or np.any(np.isinf(d)):
                d = -grad_new  # 重置为负梯度方向
            
            self.path.append(x_new.copy())
            self.function_values.append(self.objective_func(x_new))
            
            # 只在步长较大时添加中间点，减少路径长度
            step_size = np.linalg.norm(x_new - x)
            if step_size > 0.1 and i < max_iter - 1 and len(self.path) < 50:  # 限制路径长度
                mid_point = (x + x_new) / 2
                mid_point[0] = np.clip(mid_point[0], x_bounds[0], x_bounds[1])
                mid_point[1] = np.clip(mid_point[1], y_bounds[0], y_bounds[1])
                self.path.append(mid_point.copy())
                self.function_values.append(self.objective_func(mid_point))
            
            if np.linalg.norm(x_new - x) < tolerance:
                break
            
            x = x_new
            grad = grad_new
        
        return x, len(self.path)

class OptimizationThread(QThread):
    """优化算法执行线程"""
    progress = pyqtSignal(int, int)  # 当前迭代, 总迭代
    finished = pyqtSignal(object, object)  # 算法对象, 结果
    
    def __init__(self, algorithm, x0, **kwargs):
        super().__init__()
        self.algorithm = algorithm
        self.x0 = x0
        self.kwargs = kwargs
    
    def run(self):
        try:
            result, iterations = self.algorithm.optimize(self.x0, **self.kwargs)
            self.finished.emit(self.algorithm, (result, iterations))
        except Exception as e:
            print(f"优化过程出错: {e}")
            self.finished.emit(self.algorithm, None)

class PlotCanvas(FigureCanvas):
    """3D绘图画布"""
    
    def __init__(self, parent=None, width=8, height=6, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super().__init__(self.fig)
        self.setParent(parent)
        
        # 设置字体
        self.fig.patch.set_facecolor('white')
        
        self.ax = self.fig.add_subplot(111, projection='3d')
        self.setup_plot()
    
    def setup_plot(self):
        """设置绘图参数"""
        # 设置坐标轴标签
        self.ax.set_xlabel('X', fontsize=12)
        self.ax.set_ylabel('Y', fontsize=12)
        self.ax.set_zlabel('Z', fontsize=12)
        self.ax.set_title('梯度下降算法可视化', fontsize=14, pad=20)
        
        # 设置背景色
        self.ax.xaxis.pane.fill = False
        self.ax.yaxis.pane.fill = False
        self.ax.zaxis.pane.fill = False
        
        # 设置网格
        self.ax.grid(True, alpha=0.3)
    
    def plot_function_surface(self, x_range, y_range, objective_func):
        """绘制目标函数表面"""
        # 增加网格密度以获得更平滑的表面
        X = np.linspace(x_range[0], x_range[1], 80)
        Y = np.linspace(y_range[0], y_range[1], 80)
        X, Y = np.meshgrid(X, Y)
        Z = np.zeros_like(X)
        
        # 计算函数值并限制范围
        max_z = 1000  # 限制最大显示值
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                try:
                    z_val = objective_func(np.array([X[i, j], Y[i, j]]))
                    Z[i, j] = min(z_val, max_z)  # 截断过大的值
                except:
                    Z[i, j] = max_z
        
        # 绘制表面 - 使用更平滑的设置
        surf = self.ax.plot_surface(X, Y, Z, alpha=0.7, cmap='viridis', 
                                   vmin=0, vmax=max_z, linewidth=0, 
                                   antialiased=True, shade=True)
        
        # 绘制等高线 - 减少线条数量
        self.ax.contour(X, Y, Z, levels=15, alpha=0.4, colors='black', linewidths=0.3)
        
        # 设置坐标轴范围
        self.ax.set_xlim(x_range)
        self.ax.set_ylim(y_range)
        self.ax.set_zlim(0, max_z)
    
    def plot_optimization_path(self, algorithm, color='red', label=''):
        """绘制优化路径"""
        if not algorithm.path:
            return
        
        # 过滤路径点，只保留在显示范围内的点
        x_range = [-2.0, 3.0]
        y_range = [-1.0, 4.0]
        max_z = 1000
        
        filtered_path = []
        filtered_z_path = []
        
        for i, point in enumerate(algorithm.path):
            x, y = point[0], point[1]
            
            # 检查是否在显示范围内
            if x_range[0] <= x <= x_range[1] and y_range[0] <= y <= y_range[1]:
                try:
                    z_val = algorithm.objective_func(point)
                    z_val = min(z_val, max_z)
                    filtered_path.append(point)
                    filtered_z_path.append(z_val)
                    
                    # 调试输出前几个点的坐标
                    if i < 3:
                        print(f"路径点 {i}: ({x:.3f}, {y:.3f}) -> Z = {z_val:.3f}")
                except Exception as e:
                    print(f"计算路径点 {i} 时出错: {e}")
            else:
                print(f"路径点 {i} 超出显示范围: ({x:.3f}, {y:.3f})")
        
        if not filtered_path:
            print("警告：所有路径点都超出显示范围")
            return
        
        # 转换为numpy数组
        path_array = np.array(filtered_path)
        x_path = path_array[:, 0]
        y_path = path_array[:, 1]
        z_path = np.array(filtered_z_path)
        
        # 绘制平滑的路径曲线
        if len(x_path) > 1:
            print(f"路径点数量: {len(x_path)}")
            
            # 如果路径点太多，进行采样
            if len(x_path) > 30:
                # 均匀采样，保留关键点
                indices = np.linspace(0, len(x_path)-1, 30, dtype=int)
                x_path = x_path[indices]
                y_path = y_path[indices]
                z_path = z_path[indices]
                print(f"采样后路径点数量: {len(x_path)}")
            
            # 使用样条插值创建平滑曲线
            try:
                from scipy.interpolate import CubicSpline
                
                # 创建参数化曲线
                t = np.linspace(0, 1, len(x_path))
                
                # 使用三次样条插值
                cs_x = CubicSpline(t, x_path)
                cs_y = CubicSpline(t, y_path)
                cs_z = CubicSpline(t, z_path)
                
                # 生成更密集的点用于平滑曲线
                t_smooth = np.linspace(0, 1, max(30, len(x_path) * 5))
                x_smooth = cs_x(t_smooth)
                y_smooth = cs_y(t_smooth)
                z_smooth = cs_z(t_smooth)
                
                print(f"平滑后点数: {len(x_smooth)}")
                
            except ImportError:
                # 如果没有scipy，使用numpy插值
                t = np.linspace(0, 1, len(x_path))
                t_smooth = np.linspace(0, 1, max(30, len(x_path) * 3))
                x_smooth = np.interp(t_smooth, t, x_path)
                y_smooth = np.interp(t_smooth, t, y_path)
                z_smooth = np.interp(t_smooth, t, z_path)
                
                print(f"使用numpy插值，平滑后点数: {len(x_smooth)}")
            
            # 绘制平滑曲线
            self.ax.plot(x_smooth, y_smooth, z_smooth, color=color, linewidth=3, 
                        linestyle='-', alpha=0.9, label=label)
        
        # 绘制路径点（使用更小的点）
        self.ax.scatter(x_path, y_path, z_path, color=color, s=20, alpha=0.8)
        
        # 标记起点和终点
        if len(filtered_path) > 0:
            self.ax.scatter(x_path[0], y_path[0], z_path[0], 
                           color='green', s=80, marker='o', label='起点', alpha=0.9)
            self.ax.scatter(x_path[-1], y_path[-1], z_path[-1], 
                           color='yellow', s=80, marker='*', label='终点', alpha=0.9)
    
    def clear_plot(self):
        """清除绘图"""
        self.ax.clear()
        self.setup_plot()

class GradientDescentVisualizer(QMainWindow):
    """主窗口类"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("梯度下降算法可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 目标函数
        self.objective_func = self.rosenbrock_function
        self.gradient_func = self.rosenbrock_gradient
        self.hessian_func = self.rosenbrock_hessian
        
        # 算法对象
        self.algorithms = {}
        self.current_algorithm = None
        
        # 初始化UI
        self.init_ui()
        
        # 绘制初始函数表面
        self.plot_initial_surface()
    
    def rosenbrock_function(self, x):
        """Rosenbrock函数"""
        try:
            result = 100 * (x[1] - x[0]**2)**2 + (1 - x[0])**2
            # 限制函数值范围，避免数值溢出
            return min(result, 10000)
        except:
            return 10000
    
    def rosenbrock_gradient(self, x):
        """Rosenbrock函数梯度"""
        try:
            grad = np.zeros(2)
            grad[0] = -400 * x[0] * (x[1] - x[0]**2) - 2 * (1 - x[0])
            grad[1] = 200 * (x[1] - x[0]**2)
            # 限制梯度范围
            grad = np.clip(grad, -1000, 1000)
            return grad
        except:
            return np.array([0.0, 0.0])
    
    def rosenbrock_hessian(self, x):
        """Rosenbrock函数Hessian矩阵"""
        try:
            hess = np.zeros((2, 2))
            hess[0, 0] = -400 * (x[1] - x[0]**2) + 800 * x[0]**2 + 2
            hess[0, 1] = -400 * x[0]
            hess[1, 0] = -400 * x[0]
            hess[1, 1] = 200
            # 限制Hessian矩阵元素范围
            hess = np.clip(hess, -1000, 1000)
            return hess
        except:
            return np.eye(2)
    
    def init_ui(self):
        """初始化用户界面"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建分割器
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        splitter.addWidget(control_panel)
        
        # 右侧绘图区域
        self.plot_canvas = PlotCanvas(self, width=10, height=8)
        splitter.addWidget(self.plot_canvas)
        
        # 设置分割器比例
        splitter.setSizes([400, 1000])
        
        layout = QHBoxLayout()
        layout.addWidget(splitter)
        central_widget.setLayout(layout)
    
    def create_control_panel(self):
        """创建控制面板"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.StyledPanel)
        layout = QVBoxLayout()
        
        # 算法选择
        algorithm_group = QGroupBox("算法选择")
        algorithm_layout = QVBoxLayout()
        
        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["梯度下降法", "牛顿法", "共轭梯度法"])
        algorithm_layout.addWidget(QLabel("选择算法:"))
        algorithm_layout.addWidget(self.algorithm_combo)
        
        algorithm_group.setLayout(algorithm_layout)
        layout.addWidget(algorithm_group)
        
        # 参数设置
        params_group = QGroupBox("参数设置")
        params_layout = QGridLayout()
        
        # 初始点设置
        params_layout.addWidget(QLabel("初始点 X:"), 0, 0)
        self.x0_spin = QDoubleSpinBox()
        self.x0_spin.setRange(-5, 5)
        self.x0_spin.setValue(-1.5)
        self.x0_spin.setSingleStep(0.1)
        params_layout.addWidget(self.x0_spin, 0, 1)
        
        params_layout.addWidget(QLabel("初始点 Y:"), 1, 0)
        self.y0_spin = QDoubleSpinBox()
        self.y0_spin.setRange(-5, 5)
        self.y0_spin.setValue(2.0)
        self.y0_spin.setSingleStep(0.1)
        params_layout.addWidget(self.y0_spin, 1, 1)
        
        # 最大迭代次数
        params_layout.addWidget(QLabel("最大迭代次数:"), 2, 0)
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(5, 50)
        self.max_iter_spin.setValue(20)
        params_layout.addWidget(self.max_iter_spin, 2, 1)
        
        # 学习率（梯度下降法）
        params_layout.addWidget(QLabel("学习率:"), 3, 0)
        self.learning_rate_spin = QDoubleSpinBox()
        self.learning_rate_spin.setRange(0.001, 1.0)
        self.learning_rate_spin.setValue(0.01)
        self.learning_rate_spin.setSingleStep(0.001)
        self.learning_rate_spin.setDecimals(3)
        params_layout.addWidget(self.learning_rate_spin, 3, 1)
        
        # 容差
        params_layout.addWidget(QLabel("容差:"), 4, 0)
        self.tolerance_spin = QDoubleSpinBox()
        self.tolerance_spin.setRange(1e-8, 1e-2)
        self.tolerance_spin.setValue(1e-6)
        self.tolerance_spin.setSingleStep(1e-6)
        self.tolerance_spin.setDecimals(8)
        params_layout.addWidget(self.tolerance_spin, 4, 1)
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # 控制按钮
        button_layout = QVBoxLayout()
        
        self.run_button = QPushButton("运行优化")
        self.run_button.clicked.connect(self.run_optimization)
        button_layout.addWidget(self.run_button)
        
        self.clear_button = QPushButton("清除路径")
        self.clear_button.clicked.connect(self.clear_paths)
        button_layout.addWidget(self.clear_button)
        
        self.reset_button = QPushButton("重置视图")
        self.reset_button.clicked.connect(self.reset_view)
        button_layout.addWidget(self.reset_button)
        
        layout.addLayout(button_layout)
        
        # 结果显示
        results_group = QGroupBox("优化结果")
        results_layout = QVBoxLayout()
        
        self.results_text = QTextEdit()
        self.results_text.setMaximumHeight(150)
        self.results_text.setReadOnly(True)
        results_layout.addWidget(self.results_text)
        
        results_group.setLayout(results_layout)
        layout.addWidget(results_group)
        
        # 添加弹性空间
        layout.addStretch()
        
        panel.setLayout(layout)
        return panel
    
    def plot_initial_surface(self):
        """绘制初始函数表面"""
        x_range = [-2.0, 3.0]
        y_range = [-1.0, 4.0]
        self.plot_canvas.plot_function_surface(x_range, y_range, self.objective_func)
        self.plot_canvas.draw()
    
    def run_optimization(self):
        """运行优化算法"""
        # 获取参数
        x0 = np.array([self.x0_spin.value(), self.y0_spin.value()])
        max_iter = self.max_iter_spin.value()
        tolerance = self.tolerance_spin.value()
        learning_rate = self.learning_rate_spin.value()
        
        # 选择算法
        algorithm_name = self.algorithm_combo.currentText()
        
        if algorithm_name == "梯度下降法":
            algorithm = GradientDescent(self.objective_func, self.gradient_func)
            kwargs = {'learning_rate': learning_rate}
        elif algorithm_name == "牛顿法":
            algorithm = NewtonMethod(self.objective_func, self.gradient_func, self.hessian_func)
            kwargs = {}
        elif algorithm_name == "共轭梯度法":
            algorithm = ConjugateGradient(self.objective_func, self.gradient_func)
            kwargs = {}
        
        # 设置算法颜色
        colors = {"梯度下降法": "red", "牛顿法": "blue", "共轭梯度法": "green"}
        color = colors[algorithm_name]
        
        # 运行优化
        self.run_button.setEnabled(False)
        self.run_button.setText("运行中...")
        
        try:
            result, iterations = algorithm.optimize(x0, max_iter=max_iter, 
                                                 tolerance=tolerance, **kwargs)
            
            # 绘制路径
            self.plot_canvas.plot_optimization_path(algorithm, color=color, label=algorithm_name)
            self.plot_canvas.draw()
            
            # 显示结果
            self.display_results(algorithm_name, result, iterations, algorithm.function_values[-1])
            
        except Exception as e:
            self.results_text.append(f"优化过程出错: {str(e)}")
        finally:
            self.run_button.setEnabled(True)
            self.run_button.setText("运行优化")
    
    def display_results(self, algorithm_name, result, iterations, final_value):
        """显示优化结果"""
        result_text = f"\n{algorithm_name} 结果:\n"
        result_text += f"最优解: ({result[0]:.6f}, {result[1]:.6f})\n"
        result_text += f"函数值: {final_value:.6f}\n"
        result_text += f"迭代次数: {iterations}\n"
        result_text += "-" * 30
        
        self.results_text.append(result_text)
    
    def clear_paths(self):
        """清除所有路径"""
        self.plot_canvas.clear_plot()
        self.plot_initial_surface()
        self.results_text.clear()
    
    def reset_view(self):
        """重置视图"""
        self.clear_paths()
        self.x0_spin.setValue(-1.5)
        self.y0_spin.setValue(2.0)

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    window = GradientDescentVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
