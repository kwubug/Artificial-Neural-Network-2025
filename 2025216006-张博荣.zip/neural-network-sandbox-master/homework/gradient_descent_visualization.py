import numpy as np
import matplotlib.pyplot as plt

def func(x):
    return x[0]**2 + 25 * x[1]** 2

def grad(x):
    return np.array([2 * x[0], 50 * x[1]])

def hessian(x):
    return np.array([[2, 0], [0, 50]])
def steepest_descent(x0, max_iter=50, tol=1e-6):
    x = x0.copy()
    path = [x]  
    A = hessian(x) 
    for _ in range(max_iter):
        g = grad(x)
        if np.linalg.norm(g) < tol:
            break
        p = -g 
        numerator = g @ p
        denominator = p @ A @ p
        alpha = -numerator / denominator
        x = x + alpha * p 
        path.append(x)
    return np.array(path)
def newton_method(x0, max_iter=20, tol=1e-6):
    x = x0.copy()
    path = [x]
    for _ in range(max_iter):
        g = grad(x)
        if np.linalg.norm(g) < tol:
            break
        A = hessian(x)
        A_inv = np.linalg.inv(A)  
        x = x - A_inv @ g  
        path.append(x)
    return np.array(path)
def conjugate_gradient(x0, max_iter=20, tol=1e-6):
    x = x0.copy()
    path = [x]
    g = grad(x)
    p = -g  
    A = hessian(x) 
    for _ in range(max_iter):
        if np.linalg.norm(g) < tol:
            break
        numerator = g @ p
        denominator = p @ A @ p
        alpha = -numerator / denominator
        x = x + alpha * p
        path.append(x)
        g_new = grad(x)
        beta = (g_new @ g_new) / (g @ g)
        p = -g_new + beta * p
        g = g_new.copy()
    return np.array(path)
x1 = np.linspace(-1, 1, 100)
x2 = np.linspace(-1, 1, 100)
X1, X2 = np.meshgrid(x1, x2)
Z = func([X1, X2])

x0 = np.array([0.5, 0.5])

sd_path = steepest_descent(x0)
newton_path = newton_method(x0)
cg_path = conjugate_gradient(x0)

plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.contour(X1, X2, Z, levels=20, cmap='viridis') 
plt.plot(sd_path[:, 0], sd_path[:, 1], 'o-', color='blue', label='Steepest Descent')
plt.scatter(x0[0], x0[1], color='red', marker='*', s=100, label='Initial Point')
plt.title('Steepest Descent Method')
plt.xlabel('$x_1$')
plt.ylabel('$x_2$')
plt.legend()

plt.subplot(1, 3, 2)
plt.contour(X1, X2, Z, levels=20, cmap='viridis')
plt.plot(newton_path[:, 0], newton_path[:, 1], 'o-', color='green', label='Newton\'s Method')
plt.scatter(x0[0], x0[1], color='red', marker='*', s=100)
plt.title('Newton\'s Method')
plt.xlabel('$x_1$')
plt.legend()

plt.subplot(1, 3, 3)
plt.contour(X1, X2, Z, levels=20, cmap='viridis')
plt.plot(cg_path[:, 0], cg_path[:, 1], 'o-', color='orange', label='Conjugate Gradient')
plt.scatter(x0[0], x0[1], color='red', marker='*', s=100)
plt.title('Conjugate Gradient Method')
plt.xlabel('$x_1$')
plt.legend()

plt.tight_layout()
plt.savefig('gradient_descent_comparison.png', dpi=300) 
plt.show()