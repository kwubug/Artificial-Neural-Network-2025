import numpy as np
import matplotlib.pyplot as plt
import math, random
import matplotlib

# 中文字体支持
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# ------------------------------
# 1. 随机生成城市坐标
# ------------------------------
num_cities = 20
cities = np.random.rand(num_cities, 2) * 100  # 坐标范围 0-100


# ------------------------------
# 2. 距离函数 & 路径长度
# ------------------------------

def distance(a, b):
    return np.linalg.norm(a - b)


def path_length(path):
    return sum(distance(cities[path[i]], cities[path[(i + 1) % num_cities]]) for i in range(num_cities))


# ------------------------------
# 3. 模拟退火算法
# ------------------------------

def simulated_annealing(T_start=1000, T_end=1e-3, alpha=0.995):
    path = np.arange(num_cities)
    np.random.shuffle(path)
    best_path = path.copy()
    best_len = path_length(path)

    T = T_start
    history = [best_len]

    while T > T_end:
        i, j = np.random.randint(0, num_cities, 2)
        new_path = path.copy()
        new_path[i], new_path[j] = new_path[j], new_path[i]

        old_len = path_length(path)
        new_len = path_length(new_path)

        if new_len < old_len or random.random() < math.exp(-(new_len - old_len) / T):
            path = new_path
            if new_len < best_len:
                best_path, best_len = new_path.copy(), new_len

        T *= alpha
        history.append(best_len)

    return best_path, best_len, history


# ------------------------------
# 4. 运行模拟退火 & 可视化
# ------------------------------

best_path, best_len, history = simulated_annealing()

print(f"最优路径长度: {best_len:.2f}")

plt.figure(figsize=(8, 4))
plt.subplot(1, 2, 1)
for i in range(num_cities):
    a, b = cities[best_path[i]], cities[best_path[(i + 1) % num_cities]]
    plt.plot([a[0], b[0]], [a[1], b[1]], 'b-')
plt.scatter(cities[:, 0], cities[:, 1], c='r')
plt.title("最优旅行路线")

plt.subplot(1, 2, 2)
plt.plot(history)
plt.title("路径长度收敛过程")
plt.xlabel("迭代步数")
plt.ylabel("路径长度")

plt.tight_layout()
plt.show()
