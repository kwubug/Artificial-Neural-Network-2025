import numpy as np
import matplotlib
# —— 关键：启用交互后端；若 Tk 不可用，回退到 Qt5Agg 或默认
try:
    matplotlib.use('TkAgg')
except Exception:
    try:
        matplotlib.use('Qt5Agg')
    except Exception:
        pass

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

# ============ 1) 生成数据 ============
np.random.seed(0)
N = 50
x = np.linspace(0, 10, N)
true_w, true_b = 2.5, 1.5
y = true_w * x + true_b + np.random.randn(N) * 2.0

X = x.reshape(-1, 1)
X_b = np.c_[np.ones((N, 1)), X]

# ============ 2) 闭式解 ============
theta_star = np.linalg.inv(X_b.T @ X_b) @ (X_b.T @ y)
b_star, w_star = theta_star[0], theta_star[1]

# ============ 3) 构建损失曲面 ============
def mse(b, w):
    y_pred = w * x + b
    return np.mean((y_pred - y) ** 2)

w_min, w_max = w_star - 3.0, w_star + 3.0
b_min, b_max = b_star - 6.0, b_star + 6.0
W = np.linspace(w_min, w_max, 120)
B = np.linspace(b_min, b_max, 120)
WW, BB = np.meshgrid(W, B)
ZZ = 0.5 * ((WW * x.mean() + BB - y.mean())**2 * 0)  # 先占位

# 更稳妥：矢量化计算曲面
def grid_mse(WW, BB):
    # 对每个网格点计算 MSE
    # shape: WW,BB [H,W]
    H, K = WW.shape
    Z = np.empty_like(WW, dtype=float)
    for i in range(H):
        wrow = WW[i]
        brow = BB[i]
        # y_pred: [W, N]
        YP = wrow[:, None] * x[None, :] + brow[:, None]
        Z[i] = ((YP - y[None, :])**2).mean(axis=1)
    return Z

ZZ = grid_mse(WW, BB)

# ============ 4) 梯度下降轨迹 ============
def grad(b, w):
    y_pred = w * x + b
    err = (y_pred - y)
    db = 2.0 * np.mean(err)
    dw = 2.0 * np.mean(err * x)
    return db, dw

w, b = w_star + 2.5, b_star - 4.0   # 初始点
alpha = 0.01
epochs = 60

history = [(b, w, mse(b, w))]
for t in range(epochs - 1):
    db, dw = grad(b, w)
    a = alpha * (0.98 ** t)   # 轻微衰减
    b -= a * db
    w -= a * dw
    history.append((b, w, mse(b, w)))

B_hist = np.array([h[0] for h in history])
W_hist = np.array([h[1] for h in history])
Z_hist = np.array([h[2] for h in history])

# ============ 5) 画布 ============
fig = plt.figure(figsize=(14, 5))

# 左：数据 + 直线
ax1 = fig.add_subplot(1, 2, 1)
ax1.scatter(x, y, s=40, label="Data")
line2d, = ax1.plot(x, W_hist[0] * x + B_hist[0], 'r-', lw=2, label="OLS Fit", zorder=3)
ax1.set_xlabel("x"); ax1.set_ylabel("y")
ax1.legend()
ax1.set_title("OLS Learning (line updates)")

# 让 y 轴范围固定（避免抖动）
y_pred_all = W_hist[:, None] * x[None, :] + B_hist[:, None]
ax1.set_xlim(x.min() - 0.5, x.max() + 0.5)
ax1.set_ylim(min(y.min(), y_pred_all.min()) - 1.0,
             max(y.max(), y_pred_all.max()) + 1.0)

# 右：3D 曲面 + 轨迹
ax2 = fig.add_subplot(1, 2, 2, projection='3d')
surf = ax2.plot_surface(WW, BB, ZZ, alpha=0.55, rstride=2, cstride=2, linewidth=0, antialiased=True)
ax2.contour(WW, BB, ZZ, 25, offset=ZZ.min(), zdir='z', alpha=0.6)
ax2.scatter([w_star], [b_star], [mse(b_star, w_star)], marker='*', s=150, depthshade=False, label='Optimum')
path3d, = ax2.plot(W_hist[:1], B_hist[:1], Z_hist[:1], lw=2, color='k', label="Descent Path")
point3d = ax2.scatter([W_hist[0]], [B_hist[0]], [Z_hist[0]], s=40, depthshade=False, color='k')
ax2.set_xlabel("w"); ax2.set_ylabel("b"); ax2.set_zlabel("MSE")
ax2.set_title("Loss Surface and Descent Path")
ax2.legend(loc='upper right')

# ============ 6) 动画 ============
def update(frame):
    w, b = W_hist[frame], B_hist[frame]
    line2d.set_ydata(w * x + b)
    ax1.set_title(f"OLS Learning (iteration {frame+1}/{epochs}) | w={w:.3f}, b={b:.3f}")
    path3d.set_data(W_hist[:frame+1], B_hist[:frame+1])
    path3d.set_3d_properties(Z_hist[:frame+1])
    global point3d
    point3d.remove()
    point3d = ax2.scatter([W_hist[frame]], [B_hist[frame]], [Z_hist[frame]],
                          s=40, depthshade=False, color='k')
    return line2d, path3d, point3d

# —— 含3D子图请用 blit=False；interval 越小越快
ani = FuncAnimation(fig, update, frames=len(history), interval=60, blit=False)

plt.tight_layout()
plt.show()

# 可选：若你的 IDE 仍不弹窗，可保存成 gif/mp4 查看：
# ani.save('ols_3d.gif', writer='pillow', fps=20)
# ani.save('ols_3d.mp4', writer='ffmpeg', fps=20)
