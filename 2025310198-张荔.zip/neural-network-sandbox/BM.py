import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Circle
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体为 SimHei（黑体）
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class BoltzmannMachine:
    def __init__(self, num_neurons=3, temperature=1.0):
        self.num_neurons = num_neurons
        self.temperature = temperature

        # 更合理的权重初始化
        self.weights = np.random.uniform(-1.0, 1.0, (num_neurons, num_neurons))
        # 确保对称且无自连接
        for i in range(num_neurons):
            for j in range(i, num_neurons):
                if i == j:
                    self.weights[i, j] = 0  # 无自连接
                else:
                    # 随机权重，确保有正有负
                    weight = np.random.uniform(-1.0, 1.0)
                    self.weights[i, j] = weight
                    self.weights[j, i] = weight  # 对称

        # 偏置初始化
        self.biases = np.random.uniform(-0.5, 0.5, num_neurons)

        # 随机初始化神经元状态
        self.states = np.random.choice([-1, 1], size=num_neurons)

        # 记录历史状态用于可视化
        self.history = [self.states.copy()]
        self.energy_history = [self.calculate_energy()]

    def calculate_energy(self):
        """计算系统的能量"""
        energy = -0.5 * np.dot(self.states, np.dot(self.weights, self.states))
        energy -= np.dot(self.biases, self.states)
        return energy

    def update_neuron(self, neuron_idx):
        """更新单个神经元的状态"""
        # 计算该神经元的输入总和
        input_sum = np.dot(self.weights[neuron_idx], self.states) + self.biases[neuron_idx]

        # 计算激活概率（使用sigmoid函数）
        prob = 1 / (1 + np.exp(-2 * input_sum / self.temperature))

        # 根据概率更新状态
        if np.random.random() < prob:
            new_state = 1
        else:
            new_state = -1

        # 只有当状态真正改变时才记录
        if new_state != self.states[neuron_idx]:
            self.states[neuron_idx] = new_state
            return True  # 状态已改变
        return False  # 状态未改变

    def step(self):
        """执行一步更新（随机选择一个神经元更新）"""
        neuron_idx = np.random.randint(self.num_neurons)
        state_changed = self.update_neuron(neuron_idx)

        # 记录状态和能量（即使状态未改变也记录，但标记状态变化）
        self.history.append(self.states.copy())
        self.energy_history.append(self.calculate_energy())

        return state_changed

    def run(self, num_steps=1000):
        """运行指定步数"""
        state_changes = 0
        for _ in range(num_steps):
            if self.step():
                state_changes += 1
        return state_changes

    def run_to_equilibrium(self, max_steps=2000, energy_threshold=0.001):
        """运行系统直到达到热平衡状态"""
        stable_steps = 0
        for step in range(max_steps):
            old_energy = self.energy_history[-1]
            state_changed = self.step()
            new_energy = self.energy_history[-1]

            # 如果状态改变或能量变化显著，重置稳定计数器
            if state_changed or abs(new_energy - old_energy) > energy_threshold:
                stable_steps = 0
            else:
                stable_steps += 1

            # 如果连续稳定多步，认为达到平衡
            if stable_steps > 100 and step > 200:
                return step + 1

        return max_steps


def plot_network_structure(bm):
    """绘制网络结构图"""
    plt.figure(figsize=(8, 8))
    ax = plt.gca()

    ax.set_title('玻尔兹曼机网络结构', fontsize=16, fontweight='bold')
    ax.set_xlim(-2, 2)
    ax.set_ylim(-2, 2)
    ax.set_aspect('equal')

    # 在圆形上排列神经元
    angles = np.linspace(0, 2 * np.pi, bm.num_neurons, endpoint=False)
    positions = np.array([(np.cos(angle), np.sin(angle)) for angle in angles])

    # 绘制连接线
    for i in range(bm.num_neurons):
        for j in range(i + 1, bm.num_neurons):
            if abs(bm.weights[i, j]) > 0.01:  # 只显示显著连接
                color = 'red' if bm.weights[i, j] < 0 else 'blue'
                alpha = min(1.0, abs(bm.weights[i, j]))
                linewidth = max(1, abs(bm.weights[i, j]) * 3)
                ax.plot([positions[i, 0], positions[j, 0]],
                        [positions[i, 1], positions[j, 1]],
                        color=color, alpha=alpha, linewidth=linewidth)

    # 绘制神经元
    for i, (pos, state) in enumerate(zip(positions, bm.states)):
        color = 'red' if state == 1 else 'blue'
        circle = Circle(pos, 0.2, color=color, alpha=0.7, ec='black')
        ax.add_patch(circle)
        ax.text(pos[0], pos[1], f'N{i}\n({state})',
                ha='center', va='center', fontweight='bold')

    ax.axis('off')
    plt.tight_layout()
    plt.show()


def plot_weight_matrix(bm):
    """绘制权重矩阵热图"""
    plt.figure(figsize=(8, 6))
    ax = plt.gca()

    ax.set_title('连接权重矩阵', fontsize=16, fontweight='bold')

    # 创建热图
    im = ax.imshow(bm.weights, cmap='coolwarm', vmin=-1, vmax=1)

    # 添加数值标签
    for i in range(bm.num_neurons):
        for j in range(bm.num_neurons):
            text = ax.text(j, i, f'{bm.weights[i, j]:.3f}',
                           ha="center", va="center", color="black", fontweight='bold')

    ax.set_xticks(range(bm.num_neurons))
    ax.set_yticks(range(bm.num_neurons))
    ax.set_xticklabels([f'N{i}' for i in range(bm.num_neurons)])
    ax.set_yticklabels([f'N{i}' for i in range(bm.num_neurons)])

    plt.colorbar(im, ax=ax, shrink=0.8)
    plt.tight_layout()
    plt.show()


def plot_energy_evolution(bm, steps_to_equilibrium):
    """绘制能量演化图"""
    plt.figure(figsize=(10, 6))
    ax = plt.gca()

    ax.set_title('系统能量演化', fontsize=16, fontweight='bold')
    ax.set_xlabel('时间步')
    ax.set_ylabel('能量')

    # 绘制能量曲线
    ax.plot(bm.energy_history, 'b-', alpha=0.7, linewidth=1)

    # 标记平衡点
    if steps_to_equilibrium < len(bm.energy_history):
        ax.axvline(x=steps_to_equilibrium, color='r', linestyle='--',
                   label=f'平衡点 (步数: {steps_to_equilibrium})')
        ax.axhline(y=bm.energy_history[-1], color='g', linestyle=':',
                   label=f'平衡能量: {bm.energy_history[-1]:.3f}')

    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()


def plot_state_evolution(bm, steps_to_equilibrium):
    """绘制状态演化图"""
    plt.figure(figsize=(12, 6))
    ax = plt.gca()

    ax.set_title('神经元状态演化', fontsize=16, fontweight='bold')
    ax.set_xlabel('时间步')
    ax.set_ylabel('神经元状态')

    # 将历史状态转换为数组
    states_array = np.array(bm.history)

    # 绘制每个神经元的状态变化
    for i in range(bm.num_neurons):
        ax.plot(states_array[:, i], label=f'N{i}', linewidth=1.5)

    # 标记平衡点
    if steps_to_equilibrium < len(bm.history):
        ax.axvline(x=steps_to_equilibrium, color='r', linestyle='--',
                   label=f'平衡点 (步数: {steps_to_equilibrium})')

    ax.legend()
    ax.set_yticks([-1, 1])
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()


def plot_equilibrium_distribution(bm):
    """绘制热平衡状态分布"""
    plt.figure(figsize=(10, 6))
    ax = plt.gca()

    ax.set_title('热平衡状态分布', fontsize=16, fontweight='bold')
    ax.set_xlabel('状态')
    ax.set_ylabel('频率')

    # 分析最后100步的状态分布
    last_steps = min(100, len(bm.history))
    recent_states = bm.history[-last_steps:]

    # 将状态转换为二进制字符串
    states_binary = []
    for state in recent_states:
        binary_state = ''.join(['1' if s == 1 else '0' for s in state])
        states_binary.append(binary_state)

    # 计算所有可能状态的频率
    all_possible_states = [format(i, f'0{bm.num_neurons}b') for i in range(2 ** bm.num_neurons)]
    state_counts = {state: 0 for state in all_possible_states}

    for state in states_binary:
        state_counts[state] += 1

    states = list(state_counts.keys())
    frequencies = [state_counts[state] / len(states_binary) for state in states]

    # 绘制条形图
    colors = ['lightblue' if freq > 0 else 'lightgray' for freq in frequencies]
    bars = ax.bar(states, frequencies, color=colors, alpha=0.7)

    # 在条形上添加频率标签
    for bar, freq in zip(bars, frequencies):
        height = bar.get_height()
        if height > 0:  # 只显示非零频率
            ax.text(bar.get_x() + bar.get_width() / 2., height + 0.01,
                    f'{freq:.2f}', ha='center', va='bottom', fontweight='bold')

    ax.set_ylim(0, max(frequencies) * 1.2)
    plt.tight_layout()
    plt.show()


def main():
    # 设置随机种子以便复现结果
    np.random.seed(42)

    print("创建三个神经元的玻尔兹曼机...")

    # 创建玻尔兹曼机实例 - 使用更合理的参数
    bm = BoltzmannMachine(num_neurons=3, temperature=1.0)

    print("初始参数:")
    print("权重矩阵:")
    for i in range(bm.num_neurons):
        print(f"[{', '.join([f'{w:.5f}' for w in bm.weights[i]])}]")
    print(f"偏置: [{', '.join([f'{b:.5f}' for b in bm.biases])}]")
    print(f"初始状态: {bm.states}")
    print(f"初始能量: {bm.calculate_energy():.3f}")

    # 先运行一些步数以收集数据
    print("\n运行系统收集演化数据...")
    state_changes = bm.run(num_steps=300)
    print(f"在300步中状态改变了 {state_changes} 次")

    # 运行到平衡状态
    print("运行到热平衡状态...")
    steps_to_equilibrium = bm.run_to_equilibrium(max_steps=2000)

    print(f"\n在 {steps_to_equilibrium} 步后达到热平衡")
    print(f"最终状态: {bm.states}")
    print(f"最终能量: {bm.calculate_energy():.3f}")

    # 分析最终状态
    print("\n热平衡状态分析:")
    final_states_binary = [''.join(['1' if s == 1 else '0' for s in state])
                           for state in bm.history[-100:]]  # 看最后100步
    unique_states, counts = np.unique(final_states_binary, return_counts=True)

    print("在热平衡下的状态分布:")
    for state, count in zip(unique_states, counts):
        frequency = count / len(final_states_binary)
        print(f"状态 {state}: {frequency:.2%}")

    # 创建可视化 - 每个图在单独的画布中
    print("\n生成可视化图表...")
    plot_network_structure(bm)
    plot_weight_matrix(bm)
    plot_energy_evolution(bm, steps_to_equilibrium)
    plot_state_evolution(bm, steps_to_equilibrium)
    plot_equilibrium_distribution(bm)
    #     plot_parameters_info(bm, steps_to_equilibrium)

    # 返回最终的热平衡状态信息
    equilibrium_info = {
        'final_states': bm.states,
        'final_energy': bm.calculate_energy(),
        'state_distribution': dict(zip(unique_states, counts / len(final_states_binary))),
        'steps_to_equilibrium': steps_to_equilibrium
    }

    return equilibrium_info


if __name__ == "__main__":
    result = main()