import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.animation import FuncAnimation
import warnings

warnings.filterwarnings('ignore')


class SOFMTSP:
    def __init__(self, n_cities, n_neurons=None, learning_rate=0.8, radius=None):
        self.n_cities = n_cities
        self.n_neurons = n_neurons if n_neurons else n_cities * 5
        self.initial_learning_rate = learning_rate
        self.initial_radius = radius if radius else n_neurons // 2 if n_neurons else n_cities * 2.5

        self.cities = None
        self.neurons = None
        self.distance_matrix = None

        self.history = {
            'neurons': [],
            'learning_rates': [],
            'radii': [],
            'paths': [],
            'distances': []
        }

    def initialize_neurons_circle(self, cities):
        center = np.mean(cities, axis=0)
        max_distance = np.max(np.linalg.norm(cities - center, axis=1))

        angles = np.linspace(0, 2 * np.pi, self.n_neurons, endpoint=False)
        self.neurons = np.column_stack([
            center[0] + max_distance * np.cos(angles),
            center[1] + max_distance * np.sin(angles)
        ])

    def initialize_neurons_line(self, cities):
        min_coords = np.min(cities, axis=0)
        max_coords = np.max(cities, axis=0)
        t = np.linspace(0, 1, self.n_neurons)
        self.neurons = np.column_stack([
            min_coords[0] + t * (max_coords[0] - min_coords[0]),
            min_coords[1] + (1 - t) * (max_coords[1] - min_coords[1])
        ])

    def initialize_neurons_random(self, cities):
        min_coords = np.min(cities, axis=0)
        max_coords = np.max(cities, axis=0)

        self.neurons = np.random.rand(self.n_neurons, 2)
        self.neurons[:, 0] = min_coords[0] + self.neurons[:, 0] * (max_coords[0] - min_coords[0])
        self.neurons[:, 1] = min_coords[1] + self.neurons[:, 1] * (max_coords[1] - min_coords[1])

    def calculate_distance_matrix(self, points):
        n = len(points)
        distance_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                dist = np.linalg.norm(points[i] - points[j])
                distance_matrix[i, j] = dist
                distance_matrix[j, i] = dist
        return distance_matrix

    def find_winner_neuron(self, city):
        distances = np.linalg.norm(self.neurons - city, axis=1)
        return np.argmin(distances)

    def get_neighborhood(self, winner_idx, radius):
        distances = np.abs(np.arange(self.n_neurons) - winner_idx)
        distances = np.minimum(distances, self.n_neurons - distances)  # 环形拓扑
        return np.where(distances <= radius)[0]

    def update_neurons(self, city, winner_idx, learning_rate, radius):
        neighborhood_indices = self.get_neighborhood(winner_idx, radius)
        distances_to_winner = np.abs(neighborhood_indices - winner_idx)
        distances_to_winner = np.minimum(distances_to_winner,
                                         self.n_neurons - distances_to_winner)
        neighborhood_strength = np.exp(-0.5 * (distances_to_winner / max(radius, 1e-8)) ** 2)

        for i, idx in enumerate(neighborhood_indices):
            influence = learning_rate * neighborhood_strength[i]
            self.neurons[idx] += influence * (city - self.neurons[idx])

    def extract_path(self):
        city_neuron_mapping = []
        for city in self.cities:
            winner_idx = self.find_winner_neuron(city)
            city_neuron_mapping.append((winner_idx, city))

        city_neuron_mapping.sort(key=lambda x: x[0])

        path = []
        visited_neurons = set()
        for neuron_idx, city in city_neuron_mapping:
            if neuron_idx not in visited_neurons:
                path.append(city)
                visited_neurons.add(neuron_idx)

        return np.array(path)

    def calculate_path_distance(self, path):
        if len(path) < 2:
            return 0

        total_distance = 0
        for i in range(len(path)):
            total_distance += np.linalg.norm(path[i] - path[(i + 1) % len(path)])
        return total_distance

    def train(self, cities, epochs=1000, initialization='circle',
              learning_rate_decay='linear', radius_decay='exponential'):

        self.cities = cities
        self.n_cities = len(cities)

        if initialization == 'circle':
            self.initialize_neurons_circle(cities)
        elif initialization == 'line':
            self.initialize_neurons_line(cities)
        else:
            self.initialize_neurons_random(cities)

        self.history['neurons'].append(self.neurons.copy())
        initial_path = self.extract_path()
        self.history['paths'].append(initial_path)
        self.history['distances'].append(self.calculate_path_distance(initial_path))
        self.history['learning_rates'].append(self.initial_learning_rate)
        self.history['radii'].append(self.initial_radius)

        for epoch in range(epochs):

            if learning_rate_decay == 'linear':
                learning_rate = self.initial_learning_rate * (1 - epoch / epochs)
            else:
                learning_rate = self.initial_learning_rate * np.exp(-5 * epoch / epochs)

            if radius_decay == 'linear':
                radius = max(1, int(self.initial_radius * (1 - epoch / epochs)))
            else:
                radius = max(1, int(self.initial_radius * np.exp(-3 * epoch / epochs)))

            city_order = np.random.permutation(len(cities))

            for city_idx in city_order:
                city = cities[city_idx]
                winner_idx = self.find_winner_neuron(city)
                self.update_neurons(city, winner_idx, learning_rate, radius)

            if epoch % 10 == 0 or epoch == epochs - 1:
                self.history['neurons'].append(self.neurons.copy())
                current_path = self.extract_path()
                self.history['paths'].append(current_path)
                self.history['distances'].append(self.calculate_path_distance(current_path))
                self.history['learning_rates'].append(learning_rate)
                self.history['radii'].append(radius)

            if epoch % 100 == 0:
                current_distance = self.calculate_path_distance(self.extract_path())
                print(f'Epoch {epoch}/{epochs}, Distance: {current_distance:.2f}, '
                      f'LR: {learning_rate:.3f}, Radius: {radius}')

        final_path = self.extract_path()
        final_distance = self.calculate_path_distance(final_path)

        return final_path, final_distance

    def visualize_training_process(self, figsize=(15, 10)):
        fig, axes = plt.subplots(2, 3, figsize=figsize)
        fig.suptitle('SOFM Network for TSP - Training Process', fontsize=16, fontweight='bold')
        n_frames = len(self.history['neurons'])
        key_frames = np.linspace(0, n_frames - 1, min(6, n_frames), dtype=int)

        for i, frame_idx in enumerate(key_frames):
            ax = axes[i // 3, i % 3]
            neurons = self.history['neurons'][frame_idx]
            path = self.history['paths'][frame_idx]
            distance = self.history['distances'][frame_idx]
            lr = self.history['learning_rates'][frame_idx]
            radius = self.history['radii'][frame_idx]

            ax.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100,
                       label='Cities', alpha=0.7, marker='o')
            ax.scatter(neurons[:, 0], neurons[:, 1], c='blue', s=30,
                       label='Neurons', alpha=0.5, marker='x')

            for j in range(len(neurons)):
                next_j = (j + 1) % len(neurons)
                ax.plot([neurons[j, 0], neurons[next_j, 0]],
                        [neurons[j, 1], neurons[next_j, 1]], 'b-', alpha=0.3, linewidth=1)

            if len(path) > 1:
                for j in range(len(path)):
                    next_j = (j + 1) % len(path)
                    ax.plot([path[j, 0], path[next_j, 0]],
                            [path[j, 1], path[next_j, 1]], 'g-', linewidth=2, alpha=0.8)

            ax.set_title(f'Step {frame_idx}\nDist: {distance:.2f}, LR: {lr:.3f}, Rad: {radius}')
            ax.legend()
            ax.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def create_animation(self, interval=200):
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        def animate(frame):
            ax1.clear()
            ax2.clear()
            neurons = self.history['neurons'][frame]
            path = self.history['paths'][frame]
            distance = self.history['distances'][frame]

            ax1.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100,
                        label='Cities', alpha=0.7)
            ax1.scatter(neurons[:, 0], neurons[:, 1], c='blue', s=50,
                        label='Neurons', alpha=0.6)

            for j in range(len(neurons)):
                next_j = (j + 1) % len(neurons)
                ax1.plot([neurons[j, 0], neurons[next_j, 0]],
                         [neurons[j, 1], neurons[next_j, 1]], 'b-', alpha=0.3)

            if len(path) > 1:
                for j in range(len(path)):
                    next_j = (j + 1) % len(path)
                    ax1.plot([path[j, 0], path[next_j, 0]],
                             [path[j, 1], path[next_j, 1]], 'g-', linewidth=3, alpha=0.8)

            ax1.set_title(f'SOFM-TSP Network (Step {frame})\nPath Distance: {distance:.2f}')
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            ax2.plot(self.history['distances'][:frame + 1], 'b-', linewidth=2, label='Path Distance')
            ax2.set_xlabel('Training Step')
            ax2.set_ylabel('Distance')
            ax2.set_title('Convergence History')
            ax2.legend()
            ax2.grid(True, alpha=0.3)

            return ax1, ax2

        anim = FuncAnimation(fig, animate, frames=len(self.history['neurons']),
                             interval=interval, repeat=False)
        plt.tight_layout()
        plt.show()

        return anim

    def compare_initializations(self, cities, epochs=500):
        initializations = ['circle', 'line', 'random']
        results = {}

        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        axes = axes.ravel()

        for i, init_method in enumerate(initializations):
            solver = SOFMTSP(len(cities), n_neurons=len(cities) * 5)
            solver.cities = cities

            if init_method == 'circle':
                solver.initialize_neurons_circle(cities)
            elif init_method == 'line':
                solver.initialize_neurons_line(cities)
            else:
                solver.initialize_neurons_random(cities)

            distances = []
            for epoch in range(epochs):
                learning_rate = 0.8 * (1 - epoch / epochs)
                radius = max(1, int(len(cities) * 2.5 * (1 - epoch / epochs)))

                city_order = np.random.permutation(len(cities))
                for city_idx in city_order:
                    city = cities[city_idx]
                    winner_idx = solver.find_winner_neuron(city)
                    solver.update_neurons(city, winner_idx, learning_rate, radius)

                if epoch % 10 == 0:
                    path = solver.extract_path()
                    distance = solver.calculate_path_distance(path)
                    distances.append(distance)

            results[init_method] = distances

            ax = axes[i]
            path = solver.extract_path()
            ax.scatter(cities[:, 0], cities[:, 1], c='red', s=100, alpha=0.7)
            ax.scatter(solver.neurons[:, 0], solver.neurons[:, 1], c='blue', s=30, alpha=0.5)

            for j in range(len(path)):
                next_j = (j + 1) % len(path)
                ax.plot([path[j, 0], path[next_j, 0]],
                        [path[j, 1], path[next_j, 1]], 'g-', linewidth=2)

            ax.set_title(f'{init_method.capitalize()} Initialization\nFinal Distance: {distances[-1]:.2f}')
            ax.grid(True, alpha=0.3)

        axes[3].plot(results['circle'], 'b-', label='Circle', linewidth=2)
        axes[3].plot(results['line'], 'r-', label='Line', linewidth=2)
        axes[3].plot(results['random'], 'g-', label='Random', linewidth=2)
        axes[3].set_xlabel('Training Steps (x10)')
        axes[3].set_ylabel('Path Distance')
        axes[3].set_title('Convergence Comparison')
        axes[3].legend()
        axes[3].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

        return results


def generate_cities(n_cities, method='random', seed=42):
    np.random.seed(seed)

    if method == 'circle':
        angles = np.linspace(0, 2 * np.pi, n_cities, endpoint=False)
        cities = np.column_stack([50 + 40 * np.cos(angles), 50 + 40 * np.sin(angles)])
    elif method == 'grid':
        grid_size = int(np.ceil(np.sqrt(n_cities)))
        x = np.linspace(10, 90, grid_size)
        y = np.linspace(10, 90, grid_size)
        xx, yy = np.meshgrid(x, y)
        cities = np.column_stack([xx.ravel()[:n_cities], yy.ravel()[:n_cities]])
    else:
        cities = np.random.rand(n_cities, 2) * 100

    return cities


def main():

    np.random.seed(42)
    n_cities = 20
    cities = generate_cities(n_cities, method='random')

    sofm_solver = SOFMTSP(n_cities, n_neurons=n_cities * 6,
                          learning_rate=0.6, radius=n_cities * 3)

    final_path, final_distance = sofm_solver.train(
        cities, epochs=1000, initialization='circle',
        learning_rate_decay='exponential', radius_decay='exponential'
    )

    sofm_solver.visualize_training_process()

    sofm_solver.create_animation(interval=300)

    sofm_solver.compare_initializations(cities, epochs=300)

if __name__ == "__main__":
    main()