import sys
import numpy as np
import random
import math
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QProgressBar,
                             QSpinBox, QCheckBox, QComboBox, QGridLayout, QSlider)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scipy.special import expit  # Sigmoid function

class BoltzmannMachine:
    """Boltzmann Machine with 3 neurons"""
    
    def __init__(self):
        self.num_neurons = 3
        self.neurons = np.array([0, 0, 0])  # Binary states: 0 or 1
        self.weights = np.zeros((3, 3))
        self.biases = np.zeros(3)
        
        # Initialize with random weights and biases
        self.initialize_weights()
        
        # History tracking
        self.state_history = []
        self.energy_history = []
        self.temperature_history = []
        self.probability_history = []
        
        # Simulation parameters
        self.current_temperature = 1.0
        self.target_temperature = 0.01
        self.cooling_rate = 0.95
        self.step_count = 0
        
    def initialize_weights(self):
        """Initialize weights with symmetric connections (no self-connections)"""
        # Random weights between -1 and 1
        self.weights = np.random.uniform(-1, 1, (3, 3))
        np.fill_diagonal(self.weights, 0)  # No self-connections
        self.weights = (self.weights + self.weights.T) / 2  # Symmetric
        
        # Random biases
        self.biases = np.random.uniform(-0.5, 0.5, 3)
        
    def calculate_energy(self, state=None):
        """Calculate the energy of a given state"""
        if state is None:
            state = self.neurons
            
        energy = 0
        # Energy = -ΣΣ w_ij s_i s_j - Σ b_i s_i
        for i in range(self.num_neurons):
            for j in range(i+1, self.num_neurons):
                energy -= self.weights[i, j] * state[i] * state[j]
            energy -= self.biases[i] * state[i]
            
        return energy
    
    def calculate_probability(self, neuron_index, current_state):
        """Calculate the probability of neuron being active"""
        # Local field: h_i = Σ_j w_ij s_j + b_i
        local_field = 0
        for j in range(self.num_neurons):
            if j != neuron_index:
                local_field += self.weights[neuron_index, j] * current_state[j]
        local_field += self.biases[neuron_index]
        
        # Probability using Boltzmann distribution
        probability = expit(local_field / self.current_temperature)
        return probability, local_field
    
    def update_neuron(self, neuron_index):
        """Update a single neuron using stochastic update rule"""
        probability, local_field = self.calculate_probability(neuron_index, self.neurons)
        
        # Stochastic update
        if random.random() < probability:
            new_state = 1
        else:
            new_state = 0
            
        return new_state, probability, local_field
    
    def asynchronous_update(self):
        """Perform one asynchronous update (update one random neuron)"""
        neuron_index = random.randint(0, self.num_neurons - 1)
        old_state = self.neurons[neuron_index]
        
        new_state, probability, local_field = self.update_neuron(neuron_index)
        self.neurons[neuron_index] = new_state
        
        # Record history
        self.state_history.append(self.neurons.copy())
        current_energy = self.calculate_energy()
        self.energy_history.append(current_energy)
        self.temperature_history.append(self.current_temperature)
        self.probability_history.append(probability)
        
        self.step_count += 1
        
        return neuron_index, old_state, new_state, probability, local_field, current_energy
    
    def cool_temperature(self):
        """Reduce temperature according to cooling schedule"""
        self.current_temperature *= self.cooling_rate
        if self.current_temperature < self.target_temperature:
            self.current_temperature = self.target_temperature
            
    def is_thermal_equilibrium(self, window_size=50, threshold=0.01):
        """Check if network has reached thermal equilibrium"""
        if len(self.energy_history) < window_size:
            return False
            
        # Check if energy has stabilized
        recent_energies = self.energy_history[-window_size:]
        energy_std = np.std(recent_energies)
        
        # Check if temperature is near target
        temperature_near_target = (self.current_temperature - self.target_temperature) < 0.1
        
        return energy_std < threshold and temperature_near_target
    
    def get_state_probability_distribution(self):
        """Calculate probability distribution over all possible states"""
        all_states = []
        for i in range(2**self.num_neurons):
            state = [(i >> j) & 1 for j in range(self.num_neurons)]
            all_states.append(state)
            
        probabilities = []
        for state in all_states:
            energy = self.calculate_energy(state)
            # Boltzmann probability: p(state) ∝ exp(-E(state)/T)
            probability = math.exp(-energy / self.current_temperature)
            probabilities.append(probability)
            
        # Normalize probabilities
        total = sum(probabilities)
        probabilities = [p/total for p in probabilities]
        
        return all_states, probabilities
    
    def reset(self):
        """Reset the network to initial state"""
        self.neurons = np.array([0, 0, 0])
        self.current_temperature = 1.0
        self.step_count = 0
        self.state_history = []
        self.energy_history = []
        self.temperature_history = []
        self.probability_history = []

class MplCanvas(FigureCanvas):
    """Matplotlib canvas wrapper"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class BoltzmannVisualizer(QMainWindow):
    """Boltzmann Machine PyQt Visualizer"""
    
    update_signal = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.bm = BoltzmannMachine()
        self.is_running = False
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_step)
        self.update_signal.connect(self.update_display)
        
        self.init_ui()
        self.update_display()
        
    def init_ui(self):
        """Initialize user interface"""
        self.setWindowTitle("3-Neuron Boltzmann Machine Visualizer")
        self.setGeometry(100, 100, 1400, 900)
        
        # Set dark theme
        self.set_dark_theme()
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left control panel
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # Right visualization area
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 2)
        
    def set_dark_theme(self):
        """Set dark theme for the application"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """Create control panel"""
        control_group = QGroupBox("Control Panel")
        control_layout = QVBoxLayout(control_group)
        
        # Title
        title_label = QLabel("Boltzmann Machine Console")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # Network parameters
        params_group = QGroupBox("Network Parameters")
        params_layout = QGridLayout(params_group)
        
        params_layout.addWidget(QLabel("Initial Temperature:"), 0, 0)
        self.init_temp_slider = QSlider(Qt.Horizontal)
        self.init_temp_slider.setRange(1, 100)
        self.init_temp_slider.setValue(10)
        self.init_temp_slider.valueChanged.connect(self.update_init_temp)
        params_layout.addWidget(self.init_temp_slider, 0, 1)
        
        self.init_temp_label = QLabel("1.0")
        params_layout.addWidget(self.init_temp_label, 0, 2)
        
        params_layout.addWidget(QLabel("Target Temperature:"), 1, 0)
        self.target_temp_slider = QSlider(Qt.Horizontal)
        self.target_temp_slider.setRange(1, 100)
        self.target_temp_slider.setValue(1)
        self.target_temp_slider.valueChanged.connect(self.update_target_temp)
        params_layout.addWidget(self.target_temp_slider, 1, 1)
        
        self.target_temp_label = QLabel("0.01")
        params_layout.addWidget(self.target_temp_label, 1, 2)
        
        params_layout.addWidget(QLabel("Cooling Rate:"), 2, 0)
        self.cooling_slider = QSlider(Qt.Horizontal)
        self.cooling_slider.setRange(50, 99)
        self.cooling_slider.setValue(95)
        self.cooling_slider.valueChanged.connect(self.update_cooling_rate)
        params_layout.addWidget(self.cooling_slider, 2, 1)
        
        self.cooling_label = QLabel("0.95")
        params_layout.addWidget(self.cooling_label, 2, 2)
        
        params_layout.addWidget(QLabel("Update Speed (ms):"), 3, 0)
        self.speed_spin = QSpinBox()
        self.speed_spin.setRange(10, 1000)
        self.speed_spin.setValue(100)
        self.speed_spin.valueChanged.connect(self.change_update_speed)
        params_layout.addWidget(self.speed_spin, 3, 1)
        
        control_layout.addWidget(params_group)
        
        # Weight matrix display
        weight_group = QGroupBox("Weight Matrix & Biases")
        weight_layout = QGridLayout(weight_group)
        
        weight_layout.addWidget(QLabel("Weights:"), 0, 0)
        self.weight_display = QTextEdit()
        self.weight_display.setMaximumHeight(80)
        self.weight_display.setReadOnly(True)
        weight_layout.addWidget(self.weight_display, 0, 1, 1, 2)
        
        weight_layout.addWidget(QLabel("Biases:"), 1, 0)
        self.bias_display = QTextEdit()
        self.bias_display.setMaximumHeight(40)
        self.bias_display.setReadOnly(True)
        weight_layout.addWidget(self.bias_display, 1, 1, 1, 2)
        
        control_layout.addWidget(weight_group)
        
        # Simulation control
        sim_group = QGroupBox("Simulation Control")
        sim_layout = QVBoxLayout(sim_group)
        
        sim_buttons_layout = QHBoxLayout()
        self.start_btn = QPushButton("Start Simulation")
        self.start_btn.clicked.connect(self.start_simulation)
        sim_buttons_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop Simulation")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        sim_buttons_layout.addWidget(self.stop_btn)
        
        self.step_btn = QPushButton("Single Step")
        self.step_btn.clicked.connect(self.single_step)
        sim_buttons_layout.addWidget(self.step_btn)
        
        sim_layout.addLayout(sim_buttons_layout)
        
        reset_layout = QHBoxLayout()
        self.reset_btn = QPushButton("Reset Network")
        self.reset_btn.clicked.connect(self.reset_network)
        reset_layout.addWidget(self.reset_btn)
        
        self.random_weights_btn = QPushButton("Random Weights")
        self.random_weights_btn.clicked.connect(self.randomize_weights)
        reset_layout.addWidget(self.random_weights_btn)
        
        sim_layout.addLayout(reset_layout)
        control_layout.addWidget(sim_group)
        
        # Current state display
        state_group = QGroupBox("Current State")
        state_layout = QGridLayout(state_group)
        
        self.neuron_labels = []
        self.state_labels = []
        self.prob_labels = []
        
        for i in range(3):
            neuron_label = QLabel(f"Neuron {i+1}:")
            state_label = QLabel("0")
            state_label.setStyleSheet("color: red; font-weight: bold;")
            prob_label = QLabel("P = 0.000")
            
            state_layout.addWidget(neuron_label, i, 0)
            state_layout.addWidget(state_label, i, 1)
            state_layout.addWidget(prob_label, i, 2)
            
            self.neuron_labels.append(neuron_label)
            self.state_labels.append(state_label)
            self.prob_labels.append(prob_label)
            
        state_layout.addWidget(QLabel("Temperature:"), 3, 0)
        self.temp_label = QLabel("1.000")
        state_layout.addWidget(self.temp_label, 3, 1)
        
        state_layout.addWidget(QLabel("Energy:"), 4, 0)
        self.energy_label = QLabel("0.000")
        state_layout.addWidget(self.energy_label, 4, 1)
        
        control_layout.addWidget(state_group)
        
        # Progress and info
        info_group = QGroupBox("Simulation Information")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(120)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        self.progress_bar = QProgressBar()
        info_layout.addWidget(self.progress_bar)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
        
    def create_visualization_area(self):
        """Create visualization area"""
        visualization_widget = QTabWidget()
        
        # Energy landscape tab
        energy_tab = QWidget()
        energy_layout = QVBoxLayout(energy_tab)
        self.energy_canvas = MplCanvas(self, width=8, height=4)
        energy_layout.addWidget(self.energy_canvas)
        visualization_widget.addTab(energy_tab, "Energy Landscape")
        
        # Temperature evolution tab
        temp_tab = QWidget()
        temp_layout = QVBoxLayout(temp_tab)
        self.temp_canvas = MplCanvas(self, width=8, height=4)
        temp_layout.addWidget(self.temp_canvas)
        visualization_widget.addTab(temp_tab, "Temperature Evolution")
        
        # State probability distribution tab
        prob_tab = QWidget()
        prob_layout = QVBoxLayout(prob_tab)
        self.prob_canvas = MplCanvas(self, width=8, height=4)
        prob_layout.addWidget(self.prob_canvas)
        visualization_widget.addTab(prob_tab, "State Probabilities")
        
        # Network structure tab
        struct_tab = QWidget()
        struct_layout = QVBoxLayout(struct_tab)
        self.struct_canvas = MplCanvas(self, width=6, height=6)
        struct_layout.addWidget(self.struct_canvas)
        visualization_widget.addTab(struct_tab, "Network Structure")
        
        return visualization_widget
        
    def update_init_temp(self):
        """Update initial temperature"""
        value = self.init_temp_slider.value() / 10.0
        self.bm.current_temperature = value
        self.init_temp_label.setText(f"{value:.1f}")
        
    def update_target_temp(self):
        """Update target temperature"""
        value = self.target_temp_slider.value() / 100.0
        self.bm.target_temperature = value
        self.target_temp_label.setText(f"{value:.2f}")
        
    def update_cooling_rate(self):
        """Update cooling rate"""
        value = self.cooling_slider.value() / 100.0
        self.bm.cooling_rate = value
        self.cooling_label.setText(f"{value:.2f}")
        
    def change_update_speed(self):
        """Change update speed"""
        self.update_timer.setInterval(self.speed_spin.value())
        
    def start_simulation(self):
        """Start the simulation"""
        self.is_running = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.update_timer.start(self.speed_spin.value())
        self.info_text.append("Simulation started")
        
    def stop_simulation(self):
        """Stop the simulation"""
        self.is_running = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.update_timer.stop()
        self.info_text.append("Simulation stopped")
        
    def single_step(self):
        """Perform a single update step"""
        self.update_step()
        
    def reset_network(self):
        """Reset the network"""
        self.bm.reset()
        self.info_text.append("Network reset")
        self.update_display()
        
    def randomize_weights(self):
        """Randomize weights and biases"""
        self.bm.initialize_weights()
        self.info_text.append("Weights and biases randomized")
        self.update_display()
        
    def update_step(self):
        """Perform one update step"""
        if self.is_running:
            # Perform asynchronous update
            neuron_idx, old_state, new_state, probability, local_field, energy = self.bm.asynchronous_update()
            
            # Cool temperature
            self.bm.cool_temperature()
            
            # Check for thermal equilibrium
            if self.bm.is_thermal_equilibrium():
                self.info_text.append("Thermal equilibrium reached!")
                self.stop_simulation()
            
            # Update display
            self.update_signal.emit()
            
    def update_display(self):
        """Update all displays"""
        self.update_network_info()
        self.plot_energy_landscape()
        self.plot_temperature_evolution()
        self.plot_state_probabilities()
        self.plot_network_structure()
        
    def update_network_info(self):
        """Update network information display"""
        # Update weight and bias displays
        weight_text = "Weight Matrix:\n"
        for i in range(3):
            weight_text += f"[{self.bm.weights[i, 0]:.3f}, {self.bm.weights[i, 1]:.3f}, {self.bm.weights[i, 2]:.3f}]\n"
        self.weight_display.setText(weight_text)
        
        bias_text = f"Biases: [{self.bm.biases[0]:.3f}, {self.bm.biases[1]:.3f}, {self.bm.biases[2]:.3f}]"
        self.bias_display.setText(bias_text)
        
        # Update current state display
        for i in range(3):
            probability, local_field = self.bm.calculate_probability(i, self.bm.neurons)
            self.state_labels[i].setText(str(self.bm.neurons[i]))
            self.prob_labels[i].setText(f"P = {probability:.3f}")
            
            # Color active neurons green
            if self.bm.neurons[i] == 1:
                self.state_labels[i].setStyleSheet("color: green; font-weight: bold;")
            else:
                self.state_labels[i].setStyleSheet("color: red; font-weight: bold;")
        
        # Update temperature and energy
        self.temp_label.setText(f"{self.bm.current_temperature:.3f}")
        current_energy = self.bm.calculate_energy()
        self.energy_label.setText(f"{current_energy:.3f}")
        
        # Update progress bar (temperature progress)
        temp_progress = 100 * (1 - (self.bm.current_temperature - self.bm.target_temperature) / 
                             (1.0 - self.bm.target_temperature))
        self.progress_bar.setValue(int(temp_progress))
        
        # Update info text
        info = f"Step: {self.bm.step_count}\n"
        info += f"Temperature: {self.bm.current_temperature:.3f}\n"
        info += f"Energy: {current_energy:.3f}\n"
        
        if self.bm.is_thermal_equilibrium():
            info += "Status: Thermal Equilibrium ✓"
        else:
            info += "Status: Cooling..."
            
        self.info_text.clear()
        self.info_text.append(info)
        
    def plot_energy_landscape(self):
        """Plot energy landscape"""
        self.energy_canvas.fig.clear()
        ax = self.energy_canvas.fig.add_subplot(111)
        
        if self.bm.energy_history:
            ax.plot(range(len(self.bm.energy_history)), 
                   self.bm.energy_history, 'b-', linewidth=2, alpha=0.7)
            ax.set_title('Energy Landscape Over Time', color='white', fontsize=12)
            ax.set_xlabel('Update Steps', color='white')
            ax.set_ylabel('Energy', color='white')
            ax.grid(True, alpha=0.3)
            
        ax.set_facecolor('#2b2b2b')
        self.energy_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        self.energy_canvas.draw()
        
    def plot_temperature_evolution(self):
        """Plot temperature evolution"""
        self.temp_canvas.fig.clear()
        ax = self.temp_canvas.fig.add_subplot(111)
        
        if self.bm.temperature_history:
            ax.plot(range(len(self.bm.temperature_history)), 
                   self.bm.temperature_history, 'r-', linewidth=2, alpha=0.7)
            ax.set_title('Temperature Evolution', color='white', fontsize=12)
            ax.set_xlabel('Update Steps', color='white')
            ax.set_ylabel('Temperature', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_yscale('log')  # Log scale for better visualization
            
        ax.set_facecolor('#2b2b2b')
        self.temp_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        self.temp_canvas.draw()
        
    def plot_state_probabilities(self):
        """Plot state probability distribution"""
        self.prob_canvas.fig.clear()
        ax = self.prob_canvas.fig.add_subplot(111)
        
        # Get current probability distribution
        all_states, probabilities = self.bm.get_state_probability_distribution()
        
        # Create state labels
        state_labels = [f"{state[0]}{state[1]}{state[2]}" for state in all_states]
        
        # Plot bar chart
        bars = ax.bar(range(len(probabilities)), probabilities, color='skyblue', alpha=0.7)
        ax.set_title('State Probability Distribution', color='white', fontsize=12)
        ax.set_xlabel('State (Binary)', color='white')
        ax.set_ylabel('Probability', color='white')
        ax.set_xticks(range(len(state_labels)))
        ax.set_xticklabels(state_labels, color='white')
        
        # Add probability values on bars
        for i, (bar, prob) in enumerate(zip(bars, probabilities)):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                   f'{prob:.3f}', ha='center', va='bottom', color='white', fontsize=8)
        
        ax.set_facecolor('#2b2b2b')
        self.prob_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        self.prob_canvas.draw()
        
    def plot_network_structure(self):
        """Plot network structure with weights"""
        self.struct_canvas.fig.clear()
        ax = self.struct_canvas.fig.add_subplot(111)
        
        # Neuron positions in a triangle
        positions = {
            0: (0.5, 0.9),   # Top
            1: (0.1, 0.1),   # Bottom left
            2: (0.9, 0.1)    # Bottom right
        }
        
        # Plot neurons
        for i in range(3):
            color = 'green' if self.bm.neurons[i] == 1 else 'red'
            circle = plt.Circle(positions[i], 0.1, color=color, alpha=0.8)
            ax.add_patch(circle)
            ax.text(positions[i][0], positions[i][1], f'N{i+1}', 
                   ha='center', va='center', color='white', fontweight='bold')
        
        # Plot connections with weights
        for i in range(3):
            for j in range(i+1, 3):
                weight = self.bm.weights[i, j]
                color = 'green' if weight > 0 else 'red'
                width = abs(weight) * 3
                
                # Draw line with arrow in the middle
                x1, y1 = positions[i]
                x2, y2 = positions[j]
                
                # Draw bidirectional connection
                ax.plot([x1, x2], [y1, y2], color=color, linewidth=width, alpha=0.6)
                
                # Add weight label in the middle
                mid_x, mid_y = (x1 + x2) / 2, (y1 + y2) / 2
                ax.text(mid_x, mid_y, f'{weight:.2f}', 
                       ha='center', va='center', 
                       bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8),
                       fontsize=8)
        
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_aspect('equal')
        ax.set_title('Network Structure (Green=Active, Red=Inactive)', color='white', fontsize=12)
        ax.set_facecolor('#2b2b2b')
        self.struct_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        ax.set_xticks([])
        ax.set_yticks([])
        
        self.struct_canvas.draw()

def main():
    """Main function"""
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = BoltzmannVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()