import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import seaborn as sns
from matplotlib.animation import FuncAnimation
from matplotlib.gridspec import GridSpec
import warnings

warnings.filterwarnings('ignore')

# 设置中文字体和样式
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False
sns.set_style("whitegrid")


class OLS_RBF_Network:
    """OLS RBF网络实现"""

    def __init__(self, max_centers=20, tolerance=1e-6):
        self.max_centers = max_centers
        self.tolerance = tolerance
        self.centers = None
        self.sigma = None
        self.weights = None
        self.selected_indices = []
        self.errors = []
        self.explained_variance = []

    def _rbf_function(self, x, center, sigma):
        """高斯径向基函数"""
        return np.exp(-np.linalg.norm(x - center) ** 2 / (2 * sigma ** 2))

    def _compute_gram_matrix(self, X, centers, sigma):
        """计算Gram矩阵"""
        n_samples = X.shape[0]
        n_centers = len(centers)
        Phi = np.zeros((n_samples, n_centers))

        for i in range(n_samples):
            for j in range(n_centers):
                Phi[i, j] = self._rbf_function(X[i], centers[j], sigma)

        return Phi

    def fit(self, X, y, sigma=1.0):
        """OLS训练算法"""
        n_samples, n_features = X.shape
        self.centers = X.copy()
        self.sigma = sigma

        # 初始化
        residual = y.copy()
        selected_indices = []
        errors = []
        explained_variance = []

        # 所有候选中心
        candidate_indices = list(range(n_samples))

        # 计算初始误差
        initial_error = np.sum(residual ** 2)
        total_variance = np.sum((y - np.mean(y)) ** 2)

        print("开始OLS训练...")
        print(f"初始误差: {initial_error:.6f}")
        print(f"总方差: {total_variance:.6f}")
        print("-" * 50)

        for step in range(self.max_centers):
            if len(candidate_indices) == 0:
                break

            # 计算每个候选基函数对残差的投影
            projections = []
            for idx in candidate_indices:
                # 计算当前基函数
                phi = np.array([self._rbf_function(x, self.centers[idx], sigma)
                                for x in X])

                # 计算投影
                if np.linalg.norm(phi) > 1e-10:
                    projection = np.dot(residual, phi) / np.linalg.norm(phi) ** 2
                    projections.append((idx, abs(projection)))
                else:
                    projections.append((idx, 0))

            # 选择投影最大的基函数
            selected_idx, max_projection = max(projections, key=lambda x: x[1])

            if max_projection < self.tolerance:
                break

            # 添加到已选集合
            selected_indices.append(selected_idx)
            candidate_indices.remove(selected_idx)

            # 构建设计矩阵
            Phi_selected = np.column_stack([
                np.array([self._rbf_function(x, self.centers[idx], sigma)
                          for x in X])
                for idx in selected_indices
            ])

            # 添加偏置项
            Phi_selected = np.column_stack([np.ones(n_samples), Phi_selected])

            # 计算最小二乘解
            try:
                weights = np.linalg.lstsq(Phi_selected, y, rcond=None)[0]
            except:
                weights = np.linalg.pinv(Phi_selected) @ y

            # 更新预测和残差
            y_pred = Phi_selected @ weights
            residual = y - y_pred

            # 计算误差和解释方差
            current_error = np.sum(residual ** 2)
            explained_var = 1 - current_error / total_variance

            errors.append(current_error)
            explained_variance.append(explained_var)

            print(f"步骤 {step + 1}: 选择中心 {selected_idx}, "
                  f"误差: {current_error:.6f}, "
                  f"解释方差: {explained_var:.4f}")

            # 检查收敛
            if current_error < self.tolerance:
                break

        # 保存最终结果
        self.selected_indices = selected_indices
        self.weights = weights
        self.errors = errors
        self.explained_variance = explained_variance
        self.final_centers = [self.centers[idx] for idx in selected_indices]

        print("-" * 50)
        print(f"训练完成! 最终选择 {len(selected_indices)} 个中心")
        print(f"最终误差: {errors[-1]:.6f}")
        print(f"最终解释方差: {explained_variance[-1]:.4f}")

        return self

    def predict(self, X):
        """预测"""
        if self.weights is None:
            raise ValueError("模型尚未训练")

        n_samples = X.shape[0]
        n_centers = len(self.selected_indices)

        # 构建设计矩阵
        Phi = np.ones((n_samples, n_centers + 1))

        for i, idx in enumerate(self.selected_indices):
            center = self.centers[idx]
            for j in range(n_samples):
                Phi[j, i + 1] = self._rbf_function(X[j], center, self.sigma)

        return Phi @ self.weights


def generate_synthetic_data():
    """生成合成数据"""
    np.random.seed(42)

    # 生成训练数据
    n_samples = 100
    X_train = np.linspace(-2, 2, n_samples).reshape(-1, 1)
    y_train = 1 + np.sin(np.pi * X_train / 2).flatten() + 0.1 * np.random.randn(n_samples)

    # 生成测试数据
    X_test = np.linspace(-2.5, 2.5, 200).reshape(-1, 1)
    y_test_true = 1 + np.sin(np.pi * X_test / 2).flatten()

    return X_train, y_train, X_test, y_test_true


def visualize_ols_process():
    """可视化OLS学习过程"""

    # 生成数据
    X_train, y_train, X_test, y_test_true = generate_synthetic_data()

    # 创建OLS RBF网络
    ols_net = OLS_RBF_Network(max_centers=15, tolerance=1e-6)

    # 训练网络
    ols_net.fit(X_train, y_train, sigma=0.5)

    # 预测
    y_pred = ols_net.predict(X_test)

    # 创建可视化图形
    fig = plt.figure(figsize=(20, 12))
    gs = GridSpec(3, 3, figure=fig)

    # 1. 主图：拟合结果
    ax1 = fig.add_subplot(gs[0:2, 0:2])
    ax1.plot(X_test, y_test_true, 'k-', linewidth=3, alpha=0.7, label='真实函数')
    ax1.plot(X_test, y_pred, 'r--', linewidth=2, label='OLS RBF预测')
    ax1.scatter(X_train, y_train, c='blue', alpha=0.6, s=30, label='训练数据')

    # 标记选择的中心
    selected_centers = np.array(ols_net.final_centers).flatten()
    center_y = ols_net.predict(selected_centers.reshape(-1, 1))
    ax1.scatter(selected_centers, center_y, c='red', s=100,
                marker='*', edgecolors='black', linewidth=1, label='RBF中心')

    ax1.set_xlabel('输入 x', fontsize=12)
    ax1.set_ylabel('输出 y', fontsize=12)
    ax1.set_title('OLS RBF网络拟合结果', fontsize=14, fontweight='bold')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # 2. 误差收敛曲线
    ax2 = fig.add_subplot(gs[0, 2])
    steps = range(1, len(ols_net.errors) + 1)
    ax2.plot(steps, ols_net.errors, 'bo-', linewidth=2, markersize=6)
    ax2.set_xlabel('选择的基函数数量', fontsize=10)
    ax2.set_ylabel('误差平方和', fontsize=10)
    ax2.set_title('误差收敛曲线', fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    ax2.set_yscale('log')

    # 3. 解释方差曲线
    ax3 = fig.add_subplot(gs[1, 2])
    ax3.plot(steps, ols_net.explained_variance, 'go-', linewidth=2, markersize=6)
    ax3.set_xlabel('选择的基函数数量', fontsize=10)
    ax3.set_ylabel('解释方差比例', fontsize=10)
    ax3.set_title('解释方差增长曲线', fontsize=12, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.set_ylim(0, 1.1)

    # 4. 基函数可视化
    ax4 = fig.add_subplot(gs[2, 0])
    colors = plt.cm.viridis(np.linspace(0, 1, len(ols_net.final_centers)))

    for i, center in enumerate(ols_net.final_centers):
        rbf_values = np.array([ols_net._rbf_function(x, center, ols_net.sigma)
                               for x in X_test.flatten()])
        ax4.plot(X_test, rbf_values, color=colors[i], alpha=0.7,
                 label=f'中心 {i + 1}')

    ax4.set_xlabel('输入 x', fontsize=10)
    ax4.set_ylabel('基函数值', fontsize=10)
    ax4.set_title('选择的RBF基函数', fontsize=12, fontweight='bold')
    ax4.grid(True, alpha=0.3)

    # 5. 残差图
    ax5 = fig.add_subplot(gs[2, 1])
    y_train_pred = ols_net.predict(X_train)
    residuals = y_train - y_train_pred
    ax5.scatter(y_train_pred, residuals, c='purple', alpha=0.6)
    ax5.axhline(y=0, color='red', linestyle='--', alpha=0.8)
    ax5.set_xlabel('预测值', fontsize=10)
    ax5.set_ylabel('残差', fontsize=10)
    ax5.set_title('残差分析图', fontsize=12, fontweight='bold')
    ax5.grid(True, alpha=0.3)

    # 6. 参数重要性
    ax6 = fig.add_subplot(gs[2, 2])
    weights = ols_net.weights[1:]  # 排除偏置项
    centers_idx = range(1, len(weights) + 1)

    ax6.bar(centers_idx, np.abs(weights), color='orange', alpha=0.7)
    ax6.set_xlabel('基函数索引', fontsize=10)
    ax6.set_ylabel('权值绝对值', fontsize=10)
    ax6.set_title('RBF权值重要性', fontsize=12, fontweight='bold')
    ax6.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    return ols_net


def compare_different_sigmas():
    """比较不同sigma参数的效果"""

    X_train, y_train, X_test, y_test_true = generate_synthetic_data()

    sigma_values = [0.2, 0.5, 1.0, 2.0]
    results = {}

    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    axes = axes.flatten()

    for i, sigma in enumerate(sigma_values):
        ols_net = OLS_RBF_Network(max_centers=10, tolerance=1e-6)
        ols_net.fit(X_train, y_train, sigma=sigma)

        y_pred = ols_net.predict(X_test)
        mse = np.mean((y_pred - y_test_true) ** 2)

        # 绘制结果
        ax = axes[i]
        ax.plot(X_test, y_test_true, 'k-', linewidth=2, alpha=0.7, label='真实函数')
        ax.plot(X_test, y_pred, 'r--', linewidth=2, label='预测')
        ax.scatter(X_train, y_train, c='blue', alpha=0.5, s=20, label='训练数据')

        ax.set_title(f'σ = {sigma}, MSE = {mse:.4f}\n选择{len(ols_net.selected_indices)}个中心',
                     fontsize=12, fontweight='bold')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.legend()
        ax.grid(True, alpha=0.3)

        results[sigma] = {
            'mse': mse,
            'n_centers': len(ols_net.selected_indices),
            'final_error': ols_net.errors[-1]
        }

    plt.tight_layout()
    plt.show()

    # 打印比较结果
    print("\n" + "=" * 60)
    print("不同Sigma参数比较结果:")
    print("=" * 60)
    print(f"{'Sigma':<8} {'MSE':<12} {'选择中心数':<12} {'最终误差':<12}")
    print("-" * 60)
    for sigma, result in results.items():
        print(f"{sigma:<8} {result['mse']:<12.6f} {result['n_centers']:<12} {result['final_error']:<12.6f}")

    return results


def ols_step_by_step_animation():
    """OLS逐步选择过程的动画演示"""

    # 生成简单数据用于动画
    np.random.seed(42)
    n_samples = 50
    X_simple = np.linspace(-2, 2, n_samples).reshape(-1, 1)
    y_simple = 1 + np.sin(np.pi * X_simple / 2).flatten() + 0.1 * np.random.randn(n_samples)

    # 简化OLS实现用于动画
    class SimpleOLS:
        def __init__(self, max_steps=8):
            self.max_steps = max_steps
            self.steps_data = []

        def fit_animated(self, X, y, sigma=0.5):
            n_samples = X.shape[0]
            residual = y.copy()
            selected = []

            for step in range(self.max_steps):
                # 找到最佳候选
                best_idx = -1
                best_proj = -1

                for idx in range(n_samples):
                    if idx in selected:
                        continue

                    phi = np.array([np.exp(-np.linalg.norm(x - X[idx]) ** 2 / (2 * sigma ** 2))
                                    for x in X])

                    if np.linalg.norm(phi) > 1e-10:
                        proj = abs(np.dot(residual, phi) / np.linalg.norm(phi) ** 2)
                        if proj > best_proj:
                            best_proj = proj
                            best_idx = idx

                if best_idx == -1:
                    break

                selected.append(best_idx)

                # 计算当前预测
                Phi = np.column_stack([
                    np.array([np.exp(-np.linalg.norm(x - X[idx]) ** 2 / (2 * sigma ** 2))
                              for x in X])
                    for idx in selected
                ])
                Phi = np.column_stack([np.ones(n_samples), Phi])

                try:
                    w = np.linalg.lstsq(Phi, y, rcond=None)[0]
                except:
                    w = np.linalg.pinv(Phi) @ y

                y_pred = Phi @ w
                current_error = np.sum((y - y_pred) ** 2)

                self.steps_data.append({
                    'step': step + 1,
                    'selected': selected.copy(),
                    'prediction': y_pred.copy(),
                    'error': current_error,
                    'centers': [X[idx][0] for idx in selected]
                })

            return self

    # 创建动画
    simple_ols = SimpleOLS(max_steps=8)
    simple_ols.fit_animated(X_simple, y_simple)

    # 创建动画图形
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    def animate(frame):
        ax1.clear()
        ax2.clear()

        if frame < len(simple_ols.steps_data):
            data = simple_ols.steps_data[frame]

            # 左图：拟合情况
            ax1.scatter(X_simple, y_simple, c='blue', alpha=0.6, s=30, label='数据点')
            ax1.plot(X_simple, data['prediction'], 'r-', linewidth=2,
                     label=f'当前拟合 (步骤 {data["step"]})')

            # 标记已选中心
            for i, center in enumerate(data['centers']):
                ax1.axvline(x=center, color='red', linestyle='--', alpha=0.5,
                            label=f'中心 {i + 1}' if i == 0 else "")

            ax1.set_xlim(-2.2, 2.2)
            ax1.set_ylim(0, 2.5)
            ax1.set_xlabel('x')
            ax1.set_ylabel('y')
            ax1.set_title(f'OLS逐步选择 - 步骤 {data["step"]}')
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            # 右图：误差下降
            steps = [d['step'] for d in simple_ols.steps_data[:frame + 1]]
            errors = [d['error'] for d in simple_ols.steps_data[:frame + 1]]

            ax2.plot(steps, errors, 'go-', linewidth=2, markersize=8)
            ax2.set_xlabel('step')
            ax2.set_ylabel('loss^2')
            ax2.set_title('procerss')
            ax2.grid(True, alpha=0.3)
            ax2.set_yscale('log')

    # 创建动画
    anim = FuncAnimation(fig, animate, frames=len(simple_ols.steps_data) + 1,
                         interval=1000, repeat=True)

    plt.tight_layout()
    plt.show()

    return anim


if __name__ == "__main__":
    print("OLS RBF网络可视化演示")
    print("=" * 50)

    # 1. 主要可视化
    print("1. OLS RBF网络主要可视化")
    ols_net = visualize_ols_process()

    # 2. 参数比较
    print("\n2. 不同Sigma参数比较")
    results = compare_different_sigmas()

    # 3. 动画演示（可选）
    print("\n3. 生成逐步选择动画...")
    try:
        anim = ols_step_by_step_animation()
        print("动画生成完成!")
    except:
        print("动画生成遇到问题，跳过此步骤")

    print("\n演示完成!")