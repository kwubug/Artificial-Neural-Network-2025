import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BmAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BmBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.01)
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(100)
    initial_temperature = BridgeProperty(10.0)
    cooling_rate = BridgeProperty(0.95)
    equilibrium_iterations = BridgeProperty(100)
    convergence_threshold = BridgeProperty(0.01)
    current_iterations = BridgeProperty(0)
    current_temperature = BridgeProperty(0.0)
    current_energy = BridgeProperty(0.0)
    current_states = BridgeProperty([])
    current_weights = BridgeProperty([])
    current_biases = BridgeProperty([])
    is_equilibrium = BridgeProperty(False)
    has_finished = BridgeProperty(True)
    energy_history = BridgeProperty([])
    state_history = BridgeProperty([])
    temperature_history = BridgeProperty([])
    last_energy_change = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self.bm_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm_algorithm(self):
        self.bm_algorithm = ObservableBmAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=[],
            total_epoches=self.total_epoches,
            initial_temperature=self.initial_temperature,
            cooling_rate=self.cooling_rate,
            equilibrium_iterations=self.equilibrium_iterations,
            convergence_threshold=self.convergence_threshold
        )
        self.bm_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()


class ObservableBmAlgorithm(Observable, BmAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BmAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        # Notify for public runtime fields like current_iterations
        if name == 'current_iterations' and hasattr(self, '_observer'):
            super().__setattr__(name, value)
            self.notify(name, value)
            return

        # Check if this is an internal attribute update that needs notification
        needs_notification = name.startswith('_') and hasattr(self, '_observer')

        super().__setattr__(name, value)
        
        # Notify observer of important state changes
        if needs_notification:
            if name == '_temperature':
                self.notify('current_temperature', value)
                if hasattr(self, '_temperature_history') and self._temperature_history:
                    self.notify('temperature_history', 
                               [float(t) for t in self._temperature_history])
            elif name == '_energy':
                self.notify('current_energy', value)
                if hasattr(self, '_energy_history') and self._energy_history:
                    self.notify('energy_history', 
                               [float(e) for e in self._energy_history])
            elif name == '_is_equilibrium':
                self.notify('is_equilibrium', value)
            elif name == '_states':
                if value is not None:
                    self.notify('current_states', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_weights':
                if value is not None:
                    self.notify('current_weights', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_biases':
                if value is not None:
                    self.notify('current_biases', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_last_energy_change':
                self.notify('last_energy_change', float(value) if value != float('inf') else 0.0)

    def _notify_state(self):
        """Notify all current state information."""
        if hasattr(self, '_states') and self._states is not None:
            self.notify('current_states', self._states.tolist())
        if hasattr(self, '_weights') and self._weights is not None:
            self.notify('current_weights', self._weights.tolist())
        if hasattr(self, '_biases') and self._biases is not None:
            self.notify('current_biases', self._biases.tolist())
        if hasattr(self, '_energy'):
            self.notify('current_energy', float(self._energy))
        if hasattr(self, '_temperature'):
            self.notify('current_temperature', float(self._temperature))
        if hasattr(self, '_is_equilibrium'):
            self.notify('is_equilibrium', self._is_equilibrium)
        if hasattr(self, '_energy_history'):
            self.notify('energy_history', [float(e) for e in self._energy_history])
        if hasattr(self, '_state_history'):
            self.notify('state_history', 
                       [[float(s) for s in state] for state in self._state_history])
        if hasattr(self, '_temperature_history'):
            self.notify('temperature_history', 
                       [float(t) for t in self._temperature_history])
        if hasattr(self, '_last_energy_change'):
            self.notify('last_energy_change', float(self._last_energy_change))

    def run(self):
        self.notify('has_finished', False)
        self.notify('is_equilibrium', False)
        # Call parent run which handles the algorithm logic
        # But we need to notify after each iteration
        # So we override the run loop to add notifications
        self._initialize_network()
        self._notify_state()
        for iteration in range(self._total_epoches):
            if self._should_stop:
                break
            # Update iteration counter (parent run also does this, but we do it for notification)
            self.current_iterations = iteration
            # Parent's run will update temperature and call _iterate
            # But we need to ensure notification happens
            # So we manually do what parent does but with notifications
            self._temperature = max(0.1, self._initial_temperature * 
                                  (self._cooling_rate ** iteration))
            self.__setattr__('_temperature', self._temperature)
            self._iterate()
        # Final notification
        self._notify_state()
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # Notify updated state after iteration (including temperature update from parent)
        self._notify_state()
        # Sleep to keep GUI responsive
        time.sleep(self.ui_refresh_interval)

    def _check_equilibrium(self, energy_change):
        super()._check_equilibrium(energy_change)
        self.__setattr__('_last_energy_change', energy_change)
        self.__setattr__('_is_equilibrium', self._is_equilibrium)

