import numpy as np

from . import TraningAlgorithm
from ..utils import sign


class HopfieldAlgorithm(TraningAlgorithm):
    """
    离散型Hopfield神经网络算法
    
    实现功能：
    1. 异步更新：每次随机选择一个神经元进行更新
    2. 吸引子检测：检测网络收敛到的稳定状态
    3. 能量计算：计算网络当前状态的能量
    """
    def __init__(self, dataset, max_iterations=1000, convergence_threshold=0.001):
        """
        初始化Hopfield算法
        
        Args:
            dataset: 训练数据集，每行是一个记忆模式（-1或1）
            max_iterations: 最大迭代次数
            convergence_threshold: 收敛阈值，用于判断是否达到吸引子
        """
        super().__init__(dataset, total_epoches=1)  # Hopfield不需要多个epoch
        self._max_iterations = max_iterations
        self._convergence_threshold = convergence_threshold
        
        # 网络状态
        self._weights = None  # 权重矩阵（对称，对角线为0）
        self._current_state = None  # 当前网络状态
        self._initial_state = None  # 初始状态（用于测试）
        self._energy_history = []  # 能量历史
        self._state_history = []  # 状态历史
        
        # 训练/测试相关
        self.current_iterations = 0
        self.current_energy = 0.0
        self.has_converged = False
        self.attractor_state = None  # 吸引子状态
        
    def run(self):
        """运行算法：训练权重矩阵"""
        self._initialize_weights()
        self.current_iterations = 0
        self.has_converged = False
        
    def _initialize_weights(self):
        """
        使用Hebb规则初始化权重矩阵
        w_ij = (1/N) * sum_p (x_p_i * x_p_j) for i != j
        w_ii = 0 (对角线为0)
        """
        # 将数据集转换为numpy数组，确保值为-1或1
        patterns = np.array(self._dataset)
        if patterns.ndim == 1:
            patterns = patterns.reshape(1, -1)
        
        # 确保值是-1或1
        patterns = np.where(patterns >= 0, 1, -1)
        
        N = patterns.shape[1]  # 神经元数量
        
        # 初始化权重矩阵
        self._weights = np.zeros((N, N))
        
        # 使用Hebb规则计算权重
        for pattern in patterns:
            pattern = pattern.reshape(-1, 1)
            # w_ij = sum_p (x_p_i * x_p_j) / N
            self._weights += np.dot(pattern, pattern.T) / N
        
        # 对角线置为0
        np.fill_diagonal(self._weights, 0)
        
    def test_pattern(self, initial_state):
        """
        测试一个模式，进行异步更新直到收敛
        
        Args:
            initial_state: 初始状态（可以是噪声模式）
        
        Returns:
            attractor_state: 收敛到的吸引子状态
            energy_history: 能量历史
            iterations: 迭代次数
        """
        # 确保初始状态是-1或1
        self._initial_state = np.array(initial_state)
        self._initial_state = np.where(self._initial_state >= 0, 1, -1)
        self._current_state = self._initial_state.copy()
        
        self._energy_history = []
        self._state_history = [self._current_state.copy()]
        self.current_iterations = 0
        self.has_converged = False
        
        N = len(self._current_state)
        
        for iteration in range(self._max_iterations):
            self.current_iterations = iteration
            
            # 计算当前能量
            energy = self._calculate_energy(self._current_state)
            self.current_energy = energy
            self._energy_history.append(energy)
            
            # 随机选择一个神经元进行异步更新
            neuron_idx = np.random.randint(0, N)
            
            # 计算该神经元的输入
            # net_i = sum_j (w_ij * x_j)
            net_input = np.dot(self._weights[neuron_idx], self._current_state)
            
            # 更新神经元状态
            new_value = sign(net_input)
            old_value = self._current_state[neuron_idx]
            
            # 如果状态改变，更新
            if new_value != old_value:
                self._current_state[neuron_idx] = new_value
                self._state_history.append(self._current_state.copy())
            
            # 检查是否收敛（能量不再变化或状态稳定）
            if len(self._energy_history) >= 2:
                energy_change = abs(self._energy_history[-1] - self._energy_history[-2])
                if energy_change < self._convergence_threshold:
                    # 再检查几次确保稳定
                    if iteration > 10:
                        self.has_converged = True
                        break
            
            # 如果状态不再变化，说明已收敛
            if len(self._state_history) >= 2:
                if np.array_equal(self._state_history[-1], self._state_history[-2]):
                    self.has_converged = True
                    break
        
        self.attractor_state = self._current_state.copy()
        return self.attractor_state, self._energy_history, self.current_iterations
    
    def _calculate_energy(self, state):
        """
        计算网络能量
        E = -0.5 * sum_i sum_j (w_ij * x_i * x_j)
        
        Args:
            state: 网络状态
        
        Returns:
            energy: 能量值
        """
        state = np.array(state)
        # E = -0.5 * x^T * W * x
        energy = -0.5 * np.dot(state, np.dot(self._weights, state))
        return float(energy)
    
    @property
    def weights(self):
        """返回权重矩阵"""
        return self._weights
    
    @property
    def current_state(self):
        """返回当前状态"""
        return self._current_state
    
    @property
    def initial_state(self):
        """返回初始状态"""
        return self._initial_state
    
    @property
    def energy_history(self):
        """返回能量历史"""
        return self._energy_history

