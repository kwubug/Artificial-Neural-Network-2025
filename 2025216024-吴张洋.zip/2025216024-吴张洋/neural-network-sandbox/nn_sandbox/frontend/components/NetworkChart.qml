import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

ChartView {
    id: chart
    title: "网络权重可视化"
    antialiasing: true
    
    property var inputHiddenWeights: []
    property var hiddenOutputWeights: []
    property var hiddenBias: []
    property var outputBias: []
    property var hiddenOutputs: []
    property var finalOutputs: []
    
    ValueAxis {
        id: xAxis
        titleText: "权重值"
        min: -1.0
        max: 1.0
    }
    
    ValueAxis {
        id: yAxis
        titleText: "连接索引"
        min: 0
        max: 10
    }
    
    BarSeries {
        id: inputHiddenSeries
        axisX: xAxis
        axisY: yAxis
        BarSet {
            id: inputHiddenBarSet
            label: "输入-隐藏层权重"
            color: "#FF6B6B"
        }
    }
    
    BarSeries {
        id: hiddenOutputSeries
        axisX: xAxis
        axisY: yAxis
        BarSet {
            id: hiddenOutputBarSet
            label: "隐藏-输出层权重"
            color: "#4ECDC4"
        }
    }
    
    BarSeries {
        id: biasSeries
        axisX: xAxis
        axisY: yAxis
        BarSet {
            id: biasBarSet
            label: "偏置值"
            color: "#45B7D1"
        }
    }
    
    function updateNetworkWeights() {
        if (!bpBridge || !bpBridge.network_weights) return
        
        const weights = bpBridge.network_weights
        
        // 更新输入-隐藏层权重
        inputHiddenWeights = weights.input_hidden_weights || []
        inputHiddenBarSet.values = flattenWeights(inputHiddenWeights)
        
        // 更新隐藏-输出层权重
        hiddenOutputWeights = weights.hidden_output_weights || []
        hiddenOutputBarSet.values = flattenWeights(hiddenOutputWeights)
        
        // 更新偏置值
        hiddenBias = weights.hidden_bias || []
        outputBias = weights.output_bias || []
        biasBarSet.values = hiddenBias.concat(outputBias)
        
        // 更新Y轴范围
        const maxConnections = Math.max(
            inputHiddenBarSet.values.length,
            hiddenOutputBarSet.values.length,
            biasBarSet.values.length
        )
        yAxis.max = Math.max(10, maxConnections)
        
        // 更新X轴范围
        const allValues = inputHiddenBarSet.values.concat(
            hiddenOutputBarSet.values, biasBarSet.values
        )
        if (allValues.length > 0) {
            const minVal = Math.min(...allValues)
            const maxVal = Math.max(...allValues)
            xAxis.min = Math.min(-1.0, minVal - 0.1)
            xAxis.max = Math.max(1.0, maxVal + 0.1)
        }
    }
    
    function flattenWeights(weights) {
        const result = []
        for (let row of weights) {
            for (let weight of row) {
                result.push(weight)
            }
        }
        return result
    }
    
    function reset() {
        inputHiddenBarSet.values = []
        hiddenOutputBarSet.values = []
        biasBarSet.values = []
        xAxis.min = -1.0
        xAxis.max = 1.0
        yAxis.min = 0
        yAxis.max = 10
    }
    
    Component.onCompleted: reset()
}
