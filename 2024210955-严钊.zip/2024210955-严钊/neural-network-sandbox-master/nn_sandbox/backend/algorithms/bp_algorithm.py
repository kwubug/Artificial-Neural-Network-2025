from . import PredictiveAlgorithm
import numpy as np


class BpAlgorithm(PredictiveAlgorithm):
    def __init__(self, dataset, total_epoches=100, most_correct_rate=None,
                 initial_learning_rate=0.1, search_iteration_constant=1000,
                 test_ratio=0.3, hidden_neurons=4):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.hidden_neurons_count = hidden_neurons
        self.hidden_weights = None
        self.output_weights = None
        self._current_loss = 0.0
        self._initialize_weights()

    def _initialize_weights(self):
        # 输入层到隐藏层权重 (包括偏置)
        input_size = len(self.training_dataset[0]) - 1  # 减去标签
        self.hidden_weights = np.random.uniform(-1, 1, (self.hidden_neurons_count, input_size + 1))

        # 隐藏层到输出层权重 (包括偏置)
        if len(self.group_types) <= 2:
            output_size = 1  # 二分类
        else:
            output_size = len(self.group_types)  # 多分类
        self.output_weights = np.random.uniform(-1, 1, (output_size, self.hidden_neurons_count + 1))

    def _sigmoid(self, x):
        return 1 / (1 + np.exp(-np.clip(x, -250, 250)))

    def _sigmoid_derivative(self, x):
        return x * (1 - x)

    def _feed_forward(self, inputs):
        # 添加偏置项到输入
        inputs_with_bias = np.insert(inputs, 0, 1)

        # 隐藏层计算
        hidden_inputs = np.dot(self.hidden_weights, inputs_with_bias)
        hidden_outputs = self._sigmoid(hidden_inputs)
        hidden_outputs_with_bias = np.insert(hidden_outputs, 0, 1)

        # 输出层计算
        output_inputs = np.dot(self.output_weights, hidden_outputs_with_bias)
        outputs = self._sigmoid(output_inputs)

        return inputs_with_bias, hidden_outputs_with_bias, outputs

    def _iterate(self):
        data = self.current_data[:-1]
        expected = self.current_data[-1]

        # 前向传播
        inputs_with_bias, hidden_outputs_with_bias, outputs = self._feed_forward(data)

        # 计算期望输出
        if len(self.output_weights) == 1:
            # 二分类
            expected_output = np.array([1]) if expected == self.group_types[0] else np.array([0])
        else:
            # 多分类
            expected_output = np.zeros(len(self.group_types))
            expected_output[self.group_types.index(expected)] = 1

        # 计算当前损失 (均方误差)
        self._current_loss = np.mean((expected_output - outputs) ** 2)

        # 反向传播
        self._back_propagate(inputs_with_bias, hidden_outputs_with_bias, outputs, expected_output)

    def _back_propagate(self, inputs, hidden_outputs, outputs, expected):
        # 输出层误差
        output_errors = (expected - outputs) * self._sigmoid_derivative(outputs)

        # 隐藏层误差
        hidden_errors = (np.dot(self.output_weights[:, 1:].T, output_errors) *
                         self._sigmoid_derivative(hidden_outputs[1:]))

        # 更新输出层权重
        self.output_weights += self.current_learning_rate * np.outer(output_errors, hidden_outputs)

        # 更新隐藏层权重
        self.hidden_weights += self.current_learning_rate * np.outer(hidden_errors, inputs)

    def _correct_rate(self, dataset):
        correct_count = 0
        for data in dataset:
            _, _, outputs = self._feed_forward(data[:-1])

            if len(self.output_weights) == 1:
                # 二分类
                predicted = 1 if outputs[0] > 0.5 else 0
                expected = 1 if data[-1] == self.group_types[0] else 0
                if predicted == expected:
                    correct_count += 1
            else:
                # 多分类
                predicted_index = np.argmax(outputs)
                expected_index = self.group_types.index(data[-1])
                if predicted_index == expected_index:
                    correct_count += 1

        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def _initialize_neurons(self):
        # BP算法不使用单个神经元，使用权重矩阵
        pass

    def _adjust_synaptic_weights(self):
        # 权重更新在_back_propagate中处理
        pass

    @property
    def current_loss(self):
        return self._current_loss

    @property
    def current_synaptic_weights(self):
        """获取当前所有权重信息"""
        return {
            'hidden_weights': self.hidden_weights.tolist(),
            'output_weights': self.output_weights.tolist()
        }