import math
import random
import pickle
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch

# 设置中文字体显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

try:
    import cPickle as pickle
except:
    import pickle

random.seed(0)


# 计算[a, b)区间的随机数
def rand(a, b):
    return (b - a) * random.random() + a


# sigmoid激活函数（使用tanh）
def sigmoid(x):
    return math.tanh(x)


# sigmoid函数的导数（基于输出y）
def dsigmoid(y):
    return 1.0 - y ** 2


class Unit:
    def __init__(self, length):
        self.weight = [rand(-0.2, 0.2) for i in range(length)]
        self.change = [0.0] * length
        self.threshold = rand(-0.2, 0.2)
        self.sample = None
        self.output = 0.0

    def calc(self, sample):
        self.sample = sample[:]
        partsum = sum([i * j for i, j in zip(self.sample, self.weight)]) - self.threshold
        self.output = sigmoid(partsum)
        return self.output

    def update(self, diff, rate=0.5, factor=0.1):
        change = [rate * x * diff + factor * c for x, c in zip(self.sample, self.change)]
        self.weight = [w + c for w, c in zip(self.weight, change)]
        self.change = [x * diff for x in self.sample]

    def get_weight(self):
        return self.weight[:]

    def set_weight(self, weight):
        self.weight = weight[:]


class Layer:
    def __init__(self, input_length, output_length):
        self.units = [Unit(input_length) for _ in range(output_length)]
        self.output = [0.0] * output_length
        self.ilen = input_length

    def calc(self, sample):
        self.output = [unit.calc(sample) for unit in self.units]
        return self.output[:]

    def update(self, diffs, rate=0.5, factor=0.1):
        for diff, unit in zip(diffs, self.units):
            unit.update(diff, rate, factor)

    def get_error(self, deltas):
        def _error(deltas, j):
            return sum([delta * unit.weight[j] for delta, unit in zip(deltas, self.units)])

        return [_error(deltas, j) for j in range(self.ilen)]

    def get_weights(self):
        weights = {}
        for key, unit in enumerate(self.units):
            weights[key] = unit.get_weight()
        return weights

    def set_weights(self, weights):
        for key, unit in enumerate(self.units):
            unit.set_weight(weights[key])


class BPNNet:
    def __init__(self, ni, nh, no):
        # 输入层、隐藏层、输出层节点数（+1为偏置节点）
        self.ni = ni + 1  # +1 for bias node
        self.nh = nh
        self.no = no
        self.hlayer = Layer(self.ni, self.nh)
        self.olayer = Layer(self.nh, self.no)
        self.train_errors = []  # 用于记录训练误差

    def calc(self, inputs):
        if len(inputs) != self.ni - 1:
            raise ValueError('输入数量错误')

        # 输入激活值（添加偏置节点）
        self.ai = inputs[:] + [1.0]

        # 隐藏层激活值
        self.ah = self.hlayer.calc(self.ai)
        # 输出层激活值
        self.ao = self.olayer.calc(self.ah)

        return self.ao[:]

    def update(self, targets, rate, factor):
        if len(targets) != self.no:
            raise ValueError('目标值数量错误')

        # 计算输出层误差项
        output_deltas = [dsigmoid(ao) * (target - ao) for target, ao in zip(targets, self.ao)]

        # 计算隐藏层误差项
        hidden_deltas = [dsigmoid(ah) * error for ah, error in zip(self.ah, self.olayer.get_error(output_deltas))]

        # 更新输出层权重
        self.olayer.update(output_deltas, rate, factor)

        # 更新隐藏层权重
        self.hlayer.update(hidden_deltas, rate, factor)

        # 计算误差
        return sum([0.5 * (t - o) ** 2 for t, o in zip(targets, self.ao)])

    def test(self, patterns):
        results = []
        for p in patterns:
            pred = self.calc(p[0])
            results.append((p[0], p[1], pred))
            print(f"输入: {p[0]}, 预期输出: {p[1]}, 实际输出: {[round(x, 4) for x in pred]}")
        return results

    def train(self, patterns, iterations=1000, N=0.5, M=0.1):
        # N: 学习率, M: 动量因子
        self.train_errors = []  # 重置误差记录
        for i in range(iterations):
            error = 0.0
            for p in patterns:
                inputs = p[0]
                targets = p[1]
                self.calc(inputs)
                error += self.update(targets, N, M)
            if i % 100 == 0:
                print(f'迭代次数 {i}, 误差 {error:.10f}')
                self.train_errors.append((i, error))  # 记录误差
        return self.train_errors

    def save_weights(self, fn):
        weights = {
            "olayer": self.olayer.get_weights(),
            "hlayer": self.hlayer.get_weights()
        }
        with open(fn, "wb") as f:
            pickle.dump(weights, f)

    def load_weights(self, fn):
        with open(fn, "rb") as f:
            weights = pickle.load(f)
            self.olayer.set_weights(weights["olayer"])
            self.hlayer.set_weights(weights["hlayer"])


# 可视化网络结构
def visualize_network(net, figsize=(10, 6)):
    fig, ax = plt.subplots(figsize=figsize)

    # 层位置设置
    layers = [
        {'name': '输入层', 'size': net.ni, 'y': 0.8},
        {'name': '隐藏层', 'size': net.nh, 'y': 0.5},
        {'name': '输出层', 'size': net.no, 'y': 0.2}
    ]

    # 绘制神经元
    neurons = []
    for layer in layers:
        layer_neurons = []
        x_positions = np.linspace(0.2, 0.8, layer['size'])
        for x in x_positions:
            circle = Circle((x, layer['y']), 0.05, color='lightblue', ec='black', zorder=3)
            ax.add_patch(circle)
            layer_neurons.append((x, layer['y']))
        neurons.append(layer_neurons)

    # 绘制连接（权重用线的粗细表示）
    # 输入层到隐藏层
    for i, (x1, y1) in enumerate(neurons[0]):
        for j, (x2, y2) in enumerate(neurons[1]):
            weight = net.hlayer.units[j].weight[i]
            width = abs(weight) * 5  # 权重可视化缩放
            color = 'red' if weight > 0 else 'blue'
            arrow = FancyArrowPatch(
                (x1, y1), (x2, y2),
                arrowstyle='-', linewidth=width,
                color=color, alpha=0.6, zorder=2
            )
            ax.add_patch(arrow)

    # 隐藏层到输出层
    for i, (x1, y1) in enumerate(neurons[1]):
        for j, (x2, y2) in enumerate(neurons[2]):
            weight = net.olayer.units[j].weight[i]
            width = abs(weight) * 5  # 权重可视化缩放
            color = 'red' if weight > 0 else 'blue'
            arrow = FancyArrowPatch(
                (x1, y1), (x2, y2),
                arrowstyle='-', linewidth=width,
                color=color, alpha=0.6, zorder=2
            )
            ax.add_patch(arrow)

    # 添加层标签
    for layer in layers:
        ax.text(0.05, layer['y'], layer['name'], fontsize=12, verticalalignment='center')

    # 添加神经元标签
    for i, (x, y) in enumerate(neurons[0]):
        label = '偏置' if i == net.ni - 1 else f'输入{i + 1}'
        ax.text(x, y - 0.08, label, ha='center', fontsize=10)

    for i, (x, y) in enumerate(neurons[1]):
        ax.text(x, y - 0.08, f'隐藏{i + 1}', ha='center', fontsize=10)

    for i, (x, y) in enumerate(neurons[2]):
        ax.text(x, y - 0.08, f'输出{i + 1}', ha='center', fontsize=10)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis('off')
    plt.title('BP神经网络结构可视化（红色为正权重，蓝色为负权重，线宽表示权重大小）')
    plt.tight_layout()
    return fig


# 可视化训练误差
def visualize_training_error(errors, figsize=(10, 6)):
    plt.figure(figsize=figsize)
    iterations, errors = zip(*errors)
    plt.plot(iterations, errors, 'b-', linewidth=2)
    plt.xlabel('迭代次数')
    plt.ylabel('总误差')
    plt.title('训练过程误差变化')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    return plt.gcf()


# 可视化XOR问题的决策边界
def visualize_decision_boundary(net, figsize=(8, 8)):
    # 生成网格数据
    x_min, x_max = -0.5, 1.5
    y_min, y_max = -0.5, 1.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                         np.linspace(y_min, y_max, 100))

    # 预测网格点
    Z = []
    for x, y in zip(xx.ravel(), yy.ravel()):
        Z.append(net.calc([x, y])[0])
    Z = np.array(Z).reshape(xx.shape)

    # 绘制决策边界
    plt.figure(figsize=figsize)
    plt.contourf(xx, yy, Z, alpha=0.8, cmap=plt.cm.RdBu)
    plt.colorbar(label='预测输出值')

    # 绘制训练数据点
    xor_points = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    xor_labels = np.array([0, 1, 1, 0])
    plt.scatter(xor_points[:, 0], xor_points[:, 1], c=xor_labels,
                edgecolors='black', s=100, cmap=plt.cm.RdBu)

    plt.xlabel('输入1')
    plt.ylabel('输入2')
    plt.title('XOR问题的决策边界')
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    return plt.gcf()


def demo():
    # XOR问题的训练数据
    pat = [
        [[0, 0], [0]],
        [[0, 1], [1]],
        [[1, 0], [1]],
        [[1, 1], [0]]
    ]

    # 创建神经网络：2输入，2隐藏，1输出
    n = BPNNet(2, 2, 1)

    # 训练网络
    print("开始训练XOR神经网络...")
    errors = n.train(pat, iterations=10000, N=0.3, M=0.1)
    n.save_weights("demo.weights")

    # 测试网络
    print("\n测试结果：")
    n.test(pat)

    # 可视化
    print("\n生成可视化结果...")
    visualize_network(n)
    visualize_training_error(errors)
    visualize_decision_boundary(n)

    plt.show()


if __name__ == '__main__':
    demo()