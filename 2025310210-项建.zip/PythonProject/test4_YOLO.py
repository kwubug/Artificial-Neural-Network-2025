from ultralytics import YOLO
import cv2
import matplotlib.pyplot as plt
import numpy as np

def detect_specific_image():
    """Detect objects in the specified image"""
    # Specify the image path
    image_path = r"G:\ZA\YOLO\1.jpg"

    print("YOLO Object Detection")
    print("=" * 40)
    print(f"Detecting image: {image_path}")

    try:
        # Load the model
        model = YOLO('yolov8n.pt')
        print("✅ Model loaded successfully")

        # Read and display image info
        image = cv2.imread(image_path)
        if image is None:
            raise FileNotFoundError(f"Unable to read image: {image_path}")

        height, width = image.shape[:2]
        print(f"Image size: {width} x {height}")

        # Perform object detection
        print("🔍 Performing object detection...")
        results = model(image, conf=0.25)
        result = results[0]

        # Display the detection results
        display_detection_results(result, image_path)

    except Exception as e:
        print(f"❌ Error: {e}")
        print("Please check the image path and ensure the file is valid")


def display_detection_results(result, image_path):
    """Display detection results"""
    # Draw bounding boxes
    plotted_image = result.plot()

    # Convert BGR to RGB
    plotted_image_rgb = cv2.cvtColor(plotted_image, cv2.COLOR_BGR2RGB)

    # Display the image
    plt.figure(figsize=(12, 8))
    plt.imshow(plotted_image_rgb)
    plt.title(f'YOLO Object Detection Result\n{image_path}', fontsize=16, fontweight='bold')
    plt.axis('off')

    # Display detection statistics
    boxes = result.boxes
    if len(boxes) > 0:
        print(f"\nDetected {len(boxes)} objects:")
        print("=" * 60)

        # Sort by confidence
        detections = []
        for box in boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            cls_name = result.names[cls_id]
            bbox = box.xyxy[0].cpu().numpy()
            detections.append((cls_name, conf, bbox))

        # Sort detections by confidence (descending order)
        detections.sort(key=lambda x: x[1], reverse=True)

        for i, (cls_name, conf, bbox) in enumerate(detections):
            print(
                f"{i + 1:2d}. {cls_name:15s} | Confidence: {conf:.3f} | Location: [{bbox[0]:.0f}, {bbox[1]:.0f}, {bbox[2]:.0f}, {bbox[3]:.0f}]")

        # Display category statistics
        print("\nCategory statistics:")
        class_count = {}
        for cls_name, conf, bbox in detections:
            class_count[cls_name] = class_count.get(cls_name, 0) + 1

        for cls_name, count in class_count.items():
            print(f"   {cls_name:15s}: {count} objects")

    else:
        print("❌ No objects detected")
        print("Tip: Try lowering the confidence threshold or check the image content")

    plt.tight_layout()
    plt.show()


# Run detection
if __name__ == "__main__":
    detect_specific_image()
