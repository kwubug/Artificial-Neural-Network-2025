import PyQt5.QtCore

from .bridge import Bridge, BridgeProperty
from .perceptron_bridge import PerceptronBridge
from .mlp_bridge import MlpBridge
from .ADAline_bridge import ADAlineBridge
from .rbfn_bridge import RbfnBridge
from .som_bridge import SomBridge
from .BPnetwork_bridge import BPnetworkBridge
from .DHNN_bridge import DHNNBridge
from .advanced_bridge import AdvancedBridge

