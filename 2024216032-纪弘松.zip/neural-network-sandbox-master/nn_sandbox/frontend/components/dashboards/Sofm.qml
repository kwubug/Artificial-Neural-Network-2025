import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import '..'
Page {
    id: sofmPage
    name: 'SOFM'

    property var weights: SOFM.weightsList
    property var classification: SOFM.classification
    property int classification1: SOFM.classification1
    property int classification2: SOFM.classification2

    ColumnLayout {



        // 输入样本
        GroupBox {
            title: "Input Sample"
            Layout.fillWidth: true
            RowLayout {
                spacing: 10
                TextField {
                    id: inputSample
                    width: 250
                    placeholderText: "Enter sample (e.g., 0.1, 0.4)"
                }
                Button {
                    text: "Classify Sample"
                    onClicked: {
                        var sample = inputSample.text.split(",").map(parseFloat);
                        if (sample.length === 2) {
                            SOFM.classifySample(sample);
                        } else {
                            console.log("Invalid input sample size. Must be 2 elements.");
                        }
                    }
                }
            }
        }

        // 显示训练按钮
        Button {
            text: "Train Network"
            onClicked: {
                var data = [[0.1, 0.4, 1.3, 1.2, 1.9, 1.8, 0.2, 0.4, 1.3, 1.2],
                            [0.3, 0.2, 0.4, 0.2, 1.9, 1.9, 1.8, 1.8, 1.7, 1.9]];
                SOFM.trainNetwork(data, 100);
            }
        }

        // 显示权重
        GroupBox {
            title: "Neuron Weights"
            Layout.fillWidth: true
            Layout.fillHeight:true

            ListView {
                id: weightsView
                width: parent.width
                height: 150
                model: weights
                delegate: Text {
                text: "Neuron [" + index + "]: " + modelData.join(", ")
                }
            }
        }


        // 显示分类结果
        GroupBox {
            title: "Classification Result"
            Layout.fillWidth: true
            Label {
                id: classifyResult
                text: "BMU Index: (" + SOFM.classification1 + ", " + SOFM.classification2 + ")"
                Layout.alignment: Qt.AlignHCenter
            }
        }
    }
}