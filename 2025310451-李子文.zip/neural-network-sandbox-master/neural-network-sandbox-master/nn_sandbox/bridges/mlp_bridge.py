# -*- coding: utf-8 -*-
"""
桥接层：把后端 MlpAlgorithm 的属性与操作暴露到 QML，并按“迭代（iteration）”推送收敛曲线。

变化点（相对上一版）：
- 曲线 X 轴为「迭代次数」：在训练中“每完成若干个样本更新”就追加一个点（iteration += 1）。
- 兼容不同基类字段命名：dataset/_dataset、test_ratio/_test_ratio、total_epoches/_total_epoches。
- 未选数据集时自动选择第一个；训练可中断；关键属性变化会 notify 到前端。
"""

import time
import PyQt5.QtCore
import numpy as np

from nn_sandbox.backend.algorithms import MlpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class MlpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)

    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')

    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    momentum_weight = BridgeProperty(0.5)
    test_ratio = BridgeProperty(0.3)

    # 单隐藏层宽度（以列表承载，取首元素）
    network_shape = BridgeProperty([5])

    # 激活函数
    activation = BridgeProperty('unipolar')  # 'unipolar' | 'bipolar'

    # 训练状态
    has_finished = BridgeProperty(True)

    # —— 收敛曲线属性（QML 监听这些来画图） ——
    iteration = BridgeProperty(0)                    # 当前迭代（每次样本更新 +1）
    training_correct_rate = BridgeProperty(0.0)      # 训练集正确率
    test_correct_rate = BridgeProperty(0.0)          # 测试集正确率
    best_training_correct_rate = BridgeProperty(0.0) # 历史最好训练正确率

    mlp_algorithm = None

    @property
    def _most_correct_rate(self):
        return self.most_correct_rate if self.most_correct_rate_checkbox else None

    @PyQt5.QtCore.pyqtSlot()
    def start_mlp_algorithm(self):
        """创建并启动算法（自动兜底选择一个数据集），并重置曲线。"""
        if not self.dataset_dict:
            print('[MLP] dataset_dict is empty.')
            return

        # 若未选择数据集，则默认取第一个
        if (not self.current_dataset_name) or (self.current_dataset_name not in self.dataset_dict):
            self.current_dataset_name = next(iter(self.dataset_dict.keys()))
            print(f"[MLP] auto-select dataset: {self.current_dataset_name}")

        # 重置曲线
        self.iteration = 0
        self.training_correct_rate = 0.0
        self.test_correct_rate = 0.0
        self.best_training_correct_rate = 0.0

        # 实例化可观察算法
        self.mlp_algorithm = ObservableMlpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            momentum_weight=self.momentum_weight,
            test_ratio=self.test_ratio,
            network_shape=self.network_shape,
            activation=self.activation,
        )
        # 使用父类线程式 start（在 Observable 里实现），避免阻塞 UI
        self.mlp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_mlp_algorithm(self):
        if self.mlp_algorithm:
            try:
                self.mlp_algorithm.stop()
            except Exception:
                # 兜底：若基类无 stop()，用标志位中断
                setattr(self.mlp_algorithm, '_interrupted', True)

    @PyQt5.QtCore.pyqtSlot()
    def reset_weights(self):
        if self.mlp_algorithm:
            self.mlp_algorithm.reset_weights()


class ObservableMlpAlgorithm(Observable, MlpAlgorithm):
    """将 MlpAlgorithm 的关键信息周期性通知到 UI，并按「迭代」推送收敛曲线。"""

    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        MlpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    # 满足抽象接口要求，并把关键属性变更通知到 UI
    def __setattr__(self, name, value):
        object.__setattr__(self, name, value)
        try:
            if name in (
                'has_finished',
                'iteration',
                'training_correct_rate',
                'test_correct_rate',
                'best_training_correct_rate',
                'ui_refresh_interval',
                'training_dataset',
                'testing_dataset',
            ):
                self.notify(name, value)
        except Exception:
            pass

    def run(self):
        """按 epoch × 样本 的粒度训练：每次样本更新记一次 iteration，并定期推送曲线点。"""
        # —— 数据集：优先 self.dataset；否则 self._dataset ——
        ds = getattr(self, 'dataset', None)
        if ds is None:
            ds = getattr(self, '_dataset', None)
        if ds is None:
            print('[MLP] No dataset found on algorithm (dataset/_dataset is None).')
            self.has_finished = True
            return

        data = np.asarray(ds, dtype=float)
        rng = np.random.default_rng(2024)
        idx = rng.permutation(data.shape[0])
        data = data[idx]

        # —— 测试比例 ——（test_ratio -> _test_ratio -> 默认 0.3）
        ratio = getattr(self, 'test_ratio', None)
        if ratio is None:
            ratio = getattr(self, '_test_ratio', 0.3)
        try:
            ratio = float(ratio)
        except Exception:
            ratio = 0.3
        ratio = min(max(ratio, 0.0), 0.95)  # clamp

        # 切分并回写（使前端需要时可读）
        split = max(1, int(round(data.shape[0] * (1.0 - ratio))))
        train = data[:split]
        test  = data[split:] if split < data.shape[0] else data[:0]
        self.training_dataset = train
        self.testing_dataset  = test

        # —— 初始化 ——
        self.has_finished = False
        self.iteration = 0
        best_train = 0.0

        # —— 轮数 ——（total_epoches -> _total_epoches -> 默认 10）
        total_epochs = getattr(self, 'total_epoches', None)
        if total_epochs is None:
            total_epochs = getattr(self, '_total_epoches', 10)
        try:
            total_epochs = int(total_epochs)
        except Exception:
            total_epochs = 10
        if total_epochs <= 0:
            total_epochs = 1

        # —— 迭代点抽样频率（每个 epoch 画多少点）：自适应为 ~20 个点/epoch ——
        # （点太密 UI 会卡；数据量很小时自动退回每步都画）
        per_epoch_points = 20
        step_every = max(1, len(train) // per_epoch_points)

        # —— 训练循环：epoch × 样本 ——
        for epoch in range(total_epochs):
            if getattr(self, '_interrupted', False):
                break

            # 每个 epoch 开始时打乱训练集，提升泛化
            perm = rng.permutation(len(train))
            train = train[perm]
            self.training_dataset = train  # 如需在 UI 上查看

            for i, sample in enumerate(train):
                if getattr(self, '_interrupted', False):
                    break

                # ---- 一次「样本级」BP 更新（一次迭代）----
                x = np.asarray(sample[:-1], dtype=float)
                expect = float(self._normalize(sample[-1]))  # 与原实现保持一致（先规约到 [0,1]）
                y = self._feed_forward(x)
                deltas = self._pass_backward(expect, y)
                self._adjust_synaptic_weights(deltas)

                # 迭代计数 +1
                self.iteration = self.iteration + 1

                # 按频率采样并推送一次曲线点
                is_last_step = (epoch == total_epochs - 1) and (i == len(train) - 1)
                if (self.iteration % step_every == 0) or is_last_step:
                    train_cr = self._correct_rate(train) if len(train) else 0.0
                    test_cr  = self._correct_rate(test)  if len(test)  else 0.0
                    best_train = max(best_train, train_cr)

                    self.training_correct_rate = float(train_cr)
                    self.test_correct_rate = float(test_cr)
                    self.best_training_correct_rate = float(best_train)

                    if self.ui_refresh_interval and self.ui_refresh_interval > 0:
                        time.sleep(self.ui_refresh_interval)

        # —— 结束 ——
        self.has_finished = True
