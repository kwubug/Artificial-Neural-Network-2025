import time
import threading
import numpy as np

from . import TraningAlgorithm
from ..utils import sigmoid


class BMAlgorithm(TraningAlgorithm):
    """
    三神经元玻尔兹曼机（对称权重、0/1状态），异步Gibbs抽样 + 退火直到近似热平衡（稳定状态或达到最低温/最大迭代）。
    """

    def __init__(
        self,
        weights,
        biases,
        initial_state=None,
        initial_temperature=2.0,
        min_temperature=0.05,
        cooling_rate=0.99,
        max_iterations=5000,
        ui_refresh_interval=0.0,
    ):
        # 父类接口需要dataset/epoch，但BM不使用，这里给出占位
        super().__init__(dataset=[], total_epoches=1)
        self._weights = np.array(weights, dtype=float)  # 3x3，对称，diag为0
        self._biases = np.array(biases, dtype=float)    # 3
        self._state = (
            np.array(initial_state, dtype=int) if initial_state is not None else np.random.randint(0, 2, size=3)
        )
        self._temperature = float(initial_temperature)
        self._min_temperature = float(min_temperature)
        self._cooling_rate = float(cooling_rate)
        self._max_iterations = int(max_iterations)
        self._ui_refresh_interval = float(ui_refresh_interval)

        self.current_iterations = 0
        self.current_energy = self._energy(self._state)
        self.equilibrium_state = None
        self.has_finished = True

        # 用于“稳定判定”的缓冲：最近若干步状态相同则视为稳定
        self._stable_count = 0
        self._stable_threshold = 50
        self._last_state_snapshot = self._state.copy()

        # 保障对外读取的线程安全
        self._lock = threading.Lock()

    # 玻尔兹曼能量（0/1版）：E(v) = - sum_{i<j} w_ij v_i v_j - sum_i b_i v_i
    def _energy(self, state):
        w_term = 0.0
        for i in range(3):
            for j in range(i + 1, 3):
                w_term += self._weights[i, j] * state[i] * state[j]
        b_term = np.dot(self._biases, state)
        return -(w_term + b_term)

    # 条件激活概率（Gibbs）：P(v_i=1 | v_{-i}) = sigmoid((sum_j w_ij v_j + b_i)/T)
    def _conditional_prob_one(self, i, state):
        total_input = np.dot(self._weights[i], state) + self._biases[i]
        if self._temperature <= 0:
            return 1.0 if total_input > 0 else 0.0
        return sigmoid(total_input / self._temperature)

    def run(self):
        with self._lock:
            self.has_finished = False
        for self.current_iterations in range(self._max_iterations):
            if self._should_stop:
                break

            # 异步随机挑一个神经元进行采样更新
            i = np.random.randint(0, 3)
            with self._lock:
                prob = self._conditional_prob_one(i, self._state)
                self._state[i] = 1 if np.random.rand() < prob else 0
                self.current_energy = self._energy(self._state)

                # 稳定性检测：若状态长时间未改变，认为达到热平衡近似
                if np.array_equal(self._state, self._last_state_snapshot):
                    self._stable_count += 1
                else:
                    self._stable_count = 0
                    self._last_state_snapshot = self._state.copy()

                if self._stable_count >= self._stable_threshold:
                    self.equilibrium_state = self._state.copy()
                    break

            # 退火
            self._temperature = max(self._min_temperature, self._temperature * self._cooling_rate)

            # UI节流
            if self._ui_refresh_interval > 0:
                remaining = self._ui_refresh_interval
                # 分片睡眠，提升停止响应
                while remaining > 0 and not self._should_stop:
                    step = 0.01 if remaining > 0.01 else remaining
                    time.sleep(step)
                    remaining -= step
            else:
                if (self.current_iterations + 1) % 200 == 0:
                    time.sleep(0)

        # 若未因稳定提前退出，则以最后状态作为近似热平衡
        with self._lock:
            if self.equilibrium_state is None:
                self.equilibrium_state = self._state.copy()
            self.has_finished = True

    # 以下属性用于桥接侧读取
    @property
    def state(self):
        with self._lock:
            return self._state.copy()

    @property
    def temperature(self):
        return self._temperature

    @property
    def weights(self):
        return self._weights.copy()

    @property
    def biases(self):
        return self._biases.copy()


