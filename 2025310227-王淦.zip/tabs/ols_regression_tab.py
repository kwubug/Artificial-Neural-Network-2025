import numpy as np
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QDoubleSpinBox, QFormLayout)
from PySide6.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class OLSRegressionTab(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 控制面板
        control_group = QGroupBox("OLS回归参数设置")
        control_layout = QFormLayout()

        self.sample_spin = QSpinBox()
        self.sample_spin.setRange(10, 1000)
        self.sample_spin.setValue(100)

        self.noise_spin = QDoubleSpinBox()
        self.noise_spin.setRange(0.1, 10.0)
        self.noise_spin.setValue(1.0)
        self.noise_spin.setSingleStep(0.1)

        control_layout.addRow("样本数量:", self.sample_spin)
        control_layout.addRow("噪声水平:", self.noise_spin)

        control_group.setLayout(control_layout)

        # 按钮
        self.run_button = QPushButton("运行OLS回归")
        self.run_button.clicked.connect(self.run_ols)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(10, 8)))

        # 布局
        layout.addWidget(control_group)
        layout.addWidget(self.run_button)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def run_ols(self):
        try:
            # 生成模拟数据
            np.random.seed(42)
            n_samples = self.sample_spin.value()
            noise_level = self.noise_spin.value()

            x = np.linspace(0, 10, n_samples)
            y_true = 2 * x + 5
            y = y_true + np.random.normal(0, noise_level, n_samples)

            # 构造设计矩阵X（包含截距项）
            X = np.column_stack((np.ones_like(x), x))

            # 求解OLS参数：β = (X^T X)^(-1) X^T y
            beta = np.linalg.inv(X.T @ X) @ X.T @ y
            y_pred = X @ beta

            # 计算残差
            residuals = y - y_pred

            # 清空画布
            self.canvas.figure.clear()

            # 创建子图
            ax1 = self.canvas.figure.add_subplot(211)
            ax2 = self.canvas.figure.add_subplot(212)

            # 绘制数据与拟合直线
            ax1.scatter(x, y, label='观测数据', color='blue', alpha=0.6)
            ax1.plot(x, y_true, label='真实模型', color='red', linestyle='--', linewidth=2)
            ax1.plot(x, y_pred, label='OLS拟合', color='green', linewidth=2)
            ax1.set_xlabel('自变量x')
            ax1.set_ylabel('因变量y')
            ax1.set_title('OLS线性回归拟合效果')
            ax1.legend()
            ax1.grid(True, alpha=0.3)

            # 绘制残差
            ax2.scatter(x, residuals, label='残差', color='orange', alpha=0.6)
            ax2.axhline(y=0, color='black', linestyle='--', label='残差为0')
            ax2.set_xlabel('自变量x')
            ax2.set_ylabel('残差')
            ax2.set_title('OLS残差分布')
            ax2.legend()
            ax2.grid(True, alpha=0.3)

            self.canvas.figure.tight_layout()
            self.canvas.draw()

            print(f"OLS参数: 截距={beta[0]:.3f}, 斜率={beta[1]:.3f}")

        except Exception as e:
            print(f"OLS回归错误: {e}")