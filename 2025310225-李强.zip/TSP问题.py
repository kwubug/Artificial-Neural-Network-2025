import sys
import random
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QPushButton, QLabel, QSpinBox, QGroupBox)
from PyQt5.QtGui import QPainter, QPen, QColor, QFont, QPolygonF
from PyQt5.QtCore import Qt, QRectF, QPointF


class FastHopfieldTSP:
    def __init__(self, cities):
        self.cities = cities
        self.num_cities = len(cities)
        self.distances = self._calculate_distances()

        self.A = 500
        self.B = 500
        self.C = 200
        self.D = 500
        self.u0 = 0.02
        self.step = 0.000001
        self.max_iter = 50000

    def _calculate_distances(self):
        distances = np.zeros((self.num_cities, self.num_cities))
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                dx = self.cities[i][0] - self.cities[j][0]
                dy = self.cities[i][1] - self.cities[j][1]
                distances[i][j] = np.sqrt(dx * dx + dy * dy)
        return distances

    def solve(self):
        n = self.num_cities
        V = np.random.rand(n, n)

        dist_T = self.distances.T

        for _ in range(self.max_iter):
            # 向量化计算能量函数的四项
            A_term = self.A * (np.sum(V, axis=0) - 1)
            B_term = self.B * (np.sum(V, axis=1) - 1)

            C_term = self.C * np.roll(V, -1, axis=1)

            D_term = self.D * np.dot(self.distances, np.roll(V, -1, axis=0))

            dU = -A_term[:, None] - B_term[:, None] - C_term - D_term
            U = -dU * self.step
            V = (1 + np.tanh(U / self.u0)) / 2

        # 计算总距离
        path = self._decode_path(V)
        total_distance = self._calculate_path_distance(path)

        return path, total_distance

    def _decode_path(self, V):
        path = []
        visited = set()
        current = np.argmax(V[:, 0])  # 从第一列开始

        for _ in range(self.num_cities):
            path.append(current)
            visited.add(current)
            row = V[current, :]
            row[list(visited)] = -1
            current = np.argmax(row)

        return path

    def _calculate_path_distance(self, path):
        total = 0
        for i in range(len(path)):
            x = path[i]
            y = path[(i + 1) % len(path)]
            total += self.distances[x][y]
        return total


class TSPVisualizer(QWidget):
    def __init__(self):
        super().__init__()
        self.cities = []
        self.path = []
        self.distance = 0
        self.city_point_size = 12
        self.setMinimumSize(700, 600)

    def set_cities(self, cities):
        self.cities = cities

    def set_path(self, path, distance):
        self.path = path
        self.distance = distance
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(event.rect(), Qt.white)

        if not self.cities:
            return

        # 计算缩放和偏移
        min_x = min(city[0] for city in self.cities)
        max_x = max(city[0] for city in self.cities)
        min_y = min(city[1] for city in self.cities)
        max_y = max(city[1] for city in self.cities)

        scale_x = (self.width() - 150) / (max_x - min_x) if max_x != min_x else 1
        scale_y = (self.height() - 150) / (max_y - min_y) if max_y != min_y else 1
        scale = min(scale_x, scale_y)

        offset_x = (self.width() - (max_x - min_x) * scale) / 2 - min_x * scale
        offset_y = (self.height() - (max_y - min_y) * scale) / 2 - min_y * scale

        # 绘制地图背景区域
        map_rect = QRectF(
            offset_x + min_x * scale - 10,
            offset_y + min_y * scale - 10,
            (max_x - min_x) * scale + 20,
            (max_y - min_y) * scale + 20
        )
        painter.setPen(QPen(QColor(220, 220, 220), 1))
        painter.setBrush(QColor(255, 255, 255))
        painter.drawRect(map_rect)

        # 绘制路径
        if self.path:
            path_pen = QPen(QColor(0, 120, 215), 3)
            path_pen.setStyle(Qt.SolidLine)
            path_pen.setCapStyle(Qt.RoundCap)
            painter.setPen(path_pen)

            for i in range(len(self.path)):
                x1, y1 = self.cities[self.path[i]]
                x2, y2 = self.cities[self.path[(i + 1) % len(self.path)]]

                x1 = x1 * scale + offset_x
                y1 = y1 * scale + offset_y
                x2 = x2 * scale + offset_x
                y2 = y2 * scale + offset_y

                painter.drawLine(x1, y1, x2, y2)

                # 标记起始点
                if i == 0:
                    painter.setBrush(QColor(255, 215, 0))
                    painter.drawEllipse(QPointF(x1, y1), 10, 10)
                    # 添加"Start"文字标记
                    font = QFont()
                    font.setPointSize(10)
                    font.setBold(True)
                    painter.setFont(font)
                    painter.setPen(QPen(QColor(0, 0, 0), 1))
                    painter.drawText(QRectF(x1 - 20, y1 - 35, 40, 20),
                                     Qt.AlignCenter, "Start")

                # 绘制箭头
                arrow_size = 12
                angle = np.arctan2(y2 - y1, x2 - x1)

                arrow_p1 = QPointF(
                    x2 - arrow_size * np.cos(angle - np.pi / 6),
                    y2 - arrow_size * np.sin(angle - np.pi / 6)
                )
                arrow_p2 = QPointF(
                    x2 - arrow_size * np.cos(angle + np.pi / 6),
                    y2 - arrow_size * np.sin(angle + np.pi / 6)
                )

                arrow = QPolygonF()
                arrow.append(QPointF(x2, y2))
                arrow.append(arrow_p1)
                arrow.append(arrow_p2)

                painter.setBrush(QColor(0, 120, 215))
                painter.drawPolygon(arrow)

        # 绘制城市点（统一大小的红色圆点）
        city_pen = QPen(QColor(255, 0, 0), self.city_point_size)
        city_pen.setCapStyle(Qt.RoundCap)
        painter.setPen(city_pen)

        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        painter.setFont(font)

        for i, (x, y) in enumerate(self.cities):
            px = x * scale + offset_x
            py = y * scale + offset_y

            painter.drawPoint(px, py)

            painter.setPen(QPen(QColor(0, 0, 0), 1))
            painter.drawText(QRectF(px - 15, py - 25, 30, 30),
                             Qt.AlignCenter, str(i))
            painter.setPen(city_pen)

        # 显示信息面板
        if self.path:
            info_rect = QRectF(15, 15, 250, 80)
            painter.setPen(QPen(QColor(100, 100, 100), 1))
            painter.setBrush(QColor(255, 255, 255, 220))
            painter.drawRoundedRect(info_rect, 8, 8)

            # 信息文本
            font = QFont()
            font.setPointSize(11)
            font.setBold(True)
            painter.setFont(font)
            painter.setPen(QPen(QColor(0, 0, 0), 1))

            painter.drawText(QRectF(20, 20, 240, 25),
                             Qt.AlignLeft, f"城市数量: {len(self.cities)}")
            painter.drawText(QRectF(20, 45, 240, 25),
                             Qt.AlignLeft, f"路径长度: {self.distance:.2f}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('快速Hopfield神经网络TSP求解器')
        self.setGeometry(100, 100, 1000, 700)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # 可视化
        self.visualizer = TSPVisualizer()
        main_layout.addWidget(self.visualizer, stretch=4)

        # 控制面板
        control_panel = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_panel)
        control_layout.setAlignment(Qt.AlignTop)

        # 城市数量设置
        city_group = QGroupBox("城市设置")
        city_layout = QVBoxLayout(city_group)

        city_label = QLabel("城市数量:")
        self.city_spin = QSpinBox()
        self.city_spin.setRange(3, 15)
        self.city_spin.setValue(8)

        self.generate_btn = QPushButton("生成随机城市")
        self.generate_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        self.generate_btn.clicked.connect(self.generate_cities)

        city_layout.addWidget(city_label)
        city_layout.addWidget(self.city_spin)
        city_layout.addWidget(self.generate_btn)
        city_group.setLayout(city_layout)

        # 求解按钮
        self.solve_btn = QPushButton("快速求解TSP")
        self.solve_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0b7dda;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.solve_btn.clicked.connect(self.solve_tsp)

        # 信息显示
        info_group = QGroupBox("求解信息")
        info_layout = QVBoxLayout(info_group)

        self.info_label = QLabel("欢迎使用快速TSP求解器\n请先生成城市分布")
        self.info_label.setStyleSheet("font-size: 12px;")
        self.info_label.setWordWrap(True)

        info_layout.addWidget(self.info_label)
        info_group.setLayout(info_layout)

        # 添加到控制面板
        control_layout.addWidget(city_group)
        control_layout.addWidget(self.solve_btn)
        control_layout.addWidget(info_group)
        control_layout.addStretch()

        main_layout.addWidget(control_panel, stretch=1)
        self.generate_cities()

    def generate_cities(self):
        num_cities = self.city_spin.value()
        self.cities = [(random.uniform(0, 100), random.uniform(0, 100))
                       for _ in range(num_cities)]
        self.visualizer.set_cities(self.cities)
        self.visualizer.set_path([], 0)
        self.info_label.setText(f"已生成 {num_cities} 个随机城市\n点击'快速求解TSP'按钮开始计算")

    def solve_tsp(self):
        if not self.cities:
            return

        self.solve_btn.setEnabled(False)
        self.solve_btn.setText("计算中...")
        self.info_label.setText("正在快速计算最优路径...\n请稍候...")
        QApplication.processEvents()

        try:
            hopfield = FastHopfieldTSP(self.cities)
            path, distance = hopfield.solve()
            self.visualizer.set_path(path, distance)
            self.info_label.setText(
                f"计算完成！\n"
                f"城市数量: {len(self.cities)}\n"
                f"路径长度: {distance:.2f}\n"
                f"路径顺序: {' → '.join(map(str, path))}"
            )
        finally:
            self.solve_btn.setEnabled(True)
            self.solve_btn.setText("快速求解TSP")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
