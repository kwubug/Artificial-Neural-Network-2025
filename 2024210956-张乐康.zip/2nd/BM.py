#!/usr/bin/env python3
"""
boltzmann_machine_3neurons_full.py

Complete, runnable script implementing a 3-neuron Boltzmann Machine (BM)
with dynamic visualization of the update process and visualization of
the neuron connections (line width ~ |weight|, solid for positive, dashed for negative).

Requirements: numpy, matplotlib, pandas
Optional for saving animation: ffmpeg or imagemagick (if you use --save_anim)

Usage examples:
    python boltzmann_machine_3neurons_full.py
    python boltzmann_machine_3neurons_full.py --n_steps 5000 --T 0.8 --save_anim bm_anim.mp4
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import animation
import pandas as pd
import argparse
import sys
import math
import random

DEFAULT_W = np.array([[0.0, 1.2, -0.8],
                      [1.2, 0.0, 0.5],
                      [-0.8, 0.5, 0.0]])  # symmetric 3x3
DEFAULT_b = np.array([0.2, -0.1, 0.0])    # biases
DEFAULT_T = 1.0
DEFAULT_N_STEPS = 2000
DEFAULT_BURN_IN = 500
RANDOM_SEED = 0

BASE_RADIUS = 0.08
ACTIVE_RADIUS = 0.22
NEURON_POS = np.array([[-0.7, -0.4], [0.7, -0.4], [0.0, 0.7]])  # positions for n0, n1, n2 (triangle)
LINEWIDTH_SCALE = 3.0  # scales linewidth ~ LINEWIDTH_SCALE * |w|

np.set_printoptions(precision=3, suppress=True)

def energy(state, W, b):
    s = np.asarray(state)
    return -0.5 * s.dot(W).dot(s) - b.dot(s)


def gibbs_step(state, W, b, T):
    n = len(state)
    i = np.random.randint(0, n)
    h = W[i].dot(state) + b[i]
    p = 1.0 / (1.0 + np.exp(-h / T))
    new_val = 1 if np.random.rand() < p else 0
    state[i] = new_val
    return i, p


def all_states_list(n):
    states = []
    for i in range(2**n):
        bits = tuple(((i >> j) & 1) for j in range(n))
        states.append(bits)
    return states


def exact_boltzmann_distribution(W, b, T):
    n = W.shape[0]
    states = all_states_list(n)
    energies = np.array([energy(np.array(s), W, b) for s in states])
    boltz = np.exp(-energies / T)
    Z = boltz.sum()
    probs = {s: boltz[idx] / Z for idx, s in enumerate(states)}
    return probs, states, energies

def draw_network(ax, W, b, positions=NEURON_POS):
    n = W.shape[0]
    conn_artists = {}
    for i in range(n):
        for j in range(i+1, n):
            x1, y1 = positions[i]
            x2, y2 = positions[j]
            w = W[i, j]
            lw = max(0.5, LINEWIDTH_SCALE * abs(w))
            linestyle = '-' if w >= 0 else '--'
            line, = ax.plot([x1, x2], [y1, y2], linestyle=linestyle, linewidth=lw, zorder=0)
            # place weight label at midpoint
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            ax.text(mx, my - 0.06, f"{w:.2f}", ha='center', va='top', fontsize=8)
            conn_artists[(i, j)] = line
    # Draw neuron circles outlines and labels
    neuron_patches = []
    for i, (x, y) in enumerate(positions):
        circ = plt.Circle((x, y), BASE_RADIUS, fill=False, linewidth=1.2, zorder=2)
        ax.add_patch(circ)
        neuron_patches.append(circ)
        ax.text(x, y + 0.12, f"n{i}", ha='center', va='bottom', fontsize=10)
    return conn_artists, neuron_patches

def run_and_animate(W, b, T, n_steps, burn_in, seed=RANDOM_SEED, save_anim_path=None, anim_fps=20, anim_frames_limit=800):
    np.random.seed(seed)
    random.seed(seed)

    n = W.shape[0]
    state = np.random.randint(0, 2, size=n)

    state_history = []
    energy_history = []
    updated_index_history = []
    prob_history = []

    fig = plt.figure(constrained_layout=True, figsize=(10, 6))
    gs = fig.add_gridspec(2, 3)

    ax_net = fig.add_subplot(gs[:, 0])
    ax_net.set_xlim(-1.1, 1.1)
    ax_net.set_ylim(-1.1, 1.1)
    ax_net.set_aspect('equal')
    ax_net.axis('off')

    conn_artists, neuron_outlines = draw_network(ax_net, W, b, positions=NEURON_POS)

    neuron_fill = []
    for (x, y) in NEURON_POS:
        C = plt.Circle((x, y), BASE_RADIUS, fill=True, alpha=0.8, zorder=3)
        ax_net.add_patch(C)
        neuron_fill.append(C)

    info_text = ax_net.text(0.0, -0.95, "", ha='center', fontsize=9)

    ax_ts = fig.add_subplot(gs[0, 1:])
    ax_ts.set_title("Neuron states over time (last window)")
    ax_ts.set_ylim(-0.1, 1.1)
    ax_ts.set_ylabel("state")
    ax_ts.set_xlabel("step")
    line_ts = [ax_ts.plot([], [], label=f"n{i}")[0] for i in range(n)]
    ax_ts.legend(loc='upper right')

    ax_bar = fig.add_subplot(gs[1, 1:])
    ax_bar.set_title("Exact Boltzmann distribution vs empirical (after burn-in)")

    for step in range(n_steps):
        i, p = gibbs_step(state, W, b, T)
        state_history.append(state.copy())
        energy_history.append(energy(state, W, b))
        updated_index_history.append(i)
        prob_history.append(p)

    states = np.array(state_history)  # shape (n_steps, n)
    energies = np.array(energy_history)
    updated_idx = np.array(updated_index_history)
    probs = np.array(prob_history)

    states_after = states[burn_in:]
    counts = {}
    for s in states_after:
        key = tuple(s.tolist())
        counts[key] = counts.get(key, 0) + 1
    empirical_probs = {k: v / len(states_after) for k, v in counts.items()}

    theoretical_probs, all_states, all_energies = exact_boltzmann_distribution(W, b, T)

    theoretical_most = max(theoretical_probs.items(), key=lambda x: x[1])
    empirical_most = max(empirical_probs.items(), key=lambda x: x[1]) if empirical_probs else (None, 0.0)

    print("=== Simulation summary ===")
    print(f"Temperature T = {T}")
    print(f"Total steps = {n_steps}, burn-in = {burn_in}")
    print("Weights W:\n", W)
    print("Biases b:", b)
    print("Theoretical most probable state:", theoretical_most)
    print("Empirical most frequent state (after burn-in):", empirical_most)

    sorted_states = sorted(all_states)
    x_labels = [''.join(map(str, s[::-1])) for s in sorted_states]  # show as n2 n1 n0
    theo = [theoretical_probs[s] for s in sorted_states]
    emp = [empirical_probs.get(s, 0.0) for s in sorted_states]

    total_frames = min(anim_frames_limit, n_steps)
    indices = np.linspace(0, n_steps - 1, total_frames).astype(int)

    def init_anim():
        for idx, circ in enumerate(neuron_fill):
            circ.set_radius(BASE_RADIUS if states[0, idx] == 0 else ACTIVE_RADIUS)
        info_text.set_text(f"step=0  energy={energies[0]:.3f}  updated=n/A")
        for ln in line_ts:
            ln.set_data([], [])
        ax_ts.set_xlim(0, max(100, n_steps))
        return neuron_fill + [info_text] + line_ts

    def anim_update(frame_k):
        frame = indices[frame_k]
        st = states[frame]
        for idx, circ in enumerate(neuron_fill):
            target_r = ACTIVE_RADIUS if st[idx] == 1 else BASE_RADIUS
            circ.set_radius(target_r)
        upd = updated_idx[frame]
        info_text.set_text(f"step={frame}  energy={energies[frame]:.3f}  updated=n{upd}  p={probs[frame]:.3f}")
        window = 200
        start = max(0, frame - window + 1)
        xaxis = np.arange(start, frame + 1)
        for i_ln in range(n):
            ydata = states[start:frame + 1, i_ln]
            line_ts[i_ln].set_data(xaxis, ydata)
        ax_ts.set_xlim(max(0, frame - window + 1), frame + 1)
        return neuron_fill + [info_text] + line_ts

    anim = animation.FuncAnimation(fig, anim_update, frames=len(indices), init_func=init_anim,
                                   interval=50, blit=True)
    if save_anim_path:
        try:
            print(f"Saving animation to {save_anim_path} ...")
            anim.save(save_anim_path, fps=anim_fps, dpi=150)
            print("Saved animation.")
        except Exception as e:
            print("Failed to save animation:", e)
            print("You may need ffmpeg or imagemagick installed for saving animations.")

    window = 400 if n_steps >= 400 else n_steps
    start = max(0, n_steps - window)
    x_ts = np.arange(start, n_steps)
    for i in range(n):
        line_ts[i].set_data(x_ts, states[start:, i])

    ax_ts.set_xlim(start, n_steps)
    ax_ts.set_ylim(-0.1, 1.1)
    ax_ts.set_xlabel("step")
    ax_ts.set_ylabel("state (0/1)")

    ax_bar.clear()
    x = np.arange(len(x_labels))
    width = 0.35
    ax_bar.bar(x - width / 2, theo, width, label='theoretical')
    ax_bar.bar(x + width / 2, emp, width, label='empirical')
    ax_bar.set_xticks(x)
    ax_bar.set_xticklabels(x_labels)
    ax_bar.set_xlabel('state (n2 n1 n0)')
    ax_bar.set_ylabel('probability')
    ax_bar.legend()

    plt.suptitle("3-Neuron Boltzmann Machine: Dynamic Updates & Distributions")
    plt.show()

    rows = []
    for s in sorted_states:
        rows.append({
            'state': ''.join(map(str, s[::-1])),
            'theoretical_prob': theoretical_probs[s],
            'empirical_prob': empirical_probs.get(s, 0.0),
            'energy': energy(np.array(s), W, b)
        })
    df = pd.DataFrame(rows).sort_values('state', ascending=False).reset_index(drop=True)
    print("\nState distribution (theoretical vs empirical):")
    print(df.to_string(index=False))

    return {
        "states": states,
        "energies": energies,
        "theoretical_probs": theoretical_probs,
        "empirical_probs": empirical_probs,
        "df": df
    }


# -------------------- CLI --------------------
def parse_args():
    p = argparse.ArgumentParser(description="3-neuron Boltzmann Machine simulation with dynamic visualization.")
    p.add_argument("--W", nargs=9, type=float, help="9 numbers row-major for 3x3 weight matrix (diagonal ignored)", default=None)
    p.add_argument("--b", nargs=3, type=float, help="3 biases", default=None)
    p.add_argument("--T", type=float, default=DEFAULT_T, help="temperature")
    p.add_argument("--n_steps", type=int, default=DEFAULT_N_STEPS, help="number of Gibbs steps")
    p.add_argument("--burn_in", type=int, default=DEFAULT_BURN_IN, help="burn-in steps to discard for empirical distribution")
    p.add_argument("--seed", type=int, default=RANDOM_SEED, help="random seed")
    p.add_argument("--save_anim", type=str, default=None, help="filename to save animation (e.g. out.mp4 or out.gif)")
    p.add_argument("--anim_fps", type=int, default=20, help="fps for saved animation")
    return p.parse_args()


def main():
    args = parse_args()

    W = DEFAULT_W.copy()
    b = DEFAULT_b.copy()
    if args.W:
        arr = np.array(args.W)
        if arr.size != 9:
            print("Please specify 9 numbers for --W")
            sys.exit(1)
        W = arr.reshape((3, 3))
        W = 0.5 * (W + W.T)
    if args.b:
        b = np.array(args.b)

    run_and_animate(W=W, b=b, T=args.T, n_steps=args.n_steps, burn_in=args.burn_in,
                    seed=args.seed, save_anim_path=args.save_anim, anim_fps=args.anim_fps)


if __name__ == "__main__":
    main()
