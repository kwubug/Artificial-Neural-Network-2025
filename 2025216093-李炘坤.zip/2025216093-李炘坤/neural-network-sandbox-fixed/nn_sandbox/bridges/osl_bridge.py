import PyQt5.QtCore

from . import Bridge, BridgeProperty


class OSLBridge(Bridge):
    # Properties for OSL visualization control
    learning_rate = BridgeProperty(0.1)
    sample_count = BridgeProperty(200)
    training_steps = BridgeProperty(100)
    batch_size = BridgeProperty(10)
    is_training = BridgeProperty(False)
    current_step = BridgeProperty(0)
    progress = BridgeProperty(0)
    loss_value = BridgeProperty(0.0)
    accuracy_value = BridgeProperty(0.0)
    
    def __init__(self):
        super().__init__()

    @PyQt5.QtCore.pyqtSlot()
    def start_training(self):
        """Start OSL training"""
        self.is_training = True
        self.current_step = 0
        self.progress = 0

    @PyQt5.QtCore.pyqtSlot()
    def pause_training(self):
        """Pause OSL training"""
        self.is_training = False

    @PyQt5.QtCore.pyqtSlot()
    def reset_model(self):
        """Reset OSL model"""
        self.is_training = False
        self.current_step = 0
        self.progress = 0
        self.loss_value = 0.0
        self.accuracy_value = 0.0