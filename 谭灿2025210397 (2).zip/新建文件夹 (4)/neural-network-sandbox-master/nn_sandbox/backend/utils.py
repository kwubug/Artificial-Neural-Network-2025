import pathlib
import math

import numpy as np


def sign(value):
    return 1 if value >= 0 else -1


def sigmoid(value):
    """数值稳定的Sigmoid函数"""
    # 防止数学溢出
    if value < -709:  # math.exp(-709) 接近最小值
        return 0.0
    elif value > 709:  # math.exp(709) 接近最大值
        return 1.0
    return 1 / (1 + math.exp(-value))

def bipolar_sigmoid(value):
    """双极性Sigmoid激活函数，输出范围(-1, 1)"""
    # 防止数学溢出
    if value < -709:  # math.exp(-709) 接近最小值
        return -1.0
    elif value > 709:  # math.exp(709) 接近最大值
        return 1.0
    exp_neg = math.exp(-value)
    return (1 - exp_neg) / (1 + exp_neg)

def sigmoid_derivative(output):
    """单极性Sigmoid的导数"""
    return output * (1 - output)

def bipolar_sigmoid_derivative(output):
    """双极性Sigmoid的导数"""
    return 0.5 * (1 - output * output)


def gaussian(value: np.ndarray, mean: np.ndarray, standard_deviation):
    if standard_deviation == 0:
        return 0
    return math.exp((value - mean).dot(value - mean) / (-2 * standard_deviation**2))


def dist(p1, p2):
    return sum((x1 - x2)**2 for x1, x2 in zip(p1, p2))**0.5


def flatten(list_or_tuple):
    for element in list_or_tuple:
        if isinstance(element, (list, tuple)):
            yield from flatten(element)
        else:
            yield element


def newton_method_update(weights: np.ndarray, gradient: np.ndarray, hessian: np.ndarray, learning_rate: float = 1.0) -> np.ndarray:
    """牛顿法权重更新公式: w_new = w_old - learning_rate * H^(-1) * g"""
    try:
        # 计算Hessian矩阵的逆
        hessian_inv = np.linalg.inv(hessian)
        # 应用牛顿法更新规则
        weight_update = learning_rate * hessian_inv @ gradient
        return weights - weight_update
    except np.linalg.LinAlgError:
        # 如果Hessian矩阵不可逆，使用梯度下降作为备选
        return weights - learning_rate * gradient


def compute_numerical_hessian(func, weights: np.ndarray, epsilon: float = 1e-5) -> np.ndarray:
    """数值计算Hessian矩阵（二阶导数矩阵）"""
    n = len(weights)
    hessian = np.zeros((n, n))
    
    for i in range(n):
        for j in range(n):
            # 计算四个点的函数值来估计二阶导数
            weights_ij = weights.copy()
            weights_ij[i] += epsilon
            weights_ij[j] += epsilon
            f_pp = func(weights_ij)
            
            weights_i = weights.copy()
            weights_i[i] += epsilon
            weights_i[j] -= epsilon
            f_pm = func(weights_i)
            
            weights_j = weights.copy()
            weights_j[i] -= epsilon
            weights_j[j] += epsilon
            f_mp = func(weights_j)
            
            weights_mm = weights.copy()
            weights_mm[i] -= epsilon
            weights_mm[j] -= epsilon
            f_mm = func(weights_mm)
            
            # 中心差分公式计算二阶导数
            hessian[i, j] = (f_pp - f_pm - f_mp + f_mm) / (4 * epsilon * epsilon)
    
    return hessian


def read_data(folder='nn_sandbox/assets/data'):
    data = {}
    for filepath in pathlib.Path(folder).glob('**/*.txt'):
        with filepath.open() as file_object:
            # make sure the data is stored in native Python type in order to
            # communicate with QML.
            data[filepath.stem] = np.loadtxt(file_object).tolist()
    return data
