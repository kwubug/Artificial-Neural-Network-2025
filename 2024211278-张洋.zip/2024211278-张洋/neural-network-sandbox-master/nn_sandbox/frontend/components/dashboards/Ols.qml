import QtQml 2.13
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'OLS-RBF'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: olsBridge ? Object.keys(olsBridge.dataset_dict) : []
                enabled: olsBridge ? olsBridge.has_finished : false
                onActivated: () => {
                    olsBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    olsBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: 'OLS Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: 'Total Training Epoches'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 10
                    to: 999999
                    onValueChanged: olsBridge.total_epoches = value
                    Component.onCompleted: olsBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                CheckBox {
                    id: mostCorrectRateCheckBox
                    enabled: olsBridge.has_finished
                    text: 'Most Correct Rate'
                    checked: true
                    onCheckedChanged: olsBridge.most_correct_rate_checkbox = checked
                    Component.onCompleted: olsBridge.most_correct_rate_checkbox = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: mostCorrectRateCheckBox.checked && olsBridge.has_finished
                    editable: true
                    value: 1.00 * 100
                    onValueChanged: olsBridge.most_correct_rate = value / 100
                    Component.onCompleted: olsBridge.most_correct_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Acceptable Range (±)'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.5 * 100
                    to: 999999 * 100
                    onValueChanged: olsBridge.acceptable_range = value / 100
                    Component.onCompleted: olsBridge.acceptable_range = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Initial Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.8 * 100
                    onValueChanged: olsBridge.initial_learning_rate = value / 100
                    Component.onCompleted: olsBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Search Iteration Constant'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 10000
                    to: 999999
                    onValueChanged: olsBridge.search_iteration_constant = value
                    Component.onCompleted: olsBridge.search_iteration_constant = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Max Number of Centers'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.visible: maxCentersHover.containsMouse
                    ToolTip.text: 'Maximum number of RBF centers to select (OLS will auto-select optimal number)'
                    MouseArea {
                        id: maxCentersHover
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                SpinBox {
                    id: maxCenters
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 5
                    from: 1
                    to: Math.ceil((olsBridge.dataset_dict[datasetCombobox.currentText].length) * (1 - olsBridge.test_ratio))
                    onValueChanged: olsBridge.max_centers = value
                    Component.onCompleted: olsBridge.max_centers = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'ERR Threshold'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.visible: errThresholdHover.containsMouse
                    ToolTip.text: 'Error Reduction Ratio threshold for stopping center selection'
                    MouseArea {
                        id: errThresholdHover
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.001 * 1000
                    from: 0
                    to: 1 * 1000
                    stepSize: 1
                    onValueChanged: olsBridge.err_threshold = value / 1000
                    Component.onCompleted: olsBridge.err_threshold = value / 1000
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Initial Sigma (σ)'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.visible: sigmaHover.containsMouse
                    ToolTip.text: 'Initial standard deviation for RBF neurons'
                    MouseArea {
                        id: sigmaHover
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 1.0 * 100
                    from: 1
                    to: 100 * 100
                    onValueChanged: olsBridge.initial_sigma = value / 100
                    Component.onCompleted: olsBridge.initial_sigma = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Test-Train Ratio'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: olsBridge.test_ratio = value / 100
                    Component.onCompleted: olsBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.1 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: olsBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: olsBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: olsBridge.has_finished
                    startButton.onClicked: () => {
                        olsBridge.start_ols_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(olsBridge.training_dataset)
                        dataChart.updateTestingDataset(olsBridge.testing_dataset)
                        rateChart.reset()
                    }
                    stopButton.enabled: !olsBridge.has_finished
                    stopButton.onClicked: olsBridge.stop_ols_algorithm()
                    progressBar.value: (olsBridge.current_iterations + 1) / (totalEpoches.value * olsBridge.training_dataset.length)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Selected Centers Count'
                    Layout.alignment: Qt.AlignHCenter
                    font.bold: true
                    color: 'blue'
                }
                Label {
                    text: (olsBridge && olsBridge.center_count !== undefined ? olsBridge.center_count : 0) + ' centers selected by OLS'
                    horizontalAlignment: Text.AlignHCenter
                    font.bold: true
                    color: 'blue'
                    Layout.fillWidth: true
                }
                Label {
                    text: 'OLS详细计算过程'
                    Layout.alignment: Qt.AlignHCenter
                    Layout.columnSpan: 2
                    font.bold: true
                    font.pixelSize: 14
                    color: '#0066cc'
                    visible: olsBridge && olsBridge.calculation_steps && olsBridge.calculation_steps.length > 0
                }
                ScrollView {
                    Layout.fillWidth: true
                    Layout.columnSpan: 2
                    Layout.preferredHeight: 200
                    visible: olsBridge && olsBridge.calculation_steps && olsBridge.calculation_steps.length > 0
                    clip: true
                    
                    TextArea {
                        id: calculationProcess
                        readOnly: true
                        text: getCalculationProcess()
                        wrapMode: TextArea.Wrap
                        font.family: 'Consolas, Courier New, monospace'
                        font.pixelSize: 10
                        padding: 10
                        
                        function getCalculationProcess() {
                            if (!olsBridge || !olsBridge.calculation_steps || olsBridge.calculation_steps.length === 0) {
                                return '等待计算开始...'
                            }
                            
                            let result = '━━━ OLS 正交最小二乘算法计算过程 ━━━\n\n'
                            
                            for (let i = 0; i < olsBridge.calculation_steps.length; i++) {
                                const step = olsBridge.calculation_steps[i]
                                
                                if (step.description.includes('初始化')) {
                                    result += `📊 步骤 ${step.step}: ${step.description}\n`
                                    result += `   候选中心数: ${step.n_candidates}, 样本数: ${step.n_samples}\n`
                                    result += `   回归矩阵 Φ 维度: ${step.phi_shape[0]}×${step.phi_shape[1]}\n\n`
                                }
                                else if (step.description.includes('选择中心')) {
                                    result += `✓ 步骤 ${step.step}: ${step.description}\n`
                                    result += `   ERR = ${(step.err_value * 100).toFixed(4)}%\n`
                                    result += `   投影系数 g = ${step.g_value.toFixed(6)}\n`
                                    result += `   ‖u‖² = ${step.w_norm_sq.toFixed(6)}\n`
                                    result += `   公式: ERR = (g² × ‖u‖²) / ‖d‖²\n\n`
                                }
                                else if (step.description.includes('Gram-Schmidt')) {
                                    result += `🔄 步骤 ${step.step}: ${step.description}\n`
                                    result += `   已正交化 ${step.orthogonalized_count} 个候选向量\n`
                                    if (step.alphas && step.alphas.length > 0) {
                                        result += `   投影系数 α (前${step.alphas.length}个):\n`
                                        for (let j = 0; j < step.alphas.length; j++) {
                                            const alpha = step.alphas[j]
                                            result += `      α[${alpha.candidate_index}] = ${alpha.alpha.toFixed(6)}\n`
                                        }
                                    }
                                    result += `   公式: u_j = u_j - α × u_selected\n\n`
                                }
                                else if (step.description.includes('ERR低于阈值')) {
                                    result += `⛔ 步骤 ${step.step}: ${step.description}\n`
                                    result += `   阈值: ${step.threshold.toFixed(6)}\n`
                                    result += `   当前ERR: ${step.max_err.toFixed(6)}\n\n`
                                }
                            }
                            
                            result += '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'
                            result += `✅ 共选择 ${olsBridge.center_count} 个RBF中心\n`
                            
                            if (olsBridge.err_ratios && olsBridge.err_ratios.length > 0) {
                                let totalERR = 0
                                for (let i = 0; i < olsBridge.err_ratios.length; i++) {
                                    totalERR += olsBridge.err_ratios[i]
                                }
                                result += `累计误差减少率: ${(totalERR * 100).toFixed(2)}%\n`
                            }
                            
                            return result
                        }
                        
                        Connections {
                            target: olsBridge
                            function onCalculation_stepsChanged() {
                                calculationProcess.text = calculationProcess.getCalculationProcess()
                            }
                            function onHas_finishedChanged() {
                                if (olsBridge.has_finished) {
                                    calculationProcess.text = calculationProcess.getCalculationProcess()
                                }
                            }
                        }
                    }
                }
                Label {
                    text: 'RBF Neuron Weights'
                    Layout.alignment: Qt.AlignHCenter
                    font.bold: true
                    color: 'purple'
                    visible: olsBridge && olsBridge.current_neurons && olsBridge.current_neurons.length > 0
                }
                ScrollView {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 100
                    visible: olsBridge && olsBridge.current_neurons && olsBridge.current_neurons.length > 0
                    TextArea {
                        readOnly: true
                        text: getNeuronWeights()
                        wrapMode: TextArea.Wrap
                        font.family: 'Courier New'
                        font.pixelSize: 11
                        
                        function getNeuronWeights() {
                            if (!olsBridge || !olsBridge.current_neurons) return ''
                            let result = 'Final Weights:\n'
                            for (let i = 0; i < Math.min(olsBridge.current_neurons.length, 10); i++) {
                                const neuron = olsBridge.current_neurons[i]
                                if (neuron && neuron.synaptic_weight !== undefined) {
                                    result += `w${i+1}=${neuron.synaptic_weight.toFixed(4)} `
                                    if ((i + 1) % 4 === 0) result += '\n'
                                }
                            }
                            if (olsBridge.current_neurons.length > 10) {
                                result += '\n...'
                            }
                            return result
                        }
                    }
                }
                Label {
                    text: 'Current Training Epoch'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const epoch = Math.floor(olsBridge.current_iterations / olsBridge.training_dataset.length) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: 'Current Training Iteration'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        dataChart.updateNeurons()
                        neuronChart.updateAxisY()
                        rateChart.bestCorrectRate.append(
                            olsBridge.current_iterations + 1,
                            olsBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            olsBridge.current_iterations + 1,
                            olsBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            olsBridge.current_iterations + 1,
                            olsBridge.test_correct_rate
                        )
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsBridge.current_learning_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Best Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsBridge.best_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsBridge.current_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Testing Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsBridge.test_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            property var neuronScatters: []
            

            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true

            function updateNeurons() {
                neuronScatters.forEach(neuron => {removeSeries(neuron)})
                neuronScatters = []

                // 在训练过程中和训练完成后都显示中心点（动态变化）
                if (olsBridge && olsBridge.current_neurons && olsBridge.current_neurons.length > 0) {
                    // 检查是否已经开始训练（有迭代次数或训练完成）
                    const hasStarted = olsBridge.current_iterations > 0 || olsBridge.has_finished
                    
                    if (hasStarted) {
                        for (let i = 0; i < olsBridge.current_neurons.length; i++) {
                            const neuron = olsBridge.current_neurons[i]
                            // 检查neuron数据有效性：必须有mean且是数组，权重有效
                            if (neuron && 
                                neuron.mean && 
                                Array.isArray(neuron.mean) && 
                                neuron.mean.length >= 2 && 
                                neuron.synaptic_weight !== undefined && 
                                !isNaN(neuron.synaptic_weight) &&
                                !isNaN(neuron.mean[0]) &&
                                !isNaN(neuron.mean[1])) {
                                // 根据训练状态改变标记颜色和样式
                                neuronScatters.push(createHoverableNeuronSeries(
                                    neuron.mean, 
                                    neuron.synaptic_weight,
                                    olsBridge.has_finished,  // 传递训练状态
                                    i
                                ))
                            }
                        }
                    }
                }
            }

            function createHoverableNeuronSeries(mean, weight, isFinished, index) {
                const newSeries = createSeries(
                    ChartView.SeriesTypeScatter, `center_${index}`,
                    xAxis, yAxis
                )
                
                // 根据权重大小动态调整颜色和大小（限制权重范围避免异常）
                const absWeight = Math.abs(weight)
                const normalizedWeight = Math.min(Math.max(absWeight, 0), 10)  // 限制在0-10之间
                const maxSize = 25
                const minSize = 12
                const size = minSize + (maxSize - minSize) * Math.min(normalizedWeight / 2, 1)
                
                // 训练中：半透明颜色，训练完成：亮色
                if (isFinished) {
                    // 训练完成：使用鲜明颜色
                    newSeries.color = weight > 0 ? '#FF0000' : '#87CEEB'  // 红色/天蓝色（正/负权重）
                    newSeries.borderColor = weight > 0 ? '#CC0000' : '#4682B4'  // 深红/钢蓝
                    newSeries.borderWidth = 3  // 更粗的边框表示完成
                } else {
                    // 训练中：使用半透明颜色，显示动态变化过程
                    newSeries.color = weight > 0 ? '#FF9999' : '#B0E0E6'  // 浅红色/浅蓝色（正/负权重）
                    newSeries.borderColor = weight > 0 ? '#FF6666' : '#87CEEB'  // 浅红/浅蓝边框
                    newSeries.borderWidth = 2  // 较细的边框表示训练中
                }
                
                newSeries.markerSize = Math.max(minSize, Math.min(size, maxSize))  // 确保大小在范围内
                newSeries.markerShape = ScatterSeries.MarkerShapeCircle
                
                newSeries.hovered.connect((point, state) => {
                    const position = mapToPosition(point)
                    chartToolTip.x = position.x - chartToolTip.width
                    chartToolTip.y = position.y - chartToolTip.height
                    chartToolTip.text = `Center #${index+1}\n` +
                                       `Position: (${point.x.toFixed(3)}, ${point.y.toFixed(3)})\n` +
                                       `Weight: ${weight.toFixed(4)}\n` +
                                       `Status: ${isFinished ? 'Final' : 'Training...'}`
                    chartToolTip.visible = state
                })
                
                // 确保mean是有效的坐标数组
                if (mean && mean.length >= 2) {
                    newSeries.append(mean[0], mean[1])
                }
                newSeries.useOpenGL = true
                return newSeries
            }

            // XXX: sadly, QML does not have `super` access to the base class. Thus,
            // we cannot call super method in overridden methods.
            // Further details: https://bugreports.qt.io/browse/QTBUG-25942
            function clear() {
                removeAllSeries()
                scatterSeriesMap = {}
                neuronScatters = []
            }
        }
        RowLayout {
            ChartView {
                id: neuronChart
                title: 'RBF Neuron Parameters'
                antialiasing: true
                Layout.fillWidth: true
                Layout.fillHeight: true
                ToolTip {
                    id: neuronChartToolTip
                    x: (parent.width - width) / 2
                    y: (parent.height - height) / 2
                }
                BarSeries {
                    id: neuronChartSeries
                    useOpenGL: true
                    axisX: BarCategoryAxis {
                        titleText: 'Neuron Index'
                        categories: Array.from(Array(olsBridge.center_count).keys())
                    }
                    axisY: ValueAxis {
                        id: neuronChartAxisY
                        max: 0
                        min: 0
                    }
                    BarSet {
                        id: standardDeviationBarSet
                        label: 'Standard Deviation (σ)'
                        color: '#5470c6'
                        values: olsBridge.current_neurons.map(neuron => neuron.standard_deviation)
                    }
                    BarSet {
                        id: synapticWeightBarSet
                        label: 'Synaptic Weight'
                        color: '#91cc75'
                        values: olsBridge.current_neurons.map(neuron => neuron.synaptic_weight)
                    }
                    onHovered: (status, index, barset) => {
                        neuronChartToolTip.text = barset.label + ': ' + barset.at(index).toFixed(4)
                        neuronChartToolTip.visible = status
                    }
                }
                function updateAxisY() {
                    const max = Math.max(0, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    const min = Math.min(0, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    neuronChartAxisY.max = isFinite(max) ? max : 0
                    neuronChartAxisY.min = isFinite(min) ? min : 0
                }
            }
            RateChart {
                id: rateChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }
    Connections {
        target: olsBridge
        // update the chart scatter series to the best neurons at the end of the
        // training.
        onHas_finishedChanged: dataChart.updateNeurons()
    }
}

