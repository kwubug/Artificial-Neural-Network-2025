import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '../'

Page {
    name: "玻尔兹曼机 (BM)"

    ColumnLayout {
        spacing: 10
        // 删除此行: anchors.fill: parent
        Layout.fillWidth: true
        Layout.fillHeight: true

        // 控制面板
        GroupBox {
            title: "Boltzmann Machine 控制面板"
            Layout.fillWidth: true

            ColumnLayout {
                spacing: 10

                // 网络参数
                GroupBox {
                    title: "网络参数"
                    Layout.fillWidth: true

                    GridLayout {
                        columns: 4
                        rowSpacing: 10
                        columnSpacing: 10

                        Label { text: "初始温度:" }
                        Slider {
                            from: 0.1
                            to: 5.0
                            value: 1.0
                            stepSize: 0.1
                            Layout.preferredWidth: 150
                        }
                        Label { text: "目标温度:" }
                        Slider {
                            from: 0.01
                            to: 1.0
                            value: 0.01
                            stepSize: 0.01
                            Layout.preferredWidth: 150
                        }

                        Label { text: "冷却速率:" }
                        Slider {
                            from: 0.8
                            to: 0.99
                            value: 0.95
                            stepSize: 0.01
                            Layout.preferredWidth: 150
                        }
                        Label { text: "更新速度(ms):" }
                        SpinBox {
                            from: 10
                            to: 1000
                            value: 100
                            stepSize: 10
                            Layout.preferredWidth: 100
                        }
                    }
                }

                // 权重矩阵显示
                GroupBox {
                    title: "权重矩阵 & 偏置"
                    Layout.fillWidth: true

                    GridLayout {
                        columns: 2
                        rowSpacing: 5
                        columnSpacing: 10

                        Label { text: "权重:" }
                        TextArea {
                            text: "[0.000, 0.000, 0.000]\n[0.000, 0.000, 0.000]\n[0.000, 0.000, 0.000]"
                            readOnly: true
                            Layout.preferredHeight: 80
                        }

                        Label { text: "偏置:" }
                        TextArea {
                            text: "[0.000, 0.000, 0.000]"
                            readOnly: true
                            Layout.preferredHeight: 40
                        }
                    }
                }

                // 模拟控制
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 15

                    Button {
                        text: "开始模拟"
                        onClicked: {
                            console.log("开始 Boltzmann Machine 模拟")
                            bmBridge.start_simulation()
                        }
                    }

                    Button {
                        text: "停止模拟"
                        enabled: bmBridge.is_running
                        onClicked: {
                            console.log("停止 Boltzmann Machine 模拟")
                            bmBridge.stop_simulation()
                        }
                    }

                    Button {
                        text: "单步执行"
                        onClicked: {
                            console.log("执行 Boltzmann Machine 单步")
                            bmBridge.single_step()
                        }
                    }

                    Button {
                        text: "重置网络"
                        onClicked: {
                            console.log("重置 Boltzmann Machine 网络")
                            bmBridge.reset_network()
                        }
                    }

                    Button {
                        text: "随机权重"
                        onClicked: {
                            console.log("随机化权重和偏置")
                            bmBridge.randomize_weights()
                        }
                    }
                }

                // 当前状态显示
                GroupBox {
                    title: "当前状态"
                    Layout.fillWidth: true

                    GridLayout {
                        columns: 4
                        rowSpacing: 5
                        columnSpacing: 15

                        Label { text: "神经元 1:" }
                        Label { 
                            text: bmBridge.neuron_states[0] 
                            color: bmBridge.neuron_states[0] === 1 ? "green" : "red"
                            font.bold: true
                        }
                        Label { text: "P = 0.000" }

                        Label { text: "神经元 2:" }
                        Label { 
                            text: bmBridge.neuron_states[1] 
                            color: bmBridge.neuron_states[1] === 1 ? "green" : "red"
                            font.bold: true
                        }
                        Label { text: "P = 0.000" }

                        Label { text: "神经元 3:" }
                        Label { 
                            text: bmBridge.neuron_states[2] 
                            color: bmBridge.neuron_states[2] === 1 ? "green" : "red"
                            font.bold: true
                        }
                        Label { text: "P = 0.000" }

                        Label { text: "温度:" }
                        Label { text: bmBridge.current_temperature.toFixed(3) }

                        Label { text: "能量:" }
                        Label { text: bmBridge.current_energy.toFixed(3) }
                    }
                }

                // 进度和信息
                GroupBox {
                    title: "模拟信息"
                    Layout.fillWidth: true

                    ColumnLayout {
                        spacing: 5

                        ScrollView {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 80

                            TextArea {
                                readOnly: true
                                text: "步数: " + bmBridge.step_count + 
                                      "\n温度: " + bmBridge.current_temperature.toFixed(3) + 
                                      "\n能量: " + bmBridge.current_energy.toFixed(3) +
                                      "\n状态: " + (bmBridge.thermal_equilibrium ? "热平衡 ✓" : "冷却中...")
                            }
                        }

                        ProgressBar {
                            Layout.fillWidth: true
                            value: bmBridge.current_temperature > 0 ? 
                                   (1 - (bmBridge.current_temperature - bmBridge.target_temperature) / 
                                   (1.0 - bmBridge.target_temperature)) : 0
                        }
                    }
                }
            }
        }

        // 可视化区域
        GroupBox {
            title: "Boltzmann Machine 可视化"
            Layout.fillWidth: true
            Layout.fillHeight: true

            TabBar {
                id: tabBar
                width: parent.width

                TabButton { text: "能量景观" }
                TabButton { text: "温度演化" }
                TabButton { text: "状态概率" }
                TabButton { text: "网络结构" }
            }

            StackLayout {
                width: parent.width
                height: parent.height - tabBar.height
                currentIndex: tabBar.currentIndex
                anchors.top: tabBar.bottom

                // 能量景观图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "能量景观可视化区域"
                    }
                }

                // 温度演化图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "温度演化可视化区域"
                    }
                }

                // 状态概率图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "状态概率分布可视化区域"
                    }
                }

                // 网络结构图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "网络结构可视化区域"
                    }
                }
            }
        }
    }
}