import numpy as np
import matplotlib.pyplot as plt

# ======== matplotlib 中文显示设置（避免中文乱码、负号错位） ========
plt.rcParams["font.sans-serif"] = ["SimHei", "Noto Sans CJK SC", "Microsoft YaHei", "PingFang SC", "STHeiti"]
plt.rcParams["axes.unicode_minus"] = False


class SingleNodeNetwork:
    def __init__(self, num_inputs=6):
        self.num_inputs = num_inputs
        self.weights = np.random.uniform(-0.5, 0.5, num_inputs)
        self.bias = np.random.uniform(-0.5, 0.5)
        self.learning_rate = 0.1
        self.epoch = 0
        self.delta_loss = 'mse'  # 'mse' 或 'ce'（配 sigmoid 用 'ce' 更稳）

    def activation_function(self, net, func_type='step'):
        if func_type == 'step':
            return 1 if net >= 0 else 0
        elif func_type == 'linear':
            return net
        elif func_type == 'sigmoid':
            return 1 / (1 + np.exp(-net))
        elif func_type == 'tanh':
            return np.tanh(net)
        else:
            return net

    def derivative(self, output, func_type='step'):
        if func_type == 'linear':
            return 1.0
        elif func_type == 'sigmoid':
            return output * (1 - output)
        elif func_type == 'tanh':
            return 1.0 - output ** 2
        else:
            return 1.0  # 阶跃不可导：仅占位，别和 delta 配

    def calculate_net_input(self, inputs):
        return np.dot(inputs, self.weights) + self.bias

    def predict(self, inputs, func_type='step'):
        net = self.calculate_net_input(inputs)
        return self.activation_function(net, func_type), net

    # ---------- 三种学习规则（都返回：误差e、净输入v、Δw、Δb） ----------
    def train_perceptron(self, inputs, target, func_type='step'):
        y, net = self.predict(inputs, func_type)
        e = target - y
        delta_w = self.learning_rate * e * inputs
        delta_b = self.learning_rate * e
        self.weights += delta_w
        self.bias += delta_b
        return e, net, delta_w, delta_b

    def train_delta(self, inputs, target, func_type='linear'):
        y, net = self.predict(inputs, func_type)
        e = target - y
        if self.delta_loss == 'ce' and func_type == 'sigmoid':
            # 交叉熵 + sigmoid：梯度 (y - t)
            grad = (y - target)
            delta_w = -self.learning_rate * grad * inputs
            delta_b = -self.learning_rate * grad
        else:
            df = self.derivative(y, func_type)
            delta_w = self.learning_rate * e * df * inputs
            delta_b = self.learning_rate * e * df
        self.weights += delta_w
        self.bias += delta_b
        return e, net, delta_w, delta_b

    def train_lms(self, inputs, target, func_type='linear'):
        y, net = self.predict(inputs, func_type)
        e = target - y
        delta_w = self.learning_rate * e * inputs
        delta_b = self.learning_rate * e
        self.weights += delta_w
        self.bias += delta_b
        return e, net, delta_w, delta_b

    # ---------- 逐步打印：每一步给出 v、Δw、Δb ----------
    def train_epoch(self, training_data, learning_rule='perceptron', func_type='step', verbose=True):
        print(f"\n=== 第 {self.epoch + 1} 轮训练 ===")
        print(f"学习规则：{learning_rule}   激活函数：{func_type}")
        total_error = 0.0
        order = np.random.permutation(len(training_data))
        for step, i in enumerate(order, start=1):
            inputs, target = training_data[i]
            if learning_rule == 'perceptron':
                e, net, delta_w, delta_b = self.train_perceptron(inputs, target, func_type)
            elif learning_rule == 'delta':
                e, net, delta_w, delta_b = self.train_delta(inputs, target, func_type)
            elif learning_rule == 'lms':
                e, net, delta_w, delta_b = self.train_lms(inputs, target, func_type)
            else:
                e, net, delta_w, delta_b = self.train_perceptron(inputs, target, func_type)

            total_error += e ** 2

            if verbose:
                print(f"\n—— 样本 {step} ——")
                print(f"输入向量 x = {inputs}")
                print(f"目标输出 t = {target}")
                print(f"净输入 v = {net:.6f}")
                print(f"误差 e = {e:.6f}")
                print(f"权值调整 Δw = {delta_w}")
                print(f"偏置调整 Δb = {delta_b:.6f}")
                print(f"新权值 w = {self.weights}")
                print(f"新偏置 b = {self.bias:.6f}")

        mse = total_error / len(training_data)
        print(f"\n本轮均方误差 MSE = {mse:.6f}")
        self.epoch += 1
        return mse


# ------------------ 对比实验：出图（不保存，直接显示） ------------------

def 运行对比实验并画图(
    训练数据,
    规则=('perceptron', 'delta', 'lms'),
    激活=('step', 'linear', 'sigmoid'),
    轮数=20,
    学习率=0.2,
    随机种子=2025,
    sigmoid用交叉熵=True,
    柱状图显示占位不适用=True,
    打印每步=False
):
    规则名 = {'perceptron': '感知机', 'delta': 'Delta（梯度）', 'lms': 'LMS'}
    激活名 = {'step': '阶跃', 'linear': '线性', 'sigmoid': 'Sigmoid', 'tanh': 'Tanh'}

    样式 = {
        'perceptron': dict(linestyle='-',  marker='o', linewidth=2),
        'delta':      dict(linestyle='--', marker='s', linewidth=2),
        'lms':        dict(linestyle='-.', marker='^', linewidth=2),
    }

    # 固定起点，公平对比
    rng = np.random.default_rng(随机种子)
    init_w = rng.uniform(-0.5, 0.5, size=6)
    init_b = float(rng.uniform(-0.5, 0.5))

    results = {}

    for act in 激活:
        for rule in 规则:
            if rule == 'delta' and act == 'step':
                # 阶跃不可导，跳过
                continue

            net = SingleNodeNetwork(num_inputs=6)
            net.learning_rate = 学习率
            net.weights = init_w.copy()
            net.bias = init_b
            net.epoch = 0
            net.delta_loss = 'ce' if (rule == 'delta' and act == 'sigmoid' and sigmoid用交叉熵) else 'mse'

            mses = []
            for _ in range(轮数):
                mse = net.train_epoch(
                    训练数据, learning_rule=rule, func_type=act,
                    verbose=打印每步  # True -> 打印每一步 v/Δw/Δb；False -> 安静训练
                )
                mses.append(mse)
            results[(rule, act)] = mses

    # 学习曲线（每个激活函数一张图）
    for act in 激活:
        pairs = [(r, a) for (r, a) in results.keys() if a == act]
        if not pairs:  # 例如 step 下没有 delta
            continue

        all_mses = [m for (r, a) in pairs for m in results[(r, a)]]
        ymax = max(all_mses) if all_mses else 1.0
        ybottom = -0.02 * ymax

        plt.figure()
        for (r, a) in pairs:
            mses = results[(r, a)]
            style = 样式.get(r, {})
            x = range(1, len(mses) + 1)
            plt.plot(x, mses, label=f"{规则名[r]}", **style)
            plt.scatter(x, mses, s=20)
        plt.xlabel("训练轮数（Epoch）")
        plt.ylabel("均方误差（MSE）")
        plt.title(f"学习曲线：激活函数 = {激活名.get(act, act)}")
        plt.legend(title="学习规则")
        plt.ylim(bottom=ybottom)
        plt.tight_layout()
        plt.show()

    # 最终 MSE 柱状图
    if 柱状图显示占位不适用:
        想看的组合 = [
            ('perceptron','step'), ('delta','step'), ('lms','step'),
            ('perceptron','linear'), ('delta','linear'), ('lms','linear'),
            ('perceptron','sigmoid'), ('delta','sigmoid'), ('lms','sigmoid')
        ]
        标签, 最终误差, 是否占位 = [], [], []
        for (r,a) in 想看的组合:
            标签.append(f"{规则名[r]}\n{激活名.get(a,a)}")
            if (r,a) in results:
                最终误差.append(results[(r,a)][-1])
                是否占位.append(False)
            else:
                最终误差.append(0.0)
                是否占位.append(True)
    else:
        标签 = [f"{规则名[r]}\n{激活名.get(a,a)}" for (r,a) in results.keys()]
        最终误差 = [results[(r,a)][-1] for (r,a) in results.keys()]
        是否占位 = [False]*len(标签)

    plt.figure()
    bars = plt.bar(标签, 最终误差)
    for i, b in enumerate(bars):
        if 是否占位[i]:
            b.set_color('lightgray')
            plt.text(b.get_x()+b.get_width()/2, 0.001, "不适用", ha='center', va='bottom')
    for b, v in zip(bars, 最终误差):
        plt.text(b.get_x()+b.get_width()/2, v + max(1e-4, 0.01*v), f"{v:.3g}", ha='center', va='bottom')
    vmax = max(最终误差) if 最终误差 else 1.0
    plt.ylim(bottom=-0.02 * vmax)
    plt.ylabel("最终均方误差（Final MSE）")
    plt.title("不同学习规则 × 激活函数 的最终 MSE 对比")
    plt.tight_layout()
    plt.show()

    # 控制台汇总
    print("\n=== 实验汇总（最终 MSE）===")
    for (r, a), mses in results.items():
        best_epoch = int(np.argmin(mses) + 1)
        print(f"规则={规则名[r]:8s} | 激活={激活名.get(a,a):6s} | 最终MSE={mses[-1]:.6f} | 最优MSE={min(mses):.6f}（第{best_epoch}轮）")

    return results


# ------------------ 示例：先画图，再逐步打印一轮 ------------------

if __name__ == "__main__":
    训练数据 = [
        (np.array([1, 0, 0, 0, 0, 0], dtype=float), 1.0),
        (np.array([0, 1, 0, 0, 0, 0], dtype=float), 0.0),
        (np.array([0, 0, 1, 0, 0, 0], dtype=float), 1.0),
        (np.array([0, 0, 0, 1, 0, 0], dtype=float), 0.0),
    ]

    # 一键画图：不打印每步细节，只出图
    EPOCHS, LR = 20, 0.2
    运行对比实验并画图(
        训练数据,
        规则=('perceptron', 'delta', 'lms'),
        激活=('step', 'linear', 'sigmoid'),
        轮数=EPOCHS,
        学习率=LR,
        随机种子=2025,
        sigmoid用交叉熵=True,
        柱状图显示占位不适用=True,
        打印每步=False     # 想同时看逐步细节就改成 True（控制台会很多输出）
    )

    # 若你还需要“逐步打印”的版本（举例：perceptron + sigmoid 训练3轮）
    net = SingleNodeNetwork(num_inputs=6)
    net.learning_rate = 0.2
    net.delta_loss = 'ce'
    for _ in range(3):
        net.train_epoch(训练数据, learning_rule='perceptron', func_type='sigmoid', verbose=True)
