import matplotlib

matplotlib.use('TkAgg')  # 切换到Tkinter交互式后端
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

# 解决中文显示问题（针对Windows系统）
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号

# 1. 玻尔兹曼机参数（3个神经元）
w = np.array([[0, 1, 1],  # 权重矩阵（对称，无自连接）
              [1, 0, 1],
              [1, 1, 0]])
b = np.array([0, 0, 0])  # 偏置
T = 1.0  # 温度
threshold = 0.01  # 热平衡判断阈值
reached_equilibrium = False  # 标记是否达到热平衡

# 2. 初始化状态与记录
state = np.random.randint(0, 2, size=3)  # 随机初始状态（0或1）
history = [state.copy()]  # 记录状态变化
prob_history = []  # 记录状态概率分布变化


# 3. 能量计算函数
def energy(s):
    return -np.sum(w * np.outer(s, s)) - np.sum(b * s)


# 4. 状态更新函数（吉布斯采样）
def update_state(s):
    new_s = s.copy()
    i = np.random.randint(3)  # 随机选择一个神经元更新
    activation = np.sum(w[i, :] * new_s) + b[i]  # 激活能量
    prob = 1 / (1 + np.exp(-activation / T))  # 状态1的概率（sigmoid函数）
    new_s[i] = 1 if np.random.rand() < prob else 0  # 按概率更新
    return new_s


# 5. 可视化设置（确保动画窗口正确显示）
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
fig.suptitle("三个神经元的玻尔兹曼机（BM）运行过程")

# 神经元位置（三角形分布，便于观察）
positions = np.array([[0, 1], [-1, -1], [1, -1]])
node_size = 3000


# 6. 动画更新函数（核心：每帧刷新图像）
def animate(frame):
    global state, history, prob_history, reached_equilibrium, ani

    # 如果已达热平衡，不再更新状态
    if reached_equilibrium:
        return

    # 更新状态
    state = update_state(state)
    history.append(state.copy())

    # 计算最近状态的概率分布（取最近100步，确保统计稳定）
    recent = history[-100:] if len(history) >= 100 else history
    unique, counts = np.unique(recent, axis=0, return_counts=True)
    probs = counts / len(recent)
    prob_history.append(probs)

    # 左侧：绘制神经元状态（动态更新）
    ax1.clear()  # 清除上一帧图像
    ax1.set_title(f"迭代步数：{frame} | 状态：{state}")
    ax1.set_xlim(-2, 2)
    ax1.set_ylim(-2, 2)
    # 绘制神经元之间的连接
    for i in range(3):
        for j in range(i + 1, 3):
            ax1.plot([positions[i, 0], positions[j, 0]],
                     [positions[i, 1], positions[j, 1]],
                     'gray', linestyle='-', linewidth=2)
    # 绘制神经元（蓝色=激活（1），灰色=未激活（0））
    for i in range(3):
        color = 'blue' if state[i] == 1 else 'lightgray'
        ax1.scatter(positions[i, 0], positions[i, 1],
                    s=node_size, c=color, edgecolors='black')
        ax1.text(positions[i, 0] - 0.3, positions[i, 1] - 0.3, f"神经元 {i + 1}", fontsize=12)

    # 右侧：绘制状态概率分布（动态更新）
    ax2.clear()  # 清除上一帧图像
    ax2.set_title("状态概率分布（最近100步）")
    ax2.set_ylim(0, 1)
    ax2.set_xlabel("状态（二进制编码）")
    ax2.set_ylabel("概率")
    if len(unique) > 0:
        labels = [''.join(map(str, u)) for u in unique]  # 状态编码为字符串（如"101"）
        ax2.bar(labels, probs, color='orange')

    # 判断热平衡（状态分布稳定）
    if len(prob_history) > 1:
        prev_probs = prob_history[-2]
        current_probs = prob_history[-1]
        # 简化判断：最大概率的变化小于阈值
        max_diff = np.abs(np.max(prev_probs) - np.max(current_probs))
        if max_diff < threshold:
            ax1.text(-1.8, 1.5, "已达热平衡，停止迭代", color='red', fontsize=14, fontweight='bold')
            reached_equilibrium = True  # 标记达到平衡
            ani.event_source.stop()  # 停止动画迭代


# 7. 启动动画（关键参数：设置足够大的帧数，由热平衡条件控制停止）
ani = FuncAnimation(
    fig,
    animate,
    frames=1000,  # 设置较大帧数，确保能达到平衡
    interval=300,  # 每帧间隔毫秒
    repeat=False,  # 不循环播放
    blit=False
)

# 显示动画
plt.show()