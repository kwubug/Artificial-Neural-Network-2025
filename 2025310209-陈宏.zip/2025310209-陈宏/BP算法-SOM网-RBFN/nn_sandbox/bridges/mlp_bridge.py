import time
import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import MlpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class MlpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    momentum_weight = BridgeProperty(0.5)
    test_ratio = BridgeProperty(0.3)
    network_shape = BridgeProperty([5, 5])
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)


    bp_input_nodes = BridgeProperty(2)
    bp_hidden_nodes = BridgeProperty(4)
    bp_output_nodes = BridgeProperty(1)
    bp_learning_rate = BridgeProperty(0.5)
    bp_activation_type = BridgeProperty("unipolar")
    bp_result = BridgeProperty("点击运行查看结果")

    def __init__(self):
        super().__init__()
        self.mlp_algorithm = None






### 3.7题新增代码如下
        self.bp_weights_ih = None
        self.bp_weights_ho = None

        self._bp_initialize_weights()

    def _bp_initialize_weights(self):
###权值在[-1,1]随机初始化

        # 输入层到隐层权值
        self.bp_weights_ih = np.random.uniform(-1, 1, (self.bp_input_nodes + 1, self.bp_hidden_nodes))
        # 隐层到输出层权值
        self.bp_weights_ho = np.random.uniform(-1, 1, (self.bp_hidden_nodes + 1, self.bp_output_nodes))
        self.bp_result = "权值初始化完成！"

        @PyQt5.QtCore.pyqtSlot()
        def bp_initialize_weights(self):
###权值初始化

            self._bp_initialize_weights()

        @PyQt5.QtCore.pyqtSlot()
        def bp_run_demo(self):
            try:
                # 准备数据
                input_data = np.array([0.5, 0.3])
                target = np.array([0.8])

### 自主选择两种激活函数
                def sigmoid(x):
                    if self.bp_activation_type == "unipolar":
                        return 1.0 / (1.0 + np.exp(-x))  # 单极性
                    else:
                        return np.tanh(x)  # 双极性

### 前向传播
                input_bias = np.append(input_data, 1)
                net_y = np.dot(input_bias, self.bp_weights_ih)
                y = sigmoid(net_y)
                y_bias = np.append(y, 1)
                net_o = np.dot(y_bias, self.bp_weights_ho)
                output = sigmoid(net_o)
                result = f"""3.7题BP算法运行成功！

        网络结构: 输入层{self.bp_input_nodes}节点, 隐层{self.bp_hidden_nodes}节点, 输出层{self.bp_output_nodes}节点
        学习率: {self.bp_learning_rate}
        激活函数: {self.bp_activation_type}
        输入数据: {input_data}
        目标输出: {target}
        网络输出: {output}
        权值矩阵V形状: {self.bp_weights_ih.shape}
        权值矩阵W形状: {self.bp_weights_ho.shape}"""
                self.bp_result = result
            except Exception as e:
                self.bp_result = f"运行错误: {str(e)}"


















    @PyQt5.QtCore.pyqtSlot()
    def start_mlp_algorithm(self):
        self.mlp_algorithm = ObservableMlpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            momentum_weight=self.momentum_weight,
            test_ratio=self.test_ratio,
            network_shape=self.network_shape
        )
        self.mlp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_mlp_algorithm(self):
        self.mlp_algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableMlpAlgorithm(Observable, MlpAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        MlpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # the following line keeps the GUI from blocking
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
