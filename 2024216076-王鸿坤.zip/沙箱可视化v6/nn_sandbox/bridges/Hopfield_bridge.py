import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import HopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    # UI控制参数
    ui_refresh_interval = BridgeProperty(0.1)
    total_iterations = BridgeProperty(100)
    update_mode = BridgeProperty('async')  # 'async' or 'sync'
    
    # 运行状态
    has_finished = BridgeProperty(True)
    current_iterations = BridgeProperty(0)
    converged = BridgeProperty(False)
    
    # 当前状态
    current_state = BridgeProperty([1, 1, 0, 0, 1, 1, 0, 0])
    current_energy = BridgeProperty(0.0)
    
    # 模式存储 (默认存储两个8位模式)
    patterns = BridgeProperty([
        [1, 1, 1, 1, 0, 0, 0, 0],  # Pattern 1
        [0, 0, 0, 0, 1, 1, 1, 1],  # Pattern 2
    ])
    
    # 初始输入状态
    initial_state = BridgeProperty([1, 1, 0, 0, 1, 1, 0, 0])
    
    # 权重矩阵
    weight_matrix = BridgeProperty([])
    
    # 吸引子信息
    attractor_state = BridgeProperty([])
    attractor_iteration = BridgeProperty(-1)
    attractor_energy = BridgeProperty(0.0)
    
    # 历史记录
    state_history = BridgeProperty([])
    energy_history = BridgeProperty([])
    
    # 模式相似度
    pattern_similarities = BridgeProperty([])
    
    # 检测到的吸引子列表
    detected_attractors = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self._algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_hopfield_algorithm(self):
        """启动Hopfield网络"""
        if self._algorithm and self._algorithm.is_alive():
            return

        # 重置状态
        self.has_finished = False
        self.current_iterations = 0
        self.converged = False
        self.state_history = []
        self.energy_history = []
        self.attractor_state = []
        self.attractor_iteration = -1
        self.attractor_energy = 0.0
        self.pattern_similarities = []
        self.detected_attractors = []

        # 验证和规范化输入
        normalized_patterns = self._normalize_patterns(self.patterns)
        normalized_initial = self._normalize_state(self.initial_state)
        
        self.current_state = normalized_initial

        # 创建并启动算法
        self._algorithm = ObservableHopfieldAlgorithm(
            observer=self,
            ui_refresh_interval=self.ui_refresh_interval,
            patterns=normalized_patterns,
            initial_state=normalized_initial,
            total_iterations=int(self.total_iterations),
            update_mode=str(self.update_mode),
        )
        self._algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_hopfield_algorithm(self):
        """停止Hopfield网络"""
        if self._algorithm and self._algorithm.is_alive():
            self._algorithm.stop()
            self._algorithm.join()
        self._algorithm = None
        self.has_finished = True

    @PyQt5.QtCore.pyqtSlot(list)
    def add_pattern(self, pattern):
        """添加新模式"""
        if len(pattern) > 0:
            current_patterns = list(self.patterns)
            current_patterns.append(list(pattern))
            self.patterns = current_patterns

    @PyQt5.QtCore.pyqtSlot(int)
    def remove_pattern(self, index):
        """删除模式"""
        current_patterns = list(self.patterns)
        if 0 <= index < len(current_patterns):
            current_patterns.pop(index)
            self.patterns = current_patterns

    @PyQt5.QtCore.pyqtSlot()
    def clear_patterns(self):
        """清除所有模式"""
        self.patterns = []

    @PyQt5.QtCore.pyqtSlot(list)
    def set_initial_state(self, state):
        """设置初始状态"""
        self.initial_state = list(state)

    @PyQt5.QtCore.pyqtSlot(list)
    def add_noise_to_pattern(self, pattern_index):
        """给指定模式添加噪声作为初始状态"""
        patterns_list = list(self.patterns)
        if 0 <= pattern_index < len(patterns_list):
            import random
            pattern = patterns_list[pattern_index]
            noisy_state = pattern.copy()
            # Flip 20% of bits
            n_flips = max(1, len(pattern) // 5)
            indices = random.sample(range(len(pattern)), n_flips)
            for idx in indices:
                noisy_state[idx] = 1 - noisy_state[idx]
            self.initial_state = noisy_state

    @staticmethod
    def _normalize_patterns(patterns):
        """规范化模式列表"""
        if not patterns or len(patterns) == 0:
            # 提供默认模式
            return [[1, 1, 1, 1, 0, 0, 0, 0], [0, 0, 0, 0, 1, 1, 1, 1]]
        
        normalized = []
        for pattern in patterns:
            normalized.append([1 if bool(x) else 0 for x in pattern])
        return normalized

    @staticmethod
    def _normalize_state(state):
        """规范化状态向量"""
        return [1 if bool(x) else 0 for x in state]


class ObservableHopfieldAlgorithm(Observable, HopfieldAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self._ui_refresh_interval = ui_refresh_interval
        self._has_initialized = False
        Observable.__init__(self, observer)
        HopfieldAlgorithm.__init__(self, **kwargs)
        self._has_initialized = True

        # 推送初始快照到UI
        self.notify('current_state', self.neuron_state)
        self.notify('current_energy', self.current_energy)
        self.notify('weight_matrix', self.weights)
        self.notify('state_history', self._serialize_history())
        self.notify('energy_history', self.energy_history)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if getattr(self, '_has_initialized', False):
            if name in {'attractor_state', 'attractor_iteration', 'attractor_energy', 'converged'}:
                self.notify(name, value)

    def run(self):
        """运行Hopfield算法并通知UI更新"""
        self.notify('has_finished', False)
        super().run()
        
        # 算法完成后，发送最终状态
        self.notify('state_history', self._serialize_history())
        self.notify('energy_history', self.energy_history)
        self.notify('current_state', self.neuron_state)
        self.notify('current_energy', self.current_energy)
        self.notify('pattern_similarities', self.get_pattern_similarity())
        self.notify('detected_attractors', self.detect_attractors())
        self.notify('has_finished', True)

    def _record_snapshot(self):
        """记录快照并通知UI"""
        snapshot = super()._record_snapshot()
        if self._has_initialized:
            self.notify('current_iterations', snapshot['iteration'])
            self.notify('current_state', snapshot['state'])
            self.notify('current_energy', snapshot['energy'])
            self.notify('state_history', self._serialize_history())
            self.notify('energy_history', self.energy_history)
            self.notify('pattern_similarities', self.get_pattern_similarity())
            time.sleep(max(self._ui_refresh_interval, 0))
        return snapshot

    def _serialize_history(self):
        """序列化历史记录用于UI显示"""
        serialized = []
        for entry in self.state_history:
            serialized.append({
                'iteration': int(entry['iteration']),
                'state': [int(x) for x in entry['state']],
                'energy': float(entry['energy']),
            })
        return serialized
