import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import ttk
import math

class GradientDescentVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("梯度下降算法可视化")
        self.root.geometry("1400x900")
        
        # 优化算法参数
        self.learning_rate = 0.1
        self.max_iterations = 50
        self.epsilon = 1e-6
        
        # 当前选择的函数
        self.function_type = "rosenbrock"  # 默认函数
        
        # 算法结果存储
        self.results = {}
        
        # 创建界面
        self.setup_ui()
        
        # 初始化可视化
        self.initialize_visualization()
        
    def setup_ui(self):
        # 主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 控制面板
        control_frame = tk.LabelFrame(main_frame, text="控制面板", padx=10, pady=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 函数选择框架
        function_frame = tk.Frame(control_frame)
        function_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(function_frame, text="目标函数:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        self.function_var = tk.StringVar(value="rosenbrock")
        function_combo = ttk.Combobox(function_frame, textvariable=self.function_var, 
                                     values=["rosenbrock", "himmelblau", "sphere"], 
                                     state="readonly", width=15)
        function_combo.pack(pady=2)
        function_combo.bind("<<ComboboxSelected>>", self.on_function_change)
        
        # 参数设置框架
        param_frame = tk.Frame(control_frame)
        param_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(param_frame, text="算法参数:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        # 学习率设置
        lr_frame = tk.Frame(param_frame)
        lr_frame.pack(pady=2)
        tk.Label(lr_frame, text="学习率:").pack(side=tk.LEFT)
        self.lr_entry = tk.Entry(lr_frame, width=10)
        self.lr_entry.insert(0, str(self.learning_rate))
        self.lr_entry.pack(side=tk.LEFT, padx=(5, 0))
        
        # 最大迭代次数设置
        iter_frame = tk.Frame(param_frame)
        iter_frame.pack(pady=2)
        tk.Label(iter_frame, text="最大迭代:").pack(side=tk.LEFT)
        self.iter_entry = tk.Entry(iter_frame, width=10)
        self.iter_entry.insert(0, str(self.max_iterations))
        self.iter_entry.pack(side=tk.LEFT, padx=(5, 0))
        
        # 算法控制框架
        algo_frame = tk.Frame(control_frame)
        algo_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Label(algo_frame, text="算法控制:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        # 算法选择按钮
        button_frame = tk.Frame(algo_frame)
        button_frame.pack(pady=2)
        
        run_all_button = tk.Button(button_frame, text="运行所有算法", command=self.run_all_algorithms)
        run_all_button.pack(side=tk.LEFT, padx=(0, 5))
        
        clear_button = tk.Button(button_frame, text="清空轨迹", command=self.clear_trajectories)
        clear_button.pack(side=tk.LEFT, padx=(0, 5))
        
        update_params_button = tk.Button(button_frame, text="更新参数", command=self.update_parameters)
        update_params_button.pack(side=tk.LEFT)
        
        # 显示区域
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # 图形显示区域
        plot_frame = tk.LabelFrame(display_frame, text="优化过程可视化", padx=10, pady=10)
        plot_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # 创建matplotlib图形
        self.fig, self.ax = plt.subplots(figsize=(8, 6))
        self.canvas = FigureCanvasTkAgg(self.fig, plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 收敛曲线区域
        convergence_frame = tk.LabelFrame(display_frame, text="收敛曲线", padx=10, pady=10)
        convergence_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.conv_fig, self.conv_ax = plt.subplots(figsize=(6, 6))
        self.conv_canvas = FigureCanvasTkAgg(self.conv_fig, convergence_frame)
        self.conv_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 信息显示区域
        info_frame = tk.Frame(main_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # 算法说明
        explanation_frame = tk.LabelFrame(info_frame, text="算法说明", padx=10, pady=10)
        explanation_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        explanation_text = tk.Text(explanation_frame, height=10, wrap=tk.WORD)
        explanation_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = tk.Scrollbar(explanation_frame, command=explanation_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        explanation_text.config(yscrollcommand=scrollbar.set)
        
        # 插入算法说明
        explanation = """三种梯度下降算法比较:

1. 最速下降法 (Steepest Descent)
   - 原理: 沿着目标函数梯度的负方向进行搜索
   - 更新公式: x_{k+1} = x_k - α∇f(x_k)
   - 优点: 简单易实现，收敛性有保证
   - 缺点: 收敛速度慢，容易出现锯齿现象

2. 牛顿法 (Newton's Method)
   - 原理: 利用目标函数的二阶导数信息构造二次模型进行优化
   - 更新公式: x_{k+1} = x_k - [∇²f(x_k)]^(-1)∇f(x_k)
   - 优点: 收敛速度快，具有二次收敛性
   - 缺点: 需要计算和存储Hessian矩阵，计算量大

3. 非线性共轭梯度法 (Nonlinear Conjugate Gradient)
   - 原理: 结合最速下降法和共轭方向法的思想
   - 更新公式: 
     - 搜索方向: d_k = -g_k + β_k * d_{k-1}
     - 参数更新: x_{k+1} = x_k + α_k * d_k
   - 优点: 不需要计算Hessian矩阵，收敛速度介于最速下降法和牛顿法之间
   - 缺点: 方向更新公式有多种选择，实现相对复杂

目标函数说明:
- Rosenbrock函数: f(x,y) = (1-x)² + 100(y-x²)²，是非凸函数，常用于测试优化算法
- Himmelblau函数: f(x,y) = (x²+y-11)² + (x+y²-7)²，有多个局部极小值点
- Sphere函数: f(x,y) = x² + y²，是凸函数，全局最小值在原点"""
        
        explanation_text.insert(tk.END, explanation)
        explanation_text.config(state=tk.DISABLED)
        
        # 日志信息
        log_frame = tk.LabelFrame(info_frame, text="运行日志", padx=10, pady=10)
        log_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=10)
        self.log_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
        
        # 算法结果
        result_frame = tk.LabelFrame(info_frame, text="算法结果", padx=10, pady=10)
        result_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        self.result_text = tk.Text(result_frame, height=10)
        self.result_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        result_scrollbar = tk.Scrollbar(result_frame, command=self.result_text.yview)
        result_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.result_text.config(yscrollcommand=result_scrollbar.set)
        
    def log_message(self, message):
        """添加日志信息"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        
    def update_parameters(self):
        """更新算法参数"""
        try:
            self.learning_rate = float(self.lr_entry.get())
            self.max_iterations = int(self.iter_entry.get())
            self.log_message(f"参数已更新 - 学习率: {self.learning_rate}, 最大迭代: {self.max_iterations}")
        except ValueError:
            self.log_message("错误: 请输入有效的参数值")
            
    def on_function_change(self, event=None):
        """当函数选择改变时"""
        self.function_type = self.function_var.get()
        self.initialize_visualization()
        self.log_message(f"目标函数已切换为: {self.function_type}")
        
    def initialize_visualization(self):
        """初始化可视化"""
        self.ax.clear()
        
        # 根据选择的函数定义目标函数和梯度
        if self.function_type == "rosenbrock":
            # Rosenbrock函数
            def f(x, y):
                return (1 - x)**2 + 100 * (y - x**2)**2
                
            x_range = np.linspace(-2, 2, 100)
            y_range = np.linspace(-1, 3, 100)
        elif self.function_type == "himmelblau":
            # Himmelblau函数
            def f(x, y):
                return (x**2 + y - 11)**2 + (x + y**2 - 7)**2
                
            x_range = np.linspace(-5, 5, 100)
            y_range = np.linspace(-5, 5, 100)
        else:  # sphere
            # Sphere函数
            def f(x, y):
                return x**2 + y**2
                
            x_range = np.linspace(-3, 3, 100)
            y_range = np.linspace(-3, 3, 100)
            
        X, Y = np.meshgrid(x_range, y_range)
        Z = f(X, Y)
        
        # 绘制等高线
        contour = self.ax.contour(X, Y, Z, levels=20, alpha=0.6)
        self.ax.clabel(contour, inline=True, fontsize=8)
        
        # 绘制3D表面图的投影
        self.ax.contourf(X, Y, Z, levels=20, alpha=0.3, cmap='viridis')
        
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_title(f'{self.function_type.capitalize()}函数优化过程')
        self.ax.grid(True, alpha=0.3)
        
        self.canvas.draw()
        
        # 清空收敛曲线图
        self.conv_ax.clear()
        self.conv_ax.set_xlabel('迭代次数')
        self.conv_ax.set_ylabel('函数值')
        self.conv_ax.set_title('收敛曲线')
        self.conv_ax.grid(True, alpha=0.3)
        self.conv_canvas.draw()
        
        # 清空结果
        self.results = {}
        self.result_text.delete(1.0, tk.END)
        
    def clear_trajectories(self):
        """清空轨迹"""
        self.initialize_visualization()
        self.log_message("轨迹已清空")
        
    def rosenbrock_function(self, x):
        """Rosenbrock函数"""
        return (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2
    
    def rosenbrock_gradient(self, x):
        """Rosenbrock函数梯度"""
        df_dx0 = -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0]**2)
        df_dx1 = 200 * (x[1] - x[0]**2)
        return np.array([df_dx0, df_dx1])
    
    def rosenbrock_hessian(self, x):
        """Rosenbrock函数Hessian矩阵"""
        d2f_dx02 = 2 - 400 * (x[1] - 3 * x[0]**2)
        d2f_dx0dx1 = -400 * x[0]
        d2f_dx1dx0 = -400 * x[0]
        d2f_dx12 = 200
        return np.array([[d2f_dx02, d2f_dx0dx1], 
                         [d2f_dx1dx0, d2f_dx12]])
    
    def himmelblau_function(self, x):
        """Himmelblau函数"""
        return (x[0]**2 + x[1] - 11)**2 + (x[0] + x[1]**2 - 7)**2
    
    def himmelblau_gradient(self, x):
        """Himmelblau函数梯度"""
        df_dx0 = 2 * (x[0]**2 + x[1] - 11) * 2 * x[0] + 2 * (x[0] + x[1]**2 - 7)
        df_dx1 = 2 * (x[0]**2 + x[1] - 11) + 2 * (x[0] + x[1]**2 - 7) * 2 * x[1]
        return np.array([df_dx0, df_dx1])
    
    def sphere_function(self, x):
        """Sphere函数"""
        return x[0]**2 + x[1]**2
    
    def sphere_gradient(self, x):
        """Sphere函数梯度"""
        return 2 * x
    
    def sphere_hessian(self, x):
        """Sphere函数Hessian矩阵"""
        return np.array([[2.0, 0.0], 
                         [0.0, 2.0]])
    
    def get_function_components(self):
        """根据选择的函数返回函数、梯度和Hessian矩阵"""
        if self.function_type == "rosenbrock":
            return self.rosenbrock_function, self.rosenbrock_gradient, self.rosenbrock_hessian
        elif self.function_type == "himmelblau":
            return self.himmelblau_function, self.himmelblau_gradient, None
        else:  # sphere
            return self.sphere_function, self.sphere_gradient, self.sphere_hessian
    
    def steepest_descent(self, x0):
        """最速下降法"""
        f, grad_f, _ = self.get_function_components()
        
        x = np.array(x0, dtype=float)
        trajectory = [x.copy()]
        values = [f(x)]
        
        for i in range(self.max_iterations):
            # 计算梯度
            g = grad_f(x)
            
            # 检查收敛条件
            if np.linalg.norm(g) < self.epsilon:
                break
                
            # 更新参数
            x = x - self.learning_rate * g
            trajectory.append(x.copy())
            values.append(f(x))
            
        return np.array(trajectory), np.array(values)
    
    def newton_method(self, x0):
        """牛顿法"""
        f, grad_f, hess_f = self.get_function_components()
        
        # 如果没有Hessian矩阵，无法使用牛顿法
        if hess_f is None:
            self.log_message(f"警告: {self.function_type}函数没有实现Hessian矩阵，无法使用牛顿法")
            return np.array([]), np.array([])
        
        x = np.array(x0, dtype=float)
        trajectory = [x.copy()]
        values = [f(x)]
        
        for i in range(self.max_iterations):
            # 计算梯度和Hessian矩阵
            g = grad_f(x)
            H = hess_f(x)
            
            # 检查收敛条件
            if np.linalg.norm(g) < self.epsilon:
                break
                
            # 牛顿更新
            try:
                delta = np.linalg.solve(H, -g)
                x = x + delta
            except np.linalg.LinAlgError:
                # 如果矩阵奇异，使用最速下降法作为备选
                self.log_message("警告: Hessian矩阵奇异，使用最速下降法替代")
                x = x - self.learning_rate * g
                
            trajectory.append(x.copy())
            values.append(f(x))
            
        return np.array(trajectory), np.array(values)
    
    def nonlinear_conjugate_gradient(self, x0):
        """非线性共轭梯度法 (Polak-Ribiere公式)"""
        f, grad_f, _ = self.get_function_components()
        
        x = np.array(x0, dtype=float)
        g = grad_f(x)
        d = -g  # 初始搜索方向
        
        trajectory = [x.copy()]
        values = [f(x)]
        
        for i in range(self.max_iterations):
            # 检查收敛条件
            if np.linalg.norm(g) < self.epsilon:
                break
                
            # 线搜索确定步长（使用固定步长作为简化）
            alpha = self.learning_rate
            
            # 更新参数
            x_new = x + alpha * d
            g_new = grad_f(x_new)
            
            # 计算beta (Polak-Ribiere公式)
            y = g_new - g
            beta = max(0, np.dot(g_new, y) / np.dot(g, g))  # PR公式，确保非负
            
            # 更新搜索方向
            d = -g_new + beta * d
            
            # 更新变量
            x = x_new
            g = g_new
            
            trajectory.append(x.copy())
            values.append(f(x))
            
        return np.array(trajectory), np.array(values)
    
    def run_all_algorithms(self):
        """运行所有算法"""
        self.log_message("开始运行所有算法...")
        
        # 清空之前的轨迹
        self.initialize_visualization()
        
        # 初始点
        if self.function_type == "rosenbrock":
            x0 = np.array([-1.0, 1.0])
        elif self.function_type == "himmelblau":
            x0 = np.array([0.0, 0.0])
        else:  # sphere
            x0 = np.array([2.0, 2.0])
            
        self.log_message(f"初始点: {x0}")
        
        # 定义算法和颜色
        algorithms = [
            ("最速下降法", self.steepest_descent, 'blue'),
            ("牛顿法", self.newton_method, 'red'),
            ("非线性共轭梯度法", self.nonlinear_conjugate_gradient, 'green')
        ]
        
        # 运行每个算法
        for name, algorithm, color in algorithms:
            try:
                trajectory, values = algorithm(x0)
                if len(trajectory) > 0:
                    self.results[name] = {
                        'trajectory': trajectory,
                        'values': values,
                        'final_point': trajectory[-1],
                        'final_value': values[-1],
                        'iterations': len(trajectory) - 1
                    }
                    
                    # 绘制轨迹
                    self.ax.plot(trajectory[:, 0], trajectory[:, 1], 
                                color=color, marker='o', markersize=4, 
                                linewidth=2, label=f'{name}')
                    
                    # 绘制收敛曲线
                    self.conv_ax.plot(range(len(values)), values, 
                                     color=color, marker='o', markersize=4, 
                                     linewidth=2, label=f'{name}')
                    
                    self.log_message(f"{name}完成 - 迭代次数: {len(trajectory)-1}, 最终函数值: {values[-1]:.6f}")
                else:
                    self.log_message(f"{name}未运行")
            except Exception as e:
                self.log_message(f"{name}运行出错: {str(e)}")
        
        # 更新图例
        self.ax.legend()
        self.conv_ax.legend()
        
        # 刷新图形
        self.canvas.draw()
        self.conv_canvas.draw()
        
        # 显示结果
        self.display_results()
        
    def display_results(self):
        """显示算法结果"""
        self.result_text.delete(1.0, tk.END)
        
        if not self.results:
            self.result_text.insert(tk.END, "暂无结果\n")
            return
            
        self.result_text.insert(tk.END, f"目标函数: {self.function_type.capitalize()}\n")
        self.result_text.insert(tk.END, "="*50 + "\n\n")
        
        for name, result in self.results.items():
            self.result_text.insert(tk.END, f"{name}:\n")
            self.result_text.insert(tk.END, f"  最终点: [{result['final_point'][0]:.6f}, {result['final_point'][1]:.6f}]\n")
            self.result_text.insert(tk.END, f"  最终函数值: {result['final_value']:.6f}\n")
            self.result_text.insert(tk.END, f"  迭代次数: {result['iterations']}\n\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = GradientDescentVisualizer(root)
    root.mainloop()