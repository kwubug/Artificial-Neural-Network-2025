import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib

# ---- 中文字体 ----
matplotlib.rcParams['font.sans-serif'] = [
    'Microsoft YaHei', 'SimHei', 'Noto Sans CJK SC', 'Arial Unicode MS', 'DejaVu Sans'
]
matplotlib.rcParams['axes.unicode_minus'] = False


# -------------------- 数学与网络工具 --------------------
def sigmoid(a: np.ndarray):
    return 1.0 / (1.0 + np.exp(-a))


def sigmoid_deri(y: np.ndarray):
    return y * (1.0 - y)


def pack_params(W1, W2):
    # 展平顺序：先 W2（行优先），再 W1 —— 与前面一致
    return np.concatenate([W2.ravel(), W1.ravel()])


def unpack_params(p, W1_shape, W2_shape):
    s2 = W2_shape[0] * W2_shape[1]
    W2 = p[:s2].reshape(W2_shape)
    W1 = p[s2:].reshape(W1_shape)
    return W1, W2


def forward_backprop(W1, W2, x, d):
    """
    单次前向 + 反向，返回：
      o, E, grad_W1, grad_W2 （注意这里的 grad 是“真·梯度”∂E/∂W）
    """
    # 前向
    net_y = W1 @ x
    y = sigmoid(net_y)
    z = np.concatenate([[-1.0], y])
    net_o = W2 @ z
    o = sigmoid(net_o)

    # 损失
    E = 0.5 * np.sum((d - o) ** 2)

    # 反向
    fprime_h = sigmoid_deri(y)
    fprime_o = sigmoid_deri(o)
    delta_o = (d - o) * fprime_o                 # (M,)
    W2_no_bias = W2[:, 1:]                       # (M, H)
    delta_y = (W2_no_bias.T @ delta_o) * fprime_h  # (H,)

    # 真·梯度（注意符号）：
    # ∂E/∂W2 = - delta_o ⊗ z
    # ∂E/∂W1 = - delta_y ⊗ x
    grad_W2 = -np.outer(delta_o, z)
    grad_W1 = -np.outer(delta_y, x)

    return o, E, grad_W1, grad_W2


def bp_1step(W1, W2, x, d, eta, optimizer='gd', newton_damping=1e-9):
    """
    单步训练：
      - optimizer='gd'：最速下降法（与你原更新式一致）
      - optimizer='newton'：Gauss-Newton 近似（牛顿法）
    说明：CG 在训练循环里实现（需要跨步保存方向与上一步梯度），这里不处理。
    """
    # 前向
    net_y = W1 @ x
    y = sigmoid(net_y)
    z = np.concatenate([[-1.0], y])
    net_o = W2 @ z
    o = sigmoid(net_o)

    # 损失
    E = 0.5 * np.sum((d - o) ** 2)

    fprime_h = sigmoid_deri(y)
    fprime_o = sigmoid_deri(o)

    if optimizer == 'gd':
        # 最速下降（与你之前一致）
        delta_o = (d - o) * fprime_o
        W2_no_bias = W2[:, 1:]
        delta_y = (W2_no_bias.T @ delta_o) * fprime_h

        dW2 = eta * np.outer(delta_o, z)
        dW1 = eta * np.outer(delta_y, x)
        return W1 + dW1, W2 + dW2, o, E

    elif optimizer == 'newton':
        # Gauss-Newton：H ≈ J^T J,  g = J^T (o - d)
        H, N_in = W1.shape
        M, Hp1 = W2.shape
        assert Hp1 == H + 1

        P = M * (H + 1) + H * N_in
        J = np.zeros((M, P), dtype=float)

        # 对 W2 分块：∂o_k/∂W2[k,j] = fprime_o[k]*z[j]
        offset = 0
        for k in range(M):
            J[k, offset + k * (H + 1): offset + (k + 1) * (H + 1)] = fprime_o[k] * z
        offset += M * (H + 1)

        # 对 W1 分块：∂o_k/∂W1[h,i] = fprime_o[k]*W2[k,1+h]*fprime_h[h]*x[i]
        for h in range(H):
            for i in range(N_in):
                col = offset + h * N_in + i
                J[:, col] = fprime_o * W2[:, 1 + h] * fprime_h[h] * x[i]

        g = J.T @ (o - d)        # 梯度（按参数向量）
        Hgn = J.T @ J            # 近似 Hessian
        Hgn += newton_damping * np.eye(P)

        step = np.linalg.solve(Hgn, g)
        pvec = pack_params(W1, W2)
        p_new = pvec - eta * step   # eta 作为步长/阻尼
        W1_new, W2_new = unpack_params(p_new, W1.shape, W2.shape)
        return W1_new, W2_new, o, E

    else:
        raise ValueError("optimizer must be 'gd' or 'newton'")


# -------------------- GUI 应用 --------------------
class BPTrainerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BP 训练可视化（最速下降 / 牛顿法 / 共轭梯度法） - Tkinter")
        self.geometry("1180x640")

        # 状态
        self.running = False
        self.train_thread = None

        # 默认数据（与你的 Python 示例一致）
        self.W1_init = np.array([[3., 1., -2.],
                                 [-1., 2., 0.]], dtype=float)
        self.W2_init = np.array([[-2., 1., 0.],
                                 [3., 1., -2.]], dtype=float)
        self.x = np.array([-1., 1., 3.], dtype=float)
        self.d = np.array([0.95, 0.05], dtype=float)

        # 历史数据（UI 线程读，训练线程写）
        self.E_hist = []
        self.O_hist = []  # [(o0,o1), ...]
        self.curr_loss = None
        self.curr_iter = 0

        # —— 慢速可视化参数 ——（更易读）
        self.ui_interval_ms = 200   # UI刷新：200ms 一次
        self.live_refresh = 1       # 每1步记录一次
        self.slowdown_ms = 1        # 每次记录后的停顿

        self._build_ui()
        # 定时刷新图像/数值
        self.after(self.ui_interval_ms, self._refresh_plots)

    def _build_ui(self):
        # 顶部控制条
        ctrl = ttk.Frame(self)
        ctrl.pack(side=tk.TOP, fill=tk.X, padx=10, pady=8)

        # 学习率
        ttk.Label(ctrl, text="学习率 η:").grid(row=0, column=0, sticky="w")
        self.eta_var = tk.StringVar(value="0.5")
        ttk.Entry(ctrl, textvariable=self.eta_var, width=12).grid(row=0, column=1, padx=6)

        # 最大迭代
        ttk.Label(ctrl, text="最大迭代次数:").grid(row=0, column=2, sticky="w", padx=(12, 0))
        self.maxiters_var = tk.StringVar(value="10000")
        ttk.Entry(ctrl, textvariable=self.maxiters_var, width=12).grid(row=0, column=3, padx=6)

        # 收敛标准
        ttk.Label(ctrl, text="收敛标准 tol:").grid(row=0, column=4, sticky="w", padx=(12, 0))
        self.tol_var = tk.StringVar(value="1e-7")
        ttk.Entry(ctrl, textvariable=self.tol_var, width=12).grid(row=0, column=5, padx=6)

        # 优化算法
        ttk.Label(ctrl, text="优化算法:").grid(row=0, column=6, sticky="w", padx=(12, 0))
        self.opt_var = tk.StringVar(value="最速下降法")
        self.opt_combo = ttk.Combobox(
            ctrl, textvariable=self.opt_var, width=14, state="readonly",
            values=["最速下降法", "牛顿法", "共轭梯度法"]
        )
        self.opt_combo.grid(row=0, column=7, padx=6)

        # 训练按钮
        self.btn_train = ttk.Button(ctrl, text="训练", command=self.start_training)
        self.btn_train.grid(row=0, column=8, padx=(16, 0))

        # 状态栏
        stat = ttk.Frame(self)
        stat.pack(side=tk.TOP, fill=tk.X, padx=10)
        self.iter_label = ttk.Label(stat, text="当前迭代：0")
        self.iter_label.pack(side=tk.LEFT, padx=(0, 20))
        self.loss_label = ttk.Label(stat, text="当前 Loss：-")
        self.loss_label.pack(side=tk.LEFT)

        # 图像区（左右两幅图）
        fig = Figure(figsize=(11.5, 4.8), dpi=100)
        self.ax_out = fig.add_subplot(1, 2, 1)
        self.ax_loss = fig.add_subplot(1, 2, 2)

        self.ax_out.set_title("输出空间收敛轨迹 (o → d)")
        self.ax_out.set_xlabel("x轴")  # ← 改名
        self.ax_out.set_ylabel("y轴")  # ← 改名
        self.ax_out.grid(True)
        # —— 固定显示范围（按你的需求）——
        self.ax_out.set_xlim(0.88, 0.96)
        self.ax_out.set_ylim(0.00, 0.06)

        # 目标点
        self.ax_out.scatter([self.d[0]], [self.d[1]], marker='*', s=120, c='r', label='goal')
        # 轨迹与当前点
        (self.path_line,) = self.ax_out.plot([], [], lw=2, label='trajectory')
        self.curr_scatter = self.ax_out.scatter([], [], s=40, c='k', label='current')
        self.ax_out.legend(loc='best')

        self.ax_loss.set_title("Loss 收敛曲线")
        self.ax_loss.set_xlabel("Iteration")
        self.ax_loss.set_ylabel("Loss (SSE)")
        self.ax_loss.grid(True)
        (self.loss_line,) = self.ax_loss.plot([], [], lw=2)

        canvas = FigureCanvasTkAgg(fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=10, pady=8)
        self.canvas = canvas

    # -------------------- 训练控制 --------------------
    def start_training(self):
        if self.running:
            return
        try:
            eta = float(self.eta_var.get())
            max_iters = int(self.maxiters_var.get())
            tol = float(self.tol_var.get())
        except Exception as e:
            messagebox.showerror("参数错误", f"请检查输入参数：{e}")
            return

        opt_txt = self.opt_var.get()
        if opt_txt == "最速下降法":
            optimizer = 'gd'
        elif opt_txt == "牛顿法":
            optimizer = 'newton'
        else:
            optimizer = 'cg'   # 共轭梯度

        # 初始化状态
        self.running = True
        self.btn_train.configure(state=tk.DISABLED)
        self.E_hist = []
        self.O_hist = []
        self.curr_loss = None
        self.curr_iter = 0

        def _train_loop():
            W1_local = self.W1_init.copy()
            W2_local = self.W2_init.copy()

            # —— CG 需要保存的状态 —— #
            g_prev = None
            p_dir = None

            for it in range(1, max_iters + 1):
                if not self.running:
                    break

                if optimizer == 'cg':
                    # --- 非线性共轭梯度（Fletcher–Reeves + Armijo 回溯 + 重启） ---
                    # 当前点 & 梯度
                    o, E, grad_W1, grad_W2 = forward_backprop(W1_local, W2_local, self.x, self.d)
                    g_vec = np.concatenate([grad_W2.ravel(), grad_W1.ravel()])   # ∂E/∂p（真·梯度）
                    p_vec = pack_params(W1_local, W2_local)

                    # 首个方向或重启：走负梯度
                    if g_prev is None:
                        p_dir = -g_vec
                    else:
                        beta_FR = float(np.dot(g_vec, g_vec) / (np.dot(g_prev, g_prev) + 1e-12))
                        beta_FR = max(0.0, beta_FR)  # 防负数
                        p_dir = -g_vec + beta_FR * p_dir

                    # 若不是下降方向，则重启
                    if np.dot(p_dir, g_vec) >= 0:
                        p_dir = -g_vec

                    # ------ Armijo 回溯线搜索 ------
                    # 目标：E(p + alpha * p_dir) <= E(p) + c1 * alpha * g^T p_dir
                    c1 = 1e-4
                    rho = 0.5
                    alpha = eta  # 以 UI 的 eta 作为初始步长
                    # 简单尺度限制，避免巨步：alpha_max ~ 10 / ||p_dir||
                    dnorm = np.linalg.norm(p_dir)
                    if dnorm > 0:
                        alpha = min(alpha, 10.0 / dnorm)

                    def energy_at(p_try):
                        W1_try, W2_try = unpack_params(p_try, W1_local.shape, W2_local.shape)
                        o_try, E_try, _, _ = forward_backprop(W1_try, W2_try, self.x, self.d)
                        return E_try, o_try

                    # 回溯
                    E0 = E
                    gTp = np.dot(g_vec, p_dir)
                    for _ in range(20):  # 最多回溯 20 次
                        p_try = p_vec + alpha * p_dir
                        E_try, o_try = energy_at(p_try)
                        if E_try <= E0 + c1 * alpha * gTp:
                            # 满足 Armijo
                            E = E_try
                            o = o_try
                            p_vec = p_try
                            break
                        alpha *= rho
                    else:
                        # 线搜索失败：退化为一次小步负梯度，稳妥起见
                        p_vec = p_vec - 1e-3 * g_vec
                        W1_tmp, W2_tmp = unpack_params(p_vec, W1_local.shape, W2_local.shape)
                        o, E, _, _ = forward_backprop(W1_tmp, W2_tmp, self.x, self.d)

                    # 提交参数
                    W1_local, W2_local = unpack_params(p_vec, W1_local.shape, W2_local.shape)
                    g_prev = g_vec.copy()

                else:
                    # 仍用原来的 gd / newton 单步函数
                    W1_local, W2_local, o, E = bp_1step(
                        W1_local, W2_local, self.x, self.d, eta,
                        optimizer=optimizer, newton_damping=1e-9
                    )

                # —— 记录（每步） —— #
                if (it % self.live_refresh == 0) or (E < tol) or (it == max_iters):
                    self.E_hist.append(float(E))
                    self.O_hist.append((float(o[0]), float(o[1])))
                    self.curr_iter = it
                    self.curr_loss = float(E)
                    time.sleep(self.slowdown_ms / 1000.0)

                if E < tol:
                    break

            self.running = False
            self.after(0, lambda: self.btn_train.configure(state=tk.NORMAL))

        self.train_thread = threading.Thread(target=_train_loop, daemon=True)
        self.train_thread.start()

    # -------------------- UI 定时刷新 --------------------
    def _refresh_plots(self):
        # 刷新数值显示
        self.iter_label.config(text=f"当前迭代：{self.curr_iter}")
        if self.curr_loss is None:
            self.loss_label.config(text="当前 Loss：-")
        else:
            try:
                self.loss_label.config(text=f"当前 Loss：{self.curr_loss:.6e}")
            except Exception:
                self.loss_label.config(text=f"当前 Loss：{self.curr_loss}")

        # 刷新图像
        if len(self.E_hist) > 0:
            xdata = np.arange(1, len(self.E_hist) + 1)
            self.loss_line.set_data(xdata, self.E_hist)
            self.ax_loss.relim()
            self.ax_loss.autoscale_view()

        if len(self.O_hist) > 0:
            O = np.array(self.O_hist)
            self.path_line.set_data(O[:, 0], O[:, 1])
            # 更新当前点：先移除旧对象再新建
            self.curr_scatter.remove()
            self.curr_scatter = self.ax_out.scatter([O[-1, 0]], [O[-1, 1]], s=40, c='k')

        self.canvas.draw_idle()
        # UI刷新间隔（200ms）
        self.after(self.ui_interval_ms, self._refresh_plots)


if __name__ == "__main__":
    app = BPTrainerApp()
    app.mainloop()
