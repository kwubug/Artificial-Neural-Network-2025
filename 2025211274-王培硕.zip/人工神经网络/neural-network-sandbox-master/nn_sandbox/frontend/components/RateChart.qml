import QtQuick 2.12
import QtQuick.Controls 2.5
import QtCharts 2.3

ChartView {
    id: chart
    property var bestCorrectRate: LineSeries {
        axisX: xAxis
        axisY: yAxis
        useOpenGL: true
    }
    property var trainingCorrectRate: LineSeries {
        axisX: xAxis
        axisY: yAxis
        useOpenGL: true
    }
    property var testingCorrectRate: LineSeries {
        axisX: xAxis
        axisY: yAxis
        useOpenGL: true
    }

    antialiasing: true
    
    ValueAxis{
        id: xAxis
        titleText: 'Iterations'
        min: 1.0
        max: 2.0
    }
    ValueAxis{
        id: yAxis
        titleText: '重构误差'
        min: 0.0
        max: 2.0
    }

    function updateAxes(point) {
        // 更新x轴范围
        xAxis.max = Math.max(xAxis.max, point.x)
        xAxis.min = Math.min(xAxis.min, point.x)
        
        // 更新y轴范围
        if (point.y !== undefined && !isNaN(point.y)) {
            yAxis.max = Math.max(yAxis.max, point.y * 1.1) // 留出10%的余量
            yAxis.min = Math.min(yAxis.min, point.y * 0.9) // 留出10%的余量
            // 确保最小值不为负（如果数据都是正数）
            if (yAxis.min < 0 && point.y >= 0) {
                yAxis.min = 0
            }
        }
    }

    function reset() {
        removeAllSeries()
        // 创建训练曲线
        trainingCorrectRate = createSeries(
            ChartView.SeriesTypeLine, '当前重构误差', xAxis, yAxis
        )
        trainingCorrectRate.color = 'blue'
        trainingCorrectRate.visible = true
        trainingCorrectRate.pointAdded.connect((index) => {
            updateAxes(trainingCorrectRate.at(index))
        })
        
        // 创建测试曲线
        testingCorrectRate = createSeries(
            ChartView.SeriesTypeLine, '测试重构误差', xAxis, yAxis
        )
        testingCorrectRate.color = 'red'
        testingCorrectRate.visible = true
        testingCorrectRate.pointAdded.connect((index) => {
            updateAxes(testingCorrectRate.at(index))
        })
        
        // 创建最佳曲线
        bestCorrectRate = createSeries(
            ChartView.SeriesTypeLine, '最佳重构误差', xAxis, yAxis
        )
        bestCorrectRate.color = 'green'
        bestCorrectRate.visible = true
        bestCorrectRate.pointAdded.connect((index) => {
            updateAxes(bestCorrectRate.at(index))
        })
        
        // 设置初始范围
        xAxis.max = 10
        xAxis.min = 0
        yAxis.max = 2
        yAxis.min = 0
        
        // 确保图例可见
        legend.visible = true
    }

    Component.onCompleted: reset()
}