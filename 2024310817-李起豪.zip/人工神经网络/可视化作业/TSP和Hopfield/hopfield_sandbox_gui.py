from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from hopfield_async_visualization import (
    HopfieldConfig,
    add_noise,
    asynchronous_update,
    build_patterns,
    export_summary,
    hebbian_weights,
    plot_results,
)


class HopfieldSandboxWindow(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Hopfield 沙箱可视化（异步更新）")
        self.resize(1280, 720)

        self.patterns = build_patterns()
        self.weights = hebbian_weights(self.patterns)
        self.output_dir = Path(__file__).parent

        self.all_states: List[List[np.ndarray]] = []
        self.all_energies: List[List[float]] = []
        self.final_counts: Dict[str, int] = {}
        self.config: HopfieldConfig | None = None

        self._build_ui()
        self.run_simulation()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout()
        self.setLayout(root_layout)

        control_group = QGroupBox("仿真参数设置")
        control_layout = QFormLayout()
        control_group.setLayout(control_layout)

        self.runs_spin = QSpinBox()
        self.runs_spin.setRange(1, 30)
        self.runs_spin.setValue(6)

        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(1, 200)
        self.max_iter_spin.setValue(40)

        self.noise_spin = QDoubleSpinBox()
        self.noise_spin.setRange(0.0, 0.9)
        self.noise_spin.setSingleStep(0.05)
        self.noise_spin.setDecimals(2)
        self.noise_spin.setValue(0.2)

        control_layout.addRow("运行次数", self.runs_spin)
        control_layout.addRow("最大异步迭代步", self.max_iter_spin)
        control_layout.addRow("初态扰动比例", self.noise_spin)

        self.run_selector = QComboBox()
        self.run_selector.currentIndexChanged.connect(self._update_dynamics_view)

        button_row = QHBoxLayout()
        self.run_button = QPushButton("运行仿真")
        self.run_button.clicked.connect(self.run_simulation)
        self.export_button = QPushButton("保存当前结果")
        self.export_button.clicked.connect(self.export_results)
        self.export_button.setEnabled(False)
        button_row.addWidget(self.run_button)
        button_row.addWidget(self.export_button)
        button_row.addStretch(1)
        button_row.addWidget(QLabel("查看运行编号:"))
        button_row.addWidget(self.run_selector)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.status_label.setStyleSheet("color: #1f77b4; font-weight: 600;")

        self.dynamics_canvas = FigureCanvas(Figure(figsize=(8, 4.5), tight_layout=True))
        self.heat_ax = self.dynamics_canvas.figure.add_subplot(1, 2, 1)
        self.energy_ax = self.dynamics_canvas.figure.add_subplot(1, 2, 2)

        self.attractor_canvas = FigureCanvas(Figure(figsize=(6, 4), tight_layout=True))
        self.attractor_ax = self.attractor_canvas.figure.add_subplot(111)

        self.summary_label = QLabel()
        self.summary_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet("font-family: Consolas, 'Source Code Pro', monospace;")

        bottom_layout = QHBoxLayout()
        bottom_layout.addWidget(self.dynamics_canvas, stretch=3)
        bottom_layout.addWidget(self.attractor_canvas, stretch=2)

        summary_group = QGroupBox("结果摘要")
        summary_layout = QVBoxLayout()
        summary_layout.addWidget(self.summary_label)
        summary_group.setLayout(summary_layout)

        root_layout.addWidget(control_group)
        root_layout.addLayout(button_row)
        root_layout.addWidget(self.status_label)
        root_layout.addLayout(bottom_layout)
        root_layout.addWidget(summary_group)

    def run_simulation(self) -> None:
        runs = self.runs_spin.value()
        max_iterations = self.max_iter_spin.value()
        noise_ratio = self.noise_spin.value()

        self.config = HopfieldConfig(
            pattern_shape=(3, 3),
            noise_ratio=noise_ratio,
            runs=runs,
            max_iterations=max_iterations,
        )

        self.all_states = []
        self.all_energies = []
        self.final_counts = {f"图案{idx + 1}": 0 for idx in range(self.patterns.shape[0])}

        for run_idx in range(runs):
            pattern_idx = run_idx % self.patterns.shape[0]
            noisy_state = add_noise(self.patterns[pattern_idx], noise_ratio)
            final_state, states, energies = asynchronous_update(
                state=noisy_state,
                weights=self.weights,
                max_iterations=max_iterations,
            )
            self.all_states.append(states)
            self.all_energies.append(energies)
            similarities = self.patterns @ final_state
            winner = int(np.argmax(similarities))
            self.final_counts[f"图案{winner + 1}"] += 1

        self.run_selector.blockSignals(True)
        self.run_selector.clear()
        for idx in range(runs):
            self.run_selector.addItem(f"运行 {idx + 1}")
        self.run_selector.setCurrentIndex(0)
        self.run_selector.blockSignals(False)

        self._update_dynamics_view(0)
        self._update_attractor_view()
        self._update_summary()

        self.export_button.setEnabled(True)
        self.status_label.setText("仿真完成，可切换运行编号查看详细演化，或导出图像与摘要。")

    def export_results(self) -> None:
        if not (self.config and self.all_states and self.all_energies):
            self.status_label.setText("暂无可导出的结果，请先运行仿真。")
            return

        plot_results(
            all_states=self.all_states,
            all_energies=self.all_energies,
            final_counts=self.final_counts,
            config=self.config,
            output_path=self.output_dir / "hopfield_async_dynamics.png",
        )
        export_summary(
            summary_path=self.output_dir / "hopfield_summary.txt",
            final_counts=self.final_counts,
            all_energies=self.all_energies,
        )
        self.status_label.setText(
            "结果已保存：hopfield_async_dynamics.png、hopfield_attractor_hist.png、hopfield_summary.txt"
        )

    def _update_dynamics_view(self, index: int) -> None:
        if index < 0 or index >= len(self.all_states) or not self.config:
            self.dynamics_canvas.draw_idle()
            return

        states = self.all_states[index]
        energies = self.all_energies[index]

        matrix = np.stack([state.reshape(self.config.pattern_shape) for state in states])
        self.heat_ax.clear()
        im = self.heat_ax.imshow(
            matrix.reshape(len(states), -1),
            aspect="auto",
            cmap="coolwarm",
            vmin=-1,
            vmax=1,
        )
        self.heat_ax.set_title(f"运行 {index + 1} 状态演化")
        self.heat_ax.set_xlabel("神经元索引")
        self.heat_ax.set_ylabel("迭代步")
        self.heat_ax.figure.colorbar(im, ax=self.heat_ax, orientation="vertical", fraction=0.046, pad=0.04)

        self.energy_ax.clear()
        self.energy_ax.plot(range(len(energies)), energies, color="#1f77b4", linewidth=1.2)
        self.energy_ax.set_title("能量变化")
        self.energy_ax.set_xlabel("迭代步")
        self.energy_ax.set_ylabel("能量")
        self.energy_ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

        self.dynamics_canvas.draw_idle()

    def _update_attractor_view(self) -> None:
        labels = list(self.final_counts.keys())
        values = [self.final_counts[label] for label in labels]
        x = np.arange(len(labels))

        self.attractor_ax.clear()
        self.attractor_ax.bar(x, values, color="#2ca02c")
        self.attractor_ax.set_xticks(x)
        self.attractor_ax.set_xticklabels(labels)
        self.attractor_ax.set_xlabel("吸引子")
        self.attractor_ax.set_ylabel("收敛次数")
        self.attractor_ax.set_title("吸引子统计")
        self.attractor_ax.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.5)
        self.attractor_canvas.draw_idle()

    def _update_summary(self) -> None:
        if not (self.config and self.all_energies):
            self.summary_label.setText("")
            return

        total_runs = sum(self.final_counts.values())
        min_energy = min(min(seq) for seq in self.all_energies)
        max_energy = max(max(seq) for seq in self.all_energies)
        lines = [
            "Hopfield 异步更新仿真摘要",
            f"运行次数: {total_runs}",
            f"最大迭代步: {self.config.max_iterations}",
            f"初态扰动比例: {self.config.noise_ratio:.2f}",
            f"能量范围: [{min_energy:.3f}, {max_energy:.3f}]",
            "",
            "吸引子统计:",
        ]
        for label, count in self.final_counts.items():
            lines.append(f"  {label}: {count} 次")
        self.summary_label.setText("\n".join(lines))


def main() -> None:
    app = QApplication(sys.argv)
    window = HopfieldSandboxWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


