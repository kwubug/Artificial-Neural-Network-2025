import numpy as np


class Perceptron:
    def __init__(self, activation_function, input_size=None):
        self._data: np.ndarray = None
        self.synaptic_weight: np.ndarray = None
        self.activation_function = activation_function

        # 如果传入了 input_size，则立即初始化权重
        if input_size is not None:
            # +1 是因为感知机通常要包含偏置项
            self.synaptic_weight = np.random.uniform(-1, 1, input_size + 1)

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        if self._data is None:
            self._data = value
            self._data = np.insert(self._data, 0, -1)  # 加入偏置输入
        else:
            self._data[1:] = value

        if self.synaptic_weight is None:
            self.synaptic_weight = np.random.uniform(-1, 1, len(self.data))

    @property
    def result(self):
        return self.activation_function(np.dot(self.synaptic_weight, self.data))

    # 供 BpAlgorithm 用
    def activate(self, inputs):
        self.data = inputs
        return self.result
