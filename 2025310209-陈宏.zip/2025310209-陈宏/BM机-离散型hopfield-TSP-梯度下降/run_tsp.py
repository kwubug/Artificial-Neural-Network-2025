import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer
from tsp_model import TSPSolver


def main():
    print("🚀 TSP旅行商问题可视化启动...")

    # 创建应用
    app = QApplication(sys.argv)

    # 创建TSP求解器
    tsp_solver = TSPSolver(15)  # 15个城市

    # 创建并显示主窗口
    from tsp_pure_pyqt5 import TSPVisualizer
    window = TSPVisualizer(tsp_solver)
    window.show()

    print("✅ TSP问题可视化启动成功！")
    print("   算法: 模拟退火")
    print("   城市数量: 15")
    print("   优化目标: 寻找最短路径")

    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())