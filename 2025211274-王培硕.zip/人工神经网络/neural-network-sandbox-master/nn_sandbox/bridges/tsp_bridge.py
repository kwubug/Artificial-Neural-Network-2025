import time

import PyQt5.QtCore

from . import Bridge, BridgeProperty
from .observer import Observable


class TSPBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    max_iterations = BridgeProperty(1000)
    learning_rate = BridgeProperty(0.2)
    temperature = BridgeProperty(100.0)
    cooling_rate = BridgeProperty(0.99)
    method = BridgeProperty('simulated_annealing')
    current_iterations = BridgeProperty(0)
    current_distance = BridgeProperty(0.0)
    best_distance = BridgeProperty(float('inf'))
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.tsp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_tsp_algorithm(self):
        self.tsp_algorithm = ObservableTSPAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict.get(self.current_dataset_name, []),
            max_iterations=self.max_iterations,
            learning_rate=self.learning_rate,
            temperature=self.temperature,
            cooling_rate=self.cooling_rate,
            method=self.method
        )
        self.tsp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp_algorithm(self):
        if self.tsp_algorithm:
            self.tsp_algorithm.stop()


class ObservableTSPAlgorithm(Observable):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        # 使用super().__setattr__设置初始值，避免递归调用
        super().__setattr__('ui_refresh_interval', ui_refresh_interval)
        super().__setattr__('dataset', kwargs.get('dataset', []))
        super().__setattr__('max_iterations', kwargs.get('max_iterations', 1000))
        super().__setattr__('learning_rate', kwargs.get('learning_rate', 0.2))
        super().__setattr__('temperature', kwargs.get('temperature', 100.0))
        super().__setattr__('cooling_rate', kwargs.get('cooling_rate', 0.99))
        super().__setattr__('method', kwargs.get('method', 'simulated_annealing'))
        super().__setattr__('current_iterations', 0)
        super().__setattr__('current_distance', 0.0)
        super().__setattr__('best_distance', float('inf'))
        super().__setattr__('_stop', False)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 通知观察者特定属性的变化
        if name in ('current_iterations', 'current_distance', 'best_distance'):
            self.notify(name, value)

    def start(self):
        import threading
        self._thread = threading.Thread(target=self.run)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop = True

    def run(self):
        from ..backend.algorithms.tsp_algorithm import TSPAlgorithm
        
        self.notify('has_finished', False)
        
        # 初始化TSP算法
        if self.dataset:
            tsp = TSPAlgorithm(
                cities=self.dataset,
                learning_rate=self.learning_rate,
                temperature=self.temperature,
                cooling_rate=self.cooling_rate
            )
            
            # 求解TSP
            best_path, best_distance = tsp.solve_tsp(
                method=self.method,
                max_iterations=self.max_iterations
            )
            
            # 更新进度
            total_steps = len(tsp.distance_history)
            for i, distance in enumerate(tsp.distance_history):
                if self._stop:
                    break
                    
                self.current_iterations = i
                self.current_distance = distance
                
                if distance < self.best_distance:
                    self.best_distance = distance
                    self.notify('best_distance', self.best_distance)
                
                self.notify('current_iterations', self.current_iterations)
                self.notify('current_distance', self.current_distance)
                
                # 模拟延迟
                time.sleep(self.ui_refresh_interval)
        
        self.notify('has_finished', True)