import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.gridspec import GridSpec
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False


class OLSVisualizer:
    def __init__(self):
        self.x, self.y, self.true_params = self.generate_data()

        self.w = np.random.randn() * 0.5
        self.b = np.random.randn() * 0.5

        self.learning_rate = 0.01
        self.iterations = 200

        self.loss_history = []
        self.w_history = [self.w]
        self.b_history = [self.b]

        self.fig = plt.figure(figsize=(12, 10))
        self.gs = GridSpec(2, 2, figure=self.fig)

        self.ax1 = self.fig.add_subplot(self.gs[0, 0])
        self.ax2 = self.fig.add_subplot(self.gs[0, 1])
        self.ax3 = self.fig.add_subplot(self.gs[1, :])

        self.init_plots()

    def generate_data(self, n=50, seed=42):
        """生成带噪声的线性数据"""
        np.random.seed(seed)
        x = np.linspace(0, 10, n)
        true_w = 2.5
        true_b = 3.0
        y = true_w * x + true_b + np.random.normal(0, 1.5, n)
        return x, y, (true_w, true_b)

    def compute_loss(self, y_pred):
        """计算均方误差损失"""
        return np.mean((self.y - y_pred) ** 2)

    def gradient_descent_step(self):
        """梯度下降更新参数"""
        y_pred = self.w * self.x + self.b

        dw = -2 * np.mean(self.x * (self.y - y_pred))
        db = -2 * np.mean(self.y - y_pred)

        self.w -= self.learning_rate * dw
        self.b -= self.learning_rate * db

        self.w_history.append(self.w)
        self.b_history.append(self.b)
        self.loss_history.append(self.compute_loss(y_pred))

        return y_pred

    def init_plots(self):
        """初始化所有子图"""
        self.ax1.set_title('数据与拟合直线')
        self.ax1.set_xlabel('x')
        self.ax1.set_ylabel('y')
        self.ax1.scatter(self.x, self.y, color='blue', alpha=0.6, label='数据点')
        self.line, = self.ax1.plot([], [], 'r-', linewidth=2, label='拟合直线')
        self.param_text = self.ax1.text(0.05, 0.95, '', transform=self.ax1.transAxes,
                                        verticalalignment='top',
                                        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        self.ax1.legend()

        self.ax2.set_title('损失函数变化')
        self.ax2.set_xlabel('迭代次数')
        self.ax2.set_ylabel('均方误差')
        self.loss_line, = self.ax2.plot([], [], 'g-', linewidth=2)

        self.ax3.set_title('参数空间优化轨迹')
        self.ax3.set_xlabel('斜率 (w)')
        self.ax3.set_ylabel('截距 (b)')
        true_w, true_b = self.true_params
        self.ax3.scatter(true_w, true_b, color='green', s=100, marker='*', label='真实参数')
        self.param_trace, = self.ax3.plot([], [], 'm-', linewidth=1.5, alpha=0.7)
        self.current_param, = self.ax3.plot([], [], 'ro', markersize=6)
        self.ax3.legend()

    def update(self, i):
        """更新动画帧"""

        y_pred = self.gradient_descent_step()

        self.line.set_data(self.x, y_pred)

        self.param_text.set_text(f'w = {self.w:.4f}\nb = {self.b:.4f}')

        self.loss_line.set_data(range(len(self.loss_history)), self.loss_history)
        self.ax2.relim()
        self.ax2.autoscale_view()

        self.param_trace.set_data(self.w_history, self.b_history)
        self.current_param.set_data([self.w], [self.b])
        self.ax3.relim()
        self.ax3.autoscale_view()

        return self.line, self.loss_line, self.param_trace, self.current_param, self.param_text

    def show(self):
        """显示动画"""
        ani = FuncAnimation(
            self.fig, self.update,
            frames=self.iterations,
            interval=50,
            blit=True
        )
        plt.tight_layout()
        plt.show()
        return ani


if __name__ == "__main__":

    ols_viz = OLSVisualizer()
    animation = ols_viz.show()