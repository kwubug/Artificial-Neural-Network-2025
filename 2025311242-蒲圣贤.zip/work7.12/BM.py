# -*- coding: utf-8 -*-
"""
Boltzmann Machine (3 neurons, binary {0,1}) with sandbox-style visualization
- Exact Boltzmann distribution by enumerating all 2^3 states
- Gibbs sampling (systematic scan) at T=1 to reach thermal equilibrium
- Clear "OUTPUT" section printed to stdout
- Two plots: energy vs iteration, empirical equilibrium distribution发v。怕【【】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】】【p-

Dependencies: numpy, matplotlib
"""

import numpy as np
import itertools
from collections import Counter
import matplotlib.pyplot as plt

# ========== 可调参数 ==========
np.random.seed(42)    # 固定随机种子，方便复现
n = 3                 # 神经元个数
1
# 对称权重矩阵（对角为 0），偏置向量（可按需修改）
W = np.array([
    [0.0,  0.8, -0.3],
    [0.8,  0.0,  0.5],
    [-0.3, 0.5,  0.0]
], dtype=float)
b = np.array([0.2, -0.1, 0.0], dtype=float)

T = 1.0               # 温度
total_iters = 12000   # 总迭代轮数（每轮进行一次完整扫描）
burn_in = 2000        # 烧入期
# ===========================

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

def energy(v):
    """能量函数 E(v) = -1/2 v^T W v - b^T v"""
    v = np.asarray(v, dtype=float)
    return -0.5 * v @ W @ v - b @ v

def local_field(i, v):
    """单元 i 的局部场"""
    return W[i, :] @ v + b[i]

# 枚举所有 8 个状态
all_states = np.array(list(itertools.product([0, 1], repeat=n)), dtype=int)

def state_to_str(v):
    return ''.join(str(int(x)) for x in v)

# ----- 计算精确玻尔兹曼分布 -----
energies = np.array([energy(v) for v in all_states])
boltz_weights = np.exp(-energies / T)   # k_B=1
Z = boltz_weights.sum()
theoretical_probs = boltz_weights / Z

# 众数（最可能状态）
argmax_idx = int(np.argmax(theoretical_probs))
mode_state = all_states[argmax_idx]
mode_prob = float(theoretical_probs[argmax_idx])

# ----- Gibbs 采样以达到热平衡 -----
v = np.random.randint(0, 2, size=n).astype(int)  # 随机初态
trace_energy = []
samples = []

for t in range(total_iters):
    # 一次“扫描”依次更新每个单元
    for i in range(n):
        h = local_field(i, v) / T
        p1 = sigmoid(h)       # P(v_i=1 | 其它单元)
        v[i] = 1 if np.random.rand() < p1 else 0

    e = energy(v)
    trace_energy.append(e)
    if t >= burn_in:
        samples.append(tuple(v.tolist()))

# 经验分布
counts = Counter(samples)
num_used = len(samples)
empirical_probs = np.zeros(len(all_states))
for idx, s in enumerate(all_states):
    empirical_probs[idx] = counts.get(tuple(s.tolist()), 0) / max(1, num_used)

# 经验期望与二阶相关（在 {0,1} 域）
states01 = all_states.astype(float)
E_v = (empirical_probs[:, None] * states01).sum(axis=0)                   # E[v_i]
E_vv = (empirical_probs[:, None, None] *
        (states01[:, :, None] * states01[:, None, :])).sum(axis=0)       # E[v_i v_j]

# KL(empirical || exact)，做极小平滑以避免 log(0)
eps = 1e-12
p = empirical_probs + eps
p /= p.sum()
q = theoretical_probs + eps
q /= q.sum()
kl = float(np.sum(p * np.log(p / q)))

# ======== 输出部分 ========
def _fmt_table(states, energies, probs):
    idx = np.argsort(-probs)  # 概率降序
    lines = []
    for s, e, p in zip(states[idx], energies[idx], probs[idx]):
        lines.append(f"  state {state_to_str(s)} | E = {e: .6f} | P = {p: .6f}")
    return "\n".join(lines)

print("======== Boltzmann Machine (3 neurons) — OUTPUT ========")
print("Model summary:")
print(f"  W =\n{W}")
print(f"  b = {b}")
print(f"  Temperature T = {T}")
print(f"  Iterations = {total_iters} (burn-in = {burn_in}, samples used = {num_used})")
print(f"  Partition function Z ≈ {Z:.6f}\n")

print("Exact Boltzmann distribution (sorted by probability desc):")
print(_fmt_table(all_states, energies, theoretical_probs))
print()

print("Empirical distribution from Gibbs samples (sorted by probability desc):")
print(_fmt_table(all_states, energies, empirical_probs))
print()

print("Empirical expectations:")
print(f"  E[v] ≈ {np.round(E_v, 4)}")
print("  E[v_i v_j] ≈")
print(np.round(E_vv, 4))
print()

print("Final thermal equilibrium summary:")
print(f"  Most probable state (exact): {state_to_str(mode_state)} with P ≈ {mode_prob:.6f}")
print(f"  KL(empirical || exact) ≈ {kl:.6f}")
print("========================================================\n")

# ======== 可视化（可选，不需要可注释掉） ========
plt.figure()
plt.plot(range(total_iters), trace_energy, linewidth=1.0)
plt.xlabel("Iteration")
plt.ylabel("Energy")
plt.title("Energy over Iterations (including burn-in)")
plt.tight_layout()

plt.figure()
state_labels = [state_to_str(s) for s in all_states]
plt.bar(range(len(all_states)), empirical_probs)
plt.xticks(range(len(all_states)), state_labels)
plt.xlabel("State (binary)")
plt.ylabel("Empirical probability")
plt.title("Empirical Equilibrium Distribution (after burn-in)")
plt.tight_layout()

plt.show()
