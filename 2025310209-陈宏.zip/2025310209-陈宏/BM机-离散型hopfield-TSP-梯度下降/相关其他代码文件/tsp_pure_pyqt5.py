import sys
import numpy as np
import random
import math
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox,
                             QGridLayout, QTextEdit, QSlider, QSpinBox, QComboBox)
from PyQt5.QtCore import Qt, QTimer, QRect
from PyQt5.QtGui import QPainter, QColor, QPen, QFont, QBrush


class TSPMapWidget(QWidget):
    """专门的地图绘制组件"""

    def __init__(self, tsp_solver):
        super().__init__()
        self.tsp_solver = tsp_solver
        self.setMinimumSize(600, 500)
        self.setStyleSheet("background-color: #1e1e1e; border: 1px solid #555;")

    def paintEvent(self, event):
        """重绘地图"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 清除背景
        painter.fillRect(self.rect(), QColor(30, 30, 30))

        # 检查是否有城市数据
        if not hasattr(self.tsp_solver, 'cities') or not self.tsp_solver.cities:
            # 绘制提示信息
            painter.setPen(QPen(QColor(255, 255, 255), 1))
            painter.setFont(QFont("Arial", 14))
            painter.drawText(self.rect(), Qt.AlignCenter, "等待数据加载...")
            return

        # 获取绘图区域尺寸（留出边距）
        margin = 40
        draw_width = self.width() - 2 * margin
        draw_height = self.height() - 2 * margin

        # 计算城市坐标的边界范围
        if not self.tsp_solver.cities:
            return

        x_coords = [city[0] for city in self.tsp_solver.cities]
        y_coords = [city[1] for city in self.tsp_solver.cities]

        if not x_coords or not y_coords:
            return

        min_x, max_x = min(x_coords), max(x_coords)
        min_y, max_y = min(y_coords), max(y_coords)

        # 避免除零
        if max_x == min_x:
            max_x = min_x + 1
        if max_y == min_y:
            max_y = min_y + 1

        # 绘制当前路径（浅蓝色）
        if hasattr(self.tsp_solver, 'current_path') and len(self.tsp_solver.current_path) > 1:
            painter.setPen(QPen(QColor(100, 150, 255, 180), 2))
            self.draw_path(painter, self.tsp_solver.current_path, min_x, max_x, min_y, max_y,
                           margin, draw_width, draw_height)

        # 绘制最优路径（黄色，更粗）
        if hasattr(self.tsp_solver, 'best_path') and len(self.tsp_solver.best_path) > 1:
            painter.setPen(QPen(QColor(255, 200, 50), 3))
            self.draw_path(painter, self.tsp_solver.best_path, min_x, max_x, min_y, max_y,
                           margin, draw_width, draw_height)

        # 绘制城市点
        for i, (orig_x, orig_y) in enumerate(self.tsp_solver.cities):
            # 坐标映射到绘图区域
            x = margin + (orig_x - min_x) / (max_x - min_x) * draw_width
            y = margin + (orig_y - min_y) / (max_y - min_y) * draw_height

            # 绘制城市点（红色圆点）
            painter.setBrush(QBrush(QColor(255, 100, 100)))
            painter.setPen(QPen(QColor(200, 50, 50), 2))
            painter.drawEllipse(int(x) - 6, int(y) - 6, 12, 12)

            # 绘制城市编号
            painter.setPen(QPen(Qt.white, 1))
            painter.setFont(QFont("Arial", 8, QFont.Bold))
            painter.drawText(QRect(int(x) - 10, int(y) - 10, 20, 20), Qt.AlignCenter, str(i + 1))

    def draw_path(self, painter, path, min_x, max_x, min_y, max_y, margin, draw_width, draw_height):
        """绘制路径"""
        if len(path) < 2:
            return

        for i in range(len(path)):
            # 获取当前城市坐标
            orig_x1, orig_y1 = self.tsp_solver.cities[path[i]]
            orig_x2, orig_y2 = self.tsp_solver.cities[path[(i + 1) % len(path)]]

            # 坐标映射
            x1 = margin + (orig_x1 - min_x) / (max_x - min_x) * draw_width
            y1 = margin + (orig_y1 - min_y) / (max_y - min_y) * draw_height
            x2 = margin + (orig_x2 - min_x) / (max_x - min_x) * draw_width
            y2 = margin + (orig_y2 - min_y) / (max_y - min_y) * draw_height

            painter.drawLine(int(x1), int(y1), int(x2), int(y2))


class TSPVisualizer(QMainWindow):
    """TSP问题纯PyQt5可视化界面"""

    def __init__(self, tsp_solver):
        super().__init__()
        self.tsp_solver = tsp_solver
        self.init_ui()
        self.connect_signals()

    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("旅行商问题(TSP)可视化 - 模拟退火算法")
        self.setGeometry(100, 50, 1400, 900)

        # 设置样式
        self.setStyleSheet("""
            QMainWindow { background-color: #2b2b2b; }
            QGroupBox { 
                border: 2px solid #555; 
                border-radius: 8px; 
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title { 
                color: white; 
                font-weight: bold;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QLabel { color: white; }
            QPushButton { 
                background-color: #2196F3; 
                color: white; 
                border: none; 
                padding: 8px; 
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #1976D2; }
            QPushButton:disabled { background-color: #555; }
            QPushButton#stop { background-color: #f44336; }
            QPushButton#stop:hover { background-color: #d32f2f; }
            QPushButton#reset { background-color: #FF9800; }
            QPushButton#reset:hover { background-color: #F57C00; }
            QTextEdit { 
                background-color: #3c3c3c; 
                color: white;
                border: 1px solid #555;
                border-radius: 4px;
            }
            QSpinBox, QSlider {
                background-color: #3c3c3c;
                color: white;
                border: 1px solid #555;
                border-radius: 4px;
                padding: 2px;
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # 左侧：地图可视化区域
        left_panel = self.create_map_panel()
        main_layout.addWidget(left_panel, 2)  # 2/3宽度

        # 右侧：控制面板
        right_panel = self.create_control_panel()
        main_layout.addWidget(right_panel, 1)  # 1/3宽度

    def create_map_panel(self):
        """创建地图可视化面板"""
        panel = QGroupBox("🗺️ TSP问题地图可视化")

        layout = QVBoxLayout(panel)

        # 地图显示区域
        self.map_widget = TSPMapWidget(self.tsp_solver)
        layout.addWidget(self.map_widget)

        # 状态信息
        info_layout = QGridLayout()
        info_layout.setSpacing(10)

        info_layout.addWidget(QLabel("当前距离:"), 0, 0)
        self.distance_label = QLabel("0.00")
        self.distance_label.setStyleSheet("color: #4CAF50; font-weight: bold; font-size: 14px;")
        info_layout.addWidget(self.distance_label, 0, 1)

        info_layout.addWidget(QLabel("最优距离:"), 1, 0)
        self.best_distance_label = QLabel("0.00")
        self.best_distance_label.setStyleSheet("color: #FFC107; font-weight: bold; font-size: 14px;")
        info_layout.addWidget(self.best_distance_label, 1, 1)

        info_layout.addWidget(QLabel("迭代次数:"), 2, 0)
        self.iteration_label = QLabel("0")
        self.iteration_label.setStyleSheet("color: #2196F3; font-weight: bold; font-size: 14px;")
        info_layout.addWidget(self.iteration_label, 2, 1)

        info_layout.addWidget(QLabel("温度:"), 3, 0)
        self.temperature_label = QLabel("1000.00")
        self.temperature_label.setStyleSheet("color: #f44336; font-weight: bold; font-size: 14px;")
        info_layout.addWidget(self.temperature_label, 3, 1)

        layout.addLayout(info_layout)

        return panel

    def create_control_panel(self):
        """创建控制面板"""
        panel = QGroupBox("🎮 控制面板")

        layout = QVBoxLayout(panel)
        layout.setSpacing(15)

        # 城市数量控制
        cities_layout = QHBoxLayout()
        cities_layout.addWidget(QLabel("城市数量:"))
        self.cities_spin = QSpinBox()
        self.cities_spin.setRange(5, 50)
        self.cities_spin.setValue(15)
        self.cities_spin.valueChanged.connect(self.change_num_cities)
        cities_layout.addWidget(self.cities_spin)
        layout.addLayout(cities_layout)

        # 控制按钮
        self.start_btn = QPushButton("🚀 开始优化")
        self.stop_btn = QPushButton("⏹️ 停止优化")
        self.reset_btn = QPushButton("🔄 重新生成")

        self.start_btn.clicked.connect(self.start_optimization)
        self.stop_btn.clicked.connect(self.stop_optimization)
        self.reset_btn.clicked.connect(self.reset_problem)

        self.stop_btn.setEnabled(False)
        self.stop_btn.setObjectName("stop")
        self.reset_btn.setObjectName("reset")

        layout.addWidget(self.start_btn)
        layout.addWidget(self.stop_btn)
        layout.addWidget(self.reset_btn)

        # 速度控制
        speed_layout = QVBoxLayout()
        speed_layout.addWidget(QLabel("速度控制:"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(50, 500)
        self.speed_slider.setValue(200)
        self.speed_slider.valueChanged.connect(self.change_speed)
        speed_layout.addWidget(self.speed_slider)
        layout.addLayout(speed_layout)

        # 日志输出
        layout.addWidget(QLabel("📝 优化日志:"))
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(200)
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        return panel

    def connect_signals(self):
        """连接信号槽"""
        self.tsp_solver.pathChanged.connect(self.update_display)
        self.tsp_solver.bestPathChanged.connect(self.update_display)
        self.tsp_solver.iterationChanged.connect(self.update_display)
        self.tsp_solver.distanceChanged.connect(self.update_display)
        self.tsp_solver.citiesChanged.connect(self.update_display)
        self.tsp_solver.updateLog.connect(self.log_message)

        # 初始更新
        self.update_display()

    def start_optimization(self):
        """开始优化"""
        self.tsp_solver.start_optimization()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.log_message("🚀 开始TSP优化")

    def stop_optimization(self):
        """停止优化"""
        self.tsp_solver.stop_optimization()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.log_message("⏹️ 优化停止")

    def reset_problem(self):
        """重置问题"""
        self.tsp_solver.reset_problem()
        self.update_display()
        self.log_message("🔄 问题已重置")

    def change_num_cities(self, num):
        """改变城市数量"""
        self.tsp_solver.set_num_cities(num)
        self.update_display()

    def change_speed(self, value):
        """改变优化速度"""
        if self.tsp_solver.running:
            self.tsp_solver.timer.setInterval(value)

    def update_display(self):
        """更新显示"""
        try:
            self.distance_label.setText(f"{self.tsp_solver.current_distance:.2f}")
            self.best_distance_label.setText(f"{self.tsp_solver.best_distance:.2f}")
            self.iteration_label.setText(str(self.tsp_solver.iteration))
            self.temperature_label.setText(f"{self.tsp_solver.temperature:.2f}")

            # 强制重绘地图
            self.map_widget.update()
        except Exception as e:
            self.log_message(f"❌ 显示更新错误: {e}")

    def log_message(self, message):
        """添加日志"""
        self.log_text.append(message)
        # 自动滚动到底部
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


def main():
    """主函数"""
    app = QApplication(sys.argv)

    # 设置字体
    font = QFont("Microsoft YaHei", 10)
    app.setFont(font)

    # 创建TSP求解器
    from tsp_model import TSPSolver
    tsp_solver = TSPSolver(15)

    # 创建并显示窗口
    window = TSPVisualizer(tsp_solver)
    window.show()

    print("✅ TSP问题可视化启动成功！")
    print("   地图显示: 已修复")
    print("   城市数量: 15")
    print("   算法: 模拟退火")

    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())