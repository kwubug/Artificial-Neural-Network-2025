import numpy as np
import matplotlib.pyplot as plt
import random
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import Button
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei']
class BoltzmannMachine:
    def __init__(self, weights, biases, temperature=1.0):
        """
        初始化玻尔兹曼机

        参数:
        weights: 权重矩阵 (3x3)
        biases: 偏置向量 (3,)
        temperature: 温度参数
        """
        self.weights = np.array(weights)
        self.biases = np.array(biases)
        self.temperature = temperature
        self.n_neurons = 3

        # 确保无自连接
        np.fill_diagonal(self.weights, 0)

        # 状态历史记录
        self.states_history = []
        self.energy_history = []
        self.temperature_history = []

    def energy(self, state):
        """计算网络能量"""
        return -0.5 * np.dot(state, np.dot(self.weights, state)) - np.dot(self.biases, state)

    def probability(self, state, neuron_idx):
        """计算神经元激活的概率"""
        # 计算该神经元的净输入
        net_input = np.dot(self.weights[neuron_idx], state) + self.biases[neuron_idx]

        # 使用sigmoid函数计算概率
        probability = 1 / (1 + np.exp(-2 * net_input / self.temperature))
        return probability

    def update_neuron(self, state, neuron_idx):
        """异步更新单个神经元"""
        prob = self.probability(state, neuron_idx)
        if random.random() < prob:
            new_state = 1
        else:
            new_state = -1
        return new_state

    def step(self, initial_state=None, annealing=False):
        """执行一步更新"""
        if initial_state is None:
            # 随机初始化状态
            state = np.random.choice([-1, 1], size=self.n_neurons)
        else:
            state = initial_state.copy()

        # 随机选择更新顺序
        update_order = np.random.permutation(self.n_neurons)

        # 异步更新所有神经元
        for neuron_idx in update_order:
            state[neuron_idx] = self.update_neuron(state, neuron_idx)

        # 记录状态和能量
        current_energy = self.energy(state)
        self.states_history.append(state.copy())
        self.energy_history.append(current_energy)
        self.temperature_history.append(self.temperature)

        # 模拟退火（如果启用）
        if annealing and self.temperature > 0.1:
            self.temperature *= 0.95

        return state, current_energy

    def run_until_convergence(self, initial_state=None, max_steps=1000, energy_threshold=1e-5):
        """运行直到达到热平衡"""
        if initial_state is None:
            state = np.random.choice([-1, 1], size=self.n_neurons)
        else:
            state = initial_state.copy()

        print("开始运行直到热平衡...")
        print(f"初始状态: {state}, 初始能量: {self.energy(state):.4f}")

        for step in range(max_steps):
            old_energy = self.energy(state)
            state, new_energy = self.step(state, annealing=True)

            # 检查能量变化是否小于阈值
            if abs(new_energy - old_energy) < energy_threshold and step > 10:
                print(f"在 {step} 步后达到热平衡")
                print(f"最终状态: {state}, 最终能量: {new_energy:.4f}")
                break

            if step % 100 == 0:
                print(f"步骤 {step}: 状态={state}, 能量={new_energy:.4f}, 温度={self.temperature:.4f}")

        return state, new_energy

    def get_state_probabilities(self, num_samples=10000):
        """通过采样估计各状态的概率分布"""
        state_counts = {}

        for _ in range(num_samples):
            state = np.random.choice([-1, 1], size=self.n_neurons)
            state_tuple = tuple(state)
            state_counts[state_tuple] = state_counts.get(state_tuple, 0) + 1

        # 计算概率
        total_samples = sum(state_counts.values())
        state_probs = {state: count / total_samples for state, count in state_counts.items()}

        return state_probs


class BoltzmannVisualizer:
    def __init__(self, bm):
        self.bm = bm
        self.fig = plt.figure(figsize=(15, 10))
        self.setup_plots()
        self.current_step = 0
        self.is_playing = False

    def setup_plots(self):
        """设置绘图区域"""
        # 网络结构图
        self.ax_network = plt.subplot2grid((3, 3), (0, 0), colspan=1, rowspan=2)
        self.ax_network.set_title('玻尔兹曼机网络结构')
        self.ax_network.set_xlim(-2, 2)
        self.ax_network.set_ylim(-2, 2)
        self.ax_network.axis('off')

        # 状态可视化
        self.ax_states = plt.subplot2grid((3, 3), (0, 1), colspan=2)
        self.ax_states.set_title('神经元状态变化')
        self.ax_states.set_xlabel('时间步')
        self.ax_states.set_ylabel('状态值')
        self.ax_states.set_ylim(-1.5, 1.5)
        self.ax_states.grid(True)

        # 能量变化
        self.ax_energy = plt.subplot2grid((3, 3), (1, 1), colspan=2)
        self.ax_energy.set_title('能量变化')
        self.ax_energy.set_xlabel('时间步')
        self.ax_energy.set_ylabel('能量')
        self.ax_energy.grid(True)

        # 温度变化
        self.ax_temperature = plt.subplot2grid((3, 3), (2, 0), colspan=3)
        self.ax_temperature.set_title('温度变化')
        self.ax_temperature.set_xlabel('时间步')
        self.ax_temperature.set_ylabel('温度')
        self.ax_temperature.grid(True)

        plt.tight_layout()

    def draw_network(self, state):
        """绘制网络结构"""
        self.ax_network.clear()
        self.ax_network.set_title(f'网络结构 (步数: {self.current_step})')
        self.ax_network.set_xlim(-2, 2)
        self.ax_network.set_ylim(-2, 2)
        self.ax_network.axis('off')

        # 神经元位置（三角形排列）
        positions = [
            (0, 1.5),  # 神经元0
            (-1.3, -0.5),  # 神经元1
            (1.3, -0.5)  # 神经元2
        ]

        # 绘制连接
        for i in range(3):
            for j in range(i + 1, 3):
                weight = self.bm.weights[i, j]
                color = 'red' if weight < 0 else 'blue'
                linewidth = abs(weight) * 2
                self.ax_network.plot([positions[i][0], positions[j][0]],
                                     [positions[i][1], positions[j][1]],
                                     color=color, linewidth=linewidth, alpha=0.6)

        # 绘制神经元
        for i, (x, y) in enumerate(positions):
            color = 'lightcoral' if state[i] == 1 else 'lightblue'
            self.ax_network.scatter(x, y, s=800, c=color, edgecolors='black', linewidth=2)
            self.ax_network.text(x, y, f'N{i}\n({state[i]})',
                                 ha='center', va='center', fontweight='bold')

            # 显示偏置
            bias = self.bm.biases[i]
            bias_color = 'red' if bias < 0 else 'blue'
            self.ax_network.text(x, y - 0.3, f'b={bias:.1f}',
                                 ha='center', va='center', color=bias_color, fontsize=8)

    def update_plots(self, step):
        """更新所有图表"""
        if step >= len(self.bm.states_history):
            return

        self.current_step = step
        current_state = self.bm.states_history[step]
        current_energy = self.bm.energy_history[step]
        current_temp = self.bm.temperature_history[step]

        # 更新网络图
        self.draw_network(current_state)

        # 更新状态图
        self.ax_states.clear()
        steps = list(range(step + 1))
        states_array = np.array(self.bm.states_history[:step + 1])

        for i in range(3):
            self.ax_states.plot(steps, states_array[:, i],
                                label=f'神经元 {i}', linewidth=2, marker='o', markersize=3)

        self.ax_states.set_title(f'神经元状态变化 (步数: {step})')
        self.ax_states.set_xlabel('时间步')
        self.ax_states.set_ylabel('状态值')
        self.ax_states.set_ylim(-1.5, 1.5)
        self.ax_states.legend()
        self.ax_states.grid(True)

        # 更新能量图
        self.ax_energy.clear()
        self.ax_energy.plot(steps, self.bm.energy_history[:step + 1],
                            'g-', linewidth=2, label='能量')
        self.ax_energy.set_title(f'能量变化: {current_energy:.4f}')
        self.ax_energy.set_xlabel('时间步')
        self.ax_energy.set_ylabel('能量')
        self.ax_energy.legend()
        self.ax_energy.grid(True)

        # 更新温度图
        self.ax_temperature.clear()
        self.ax_temperature.plot(steps, self.bm.temperature_history[:step + 1],
                                 'r-', linewidth=2, label='温度')
        self.ax_temperature.set_title(f'温度变化: {current_temp:.4f}')
        self.ax_temperature.set_xlabel('时间步')
        self.ax_temperature.set_ylabel('温度')
        self.ax_temperature.legend()
        self.ax_temperature.grid(True)

        plt.tight_layout()

    def animate(self, total_steps=200, interval=200):
        """创建动画"""
        # 先运行模拟
        print("正在运行模拟...")
        state = np.random.choice([-1, 1], size=3)
        for step in range(total_steps):
            state, energy = self.bm.step(state, annealing=True)

        print("模拟完成，开始动画...")

        def update(frame):
            self.update_plots(frame)
            return []

        anim = FuncAnimation(self.fig, update, frames=total_steps,
                             interval=interval, blit=False, repeat=False)

        plt.show()
        return anim


def analyze_equilibrium(bm, num_samples=5000):
    """分析热平衡状态"""
    print("\n" + "=" * 50)
    print("热平衡状态分析")
    print("=" * 50)

    # 采样状态概率
    state_probs = bm.get_state_probabilities(num_samples)

    # 按概率排序
    sorted_states = sorted(state_probs.items(), key=lambda x: x[1], reverse=True)

    print("状态概率分布:")
    for state, prob in sorted_states:
        energy = bm.energy(np.array(state))
        print(f"状态 {state}: 概率 = {prob:.4f}, 能量 = {energy:.4f}")

    # 找到最可能的状态
    most_probable_state = sorted_states[0][0]
    print(f"\n最可能的状态: {most_probable_state}")
    print(f"该状态的概率: {sorted_states[0][1]:.4f}")
    print(f"该状态的能量: {bm.energy(np.array(most_probable_state)):.4f}")

    return most_probable_state


def main():
    # 设置随机种子
    np.random.seed(42)
    random.seed(42)

    print("三神经元玻尔兹曼机模拟")
    print("=" * 50)

    # 定义网络参数
    # 权重矩阵 (3x3)
    weights = [
        [0, 0.8, -0.5],  # 神经元0到其他神经元的权重
        [0.8, 0, 0.3],  # 神经元1到其他神经元的权重
        [-0.5, 0.3, 0]  # 神经元2到其他神经元的权重
    ]

    # 偏置向量
    biases = [0.2, -0.3, 0.1]

    print("网络参数:")
    print("权重矩阵:")
    for row in weights:
        print(f"  {row}")
    print(f"偏置向量: {biases}")

    # 创建玻尔兹曼机
    bm = BoltzmannMachine(weights, biases, temperature=2.0)

    # 运行模拟找到热平衡
    print("\n寻找热平衡状态...")
    equilibrium_state, equilibrium_energy = bm.run_until_convergence(max_steps=500)

    print(f"\n热平衡状态: {equilibrium_state}")
    print(f"热平衡能量: {equilibrium_energy:.4f}")

    # 分析状态概率分布
    most_probable_state = analyze_equilibrium(bm)

    # 创建可视化
    print("\n创建可视化...")
    visualizer = BoltzmannVisualizer(bm)

    # 运行动画
    print("运行动画演示...")
    visualizer.animate(total_steps=150, interval=300)

    # 显示最终分析结果
    plt.figure(figsize=(12, 8))

    # 状态概率分布图
    state_probs = bm.get_state_probabilities(5000)
    states = list(state_probs.keys())
    probs = list(state_probs.values())

    # 将状态转换为字符串标签
    state_labels = [str(state) for state in states]

    plt.subplot(2, 2, 1)
    bars = plt.bar(state_labels, probs, color='skyblue', edgecolor='black')
    plt.title('状态概率分布')
    plt.xlabel('状态')
    plt.ylabel('概率')
    plt.xticks(rotation=45)

    # 在柱子上显示概率值
    for bar, prob in zip(bars, probs):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                 f'{prob:.3f}', ha='center', va='bottom')

    # 能量变化图
    plt.subplot(2, 2, 2)
    plt.plot(bm.energy_history, 'g-', linewidth=2)
    plt.title('能量收敛过程')
    plt.xlabel('时间步')
    plt.ylabel('能量')
    plt.grid(True)

    # 温度变化图
    plt.subplot(2, 2, 3)
    plt.plot(bm.temperature_history, 'r-', linewidth=2)
    plt.title('温度下降过程')
    plt.xlabel('时间步')
    plt.ylabel('温度')
    plt.grid(True)

    # 最终网络状态
    plt.subplot(2, 2, 4)
    visualizer.draw_network(equilibrium_state)
    plt.title(f'最终热平衡状态\n能量: {equilibrium_energy:.4f}')

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()