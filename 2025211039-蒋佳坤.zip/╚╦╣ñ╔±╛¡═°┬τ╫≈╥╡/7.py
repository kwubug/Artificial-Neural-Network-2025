import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


X = np.array([
    [1, 0, 0, 0],
    [1, 1, 0, 0],
    [1, 1, 1, 0],
    [0, 1, 0, 0],
    [1, 1, 1, 1]
])


grid_size = 5
input_dim = 4
max_iter = 10000
eta_init = 0.5
eta_mid = 0.04
eta_final = 0.0
radius_init = 2.0
radius_final = 0.0


weights = np.random.rand(grid_size, grid_size, input_dim)


coords = np.array([[i, j] for i in range(grid_size) for j in range(grid_size)]).reshape(grid_size, grid_size, 2)


def learning_rate(t):
    """学习率线性下降"""
    if t <= 1000:
        return eta_init - (eta_init - eta_mid) * (t / 1000)
    else:
        return eta_mid - (eta_mid - eta_final) * ((t - 1000) / (max_iter - 1000))

def neighborhood_radius(t):
    """邻域半径线性下降"""
    if t <= 1000:
        return radius_init - (radius_init - radius_final) * (t / 1000)
    else:
        return radius_final

def find_bmu(x, weights):
    """找到最匹配单元（BMU）"""
    diff = weights - x
    dist = np.linalg.norm(diff, axis=2)
    return np.unravel_index(np.argmin(dist), dist.shape)

def update_weights(x, weights, bmu_idx, eta, radius):
    """更新权向量"""
    for i in range(grid_size):
        for j in range(grid_size):
            dist_to_bmu = np.linalg.norm(np.array([i, j]) - np.array(bmu_idx))
            if dist_to_bmu <= radius:
                influence = np.exp(-dist_to_bmu**2 / (2 * (radius + 1e-6)**2))
                weights[i, j] += eta * influence * (x - weights[i, j])
    return weights


snapshots = []
for t in range(max_iter):
    x = X[np.random.randint(0, len(X))]  # 随机输入样本
    eta = learning_rate(t)
    radius = neighborhood_radius(t)
    bmu_idx = find_bmu(x, weights)
    weights = update_weights(x, weights, bmu_idx, eta, radius)
    if t % 200 == 0:
        snapshots.append(weights.copy())

print(f"✅ 训练完成，共保存 {len(snapshots)} 组权向量快照。")


plt.figure(figsize=(6, 6))
plt.title("SOM映射结果：5个输入模式在输出平面上的位置", fontsize=14)

for i, x in enumerate(X):
    bmu_idx = find_bmu(x, weights)
    plt.scatter(bmu_idx[1], bmu_idx[0], s=180, label=f"X{i+1}")
    plt.text(bmu_idx[1]+0.1, bmu_idx[0]+0.1, f"X{i+1}", fontsize=12)

plt.gca().invert_yaxis()
plt.xticks(range(grid_size))
plt.yticks(range(grid_size))
plt.xlabel("输出节点列", fontsize=12)
plt.ylabel("输出节点行", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(loc='best', fontsize=10)
plt.tight_layout()
plt.show()


show_snapshots = True
if show_snapshots:
    fig, axes = plt.subplots(2, 3, figsize=(10, 6))
    fig.suptitle("SOM 权向量变化过程（每200步保存一次）", fontsize=14)
    idxs = np.linspace(0, len(snapshots)-1, 6, dtype=int)

    for ax, idx in zip(axes.flat, idxs):
        w = snapshots[idx]
        ax.imshow(w[:, :, 0], cmap='viridis', origin='upper')
        ax.set_title(f"迭代步数: {idx*200}")
        ax.axis('off')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.show()
