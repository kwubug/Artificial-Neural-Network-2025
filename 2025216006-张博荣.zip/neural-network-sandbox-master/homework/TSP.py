import numpy as np
import copy
import time
import matplotlib.pyplot as plt
from matplotlib.font_manager import findfont, FontProperties
from typing import List, Tuple, Dict, Optional

def get_available_chinese_font():
   
    chinese_fonts = [
        "SimHei",         # 黑体（Windows常见）
        "Microsoft YaHei",# 微软雅黑（Windows常见）
        "Heiti TC",       # 黑体（macOS常见）
        "WenQuanYi Micro Hei", # 文泉驿微米黑（Linux常见）
        "Arial Unicode MS"# 通用Unicode字体（跨平台）
    ]
    
    # 检测并返回第一个可用的字体
    for font in chinese_fonts:
        try:
            # 尝试查找字体
            font_path = findfont(FontProperties(family=font))
            return font  # 找到可用字体则返回
        except:
            continue
    
    # 如果没有找到中文字体，返回默认字体（可能显示方块，但避免报错）
    return "sans-serif"

# 设置可用的中文字体
chinese_font = get_available_chinese_font()
plt.rcParams["font.family"] = [chinese_font]
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号


class TSPSandbox:
    """TSP问题求解的沙箱环境，隔离数据与计算资源"""
    def __init__(self, 
                 max_iter: int = 1000, 
                 timeout: float = 30.0, 
                 pop_size: int = 50):
        """
        初始化TSP沙箱
        :param max_iter: 最大迭代次数（资源限制）
        :param timeout: 超时时间（秒，资源限制）
        :param pop_size: 种群大小（遗传算法参数）
        """
        # 沙箱内部私有状态（外部不可直接访问）
        self._cities = None  # 城市坐标（隔离存储）
        self._distance_matrix = None  # 距离矩阵（内部计算）
        self._max_iter = max_iter
        self._timeout = timeout
        self._pop_size = pop_size
        
        # 求解过程记录（内部隔离）
        self._best_path = None
        self._best_distance = float('inf')
        self._distance_history = []  # 迭代过程中的最优距离记录
        
        # 沙箱状态标记
        self._is_initialized = False
        self._last_operation_time = 0.0

    def initialize(self, external_cities: np.ndarray) -> None:
        """
        初始化TSP问题（隔离外部城市数据）
        :param external_cities: 外部输入的城市坐标（shape: [n, 2]）
        """
        # 1. 数据隔离：深拷贝外部城市数据，避免修改原始数据
        self._cities = copy.deepcopy(external_cities)
        
        # 2. 输入验证（沙箱内安全检查）
        if self._cities.ndim != 2 or self._cities.shape[1] != 2:
            raise ValueError("沙箱错误：城市数据必须是二维数组（每行包含x,y坐标）")
        if len(self._cities) < 2:
            raise ValueError("沙箱错误：至少需要2个城市")
        
        # 3. 内部预处理：计算距离矩阵（不暴露给外部）
        n = len(self._cities)
        self._distance_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    self._distance_matrix[i][j] = np.linalg.norm(
                        self._cities[i] - self._cities[j]
                    )
        
        # 更新沙箱状态
        self._is_initialized = True
        self._best_path = None
        self._best_distance = float('inf')
        self._distance_history = []
        self._last_operation_time = time.time()

    def _calculate_path_distance(self, path: List[int]) -> float:
        """沙箱内部计算路径总距离（不暴露实现）"""
        distance = 0.0
        n = len(path)
        for i in range(n):
            distance += self._distance_matrix[path[i]][path[(i+1)%n]]
        return distance

    def _generate_initial_population(self) -> List[List[int]]:
        """沙箱内部生成初始种群（遗传算法初始化）"""
        n = len(self._cities)
        population = []
        for _ in range(self._pop_size):
            # 随机生成路径（城市索引的排列）
            path = np.random.permutation(n).tolist()
            population.append(path)
        return population

    def solve(self, 
              mutation_rate: float = 0.02, 
              elitism_rate: float = 0.2) -> Tuple[List[int], float]:
        """
        在沙箱内求解TSP问题（基于遗传算法）
        :param mutation_rate: 变异概率
        :param elitism_rate: 精英保留比例
        :return: 最优路径和对应的距离
        """
        # 1. 前置检查
        if not self._is_initialized:
            raise RuntimeError("沙箱错误：未初始化城市数据，请先调用initialize方法")
        
        # 2. 资源控制：初始化计时
        start_time = time.time()
        n_cities = len(self._cities)
        n_elite = int(self._pop_size * elitism_rate)  # 精英个体数量
        
        # 3. 初始化种群（沙箱内操作）
        population = self._generate_initial_population()
        
        # 4. 遗传算法迭代（沙箱内执行，受资源限制）
        for iter_count in range(self._max_iter):
            # 超时检查
            if time.time() - start_time > self._timeout:
                raise TimeoutError(f"沙箱错误：求解超时（超过{self._timeout}秒）")
            
            # 计算适应度（距离的倒数，距离越短适应度越高）
            fitness = [1 / self._calculate_path_distance(path) for path in population]
            
            # 记录当前最优解
            current_best_idx = np.argmax(fitness)
            current_best_path = population[current_best_idx]
            current_best_distance = self._calculate_path_distance(current_best_path)
            
            # 更新全局最优
            if current_best_distance < self._best_distance:
                self._best_path = copy.deepcopy(current_best_path)
                self._best_distance = current_best_distance
            self._distance_history.append(self._best_distance)
            
            # 选择操作（轮盘赌选择）
            fitness_sum = sum(fitness)
            probabilities = [f / fitness_sum for f in fitness]
            selected_indices = np.random.choice(
                self._pop_size, 
                size=self._pop_size - n_elite,  # 减去精英个体数量
                p=probabilities
            )
            selected = [population[i] for i in selected_indices]
            
            # 精英保留（直接保留适应度最高的个体）
            elite_indices = np.argsort(fitness)[-n_elite:]
            elites = [population[i] for i in elite_indices]
            
            # 交叉操作（有序交叉OX）
            offspring = []
            while len(offspring) < self._pop_size - n_elite:
                parent1 = selected[np.random.randint(len(selected))]
                parent2 = selected[np.random.randint(len(selected))]
                if parent1 == parent2:
                    continue
                
                # 随机选择交叉区间
                a, b = np.random.randint(0, n_cities, size=2)
                if a > b:
                    a, b = b, a
                
                # 生成子代
                child = [-1] * n_cities
                child[a:b+1] = parent1[a:b+1]  # 复制父代1的交叉区间
                ptr = (b + 1) % n_cities  # 从交叉区间后开始填充
                for city in parent2:
                    if city not in child:
                        child[ptr] = city
                        ptr = (ptr + 1) % n_cities
                offspring.append(child)
            
            # 变异操作（交换变异）
            for i in range(len(offspring)):
                if np.random.random() < mutation_rate:
                    idx1, idx2 = np.random.randint(0, n_cities, size=2)
                    offspring[i][idx1], offspring[i][idx2] = offspring[i][idx2], offspring[i][idx1]
            
            # 更新种群（精英 + 子代）
            population = elites + offspring
        
        # 更新沙箱状态
        self._last_operation_time = time.time()
        return self._best_path, self._best_distance

    def get_solution_history(self) -> List[float]:
        """安全获取求解过程中的距离历史（返回副本）"""
        return copy.deepcopy(self._distance_history)

    def visualize(self, path: Optional[List[int]] = None) -> None:
        """在沙箱内可视化结果（不修改外部数据）"""
        if not self._is_initialized:
            raise RuntimeError("沙箱错误：未初始化城市数据")
        
        # 若未指定路径，则使用最优路径
        if path is None:
            path = self._best_path
            if path is None:
                raise RuntimeError("沙箱错误：未求解TSP问题，请先调用solve方法")
        
        # 复制数据进行可视化（避免修改内部状态）
        cities = copy.deepcopy(self._cities)
        path = copy.deepcopy(path)
        
        # 绘制城市和路径
        plt.figure(figsize=(10, 6))
        
        # 子图1：路径可视化
        plt.subplot(121)
        plt.scatter(cities[:, 0], cities[:, 1], c='red', s=100, label='城市')
        # 绘制路径（包括回到起点）
        for i in range(len(path)):
            x1, y1 = cities[path[i]]
            x2, y2 = cities[path[(i+1)%len(path)]]
            plt.plot([x1, x2], [y1, y2], 'b-', linewidth=1.5)
        plt.title(f'TSP最优路径（总距离：{self._best_distance:.2f}）')
        plt.xlabel('X坐标')
        plt.ylabel('Y坐标')
        plt.legend()
        plt.grid(alpha=0.3)
        
        # 子图2：距离收敛曲线
        plt.subplot(122)
        plt.plot(self._distance_history, 'g-')
        plt.title('迭代过程中最优距离变化')
        plt.xlabel('迭代次数')
        plt.ylabel('最优距离')
        plt.grid(alpha=0.3)
        
        plt.tight_layout()
        plt.show()


# 演示沙箱环境下的TSP求解
if __name__ == "__main__":
    # 设置随机种子，确保结果可复现
    np.random.seed(42)
    num_cities = 15  # 城市数量
    cities = np.random.rand(num_cities, 2) * 100  # 随机生成[0,100)范围内的坐标
    
    # 输出当前使用的字体（帮助调试）
    print(f"当前使用的字体: {chinese_font}")
    
    # 创建TSP沙箱环境
    tsp_sandbox = TSPSandbox(
        max_iter=1000,    # 最大迭代次数
        timeout=10.0,     # 超时时间（秒）
        pop_size=80       # 种群大小
    )
    
    # 初始化城市数据
    try:
        tsp_sandbox.initialize(cities)
        print(f"沙箱初始化完成，城市数量：{num_cities}")
    except Exception as e:
        print(f"初始化失败：{e}")
        exit(1)
    
    # 求解TSP问题
    try:
        best_path, best_distance = tsp_sandbox.solve(
            mutation_rate=0.02,
            elitism_rate=0.2
        )
        print(f"沙箱求解完成，最优路径总距离：{best_distance:.2f}")
        print(f"最优路径（城市索引）：{best_path}")
    except Exception as e:
        print(f"求解失败：{e}")
        exit(1)
    
    # 可视化结果
    try:
        tsp_sandbox.visualize()
    except Exception as e:
        print(f"可视化失败：{e}")
        exit(1)