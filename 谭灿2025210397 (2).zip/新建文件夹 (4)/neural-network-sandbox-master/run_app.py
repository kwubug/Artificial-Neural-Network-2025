#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
神经网络沙盒启动器
解决Qt插件路径问题的Python启动脚本
"""

import os
import sys
import subprocess

def main():
    # 设置工作目录
    project_dir = r"C:\Users\34555\Downloads\neural-network-sandbox-master\neural-network-sandbox-master"
    os.chdir(project_dir)
    
    # 设置Qt环境变量
    qt_plugin_path = r"D:\编程\lib\site-packages\PyQt5\Qt5\plugins"
    qml_import_path = r"D:\编程\lib\site-packages\PyQt5\Qt5\qml"
    
    # 设置环境变量
    os.environ['QT_PLUGIN_PATH'] = qt_plugin_path
    os.environ['QML2_IMPORT_PATH'] = qml_import_path
    
    print("=" * 50)
    print("神经网络沙盒启动器")
    print("=" * 50)
    print(f"工作目录: {os.getcwd()}")
    print(f"QT_PLUGIN_PATH: {os.environ.get('QT_PLUGIN_PATH')}")
    print(f"QML2_IMPORT_PATH: {os.environ.get('QML2_IMPORT_PATH')}")
    print("=" * 50)
    
    # 检查插件目录是否存在
    if not os.path.exists(qt_plugin_path):
        print(f"错误: Qt插件目录不存在: {qt_plugin_path}")
        input("按回车键退出...")
        return
    
    if not os.path.exists(qml_import_path):
        print(f"错误: QML导入目录不存在: {qml_import_path}")
        input("按回车键退出...")
        return
    
    # 检查main.py是否存在
    if not os.path.exists("main.py"):
        print("错误: main.py文件不存在")
        input("按回车键退出...")
        return
    
    print("正在启动神经网络沙盒...")
    print("=" * 50)
    
    try:
        # 启动主程序
        subprocess.run([sys.executable, "main.py"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"程序启动失败: {e}")
    except KeyboardInterrupt:
        print("\n程序被用户中断")
    except Exception as e:
        print(f"发生错误: {e}")
    
    print("=" * 50)
    print("程序已退出")
    input("按回车键关闭窗口...")

if __name__ == "__main__":
    main()