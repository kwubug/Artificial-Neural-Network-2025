import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import DhnnAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class DhnnBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.01)
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    num_neurons = BridgeProperty(9)  # Manual neuron count
    total_epoches = BridgeProperty(100)
    max_iterations_per_epoch = BridgeProperty(1000)
    convergence_threshold = BridgeProperty(0.01)
    use_bipolar = BridgeProperty(True)
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    current_states = BridgeProperty([])
    current_weights = BridgeProperty([])
    current_biases = BridgeProperty([])
    is_converged = BridgeProperty(False)
    convergence_iteration = BridgeProperty(0)
    has_finished = BridgeProperty(True)
    energy_history = BridgeProperty([])
    state_history = BridgeProperty([])
    attractors = BridgeProperty([])
    attractor_energies = BridgeProperty([])
    num_attractors = BridgeProperty(0)

    def __init__(self):
        super().__init__()
        self.dhnn_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_dhnn_algorithm(self):
        # Use dataset if provided, otherwise use manual neuron count
        dataset = self.dataset_dict.get(self.current_dataset_name, [])
        if len(dataset) == 0:
            dataset = None  # Use manual neuron count
        
        self.dhnn_algorithm = ObservableDhnnAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=dataset,
            total_epoches=self.total_epoches,
            max_iterations_per_epoch=self.max_iterations_per_epoch,
            convergence_threshold=self.convergence_threshold,
            use_bipolar=self.use_bipolar,
            num_neurons=self.num_neurons
        )
        self.dhnn_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_dhnn_algorithm(self):
        if self.dhnn_algorithm:
            self.dhnn_algorithm.stop()


class ObservableDhnnAlgorithm(Observable, DhnnAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        DhnnAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        # Check if this is an internal attribute update that needs notification
        needs_notification = False
        if name.startswith('_') and hasattr(self, '_observer'):
            needs_notification = True
        
        super().__setattr__(name, value)
        
        # Notify observer of important state changes
        if needs_notification:
            if name == 'current_iterations':
                self.notify(name, value)
            elif name == '_energy':
                self.notify('current_energy', value)
                if hasattr(self, '_energy_history') and self._energy_history:
                    self.notify('energy_history', 
                               [float(e) for e in self._energy_history])
            elif name == '_is_converged':
                self.notify('is_converged', value)
            elif name == '_convergence_iteration':
                self.notify('convergence_iteration', value)
            elif name == '_states':
                if value is not None:
                    self.notify('current_states', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_weights':
                if value is not None:
                    self.notify('current_weights', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_biases':
                if value is not None:
                    self.notify('current_biases', value.tolist() if hasattr(value, 'tolist') else list(value))
            elif name == '_attractors':
                if value is not None:
                    attractors_list = [attractor.tolist() if hasattr(attractor, 'tolist') else list(attractor) 
                                      for attractor in value]
                    self.notify('attractors', attractors_list)
                    self.notify('num_attractors', len(value))
            elif name == '_attractor_energies':
                if value is not None:
                    self.notify('attractor_energies', [float(e) for e in value])
            elif name == 'num_neurons':
                self.notify('num_neurons', value)

    def _notify_state(self):
        """Notify all current state information."""
        if hasattr(self, '_states') and self._states is not None:
            self.notify('current_states', self._states.tolist())
        if hasattr(self, '_weights') and self._weights is not None:
            self.notify('current_weights', self._weights.tolist())
        if hasattr(self, '_biases') and self._biases is not None:
            self.notify('current_biases', self._biases.tolist())
        if hasattr(self, '_energy'):
            self.notify('current_energy', float(self._energy))
        if hasattr(self, '_is_converged'):
            self.notify('is_converged', self._is_converged)
        if hasattr(self, '_convergence_iteration'):
            self.notify('convergence_iteration', self._convergence_iteration)
        if hasattr(self, '_energy_history'):
            self.notify('energy_history', [float(e) for e in self._energy_history])
        if hasattr(self, '_state_history'):
            self.notify('state_history', 
                       [[float(s) for s in state] for state in self._state_history])
        if hasattr(self, '_attractors'):
            attractors_list = [attractor.tolist() if hasattr(attractor, 'tolist') else list(attractor) 
                              for attractor in self._attractors]
            self.notify('attractors', attractors_list)
            self.notify('num_attractors', len(self._attractors))
        if hasattr(self, '_attractor_energies'):
            self.notify('attractor_energies', [float(e) for e in self._attractor_energies])
        if hasattr(self, 'num_neurons'):
            self.notify('num_neurons', self.num_neurons)

    def run(self):
        self.notify('has_finished', False)
        self.notify('is_converged', False)
        # Call parent run which handles the algorithm logic
        # But we need to notify after each iteration
        # So we override the run loop to add notifications
        self._initialize_network()
        # Notify num_neurons after initialization
        self.notify('num_neurons', self.num_neurons)
        self._notify_state()
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            # Update iteration counter
            self.notify('current_iterations', epoch)
            self._iterate()
        # Final notification
        self._notify_state()
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # Notify updated state after iteration
        self._notify_state()
        # Sleep to keep GUI responsive
        time.sleep(self.ui_refresh_interval)

