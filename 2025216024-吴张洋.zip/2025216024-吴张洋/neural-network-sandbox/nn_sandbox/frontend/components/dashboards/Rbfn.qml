import QtQml 2.13
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'RBFN'
    ColumnLayout {
        GroupBox {
            title: '数据集'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: rbfnBridge && rbfnBridge.dataset_dict ? Object.keys(rbfnBridge.dataset_dict) : []
                enabled: rbfnBridge && rbfnBridge.has_finished
                onActivated: () => {
                    if (rbfnBridge && rbfnBridge.dataset_dict) {
                        rbfnBridge.current_dataset_name = currentText
                        dataChart.updateDataset(rbfnBridge.dataset_dict[datasetCombobox.currentText])
                        dataChart.updateFittedCurve()
                        // 如果是曲线拟合数据集，更新默认参数
                        if (currentText === 'rbf_curve_fitting') {
                            totalEpoches.value = 100
                            clusterCount.value = 8
                            // acceptable_range 会在算法初始化时自动调整
                            // 初始学习率已设置为0.6
                            // 界面刷新间隔已设置为原来的1/3
                        }
                    }
                }
                Component.onCompleted: () => {
                    if (rbfnBridge && rbfnBridge.dataset_dict) {
                        rbfnBridge.current_dataset_name = currentText
                        dataChart.updateDataset(rbfnBridge.dataset_dict[datasetCombobox.currentText])
                        dataChart.updateFittedCurve()
                        // 如果是曲线拟合数据集，更新默认参数
                        if (currentText === 'rbf_curve_fitting') {
                            totalEpoches.value = 100
                            clusterCount.value = 8
                        }
                    }
                }
            }
        }
        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: '总训练轮数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: (rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting') ? 100 : 10
                    to: 999999
                    onValueChanged: rbfnBridge.total_epoches = value
                    Component.onCompleted: rbfnBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                CheckBox {
                    id: mostCorrectRateCheckBox
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    text: '最高正确率'
                    checked: true
                    onCheckedChanged: rbfnBridge.most_correct_rate_checkbox = checked
                    Component.onCompleted: rbfnBridge.most_correct_rate_checkbox = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: mostCorrectRateCheckBox.checked && rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: 1.00 * 100
                    onValueChanged: rbfnBridge.most_correct_rate = value / 100
                    Component.onCompleted: rbfnBridge.most_correct_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '可接受范围 (±)'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: (rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting') ? 0.1 * 100 : 0.5 * 100
                    to: 999999 * 100
                    onValueChanged: rbfnBridge.acceptable_range = value / 100
                    Component.onCompleted: rbfnBridge.acceptable_range = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '初始学习率'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: (rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting') ? 0.6 * 100 : 0.8 * 100
                    onValueChanged: rbfnBridge.initial_learning_rate = value / 100
                    Component.onCompleted: rbfnBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '搜索迭代常数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: 10000
                    to: 999999
                    onValueChanged: rbfnBridge.search_iteration_constant = value
                    Component.onCompleted: rbfnBridge.search_iteration_constant = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'K均值聚类数量'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: clusterCount
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: (rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting') ? 8 : 3
                    from: 1
                    to: rbfnBridge && rbfnBridge.dataset_dict && rbfnBridge.dataset_dict[datasetCombobox.currentText] ? Math.ceil((rbfnBridge.dataset_dict[datasetCombobox.currentText].length) * (1 - rbfnBridge.test_ratio)) : 100
                    onValueChanged: rbfnBridge.cluster_count = value
                    Component.onCompleted: rbfnBridge.cluster_count = value
                    Layout.fillWidth: true
                }
                Label {
                    text: '测试-训练比例'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: rbfnBridge.test_ratio = value / 100
                    Component.onCompleted: rbfnBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '界面刷新间隔'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: rbfnBridge && rbfnBridge.has_finished
                    editable: true
                    value: (rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting') ? (0.1 / 3) * 100 : 0.1 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: rbfnBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: rbfnBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: '信息'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: rbfnBridge && rbfnBridge.has_finished
                    startButton.onClicked: () => {
                        if (rbfnBridge) {
                            rbfnBridge.start_rbfn_algorithm()
                            dataChart.clear()
                            dataChart.updateTrainingDataset(rbfnBridge.training_dataset)
                            dataChart.updateTestingDataset(rbfnBridge.testing_dataset)
                            rateChart.reset()
                        }
                    }
                    stopButton.enabled: rbfnBridge && !rbfnBridge.has_finished
                    stopButton.onClicked: () => {
                        if (rbfnBridge) {
                            rbfnBridge.stop_rbfn_algorithm()
                        }
                    }
                    progressBar.value: rbfnBridge && rbfnBridge.training_dataset ? (rbfnBridge.current_iterations + 1) / (totalEpoches.value * rbfnBridge.training_dataset.length) : 0
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前训练轮次'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        if (!rbfnBridge || !rbfnBridge.training_dataset) return 1
                        const epoch = Math.floor(rbfnBridge.current_iterations / rbfnBridge.training_dataset.length) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: '当前训练迭代'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: rbfnBridge ? (rbfnBridge.current_iterations + 1) : 0
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        if (rbfnBridge) {
                            dataChart.updateNeurons()
                            dataChart.updateFittedCurve()
                            neuronChart.updateAxisY()
                            rateChart.bestCorrectRate.append(
                                rbfnBridge.current_iterations + 1,
                                rbfnBridge.best_correct_rate
                            )
                            rateChart.trainingCorrectRate.append(
                                rbfnBridge.current_iterations + 1,
                                rbfnBridge.current_correct_rate
                            )
                            rateChart.testingCorrectRate.append(
                                rbfnBridge.current_iterations + 1,
                                rbfnBridge.test_correct_rate
                            )
                        }
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前学习率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: rbfnBridge ? rbfnBridge.current_learning_rate.toFixed(toFixedValue) : "0.00"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '最佳训练正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: rbfnBridge ? rbfnBridge.best_correct_rate.toFixed(toFixedValue) : "0.00"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前训练正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: rbfnBridge ? rbfnBridge.current_correct_rate.toFixed(toFixedValue) : "0.00"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前测试正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: rbfnBridge ? rbfnBridge.test_correct_rate.toFixed(toFixedValue) : "0.00"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            property var neuronScatters: []
            property var fittedCurveSeries: null
            property var bestFittedCurveSeries: null
            property bool isCurveFitting: false

            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true

            function updateNeurons() {
                neuronScatters.forEach(neuron => {removeSeries(neuron)})
                neuronScatters = []

                if (rbfnBridge && rbfnBridge.current_neurons) {
                    for (let {mean: m, standardDeviation: sd, synapticWeight: sw} of rbfnBridge.current_neurons) {
                        neuronScatters.push(createHoverableNeuronSeries(m))
                    }
                }
            }
            
            function updateFittedCurve() {
                // 检查是否是曲线拟合模式
                isCurveFitting = rbfnBridge && rbfnBridge.current_dataset_name === 'rbf_curve_fitting'
                
                if (!isCurveFitting) {
                    // 如果不是曲线拟合模式，移除拟合曲线
                    if (fittedCurveSeries) {
                        removeSeries(fittedCurveSeries)
                        fittedCurveSeries = null
                    }
                    if (bestFittedCurveSeries) {
                        removeSeries(bestFittedCurveSeries)
                        bestFittedCurveSeries = null
                    }
                    return
                }
                
                // 创建或更新当前拟合曲线
                if (!fittedCurveSeries) {
                    fittedCurveSeries = createSeries(
                        ChartView.SeriesTypeLine, 'RBF拟合曲线',
                        xAxis, yAxis
                    )
                    fittedCurveSeries.color = '#FF6B6B'
                    fittedCurveSeries.width = 3
                    fittedCurveSeries.useOpenGL = true
                }
                
                // 更新当前拟合曲线数据
                if (rbfnBridge && rbfnBridge.fitted_curve && rbfnBridge.fitted_curve.length > 0) {
                    fittedCurveSeries.clear()
                    for (let point of rbfnBridge.fitted_curve) {
                        fittedCurveSeries.append(point[0], point[1])
                    }
                }
                
                // 创建或更新最佳拟合曲线
                if (!bestFittedCurveSeries) {
                    bestFittedCurveSeries = createSeries(
                        ChartView.SeriesTypeLine, '最佳拟合曲线',
                        xAxis, yAxis
                    )
                    bestFittedCurveSeries.color = '#4ECDC4'
                    bestFittedCurveSeries.width = 2
                    bestFittedCurveSeries.useOpenGL = true
                }
                
                // 更新最佳拟合曲线数据
                if (rbfnBridge && rbfnBridge.best_fitted_curve && rbfnBridge.best_fitted_curve.length > 0) {
                    bestFittedCurveSeries.clear()
                    for (let point of rbfnBridge.best_fitted_curve) {
                        bestFittedCurveSeries.append(point[0], point[1])
                    }
                }
            }

            function createHoverableNeuronSeries(mean) {
                const newSeries = createSeries(
                    ChartView.SeriesTypeScatter, '中心',
                    xAxis, yAxis
                )
                newSeries.color = 'black'
                newSeries.hovered.connect((point, state) => {
                    const position = mapToPosition(point)
                    chartToolTip.x = position.x - chartToolTip.width
                    chartToolTip.y = position.y - chartToolTip.height
                    chartToolTip.text = `Mean: (${point.x}, ${point.y})`
                    chartToolTip.visible = state
                })
                // mean是一个数组，包含[x, y]坐标
                if (mean && mean.length >= 2) {
                    newSeries.append(mean[0], mean[1])
                }
                newSeries.useOpenGL = true
                return newSeries
            }

            // XXX: sadly, QML does not have `super` access to the base class. Thus,
            // we cannot call super method in overridden methods.
            // Further details: https://bugreports.qt.io/browse/QTBUG-25942
            function clear() {
                removeAllSeries()
                scatterSeriesMap = {}
                neuronScatters = []
                fittedCurveSeries = null
                bestFittedCurveSeries = null
            }
        }
        RowLayout {
            ChartView {
                id: neuronChart
                antialiasing: true
                Layout.fillWidth: true
                Layout.fillHeight: true
                ToolTip {
                    id: neuronChartToolTip
                    x: (parent.width - width) / 2
                    y: (parent.height - height) / 2
                }
                BarSeries {
                    id: neuronChartSeries
                    useOpenGL: true
                    axisX: BarCategoryAxis {
                        titleText: '神经元'
                        categories: Array.from(Array(clusterCount.value).keys())
                    }
                    axisY: ValueAxis {
                        id: neuronChartAxisY
                        max: 0
                        min: 0
                    }
                    BarSet {
                        id: standardDeviationBarSet
                        label: '标准差'
                        values: rbfnBridge && rbfnBridge.current_neurons ? rbfnBridge.current_neurons.map(neuron => neuron.standard_deviation) : []
                    }
                    BarSet {
                        id: synapticWeightBarSet
                        label: '突触权重'
                        values: rbfnBridge && rbfnBridge.current_neurons ? rbfnBridge.current_neurons.map(neuron => neuron.synaptic_weight) : []
                    }
                    onHovered: (status, index, barset) => {
                        neuronChartToolTip.text = barset.at(index)
                        neuronChartToolTip.visible = status
                    }
                }
                function updateAxisY() {
                    const max = Math.max(0, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    const min = Math.min(0, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    neuronChartAxisY.max = isFinite(max) ? max : 0
                    neuronChartAxisY.min = isFinite(min) ? min : 0
                }
            }
            RateChart {
                id: rateChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }
    Connections {
        target: rbfnBridge
        // update the chart scatter series to the best neurons at the end of the
        // training.
        function onHas_finishedChanged() {
            dataChart.updateNeurons()
            dataChart.updateFittedCurve()
        }
        function onFitted_curveChanged() {
            dataChart.updateFittedCurve()
        }
        function onBest_fitted_curveChanged() {
            dataChart.updateFittedCurve()
        }
        function onBest_correct_rateChanged() {
            dataChart.updateFittedCurve()
        }
    }
}