import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'BoltzmannMachine'
    
    Flickable {
        anchors.fill: parent
        contentHeight: mainLayout.implicitHeight
        clip: true
        
        ColumnLayout {
            id: columnLayout
            width: parent.width
            spacing: 15
            
            // Remove anchors for layout-managed item
            // ==================== Temperature Control ====================
            GroupBox {
                id: tempControl
                title: "Temperature Control (热温度控制)"
                Layout.fillWidth: true
                Layout.preferredHeight: 140
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 8
                    
                    RowLayout {
                        Layout.fillWidth: true
                        
                        Text {
                            text: "Temperature:"
                            font.pixelSize: 12
                            color: "#333333"
                        }
                        
                        Slider {
                            id: tempSlider
                            Layout.fillWidth: true
                            from: 0.1
                            to: 5.0
                            stepSize: 0.1
                            value: 1.0
                            
                            onMoved: {
                                boltzmannBridge.set_temperature(value)
                            }
                        }
                        
                        Text {
                            text: "T = " + boltzmannBridge.temperature.toFixed(2)
                            font.pixelSize: 12
                            font.bold: true
                            color: boltzmannBridge.temperature > 2.0 ? "#FF6600" : "#0066FF"
                            width: 60
                        }
                    }
                    
                    RowLayout {
                        Layout.fillWidth: true
                        
                        Text {
                            text: "Annealing: "
                            font.pixelSize: 11
                            color: "#666666"
                        }
                        
                        Button {
                            text: "Start (从3.0冷却到0.1)"
                            Layout.fillWidth: true
                            onClicked: {
                                boltzmannBridge.anneal(3.0, 0.1, 0.05, 5)
                            }
                        }
                        
                        Button {
                            text: "Reset"
                            onClicked: {
                                boltzmannBridge.reset()
                                tempSlider.value = 1.0
                            }
                        }
                    }
                    
                    Item { Layout.fillHeight: true }
                }
            }
            
            // ==================== Network Visualization ====================
            GroupBox {
                id: networkViz
                title: "Three-Neuron Network (三神经元网络可视化)"
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 8
                    
                    Rectangle {
                        id: networkCanvas
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        color: "#FFFFFF"
                        border.color: "#CCCCCC"
                        border.width: 1
                        
                        Canvas {
                            id: neuronCanvas
                            anchors.fill: parent
                            
                            onPaint: {
                                var ctx = getContext('2d')
                                var w = width
                                var h = height
                                
                                // Clear canvas
                                ctx.fillStyle = '#FFFFFF'
                                ctx.fillRect(0, 0, w, h)
                                
                                // Three neuron positions (equilateral triangle)
                                var positions = [
                                    {x: w/2, y: 30},           // top
                                    {x: 40, y: h - 30},        // bottom-left
                                    {x: w - 40, y: h - 30}     // bottom-right
                                ]
                                
                                var state = boltzmannBridge.current_state
                                
                                // Draw connections (weights)
                                var weights = boltzmannBridge.weights_matrix
                                
                                for (var i = 0; i < 3; i++) {
                                    for (var j = i + 1; j < 3; j++) {
                                        var w_ij = weights[i][j]
                                        
                                        ctx.lineWidth = 1 + Math.abs(w_ij) * 2
                                        ctx.strokeStyle = w_ij > 0 ? '#0066FF' : '#FF6600'
                                        ctx.globalAlpha = Math.min(1.0, Math.abs(w_ij) * 2)
                                        
                                        ctx.beginPath()
                                        ctx.moveTo(positions[i].x, positions[i].y)
                                        ctx.lineTo(positions[j].x, positions[j].y)
                                        ctx.stroke()
                                    }
                                }
                                
                                ctx.globalAlpha = 1.0
                                
                                // Draw neurons
                                for (var i = 0; i < 3; i++) {
                                    // Neuron circle
                                    var neuronColor = state[i] === 1 ? '#0066FF' : '#CCCCCC'
                                    ctx.fillStyle = neuronColor
                                    ctx.beginPath()
                                    ctx.arc(positions[i].x, positions[i].y, 25, 0, 2 * Math.PI)
                                    ctx.fill()
                                    
                                    // Border
                                    ctx.strokeStyle = '#333333'
                                    ctx.lineWidth = 2
                                    ctx.stroke()
                                    
                                    // Label
                                    ctx.fillStyle = '#FFFFFF'
                                    ctx.font = 'bold 14px Arial'
                                    ctx.textAlign = 'center'
                                    ctx.textBaseline = 'middle'
                                    ctx.fillText('x' + (i + 1), positions[i].x, positions[i].y)
                                }
                                
                                // Current state label
                                ctx.fillStyle = '#000000'
                                ctx.font = '11px Arial'
                                ctx.textAlign = 'left'
                                ctx.textBaseline = 'top'
                                var stateStr = '(' + state[0] + ',' + state[1] + ',' + state[2] + ')'
                                ctx.fillText('State: ' + stateStr, 10, 10)
                            }
                            
                            Connections {
                                target: boltzmannBridge
                                function onCurrent_stateChanged() {
                                    neuronCanvas.requestPaint()
                                }
                                function onWeights_matrixChanged() {
                                    neuronCanvas.requestPaint()
                                }
                            }
                        }
                    }
                }
            }
            
            // ==================== State Space Grid ====================
            GroupBox {
                id: stateGrid
                title: "State Space (8个可能状态热力图)"
                Layout.fillWidth: true
                Layout.preferredHeight: 120
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 8
                    
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        color: "#F5F5F5"
                        border.color: "#DDDDDD"
                        border.width: 1
                        
                        Grid {
                            anchors.centerIn: parent
                            columns: 4
                            spacing: 4
                            
                            Repeater {
                                model: 8
                                
                                Control {
                                    id: stateBox
                                    width: 50
                                    height: 50
                                    
                                    // Color intensity based on visit frequency
                                    property real visitFreq: {
                                        var visits = boltzmannBridge.visit_counts[index]
                                        var total = boltzmannBridge.total_visits
                                        return total > 0 ? visits / total : 0
                                    }
                                    
                                    background: Rectangle {
                                        color: {
                                            var freq = stateBox.visitFreq
                                            // HSL: hue 0.6 (blue), saturation 0.7, lightness 1.0-freq*0.7
                                            return Qt.hsla(0.6, 0.7, Math.max(0.3, 1.0 - freq * 0.7), 1.0)
                                        }
                                        border.color: boltzmannBridge.current_state_id === index ? '#00FF00' : '#AAAAAA'
                                        border.width: boltzmannBridge.current_state_id === index ? 2 : 1
                                    }
                                    
                                    // Size based on probability
                                    scale: 0.5 + (boltzmannBridge.probabilities[index] * 1.5)
                                    
                                    Text {
                                        anchors.centerIn: parent
                                        text: {
                                            var binary = index.toString(2).padStart(3, '0')
                                            return binary[0] + binary[1] + binary[2]
                                        }
                                        font.pixelSize: 11
                                        font.bold: true
                                        color: '#000000'
                                    }
                                    
                                    ToolTip {
                                        visible: mouseArea.containsMouse
                                        text: {
                                            var visitCount = boltzmannBridge.visit_counts[index]
                                            var prob = (boltzmannBridge.probabilities[index] * 100).toFixed(1)
                                            return "State: " + index + "\nVisits: " + visitCount + "\nProb: " + prob + "%"
                                        }
                                    }
                                    
                                    MouseArea {
                                        id: mouseArea
                                        anchors.fill: parent
                                        hoverEnabled: true
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // ==================== Control Buttons ====================
            GroupBox {
                id: controls
                title: "Control (控制)"
                Layout.fillWidth: true
                Layout.preferredHeight: 70
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 8
                    
                    RowLayout {
                        Layout.fillWidth: true
                        
                        Button {
                            text: "Initialize"
                            Layout.fillWidth: true
                            onClicked: {
                                boltzmannBridge.randomize_weights()
                                boltzmannBridge.randomize_state()
                            }
                        }
                        
                        Button {
                            text: "Single Step (Gibbs采样)"
                            Layout.fillWidth: true
                            onClicked: {
                                boltzmannBridge.step()
                            }
                        }
                        
                        Button {
                            text: "Random State"
                            Layout.fillWidth: true
                            onClicked: {
                                boltzmannBridge.randomize_state()
                            }
                        }
                    }
                    
                    Item { Layout.fillHeight: true }
                }
            }
            
            // ==================== Energy Distribution ====================
            GroupBox {
                id: energyDist
                title: "Energy Distribution (8个状态的能量分布)"
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 8
                    
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        color: "#FFFFFF"
                        border.color: "#CCCCCC"
                        border.width: 1
                        
                        Canvas {
                            id: energyCanvas
                            anchors.fill: parent
                            
                            onPaint: {
                                var ctx = getContext('2d')
                                var w = width
                                var h = height
                                
                                ctx.fillStyle = '#FFFFFF'
                                ctx.fillRect(0, 0, w, h)
                                
                                var landscape = boltzmannBridge.energy_landscape
                                if (!landscape || !landscape.energies) return
                                
                                var energies = landscape.energies
                                var probs = landscape.probabilities
                                
                                // Validate arrays
                                if (!energies || energies.length === 0 || !probs || probs.length === 0) return
                                
                                // Find min and max energy for scaling (with NaN/Inf checks)
                                var minE = Number.MAX_VALUE
                                var maxE = -Number.MAX_VALUE
                                for (var k = 0; k < energies.length; k++) {
                                    var e = energies[k]
                                    if (isFinite(e)) {
                                        if (e < minE) minE = e
                                        if (e > maxE) maxE = e
                                    }
                                }
                                
                                // Fallback if all values are non-finite
                                if (!isFinite(minE) || !isFinite(maxE)) {
                                    minE = -5
                                    maxE = 5
                                }
                                
                                var eRange = maxE - minE + 0.1
                                if (eRange < 0.1) eRange = 0.1  // Avoid division by very small number
                                
                                // Draw bars
                                var barWidth = (w - 20) / 8
                                var maxBarHeight = h - 40
                                
                                for (var i = 0; i < 8; i++) {
                                    var x = 10 + i * barWidth
                                    var energy = energies[i]
                                    var prob = probs[i]
                                    
                                    // Safely handle NaN/Inf values
                                    if (!isFinite(energy)) energy = minE
                                    if (!isFinite(prob)) prob = 0
                                    prob = Math.max(0, Math.min(1, prob))  // Clamp probability to [0,1]
                                    
                                    // Energy bar (blue)
                                    var eNorm = (energy - minE) / eRange
                                    eNorm = Math.max(0, Math.min(1, eNorm))  // Clamp to [0,1]
                                    var eBarHeight = eNorm * maxBarHeight
                                    
                                    ctx.fillStyle = '#0066FF'
                                    ctx.globalAlpha = 0.6
                                    ctx.fillRect(x + 2, h - 30 - eBarHeight, barWidth / 2 - 3, Math.max(0, eBarHeight))
                                    
                                    // Probability bar (orange)
                                    var pBarHeight = prob * maxBarHeight
                                    ctx.fillStyle = '#FF9900'
                                    ctx.globalAlpha = 0.6
                                    ctx.fillRect(x + barWidth / 2 + 1, h - 30 - pBarHeight, barWidth / 2 - 3, Math.max(0, pBarHeight))
                                    
                                    ctx.globalAlpha = 1.0
                                    
                                    // State label
                                    ctx.fillStyle = '#000000'
                                    ctx.font = '10px Arial'
                                    ctx.textAlign = 'center'
                                    var binary = i.toString(2).padStart(3, '0')
                                    ctx.fillText(binary, x + barWidth / 2, h - 8)
                                }
                                
                                // Legend
                                ctx.fillStyle = '#0066FF'
                                ctx.fillRect(10, 10, 10, 10)
                                ctx.fillStyle = '#000000'
                                ctx.font = '11px Arial'
                                ctx.textAlign = 'left'
                                ctx.fillText('Energy', 25, 18)
                                
                                ctx.fillStyle = '#FF9900'
                                ctx.fillRect(100, 10, 10, 10)
                                ctx.fillStyle = '#000000'
                                ctx.fillText('Probability', 115, 18)
                            }
                            
                            Connections {
                                target: boltzmannBridge
                                function onEnergy_landscapeChanged() {
                                    energyCanvas.requestPaint()
                                }
                                function onProbabilitiesChanged() {
                                    energyCanvas.requestPaint()
                                }
                                function onVisit_countsChanged() {
                                    energyCanvas.requestPaint()
                                }
                            }
                        }
                    }
                }
            }
            
            // ==================== Statistics Panel ====================
            GroupBox {
                id: stats
                title: "Statistics (统计信息)"
                Layout.fillWidth: true
                Layout.preferredHeight: 110
                
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 5
                    width: parent.width
                    spacing: 5
                    
                    GridLayout {
                        Layout.fillWidth: true
                        columns: 4
                        
                        Text { text: "Iteration:"; font.bold: true; color: "#333333" }
                        Text { text: boltzmannBridge.iteration; color: "#0066FF"; font.bold: true }
                        
                        Text { text: "Energy:"; font.bold: true; color: "#333333" }
                        Text { 
                            text: boltzmannBridge.energy.toFixed(2)
                            color: boltzmannBridge.energy < -1.0 ? "#00AA00" : "#FF6600"
                            font.bold: true
                        }
                        
                        Text { text: "Temperature:"; font.bold: true; color: "#333333" }
                        Text { text: boltzmannBridge.temperature.toFixed(3); color: "#0066FF"; font.bold: true }
                        
                        Text { text: "Thermal Eq.:"; font.bold: true; color: "#333333" }
                        Text { 
                            text: boltzmannBridge.thermal_equilibrium ? "YES ✓" : "NO"
                            color: boltzmannBridge.thermal_equilibrium ? "#00AA00" : "#FF6600"
                            font.bold: true
                        }
                        
                        Text { text: "Visited States:"; font.bold: true; color: "#333333" }
                        Text { text: boltzmannBridge.visited_state_count + "/8"; color: "#0066FF"; font.bold: true }
                        
                        Text { text: "Total Visits:"; font.bold: true; color: "#333333" }
                        Text { text: boltzmannBridge.total_visits; color: "#0066FF"; font.bold: true }
                        
                        Text { text: "Current State:"; font.bold: true; color: "#333333" }
                        Text { 
                            text: "(" + boltzmannBridge.current_state[0] + "," + 
                                  boltzmannBridge.current_state[1] + "," + 
                                  boltzmannBridge.current_state[2] + ")"
                            color: "#0066FF"
                            font.bold: true
                            font.family: "Courier"
                        }
                    }
                    
                    Item { Layout.fillHeight: true }
                }
            }
            
            Item { Layout.fillHeight: true }
        }
    }
}
