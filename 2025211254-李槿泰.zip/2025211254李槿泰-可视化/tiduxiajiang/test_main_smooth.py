#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试主程序的平滑曲线功能
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 设置中文字体
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

def rosenbrock_function(x):
    """Rosenbrock函数"""
    return 100 * (x[1] - x[0]**2)**2 + (1 - x[0])**2

def test_smooth_plot():
    """测试平滑绘图功能"""
    # 创建图形
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制函数表面
    x_range = [-2.0, 3.0]
    y_range = [-1.0, 4.0]
    X = np.linspace(x_range[0], x_range[1], 50)
    Y = np.linspace(y_range[0], y_range[1], 50)
    X, Y = np.meshgrid(X, Y)
    Z = np.zeros_like(X)
    
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            Z[i, j] = rosenbrock_function(np.array([X[i, j], Y[i, j]]))
    
    Z = np.clip(Z, 0, 1000)
    ax.plot_surface(X, Y, Z, alpha=0.6, cmap='viridis', vmin=0, vmax=1000)
    
    # 创建测试路径点（模拟算法生成的路径）
    path_points = [
        np.array([-1.5, 2.0]),
        np.array([-1.2, 1.8]),
        np.array([-0.9, 1.6]),
        np.array([-0.6, 1.4]),
        np.array([-0.3, 1.2]),
        np.array([0.0, 1.0]),
        np.array([0.3, 1.0]),
        np.array([0.6, 1.0]),
        np.array([0.9, 1.0]),
        np.array([1.0, 1.0])
    ]
    
    # 计算Z坐标
    z_points = [rosenbrock_function(p) for p in path_points]
    
    # 转换为numpy数组
    x_path = np.array([p[0] for p in path_points])
    y_path = np.array([p[1] for p in path_points])
    z_path = np.array(z_points)
    
    print(f"原始路径点数量: {len(path_points)}")
    
    # 测试平滑曲线绘制（模拟主程序中的代码）
    if len(x_path) > 1:
        print("开始平滑处理...")
        
        # 使用样条插值创建平滑曲线
        try:
            from scipy.interpolate import CubicSpline
            
            # 创建参数化曲线
            t = np.linspace(0, 1, len(x_path))
            
            # 使用三次样条插值
            cs_x = CubicSpline(t, x_path)
            cs_y = CubicSpline(t, y_path)
            cs_z = CubicSpline(t, z_path)
            
            # 生成更密集的点用于平滑曲线
            t_smooth = np.linspace(0, 1, max(50, len(x_path) * 10))
            x_smooth = cs_x(t_smooth)
            y_smooth = cs_y(t_smooth)
            z_smooth = cs_z(t_smooth)
            
            print(f"平滑后点数: {len(x_smooth)}")
            
        except ImportError:
            print("scipy不可用，使用numpy插值")
            # 如果没有scipy，使用numpy插值
            t = np.linspace(0, 1, len(x_path))
            t_smooth = np.linspace(0, 1, max(50, len(x_path) * 5))
            x_smooth = np.interp(t_smooth, t, x_path)
            y_smooth = np.interp(t_smooth, t, y_path)
            z_smooth = np.interp(t_smooth, t, z_path)
            
            print(f"使用numpy插值，平滑后点数: {len(x_smooth)}")
        
        # 绘制原始路径（直线段）
        ax.plot(x_path, y_path, z_path, 'r--', linewidth=2, alpha=0.7, label='原始路径（直线段）')
        
        # 绘制平滑曲线
        ax.plot(x_smooth, y_smooth, z_smooth, 'b-', linewidth=3, alpha=0.9, label='平滑路径')
        
        # 绘制路径点
        ax.scatter(x_path, y_path, z_path, c='red', s=30, alpha=0.8)
        
        # 标记起点和终点
        ax.scatter(x_path[0], y_path[0], z_path[0], c='green', s=100, marker='o', label='起点')
        ax.scatter(x_path[-1], y_path[-1], z_path[-1], c='yellow', s=100, marker='*', label='终点')
    
    # 设置标签
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('主程序平滑曲线测试')
    
    # 设置坐标轴范围
    ax.set_xlim(x_range)
    ax.set_ylim(y_range)
    ax.set_zlim(0, 1000)
    
    plt.legend()
    plt.tight_layout()
    plt.savefig('main_smooth_test.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    print("主程序平滑曲线测试完成，请检查main_smooth_test.png文件")

if __name__ == "__main__":
    test_smooth_plot()

