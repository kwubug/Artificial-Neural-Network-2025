import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bipolar_sigmoid


class BpAlgorithm(PredictiveAlgorithm):
    """ 
    Standard Backpropagation Neural Network Algorithm.
    
    This implementation follows the classic BP algorithm with:
    - Feed-forward computation
    - Backpropagation of errors
    - Weight updates using gradient descent
    - Momentum for faster convergence
    """

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, hidden_layers=None,
                 acceptable_error=0.001, activation_type='unipolar'):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight
        self._acceptable_error = acceptable_error
        self._activation_type = activation_type  # 'unipolar' or 'bipolar'
        
        # Network architecture: input layer, hidden layers, output layer
        # Default: one hidden layer with 5 neurons
        self.hidden_layers = hidden_layers if hidden_layers else [5]
        
        # For momentum calculation
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)
        
        # Training metrics
        self.current_error = 0.0
        self.epoch_errors = []

    def _iterate(self):
        """Single training iteration: forward pass, backward pass, and weight update."""
        # Forward propagation
        result = self._feed_forward(self.current_data[:-1])
        
        # Calculate error
        expected = self._normalize(self.current_data[-1])
        self.current_error = 0.5 * (expected - result) ** 2
        
        # Backward propagation
        deltas = self._backpropagation(expected, result)
        
        # Update weights
        self._update_weights(deltas)

    def _initialize_neurons(self):
        """
        Initialize the neural network structure.
        Architecture: input_size -> hidden_layers -> 1 (output)
        """
        input_size = len(self.training_dataset[0]) - 1  # minus the label
        
        # Choose activation function based on type
        activation_func = sigmoid if self._activation_type == 'unipolar' else bipolar_sigmoid
        
        # Create network layers: [hidden_layer1, hidden_layer2, ..., output_layer]
        self._neurons = []
        
        # Hidden layers
        for layer_size in self.hidden_layers:
            layer = tuple(Perceptron(activation_func) for _ in range(layer_size))
            self._neurons.append(layer)
        
        # Output layer (single neuron for classification)
        output_layer = (Perceptron(activation_func),)
        self._neurons.append(output_layer)
        
        self._neurons = tuple(self._neurons)

    def _feed_forward(self, data):
        """
        Feed forward the input data through all layers.
        Returns the output of the network.
        """
        results = None
        
        for layer_idx, layer in enumerate(self._neurons):
            if layer_idx == 0:
                # First hidden layer takes input data
                results = self._get_layer_output(layer, data)
            else:
                # Subsequent layers take previous layer's output
                results = self._get_layer_output(layer, results)
        
        # Return the final output (single value)
        return results[0]

    def _get_layer_output(self, layer, input_data):
        """
        Compute the output of a layer given input data.
        """
        results = []
        for neuron in layer:
            neuron.data = input_data
            results.append(neuron.result)
        return np.array(results)

    def _backpropagation(self, expected, actual_output):
        """
        Backpropagation algorithm to compute deltas for each neuron.
        Returns a dictionary mapping each neuron to its delta value.
        """
        deltas = {}
        
        # Output layer delta calculation
        output_neuron = self._neurons[-1][0]
        output_error = expected - actual_output
        
        if self._activation_type == 'unipolar':
            # 单极性Sigmoid导数: f'(x) = f(x) * (1 - f(x))
            deltas[output_neuron] = output_error * actual_output * (1 - actual_output)
        else:
            # 双极性Sigmoid导数: f'(x) = (1 - f(x)^2) / 2
            deltas[output_neuron] = output_error * (1 - actual_output**2) / 2
        
        # Hidden layers deltas (from last hidden to first)
        for layer_idx in range(len(self._neurons) - 2, -1, -1):
            layer = self._neurons[layer_idx]
            next_layer = self._neurons[layer_idx + 1]
            
            for neuron_idx, neuron in enumerate(layer):
                # Calculate error sum from next layer
                error_sum = sum(
                    deltas[next_neuron] * next_neuron.synaptic_weight[neuron_idx]
                    for next_neuron in next_layer
                )
                
                if self._activation_type == 'unipolar':
                    # 单极性Sigmoid导数
                    deltas[neuron] = neuron.result * (1 - neuron.result) * error_sum
                else:
                    # 双极性Sigmoid导数
                    deltas[neuron] = (1 - neuron.result**2) / 2 * error_sum
        
        return deltas

    def _update_weights(self, deltas):
        """
        Update synaptic weights using gradient descent with momentum.
        Δw = α * Δw_prev + η * δ * x
        where α is momentum, η is learning rate, δ is delta, x is input
        """
        for neuron in deltas:
            # Calculate weight change with momentum
            weight_change = (
                self._momentum_weight * self._synaptic_weight_diff[neuron] +
                self.current_learning_rate * deltas[neuron] * neuron.data
            )
            
            # Store for next iteration (momentum)
            self._synaptic_weight_diff[neuron] = weight_change
            
            # Update weights
            neuron.synaptic_weight += weight_change

    def _correct_rate(self, dataset):
        """
        Calculate the classification accuracy on a dataset.
        """
        if not self._neurons:
            return 0
        
        correct_count = 0
        for data in dataset:
            output = self._feed_forward(data[:-1])
            expected = self._normalize(data[-1])
            
            # Classification threshold: ±1/(2*num_classes)
            threshold = 1.0 / (2 * len(self.group_types))
            
            if abs(expected - output) < threshold:
                correct_count += 1
        
        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def _normalize(self, value):
        """
        Normalize the output value based on activation function type.
        For unipolar: normalize to [0, 1] range
        For bipolar: normalize to [-1, 1] range
        """
        min_value = np.amin(self.group_types)
        max_value = np.amax(self.group_types)
        num_classes = len(self.group_types)
        
        if self._activation_type == 'unipolar':
            # Normalize to [0, 1] range
            return (value - min_value) / (max_value - min_value) if max_value != min_value else 0.5
        else:
            # Normalize to [-1, 1] range
            if max_value == min_value:
                return 0.0
            return 2 * (value - min_value) / (max_value - min_value) - 1

    def run(self):
        """
        Main training loop with epoch-based error tracking.
        """
        self._initialize_neurons()
        
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            
            # Shuffle training data each epoch
            np.random.shuffle(self.training_dataset)
            epoch_error = 0.0
            
            # Train on each sample
            for sample_idx in range(len(self.training_dataset)):
                self.current_iterations = epoch * len(self.training_dataset) + sample_idx
                self._iterate()
                epoch_error += self.current_error
                self._save_best_neurons()
                
                if self._should_stop:
                    break
            
            # Calculate average error for the epoch
            avg_error = epoch_error / len(self.training_dataset)
            self.epoch_errors.append(avg_error)
            
            # Check stopping criteria
            if self._most_correct_rate and self.best_correct_rate >= self._most_correct_rate:
                break
            
            if avg_error < self._acceptable_error:
                break
        
        self._load_best_neurons()

