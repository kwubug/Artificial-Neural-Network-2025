import os
import sys
import threading
import time
import numpy as np
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, QThread

# 添加后端路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'backend'))
from algorithms.optimization_algorithms import (
    GradientDescent, NewtonMethod, ConjugateGradient,
    rosenbrock_function, rosenbrock_gradient, rosenbrock_hessian,
    sphere_function, sphere_gradient, sphere_hessian,
    rastrigin_function, rastrigin_gradient, rastrigin_hessian
)
from algorithms.optimization_visualizer import OptimizationComparison


class OptimizationWorker(QThread):
    """优化算法工作线程"""
    
    # 信号定义
    progress_updated = pyqtSignal(int, float, float, float)  # 迭代次数, x, y, 函数值
    algorithm_finished = pyqtSignal(str, list, list)  # 算法名, 路径, 函数值
    all_algorithms_finished = pyqtSignal(dict)
    
    def __init__(self, objective_function_name, initial_point, learning_rate, max_iterations):
        super().__init__()
        self.objective_function_name = objective_function_name
        self.initial_point = np.array(initial_point)
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self.should_stop = False
        
        # 根据函数名选择目标函数
        self.function_map = {
            'rosenbrock': (rosenbrock_function, rosenbrock_gradient, rosenbrock_hessian),
            'sphere': (sphere_function, sphere_gradient, sphere_hessian),
            'rastrigin': (rastrigin_function, rastrigin_gradient, rastrigin_hessian)
        }
        
    def stop(self):
        self.should_stop = True
        
    def run(self):
        """运行优化算法"""
        if self.objective_function_name not in self.function_map:
            return
            
        obj_func, grad_func, hess_func = self.function_map[self.objective_function_name]
        
        # 创建算法实例
        algorithms = {
            '梯度下降法': GradientDescent(obj_func, grad_func, 
                                       learning_rate=self.learning_rate, 
                                       max_iterations=self.max_iterations),
            '牛顿法': NewtonMethod(obj_func, grad_func, hess_func,
                                max_iterations=self.max_iterations),
            '共轭梯度法': ConjugateGradient(obj_func, grad_func,
                                        max_iterations=self.max_iterations)
        }
        
        results = {}
        
        for name, algorithm in algorithms.items():
            if self.should_stop:
                break
                
            try:
                # 运行优化
                optimal_point, path, function_values = algorithm.optimize(self.initial_point.copy())
                
                # 发送结果
                self.algorithm_finished.emit(name, path.tolist(), function_values)
                
                results[name] = {
                    'optimal_point': optimal_point.tolist(),
                    'path': path.tolist(),
                    'function_values': function_values,
                    'iterations': len(path) - 1,
                    'final_value': function_values[-1] if function_values else 0
                }
                
            except Exception as e:
                print(f"算法 {name} 执行失败: {e}")
                results[name] = None
                
        # 发送所有算法完成信号
        self.all_algorithms_finished.emit(results)


class OptimizationBridge(QObject):
    """优化算法桥接器"""
    
    # 信号定义
    progress_updated = pyqtSignal(int, float, float, float)
    algorithm_finished = pyqtSignal(str, list, list)
    all_algorithms_finished = pyqtSignal(dict)
    visualization_ready = pyqtSignal(str)  # 可视化图片路径
    
    def __init__(self):
        super().__init__()
        self.worker = None
        self.current_results = {}
        self.available_functions = ['rosenbrock', 'sphere', 'rastrigin']
        
    @pyqtSlot(str, list, float, int)
    def start_optimization(self, function_name, initial_point, learning_rate, max_iterations):
        """开始优化"""
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()
            
        self.worker = OptimizationWorker(function_name, initial_point, learning_rate, max_iterations)
        
        # 连接信号
        self.worker.progress_updated.connect(self.progress_updated)
        self.worker.algorithm_finished.connect(self.algorithm_finished)
        self.worker.all_algorithms_finished.connect(self.all_algorithms_finished)
        
        self.worker.start()
        
    @pyqtSlot()
    def stop_optimization(self):
        """停止优化"""
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait()
            
    @pyqtSlot(str, list, list, list)
    def create_visualization(self, function_name, paths, algorithm_names, colors):
        """创建可视化"""
        try:
            # 根据函数名选择目标函数
            function_map = {
                'rosenbrock': (rosenbrock_function, rosenbrock_gradient, rosenbrock_hessian),
                'sphere': (sphere_function, sphere_gradient, sphere_hessian),
                'rastrigin': (rastrigin_function, rastrigin_gradient, rastrigin_hessian)
            }
            
            if function_name not in function_map:
                return
                
            obj_func, grad_func, hess_func = function_map[function_name]
            
            # 创建比较器
            comparison = OptimizationComparison(obj_func, grad_func, hess_func)
            
            # 创建可视化
            fig = comparison.visualizer.create_static_plot(
                [np.array(path) for path in paths], 
                algorithm_names, 
                colors
            )
            
            # 保存图片
            import matplotlib.pyplot as plt
            save_path = f"optimization_visualization_{int(time.time())}.png"
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close(fig)
            
            self.visualization_ready.emit(save_path)
            
        except Exception as e:
            print(f"创建可视化失败: {e}")
            
    @pyqtSlot(result=list)
    def get_available_functions(self):
        """获取可用的目标函数"""
        return self.available_functions
        
    @pyqtSlot(result=dict)
    def get_current_results(self):
        """获取当前结果"""
        return self.current_results
        
    @pyqtSlot(dict)
    def set_current_results(self, results):
        """设置当前结果"""
        self.current_results = results
