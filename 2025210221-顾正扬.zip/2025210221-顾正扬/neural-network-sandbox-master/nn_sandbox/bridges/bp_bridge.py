import PyQt5.QtCore
from nn_sandbox.backend.algorithms import BatchTrainingBPAlgorithm as BPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable

class BpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    momentum_weight = BridgeProperty(0.5)
    test_ratio = BridgeProperty(0.3)
    network_shape = BridgeProperty([5, 5])
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        try:
            print(f"Starting BP Algorithm with dataset: {self.current_dataset_name}")
            self.bp_algorithm = BPAlgorithm(
                self.dataset_dict[self.current_dataset_name],
                total_epoches=self.total_epoches,
                learning_rate=self.initial_learning_rate,
                momentum_weight=self.momentum_weight,
                test_ratio=self.test_ratio,
                network_shape=self.network_shape
            )
            print("BPAlgorithm instance created, starting training...")
            self.bp_algorithm.train(self.training_dataset, self.testing_dataset)
            self.has_finished = True
            print("BP Algorithm training finished.")
        except Exception as e:
            print(f"Error during BP Algorithm training: {e}")
            self.has_finished = False

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        # Assuming you want to stop training (if needed).
        self.has_finished = False
        # Optional: Add code to stop algorithm execution (e.g., interrupt the training loop).
        print("Stopping BP Algorithm.")
