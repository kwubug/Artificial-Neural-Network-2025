import time
import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import TspAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class TspBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.01)
    total_epoches = BridgeProperty(500)
    num_cities = BridgeProperty(20)
    current_iterations = BridgeProperty(0)

    # Current state
    current_tour = BridgeProperty([])
    current_distance = BridgeProperty(0.0)
    best_tour = BridgeProperty([])
    best_distance = BridgeProperty(0.0)
    distance_history = BridgeProperty([])
    positions = BridgeProperty([])  # [[x,y], ...]

    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.tsp_algorithm = None
        self._randomize_positions()

    @PyQt5.QtCore.pyqtSlot()
    def randomize_cities(self):
        if self.has_finished:
            self._randomize_positions()

    def _randomize_positions(self):
        n = max(int(self.num_cities), 0)
        coords = np.random.rand(n, 2)
        self.positions = coords.tolist()

    @PyQt5.QtCore.pyqtSlot()
    def start_tsp_algorithm(self):
        if not self.has_finished:
            return
        dataset = np.array(self.positions, dtype=float)
        self.tsp_algorithm = ObservableTspAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=dataset,
            total_epoches=int(self.total_epoches),
        )
        self.tsp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp_algorithm(self):
        if self.tsp_algorithm:
            self.tsp_algorithm.stop()


class ObservableTspAlgorithm(Observable, TspAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        TspAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        needs_notification = False
        if name.startswith('_') and hasattr(self, '_observer'):
            needs_notification = True
        super().__setattr__(name, value)
        if needs_notification:
            if name == 'current_iterations':
                self.notify(name, value)
            elif name == '_tour':
                self.notify('current_tour', list(value) if value is not None else [])
            elif name == '_best_tour':
                self.notify('best_tour', list(value) if value is not None else [])
            elif name == '_distance':
                self.notify('current_distance', float(value))
                if hasattr(self, '_distance_history') and self._distance_history:
                    self.notify('distance_history', [float(d) for d in self._distance_history])
            elif name == '_best_distance':
                self.notify('best_distance', float(value))
            elif name == '_positions':
                self.notify('positions', value.tolist() if hasattr(value, 'tolist') else list(value))

    def _notify_state(self):
        self.notify('current_iterations', int(self.current_iterations))
        self.notify('current_tour', list(self.tour))
        self.notify('best_tour', list(self.best_tour))
        self.notify('current_distance', float(self.distance))
        self.notify('best_distance', float(self.best_distance))
        self.notify('distance_history', [float(d) for d in self.distance_history])
        self.notify('positions', self.positions.tolist() if hasattr(self.positions, 'tolist') else list(self.positions))

    def run(self):
        self.notify('has_finished', False)
        # initialize and first notify
        self._initialize()
        self._notify_state()
        for iteration in range(self._total_epoches):
            if self._should_stop:
                break
            self.current_iterations = iteration
            self._iterate()
            self._notify_state()
            time.sleep(self.ui_refresh_interval)
        self._notify_state()
        self.notify('has_finished', True)