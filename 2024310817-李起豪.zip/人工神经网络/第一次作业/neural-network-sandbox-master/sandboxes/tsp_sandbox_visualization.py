"""
利用沙箱可视化旅行商问题（TSP）的求解过程。

主要步骤：
1. 随机生成若干城市坐标；
2. 使用模拟退火算法逐步优化巡回路径，记录路径长度变化；
3. 绘制初始、中期、最终路径，以及总距离收敛曲线；
4. 保存可视化图像和结果摘要文件。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple

import matplotlib.pyplot as plt
import numpy as np


np.random.seed(99)
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial"]
plt.rcParams["axes.unicode_minus"] = False


@dataclass(frozen=True)
class TSPConfig:
    city_count: int = 12
    initial_temperature: float = 10.0
    cooling_rate: float = 0.995
    iterations: int = 1800


def total_distance(coords: np.ndarray, tour: np.ndarray) -> float:
    reordered = coords[tour]
    shifted = np.roll(reordered, shift=-1, axis=0)
    return np.sum(np.linalg.norm(reordered - shifted, axis=1))


def simulated_annealing(coords: np.ndarray, config: TSPConfig) -> Tuple[np.ndarray, List[float], List[np.ndarray]]:
    n = coords.shape[0]
    current_tour = np.arange(n)
    np.random.shuffle(current_tour)
    best_tour = current_tour.copy()
    current_distance = total_distance(coords, current_tour)
    best_distance = current_distance
    temperature = config.initial_temperature

    distance_history: List[float] = [current_distance]
    tour_snapshots: List[np.ndarray] = [current_tour.copy()]

    for step in range(1, config.iterations + 1):
        i, j = np.sort(np.random.choice(n, size=2, replace=False))
        proposal = current_tour.copy()
        proposal[i:j] = proposal[i:j][::-1]
        proposal_distance = total_distance(coords, proposal)
        delta = proposal_distance - current_distance
        if delta < 0 or np.random.rand() < np.exp(-delta / max(temperature, 1e-6)):
            current_tour = proposal
            current_distance = proposal_distance
            if current_distance < best_distance:
                best_distance = current_distance
                best_tour = current_tour.copy()
        distance_history.append(current_distance)
        temperature *= config.cooling_rate
        if step in (config.iterations // 3, 2 * config.iterations // 3):
            tour_snapshots.append(current_tour.copy())

    tour_snapshots.append(best_tour.copy())
    return best_tour, distance_history, tour_snapshots


def plot_tours(
    coords: np.ndarray,
    tour_snapshots: List[np.ndarray],
    distance_history: List[float],
    config: TSPConfig,
    output_path: Path,
) -> None:
    fig, axes = plt.subplots(
        nrows=1,
        ncols=3,
        figsize=(15, 4.8),
    )
    titles = ["初始路径", "中期路径", "最终路径"]
    for ax, tour, title in zip(axes, tour_snapshots[:3], titles):
        ordered = coords[tour]
        ordered = np.vstack([ordered, ordered[0]])
        ax.plot(ordered[:, 0], ordered[:, 1], "-o", color="tab:blue", linewidth=1.4, markersize=5)
        for idx, (x, y) in enumerate(coords):
            ax.text(x + 0.02, y + 0.02, str(idx), fontsize=9)
        ax.set_title(f"{title}\n距离={total_distance(coords, tour):.2f}")
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect("equal")
        ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    fig2, ax_dist = plt.subplots(figsize=(6, 4))
    ax_dist.plot(np.arange(len(distance_history)), distance_history, color="tab:red", linewidth=1.4)
    ax_dist.set_xlabel("迭代步")
    ax_dist.set_ylabel("路径长度")
    ax_dist.set_title("路径长度收敛曲线")
    ax_dist.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    handles, labels = [], []
    for ax in (*axes, ax_dist):
        h, l = ax.get_legend_handles_labels()
        handles.extend(h)
        labels.extend(l)
    if handles:
        fig.legend(
            handles,
            labels,
            loc="center right",
            bbox_to_anchor=(1.02, 0.5),
            frameon=False,
        )

    fig.tight_layout(rect=(0, 0, 0.92, 1))
    fig2.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path.with_name("tsp_tour_evolution.png"), dpi=300, bbox_inches="tight")
    fig2.savefig(output_path.with_name("tsp_distance_curve.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)
    plt.close(fig2)


def export_summary(
    summary_path: Path,
    best_tour: np.ndarray,
    best_distance: float,
    config: TSPConfig,
) -> None:
    lines = [
        "旅行商问题可视化结果摘要",
        f"城市数量: {config.city_count}",
        f"迭代次数: {config.iterations}",
        f"最佳路径长度: {best_distance:.4f}",
        "最佳巡回顺序:",
        " -> ".join(map(str, best_tour.tolist())) + f" -> {best_tour[0]}",
    ]
    summary_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    config = TSPConfig()
    coords = np.random.uniform(0, 5, size=(config.city_count, 2))
    best_tour, distance_history, snapshots = simulated_annealing(coords, config)

    output_dir = Path(__file__).parent
    plot_tours(
        coords=coords,
        tour_snapshots=snapshots,
        distance_history=distance_history,
        config=config,
        output_path=output_dir / "tsp_tour_evolution.png",
    )
    export_summary(
        summary_path=output_dir / "tsp_summary.txt",
        best_tour=best_tour,
        best_distance=total_distance(coords, best_tour),
        config=config,
    )


if __name__ == "__main__":
    main()


