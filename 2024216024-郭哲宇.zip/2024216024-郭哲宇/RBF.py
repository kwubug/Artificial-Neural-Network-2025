import numpy as np
import matplotlib.pyplot as plt
from pylab import mpl
# 设置显示中文字体
mpl.rcParams["font.sans-serif"] = ["SimHei"]

class RBFNeuron:
    def __init__(self, center, width):
        self.center = center  # 中心
        self.width = width    # 宽度
    
    def activate(self, x):
        # 计算高斯激活函数
        return np.exp(-np.linalg.norm(x - self.center) ** 2 / (2 * self.width ** 2))

class RBFNetwork:
    def __init__(self, centers, width):
        self.centers = centers  # 中心点
        self.width = width      # 宽度
        self.neurons = [RBFNeuron(center, width) for center in centers]
        self.weights = np.random.rand(len(centers))  # 权重初始化

    def predict(self, x):
        # 前馈过程，计算输出
        rbf_outputs = np.array([neuron.activate(x) for neuron in self.neurons])
        return np.dot(rbf_outputs, self.weights)

    def train(self, X, T, learning_rate=0.01, epochs=100):
        for epoch in range(epochs):
            for x, t in zip(X, T):
                # 前馈
                rbf_outputs = np.array([neuron.activate(x) for neuron in self.neurons])
                prediction = np.dot(rbf_outputs, self.weights)
                
                # 计算误差
                error = t - prediction
                
                # 更新权重
                self.weights += learning_rate * error * rbf_outputs

# 定义输入和目标向量
p = np.arange(-1, 1.1, 0.1)
t = np.array([-0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600,
              0.4609, 0.1336, -0.2013, -0.4344, -0.5000, -0.3939,
              -0.1647, 0.0988, 0.3072, 0.3960, 0.3449, 0.1816,
              -0.0312, -0.2189, -0.3201])

# 设置 RBF 网络参数
centers = np.linspace(-1, 1, 10)  # 选择中心
width = 0.3                        # 设置宽度

# 创建并训练 RBF 网络
rbf_network = RBFNetwork(centers, width)
rbf_network.train(p, t, learning_rate=0.01, epochs=500)

# 进行预测
y_pred = np.array([rbf_network.predict(x) for x in p])

# 可视化结果
plt.figure(figsize=(10, 6))
plt.plot(p, t, 'ro', label='目标输出 (t)')
plt.plot(p, y_pred, 'b-', label='RBF 神经网络预测 (y)')
plt.title('RBF Neural Network Curve Fitting')
plt.xlabel('输入 (p)')
plt.ylabel('输出 (y)')
plt.legend()
plt.grid()
plt.show()
