import cv2
import torch
from ultralytics import YOLO
import numpy as np
import os


class FlameDetector:
    def __init__(self, model_path='yolov8n.pt'):
        """
        初始化火焰检测器
        :param model_path: 预训练模型路径，会自动下载如果不存在
        """
        # 检查CUDA是否可用
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"使用设备: {self.device}")

        # 加载模型
        self.model = YOLO(model_path).to(self.device)

        # 创建输出目录
        os.makedirs('output', exist_ok=True)

    def detect_flame(self, image_path, conf_threshold=0.5):

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图片文件不存在: {image_path}")

        # 执行检测
        results = self.model(image_path, conf=conf_threshold)

        # 获取带标注的图像
        annotated_img = results[0].plot()
        annotated_img = cv2.cvtColor(annotated_img, cv2.COLOR_BGR2RGB)

        # 检查是否检测到火焰
        has_flame = False
        detection_info = []

        for result in results:
            for box in result.boxes:
                cls = int(box.cls[0])
                if cls == 0:  # 假设类别0是火焰
                    has_flame = True
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    conf = float(box.conf[0])

                    detection_info.append({
                        'label': 'flame',
                        'confidence': conf,
                        'bbox': [x1, y1, x2, y2]
                    })

        # 保存结果
        output_path = os.path.join('output', os.path.basename(image_path))
        cv2.imwrite(output_path, cv2.cvtColor(annotated_img, cv2.COLOR_RGB2BGR))
        print(f"结果已保存到: {output_path}")

        return has_flame, annotated_img, detection_info


# 测试代码
if __name__ == "__main__":
    # 初始化检测器
    print("初始化火焰检测器...")
    detector = FlameDetector()

    # 测试图片检测
    print("\n测试图片检测...")
    try:

        img_path = "img_1.png"


        # 执行检测
        has_flame, result_img, detections = detector.detect_flame(img_path)

        # 打印检测结果
        print("\n检测结果:")
        if has_flame:
            print("检测到火焰!")
            for det in detections:
                print(f"火焰区域: 位置 {det['bbox']}, 置信度 {det['confidence']:.2f}")
        else:
            print("未检测到火焰")

        # 显示结果(需要GUI环境)
        if os.getenv('DISPLAY'):
            cv2.imshow("Detection Result", cv2.cvtColor(result_img, cv2.COLOR_RGB2BGR))
            cv2.waitKey(0)
            cv2.destroyAllWindows()
        else:
            print("检测完成! 结果已保存到output目录")

    except Exception as e:
        print(f"检测出错: {e}")
