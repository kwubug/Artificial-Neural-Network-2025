import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import Som2Algorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class Som2Bridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    # epoch is kept for UI compatibility but not the stopping condition now
    total_epoches = BridgeProperty(10)

    # assignment defaults
    total_steps = BridgeProperty(10000)
    snapshot_interval = BridgeProperty(200)
    initial_learning_rate = BridgeProperty(0.5)
    initial_standard_deviation = BridgeProperty(2.0)
    topology_shape = BridgeProperty([5, 5])

    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    current_standard_deviation = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_synaptic_weights = BridgeProperty([])
    snapshots = BridgeProperty([])        # saved every 200 steps
    final_mapping = BridgeProperty([])    # list of ((i, j), k)

    def __init__(self):
        super().__init__()
        self.som2_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_som2_algorithm(self):
        self.som2_algorithm = ObservableSom2Algorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,                     # kept but not used for stopping
            initial_learning_rate=self.initial_learning_rate,
            initial_standard_deviation=self.initial_standard_deviation,
            topology_shape=self.topology_shape,
            total_steps=self.total_steps,                         # <- new
            snapshot_interval=self.snapshot_interval              # <- new
        )
        self.som2_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_som2_algorithm(self):
        self.som2_algorithm.stop()


class ObservableSom2Algorithm(Observable, Som2Algorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        Som2Algorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            self.notify('current_synaptic_weights',
                        [[neuron.synaptic_weight.tolist()
                          for neuron in row] for row in self._neurons])

    def run(self):
        self.notify('has_finished', False)
        super().run()
        # send snapshots and mapping once finished
        self.notify('snapshots', [[[w.tolist() for w in row] for row in grid]
                                  for grid in self.snapshots])
        self.notify('final_mapping', self.final_mapping)
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # keep the GUI from blocking
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret

    @property
    def current_standard_deviation(self):
        ret = super().current_standard_deviation
        self.notify('current_standard_deviation', ret)
        return ret
