import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
import streamlit as st
import pandas as pd
import time

# ===== Streamlit setup =====
st.set_page_config(page_title="Backprop-like Weight Updates", layout="wide")
st.title("🧮 Simulated Optimization — Weight Update Visualization (3D)")

# ===== Sidebar controls =====
st.sidebar.header("⚙️ Parameters")

method = st.sidebar.selectbox(
    "Select Optimization Method",
    ["Steepest Descent", "Newton", "Conjugate Gradient"]
)

func_type = st.sidebar.selectbox(
    "Select Loss Function Type",
    ["Quadratic (Linear Regression MSE)", "Non-Quadratic (sin + quadratic)"]
)

lr = st.sidebar.slider("Learning rate (for Steepest Descent)", 0.001, 1.0, 0.05, 0.01)
steps = st.sidebar.slider("Max iterations", 5, 100, 20, 1)
speed = st.sidebar.slider("Animation speed (sec per step)", 0.05, 1.0, 0.2, 0.05)
azim = st.sidebar.slider("Camera azimuth (horizontal)", 0, 360, 60, 5)
elev = st.sidebar.slider("Camera elevation (vertical)", 0, 90, 30, 1)

'''
优化方法选择（梯度下降 / 牛顿 / 共轭梯度）
损失函数类型（线性二次或非线性）
学习率（梯度下降）
最大迭代次数
动画播放速度
3D 绘图视角（azimuth 水平角，elevation 垂直角）
'''


# ===== Simulated dataset =====
np.random.seed(0)
x_data = np.linspace(-2, 2, 20)
true_w1, true_w2 = 2.0, -1.0
y_data = true_w1 * x_data + true_w2 + np.random.normal(0, 0.3, size=x_data.shape)

# ===== Define loss function =====
def loss_quadratic(w):
    w1, w2 = w
    y_pred = w1 * x_data + w2
    return np.mean((y_pred - y_data)**2)

def grad_quadratic(w):
    w1, w2 = w
    y_pred = w1 * x_data + w2
    dL_dw1 = 2 * np.mean((y_pred - y_data) * x_data)
    dL_dw2 = 2 * np.mean(y_pred - y_data)
    return np.array([dL_dw1, dL_dw2])

def hess_quadratic(w):
    H11 = 2 * np.mean(x_data**2)
    H22 = 2
    H12 = H21 = 2 * np.mean(x_data)
    return np.array([[H11, H12], [H21, H22]])

# Non-quadratic loss: add sine term to make it non-convex / non-quadratic
def loss_nonquad(w):
    w1, w2 = w
    return (w1**2 + 2*w2**2 - w1*w2) + 0.5*np.sin(w1) + 0.3*np.cos(w2)

def grad_nonquad(w):
    w1, w2 = w
    dL_dw1 = (2*w1 - w2) + 0.5*np.cos(w1)
    dL_dw2 = (4*w2 - w1) - 0.3*np.sin(w2)
    return np.array([dL_dw1, dL_dw2])

def hess_nonquad(w):
    w1, w2 = w
    H11 = 2 - 0.5*np.sin(w1)
    H22 = 4 - 0.3*np.cos(w2)
    H12 = H21 = -1
    return np.array([[H11, H12], [H21, H22]])

# ===== Choose loss and gradients =====
if func_type == "Quadratic (Linear Regression MSE)":
    loss = loss_quadratic
    grad = grad_quadratic
    hess = hess_quadratic
else:
    loss = loss_nonquad
    grad = grad_nonquad
    hess = hess_nonquad

# ===== Optimization algorithms =====
def steepest_descent(w0, lr, steps, tol=1e-6):
    w = w0.copy()
    path = [w.copy()]
    prev_loss = loss(w)

    for _ in range(steps):
        w -= lr * grad(w)

        current_loss = loss(w)
        if abs(current_loss - prev_loss) < tol:  # 损失变化很小就提前停止
            break
        path.append(w.copy())
        prev_loss = current_loss

    return np.array(path)


def newton_method(w0, steps, damping=1.0, tol=1e-6):
    w = w0.copy()
    path = [w.copy()]
    prev_loss = loss(w)

    for _ in range(steps):
        H = hess(w) # 海森矩阵
        try:
            Hinv = np.linalg.inv(H)
        except np.linalg.LinAlgError:
            Hinv = np.linalg.pinv(H)
        w -= damping * (Hinv @ grad(w))

        current_loss = loss(w)
        if abs(current_loss - prev_loss) < tol:
            break
        path.append(w.copy())
        prev_loss = current_loss

    return np.array(path)


def conjugate_gradient(w0, steps, tol=1e-6):
    w = w0.copy()
    path = [w.copy()]

    g = grad(w)
    p = -g  # 初始方向为负梯度

    for _ in range(steps):
        # 1D line search (简单固定步长)
        alpha = 0.05  # 可以尝试动态调节
        w_new = w + alpha * p
        g_new = grad(w_new)

        # 更新beta (Fletcher-Reeves公式)
        beta = (g_new @ g_new) / max(g @ g, 1e-12)
        p = -g_new + beta * p

        # 更新 w
        w = w_new
        g = g_new
        path.append(w.copy())

        # 提前停止条件
        if np.linalg.norm(g) < tol:
            break

    return np.array(path)


# ===== Compute path =====
w_start = np.array([-1.5, 1.0])
if method == "Steepest Descent":
    path = steepest_descent(w_start, lr, steps)
elif method == "Newton":
    path = newton_method(w_start, steps)
else:
    path = conjugate_gradient(w_start, steps)

# ===== Generate mesh grid for loss surface =====
w1s = np.linspace(-3, 4, 200)
w2s = np.linspace(-3, 3, 200)
W1, W2 = np.meshgrid(w1s, w2s)
Z = np.vectorize(lambda w1, w2: loss(np.array([w1, w2])))(W1, W2)

# ===== Plot container =====
plot_placeholder = st.empty()

# ===== Animation =====
for i in range(len(path)):
    fig = plt.figure(figsize=(5.5, 4.5))
    ax = fig.add_subplot(111, projection="3d")

    # Loss surface
    ax.plot_surface(W1, W2, Z, cmap="plasma", alpha=0.85, linewidth=0, antialiased=True, shade=True)
    ax.contour(W1, W2, Z, zdir="z", offset=np.min(Z)-0.5, cmap="plasma", alpha=0.5)

    # Current trajectory
    z_vals = [loss(p) for p in path[:i+1]]
    ax.plot(path[:i+1, 0], path[:i+1, 1], z_vals, "r-o", linewidth=2, markersize=4, label=method)

    ax.set_xlabel("w₁")
    ax.set_ylabel("w₂")
    ax.set_zlabel("Loss")
    ax.set_title(f"{method} — Iteration {i}/{len(path)}", fontsize=11)
    ax.view_init(elev=elev, azim=azim)
    ax.legend(fontsize=8, loc="upper left")

    ax.set_facecolor("#f5f5f5")
    ax.set_zlim(np.min(Z)-0.5, np.max(Z)*1.05)

    plot_placeholder.pyplot(fig)
    plt.close(fig)
    time.sleep(speed)

st.success(f"✅ {method} finished after {len(path)-1} iterations.")

# ===== Final info =====
st.markdown("### 🧩 Final Weights")
st.write(f"Final w₁: {path[-1,0]:.4f}, w₂: {path[-1,1]:.4f}")
st.write(f"Final Loss: {loss(path[-1]):.6f}")

st.markdown("### 📜 Optimization Path")
st.dataframe(
    {"step": np.arange(len(path)),
     "w₁": path[:, 0],
     "w₂": path[:, 1],
     "Loss": [loss(p) for p in path]}
)


# ===== Plot Loss vs Iteration =====
st.markdown("### 📈 Loss over Iterations")
loss_values = [loss(p) for p in path]

fig_loss, ax_loss = plt.subplots(figsize=(6, 3.5))
ax_loss.plot(np.arange(len(path)), loss_values, 'b-o', linewidth=2, markersize=4)
ax_loss.set_xlabel("Iteration")
ax_loss.set_ylabel("Loss")
ax_loss.set_title("Loss vs Iteration")
ax_loss.grid(True)
st.pyplot(fig_loss)
plt.close(fig_loss)