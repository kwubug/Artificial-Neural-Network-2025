import numpy as np
import threading
import time


class OLSAlgorithm(threading.Thread):
    """
    普通最小二乘法（Ordinary Least Squares）算法
    用于线性回归：y = X * β + ε
    解析解：β = (X^T * X)^(-1) * X^T * y
    """
    
    def __init__(self, dataset, add_intercept=True):
        super().__init__()
        self.dataset = np.array(dataset)
        self.add_intercept = add_intercept
        self._should_stop = False
        
        # 分离特征和目标变量
        # 数据集格式: [[x1, y1], [x2, y2], ...] 或 [x1, x2, ..., xn, y]
        if len(self.dataset.shape) == 1:
            # 一维数组，可能是单个样本 [x1, x2, ..., y]
            # 转换为二维数组
            self.dataset = self.dataset.reshape(1, -1)
        
        # 确保是二维数组
        if len(self.dataset.shape) == 2:
            if self.dataset.shape[1] < 2:
                # 如果只有一列，无法进行回归
                raise ValueError("数据集至少需要两列（特征和目标变量）")
            
            # 多维数据: 最后一列是目标变量，前面的列是特征
            self.X = self.dataset[:, :-1]  # 所有特征列
            self.y = self.dataset[:, -1]   # 最后一列是目标变量
            
            # 如果只有一列特征，需要reshape为列向量
            if len(self.X.shape) == 1:
                self.X = self.X.reshape(-1, 1)
        else:
            raise ValueError(f"不支持的数据集形状: {self.dataset.shape}")
        
        # 添加截距项（常数项）
        if self.add_intercept:
            ones = np.ones((self.X.shape[0], 1))
            self.X = np.hstack([ones, self.X])
        
        # 回归结果
        self.coefficients = None  # β系数
        self.fitted_values = None  # 拟合值 ŷ
        self.residuals = None      # 残差
        self.r_squared = 0.0       # R²
        self.mse = 0.0             # 均方误差
        self.rmse = 0.0            # 均方根误差
        
        # 用于可视化的数据点
        self.data_points = []      # 原始数据点 [(x, y), ...]
        self.regression_line = []  # 回归线上的点 [(x, ŷ), ...]
        
    def run(self):
        """运行OLS算法"""
        try:
            print("OLS Algorithm started")
            
            # 计算回归系数
            self._calculate_coefficients()
            
            # 计算拟合值和残差
            self._calculate_fitted_values()
            
            # 计算统计指标
            self._calculate_statistics()
            
            # 生成可视化数据
            self._generate_visualization_data()
            
            print(f"OLS completed. R² = {self.r_squared:.4f}")
            
        except Exception as e:
            print(f"Error in OLS algorithm: {e}")
            import traceback
            traceback.print_exc()
    
    def _calculate_coefficients(self):
        """计算回归系数 β = (X^T * X)^(-1) * X^T * y"""
        try:
            # 计算 X^T * X
            XTX = np.dot(self.X.T, self.X)
            
            # 计算 (X^T * X)^(-1)
            try:
                XTX_inv = np.linalg.inv(XTX)
            except np.linalg.LinAlgError:
                # 如果矩阵不可逆，使用伪逆
                XTX_inv = np.linalg.pinv(XTX)
            
            # 计算 X^T * y
            XTy = np.dot(self.X.T, self.y)
            
            # 计算系数
            self.coefficients = np.dot(XTX_inv, XTy)
            
        except Exception as e:
            print(f"Error calculating coefficients: {e}")
            # 如果出错，使用零系数
            self.coefficients = np.zeros(self.X.shape[1])
    
    def _calculate_fitted_values(self):
        """计算拟合值 ŷ = X * β"""
        if self.coefficients is not None:
            self.fitted_values = np.dot(self.X, self.coefficients)
            self.residuals = self.y - self.fitted_values
        else:
            self.fitted_values = np.zeros_like(self.y)
            self.residuals = self.y
    
    def _calculate_statistics(self):
        """计算统计指标"""
        if self.y is None or len(self.y) == 0:
            return
        
        # 总平方和 (Total Sum of Squares)
        y_mean = np.mean(self.y)
        TSS = np.sum((self.y - y_mean) ** 2)
        
        # 残差平方和 (Residual Sum of Squares)
        if self.residuals is not None:
            RSS = np.sum(self.residuals ** 2)
        else:
            RSS = TSS
        
        # R² (决定系数)
        if TSS > 0:
            self.r_squared = 1 - (RSS / TSS)
        else:
            self.r_squared = 0.0
        
        # 均方误差 (Mean Squared Error)
        if len(self.residuals) > 0:
            self.mse = np.mean(self.residuals ** 2)
            self.rmse = np.sqrt(self.mse)
        else:
            self.mse = 0.0
            self.rmse = 0.0
    
    def _generate_visualization_data(self):
        """生成用于可视化的数据"""
        try:
            # 获取原始特征（不包含截距项）
            if self.add_intercept:
                # 如果添加了截距项，X的第一列是1，从第二列开始是特征
                if self.X.shape[1] > 1:
                    x_values = self.X[:, 1]  # 第一个特征
                else:
                    # 只有截距项，没有特征
                    x_values = np.arange(len(self.y))
            else:
                # 没有截距项，第一列就是特征
                if self.X.shape[1] > 0:
                    x_values = self.X[:, 0]  # 第一个特征
                else:
                    x_values = np.arange(len(self.y))
            
            # 生成数据点 [(x, y), ...]
            self.data_points = [[float(x), float(y)] for x, y in zip(x_values, self.y)]
            
            # 生成回归线上的点
            if len(x_values) > 0:
                x_min, x_max = float(np.min(x_values)), float(np.max(x_values))
                x_range = np.linspace(x_min, x_max, 100)
                
                if self.coefficients is not None:
                    if self.add_intercept and len(self.coefficients) >= 2:
                        # 有截距项和至少一个特征
                        intercept = float(self.coefficients[0])
                        slope = float(self.coefficients[1])
                        self.regression_line = [[float(x), float(intercept + slope * x)] for x in x_range]
                    elif not self.add_intercept and len(self.coefficients) >= 1:
                        # 没有截距项，只有斜率
                        slope = float(self.coefficients[0])
                        self.regression_line = [[float(x), float(slope * x)] for x in x_range]
                    elif self.add_intercept and len(self.coefficients) == 1:
                        # 只有截距项
                        intercept = float(self.coefficients[0])
                        self.regression_line = [[float(x), float(intercept)] for x in x_range]
                    else:
                        self.regression_line = []
                else:
                    self.regression_line = []
            else:
                self.data_points = []
                self.regression_line = []
        except Exception as e:
            print(f"Error generating visualization data: {e}")
            import traceback
            traceback.print_exc()
            self.data_points = []
            self.regression_line = []
    
    def predict(self, X_new):
        """使用训练好的模型进行预测"""
        if self.coefficients is None:
            return None
        
        X_new = np.array(X_new)
        if len(X_new.shape) == 1:
            X_new = X_new.reshape(1, -1)
        
        # 添加截距项
        if self.add_intercept:
            ones = np.ones((X_new.shape[0], 1))
            X_new = np.hstack([ones, X_new])
        
        return np.dot(X_new, self.coefficients)
    
    def stop(self):
        """停止算法"""
        self._should_stop = True
    
    def get_statistics(self):
        """返回统计信息"""
        coeffs_list = [float(c) for c in self.coefficients] if self.coefficients is not None else []
        
        return {
            'coefficients': coeffs_list,
            'intercept': float(self.coefficients[0]) if self.coefficients is not None and len(self.coefficients) > 0 else 0.0,
            'slope': float(self.coefficients[1]) if self.coefficients is not None and len(self.coefficients) > 1 else 0.0,
            'r_squared': float(self.r_squared),
            'mse': float(self.mse),
            'rmse': float(self.rmse),
            'data_points': self.data_points,
            'regression_line': self.regression_line,
            'fitted_values': [float(v) for v in self.fitted_values] if self.fitted_values is not None else [],
            'residuals': [float(r) for r in self.residuals] if self.residuals is not None else []
        }


class ObservableOLSAlgorithm(OLSAlgorithm):
    """Observable版本的OLS算法"""
    
    def __init__(self, observer, **kwargs):
        OLSAlgorithm.__init__(self, **kwargs)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            try:
                self._observer.update(name, value)
            except Exception as e:
                print(f"Error notifying {name}: {e}")
    
    def run(self):
        """重写run方法以添加通知"""
        OLSAlgorithm.run(self)
        
        # 通知结果
        stats = self.get_statistics()
        self.notify('coefficients', stats['coefficients'])
        self.notify('intercept', stats['intercept'])
        self.notify('slope', stats['slope'])
        self.notify('r_squared', stats['r_squared'])
        self.notify('mse', stats['mse'])
        self.notify('rmse', stats['rmse'])
        self.notify('data_points', stats['data_points'])
        self.notify('regression_line', stats['regression_line'])
        self.notify('fitted_values', stats['fitted_values'])
        self.notify('residuals', stats['residuals'])
        self.notify('statistics', stats)
        self.notify('is_running', False)

