import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Button, RadioButtons
import math
import warnings
import platform


warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib')


def setup_chinese_font():
    system = platform.system()
    try:
        if system == 'Windows':
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        elif system == 'Darwin':  # macOS
            plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'Heiti TC', 'PingFang SC']
        else:  # Linux
            plt.rcParams['font.sans-serif'] = ['WenQuanYi Zen Hei', 'DejaVu Sans', 'SimHei']
        plt.rcParams['axes.unicode_minus'] = False
    except:
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']


setup_chinese_font()




class TSPVisualizer:
    def __init__(self):
        self.fig, self.ax = plt.subplots(figsize=(10, 8))
        plt.subplots_adjust(left=0.1, bottom=0.2)

        self.cities = []
        self.path = []
        self.total_distance = 0


        self.city_scatter = None
        self.path_line = None
        self.distance_text = None

        self._create_buttons()
        self.fig.canvas.mpl_connect('button_press_event', self._on_click)

        self.ax.set_xlim(0, 10)
        self.ax.set_ylim(0, 10)
        self.ax.set_xlabel('X 坐标')
        self.ax.set_ylabel('Y 坐标')
        self.ax.set_title('TSP 问题可视化沙箱\n点击画布添加城市 | 选择算法后点击"求解TSP"')
        self.ax.grid(True, alpha=0.3)

        self.selected_algorithm = '贪心算法'

    def _create_buttons(self):
        """创建控制按钮"""

        ax_solve = plt.axes([0.1, 0.05, 0.2, 0.075])
        self.btn_solve = Button(ax_solve, '求解TSP', color='lightblue', hovercolor='skyblue')
        self.btn_solve.on_clicked(self._solve_tsp)


        ax_reset = plt.axes([0.4, 0.05, 0.2, 0.075])
        self.btn_reset = Button(ax_reset, '重置', color='lightcoral', hovercolor='coral')
        self.btn_reset.on_clicked(self._reset)


        ax_random = plt.axes([0.7, 0.05, 0.2, 0.075])
        self.btn_random = Button(ax_random, '随机生成10个城市', color='lightgreen', hovercolor='greenyellow')
        self.btn_random.on_clicked(self._generate_random_cities)


        ax_radio = plt.axes([0.02, 0.25, 0.08, 0.2])
        self.radio = RadioButtons(ax_radio, ['贪心算法', '最近邻算法'], active=0)
        self.radio.on_clicked(self._select_algorithm)

    def _on_click(self, event):
        """鼠标点击添加城市"""
        if event.inaxes == self.ax:
            self.cities.append((event.xdata, event.ydata))
            self._update_plot()

    def _generate_random_cities(self, event):
        """随机生成10个城市"""
        np.random.seed(42)
        self.cities = [(np.random.uniform(0.5, 9.5), np.random.uniform(0.5, 9.5)) for _ in range(10)]
        self.path = []
        self.total_distance = 0
        self._update_plot()

    def _select_algorithm(self, label):
        """选择求解算法"""
        self.selected_algorithm = label
        print(f'选择算法：{label}')

    def _calculate_distance(self, city1, city2):
        """计算两个城市之间的欧几里得距离"""
        return math.hypot(city1[0] - city2[0], city1[1] - city2[1])

    def _solve_greedy(self):
        """贪心算法求解TSP"""
        if len(self.cities) < 2:
            return []

        n = len(self.cities)
        visited = [False] * n
        path = [0]
        visited[0] = True

        for _ in range(n - 1):
            current = path[-1]
            min_dist = float('inf')
            next_city = -1

            for i in range(n):
                if not visited[i]:
                    dist = self._calculate_distance(self.cities[current], self.cities[i])
                    if dist < min_dist:
                        min_dist = dist
                        next_city = i

            path.append(next_city)
            visited[next_city] = True

        path.append(0)
        self.total_distance = sum(
            self._calculate_distance(self.cities[path[i]], self.cities[path[i + 1]])
            for i in range(n)
        )

        return path

    def _solve_nearest_neighbor(self):
        """最近邻算法求解TSP"""
        if len(self.cities) < 2:
            return []

        n = len(self.cities)
        visited = [False] * n
        start_idx = np.random.randint(0, n)
        path = [start_idx]
        visited[start_idx] = True

        for _ in range(n - 1):
            current = path[-1]
            min_dist = float('inf')
            next_city = -1

            for i in range(n):
                if not visited[i]:
                    dist = self._calculate_distance(self.cities[current], self.cities[i])
                    if dist < min_dist:
                        min_dist = dist
                        next_city = i

            path.append(next_city)
            visited[next_city] = True

        path.append(start_idx)
        self.total_distance = sum(
            self._calculate_distance(self.cities[path[i]], self.cities[path[i + 1]])
            for i in range(n)
        )

        return path

    def _solve_tsp(self, event):
        """求解TSP主函数"""
        if len(self.cities) < 2:
            print('至少需要2个城市才能求解TSP！')
            return

        if self.selected_algorithm == '贪心算法':
            self.path = self._solve_greedy()
        else:
            self.path = self._solve_nearest_neighbor()

        self._update_plot()
        print(f'求解完成！总距离：{self.total_distance:.2f}')

    def _update_plot(self):
        """更新绘图（核心修复处）"""

        if self.city_scatter is not None:
            self.city_scatter.remove()
        if self.path_line is not None:
            self.path_line.remove()
        if self.distance_text is not None:
            self.distance_text.remove()


        if self.cities:
            x, y = zip(*self.cities)
            self.city_scatter = self.ax.scatter(x, y, c='red', s=100, zorder=5)


            for i, (xi, yi) in enumerate(self.cities):
                self.ax.annotate(str(i), (xi, yi), xytext=(5, 5), textcoords='offset points', fontsize=12)


        if self.path:
            path_x = [self.cities[i][0] for i in self.path]
            path_y = [self.cities[i][1] for i in self.path]

            self.path_line = self.ax.plot(path_x, path_y, 'b-', linewidth=2, alpha=0.7, zorder=3)[0]


        text = f'总距离：{self.total_distance:.2f}' if self.total_distance > 0 else '未求解'
        self.distance_text = self.ax.text(0.02, 0.95, text, transform=self.ax.transAxes,
                                          fontsize=12, bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

        self.fig.canvas.draw()

    def _reset(self, event):
        """重置所有数据"""
        self.cities = []
        self.path = []
        self.total_distance = 0
        self._update_plot()
        print('已重置')

    def run(self):
        """运行可视化沙箱"""
        plt.show()


if __name__ == '__main__':
    tsp_visualizer = TSPVisualizer()
    tsp_visualizer.run()