import pandas as pd


def F(x: list):
    return x[0] ** 2 + x[0] * x[1] * x[1] ** 2


def g_F(x: list):
    return [2 * x[0] + x[1], 2 * x[1] + x[0]]


def lr1(x: list):
    g = g_F(x)
    A = [[2, 1], [1, 2]]
    n = g[0] ** 2 + g[1] ** 2

    s1 = [g[0] * A[0][0] + g[1] * A[1][0], g[0] * A[0][1] + g[1] * A[1][1]]
    m = s1[0] * g[0] + s1[1] * g[1]
    return n / m


def learn1(x: list):
    n = lr1(x)
    # print(n)
    g = g_F(x)
    # print(g)

    for i in range(2):
        x[i] = x[i] - n * g[i]
    print(f'初次学习_学习率为：{n}')
    print(f'初次学习_迭代结果：{x}')
    return g


def lr2(x: list, p: list):
    g = g_F(x)
    A = [[2, 1], [1, 2]]
    n = g[0] * p[0] + g[1] * p[1]

    s1 = [p[0] * A[0][0] + p[1] * A[1][0], p[0] * A[0][1] + p[1] * A[1][1]]
    m = s1[0] * g[0] + s1[1] * g[1]
    return n / m


def learn2(x: list, gflow):
    g = g_F(x)
    beta = (g[0] ** 2 + g[1] ** 2) / (gflow[0] ** 2 + gflow[1] ** 2)
    p = [-beta * gflow[0] - g[0], -beta * gflow[1] - g[1]]
    # print(p)

    n = lr2(x, p)
    for i in range(2):
        x[i] = x[i] + n * p[i]

    print(f'本次学习_学习率为：{n}')
    print(f'本次学习_迭代结果：{x}')
    return x


if __name__ == '__main__':
    data = []
    x = [0.8, -0.25]
    data.append({'x1': x[0], 'x2': x[1]})
    gflow = learn1(x)
    data.append({'x1': x[0], 'x2': x[1]})
    learn2(x, gflow)
    data.append({'x1': x[0], 'x2': x[1]})
    df = pd.DataFrame(data)
    df.to_excel('m3.xlsx', index=False)
