# nn_sandbox/bridges/HopfieldVisualizer.py
import numpy as np
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import random

class HopfieldVisualizer(QWidget):
    """
    离散Hopfield神经网络可视化组件
    - 异步更新
    - 吸引子显示
    - 能量曲线显示
    """

    def __init__(self, parent=None, n_neurons=16):
        super().__init__(parent)
        self.n = n_neurons  # 神经元数量
        self.fig, self.ax = plt.subplots(1, 2, figsize=(8, 4))  # 左: 网络状态，右: 能量
        self.canvas = FigureCanvas(self.fig)
        layout = QVBoxLayout(self)
        layout.addWidget(self.canvas)

    def generate_patterns(self, n_patterns=2, seed=None):
        """随机生成模式，每个元素 ±1"""
        if seed is not None:
            np.random.seed(seed)
        self.patterns = [np.random.choice([-1, 1], size=self.n) for _ in range(n_patterns)]
        return self.patterns

    def train_hebbian(self):
        """Hebbian训练权重矩阵"""
        self.W = np.zeros((self.n, self.n))
        for p in self.patterns:
            self.W += np.outer(p, p)
        np.fill_diagonal(self.W, 0)  # 无自连接
        return self.W

    def energy(self, state):
        """计算能量"""
        return -0.5 * state @ self.W @ state

    def async_update(self, state, n_steps=50):
        """异步更新网络"""
        state = state.copy()
        energy_list = [self.energy(state)]
        for _ in range(n_steps):
            i = random.randrange(self.n)
            state[i] = 1 if np.dot(self.W[i], state) >= 0 else -1
            energy_list.append(self.energy(state))
        self.state = state
        self.energy_list = energy_list
        return state, energy_list

    def visualize(self):
        if not hasattr(self, "state"):
            raise RuntimeError("请先调用 async_update 生成网络状态")
        self.ax[0].clear()
        self.ax[1].clear()

        # 左: 神经元状态 (矩阵或条形图)
        self.ax[0].bar(range(self.n), self.state, color='tab:blue')
        self.ax[0].set_ylim([-1.2, 1.2])
        self.ax[0].set_title("Hopfield Network State")

        # 右: 能量变化曲线
        self.ax[1].plot(self.energy_list, color='tab:red')
        self.ax[1].set_title("Network Energy")
        self.ax[1].set_xlabel("Update Step")
        self.ax[1].set_ylabel("Energy")

        self.canvas.draw()

    def refresh(self, n_patterns=2, n_steps=50):
        """随机生成模式，训练网络，异步更新并可视化"""
        self.generate_patterns(n_patterns)
        self.train_hebbian()
        # 随机初始状态
        init_state = np.random.choice([-1, 1], size=self.n)
        self.async_update(init_state, n_steps=n_steps)
        self.visualize()
