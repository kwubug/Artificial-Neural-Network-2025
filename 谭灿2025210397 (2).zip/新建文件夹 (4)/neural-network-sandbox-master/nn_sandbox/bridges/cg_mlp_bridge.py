import time
import numpy as np

import PyQt5.QtCore

from .bridge import Bridge, BridgeProperty
from .observer import Observable
from ..backend.algorithms.cg_mlp_algorithm import ConjugateGradientMlpAlgorithm


class ConjugateGradientMlpBridge(Bridge):
    """共轭梯度法MLP桥接器"""
    
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(1000)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.95)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    test_ratio = BridgeProperty(0.3)
    network_shape = BridgeProperty([5, 5])
    activation_function = BridgeProperty('sigmoid')
    cg_restart_frequency = BridgeProperty(10)
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_cg_mlp_algorithm(self):
        """启动共轭梯度法MLP算法 - Qt槽函数"""
        self._algorithm = ObservableConjugateGradientMlpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
            network_shape=self.network_shape,
            activation_function=self.activation_function,
            cg_restart_frequency=self.cg_restart_frequency
        )
        self._algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_cg_mlp_algorithm(self):
        """停止算法 - Qt槽函数"""
        if self._algorithm:
            self._algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableConjugateGradientMlpAlgorithm(Observable, ConjugateGradientMlpAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        ConjugateGradientMlpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # the following line keeps the GUI from blocking
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret

    def start_algorithm(self, dataset, total_epoches, most_correct_rate,
                        initial_learning_rate, search_iteration_constant,
                        test_ratio, network_shape, activation_function,
                        cg_restart_frequency):
        """启动共轭梯度法MLP算法"""
        self._algorithm = ConjugateGradientMlpAlgorithm(
            dataset=dataset,
            total_epoches=total_epoches,
            most_correct_rate=most_correct_rate,
            initial_learning_rate=initial_learning_rate,
            search_iteration_constant=search_iteration_constant,
            test_ratio=test_ratio,
            network_shape=network_shape,
            activation_function=activation_function,
            cg_restart_frequency=cg_restart_frequency
        )
        self._algorithm.start()

    def stop_algorithm(self):
        """停止算法"""
        if self._algorithm:
            self._algorithm.stop()



    def _get_additional_chart_data(self):
        """获取额外的图表数据"""
        return {}

    def _get_additional_info(self):
        """获取额外的算法信息"""
        if not self._algorithm:
            return {}
        
        return {
            'cg_restart_frequency': self._algorithm.cg_restart_frequency,
            'activation_function': self._algorithm.activation_function,
            'network_shape': list(self._algorithm.network_shape)
        }