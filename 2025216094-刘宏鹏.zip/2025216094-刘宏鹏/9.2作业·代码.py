import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider, CheckButtons, RadioButtons


class OptimizationVisualizer:
    def __init__(self):
        # 初始化图形界面
        self.fig, self.ax = plt.subplots(figsize=(10, 8))
        plt.subplots_adjust(left=0.1, right=0.7, bottom=0.3)

        # 初始化参数
        self.x1_init, self.x2_init = 0.0, 0.0
        self.max_steps = 100
        self.armijo_c = 0.5
        self.analytic_step = False
        self.function_type = "Quadratic"
        self.method = "Steepest Descent"

        # 创建控件
        self._create_controls()

        # 绘制初始图形
        self._plot_contour()
        plt.show()

    def _create_controls(self):
        # 函数选择单选按钮
        ax_func = plt.axes([0.75, 0.65, 0.2, 0.2])
        self.func_radio = RadioButtons(ax_func, ('Quadratic', 'Rosenbrock'))
        self.func_radio.on_clicked(self._update_function)

        # 方法选择单选按钮
        ax_method = plt.axes([0.75, 0.45, 0.2, 0.2])
        self.method_radio = RadioButtons(ax_method,
                                         ('Steepest Descent', 'Newton', 'Conjugate Gradient-FR'))
        self.method_radio.on_clicked(self._update_method)

        # 初始点滑块
        ax_x1 = plt.axes([0.1, 0.2, 0.5, 0.03])
        ax_x2 = plt.axes([0.1, 0.15, 0.5, 0.03])
        self.x1_slider = Slider(ax_x1, 'x1', -2.0, 2.0, valinit=self.x1_init)
        self.x2_slider = Slider(ax_x2, 'x2', -2.0, 2.0, valinit=self.x2_init)
        self.x1_slider.on_changed(self._update_sliders)
        self.x2_slider.on_changed(self._update_sliders)

        # 最大步数滑块
        ax_steps = plt.axes([0.1, 0.1, 0.5, 0.03])
        self.steps_slider = Slider(ax_steps, 'Max Steps', 10, 200, valinit=self.max_steps)
        self.steps_slider.on_changed(self._update_sliders)

        # Armijo参数滑块
        ax_armijo = plt.axes([0.1, 0.05, 0.5, 0.03])
        self.armijo_slider = Slider(ax_armijo, 'Armijo c', 0.01, 0.99, valinit=self.armijo_c)
        self.armijo_slider.on_changed(self._update_sliders)

        # 解析步长复选框
        ax_analytic = plt.axes([0.75, 0.25, 0.2, 0.1])
        self.analytic_check = CheckButtons(ax_analytic, ['Analytic Step'], [self.analytic_step])
        self.analytic_check.on_clicked(self._update_analytic)

        # 运行和清除按钮
        ax_run = plt.axes([0.75, 0.1, 0.1, 0.05])
        ax_clear = plt.axes([0.85, 0.1, 0.1, 0.05])
        self.run_button = Button(ax_run, 'Run')
        self.clear_button = Button(ax_clear, 'Clear')
        self.run_button.on_clicked(self._run_optimization)
        self.clear_button.on_clicked(self._clear_plot)

    def _update_function(self, label):
        self.function_type = label
        self._plot_contour()

    def _update_method(self, label):
        self.method = label
        self._plot_contour()

    def _update_sliders(self, val):
        self.x1_init = self.x1_slider.val
        self.x2_init = self.x2_slider.val
        self.max_steps = int(self.steps_slider.val)
        self.armijo_c = self.armijo_slider.val

    def _update_analytic(self, label):
        self.analytic_step = not self.analytic_step

    def _plot_contour(self):
        self.ax.clear()

        # 根据选择的函数生成网格和值
        x = np.linspace(-2, 2, 100)
        y = np.linspace(-2, 2, 100)
        X, Y = np.meshgrid(x, y)

        if self.function_type == "Quadratic":
            Z = self._quadratic_function(X, Y)
            levels = np.linspace(0, 10, 20)
        else:  # Rosenbrock
            Z = self._rosenbrock_function(X, Y)
            levels = np.linspace(0, 1000, 20)

        # 绘制等高线
        contour = self.ax.contour(X, Y, Z, levels=levels, cmap='viridis')
        self.ax.clabel(contour, inline=True, fontsize=8)
        self.ax.set_xlabel('x1')
        self.ax.set_ylabel('x2')
        self.ax.set_title(f'{self.function_type} Function - {self.method} Method')
        self.fig.canvas.draw_idle()

    def _quadratic_function(self, x1, x2):
        return x1 ** 2 + 2 * x2 ** 2

    def _rosenbrock_function(self, x1, x2):
        return (1 - x1) ** 2 + 100 * (x2 - x1 ** 2) ** 2

    def _run_optimization(self, event):
        x0 = np.array([self.x1_init, self.x2_init])

        if self.method == "Steepest Descent":
            path = self._steepest_descent(x0)
        elif self.method == "Newton":
            path = self._newton_method(x0)
        else:  # Conjugate Gradient-FR
            path = self._conjugate_gradient(x0)

        # 绘制优化路径
        path = np.array(path)
        self.ax.plot(path[:, 0], path[:, 1], 'r.-', linewidth=1, markersize=5)
        self.ax.plot(path[0, 0], path[0, 1], 'go', label='Start')
        self.ax.plot(path[-1, 0], path[-1, 1], 'bo', label='End')
        self.ax.legend()
        self.fig.canvas.draw_idle()

    def _steepest_descent(self, x0):
        x = x0.copy()
        path = [x.copy()]

        for _ in range(self.max_steps):
            if self.function_type == "Quadratic":
                grad = np.array([2 * x[0], 4 * x[1]])
            else:  # Rosenbrock
                grad = np.array([
                    -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
                    200 * (x[1] - x[0] ** 2)
                ])

            if self.analytic_step and self.function_type == "Quadratic":
                # 二次函数的解析步长
                alpha = (2 * x[0] ** 2 + 4 * x[1] ** 2) / (4 * x[0] ** 2 + 16 * x[1] ** 2)
            else:
                # Armijo线搜索
                alpha = self._armijo_line_search(x, -grad)

            x = x - alpha * grad
            path.append(x.copy())

            if np.linalg.norm(grad) < 1e-6:
                break

        return path

    def _newton_method(self, x0):
        x = x0.copy()
        path = [x.copy()]

        for _ in range(self.max_steps):
            if self.function_type == "Quadratic":
                grad = np.array([2 * x[0], 4 * x[1]])
                hess = np.array([[2, 0], [0, 4]])
            else:  # Rosenbrock
                grad = np.array([
                    -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
                    200 * (x[1] - x[0] ** 2)
                ])
                hess = np.array([
                    [2 + 400 * (3 * x[0] ** 2 - x[1]), -400 * x[0]],
                    [-400 * x[0], 200]
                ])

            try:
                d = -np.linalg.solve(hess, grad)
            except np.linalg.LinAlgError:
                d = -grad

            alpha = self._armijo_line_search(x, d)
            x = x + alpha * d
            path.append(x.copy())

            if np.linalg.norm(grad) < 1e-6:
                break

        return path

    def _conjugate_gradient(self, x0):
        x = x0.copy()
        path = [x.copy()]

        if self.function_type == "Quadratic":
            A = np.array([[2, 0], [0, 4]])
            b = np.zeros(2)
        else:
            # 对于非二次函数，使用FR共轭梯度法
            return self._fr_conjugate_gradient(x0)

        grad = A @ x - b
        d = -grad

        for _ in range(self.max_steps):
            if self.analytic_step:
                alpha = -grad.T @ d / (d.T @ A @ d)
            else:
                alpha = self._armijo_line_search(x, d)

            x = x + alpha * d
            path.append(x.copy())

            grad_new = A @ x - b
            beta = (grad_new.T @ grad_new) / (grad.T @ grad)
            d = -grad_new + beta * d
            grad = grad_new.copy()

            if np.linalg.norm(grad) < 1e-6:
                break

        return path

    def _fr_conjugate_gradient(self, x0):
        x = x0.copy()
        path = [x.copy()]

        if self.function_type == "Quadratic":
            grad = np.array([2 * x[0], 4 * x[1]])
        else:  # Rosenbrock
            grad = np.array([
                -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
                200 * (x[1] - x[0] ** 2)
            ])

        d = -grad

        for _ in range(self.max_steps):
            alpha = self._armijo_line_search(x, d)
            x = x + alpha * d
            path.append(x.copy())

            if self.function_type == "Quadratic":
                grad_new = np.array([2 * x[0], 4 * x[1]])
            else:  # Rosenbrock
                grad_new = np.array([
                    -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
                    200 * (x[1] - x[0] ** 2)
                ])

            beta = (grad_new.T @ grad_new) / (grad.T @ grad)
            d = -grad_new + beta * d
            grad = grad_new.copy()

            if np.linalg.norm(grad) < 1e-6:
                break

        return path

    def _armijo_line_search(self, x, d):
        alpha = 1.0
        rho = 0.5
        c = self.armijo_c

        if self.function_type == "Quadratic":
            f = lambda x: x[0] ** 2 + 2 * x[1] ** 2
            grad_f = lambda x: np.array([2 * x[0], 4 * x[1]])
        else:  # Rosenbrock
            f = lambda x: (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2
            grad_f = lambda x: np.array([
                -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
                200 * (x[1] - x[0] ** 2)
            ])

        # 添加最大迭代次数限制以避免无限循环
        max_iterations = 50
        iterations = 0
        
        while True:
            x_new = x + alpha * d
            if f(x_new) <= f(x) + c * alpha * grad_f(x).T @ d:
                break
            alpha *= rho
            if alpha < 1e-10 or iterations > max_iterations:
                break
            iterations += 1

        return alpha

    def _clear_plot(self, event):
        self._plot_contour()


# 运行可视化工具
if __name__ == "__main__":
    visualizer = OptimizationVisualizer()