import sys
import numpy as np
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QProgressBar,
                             QSpinBox, QCheckBox, QComboBox, QGridLayout)
from PyQt5.QtCore import QTimer, Qt, pyqtSignal
from PyQt5.QtGui import QFont, QPalette, QColor, QPixmap, QPainter
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

class HopfieldNetwork:
    """Discrete Hopfield Neural Network"""
    
    def __init__(self, size):
        self.size = size
        self.weights = np.zeros((size, size))
        self.neurons = np.random.choice([-1, 1], size=size)
        self.energy_history = []
        self.patterns = []
        self.attractors = []
        
    def train_pattern(self, pattern):
        """Train the network with a pattern"""
        pattern = np.array(pattern).flatten()
        pattern[pattern == 0] = -1  # Convert 0 to -1 for Hopfield network
        self.patterns.append(pattern.copy())
        
        # Hebbian learning rule
        outer_product = np.outer(pattern, pattern)
        np.fill_diagonal(outer_product, 0)  # No self-connections
        self.weights += outer_product
        
    def calculate_energy(self, state=None):
        """Calculate the energy of the current state"""
        if state is None:
            state = self.neurons
        energy = -0.5 * np.dot(state, np.dot(self.weights, state))
        return energy
    
    def asynchronous_update(self, neuron_index=None):
        """Asynchronous update of neurons"""
        if neuron_index is None:
            neuron_index = random.randint(0, self.size - 1)
        
        # Calculate the input to the neuron
        input_sum = np.dot(self.weights[neuron_index], self.neurons)
        
        # Update the neuron state
        if input_sum >= 0:
            self.neurons[neuron_index] = 1
        else:
            self.neurons[neuron_index] = -1
            
        return neuron_index
    
    def find_attractors(self, max_iterations=100):
        """Find attractors in the network"""
        self.attractors = []
        visited_states = set()
        
        # Test with random initial states
        for _ in range(min(50, 2**min(8, self.size))):  # Limit for large networks
            # Create random initial state
            initial_state = np.random.choice([-1, 1], size=self.size)
            current_state = initial_state.copy()
            visited_states_in_run = []
            
            # Evolve the state
            for iteration in range(max_iterations):
                # Convert state to tuple for hashing
                state_tuple = tuple(current_state)
                visited_states_in_run.append(state_tuple)
                
                # Check if we've reached an attractor
                if state_tuple in visited_states:
                    break
                    
                # Update one random neuron
                neuron_idx = random.randint(0, self.size - 1)
                input_sum = np.dot(self.weights[neuron_idx], current_state)
                if input_sum >= 0:
                    new_value = 1
                else:
                    new_value = -1
                    
                if new_value != current_state[neuron_idx]:
                    current_state[neuron_idx] = new_value
                else:
                    # Stable state found (attractor)
                    if state_tuple not in self.attractors:
                        self.attractors.append(state_tuple)
                    visited_states.add(state_tuple)
                    break
                    
                # Check for cycle (limit cycle attractor)
                if len(visited_states_in_run) > 10:
                    # Check if we're in a cycle of length 2-10
                    for cycle_len in range(2, min(11, len(visited_states_in_run))):
                        if (visited_states_in_run[-1] == 
                            visited_states_in_run[-1 - cycle_len]):
                            cycle_states = visited_states_in_run[-cycle_len:]
                            if cycle_states not in self.attractors:
                                self.attractors.append(cycle_states)
                            break
        
        return self.attractors
    
    def reset_neurons(self):
        """Reset neurons to random state"""
        self.neurons = np.random.choice([-1, 1], size=self.size)
        self.energy_history = []

class PatternVisualizer:
    """Pattern visualization helper"""
    
    @staticmethod
    def pattern_to_image(pattern, width, height):
        """Convert pattern to image array"""
        pattern = pattern.reshape(height, width)
        pattern[pattern == -1] = 0  # Convert -1 to 0 for display
        return pattern
    
    @staticmethod
    def create_sample_patterns():
        """Create sample patterns for demonstration"""
        patterns = []
        
        # Letter patterns (5x5)
        # Pattern A
        pattern_a = np.array([
            [0, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 1],
            [1, 0, 0, 0, 1],
            [1, 0, 0, 0, 1]
        ])
        
        # Pattern B
        pattern_b = np.array([
            [1, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 1, 1, 1, 0]
        ])
        
        # Pattern C
        pattern_c = np.array([
            [0, 1, 1, 1, 0],
            [1, 0, 0, 0, 1],
            [1, 0, 0, 0, 0],
            [1, 0, 0, 0, 1],
            [0, 1, 1, 1, 0]
        ])
        
        patterns.extend([pattern_a, pattern_b, pattern_c])
        return patterns

class MplCanvas(FigureCanvas):
    """Matplotlib canvas wrapper"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class HopfieldVisualizer(QMainWindow):
    """Hopfield Network PyQt Visualizer"""
    
    update_signal = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.network = None
        self.network_size = 25  # 5x5 grid
        self.grid_width = 5
        self.grid_height = 5
        self.is_running = False
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_step)
        self.update_signal.connect(self.update_display)
        
        self.init_ui()
        self.initialize_network()
        
    def init_ui(self):
        """Initialize user interface"""
        self.setWindowTitle("Discrete Hopfield Neural Network Visualizer")
        self.setGeometry(100, 100, 1600, 900)
        
        # Set dark theme
        self.set_dark_theme()
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QHBoxLayout(central_widget)
        
        # Left control panel
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # Right visualization area
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 2)
        
    def set_dark_theme(self):
        """Set dark theme for the application"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """Create control panel"""
        control_group = QGroupBox("Control Panel")
        control_layout = QVBoxLayout(control_group)
        
        # Title
        title_label = QLabel("Hopfield Network Console")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # Network parameters
        params_group = QGroupBox("Network Parameters")
        params_layout = QGridLayout(params_group)
        
        params_layout.addWidget(QLabel("Network Size:"), 0, 0)
        self.size_combo = QComboBox()
        self.size_combo.addItems(["4x4 (16)", "5x5 (25)", "6x6 (36)", "8x8 (64)"])
        self.size_combo.setCurrentIndex(1)
        self.size_combo.currentTextChanged.connect(self.change_network_size)
        params_layout.addWidget(self.size_combo, 0, 1)
        
        params_layout.addWidget(QLabel("Update Speed (ms):"), 1, 0)
        self.speed_spin = QSpinBox()
        self.speed_spin.setRange(10, 1000)
        self.speed_spin.setValue(100)
        self.speed_spin.valueChanged.connect(self.change_update_speed)
        params_layout.addWidget(self.speed_spin, 1, 1)
        
        params_layout.addWidget(QLabel("Max Iterations:"), 2, 0)
        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(10, 1000)
        self.iter_spin.setValue(100)
        params_layout.addWidget(self.iter_spin, 2, 1)
        
        control_layout.addWidget(params_group)
        
        # Pattern management
        pattern_group = QGroupBox("Pattern Management")
        pattern_layout = QVBoxLayout(pattern_group)
        
        self.pattern_list = QTextEdit()
        self.pattern_list.setMaximumHeight(100)
        self.pattern_list.setReadOnly(True)
        pattern_layout.addWidget(self.pattern_list)
        
        pattern_buttons_layout = QHBoxLayout()
        self.add_pattern_btn = QPushButton("Add Sample Patterns")
        self.add_pattern_btn.clicked.connect(self.add_sample_patterns)
        pattern_buttons_layout.addWidget(self.add_pattern_btn)
        
        self.clear_patterns_btn = QPushButton("Clear Patterns")
        self.clear_patterns_btn.clicked.connect(self.clear_patterns)
        pattern_buttons_layout.addWidget(self.clear_patterns_btn)
        
        pattern_layout.addLayout(pattern_buttons_layout)
        control_layout.addWidget(pattern_group)
        
        # Training control
        train_group = QGroupBox("Training Control")
        train_layout = QVBoxLayout(train_group)
        
        train_buttons_layout = QHBoxLayout()
        self.train_btn = QPushButton("Train Network")
        self.train_btn.clicked.connect(self.train_network)
        train_buttons_layout.addWidget(self.train_btn)
        
        self.find_attractors_btn = QPushButton("Find Attractors")
        self.find_attractors_btn.clicked.connect(self.find_attractors)
        train_buttons_layout.addWidget(self.find_attractors_btn)
        
        train_layout.addLayout(train_buttons_layout)
        control_layout.addWidget(train_group)
        
        # Simulation control
        sim_group = QGroupBox("Simulation Control")
        sim_layout = QVBoxLayout(sim_group)
        
        sim_buttons_layout = QHBoxLayout()
        self.start_btn = QPushButton("Start Simulation")
        self.start_btn.clicked.connect(self.start_simulation)
        sim_buttons_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop Simulation")
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.stop_btn.setEnabled(False)
        sim_buttons_layout.addWidget(self.stop_btn)
        
        self.step_btn = QPushButton("Single Step")
        self.step_btn.clicked.connect(self.single_step)
        sim_buttons_layout.addWidget(self.step_btn)
        
        sim_layout.addLayout(sim_buttons_layout)
        
        reset_layout = QHBoxLayout()
        self.reset_btn = QPushButton("Reset Network")
        self.reset_btn.clicked.connect(self.reset_network)
        reset_layout.addWidget(self.reset_btn)
        
        self.random_btn = QPushButton("Random State")
        self.random_btn.clicked.connect(self.random_state)
        reset_layout.addWidget(self.random_btn)
        
        sim_layout.addLayout(reset_layout)
        control_layout.addWidget(sim_group)
        
        # Progress and info
        info_group = QGroupBox("Network Information")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        self.progress_bar = QProgressBar()
        info_layout.addWidget(self.progress_bar)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
        
    def create_visualization_area(self):
        """Create visualization area"""
        visualization_widget = QTabWidget()
        
        # Current state tab
        state_tab = QWidget()
        state_layout = QVBoxLayout(state_tab)
        self.state_canvas = MplCanvas(self, width=6, height=6)
        state_layout.addWidget(self.state_canvas)
        visualization_widget.addTab(state_tab, "Current State")
        
        # Energy landscape tab
        energy_tab = QWidget()
        energy_layout = QVBoxLayout(energy_tab)
        self.energy_canvas = MplCanvas(self, width=8, height=4)
        energy_layout.addWidget(self.energy_canvas)
        visualization_widget.addTab(energy_tab, "Energy Landscape")
        
        # Attractors tab
        attractors_tab = QWidget()
        attractors_layout = QVBoxLayout(attractors_tab)
        self.attractors_canvas = MplCanvas(self, width=8, height=6)
        attractors_layout.addWidget(self.attractors_canvas)
        visualization_widget.addTab(attractors_tab, "Attractors")
        
        # Training patterns tab
        patterns_tab = QWidget()
        patterns_layout = QVBoxLayout(patterns_tab)
        self.patterns_canvas = MplCanvas(self, width=8, height=6)
        patterns_layout.addWidget(self.patterns_canvas)
        visualization_widget.addTab(patterns_tab, "Training Patterns")
        
        return visualization_widget
        
    def initialize_network(self):
        """Initialize the Hopfield network"""
        self.change_network_size()
        
    def change_network_size(self):
        """Change network size based on selection"""
        size_text = self.size_combo.currentText()
        if "4x4" in size_text:
            self.grid_width, self.grid_height = 4, 4
        elif "5x5" in size_text:
            self.grid_width, self.grid_height = 5, 5
        elif "6x6" in size_text:
            self.grid_width, self.grid_height = 6, 6
        elif "8x8" in size_text:
            self.grid_width, self.grid_height = 8, 8
            
        self.network_size = self.grid_width * self.grid_height
        self.network = HopfieldNetwork(self.network_size)
        self.update_display()
        self.info_text.append(f"Network initialized with size {self.grid_width}x{self.grid_height}")
        
    def change_update_speed(self):
        """Change update speed"""
        self.update_timer.setInterval(self.speed_spin.value())
        
    def add_sample_patterns(self):
        """Add sample patterns to the network"""
        sample_patterns = PatternVisualizer.create_sample_patterns()
        for pattern in sample_patterns:
            if pattern.size == self.network_size:
                self.network.train_pattern(pattern)
                
        self.info_text.append(f"Added {len(sample_patterns)} sample patterns")
        self.update_display()
        
    def clear_patterns(self):
        """Clear all patterns"""
        self.network.patterns = []
        self.network.weights = np.zeros((self.network_size, self.network_size))
        self.info_text.append("All patterns cleared")
        self.update_display()
        
    def train_network(self):
        """Train the network with current patterns"""
        if not self.network.patterns:
            self.info_text.append("No patterns to train with!")
            return
            
        self.info_text.append("Network training completed")
        self.update_display()
        
    def find_attractors(self):
        """Find attractors in the network"""
        self.info_text.append("Searching for attractors...")
        attractors = self.network.find_attractors(self.iter_spin.value())
        self.info_text.append(f"Found {len(attractors)} attractor(s)")
        self.update_display()
        
    def start_simulation(self):
        """Start the simulation"""
        self.is_running = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.update_timer.start(self.speed_spin.value())
        self.info_text.append("Simulation started")
        
    def stop_simulation(self):
        """Stop the simulation"""
        self.is_running = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.update_timer.stop()
        self.info_text.append("Simulation stopped")
        
    def single_step(self):
        """Perform a single update step"""
        self.update_step()
        
    def reset_network(self):
        """Reset the network"""
        self.network.reset_neurons()
        self.info_text.append("Network reset")
        self.update_display()
        
    def random_state(self):
        """Set random state"""
        self.network.neurons = np.random.choice([-1, 1], size=self.network_size)
        self.info_text.append("Random state set")
        self.update_display()
        
    def update_step(self):
        """Perform one update step"""
        if self.is_running:
            # Asynchronous update
            updated_neuron = self.network.asynchronous_update()
            
            # Calculate energy
            energy = self.network.calculate_energy()
            self.network.energy_history.append(energy)
            
            # Update display
            self.update_signal.emit()
            
    def update_display(self):
        """Update all displays"""
        self.plot_current_state()
        self.plot_energy_landscape()
        self.plot_attractors()
        self.plot_training_patterns()
        self.update_network_info()
        
    def plot_current_state(self):
        """Plot current network state"""
        self.state_canvas.fig.clear()
        ax = self.state_canvas.fig.add_subplot(111)
        
        # Reshape to grid
        state_grid = self.network.neurons.reshape(self.grid_height, self.grid_width)
        state_grid[state_grid == -1] = 0  # Convert -1 to 0 for display
        
        # Create custom colormap (black and white)
        cmap = ListedColormap(['black', 'white'])
        
        ax.imshow(state_grid, cmap=cmap, interpolation='nearest')
        ax.set_title('Current Network State', color='white', fontsize=12)
        ax.set_xticks([])
        ax.set_yticks([])
        
        # Add grid lines
        for i in range(self.grid_height + 1):
            ax.axhline(i - 0.5, color='gray', linewidth=0.5)
        for i in range(self.grid_width + 1):
            ax.axvline(i - 0.5, color='gray', linewidth=0.5)
            
        ax.set_facecolor('#2b2b2b')
        self.state_canvas.fig.patch.set_facecolor('#2b2b2b')
        self.state_canvas.draw()
        
    def plot_energy_landscape(self):
        """Plot energy landscape"""
        self.energy_canvas.fig.clear()
        ax = self.energy_canvas.fig.add_subplot(111)
        
        if self.network.energy_history:
            ax.plot(range(len(self.network.energy_history)), 
                   self.network.energy_history, 'b-', linewidth=2)
            ax.set_title('Energy Landscape', color='white', fontsize=12)
            ax.set_xlabel('Update Steps', color='white')
            ax.set_ylabel('Energy', color='white')
            ax.grid(True, alpha=0.3)
            
        ax.set_facecolor('#2b2b2b')
        self.energy_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        self.energy_canvas.draw()
        
    def plot_attractors(self):
        """Plot found attractors"""
        self.attractors_canvas.fig.clear()
        
        if not self.network.attractors:
            ax = self.attractors_canvas.fig.add_subplot(111)
            ax.text(0.5, 0.5, 'No attractors found\nClick "Find Attractors" to search', 
                   ha='center', va='center', transform=ax.transAxes, color='white')
            ax.set_facecolor('#2b2b2b')
            self.attractors_canvas.fig.patch.set_facecolor('#2b2b2b')
        else:
            n_attractors = len(self.network.attractors)
            cols = min(3, n_attractors)
            rows = (n_attractors + cols - 1) // cols
            
            for i, attractor in enumerate(self.network.attractors):
                ax = self.attractors_canvas.fig.add_subplot(rows, cols, i + 1)
                
                if isinstance(attractor[0], tuple):  # Fixed point attractor
                    state = np.array(attractor[0])
                    state_grid = state.reshape(self.grid_height, self.grid_width)
                    state_grid[state_grid == -1] = 0
                    ax.imshow(state_grid, cmap='binary', interpolation='nearest')
                    ax.set_title(f'Attractor {i+1} (Fixed)', color='white', fontsize=10)
                else:  # Limit cycle attractor
                    # Show first state of cycle
                    state = np.array(attractor[0])
                    state_grid = state.reshape(self.grid_height, self.grid_width)
                    state_grid[state_grid == -1] = 0
                    ax.imshow(state_grid, cmap='binary', interpolation='nearest')
                    ax.set_title(f'Attractor {i+1} (Cycle)', color='white', fontsize=10)
                
                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_facecolor('#2b2b2b')
                
            self.attractors_canvas.fig.patch.set_facecolor('#2b2b2b')
            
        self.attractors_canvas.draw()
        
    def plot_training_patterns(self):
        """Plot training patterns"""
        self.patterns_canvas.fig.clear()
        
        if not self.network.patterns:
            ax = self.patterns_canvas.fig.add_subplot(111)
            ax.text(0.5, 0.5, 'No training patterns\nAdd sample patterns or create custom ones', 
                   ha='center', va='center', transform=ax.transAxes, color='white')
            ax.set_facecolor('#2b2b2b')
        else:
            n_patterns = len(self.network.patterns)
            cols = min(3, n_patterns)
            rows = (n_patterns + cols - 1) // cols
            
            for i, pattern in enumerate(self.network.patterns):
                ax = self.patterns_canvas.fig.add_subplot(rows, cols, i + 1)
                pattern_grid = pattern.reshape(self.grid_height, self.grid_width)
                pattern_grid[pattern_grid == -1] = 0
                ax.imshow(pattern_grid, cmap='binary', interpolation='nearest')
                ax.set_title(f'Pattern {i+1}', color='white', fontsize=10)
                ax.set_xticks([])
                ax.set_yticks([])
                ax.set_facecolor('#2b2b2b')
                
            self.patterns_canvas.fig.patch.set_facecolor('#2b2b2b')
            
        self.patterns_canvas.draw()
        
    def update_network_info(self):
        """Update network information display"""
        info = f"Network Size: {self.grid_width}x{self.grid_height} ({self.network_size} neurons)\n"
        info += f"Trained Patterns: {len(self.network.patterns)}\n"
        info += f"Found Attractors: {len(self.network.attractors)}\n"
        
        if self.network.energy_history:
            current_energy = self.network.energy_history[-1]
            info += f"Current Energy: {current_energy:.2f}\n"
            
        info += f"Simulation Running: {self.is_running}"
        
        self.info_text.clear()
        self.info_text.append(info)

def main():
    """Main function"""
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = HopfieldVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()