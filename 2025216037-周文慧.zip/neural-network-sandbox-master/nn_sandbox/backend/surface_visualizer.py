import numpy as np
import matplotlib
matplotlib.use('Agg')  # 无GUI后端
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import io
import base64


class SurfaceVisualizer:
    """生成3D曲面图像"""
    
    # 函数信息配置
    FUNCTION_CONFIG = {
        0: {  # Rosenbrock
            'name': 'Rosenbrock',
            'range': (-2, 2),
            'optimum': (1, 1, 0),
            'func': lambda x, y: (1 - x)**2 + 100 * (y - x**2)**2
        },
        1: {  # Himmelblau
            'name': 'Himmelblau',
            'range': (-5, 5),
            'optimum': (3, 2, 0),
            'func': lambda x, y: (x**2 + y - 11)**2 + (x + y**2 - 7)**2
        },
        2: {  # Rastrigin
            'name': 'Rastrigin',
            'range': (-5.12, 5.12),
            'optimum': (0, 0, 0),
            'func': lambda x, y: 20 + (x**2 - 10*np.cos(2*np.pi*x)) + (y**2 - 10*np.cos(2*np.pi*y))
        },
        3: {  # Ackley
            'name': 'Ackley',
            'range': (-5, 5),
            'optimum': (0, 0, 0),
            'func': lambda x, y: -20*np.exp(-0.2*np.sqrt(0.5*(x**2+y**2))) - np.exp(0.5*(np.cos(2*np.pi*x)+np.cos(2*np.pi*y))) + np.e + 20
        },
        4: {  # Beale
            'name': 'Beale',
            'range': (-4.5, 4.5),
            'optimum': (3, 0.5, 0),
            'func': lambda x, y: (1.5 - x + x*y)**2 + (2.25 - x + x*y**2)**2 + (2.625 - x + x*y**3)**2
        },
        5: {  # Sphere
            'name': 'Sphere',
            'range': (-5, 5),
            'optimum': (0, 0, 0),
            'func': lambda x, y: x**2 + y**2
        }
    }
    
    def __init__(self, width=800, height=600):
        self.width = width
        self.height = height
        self.fig = None
        self.ax = None
        
    def generate_surface(self, function_index=0, path_points=None):
        """生成指定函数的3D曲面图
        
        Args:
            function_index: 函数索引 (0-5)
            path_points: 优化路径点列表 [(x1,y1), (x2,y2), ...]
        """
        config = self.FUNCTION_CONFIG.get(function_index, self.FUNCTION_CONFIG[0])
        
        # 创建网格
        x_range = config['range']
        x = np.linspace(x_range[0], x_range[1], 100)
        y = np.linspace(x_range[0], x_range[1], 100)
        X, Y = np.meshgrid(x, y)
        
        # 计算函数值
        Z = config['func'](X, Y)
        
        # 创建3D图
        self.fig = plt.figure(figsize=(self.width/100, self.height/100), dpi=100)
        self.ax = self.fig.add_subplot(111, projection='3d')
        
        # 绘制曲面
        surf = self.ax.plot_surface(X, Y, Z, cmap=cm.coolwarm, 
                                     alpha=0.7, antialiased=True,
                                     linewidth=0, edgecolor='none')
        
        # 添加路径
        if path_points and len(path_points) > 0:
            path_x = [p[0] for p in path_points]
            path_y = [p[1] for p in path_points]
            path_z = [config['func'](x, y) for x, y in path_points]
            
            self.ax.plot(path_x, path_y, path_z, 'r-', linewidth=3, label='Path', zorder=5)
            
            # 起点
            self.ax.scatter([path_x[0]], [path_y[0]], [path_z[0]], 
                           c='green', s=150, marker='o', label='Start',
                           edgecolors='black', linewidths=2, zorder=6)
            
            # 当前点
            if len(path_points) > 1:
                self.ax.scatter([path_x[-1]], [path_y[-1]], [path_z[-1]], 
                               c='blue', s=150, marker='o', label='Current',
                               edgecolors='black', linewidths=2, zorder=6)
        
        # 标记最优点
        opt = config['optimum']
        self.ax.scatter([opt[0]], [opt[1]], [opt[2]], 
                       c='gold', s=200, marker='*', 
                       edgecolors='black', linewidths=2, 
                       label=f'Optimum ({opt[0]},{opt[1]})',
                       zorder=6)
        
        # 设置标签和标题
        self.ax.set_xlabel('X', fontsize=11, labelpad=8)
        self.ax.set_ylabel('Y', fontsize=11, labelpad=8)
        self.ax.set_zlabel('f(x,y)', fontsize=11, labelpad=8)
        self.ax.set_title(f'{config["name"]} Function Optimization', 
                         fontsize=13, fontweight='bold', pad=15)
        
        # 设置视角
        self.ax.view_init(elev=25, azim=45)
        
        # 添加图例
        self.ax.legend(loc='upper left', fontsize=9, framealpha=0.9)
        
        # 添加颜色条
        cbar = self.fig.colorbar(surf, shrink=0.5, aspect=5, pad=0.1)
        cbar.set_label('Function Value', rotation=270, labelpad=15)
        
        plt.tight_layout()
        
        return self.to_base64()
    
    def generate_rosenbrock_surface(self, path_points=None):
        """保持向后兼容的Rosenbrock函数生成方法"""
        return self.generate_surface(0, path_points)
    
    def to_base64(self):
        """将图像转换为base64编码"""
        buf = io.BytesIO()
        self.fig.savefig(buf, format='png', dpi=100, bbox_inches='tight')
        buf.seek(0)
        img_base64 = base64.b64encode(buf.read()).decode('utf-8')
        plt.close(self.fig)
        return img_base64