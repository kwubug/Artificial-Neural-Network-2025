import numpy as np

# --------------------------------------------
# 离散型 Hopfield 网络 (DHNN) 图7-3 仿真（修改权值矩阵）
# --------------------------------------------

# 1️⃣ 根据图片给出的权值矩阵 W
W = np.array([
    [ 0,  1,  1, -1,  1],
    [ 1,  0, -1, -3,  3],
    [ 1, -1,  0,  1, -1],
    [-1, -3,  1,  0, -3],
    [ 1,  3, -1, -3,  0]
], dtype=float)

# 2️⃣ 定义异步更新函数
def sign(x):
    return 1 if x >= 0 else -1

def hopfield_async_update(W, state, order=None, max_iter=20):
    state = state.copy()
    n = len(state)
    if order is None:
        order = range(n)
    for _ in range(max_iter):
        old_state = state.copy()
        for i in order:
            net = np.dot(W[i], state)
            state[i] = sign(net)
        if np.array_equal(state, old_state):
            break
    return state

# 3️⃣ 能量函数
def energy(W, state):
    return -0.5 * state.T @ W @ state

# 4️⃣ 初始状态集合
X0 = [
    np.array([-1, -1,  1,  1,  1]),
    np.array([-1, -1,  1,  1, -1]),
    np.array([-1, -1, -1,  1, -1]),
    np.array([-1,  1,  1,  1, -1]),
    np.array([ 1, -1,  1,  1, -1])
]

# 5️⃣ 异步更新并计算吸引子与能量
order = [0,1,2,3,4]

attractors = {}
for idx, x0 in enumerate(X0, start=1):
    final_state = hopfield_async_update(W, x0, order=order)
    E = energy(W, final_state)
    attractors[idx] = (final_state, E)
    print(f"初始状态 X{idx}(0): {x0}")
    print(f"收敛吸引子状态: {final_state}")
    print(f"能量 E = {E}\n")

# 6️⃣ 判断吸引子（判断哪些状态收敛到同一稳定状态）
unique_states = []
state_labels = []
for idx, (state, E) in attractors.items():
    found = False
    for i, s in enumerate(unique_states):
        if np.array_equal(s, state):
            state_labels.append(i)
            found = True
            break
    if not found:
        unique_states.append(state)
        state_labels.append(len(unique_states)-1)

print("================ 吸引子判断结果 ================")
for i, state in enumerate(unique_states):
    print(f"吸引子 {i+1}: 状态 = {state}, 能量 = {energy(W, state)}")

print("\n各初始状态对应吸引子编号:")
for idx, label in enumerate(state_labels, start=1):
    print(f"X{idx}(0) → 吸引子 {label+1}")