import numpy as np
from typing import List, Tuple, Callable, Dict

class NeuralNetwork6Input:
    """6输入单节点神经网络"""
    def __init__(self, learning_rate: float = 0.1, momentum: float = 0.0, threshold: float = 0.5):
        # 初始化权重（6个输入权重 + 1个偏置）
        self.weights = np.random.randn(7)  # 前6个是输入权重，最后1个是偏置
        self.learning_rate = learning_rate
        self.momentum = momentum
        self.threshold = threshold  # 用于感知器学习规则
        self.prev_delta = np.zeros_like(self.weights)  # 用于动量法
        
        # 选择激活函数和学习规则
        self.activation_function = self.sigmoid
        self.activation_derivative = self.sigmoid_derivative
        self.learning_rule = self.delta_rule  # 默认使用delta规则
        
        # 用于记录训练过程
        self.error_history = []
        self.weights_history = [self.weights.copy()]
        
    # 激活函数及其导数
    def sigmoid(self, x: float) -> float:
        """单极性Sigmoid激活函数 (输出范围: 0-1)"""
        return 1 / (1 + np.exp(-x))
    
    def sigmoid_derivative(self, x: float) -> float:
        """单极性Sigmoid导数"""
        s = self.sigmoid(x)
        return s * (1 - s)
    
    def bipolar_sigmoid(self, x: float) -> float:
        """双极性Sigmoid激活函数 (即tanh，输出范围: -1-1)"""
        return np.tanh(x)
    
    def bipolar_sigmoid_derivative(self, x: float) -> float:
        """双极性Sigmoid导数"""
        return 1 - np.tanh(x)**2
    
    def linear(self, x: float) -> float:
        """线性激活函数 (输出范围: 任意实数)"""
        return x
    
    def linear_derivative(self, x: float) -> float:
        """线性激活函数的导数"""
        return 1
    
    def threshold_function(self, x: float) -> float:
        """阈值函数 (用于感知器，输出: 0或1)"""
        return 1 if x >= self.threshold else 0
    
    # 学习规则
    def standard_gradient_descent(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """标准梯度下降学习规则"""
        # 计算权重更新
        delta = self.learning_rate * error * self.activation_derivative(net_input) * np.append(input_vector, 1)  # 加上偏置对应的1
        # 更新权重
        self.weights += delta
        return delta
    
    def momentum_based(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """动量法学习规则"""
        # 计算当前梯度
        current_delta = self.learning_rate * error * self.activation_derivative(net_input) * np.append(input_vector, 1)
        # 结合之前的梯度更新
        delta = current_delta + self.momentum * self.prev_delta
        # 更新权重
        self.weights += delta
        # 保存当前梯度用于下次计算
        self.prev_delta = delta.copy()
        return delta
    
    def hebbian_rule(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """Hebbian学习规则（无监督学习）"""
        # 计算输出
        output = self.activation_function(net_input)
        # Hebbian学习：权重更新与输入和输出的乘积成正比
        delta = self.learning_rate * input_vector * output
        # 处理偏置项
        bias_delta = self.learning_rate * output
        # 更新权重和偏置
        self.weights[:-1] += delta
        self.weights[-1] += bias_delta
        return np.append(delta, bias_delta)
    
    def perceptron_rule(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """感知器学习规则"""
        # 计算实际输出（使用阈值函数）
        actual_output = self.threshold_function(net_input)
        # 只有当预测错误时才更新权重
        if actual_output != error:  # 注意：这里error实际上是目标值
            # 权重更新与输入和误差成正比
            delta = self.learning_rate * (error - actual_output) * np.append(input_vector, 1)
            # 更新权重
            self.weights += delta
            return delta
        return np.zeros_like(self.weights)
    
    def delta_rule(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """Delta学习规则（连续感知器，也称为Widrow-Hoff规则）"""
        # 计算权重更新（假设使用线性激活函数）
        delta = self.learning_rate * error * np.append(input_vector, 1)  # 加上偏置对应的1
        # 更新权重
        self.weights += delta
        return delta
    
    def widrow_hoff_rule(self, error: float, input_vector: np.ndarray, net_input: float) -> None:
        """Widrow-Hoff学习规则（与Delta规则相同）"""
        # 直接调用delta_rule，因为它们是相同的实现
        return self.delta_rule(error, input_vector, net_input)
    
    # 设置不同的激活函数
    def set_activation_function(self, function_name: str) -> None:
        """设置激活函数"""
        if function_name.lower() == 'sigmoid':
            self.activation_function = self.sigmoid
            self.activation_derivative = self.sigmoid_derivative
        elif function_name.lower() == 'bipolar_sigmoid':
            self.activation_function = self.bipolar_sigmoid
            self.activation_derivative = self.bipolar_sigmoid_derivative
        elif function_name.lower() == 'linear':
            self.activation_function = self.linear
            self.activation_derivative = self.linear_derivative
        elif function_name.lower() == 'threshold':
            self.activation_function = self.threshold_function
            # 阈值函数不可导，这里使用线性导数作为替代
            self.activation_derivative = self.linear_derivative
        else:
            raise ValueError(f"不支持的激活函数: {function_name}。可选的激活函数: 'sigmoid', 'bipolar_sigmoid', 'linear', 'threshold'")
    
    # 设置不同的学习规则
    def set_learning_rule(self, rule_name: str) -> None:
        """设置学习规则"""
        if rule_name.lower() == 'standard':
            self.learning_rule = self.standard_gradient_descent
        elif rule_name.lower() == 'momentum':
            self.learning_rule = self.momentum_based
        elif rule_name.lower() == 'hebbian':
            self.learning_rule = self.hebbian_rule
        elif rule_name.lower() == 'perceptron':
            self.learning_rule = self.perceptron_rule
        elif rule_name.lower() == 'delta':
            self.learning_rule = self.delta_rule
        elif rule_name.lower() == 'widrow_hoff':
            self.learning_rule = self.widrow_hoff_rule
        else:
            raise ValueError(f"不支持的学习规则: {rule_name}")
    
    # 前向传播
    def forward(self, input_vector: np.ndarray) -> Tuple[float, float]:
        """前向传播，返回净输入和输出"""
        # 计算净输入（带偏置）
        net_input = np.dot(input_vector, self.weights[:-1]) + self.weights[-1]
        # 应用激活函数
        output = self.activation_function(net_input)
        return net_input, output
    
    # 训练网络
    def train(self, training_data: List[Tuple[np.ndarray, float]], epochs: int = 1000, verbose: bool = True) -> None:
        """训练网络"""
        for epoch in range(epochs):
            total_error = 0
            
            for input_vector, target in training_data:
                # 前向传播
                net_input, output = self.forward(input_vector)
                
                # 计算误差
                error = target - output
                total_error += abs(error)
                
                # 更新权重
                delta = self.learning_rule(error, input_vector, net_input)
                
                # 记录权重历史
                self.weights_history.append(self.weights.copy())
                
                # 显示每一步的信息
                if verbose:
                    print(f"Epoch {epoch+1}, Step: 净输入={net_input:.4f}, 输出={output:.4f}, 目标={target:.4f}, 误差={error:.4f}")
                    print(f"       权重更新: {delta}")
                    print(f"       更新后权重: {self.weights}")
                    print("---")
            
            # 记录平均误差
            self.error_history.append(total_error / len(training_data))
            
            # 简单的早停机制
            if len(self.error_history) > 1 and abs(self.error_history[-1] - self.error_history[-2]) < 0.0001:
                print(f"训练提前停止，在第 {epoch+1} 轮达到收敛")
                break
    
    # 预测
    def predict(self, input_vector: np.ndarray) -> float:
        """预测新的输入"""
        _, output = self.forward(input_vector)
        return output

# 生成不同的训练样本

def generate_xor6_samples() -> List[Tuple[np.ndarray, float]]:
    """生成6输入异或问题的训练样本"""
    # 在6输入的情况下，XOR问题可以定义为：如果1的个数为奇数，输出1；否则输出0
    samples = []
    # 生成所有可能的6位二进制组合
    for i in range(64):  # 2^6 = 64
        # 将整数转换为6位二进制数组
        inputs = np.array([int(bit) for bit in f'{i:06b}'])
        # 计算1的个数是否为奇数
        target = 1 if np.sum(inputs) % 2 == 1 else 0
        samples.append((inputs, target))
    return samples

def generate_majority_samples() -> List[Tuple[np.ndarray, float]]:
    """生成6输入多数表决问题的训练样本"""
    # 多数表决：如果1的个数大于0的个数，输出1；否则输出0
    samples = []
    for i in range(64):
        inputs = np.array([int(bit) for bit in f'{i:06b}'])
        target = 1 if np.sum(inputs) > 3 else 0  # 6个输入中，大于3个1即为多数
        samples.append((inputs, target))
    return samples

def generate_custom_samples() -> List[Tuple[np.ndarray, float]]:
    """生成自定义的训练样本"""
    # 这里可以根据需要自定义训练样本
    samples = [
        (np.array([1, 1, 1, 0, 0, 0]), 1),
        (np.array([1, 1, 0, 0, 0, 0]), 1),
        
    ]
    return samples

# 使用示例
if __name__ == "__main__":
    # 创建网络实例
    nn = NeuralNetwork6Input(learning_rate=0.1, momentum=0.5, threshold=0.5)
    
    # 设置激活函数和学习规则
    nn.set_activation_function('sigmoid')  # 可选: 'sigmoid', 'bipolar_sigmoid', 'linear', 'threshold'
    # 设置学习规则：可选 'hebbian', 'perceptron', 'delta', 'widrow_hoff', 'standard', 'momentum'
    nn.set_learning_rule('widrow_hoff')
    
    # 生成训练样本
    # 可选: generate_xor6_samples(), generate_majority_samples(), generate_custom_samples()
    training_data = generate_custom_samples()
    
    print("开始训练6输入单节点神经网络...")
    # 训练网络
    nn.train(training_data, epochs=100, verbose=True)
    
    # 测试网络
    print("\n测试网络:")
    for inputs, target in training_data:
        prediction = nn.predict(inputs)
        print(f"输入: {inputs}, 目标: {target}, 预测: {prediction:.4f}")