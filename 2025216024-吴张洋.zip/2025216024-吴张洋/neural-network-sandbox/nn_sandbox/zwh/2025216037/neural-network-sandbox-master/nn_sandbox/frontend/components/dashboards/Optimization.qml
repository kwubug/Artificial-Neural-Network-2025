import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.13
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'Optimization'
    
    SplitView {
        anchors.fill: parent
        orientation: Qt.Horizontal
        
        // 左侧控制面板
        Item {
            SplitView.preferredWidth: 300
            SplitView.minimumWidth: 250
            
            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 10
                
                GroupBox {
                    title: 'Objective Function'
                    Layout.fillWidth: true
                    ComboBox {
                        id: functionSelector
                        anchors.fill: parent
                        model: ['Rosenbrock', 'Himmelblau', 'Rastrigin', 'Ackley', 'Beale', 'Sphere']
                        enabled: optimizationBridge.has_finished
                        onActivated: {
                            optimizationBridge.objective_function = currentIndex
                            updateStartPointsForFunction(currentIndex)
                        }
                        Component.onCompleted: optimizationBridge.objective_function = currentIndex
                    }
                }
                
                GroupBox {
                    title: 'Optimization Method'
                    Layout.fillWidth: true
                    ComboBox {
                        anchors.fill: parent
                        model: ['Steepest Descent', 'Newton Method', 'Conjugate Gradient']
                        enabled: optimizationBridge.has_finished
                        onActivated: optimizationBridge.optimization_method = currentIndex
                        Component.onCompleted: optimizationBridge.optimization_method = currentIndex
                    }
                }
                
                GroupBox {
                    title: 'Parameters'
                    Layout.fillWidth: true
                    GridLayout {
                        anchors.fill: parent
                        columns: 2
                        
                        Label { text: 'Learning Rate' }
                        DoubleSpinBox {
                            id: learningRateSpinBox
                            value: 1
                            from: 1
                            to: 100
                            onValueChanged: optimizationBridge.learning_rate = value / 1000
                            Component.onCompleted: optimizationBridge.learning_rate = 0.001
                            Layout.fillWidth: true
                        }
                        
                        Label { text: 'Max Iterations' }
                        SpinBox {
                            value: 50
                            from: 10
                            to: 200
                            onValueChanged: optimizationBridge.max_iterations = value
                            Component.onCompleted: optimizationBridge.max_iterations = value
                            Layout.fillWidth: true
                        }
                        
                        Label { text: 'Start Point X' }
                        DoubleSpinBox {
                            id: startXSpinBox
                            value: -100
                            from: -500
                            to: 500
                            onValueChanged: optimizationBridge.start_x = value / 100
                            Component.onCompleted: optimizationBridge.start_x = -1.0
                            Layout.fillWidth: true
                        }
                        
                        Label { text: 'Start Point Y' }
                        DoubleSpinBox {
                            id: startYSpinBox
                            value: -100
                            from: -500
                            to: 500
                            onValueChanged: optimizationBridge.start_y = value / 100
                            Component.onCompleted: optimizationBridge.start_y = -1.0
                            Layout.fillWidth: true
                        }
                    }
                }
                
                Button {
                    text: 'Start Optimization'
                    Layout.fillWidth: true
                    enabled: optimizationBridge.has_finished
                    onClicked: {
                        optimizationBridge.start_optimization()
                    }
                }
                
                Button {
                    text: 'Stop'
                    Layout.fillWidth: true
                    enabled: !optimizationBridge.has_finished
                    onClicked: {
                        optimizationBridge.stop_optimization()
                    }
                }
                
                GroupBox {
                    title: 'Information'
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    
                    GridLayout {
                        anchors.fill: parent
                        columns: 2
                        
                        Label { text: 'Current Iteration' }
                        Label { text: optimizationBridge.current_iteration }
                        
                        Label { text: 'X' }
                        Label { text: optimizationBridge.current_x.toFixed(4) }
                        
                        Label { text: 'Y' }
                        Label { text: optimizationBridge.current_y.toFixed(4) }
                        
                        Label { text: 'f(x,y)' }
                        Label { text: optimizationBridge.current_value.toFixed(4) }
                        
                        Label { text: 'Gradient Norm' }
                        Label { text: optimizationBridge.gradient_norm.toFixed(4) }
                    }
                }
            }
        }
        
        // 右侧3D曲面图
        Item {
            SplitView.fillWidth: true
            
            Rectangle {
                anchors.fill: parent
                color: "white"
                
                Image {
                    id: surfaceImage
                    anchors.fill: parent
                    anchors.margins: 10
                    fillMode: Image.PreserveAspectFit
                    cache: false
                    
                    Label {
                        anchors.centerIn: parent
                        text: "Click 'Start Optimization' to visualize"
                        visible: surfaceImage.source == ""
                        font.pixelSize: 18
                        color: "gray"
                    }
                }
            }
        }
    }
    
    Connections {
        target: optimizationBridge
        function onSurfaceUpdated(imageBase64) {
            surfaceImage.source = "data:image/png;base64," + imageBase64
        }
    }
    
    // 根据选择的函数更新推荐的起始点
    function updateStartPointsForFunction(functionIndex) {
        switch(functionIndex) {
            case 0: // Rosenbrock
                startXSpinBox.value = -100
                startYSpinBox.value = -100
                learningRateSpinBox.value = 1
                break
            case 1: // Himmelblau
                startXSpinBox.value = 0
                startYSpinBox.value = 0
                learningRateSpinBox.value = 10
                break
            case 2: // Rastrigin
                startXSpinBox.value = 400
                startYSpinBox.value = 400
                learningRateSpinBox.value = 5
                break
            case 3: // Ackley
                startXSpinBox.value = -200
                startYSpinBox.value = 200
                learningRateSpinBox.value = 5
                break
            case 4: // Beale
                startXSpinBox.value = 100
                startYSpinBox.value = 100
                learningRateSpinBox.value = 2
                break
            case 5: // Sphere
                startXSpinBox.value = -300
                startYSpinBox.value = 300
                learningRateSpinBox.value = 10
                break
        }
    }
}
