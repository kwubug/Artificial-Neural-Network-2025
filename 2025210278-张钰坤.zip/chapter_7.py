import numpy as np
import matplotlib.pyplot as plt
import sys

# 创建输出文件，指定UTF-8编码
output_file = open('hopfield_output.txt', 'w', encoding='utf-8')

# 初始化网络参数
class HopfieldNetwork:
    def __init__(self, N):
        self.N = N  # 神经元数量
        self.state = np.random.choice([-1, 1], size=N)  # 随机初始化状态
        self.weights = np.zeros((N, N))  # 权重矩阵，初始化为零
    
    def train(self, patterns):
        """
        使用Hebbian学习规则训练网络。
        :param patterns: 训练样本矩阵，每行一个样本，大小为 (P, N)
        """
        P = patterns.shape[0]
        for p in range(P):
            # Hebbian学习法则：w = sum(pattern * pattern.T)
            self.weights += np.outer(patterns[p], patterns[p])
        
        # 权重矩阵对角线置为0（神经元不与自己连接）
        np.fill_diagonal(self.weights, 0)
    
    def energy(self):
        """
        计算当前状态的能量
        """
        return -0.5 * np.sum(np.dot(self.state, self.weights) * self.state)
    
    def update(self):
        """
        异步更新神经网络
        """
        i = np.random.randint(self.N)  # 随机选择一个神经元
        # 计算神经元 i 的净输入
        net_input = np.dot(self.weights[i], self.state)
        # 更新状态：如果净输入大于0，则激活，否则不激活
        self.state[i] = 1 if net_input > 0 else -1
    
    def run(self, max_iter=1000, threshold=0.01):
        """
        运行网络，直到收敛
        :param max_iter: 最大迭代次数
        :param threshold: 收敛阈值
        """
        energy_history = []
        for _ in range(max_iter):
            old_state = self.state.copy()
            self.update()  # 异步更新
            energy_history.append(self.energy())
            
            # 如果状态没有变化，认为网络已经收敛
            if np.all(self.state == old_state):
                break
            
        return energy_history

# 定义训练模式 - 修改为更丰富的模式组合
pattern_1 = np.array([1, 1, 1, 1])       # 全1模式
pattern_2 = np.array([1, 1, -1, -1])     # 前两个1，后两个-1
pattern_3 = np.array([1, -1, 1, -1])     # 交替模式
pattern_4 = np.array([-1, -1, -1, -1])   # 全-1模式
patterns = np.array([pattern_1, pattern_2, pattern_3, pattern_4])

# 打印训练模式到文件
output_file.write("训练模式：\n")
for i, pattern in enumerate(patterns):
    output_file.write(f"模式 {i+1}: {pattern}\n")

# 初始化 Hopfield 网络
N = len(pattern_1)  # 模式长度（神经元个数）
hopfield = HopfieldNetwork(N)

# 使用训练样本训练网络
hopfield.train(patterns)

# 运行网络，观察能量的变化
energy_history = hopfield.run(max_iter=1000)

# 绘制能量变化
plt.figure(figsize=(8, 6))
plt.plot(energy_history, label="Energy")
plt.xlabel("Iterations", fontsize=14)
plt.ylabel("Energy", fontsize=14)
plt.title("Energy vs Iterations in Hopfield Network", fontsize=16)
plt.grid(True)
plt.legend()
plt.show()

# 输出权重矩阵到文件
output_file.write("\n权重矩阵：\n")
output_file.write(f"{hopfield.weights}\n")

# 输出最终状态（吸引子）到文件
output_file.write(f"\n最终状态（吸引子）: {hopfield.state}\n")

# 检查最终状态是否是训练模式之一
matched = False
for i, pattern in enumerate(patterns):
    if np.array_equal(hopfield.state, pattern):
        output_file.write(f"最终状态匹配训练模式 {i+1}\n")
        matched = True
        break
if not matched:
    output_file.write("最终状态不匹配任何训练模式\n")

# 关闭文件
output_file.close()