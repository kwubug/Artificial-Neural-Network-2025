import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield'

    property bool bridgeReady: typeof hopfieldBridge !== 'undefined' && hopfieldBridge !== null

    ColumnLayout {
        anchors.fill: parent
        
        GroupBox {
            title: 'Hopfield 神经网络'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ColumnLayout {
                anchors.fill: parent
                
                Label {
                    text: bridgeReady ? "Bridge 已连接" : "Bridge 未连接"
                    color: bridgeReady ? "green" : "red"
                    font.bold: true
                    font.pixelSize: 16
                }
                
                GridLayout {
                    columns: 2
                    columnSpacing: 10
                    rowSpacing: 5
                    
                    Label { text: '最大迭代次数' }
                    SpinBox {
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        value: 100
                        from: 10
                        to: 1000
                        stepSize: 10
                        onValueChanged: { if (bridgeReady) hopfieldBridge.max_iterations = value }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '训练网络'
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        onClicked: { if (bridgeReady) hopfieldBridge.train_network() }
                        Layout.columnSpan: 2
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '神经元数量' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.n_neurons : '0'
                        font.bold: true
                    }
                    
                    Label { text: '当前迭代' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.current_iterations : '0'
                        font.bold: true
                    }
                    
                    Label { text: '当前能量' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.current_energy.toFixed(4) : '0.0000'
                        font.bold: true
                    }
                }
                
                Item { Layout.fillHeight: true }
            }
        }
    }

    Connections {
        target: bridgeReady ? hopfieldBridge : null
        enabled: bridgeReady
        
        function onHas_finishedChanged() {
            console.log("Hopfield training finished:", bridgeReady ? hopfieldBridge.has_finished : false)
        }
    }
}