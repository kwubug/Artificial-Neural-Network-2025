# nn_sandbox/bridges/OLSVisualizer.py
import numpy as np
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

class OLSVisualizer(QWidget):
    """
    多项式 OLS 可视化组件
    支持用户选择多项式阶数进行拟合
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.fig)
        layout = QVBoxLayout(self)
        layout.addWidget(self.canvas)

    def generate_data(self, n_points=20, seed=None):
        if seed is not None:
            np.random.seed(seed)
        self.x = np.linspace(0, 10, n_points)
        noise = np.random.randn(n_points) * 2
        # 用真实二次曲线生成数据，增加随机噪声
        self.y = 0.5 * self.x**2 - 3 * self.x + 5 + noise
        return self.x, self.y

    def fit_polynomial(self, degree=2):
        # 使用 np.vander 构建多项式矩阵，最小二乘求解系数
        X = np.vander(self.x, N=degree+1, increasing=True)  # [1, x, x^2, ...]
        beta = np.linalg.lstsq(X, self.y, rcond=None)[0]
        self.beta = beta
        return beta

    def visualize(self, degree=2):
        if not hasattr(self, 'x'):
            raise RuntimeError("请先生成数据 generate_data()")
        self.fit_polynomial(degree)
        self.ax.clear()
        self.ax.scatter(self.x, self.y, color='tab:blue', label='Random Data')
        # 拟合曲线
        X_fit = np.vander(self.x, N=degree+1, increasing=True)
        y_fit = X_fit @ self.beta
        self.ax.plot(self.x, y_fit, color='tab:red', label=f'Poly fit (deg={degree})')
        self.ax.set_title(f"Polynomial Regression (degree={degree})")
        self.ax.legend()
        self.canvas.draw()

    def refresh(self, degree=2, n_points=20):
        """随机生成新数据并重新绘制拟合曲线"""
        self.generate_data(n_points=n_points)
        self.visualize(degree)

