import sys
import numpy as np
from sklearn.datasets import make_classification, make_blobs
import time
import math
import operator
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QSplitter, QProgressBar)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

class SomNeuron:
    """SOM神经元"""
    def __init__(self, synaptic_weight_range):
        self._data = None
        self.synaptic_weight = np.fromiter(
            (np.random.uniform(lower, upper)
             for lower, upper in synaptic_weight_range), dtype=float
        )

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        self._data = value

    @property
    def dist(self):
        """输入数据与突触权重之间的距离"""
        return np.linalg.norm(self._data - self.synaptic_weight)

class SomAlgorithm:
    """SOM算法实现"""
    def __init__(self, dataset, total_epoches=10, initial_learning_rate=0.8,
                 initial_standard_deviation=1, topology_shape=None):
        self._dataset = dataset
        self._total_epoches = total_epoches
        self._initial_learning_rate = initial_learning_rate
        self._initial_standard_deviation = initial_standard_deviation
        self.topology_shape = topology_shape if topology_shape else [10, 10]
        self.current_iterations = 0
        self._neurons = None
        self._should_stop = False
        
        # 历史记录用于可视化
        self.learning_rate_history = []
        self.standard_deviation_history = []
        self.weights_history = []
        self.winner_history = []

    def run(self):
        """运行SOM算法"""
        self._initialize_neurons()
        for self.current_iterations in range(self._total_epoches * len(self._dataset)):
            if self._should_stop:
                break
            if self.current_iterations % len(self._dataset) == 0:
                np.random.shuffle(self._dataset)
            self._iterate()

    def _initialize_neurons(self):
        """初始化神经元"""
        data_range = tuple(zip(np.amin(self._dataset, axis=0),
                               np.amax(self._dataset, axis=0)))
        self._neurons = [[SomNeuron(data_range)
                          for _ in range(self.topology_shape[0])]
                         for _ in range(self.topology_shape[1])]

    def _iterate(self):
        """单次迭代"""
        self._feed_forward()
        winner = self._get_winner()
        self._adjust_synaptic_weight(winner)
        
        # 记录历史数据
        self.learning_rate_history.append(self.current_learning_rate)
        self.standard_deviation_history.append(self.current_standard_deviation)
        self.weights_history.append(self.get_weights_matrix())
        self.winner_history.append(winner)

    def _feed_forward(self):
        """前向传播"""
        for row in self._neurons:
            for neuron in row:
                neuron.data = self.current_data

    def _get_winner(self):
        """获取获胜神经元"""
        return min(self._flatten(self._neurons), key=operator.attrgetter('dist'))

    def _adjust_synaptic_weight(self, winner: SomNeuron):
        """调整突触权重"""
        for i, row in enumerate(self._neurons):
            if winner in row:
                winner_index = (i, row.index(winner))
                break

        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                distance = np.linalg.norm(np.array([i, j]) - np.array(winner_index))
                neighborhood = math.exp(-distance**2 / (2 * self.current_standard_deviation**2))
                neuron.synaptic_weight += (
                    self.current_learning_rate * neighborhood *
                    (self.current_data - neuron.synaptic_weight)
                )

    def _flatten(self, nested_list):
        """展平嵌套列表"""
        for sublist in nested_list:
            for item in sublist:
                yield item

    def get_weights_matrix(self):
        """获取权重矩阵"""
        weights = []
        for row in self._neurons:
            row_weights = []
            for neuron in row:
                row_weights.append(neuron.synaptic_weight.copy())
            weights.append(row_weights)
        return weights

    def stop(self):
        """停止训练"""
        self._should_stop = True

    @property
    def current_data(self):
        return self._dataset[self.current_iterations % len(self._dataset)]

    @property
    def current_learning_rate(self):
        return self._initial_learning_rate * math.exp(
            -self.current_iterations / (self._total_epoches * len(self._dataset))
        )

    @property
    def current_standard_deviation(self):
        return self._initial_standard_deviation * math.exp(
            -self.current_iterations / (self._total_epoches * len(self._dataset))
        )

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class SomVisualizer(QMainWindow):
    """SOM网络PyQt可视化器"""
    
    def __init__(self):
        super().__init__()
        self.model = None
        self.X = None
        self.training = False
        self.current_step = 0
        self.total_steps = 100
        self.timer = QTimer()
        self.timer.timeout.connect(self.train_step)
        
        self.init_ui()
        self.generate_data()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("SOM自组织映射网络可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 3)
        
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """创建控制面板"""
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)
        
        # 标题
        title_label = QLabel("SOM算法控制台")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # 参数设置
        params_group = QGroupBox("参数设置")
        params_layout = QVBoxLayout(params_group)
        
        # 学习率
        lr_layout = QHBoxLayout()
        lr_label = QLabel("初始学习率:")
        self.lr_input = QLineEdit("0.8")
        lr_layout.addWidget(lr_label)
        lr_layout.addWidget(self.lr_input)
        params_layout.addLayout(lr_layout)
        
        # 标准差
        std_layout = QHBoxLayout()
        std_label = QLabel("初始标准差:")
        self.std_input = QLineEdit("1.0")
        std_layout.addWidget(std_label)
        std_layout.addWidget(self.std_input)
        params_layout.addLayout(std_layout)
        
        # 样本数量
        samples_layout = QHBoxLayout()
        samples_label = QLabel("样本数量:")
        self.samples_input = QLineEdit("300")
        samples_layout.addWidget(samples_label)
        samples_layout.addWidget(self.samples_input)
        params_layout.addLayout(samples_layout)
        
        # 训练轮数
        epochs_layout = QHBoxLayout()
        epochs_label = QLabel("训练轮数:")
        self.epochs_input = QLineEdit("10")
        epochs_layout.addWidget(epochs_label)
        epochs_layout.addWidget(self.epochs_input)
        params_layout.addLayout(epochs_layout)
        
        # 拓扑形状
        topology_layout = QHBoxLayout()
        topology_label = QLabel("拓扑形状:")
        self.topology_input = QLineEdit("10,10")
        topology_layout.addWidget(topology_label)
        topology_layout.addWidget(self.topology_input)
        params_layout.addLayout(topology_layout)
        
        control_layout.addWidget(params_group)
        
        # 控制按钮
        buttons_group = QGroupBox("训练控制")
        buttons_layout = QVBoxLayout(buttons_group)
        
        self.start_button = QPushButton("开始训练")
        self.start_button.clicked.connect(self.start_training)
        buttons_layout.addWidget(self.start_button)
        
        self.pause_button = QPushButton("暂停训练")
        self.pause_button.clicked.connect(self.pause_training)
        self.pause_button.setEnabled(False)
        buttons_layout.addWidget(self.pause_button)
        
        self.reset_button = QPushButton("重置模型")
        self.reset_button.clicked.connect(self.reset_model)
        buttons_layout.addWidget(self.reset_button)
        
        control_layout.addWidget(buttons_group)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        control_layout.addWidget(self.progress_bar)
        
        # 训练信息
        info_group = QGroupBox("训练信息")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 网络拓扑标签页
        topology_tab = QWidget()
        topology_layout = QVBoxLayout(topology_tab)
        self.topology_canvas = MplCanvas(self, width=8, height=6)
        topology_layout.addWidget(self.topology_canvas)
        visualization_widget.addTab(topology_tab, "网络拓扑")
        
        # 学习率标签页
        lr_tab = QWidget()
        lr_layout = QVBoxLayout(lr_tab)
        self.lr_canvas = MplCanvas(self, width=8, height=4)
        lr_layout.addWidget(self.lr_canvas)
        visualization_widget.addTab(lr_tab, "学习率变化")
        
        # 标准差标签页
        std_tab = QWidget()
        std_layout = QVBoxLayout(std_tab)
        self.std_canvas = MplCanvas(self, width=8, height=4)
        std_layout.addWidget(self.std_canvas)
        visualization_widget.addTab(std_tab, "标准差变化")
        
        # 数据分布标签页
        data_tab = QWidget()
        data_layout = QVBoxLayout(data_tab)
        self.data_canvas = MplCanvas(self, width=8, height=4)
        data_layout.addWidget(self.data_canvas)
        visualization_widget.addTab(data_tab, "数据分布")
        
        # 权重矩阵标签页
        weights_tab = QWidget()
        weights_layout = QVBoxLayout(weights_tab)
        self.weights_canvas = MplCanvas(self, width=8, height=4)
        weights_layout.addWidget(self.weights_canvas)
        visualization_widget.addTab(weights_tab, "权重矩阵")
        
        return visualization_widget
    
    def generate_data(self):
        """生成演示数据"""
        n_samples = int(self.samples_input.text())
        # 生成聚类数据用于SOM演示
        self.X, _ = make_blobs(n_samples=n_samples, centers=4, n_features=2, 
                              random_state=42, cluster_std=0.8)
        
        # 初始化模型
        self.reset_model()
        
        # 绘制初始数据分布
        self.plot_data_distribution()
    
    def reset_model(self):
        """重置模型"""
        learning_rate = float(self.lr_input.text())
        standard_deviation = float(self.std_input.text())
        epochs = int(self.epochs_input.text())
        topology_shape = [int(x.strip()) for x in self.topology_input.text().split(',')]
        
        self.model = SomAlgorithm(dataset=self.X, total_epoches=epochs,
                                initial_learning_rate=learning_rate,
                                initial_standard_deviation=standard_deviation,
                                topology_shape=topology_shape)
        self.current_step = 0
        self.progress_bar.setValue(0)
        self.info_text.clear()
        self.info_text.append("SOM模型已重置，准备开始训练...")
        self.update_plots()
    
    def start_training(self):
        """开始训练"""
        if not self.training:
            self.total_steps = int(self.epochs_input.text()) * len(self.X)
            self.training = True
            self.start_button.setEnabled(False)
            self.pause_button.setEnabled(True)
            self.timer.start(50)  # 每50ms训练一步
            self.info_text.append("SOM训练开始...")
    
    def pause_training(self):
        """暂停训练"""
        if self.training:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("训练暂停...")
    
    def train_step(self):
        """训练一步"""
        if self.current_step >= self.total_steps:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("SOM训练完成!")
            return
        
        # 手动执行一次迭代
        if self.model._neurons is None:
            self.model._initialize_neurons()
        
        # 执行迭代
        self.model._iterate()
        
        # 更新进度
        self.current_step += 1
        progress = int((self.current_step / self.total_steps) * 100)
        self.progress_bar.setValue(progress)
        
        # 更新信息显示
        if self.current_step % 100 == 0:
            lr = self.model.current_learning_rate
            std = self.model.current_standard_deviation
            self.info_text.append(f"步数: {self.current_step}, 学习率: {lr:.4f}, 标准差: {std:.4f}")
        
        # 更新图表
        self.update_plots()
    
    def update_plots(self):
        """更新所有图表"""
        self.plot_topology()
        self.plot_learning_rate()
        self.plot_standard_deviation()
        self.plot_weights_matrix()
        self.topology_canvas.draw()
        self.lr_canvas.draw()
        self.std_canvas.draw()
        self.weights_canvas.draw()
    
    def plot_topology(self):
        """绘制网络拓扑"""
        self.topology_canvas.fig.clear()
        ax = self.topology_canvas.fig.add_subplot(111)
        
        if self.model._neurons is not None:
            # 绘制数据点
            ax.scatter(self.X[:, 0], self.X[:, 1], c='blue', alpha=0.3, s=20, label='Data Points')
            
            # 绘制神经元权重
            weights = self.model.get_weights_matrix()
            neuron_x = []
            neuron_y = []
            
            for i, row in enumerate(weights):
                for j, neuron_weights in enumerate(row):
                    neuron_x.append(neuron_weights[0])
                    neuron_y.append(neuron_weights[1])
            
            # 绘制神经元位置
            ax.scatter(neuron_x, neuron_y, c='red', s=50, marker='s', label='Neurons')
            
            # 绘制拓扑连接线
            rows, cols = len(weights), len(weights[0])
            
            # 水平连接
            for i in range(rows):
                for j in range(cols - 1):
                    x1, y1 = weights[i][j]
                    x2, y2 = weights[i][j + 1]
                    ax.plot([x1, x2], [y1, y2], 'g-', alpha=0.5, linewidth=1)
            
            # 垂直连接
            for i in range(rows - 1):
                for j in range(cols):
                    x1, y1 = weights[i][j]
                    x2, y2 = weights[i + 1][j]
                    ax.plot([x1, x2], [y1, y2], 'g-', alpha=0.5, linewidth=1)
            
            ax.set_title(f'SOM network topology (step: {self.current_step})', fontsize=12, color='white')
            ax.set_xlabel('Feature 1', color='white')
            ax.set_ylabel('Feature 2', color='white')
            ax.legend()
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.topology_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.topology_canvas.draw()
    
    def plot_learning_rate(self):
        """绘制学习率变化曲线"""
        self.lr_canvas.fig.clear()
        ax = self.lr_canvas.fig.add_subplot(111)
        
        if len(self.model.learning_rate_history) > 0:
            ax.plot(range(len(self.model.learning_rate_history)), 
                   self.model.learning_rate_history, 'r-', linewidth=2)
            ax.set_title('Learning rate curve', fontsize=12, color='white')
            ax.set_xlabel('Training steps', color='white')
            ax.set_ylabel('Learning rate', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.lr_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.lr_canvas.draw()
    
    def plot_standard_deviation(self):
        """绘制标准差变化曲线"""
        self.std_canvas.fig.clear()
        ax = self.std_canvas.fig.add_subplot(111)
        
        if len(self.model.standard_deviation_history) > 0:
            ax.plot(range(len(self.model.standard_deviation_history)), 
                   self.model.standard_deviation_history, 'b-', linewidth=2)
            ax.set_title('Neighborhood standard deviation curve', fontsize=12, color='white')
            ax.set_xlabel('Training steps', color='white')
            ax.set_ylabel('Standard deviation', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.std_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.std_canvas.draw()
    
    def plot_data_distribution(self):
        """绘制数据分布"""
        self.data_canvas.fig.clear()
        ax = self.data_canvas.fig.add_subplot(111)
        
        if self.X is not None:
            ax.scatter(self.X[:, 0], self.X[:, 1], alpha=0.6, c='blue')
            ax.set_title('Training data distribution', fontsize=12, color='white')
            ax.set_xlabel('Feature 1', color='white')
            ax.set_ylabel('Feature 2', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.data_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.data_canvas.draw()
    
    def plot_weights_matrix(self):
        """绘制权重矩阵热力图"""
        self.weights_canvas.fig.clear()
        ax = self.weights_canvas.fig.add_subplot(111)
        
        if self.model._neurons is not None and len(self.model.weights_history) > 0:
            # 获取最新的权重矩阵
            current_weights = self.model.weights_history[-1]
            # 将权重矩阵转换为2D数组用于热力图
            weight_values = []
            for row in current_weights:
                row_values = []
                for neuron_weights in row:
                    # 使用权重向量的模作为热力图值
                    row_values.append(np.linalg.norm(neuron_weights))
                weight_values.append(row_values)
            
            im = ax.imshow(weight_values, cmap='viridis', aspect='auto')
            ax.set_title('Weights matrix heatmap', fontsize=12, color='white')
            ax.set_xlabel('Column index', color='white')
            ax.set_ylabel('Row index', color='white')
            self.weights_canvas.fig.colorbar(im, ax=ax)
            ax.set_facecolor('#2b2b2b')
            self.weights_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.weights_canvas.draw()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = SomVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()