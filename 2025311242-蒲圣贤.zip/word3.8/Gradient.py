import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# -------------------- 定义函数及梯度 --------------------
def f(X):
    x, y = X
    return (4 - 2.1 * x**2 + x**4 / 3) * x**2 + x * y + (-4 + 4 * y**2) * y**2

def grad_f(X):
    x, y = X
    dfdx = 8 * x - 8.4 * x**3 + 2 * x**5 + y
    dfdy = x - 8 * y + 16 * y**3
    return np.array([dfdx, dfdy])

def hessian_f(X):
    x, y = X
    d2fdx2 = 8 - 25.2 * x**2 + 10 * x**4
    d2fdy2 = -8 + 48 * y**2
    d2fdxdy = 1
    return np.array([[d2fdx2, d2fdxdy], [d2fdxdy, d2fdy2]])

# -------------------- 算法实现 --------------------
def steepest_descent(X0, lr=0.001, max_iter=200):
    X = X0
    path = [X.copy()]
    for _ in range(max_iter):
        X = X - lr * grad_f(X)
        path.append(X.copy())
    return np.array(path)

def newton_method(X0, max_iter=20):
    X = X0
    path = [X.copy()]
    for _ in range(max_iter):
        g = grad_f(X)
        H = hessian_f(X)
        try:
            X = X - np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        path.append(X.copy())
    return np.array(path)

def conjugate_gradient(X0, max_iter=100):
    X = X0
    g = grad_f(X)
    d = -g
    path = [X.copy()]
    for _ in range(max_iter):
        alpha = 1e-3
        X_new = X + alpha * d
        g_new = grad_f(X_new)
        beta = np.dot(g_new, g_new) / (np.dot(g, g) + 1e-8)
        d = -g_new + beta * d
        X = X_new
        g = g_new
        path.append(X.copy())
    return np.array(path)

# -------------------- 绘图背景 --------------------
def draw_contour(ax):
    x = np.linspace(-2, 2, 400)
    y = np.linspace(-1, 1, 400)
    X, Y = np.meshgrid(x, y)
    Z = f([X, Y])
    ax.contour(X, Y, Z, levels=50, cmap='viridis')
    ax.set_xlim(-2, 2)
    ax.set_ylim(-1, 1)
    ax.set_xlabel('x')
    ax.set_ylabel('y')

# -------------------- 动画生成 --------------------
def animate_all(path_sd, path_newton, path_cg):
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    titles = ["Steepest Descent", "Newton's Method", "Conjugate Gradient"]
    paths = [path_sd, path_newton, path_cg]

    points, lines = [], []

    for ax, title, path in zip(axes, titles, paths):
        draw_contour(ax)
        ax.set_title(title)
        p, = ax.plot([], [], 'ro', markersize=5)
        l, = ax.plot([], [], 'r-', lw=1.5)
        points.append(p)
        lines.append(l)

    max_len = max(len(p) for p in paths)

def update(i):
    plt.show()
    for j, path in enumerate(paths):
        k = min(i, len(path)-1)
        points[j].set_data([path[k, 0]], [path[k, 1]])
        lines[j].set_data(path[:k+1, 0], path[:k+1, 1])
    return points + lines

    ani = animation.FuncAnimation(fig, update, frames=max_len, blit=True, interval=100)
    ani.save("gradient_descent_comparison.gif", writer='pillow', fps=10)

    # plt.close(fig)
# -------------------- 主程序 --------------------
if __name__ == "__main__":
    X0 = np.array([-0.75, -0.75])

    path_sd = steepest_descent(X0)
    path_newton = newton_method(X0)
    path_cg = conjugate_gradient(X0)

    animate_all(path_sd, path_newton, path_cg)
    print("✅ 动图已生成：gradient_descent_comparison.gif")