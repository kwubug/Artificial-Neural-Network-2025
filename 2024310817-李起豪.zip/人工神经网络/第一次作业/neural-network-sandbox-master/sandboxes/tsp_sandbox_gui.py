from __future__ import annotations

import sys
from pathlib import Path
from typing import List

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QApplication,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

try:
    from .tsp_sandbox_visualization import (
        TSPConfig,
        export_summary,
        plot_tours,
        simulated_annealing,
        total_distance,
    )
except ImportError:  # pragma: no cover
    from tsp_sandbox_visualization import (  # type: ignore
        TSPConfig,
        export_summary,
        plot_tours,
        simulated_annealing,
        total_distance,
    )


class TSPSandboxWindow(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("TSP 沙箱可视化（模拟退火）")
        self.resize(1200, 720)

        self.output_dir = Path(__file__).parent

        self.coords: np.ndarray | None = None
        self.best_tour: np.ndarray | None = None
        self.distance_history: List[float] = []
        self.snapshots: List[np.ndarray] = []
        self.config: TSPConfig | None = None

        self._build_ui()
        self.run_simulation()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout()
        self.setLayout(root_layout)

        control_group = QGroupBox("仿真参数设置")
        control_layout = QFormLayout()
        control_group.setLayout(control_layout)

        self.city_spin = QSpinBox()
        self.city_spin.setRange(4, 40)
        self.city_spin.setValue(12)

        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(100, 10000)
        self.iter_spin.setSingleStep(100)
        self.iter_spin.setValue(1800)

        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setDecimals(2)
        self.temp_spin.setRange(0.1, 100.0)
        self.temp_spin.setSingleStep(0.5)
        self.temp_spin.setValue(10.0)

        self.cooling_spin = QDoubleSpinBox()
        self.cooling_spin.setDecimals(4)
        self.cooling_spin.setRange(0.9000, 0.9999)
        self.cooling_spin.setSingleStep(0.0005)
        self.cooling_spin.setValue(0.9950)

        control_layout.addRow("城市数量", self.city_spin)
        control_layout.addRow("迭代次数", self.iter_spin)
        control_layout.addRow("初始温度", self.temp_spin)
        control_layout.addRow("降温速率", self.cooling_spin)

        button_row = QHBoxLayout()
        self.run_button = QPushButton("运行仿真")
        self.run_button.clicked.connect(self.run_simulation)
        self.export_button = QPushButton("保存当前结果")
        self.export_button.clicked.connect(self.export_results)
        self.export_button.setEnabled(False)
        button_row.addWidget(self.run_button)
        button_row.addWidget(self.export_button)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.status_label.setStyleSheet("color: #d62728; font-weight: 600;")

        self.tour_canvas = FigureCanvas(Figure(figsize=(10, 4.5), tight_layout=True))
        self.tour_axes = self.tour_canvas.figure.subplots(1, 3)

        self.dist_canvas = FigureCanvas(Figure(figsize=(6, 4), tight_layout=True))
        self.dist_ax = self.dist_canvas.figure.add_subplot(111)

        self.summary_label = QLabel()
        self.summary_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet("font-family: Consolas, 'Source Code Pro', monospace;")

        bottom_layout = QHBoxLayout()
        bottom_layout.addWidget(self.tour_canvas, stretch=3)
        bottom_layout.addWidget(self.dist_canvas, stretch=2)

        summary_group = QGroupBox("结果摘要")
        summary_layout = QVBoxLayout()
        summary_layout.addWidget(self.summary_label)
        summary_group.setLayout(summary_layout)

        root_layout.addWidget(control_group)
        root_layout.addLayout(button_row)
        root_layout.addWidget(self.status_label)
        root_layout.addLayout(bottom_layout)
        root_layout.addWidget(summary_group)

    def run_simulation(self) -> None:
        city_count = self.city_spin.value()
        iterations = self.iter_spin.value()
        initial_temperature = self.temp_spin.value()
        cooling_rate = self.cooling_spin.value()

        self.config = TSPConfig(
            city_count=city_count,
            initial_temperature=initial_temperature,
            cooling_rate=cooling_rate,
            iterations=iterations,
        )

        self.coords = np.random.uniform(0, 5, size=(city_count, 2))
        self.best_tour, self.distance_history, self.snapshots = simulated_annealing(
            self.coords, self.config
        )

        if len(self.snapshots) < 3:
            self.snapshots = (
                self.snapshots
                + [self.snapshots[-1]] * (3 - len(self.snapshots))
                if self.snapshots
                else [np.arange(city_count)] * 3
            )

        self._update_tour_plots()
        self._update_distance_plot()
        self._update_summary()

        self.export_button.setEnabled(True)
        self.status_label.setText("仿真完成，可导出路径演化图、收敛曲线及摘要。")

    def export_results(self) -> None:
        if not (self.coords is not None and self.best_tour is not None and self.config):
            self.status_label.setText("暂无可导出的结果，请先运行仿真。")
            return

        plot_tours(
            coords=self.coords,
            tour_snapshots=self.snapshots,
            distance_history=self.distance_history,
            config=self.config,
            output_path=self.output_dir / "tsp_tour_evolution.png",
        )
        export_summary(
            summary_path=self.output_dir / "tsp_summary.txt",
            best_tour=self.best_tour,
            best_distance=total_distance(self.coords, self.best_tour),
            config=self.config,
        )
        self.status_label.setText(
            "结果已保存：tsp_tour_evolution.png、tsp_distance_curve.png、tsp_summary.txt"
        )

    def _update_tour_plots(self) -> None:
        if self.coords is None or not self.snapshots:
            self.tour_canvas.draw_idle()
            return

        titles = ["初始路径", "中期路径", "最终路径"]
        for ax, tour, title in zip(self.tour_axes, self.snapshots[:3], titles):
            ax.clear()
            ordered = self.coords[tour]
            ordered = np.vstack([ordered, ordered[0]])
            ax.plot(
                ordered[:, 0],
                ordered[:, 1],
                "-o",
                color="#1f77b4",
                linewidth=1.2,
                markersize=5,
            )
            for idx, (x, y) in enumerate(self.coords):
                ax.text(x + 0.03, y + 0.03, str(idx), fontsize=8)
            ax.set_title(f"{title}\n距离 = {total_distance(self.coords, tour):.2f}")
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_aspect("equal")
            ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.4)
        self.tour_canvas.draw_idle()

    def _update_distance_plot(self) -> None:
        if not self.distance_history:
            self.dist_canvas.draw_idle()
            return

        self.dist_ax.clear()
        self.dist_ax.plot(
            np.arange(len(self.distance_history)),
            self.distance_history,
            color="#d62728",
            linewidth=1.4,
        )
        self.dist_ax.set_xlabel("迭代步")
        self.dist_ax.set_ylabel("路径长度")
        self.dist_ax.set_title("路径长度收敛曲线")
        self.dist_ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)
        self.dist_canvas.draw_idle()

    def _update_summary(self) -> None:
        if not (self.config and self.best_tour is not None and self.coords is not None):
            self.summary_label.setText("")
            return

        best_distance = total_distance(self.coords, self.best_tour)
        lines = [
            "TSP 模拟退火仿真摘要",
            f"城市数量: {self.config.city_count}",
            f"迭代次数: {self.config.iterations}",
            f"初始温度: {self.config.initial_temperature:.2f}",
            f"降温速率: {self.config.cooling_rate:.4f}",
            f"最佳路径长度: {best_distance:.4f}",
            "",
            "最佳路径顺序:",
            " -> ".join(map(str, self.best_tour.tolist())) + f" -> {self.best_tour[0]}",
        ]
        self.summary_label.setText("\n".join(lines))


def main() -> None:
    app = QApplication(sys.argv)
    app.setFont(QFont("Microsoft YaHei"))
    window = TSPSandboxWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


