import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from collections import defaultdict
import csv



class BoltzmannMachine3N:
    def __init__(self, weights, biases, temperature=1.0):
        self.n_neurons = 3
        self.weights = np.array(weights, dtype=np.float32)
        assert self.weights.shape == (self.n_neurons, self.n_neurons), "权重矩阵需为3x3"
        assert np.allclose(self.weights, self.weights.T), "权重矩阵必须对称"
        assert np.allclose(np.diag(self.weights), 0), "自连接权重需为0"

        self.biases = np.array(biases, dtype=np.float32)
        assert self.biases.shape == (self.n_neurons,), "偏置需为3维向量"

        self.temperature = temperature
        self.beta = 1.0 / self.temperature
        self.state = np.random.randint(0, 2, size=self.n_neurons)

    def calculate_energy(self):
        interaction = 0.5 * np.dot(self.state.T, np.dot(self.weights, self.state))
        bias_term = np.dot(self.biases, self.state)
        return - (interaction + bias_term)

    def update_state(self):
        for i in range(self.n_neurons):
            input_sum = np.dot(self.weights[i, :], self.state) + self.biases[i]
            activate_prob = 1.0 / (1.0 + np.exp(-self.beta * input_sum))
            self.state[i] = 1 if np.random.random() < activate_prob else 0
        return self.state.copy()



weights = [[0, 1, 1], [1, 0, 1], [1, 1, 0]]
biases = [0, 0, 0]
temperature = 1.0
bm = BoltzmannMachine3N(weights, biases, temperature)


energy_history = []
iter_history = []
state_history = []
max_iter = 1000
state_counts = defaultdict(int)


fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('3-Neuron Boltzmann Machine (BM) Simulation', fontsize=16, fontweight='bold')


neuron_pos = np.array([[0, 0], [1, 0], [0.5, np.sqrt(3) / 2]])
state_colors = ['#2E86AB', '#E63946']
scatter = ax1.scatter(neuron_pos[:, 0], neuron_pos[:, 1],
                      c=[state_colors[s] for s in bm.state], s=800,
                      edgecolors='white', linewidths=5)

ax1.set_xlim(-0.6, 1.6)
ax1.set_ylim(-0.6, 1.6)
ax1.set_title('Neuron States\n(Blue=0, Red=1)', fontsize=14, pad=20)
ax1.set_xticks([])
ax1.set_yticks([])
for i in range(3):
    ax1.text(neuron_pos[i, 0], neuron_pos[i, 1], f'N{i + 1}',
             ha='center', va='center', fontsize=18, fontweight='bold', color='white')


line, = ax2.plot(iter_history, energy_history, color='#2E86AB', linewidth=3, alpha=0.8)
ax2.set_xlabel('Iteration', fontsize=12)
ax2.set_ylabel('Energy', fontsize=12)
ax2.set_title('System Energy Over Time', fontsize=14, pad=20)
ax2.grid(True, alpha=0.3, linestyle='--')
ax2.set_xlim(0, 100)
ax2.set_ylim(-4, 1)



def update_animation(frame):
    current_state = bm.update_state()
    current_energy = bm.calculate_energy()


    energy_history.append(current_energy)
    iter_history.append(frame)
    state_history.append(tuple(current_state))  # 保存每一步状态


    scatter.set_color([state_colors[s] for s in current_state])
    line.set_data(iter_history, energy_history)
    ax2.set_xlim(0, frame + 50)


    if frame >= max_iter // 2:
        state_key = tuple(current_state)
        state_counts[state_key] += 1

    return scatter, line



ani = FuncAnimation(fig, update_animation, frames=max_iter,
                    interval=50, blit=True, repeat=False)
plt.tight_layout()
plt.show()


print("=" * 60)
print("                     热平衡状态分析结果")
print("=" * 60)
total_samples = sum(state_counts.values())
print(f"统计样本数（热平衡阶段）：{total_samples}")
print(f"温度 T = {temperature}, β = {1 / temperature:.2f}")
print("\n各状态统计（按出现概率排序）：")
print("-" * 60)

print(f"{'状态':<12} {'出现次数':<10} {'概率':<10} {'能量':<10}")
print("-" * 60)


sorted_states = sorted(state_counts.items(), key=lambda x: x[1], reverse=True)
for state, count in sorted_states:
    bm.state = np.array(state)
    energy = bm.calculate_energy()
    prob = count / total_samples


    state_str = str(state).ljust(12)
    count_str = str(count).ljust(10)
    prob_str = f"{prob:.3f}".ljust(10)
    energy_str = f"{energy:.2f}".ljust(10)

    print(f"{state_str} {count_str} {prob_str} {energy_str}")


min_energy = float('inf')
min_energy_state = None
for state, _ in sorted_states:
    bm.state = np.array(state)
    current_energy = bm.calculate_energy()
    if current_energy < min_energy:
        min_energy = current_energy
        min_energy_state = state

max_prob_state = sorted_states[0]
max_prob = max_prob_state[1] / total_samples

print("-" * 60)
print("热平衡结论：")
print(f"1. 能量最低状态：{min_energy_state}，能量={min_energy:.2f}")
print(f"2. 出现概率最高状态：{max_prob_state[0]}，概率={max_prob:.3f}")
print(f"3. 热平衡核心状态：{max_prob_state[0]}（能量最低且概率最高）")
print("=" * 60)



csv_path = "../pythonProject/bm_thermal_equilibrium.csv"
with open(csv_path, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['状态', '出现次数', '概率', '能量', '温度T', 'β值'])
    for state, count in sorted_states:
        bm.state = np.array(state)
        energy = bm.calculate_energy()
        prob = count / total_samples
        writer.writerow([str(state), count, round(prob, 3), round(energy, 2), temperature, round(1 / temperature, 2)])


history_path = "../pythonProject/bm_iteration_history.csv"
with open(history_path, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['迭代次数', '神经元1状态', '神经元2状态', '神经元3状态', '系统能量'])
    for i, (state, energy) in enumerate(zip(state_history, energy_history)):
        writer.writerow([i, state[0], state[1], state[2], round(energy, 2)])

print(f"\n✅ 数据已保存到：{csv_path} 和 {history_path}")