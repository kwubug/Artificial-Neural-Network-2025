import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, ConnectionPatch
import random
import math
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体为 SimHei（黑体）
plt.rcParams['font.family'] = 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class TSPSolver:
    """
    Traveling Salesman Problem Solver

    Uses simulated annealing algorithm to solve TSP with visualization
    """

    def __init__(self, num_cities=20, map_size=100):
        """
        Initialize TSP problem

        Parameters:
            num_cities: number of cities
            map_size: map dimensions
        """
        self.num_cities = num_cities
        self.map_size = map_size
        self.cities = self.generate_cities()
        self.distance_matrix = self.calculate_distance_matrix()
        self.best_tour = None
        self.best_distance = float('inf')
        self.history = []  # Record search history

    def generate_cities(self):
        """Randomly generate city coordinates"""
        cities = []
        for _ in range(self.num_cities):
            x = random.uniform(0, self.map_size)
            y = random.uniform(0, self.map_size)
            cities.append((x, y))
        return cities

    def calculate_distance_matrix(self):
        """Calculate distance matrix between cities"""
        dist_matrix = np.zeros((self.num_cities, self.num_cities))
        for i in range(self.num_cities):
            for j in range(i + 1, self.num_cities):
                dx = self.cities[i][0] - self.cities[j][0]
                dy = self.cities[i][1] - self.cities[j][1]
                dist = math.sqrt(dx * dx + dy * dy)
                dist_matrix[i][j] = dist
                dist_matrix[j][i] = dist
        return dist_matrix

    def tour_distance(self, tour):
        """Calculate total tour distance"""
        total_distance = 0
        for i in range(len(tour)):
            from_city = tour[i]
            to_city = tour[(i + 1) % len(tour)]
            total_distance += self.distance_matrix[from_city][to_city]
        return total_distance

    def initial_solution(self):
        """Generate initial solution (random tour)"""
        tour = list(range(self.num_cities))
        random.shuffle(tour)
        return tour

    def get_neighbor(self, tour):
        """Generate neighbor solution (using 2-opt swap)"""
        new_tour = tour.copy()
        i, j = random.sample(range(self.num_cities), 2)
        i, j = min(i, j), max(i, j)
        new_tour[i:j + 1] = reversed(new_tour[i:j + 1])
        return new_tour

    def simulated_annealing(self, initial_temperature=1000, cooling_rate=0.995,
                            max_iterations=10000, plot_progress=True):
        """
        Solve TSP using simulated annealing

        Parameters:
            initial_temperature: initial temperature
            cooling_rate: cooling rate
            max_iterations: maximum iterations
            plot_progress: whether to plot progress

        Returns:
            best tour and distance
        """
        # Initialize
        current_tour = self.initial_solution()
        current_distance = self.tour_distance(current_tour)
        temperature = initial_temperature

        # Record best solution
        self.best_tour = current_tour.copy()
        self.best_distance = current_distance

        # Record search history
        self.history = []

        print("Starting simulated annealing...")
        print(f"Initial tour distance: {current_distance:.2f}")

        for iteration in range(max_iterations):
            # Generate neighbor solution
            new_tour = self.get_neighbor(current_tour)
            new_distance = self.tour_distance(new_tour)

            # Calculate energy difference
            delta_energy = new_distance - current_distance

            # Acceptance criterion
            if delta_energy < 0 or random.random() < math.exp(-delta_energy / temperature):
                current_tour = new_tour
                current_distance = new_distance

                # Update best solution
                if current_distance < self.best_distance:
                    self.best_tour = current_tour.copy()
                    self.best_distance = current_distance

            # Record history
            if iteration % 100 == 0:
                self.history.append({
                    'iteration': iteration,
                    'temperature': temperature,
                    'current_distance': current_distance,
                    'best_distance': self.best_distance,
                    'tour': current_tour.copy()
                })

            # Cooling
            temperature *= cooling_rate

            # Early termination
            if temperature < 1e-10:
                break

        print(f"Final tour distance: {self.best_distance:.2f}")
        print(f"Total iterations: {iteration}")

        if plot_progress:
            self.plot_optimization_progress()

        return self.best_tour, self.best_distance

    def plot_cities(self, ax=None):
        """Plot city distribution"""
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 8))

        x = [city[0] for city in self.cities]
        y = [city[1] for city in self.cities]

        ax.scatter(x, y, c='red', s=100, zorder=5)

        # Annotate city numbers
        for i, (x_pos, y_pos) in enumerate(self.cities):
            ax.annotate(str(i), (x_pos, y_pos), xytext=(5, 5),
                        textcoords='offset points', fontsize=12, zorder=6)

        ax.set_xlim(0, self.map_size)
        ax.set_ylim(0, self.map_size)
        ax.set_xlabel('X Coordinate')
        ax.set_ylabel('Y Coordinate')
        ax.set_title(f'TSP Problem - {self.num_cities} Cities Distribution')
        ax.grid(True, alpha=0.3)

        return ax

    def plot_tour(self, tour=None, ax=None, title="TSP Tour"):
        """Plot tour path"""
        if tour is None:
            tour = self.best_tour

        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 8))

        # Plot cities
        self.plot_cities(ax)

        # Plot tour path
        for i in range(len(tour)):
            from_city = tour[i]
            to_city = tour[(i + 1) % len(tour)]

            from_x, from_y = self.cities[from_city]
            to_x, to_y = self.cities[to_city]

            ax.plot([from_x, to_x], [from_y, to_y], 'b-', linewidth=2, alpha=0.7)

        distance = self.tour_distance(tour)
        ax.set_title(f'{title}\nTour Length: {distance:.2f}')

        return ax

    def plot_optimization_progress(self):
        """Plot optimization progress"""
        if not self.history:
            print("No history data to plot")
            return

        iterations = [h['iteration'] for h in self.history]
        current_distances = [h['current_distance'] for h in self.history]
        best_distances = [h['best_distance'] for h in self.history]
        temperatures = [h['temperature'] for h in self.history]

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

        # Plot distance evolution
        ax1.plot(iterations, current_distances, 'b-', alpha=0.7, label='Current Distance')
        ax1.plot(iterations, best_distances, 'r-', linewidth=2, label='Best Distance')
        ax1.set_xlabel('Iteration')
        ax1.set_ylabel('Tour Distance')
        ax1.set_title('Simulated Annealing Optimization Progress')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # Plot temperature evolution
        ax2.semilogy(iterations, temperatures, 'g-')
        ax2.set_xlabel('Iteration')
        ax2.set_ylabel('Temperature (log scale)')
        ax2.set_title('Annealing Temperature Evolution')
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def create_animation(self, save_path=None, fps=10):
        """Create optimization process animation"""
        if not self.history:
            print("No history data to create animation")
            return

        # Setup figure
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Initialize
        def init():
            ax1.clear()
            ax2.clear()
            return []

        # Animation update function
        def update(frame):
            ax1.clear()
            ax2.clear()

            # Get current frame data
            data = self.history[frame]
            iteration = data['iteration']
            tour = data['tour']
            current_distance = data['current_distance']
            best_distance = data['best_distance']
            temperature = data['temperature']

            # Plot current tour
            self.plot_tour(tour, ax=ax1, title=f'Iteration {iteration}')

            # Plot optimization progress
            iterations = [h['iteration'] for h in self.history[:frame + 1]]
            current_distances = [h['current_distance'] for h in self.history[:frame + 1]]
            best_distances = [h['best_distance'] for h in self.history[:frame + 1]]

            ax2.plot(iterations, current_distances, 'b-', alpha=0.7, label='Current Distance')
            ax2.plot(iterations, best_distances, 'r-', linewidth=2, label='Best Distance')
            ax2.axhline(y=best_distance, color='r', linestyle='--', alpha=0.5)
            ax2.set_xlabel('Iteration')
            ax2.set_ylabel('Tour Distance')
            ax2.set_title(f'Optimization Progress (Temperature: {temperature:.2f})')
            ax2.legend()
            ax2.grid(True, alpha=0.3)

            return []

        # Create animation
        anim = animation.FuncAnimation(
            fig, update, frames=len(self.history),
            init_func=init, blit=False, repeat=False, interval=1000 / fps
        )

        # Save or display animation
        if save_path:
            anim.save(save_path, writer='pillow', fps=fps)
            print(f"Animation saved to: {save_path}")
        else:
            plt.show()

        return anim


def compare_algorithms():
    """Compare different algorithms on TSP problem"""
    # Create same problem instance
    num_cities = 15
    map_size = 100

    # Generate fixed city coordinates for fair comparison
    random.seed(42)
    cities = []
    for _ in range(num_cities):
        x = random.uniform(0, map_size)
        y = random.uniform(0, map_size)
        cities.append((x, y))

    # Test different algorithms
    algorithms = [
        ("Random Search", random_search),
        ("Greedy Algorithm", greedy_algorithm),
        ("Simulated Annealing", simulated_annealing_wrapper)
    ]

    results = []

    for name, algorithm in algorithms:
        print(f"\n=== {name} ===")

        # Create solver instance
        solver = TSPSolver(num_cities, map_size)
        solver.cities = cities.copy()  # Use same city distribution
        solver.distance_matrix = solver.calculate_distance_matrix()

        # Run algorithm
        if name == "Simulated Annealing":
            tour, distance = algorithm(solver, max_iterations=5000)
        else:
            tour, distance = algorithm(solver)

        results.append((name, tour, distance))

        # Plot results
        plt.figure(figsize=(8, 6))
        solver.plot_tour(tour, title=f'{name} - Tour Length: {distance:.2f}')
        plt.show()

    # Compare results
    print("\n=== Algorithm Comparison ===")
    for name, tour, distance in results:
        print(f"{name}: {distance:.2f}")

    # Plot comparison chart
    names = [r[0] for r in results]
    distances = [r[2] for r in results]

    plt.figure(figsize=(10, 6))
    bars = plt.bar(names, distances, color=['skyblue', 'lightgreen', 'lightcoral'])
    plt.ylabel('Tour Length')
    plt.title('Performance of Different Algorithms on TSP')

    # Add value labels on bars
    for bar, distance in zip(bars, distances):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 5,
                 f'{distance:.2f}', ha='center', va='bottom')

    plt.grid(True, alpha=0.3, axis='y')
    plt.show()


def random_search(solver, max_iterations=10000):
    """Random search algorithm"""
    best_tour = None
    best_distance = float('inf')

    for _ in range(max_iterations):
        tour = solver.initial_solution()
        distance = solver.tour_distance(tour)

        if distance < best_distance:
            best_tour = tour
            best_distance = distance

    return best_tour, best_distance


def greedy_algorithm(solver):
    """Greedy algorithm (nearest neighbor)"""
    unvisited = set(range(solver.num_cities))
    tour = []

    # Start from random city
    current_city = random.choice(list(unvisited))
    tour.append(current_city)
    unvisited.remove(current_city)

    while unvisited:
        # Find nearest unvisited city
        nearest_city = None
        min_distance = float('inf')

        for city in unvisited:
            distance = solver.distance_matrix[current_city][city]
            if distance < min_distance:
                min_distance = distance
                nearest_city = city

        tour.append(nearest_city)
        unvisited.remove(nearest_city)
        current_city = nearest_city

    distance = solver.tour_distance(tour)
    return tour, distance


def simulated_annealing_wrapper(solver, max_iterations=10000):
    """Simulated annealing wrapper"""
    return solver.simulated_annealing(
        initial_temperature=1000,
        cooling_rate=0.995,
        max_iterations=max_iterations,
        plot_progress=False
    )


def analyze_problem_characteristics(solver):
    """Analyze TSP problem characteristics"""
    print("=== Problem Characteristics Analysis ===")

    # Calculate average, min and max distances
    distances = []
    for i in range(solver.num_cities):
        for j in range(i + 1, solver.num_cities):
            distances.append(solver.distance_matrix[i][j])

    avg_distance = np.mean(distances)
    min_distance = np.min(distances)
    max_distance = np.max(distances)

    print(f"Number of cities: {solver.num_cities}")
    print(f"Average inter-city distance: {avg_distance:.2f}")
    print(f"Minimum inter-city distance: {min_distance:.2f}")
    print(f"Maximum inter-city distance: {max_distance:.2f}")
    print(f"Map size: {solver.map_size} x {solver.map_size}")

    # Plot distance distribution histogram
    plt.figure(figsize=(10, 6))
    plt.hist(distances, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
    plt.axvline(avg_distance, color='red', linestyle='--', linewidth=2, label=f'Average: {avg_distance:.2f}')
    plt.xlabel('Inter-city Distance')
    plt.ylabel('Frequency')
    plt.title('Inter-city Distance Distribution')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()


# Example usage
if __name__ == "__main__":
    print("=== TSP Problem Visualization Solution ===")

    # Create TSP problem instance
    tsp_solver = TSPSolver(num_cities=20, map_size=100)

    # Plot city distribution
    print("\n1. City Distribution Plot")
    tsp_solver.plot_cities()
    plt.show()

    # Solve using simulated annealing
    print("\n2. Simulated Annealing Process")
    best_tour, best_distance = tsp_solver.simulated_annealing(
        initial_temperature=1000,
        cooling_rate=0.995,
        max_iterations=10000
    )

    # Plot final tour
    print("\n3. Optimal Tour Visualization")
    tsp_solver.plot_tour(best_tour, title="Optimal Tour")
    plt.show()

    # Create optimization animation (optional)
    print("\n4. Generating Optimization Animation")
    # Note: May not be able to save animation files in sandbox environment
    # tsp_solver.create_animation("tsp_optimization.gif", fps=5)

    # Algorithm comparison
    print("\n5. Algorithm Performance Comparison")
    compare_algorithms()

    # Problem analysis
    print("\n6. Problem Characteristics Analysis")
    analyze_problem_characteristics(tsp_solver)