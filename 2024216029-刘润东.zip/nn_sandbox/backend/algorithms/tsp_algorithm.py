import numpy as np
import threading
import time


class TspAlgorithm(threading.Thread):
    """
    使用神经网络方法求解TSP问题
    使用自组织映射(SOM)的思想来求解旅行商问题
    """
    
    def __init__(self, cities, num_neurons=None, learning_rate=0.8, 
                 max_iterations=1000, neighborhood_size=None):
        """
        初始化TSP求解器
        
        Args:
            cities: 城市坐标列表 [[x1, y1], [x2, y2], ...]
            num_neurons: 神经元数量（通常是城市数量的2-3倍）
            learning_rate: 学习率
            max_iterations: 最大迭代次数
            neighborhood_size: 邻域大小
        """
        super().__init__()
        self.cities = np.array(cities)
        self.num_cities = len(cities)
        
        # 默认神经元数量是城市数量的2.5倍
        if num_neurons is None:
            num_neurons = int(self.num_cities * 2.5)
        self.num_neurons = num_neurons
        
        # 默认邻域大小
        if neighborhood_size is None:
            neighborhood_size = max(1, self.num_neurons // 10)
        self.initial_neighborhood_size = neighborhood_size
        
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self._should_stop = False
        
        # 初始化神经元环（围绕城市中心的圆圈）
        self._initialize_neurons()
        
        # 记录历史
        self.current_iteration = 0
        self.current_tour_length = float('inf')
        self.best_tour_length = float('inf')
        self.best_tour = None
        self.tour_length_history = []
        
    def _initialize_neurons(self):
        """初始化神经元为围绕城市中心的圆圈"""
        # 计算城市中心和半径
        center = np.mean(self.cities, axis=0)
        max_dist = np.max(np.linalg.norm(self.cities - center, axis=1))
        radius = max_dist * 0.8
        
        # 在圆圈上均匀分布神经元
        angles = np.linspace(0, 2 * np.pi, self.num_neurons, endpoint=False)
        self.neurons = np.column_stack([
            center[0] + radius * np.cos(angles),
            center[1] + radius * np.sin(angles)
        ])
        
    def run(self):
        """运行SOM算法求解TSP"""
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 随机选择一个城市
            city_idx = np.random.randint(0, self.num_cities)
            city = self.cities[city_idx]
            
            # 找到最近的神经元（获胜者）
            winner_idx = self._find_winner(city)
            
            # 更新获胜者及其邻域
            self._update_neurons(winner_idx, city)
            
            # 计算当前路径长度
            self.current_tour_length = self._calculate_tour_length()
            self.tour_length_history.append(self.current_tour_length)
            
            # 更新最佳路径
            if self.current_tour_length < self.best_tour_length:
                self.best_tour_length = self.current_tour_length
                self.best_tour = self._get_tour()
            
            # 添加延迟以便可视化
            time.sleep(0.02)
        
        # 确保有最佳路径
        if self.best_tour is None:
            self.best_tour = self._get_tour()
            
    def _find_winner(self, city):
        """找到最接近给定城市的神经元"""
        distances = np.linalg.norm(self.neurons - city, axis=1)
        return np.argmin(distances)
    
    def _update_neurons(self, winner_idx, city):
        """更新获胜神经元及其邻域"""
        # 计算当前邻域大小（随时间衰减）
        progress = self.current_iteration / self.max_iterations
        current_neighborhood = max(1, int(
            self.initial_neighborhood_size * (1 - progress)
        ))
        current_lr = self.learning_rate * (1 - progress)
        
        # 更新邻域内的神经元
        for i in range(self.num_neurons):
            # 计算环形距离
            distance = min(
                abs(i - winner_idx),
                self.num_neurons - abs(i - winner_idx)
            )
            
            if distance <= current_neighborhood:
                # 计算影响因子（高斯型）
                influence = np.exp(-(distance ** 2) / (2 * (current_neighborhood ** 2)))
                
                # 更新神经元位置
                self.neurons[i] += current_lr * influence * (city - self.neurons[i])
    
    def _get_tour(self):
        """
        根据当前神经元位置构建TSP路径
        为每个城市分配最近的神经元，然后按神经元顺序排列城市
        """
        # 为每个城市找到最近的神经元
        city_to_neuron = []
        for i, city in enumerate(self.cities):
            winner = self._find_winner(city)
            city_to_neuron.append((i, winner))
        
        # 按神经元索引排序
        city_to_neuron.sort(key=lambda x: x[1])
        
        # 提取城市顺序
        tour = [city_idx for city_idx, _ in city_to_neuron]
        
        return tour
    
    def _calculate_tour_length(self):
        """计算当前路径的总长度"""
        tour = self._get_tour()
        if not tour:
            return float('inf')
        
        length = 0
        for i in range(len(tour)):
            city1 = self.cities[tour[i]]
            city2 = self.cities[tour[(i + 1) % len(tour)]]
            length += np.linalg.norm(city1 - city2)
        
        return length
    
    def stop(self):
        """停止算法运行"""
        self._should_stop = True
    
    def get_statistics(self):
        """返回统计信息"""
        return {
            'neurons': self.neurons.tolist(),
            'cities': self.cities.tolist(),
            'current_tour': self._get_tour(),
            'best_tour': self.best_tour if self.best_tour else [],
            'current_tour_length': float(self.current_tour_length),
            'best_tour_length': float(self.best_tour_length)
        }


class ObservableTspAlgorithm(TspAlgorithm):
    """Observable版本的TSP算法，用于与Bridge集成"""
    
    def __init__(self, observer, cities, num_neurons=None, learning_rate=0.8,
                 max_iterations=1000, neighborhood_size=None):
        TspAlgorithm.__init__(self, cities, num_neurons, learning_rate,
                             max_iterations, neighborhood_size)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            self._observer.update(name, value)
        
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_tour_length', 'best_tour_length']:
            if hasattr(self, '_observer'):
                self.notify(name, value)
                
    def run(self):
        """重写run方法以添加通知"""
        # 发送初始状态
        print("[Python Algorithm] Sending initial statistics")
        self.notify('statistics', self.get_statistics())
        print("[Python Algorithm] Initial statistics sent")
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            city_idx = np.random.randint(0, self.num_cities)
            city = self.cities[city_idx]
            
            winner_idx = self._find_winner(city)
            self._update_neurons(winner_idx, city)
            
            self.current_tour_length = self._calculate_tour_length()
            self.tour_length_history.append(self.current_tour_length)
            
            if self.current_tour_length < self.best_tour_length:
                self.best_tour_length = self.current_tour_length
                self.best_tour = self._get_tour()
            
            # 每次都通知统计信息以确保可视化流畅
            if self.current_iteration % 10 == 0:  # 每10次打印一次，避免刷屏
                print(f"[Python Algorithm] Iteration {self.current_iteration}: notifying statistics")
            self.notify('statistics', self.get_statistics())
            
            time.sleep(0.05)  # 增加延迟以便观察
        
        if self.best_tour is None:
            self.best_tour = self._get_tour()
        
        # 最后通知一次
        self.notify('statistics', self.get_statistics())

