import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import seaborn as sns

plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei']
class SOM:
    def __init__(self, grid_size=(5, 5), input_dim=4, learning_rate=0.5, radius=2):
        """
        初始化SOM网络

        参数:
        grid_size: 输出层网格大小 (rows, cols)
        input_dim: 输入维度
        learning_rate: 初始学习率
        radius: 初始邻域半径
        """
        self.grid_size = grid_size
        self.input_dim = input_dim
        self.learning_rate = learning_rate
        self.radius = radius

        # 初始化权重矩阵 (5x5x4)
        self.weights = np.random.randn(grid_size[0], grid_size[1], input_dim) * 0.1

        # 创建网格坐标
        self.grid_coords = np.array([[i, j] for i in range(grid_size[0]) for j in range(grid_size[1])])
        self.grid_coords = self.grid_coords.reshape(grid_size[0], grid_size[1], 2)

        # 记录训练历史
        self.weights_history = []
        self.winning_neurons_history = []

    def find_bmu(self, x):
        """
        寻找最佳匹配单元(BMU)

        参数:
        x: 输入向量

        返回:
        bmu: BMU的坐标 (row, col)
        """
        # 计算所有神经元与输入向量的距离
        distances = np.linalg.norm(self.weights - x, axis=2)
        # 找到距离最小的神经元
        bmu_index = np.unravel_index(np.argmin(distances), distances.shape)
        return bmu_index

    def neighborhood_function(self, bmu_pos, current_radius):
        """
        计算邻域函数

        参数:
        bmu_pos: BMU位置
        current_radius: 当前邻域半径

        返回:
        neighborhood: 邻域影响矩阵
        """
        # 计算所有神经元到BMU的距离
        distances = np.linalg.norm(self.grid_coords - np.array(bmu_pos), axis=2)

        # 高斯邻域函数
        neighborhood = np.exp(-distances ** 2 / (2 * current_radius ** 2))

        return neighborhood

    def update_weights(self, x, bmu_pos, current_lr, current_radius):
        """
        更新权重

        参数:
        x: 输入向量
        bmu_pos: BMU位置
        current_lr: 当前学习率
        current_radius: 当前邻域半径
        """
        # 计算邻域影响
        neighborhood = self.neighborhood_function(bmu_pos, current_radius)

        # 更新权重
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                influence = neighborhood[i, j]
                self.weights[i, j] += current_lr * influence * (x - self.weights[i, j])

    def train(self, data, total_steps=10000, save_interval=200):
        """
        训练SOM网络

        参数:
        data: 训练数据
        total_steps: 总训练步数
        save_interval: 保存间隔
        """
        n_samples = len(data)

        print("开始训练SOM网络...")
        print(f"网格大小: {self.grid_size}")
        print(f"输入维度: {self.input_dim}")
        print(f"总训练步数: {total_steps}")
        print(f"保存间隔: {save_interval}")

        for step in range(total_steps):
            # 选择随机样本
            sample_idx = np.random.randint(n_samples)
            x = data[sample_idx]

            # 计算当前学习率和邻域半径
            if step < 1000:
                current_lr = 0.5 - (0.5 - 0.04) * (step / 1000)
                current_radius = 2 - 2 * (step / 1000)
            else:
                current_lr = 0.04 * (1 - (step - 1000) / (total_steps - 1000))
                current_radius = 0

            # 找到BMU
            bmu_pos = self.find_bmu(x)

            # 更新权重
            self.update_weights(x, bmu_pos, current_lr, current_radius)

            # 记录训练历史
            if step % save_interval == 0 or step == total_steps - 1:
                self.weights_history.append(self.weights.copy())
                winning_neurons = []
                for sample in data:
                    bmu = self.find_bmu(sample)
                    winning_neurons.append(bmu)
                self.winning_neurons_history.append(winning_neurons)

                if step % 1000 == 0:
                    print(f"步骤 {step}: 学习率={current_lr:.4f}, 半径={current_radius:.4f}")

        print("训练完成!")

    def plot_training_process(self, data, pattern_names):
        """
        绘制训练过程
        """
        n_snapshots = len(self.weights_history)

        fig, axes = plt.subplots(2, (n_snapshots + 1) // 2, figsize=(20, 8))
        axes = axes.flatten()

        for i, (weights, winning_neurons) in enumerate(zip(self.weights_history, self.winning_neurons_history)):
            ax = axes[i]

            # 绘制权重向量的第一个分量作为背景
            weight_component = weights[:, :, 0]
            im = ax.imshow(weight_component, cmap='viridis', alpha=0.7)

            # 标记获胜神经元
            for j, (row, col) in enumerate(winning_neurons):
                ax.scatter(col, row, s=100, marker='o', edgecolors='red', facecolors='none', linewidths=2)
                ax.text(col, row, pattern_names[j], ha='center', va='center',
                        fontsize=8, fontweight='bold', color='red')

            ax.set_title(f'训练步数: {i * 200}')
            ax.set_xlabel('列')
            ax.set_ylabel('行')
            ax.grid(True, alpha=0.3)

        # 移除多余的子图
        for i in range(n_snapshots, len(axes)):
            fig.delaxes(axes[i])

        plt.tight_layout()
        plt.show()

    def plot_final_map(self, data, pattern_names):
        """
        绘制最终映射图
        """
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # 子图1: 权重分量可视化
        weight_component = self.weights[:, :, 0]
        im = ax1.imshow(weight_component, cmap='viridis')
        plt.colorbar(im, ax=ax1, label='权重值')

        # 标记所有输入模式的BMU
        winning_neurons = []
        for i, sample in enumerate(data):
            bmu = self.find_bmu(sample)
            winning_neurons.append(bmu)
            row, col = bmu
            ax1.scatter(col, row, s=200, marker='s', edgecolors='red',
                        facecolors='none', linewidths=3)
            ax1.text(col, row, pattern_names[i], ha='center', va='center',
                     fontsize=12, fontweight='bold', color='red')

        ax1.set_title('SOM最终映射图\n(红色方块表示输入模式的BMU)')
        ax1.set_xlabel('列索引')
        ax1.set_ylabel('行索引')
        ax1.grid(True, alpha=0.3)

        # 子图2: U-Matrix可视化
        u_matrix = self.calculate_umat()
        im2 = ax2.imshow(u_matrix, cmap='hot_r')
        plt.colorbar(im2, ax=ax2, label='距离')

        # 在U-Matrix上标记BMU
        for i, (row, col) in enumerate(winning_neurons):
            ax2.scatter(col, row, s=200, marker='s', edgecolors='blue',
                        facecolors='none', linewidths=3)
            ax2.text(col, row, pattern_names[i], ha='center', va='center',
                     fontsize=12, fontweight='bold', color='blue')

        ax2.set_title('U-Matrix可视化\n(显示神经元间的距离)')
        ax2.set_xlabel('列索引')
        ax2.set_ylabel('行索引')
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

        return winning_neurons

    def calculate_umat(self):
        """
        计算U-Matrix
        """
        u_matrix = np.zeros(self.grid_size)

        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                distances = []
                # 检查相邻神经元
                for di in [-1, 0, 1]:
                    for dj in [-1, 0, 1]:
                        if di == 0 and dj == 0:
                            continue
                        ni, nj = i + di, j + dj
                        if 0 <= ni < self.grid_size[0] and 0 <= nj < self.grid_size[1]:
                            dist = np.linalg.norm(self.weights[i, j] - self.weights[ni, nj])
                            distances.append(dist)

                if distances:
                    u_matrix[i, j] = np.mean(distances)

        return u_matrix

    def analyze_mapping(self, data, pattern_names):
        """
        分析映射结果
        """
        print("\n" + "=" * 50)
        print("映射结果分析")
        print("=" * 50)

        winning_neurons = []
        distances = []

        for i, (sample, name) in enumerate(zip(data, pattern_names)):
            bmu = self.find_bmu(sample)
            winning_neurons.append(bmu)
            dist = np.linalg.norm(self.weights[bmu] - sample)
            distances.append(dist)

            print(f"{name}: BMU位置={bmu}, 量化误差={dist:.4f}")

        # 检查是否有冲突映射（多个模式映射到同一个神经元）
        unique_neurons = set(winning_neurons)
        if len(unique_neurons) < len(data):
            print(f"\n警告: 有{len(data) - len(unique_neurons)}个冲突映射!")
        else:
            print(f"\n所有输入模式都映射到了不同的神经元!")

        return winning_neurons, distances


def main():
    # 设置随机种子以便重现结果
    np.random.seed(42)

    # 定义输入模式
    X1 = np.array([1, 0, 0, 0])
    X2 = np.array([1, 1, 0, 0])
    X3 = np.array([1, 1, 1, 0])
    X4 = np.array([0, 1, 0, 0])
    X5 = np.array([1, 1, 1, 1])

    data = np.array([X1, X2, X3, X4, X5])
    pattern_names = ['X1', 'X2', 'X3', 'X4', 'X5']

    print("输入模式:")
    for i, (pattern, name) in enumerate(zip(data, pattern_names)):
        print(f"{name}: {pattern}")

    # 创建SOM网络
    som = SOM(grid_size=(5, 5), input_dim=4, learning_rate=0.5, radius=2)

    # 训练网络
    som.train(data, total_steps=10000, save_interval=200)

    # 分析映射结果
    winning_neurons, distances = som.analyze_mapping(data, pattern_names)

    # 绘制训练过程
    print("\n绘制训练过程...")
    som.plot_training_process(data, pattern_names)

    # 绘制最终映射图
    print("绘制最终映射图...")
    som.plot_final_map(data, pattern_names)

    # 显示权重向量的详细信息
    print("\n最终权重向量:")
    for i in range(5):
        for j in range(5):
            print(f"神经元({i},{j}): {som.weights[i, j]}")

    # 显示每个输入模式对应的BMU权重
    print("\n各输入模式对应的BMU权重:")
    for i, (sample, name) in enumerate(zip(data, pattern_names)):
        bmu = winning_neurons[i]
        bmu_weights = som.weights[bmu]
        print(f"{name} -> 神经元{bmu}:")
        print(f"  输入: {sample}")
        print(f"  BMU权重: {bmu_weights}")
        print(f"  差异: {np.abs(sample - bmu_weights)}")


if __name__ == "__main__":
    main()