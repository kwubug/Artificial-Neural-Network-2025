from PyQt5.QtCore import pyqtSlot
from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.tsp_algorithm import ObservableTspAlgorithm
import json


class TspBridge(Bridge):
    """
    TSP求解器的Bridge类
    连接TSP算法和QML界面
    """
    
    # 定义Bridge属性
    current_iteration = BridgeProperty(0)
    current_tour_length = BridgeProperty(0.0)
    best_tour_length = BridgeProperty(float('inf'))
    statistics = BridgeProperty({})
    is_running = BridgeProperty(False)
    
    def __init__(self):
        super().__init__()
        self.algorithm = None
        
    @pyqtSlot(str, int, float, int, int)
    def start(self, cities_json, num_neurons, learning_rate_percent, 
             max_iterations, neighborhood_size):
        """
        启动TSP算法
        
        Args:
            cities_json: JSON字符串形式的城市坐标列表
            num_neurons: 神经元数量
            learning_rate_percent: 学习率（百分比形式）
            max_iterations: 最大迭代次数
            neighborhood_size: 邻域大小
        """
        if self.algorithm and self.algorithm.is_alive():
            self.algorithm.stop()
            self.algorithm.join()
        
        # 解析城市坐标
        try:
            cities = json.loads(cities_json)
        except:
            # 默认城市
            cities = [[0, 0], [1, 3], [4, 3], [6, 1], [3, 0]]
        
        learning_rate = learning_rate_percent / 100.0
        
        self.algorithm = ObservableTspAlgorithm(
            observer=self,
            cities=cities,
            num_neurons=num_neurons if num_neurons > 0 else None,
            learning_rate=learning_rate,
            max_iterations=max_iterations,
            neighborhood_size=neighborhood_size if neighborhood_size > 0 else None
        )
        self.is_running = True
        self.best_tour_length = float('inf')
        
        # 立即发送初始统计信息以显示初始状态
        initial_stats = self.algorithm.get_statistics()
        print(f"[Python Bridge] Initial statistics: cities={len(initial_stats['cities'])}, neurons={len(initial_stats['neurons'])}")
        self.statistics = initial_stats
        print(f"[Python Bridge] Statistics property set, type={type(self.statistics)}")
        
        self.algorithm.start()
        print("[Python Bridge] Algorithm started")
        
    @pyqtSlot()
    def stop(self):
        """停止TSP算法"""
        if self.algorithm:
            self.algorithm.stop()
            self.is_running = False

