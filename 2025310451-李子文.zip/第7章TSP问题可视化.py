# -*- coding: utf-8 -*-
"""
连续型 Hopfield–Tank 网络求解 TSP —— 动态可视化版（带开始按钮）
- 子图1：优化前路径（静态）
- 子图2：优化过程路径（动态，随迭代更新）
- 子图3：能量函数变化曲线（动态）
- 新增：右下角“开始计算”按钮；不点击不运行
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib import gridspec
from matplotlib.animation import FuncAnimation
from matplotlib.widgets import Button  # <<< 新增

# =========================
# 中文绘图环境修复（避免中文方框）
# =========================
def setup_chinese_fonts():
    candidates = [
        "Microsoft YaHei", "SimHei", "PingFang SC", "Noto Sans CJK SC",
        "WenQuanYi Micro Hei", "Source Han Sans SC", "Arial Unicode MS"
    ]
    available_names = set(f.name for f in fm.fontManager.ttflist)
    chosen = None
    for name in candidates:
        if name in available_names:
            chosen = name
            break
    plt.rcParams["axes.unicode_minus"] = False  # 负号正常显示
    if chosen:
        plt.rcParams["font.sans-serif"] = [chosen]
        return True, chosen
    return False, None

HAS_CJK, CHOSEN_FONT = setup_chinese_fonts()

# =========================
# 工具函数
# =========================
def euclidean_distance_matrix(points):
    diff = points[:, None, :] - points[None, :, :]
    return np.sqrt(np.sum(diff**2, axis=2))

def tour_length(points, perm):
    n = len(perm)
    s = 0.0
    for i in range(n):
        a = perm[i]
        b = perm[(i + 1) % n]
        s += np.linalg.norm(points[a] - points[b])
    return float(s)

def greedy_assignment_from_V(V):
    """
    将连续输出 V (n x n) 贪心离散化为合法排列：
    每列（位置）选一个最大值，且不重复城市。
    """
    n = V.shape[0]
    Vw = V.copy()
    perm = np.full(n, -1, dtype=int)
    used_city, used_pos = set(), set()
    NEG = -1e9
    while len(used_pos) < n:
        r, c = np.unravel_index(np.argmax(Vw), Vw.shape)
        if (r not in used_city) and (c not in used_pos):
            perm[c] = r
            used_city.add(r)
            used_pos.add(c)
            Vw[r, :] = NEG
            Vw[:, c] = NEG
        else:
            Vw[r, c] = NEG
    return perm

# =========================
# Hopfield–Tank TSP 网络
# =========================
class HopfieldTankTSP:
    """
    能量包含：
      A：行唯一（每个城市仅出现一次）
      B：列唯一（每个位置仅被占一次）
      C：总激活量约束 sum(V)=n
      D：邻位距离项
    """
    def __init__(self, points, A=500.0, B=500.0, C=500.0, D=500.0,
                 tau=1.0, dt=0.01, gain=3.0, steps=2500, seed=0):
        self.points = points
        self.n = points.shape[0]
        self.A, self.B, self.C, self.D = A, B, C, D
        self.tau, self.dt, self.gain, self.steps = tau, dt, gain, steps
        self.rng = np.random.default_rng(seed)

        Dmat = euclidean_distance_matrix(points)
        Dmax = np.max(Dmat) if np.max(Dmat) > 0 else 1.0
        self.Dmat = Dmat / Dmax  # 距离归一化，增强数值稳定性

        # 初始状态
        self.u = 0.1 * self.rng.standard_normal((self.n, self.n))
        self.V = self.activation(self.u)
        self.energy_hist = []

    def activation(self, u):
        # Sigmoid in (0,1)
        return 0.5 * (1.0 + np.tanh(self.gain * u))

    def energy(self):
        V = self.V
        n = self.n
        row_sums = V.sum(axis=1, keepdims=True)
        col_sums = V.sum(axis=0, keepdims=True)
        total = V.sum()

        # 行唯一性
        term1 = 0.5 * self.A * np.sum((row_sums**2 - (V**2).sum(axis=1, keepdims=True)))
        # 列唯一性
        term2 = 0.5 * self.B * np.sum((col_sums**2 - (V**2).sum(axis=0, keepdims=True)))
        # 总激活量
        term3 = 0.5 * self.C * (total - n) ** 2
        # 距离项（与前后相邻位置的耦合）
        V_plus = np.roll(V, -1, axis=1)
        V_minus = np.roll(V, 1, axis=1)
        DVp = self.Dmat @ V_plus
        DVm = self.Dmat @ V_minus
        term4 = 0.5 * self.D * np.sum(V * (DVp + DVm))

        return float(term1 + term2 + term3 + term4)

    def step(self):
        V, u = self.V, self.u
        row_sum = V.sum(axis=1, keepdims=True)
        col_sum = V.sum(axis=0, keepdims=True)
        total_sum = V.sum()

        V_plus = np.roll(V, -1, axis=1)
        V_minus = np.roll(V, 1, axis=1)
        DVp = self.Dmat @ V_plus
        DVm = self.Dmat @ V_minus

        du = (
            -u / self.tau
            - self.A * (row_sum - V)
            - self.B * (col_sum - V)
            - self.C * (total_sum - self.n)
            - self.D * (DVp + DVm)
        )
        u = u + self.dt * du
        V = self.activation(u)
        self.u, self.V = u, V
        self.energy_hist.append(self.energy())

    def extract_tour(self):
        return greedy_assignment_from_V(self.V)

# =========================
# 主程序（单画布三子图 + 动画）
# =========================
def main():
    # ---------------------
    # 可调参数（保持你现有设置）
    # ---------------------
    n_cities = 20
    seed = 42
    total_steps = 400      # 按你当前代码
    update_every = 1       # 按你当前代码
    interval_ms = 30       # 按你当前代码

    rng = np.random.default_rng(seed)
    cities = rng.random((n_cities, 2))  # [0,1]^2 随机城市
    initial_perm = rng.permutation(n_cities)

    # 初始化网络
    net = HopfieldTankTSP(
        cities,
        A=500.0, B=500.0, C=500.0, D=500.0,
        tau=1.0, dt=0.01, gain=3.0,
        steps=total_steps, seed=seed
    )

    # ---------------------
    # 先搭好三子图
    # ---------------------
    L0 = tour_length(cities, initial_perm)
    title_before = f"优化前路径（长度={L0:.3f}）" if HAS_CJK else f"Before Optimization (Len={L0:.3f})"
    title_after_fmt = "迭代 {it}/{tot}，当前长度={L:.3f}" if HAS_CJK else "Optimizing: step {it}/{tot}, len={L:.3f}"
    title_energy = "能量函数变化曲线" if HAS_CJK else "Energy Function vs Iterations"
    xlabel_energy = "迭代步" if HAS_CJK else "Iterations"
    ylabel_energy = "能量" if HAS_CJK else "Energy"

    fig = plt.figure(figsize=(12, 8))
    gs = gridspec.GridSpec(2, 2, height_ratios=[1.0, 1.1])

    # 子图1：优化前（静态）
    ax1 = fig.add_subplot(gs[0, 0])
    xs = cities[initial_perm, 0]; ys = cities[initial_perm, 1]
    xs = np.append(xs, xs[0]); ys = np.append(ys, ys[0])
    line1, = ax1.plot(xs, ys, marker='o')
    ax1.set_title(title_before)
    ax1.set_xlabel("x"); ax1.set_ylabel("y")
    ax1.axis('equal'); ax1.grid(True)

    # 子图2：优化过程（动态）
    ax2 = fig.add_subplot(gs[0, 1])
    xs2 = cities[initial_perm, 0]; ys2 = cities[initial_perm, 1]
    xs2 = np.append(xs2, xs2[0]); ys2 = np.append(ys2, ys2[0])
    line2, = ax2.plot(xs2, ys2, marker='o')
    ax2.set_title(title_after_fmt.format(it=0, tot=total_steps, L=tour_length(cities, initial_perm)))
    ax2.set_xlabel("x"); ax2.set_ylabel("y")
    ax2.axis('equal'); ax2.grid(True)

    # 子图3：能量曲线（动态）
    ax3 = fig.add_subplot(gs[1, :])
    line3, = ax3.plot([], [], lw=1.5)
    ax3.set_title(title_energy)
    ax3.set_xlabel(xlabel_energy)
    ax3.set_ylabel(ylabel_energy)
    ax3.grid(True)
    ax3.set_xlim(0, total_steps)
    ax3.set_ylim(0, 1.0)

    fig.tight_layout(rect=[0, 0.08, 1, 1])  # 给按钮留出底部空间

    # ---------------------
    # 动画更新函数（不改）
    # ---------------------
    current_step = {'k': 0}

    def do_iterations(n_iter):
        for _ in range(n_iter):
            net.step()

    def update(frame_idx):
        remain = total_steps - current_step['k']
        step_now = min(update_every, remain)
        if step_now <= 0:
            return line2, line3

        do_iterations(step_now)
        current_step['k'] += step_now

        perm_now = net.extract_tour()
        L_now = tour_length(cities, perm_now)

        x2 = cities[perm_now, 0]; y2 = cities[perm_now, 1]
        x2 = np.append(x2, x2[0]); y2 = np.append(y2, y2[0])
        line2.set_data(x2, y2)
        ax2.set_title(title_after_fmt.format(it=current_step['k'], tot=total_steps, L=L_now))

        y = np.array(net.energy_hist, dtype=float)
        x = np.arange(1, len(y) + 1, dtype=int)
        line3.set_data(x, y)
        ax3.set_xlim(0, total_steps)
        ymin, ymax = float(np.min(y)), float(np.max(y))
        if ymax - ymin < 1e-6:
            ax3.set_ylim(ymin - 1.0, ymax + 1.0)
        else:
            pad = 0.05 * (ymax - ymin)
            ax3.set_ylim(ymin - pad, ymax + pad)

        return line2, line3

    # 预先算好帧数，但**先不创建动画**
    n_frames = (total_steps + update_every - 1) // update_every
    fig.anim = None  # 防止被垃圾回收；点击后赋值为真正的动画对象

    # ---------------------
    # 开始按钮：不点不算，点了才启动动画
    # ---------------------
    btn_ax = fig.add_axes([0.80, 0.02, 0.16, 0.06])
    btn_start = Button(btn_ax, '开始计算', color='#efefef', hovercolor='#dddddd')

    def on_start(event):
        if fig.anim is None:
            fig.anim = FuncAnimation(fig, update, frames=n_frames,
                                     interval=interval_ms, blit=False, repeat=False)
            # 按钮置灰并改文案，避免重复触发
            btn_start.label.set_text('运行中...')
            btn_start.ax.set_facecolor('#cccccc')
            btn_start.hovercolor = '#cccccc'
            btn_start.eventson = False
            fig.canvas.draw_idle()

    btn_start.on_clicked(on_start)

    # 控制台提示
    if HAS_CJK:
        print(f"中文字体: {CHOSEN_FONT}；总迭代步数: {total_steps}；每帧推进: {update_every} 步")
    else:
        print(f"No CJK font detected. total_steps={total_steps}, update_every={update_every}")

    plt.show()

if __name__ == "__main__":
    main()
