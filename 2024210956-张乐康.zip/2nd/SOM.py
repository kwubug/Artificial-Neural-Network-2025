import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

GRID_H, GRID_W = 20, 20
INPUT_DIM = 2
EPOCHS = 2000

LR0 = 0.6
SIGMA0 = max(GRID_H, GRID_W) / 2

data = np.vstack([
    np.random.randn(200, 2) * 0.25 + np.array([2.0, 2.0]),
    np.random.randn(200, 2) * 0.30 + np.array([-2.0, 1.5]),
    np.random.randn(200, 2) * 0.20 + np.array([0.0, -2.0]),
])

som = np.random.uniform(-3, 3, size=(GRID_H, GRID_W, INPUT_DIM))

def find_bmu(x):
    diff = som - x
    dist = np.sum(diff * diff, axis=2)
    return np.unravel_index(np.argmin(dist), (GRID_H, GRID_W))

fig, ax = plt.subplots(figsize=(7, 7))
ax.set_xlim(-4, 4)
ax.set_ylim(-4, 4)
ax.set_aspect("equal")
ax.scatter(data[:, 0], data[:, 1], s=8, alpha=0.3)

nodes = ax.scatter(som[:, :, 0].flatten(), som[:, :, 1].flatten(), c="black", s=20)

grid_lines = []
for i in range(GRID_H):
    for j in range(GRID_W - 1):
        (line,) = ax.plot(
            [som[i, j, 0], som[i, j + 1, 0]],
            [som[i, j, 1], som[i, j + 1, 1]],
            "k-", lw=0.6
        )
        grid_lines.append(line)

for i in range(GRID_H - 1):
    for j in range(GRID_W):
        (line,) = ax.plot(
            [som[i, j, 0], som[i + 1, j, 0]],
            [som[i, j, 1], som[i + 1, j, 1]],
            "k-", lw=0.6
        )
        grid_lines.append(line)

bmu_marker, = ax.plot([], [], "ro", markersize=10)

def update(t):
    global som
    lr = LR0 * np.exp(-t / (EPOCHS / 4))
    sigma = SIGMA0 * np.exp(-t / (EPOCHS / 3))
    x = data[np.random.randint(0, len(data))]
    bm_i, bm_j = find_bmu(x)
    bmu = som[bm_i, bm_j]

    for i in range(GRID_H):
        for j in range(GRID_W):
            dist2 = (i - bm_i)**2 + (j - bm_j)**2
            h = np.exp(-dist2 / (2 * sigma**2))
            som[i, j] += lr * h * (x - som[i, j])

    nodes.set_offsets(som.reshape(-1, 2))
    bmu_marker.set_data([bmu[0]], [bmu[1]])

    idx = 0
    for i in range(GRID_H):
        for j in range(GRID_W - 1):
            grid_lines[idx].set_data(
                [som[i, j, 0], som[i, j + 1, 0]],
                [som[i, j, 1], som[i, j + 1, 1]]
            )
            idx += 1
    for i in range(GRID_H - 1):
        for j in range(GRID_W):
            grid_lines[idx].set_data(
                [som[i, j, 0], som[i + 1, j, 0]],
                [som[i, j, 1], som[i + 1, j, 1]]
            )
            idx += 1

    ax.set_title(f"SOM Self-Organization   Step: {t}")
    return nodes, bmu_marker

ani = FuncAnimation(fig, update, frames=EPOCHS, interval=20, blit=False)
plt.show()
