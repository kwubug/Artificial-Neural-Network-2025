import numpy as np
import matplotlib.pyplot as plt
import random
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QDoubleSpinBox,
                               QTextEdit, QFormLayout, QTableWidget, QTableWidgetItem,
                               QHeaderView)
from PySide6.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class BoltzmannMachineTab(QWidget):
    def __init__(self):
        super().__init__()
        self.bm = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 权重和阈值设置
        param_group = QGroupBox("网络参数设置")
        param_layout = QFormLayout()

        self.temperature = QDoubleSpinBox()
        self.temperature.setRange(0.1, 10.0)
        self.temperature.setValue(0.5)
        self.temperature.setSingleStep(0.1)

        self.max_iterations = QSpinBox()
        self.max_iterations.setRange(100, 10000)
        self.max_iterations.setValue(1000)

        self.convergence_threshold = QDoubleSpinBox()
        self.convergence_threshold.setRange(0.0001, 0.1)
        self.convergence_threshold.setValue(0.001)
        self.convergence_threshold.setDecimals(4)

        param_layout.addRow("温度参数:", self.temperature)
        param_layout.addRow("最大迭代次数:", self.max_iterations)
        param_layout.addRow("收敛阈值:", self.convergence_threshold)

        param_group.setLayout(param_layout)

        # 初始状态设置
        state_group = QGroupBox("初始状态设置")
        state_layout = QHBoxLayout()

        state_layout.addWidget(QLabel("神经元状态 (V1,V2,V3):"))
        self.v1_state = QSpinBox()
        self.v1_state.setRange(0, 1)
        self.v1_state.setValue(0)
        self.v2_state = QSpinBox()
        self.v2_state.setRange(0, 1)
        self.v2_state.setValue(0)
        self.v3_state = QSpinBox()
        self.v3_state.setRange(0, 1)
        self.v3_state.setValue(0)

        state_layout.addWidget(self.v1_state)
        state_layout.addWidget(self.v2_state)
        state_layout.addWidget(self.v3_state)
        state_layout.addStretch()

        state_group.setLayout(state_layout)

        # 按钮区域
        button_layout = QHBoxLayout()
        self.init_button = QPushButton("初始化网络")
        self.simulate_button = QPushButton("单次仿真")
        self.analyze_button = QPushButton("稳定性分析")
        self.energy_button = QPushButton("能量景观分析")

        self.init_button.clicked.connect(self.init_network)
        self.simulate_button.clicked.connect(self.simulate)
        self.analyze_button.clicked.connect(self.analyze_stability)
        self.energy_button.clicked.connect(self.analyze_energy)

        button_layout.addWidget(self.init_button)
        button_layout.addWidget(self.simulate_button)
        button_layout.addWidget(self.analyze_button)
        button_layout.addWidget(self.energy_button)

        # 结果显示
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        # 状态表格
        self.state_table = QTableWidget()
        self.state_table.setColumnCount(4)
        self.state_table.setHorizontalHeaderLabels(["状态(V1,V2,V3)", "能量", "出现次数", "概率"])
        self.state_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(12, 8)))

        # 布局
        layout.addWidget(param_group)
        layout.addWidget(state_group)
        layout.addLayout(button_layout)
        layout.addWidget(self.result_text)
        layout.addWidget(QLabel("稳定状态统计:"))
        layout.addWidget(self.state_table)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

        # 初始化网络
        self.init_network()

    def init_network(self):
        try:
            # 使用文档5中的固定参数
            weights = [
                [0, 0.55, 0.45],
                [0.55, 0, 0.2],
                [0.45, 0.2, 0]
            ]
            thresholds = [-0.65, -0.3, -0.4]

            self.bm = BoltzmannMachine(weights, thresholds, self.temperature.value())
            self.result_text.append("Boltzmann机初始化成功！")
            self.result_text.append("权重矩阵:")
            self.result_text.append(str(np.array(weights)))
            self.result_text.append("阈值向量:")
            self.result_text.append(str(np.array(thresholds)))

        except Exception as e:
            self.result_text.append(f"初始化错误: {e}")

    def simulate(self):
        if self.bm is None:
            self.result_text.append("请先初始化网络！")
            return

        try:
            initial_state = [
                self.v1_state.value(),
                self.v2_state.value(),
                self.v3_state.value()
            ]

            self.bm.temperature = self.temperature.value()

            final_state, energy_history = self.bm.simulate(
                initial_state,
                self.max_iterations.value(),
                self.convergence_threshold.value()
            )

            self.result_text.append("=== 单次仿真结果 ===")
            self.result_text.append(f"初始状态: {initial_state}")
            self.result_text.append(f"最终状态: {final_state}")
            self.result_text.append(f"迭代次数: {len(energy_history)}")
            self.result_text.append(f"最终能量: {self.bm.calculate_energy(final_state):.4f}")

            # 可视化结果
            self.visualize_simulation(energy_history, self.bm.state_history)

        except Exception as e:
            self.result_text.append(f"仿真错误: {e}")

    def analyze_stability(self):
        if self.bm is None:
            self.result_text.append("请先初始化网络！")
            return

        try:
            self.result_text.append("=== 稳定性分析 ===")
            self.result_text.append("进行多次仿真寻找稳定状态...")

            stable_states = self.bm.find_all_stable_states(num_trials=50)

            # 更新表格
            self.state_table.setRowCount(len(stable_states))
            sorted_states = sorted(stable_states.items(), key=lambda x: x[1]['energy'])

            for row, (state, info) in enumerate(sorted_states):
                self.state_table.setItem(row, 0, QTableWidgetItem(str(state)))
                self.state_table.setItem(row, 1, QTableWidgetItem(f"{info['energy']:.4f}"))
                self.state_table.setItem(row, 2, QTableWidgetItem(str(info['count'])))
                self.state_table.setItem(row, 3, QTableWidgetItem(f"{info['probability']:.3f}"))

            # 找到最可能的状态
            most_probable = max(stable_states.items(), key=lambda x: x[1]['probability'])
            self.result_text.append(f"最可能的热平衡状态: {most_probable[0]}")
            self.result_text.append(f"出现概率: {most_probable[1]['probability']:.3f}")
            self.result_text.append(f"能量值: {most_probable[1]['energy']:.4f}")

        except Exception as e:
            self.result_text.append(f"稳定性分析错误: {e}")

    def analyze_energy(self):
        if self.bm is None:
            self.result_text.append("请先初始化网络！")
            return

        try:
            self.result_text.append("=== 能量景观分析 ===")

            weights = [
                [0, 0.55, 0.45],
                [0.55, 0, 0.2],
                [0.45, 0.2, 0]
            ]
            thresholds = [-0.65, -0.3, -0.4]

            state_energies = self.analyze_energy_landscape(weights, thresholds)

            self.result_text.append("所有可能状态的能量值:")
            for state, energy in state_energies.items():
                self.result_text.append(f"状态{state}: 能量 = {energy:.4f}")

            min_energy = min(state_energies.values())
            min_states = [state for state, energy in state_energies.items() if energy == min_energy]
            self.result_text.append(f"最小能量状态: {min_states}")
            self.result_text.append(f"最小能量值: {min_energy:.4f}")

        except Exception as e:
            self.result_text.append(f"能量分析错误: {e}")

    def analyze_energy_landscape(self, weights, thresholds):
        """分析能量景观"""
        all_states = []
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    all_states.append((i, j, k))

        bm_temp = BoltzmannMachine(weights, thresholds, temperature=0.1)
        state_energies = {}

        for state in all_states:
            energy = bm_temp.calculate_energy(state)
            state_energies[state] = energy

        return state_energies

    def visualize_simulation(self, energy_history, state_history):
        """修复后的可视化函数"""
        self.canvas.figure.clear()

        # 使用正确的subplots调用方式
        fig = self.canvas.figure
        ax1 = fig.add_subplot(211)  # 2行1列，第1个图
        ax2 = fig.add_subplot(212)  # 2行1列，第2个图

        # 绘制能量变化
        ax1.plot(energy_history, 'b-', linewidth=2)
        ax1.set_xlabel('迭代次数')
        ax1.set_ylabel('能量')
        ax1.set_title('BM神经网络能量收敛过程')
        ax1.grid(True, alpha=0.3)

        # 绘制状态变化
        states_array = np.array(state_history)
        for i in range(3):  # 3个神经元
            ax2.plot(states_array[:, i] + i * 0.1, label=f'神经元 V{i + 1}', linewidth=2)

        ax2.set_xlabel('迭代次数')
        ax2.set_ylabel('神经元状态')
        ax2.set_title('神经元状态变化过程')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        ax2.set_yticks([0, 1.1, 2.2])
        ax2.set_yticklabels(['0', '1', '2'])

        fig.tight_layout()
        self.canvas.draw()


class BoltzmannMachine:
    def __init__(self, weights, thresholds, temperature=1.0):
        self.weights = np.array(weights)
        self.thresholds = np.array(thresholds)
        self.temperature = temperature
        self.n_neurons = len(thresholds)
        self.states = np.zeros(self.n_neurons)
        self.energy_history = []
        self.state_history = []

    def calculate_energy(self, states):
        """计算网络能量函数"""
        energy = 0
        for i in range(self.n_neurons):
            for j in range(i + 1, self.n_neurons):
                energy -= self.weights[i, j] * states[i] * states[j]
            energy -= self.thresholds[i] * states[i]
        return energy

    def calculate_net_input(self, neuron_idx, states):
        """计算神经元的净输入"""
        net_input = 0
        for j in range(self.n_neurons):
            if j != neuron_idx:
                net_input += self.weights[neuron_idx, j] * states[j]
        net_input += self.thresholds[neuron_idx]
        return net_input

    def activation_probability(self, neuron_idx, states):
        """计算神经元激活概率"""
        net_input = self.calculate_net_input(neuron_idx, states)
        probability = 1 / (1 + np.exp(-net_input / self.temperature))
        return probability

    def update_neuron(self, neuron_idx, states):
        """异步更新单个神经元状态"""
        prob = self.activation_probability(neuron_idx, states)
        if random.random() < prob:
            new_state = 1
        else:
            new_state = 0
        return new_state

    def simulate(self, initial_states=None, max_iterations=1000, convergence_threshold=0.001):
        """仿真网络运行过程"""
        if initial_states is None:
            self.states = np.random.randint(0, 2, self.n_neurons)
        else:
            self.states = np.array(initial_states)

        self.energy_history = []
        self.state_history = []

        for iteration in range(max_iterations):
            current_energy = self.calculate_energy(self.states)
            self.energy_history.append(current_energy)
            self.state_history.append(self.states.copy())

            # 随机选择神经元进行更新
            neuron_idx = random.randint(0, self.n_neurons - 1)
            new_state = self.update_neuron(neuron_idx, self.states)

            # 创建新状态向量
            new_states = self.states.copy()
            new_states[neuron_idx] = new_state
            new_energy = self.calculate_energy(new_states)

            # Metropolis准则
            if new_energy < current_energy:
                self.states = new_states
            else:
                delta_energy = new_energy - current_energy
                acceptance_prob = np.exp(-delta_energy / self.temperature)
                if random.random() < acceptance_prob:
                    self.states = new_states

            # 检查收敛条件
            if len(self.energy_history) > 10:
                recent_energies = self.energy_history[-10:]
                energy_std = np.std(recent_energies)
                if energy_std < convergence_threshold:
                    break

        return self.states, self.energy_history

    def find_all_stable_states(self, num_trials=100):
        """通过多次仿真寻找所有稳定状态"""
        stable_states = {}

        for trial in range(num_trials):
            initial_state = np.random.randint(0, 2, self.n_neurons)
            final_state, _ = self.simulate(initial_state, max_iterations=500)

            state_key = tuple(final_state)
            energy = self.calculate_energy(final_state)

            if state_key not in stable_states:
                stable_states[state_key] = {
                    'energy': energy,
                    'count': 1,
                    'probability': 0
                }
            else:
                stable_states[state_key]['count'] += 1

        # 计算概率
        total_trials = sum(info['count'] for info in stable_states.values())
        for state_info in stable_states.values():
            state_info['probability'] = state_info['count'] / total_trials

        return stable_states