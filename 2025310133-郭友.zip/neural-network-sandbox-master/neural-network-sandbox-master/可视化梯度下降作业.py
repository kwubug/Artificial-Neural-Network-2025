import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D
import random


class TwoPeakGradientDescent:
    def __init__(self):
        # 函数
        self.f = lambda x, y: (x - 1) ** 2 + (y - 1) ** 2 + 2 * np.exp(-((x + 1) ** 2 + (y + 1) ** 2))

        # 梯度
        self.grad_f = lambda x, y: np.array([
            2 * (x - 1) - 4 * (x + 1) * np.exp(-((x + 1) ** 2 + (y + 1) ** 2)),
            2 * (y - 1) - 4 * (y + 1) * np.exp(-((x + 1) ** 2 + (y + 1) ** 2))
        ])

        # Hessian矩阵
        self.hessian_f = lambda x, y: np.array([
            [2 - 4 * np.exp(-((x + 1) ** 2 + (y + 1) ** 2)) + 8 * (x + 1) ** 2 * np.exp(-((x + 1) ** 2 + (y + 1) ** 2)),
             8 * (x + 1) * (y + 1) * np.exp(-((x + 1) ** 2 + (y + 1) ** 2))],
            [8 * (x + 1) * (y + 1) * np.exp(-((x + 1) ** 2 + (y + 1) ** 2)),
             2 - 4 * np.exp(-((x + 1) ** 2 + (y + 1) ** 2)) + 8 * (y + 1) ** 2 * np.exp(-((x + 1) ** 2 + (y + 1) ** 2))]
        ])


        self.x = np.linspace(-2, 2, 40)
        self.y = np.linspace(-2, 2, 40)
        self.X, self.Y = np.meshgrid(self.x, self.y)
        self.Z = self.f(self.X, self.Y)

        # 初始化图形
        self.fig = plt.figure(figsize=(18, 6))
        self.setup_plots()

        # 收敛标志
        self.sd_converged = False
        self.newton_converged = False
        self.cg_converged = False

    def setup_plots(self):
        """设置三个子图"""
        # 最速下降法
        self.ax1 = self.fig.add_subplot(131, projection='3d')
        self.ax1.plot_surface(self.X, self.Y, self.Z, cmap='viridis', alpha=0.6)
        self.ax1.set_xlabel('X')
        self.ax1.set_ylabel('Y')
        self.ax1.set_zlabel('f(X,Y)')
        self.ax1.set_title('Steepest Descent')
        self.ax1.view_init(elev=30, azim=45)

        # 牛顿法
        self.ax2 = self.fig.add_subplot(132, projection='3d')
        self.ax2.plot_surface(self.X, self.Y, self.Z, cmap='plasma', alpha=0.6)
        self.ax2.set_xlabel('X')
        self.ax2.set_ylabel('Y')
        self.ax2.set_zlabel('f(X,Y)')
        self.ax2.set_title('Newton Method')
        self.ax2.view_init(elev=30, azim=45)

        # 共轭梯度法
        self.ax3 = self.fig.add_subplot(133, projection='3d')
        self.ax3.plot_surface(self.X, self.Y, self.Z, cmap='coolwarm', alpha=0.6)
        self.ax3.set_xlabel('X')
        self.ax3.set_ylabel('Y')
        self.ax3.set_zlabel('f(X,Y)')
        self.ax3.set_title('Conjugate Gradient')
        self.ax3.view_init(elev=30, azim=45)

        # 初始化轨迹线
        self.sd_line, = self.ax1.plot([], [], [], 'r-', linewidth=4)
        self.sd_point, = self.ax1.plot([], [], [], 'ro', markersize=8)

        self.newton_line, = self.ax2.plot([], [], [], 'b-', linewidth=4)
        self.newton_point, = self.ax2.plot([], [], [], 'bo', markersize=8)

        self.cg_line, = self.ax3.plot([], [], [], 'g-', linewidth=4)
        self.cg_point, = self.ax3.plot([], [], [], 'go', markersize=8)

    def generate_random_start_point(self):
        """生成随机起点"""
        x = random.uniform(-1.5, 1.5)
        y = random.uniform(-1.5, 1.5)
        return [x, y]

    def steepest_descent(self, x0, learning_rate=0.05, max_iter=50):
        """最速下降法"""
        x = x0.copy()
        trajectory = [x0.copy()]

        for i in range(max_iter):
            grad = self.grad_f(x[0], x[1])
            x_new = x - learning_rate * grad

            # 如果梯度很小，提前停止
            if np.linalg.norm(grad) < 1e-4:
                print(f"Steepest Descent converged at iteration {i}")
                self.sd_converged = True
                break

            x = x_new
            trajectory.append(x.copy())

        return np.array(trajectory)

    def newton_method(self, x0, max_iter=30):
        """牛顿法"""
        x = x0.copy()
        trajectory = [x0.copy()]

        for i in range(max_iter):
            grad = self.grad_f(x[0], x[1])
            hessian = self.hessian_f(x[0], x[1])

            try:
                delta = np.linalg.solve(hessian, -grad)
                x_new = x + delta
            except np.linalg.LinAlgError:
                x_new = x - 0.05 * grad

            # 如果变化很小，提前停止
            if np.linalg.norm(x_new - x) < 1e-4:
                print(f"Newton Method converged at iteration {i}")
                self.newton_converged = True
                break

            x = x_new
            trajectory.append(x.copy())

        return np.array(trajectory)

    def conjugate_gradient(self, x0, max_iter=50):
        """共轭梯度法"""
        x = x0.copy()
        trajectory = [x0.copy()]

        # 初始梯度
        g = self.grad_f(x[0], x[1])
        d = -g

        for i in range(max_iter):
            # 线搜索
            alpha = 0.05

            x_new = x + alpha * d
            g_new = self.grad_f(x_new[0], x_new[1])

            beta = np.dot(g_new, g_new) / np.dot(g, g)
            d = -g_new + beta * d

            x = x_new
            g = g_new
            trajectory.append(x.copy())

            # 收敛检查
            if np.linalg.norm(g) < 1e-4:
                print(f"Conjugate Gradient converged at iteration {i}")
                self.cg_converged = True
                break

        return np.array(trajectory)

    def animate(self, frame):
        """动画更新函数"""
        # 更新最速下降法
        if frame < len(self.sd_trajectory):
            current_points = self.sd_trajectory[:frame + 1]
            z_values = [self.f(p[0], p[1]) for p in current_points]

            self.sd_line.set_data(current_points[:, 0], current_points[:, 1])
            self.sd_line.set_3d_properties(z_values)

            self.sd_point.set_data([current_points[-1, 0]], [current_points[-1, 1]])
            self.sd_point.set_3d_properties([z_values[-1]])

            # 更新标题
            if frame == len(self.sd_trajectory) - 1 and self.sd_converged:
                self.ax1.set_title('Steepest Descent')

        # 更新牛顿法
        if frame < len(self.newton_trajectory):
            current_points = self.newton_trajectory[:frame + 1]
            z_values = [self.f(p[0], p[1]) for p in current_points]

            self.newton_line.set_data(current_points[:, 0], current_points[:, 1])
            self.newton_line.set_3d_properties(z_values)

            self.newton_point.set_data([current_points[-1, 0]], [current_points[-1, 1]])
            self.newton_point.set_3d_properties([z_values[-1]])

            # 更新标题
            if frame == len(self.newton_trajectory) - 1 and self.newton_converged:
                self.ax2.set_title('Newton Method')

        # 更新共轭梯度法
        if frame < len(self.cg_trajectory):
            current_points = self.cg_trajectory[:frame + 1]
            z_values = [self.f(p[0], p[1]) for p in current_points]

            self.cg_line.set_data(current_points[:, 0], current_points[:, 1])
            self.cg_line.set_3d_properties(z_values)

            self.cg_point.set_data([current_points[-1, 0]], [current_points[-1, 1]])
            self.cg_point.set_3d_properties([z_values[-1]])

            # 更新标题
            if frame == len(self.cg_trajectory) - 1 and self.cg_converged:
                self.ax3.set_title('Conjugate Gradient')

        return (self.sd_line, self.sd_point, self.newton_line, self.newton_point,
                self.cg_line, self.cg_point)

    def run_optimization(self):
        """运行优化并创建动画"""
        # 生成随机起点
        start_point = self.generate_random_start_point()

        print("Starting optimization...")
        print(f"Start point: {start_point}")
        print(f"Initial function value: {self.f(start_point[0], start_point[1]):.2f}")

        # 运行各种优化方法
        self.sd_trajectory = self.steepest_descent(np.array(start_point))
        self.newton_trajectory = self.newton_method(np.array(start_point))
        self.cg_trajectory = self.conjugate_gradient(np.array(start_point))

        # 打印结果
        print(f"\nSteepest Descent:")
        print(f"  Final point: ({self.sd_trajectory[-1, 0]:.3f}, {self.sd_trajectory[-1, 1]:.3f})")
        print(f"  Final value: {self.f(self.sd_trajectory[-1, 0], self.sd_trajectory[-1, 1]):.3f}")
        print(f"  Iterations: {len(self.sd_trajectory)}")

        print(f"\nNewton Method:")
        print(f"  Final point: ({self.newton_trajectory[-1, 0]:.3f}, {self.newton_trajectory[-1, 1]:.3f})")
        print(f"  Final value: {self.f(self.newton_trajectory[-1, 0], self.newton_trajectory[-1, 1]):.3f}")
        print(f"  Iterations: {len(self.newton_trajectory)}")

        print(f"\nConjugate Gradient:")
        print(f"  Final point: ({self.cg_trajectory[-1, 0]:.3f}, {self.cg_trajectory[-1, 1]:.3f})")
        print(f"  Final value: {self.f(self.cg_trajectory[-1, 0], self.cg_trajectory[-1, 1]):.3f}")
        print(f"  Iterations: {len(self.cg_trajectory)}")

        # 创建动画
        max_frames = max(len(self.sd_trajectory), len(self.newton_trajectory), len(self.cg_trajectory))
        anim = FuncAnimation(self.fig, self.animate, frames=max_frames,
                             interval=100, blit=True, repeat=True)

        plt.tight_layout()
        plt.show()

        return anim


def create_comparison_plot():
    """创建比较图"""
    visualizer = TwoPeakGradientDescent()
    start_point = visualizer.generate_random_start_point()

    # 获取轨迹
    sd_traj = visualizer.steepest_descent(np.array(start_point))
    newton_traj = visualizer.newton_method(np.array(start_point))
    cg_traj = visualizer.conjugate_gradient(np.array(start_point))

    # 创建2D比较图
    plt.figure(figsize=(15, 5))

    # 2D轨迹图
    plt.subplot(1, 3, 1)
    x = np.linspace(-2, 2, 40)
    y = np.linspace(-2, 2, 40)
    X, Y = np.meshgrid(x, y)
    Z = visualizer.f(X, Y)

    plt.contour(X, Y, Z, levels=15, alpha=0.6)
    plt.plot(sd_traj[:, 0], sd_traj[:, 1], 'ro-', markersize=4, linewidth=2, label='Steepest Descent')
    plt.plot(newton_traj[:, 0], newton_traj[:, 1], 'bo-', markersize=4, linewidth=2, label='Newton Method')
    plt.plot(cg_traj[:, 0], cg_traj[:, 1], 'go-', markersize=4, linewidth=2, label='Conjugate Gradient')

    plt.plot(start_point[0], start_point[1], 'k*', markersize=15, label='Start')

    # 标记两个极小值点
    plt.plot(1, 1, 'kx', markersize=10, label='Global Min')
    plt.plot(-1, -1, 'kx', markersize=10, label='Local Min')

    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Optimization Paths (2D)')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 函数值下降图
    plt.subplot(1, 3, 2)
    sd_vals = [visualizer.f(p[0], p[1]) for p in sd_traj]
    newton_vals = [visualizer.f(p[0], p[1]) for p in newton_traj]
    cg_vals = [visualizer.f(p[0], p[1]) for p in cg_traj]

    plt.plot(range(len(sd_vals)), sd_vals, 'r-', label='Steepest Descent', linewidth=2)
    plt.plot(range(len(newton_vals)), newton_vals, 'b-', label='Newton Method', linewidth=2)
    plt.plot(range(len(cg_vals)), cg_vals, 'g-', label='Conjugate Gradient', linewidth=2)
    plt.xlabel('Iterations')
    plt.ylabel('Function Value')
    plt.title('Convergence Comparison')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 最终结果比较
    plt.subplot(1, 3, 3)
    methods = ['Steepest\nDescent', 'Newton\nMethod', 'Conjugate\nGradient']
    final_values = [sd_vals[-1], newton_vals[-1], cg_vals[-1]]
    iterations = [len(sd_traj), len(newton_traj), len(cg_traj)]

    x_pos = np.arange(len(methods))

    plt.bar(x_pos - 0.2, final_values, 0.4, label='Final Value', color=['red', 'blue', 'green'], alpha=0.7)
    plt.bar(x_pos + 0.2, iterations, 0.4, label='Iterations', color=['red', 'blue', 'green'], alpha=0.5)

    plt.xlabel('Method')
    plt.ylabel('Value / Iterations')
    plt.title('Final Results Comparison')
    plt.xticks(x_pos, methods)
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


# 运行主程序
if __name__ == "__main__":
    print("=" * 50)
    print("Two-Peak Optimization Comparison")
    print("Global minimum at (1,1), Local minimum at (-1,-1)")
    print("=" * 50)

    # 创建可视化器并运行动画
    visualizer = TwoPeakGradientDescent()
    anim = visualizer.run_optimization()

    # 创建比较图
    print("\nCreating comparison plot...")
    create_comparison_plot()