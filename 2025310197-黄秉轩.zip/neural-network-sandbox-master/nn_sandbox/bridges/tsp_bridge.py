import math
import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import TspAlgorithm
from . import Bridge, BridgeProperty

class TspBridge(Bridge):
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    current_route = BridgeProperty([])
    best_route = BridgeProperty([])
    best_distance = BridgeProperty(0.0)
    current_iteration = BridgeProperty(0)
    has_finished = BridgeProperty(True)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._algorithm = TspAlgorithm()
        self._timer = PyQt5.QtCore.QTimer(self)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._on_timeout)

        datasets = self._load_datasets()
        self.dataset_dict = datasets
        if datasets:
            self.current_dataset_name = next(iter(datasets))

    def _load_datasets(self):
        return {
            'Random 10 Cities': self._generate_random_cities(10),
            'Random 20 Cities': self._generate_random_cities(20),
            'Random 30 Cities': self._generate_random_cities(30)
        }

    def _generate_random_cities(self, num_cities):
        return (np.random.rand(num_cities, 2) * 10 - 5).tolist()

    def _push_state(self):
        current_route = self._algorithm.current_route
        best_route = self._algorithm.best_route
        self.current_route = current_route.tolist() if current_route is not None else []
        self.best_route = best_route.tolist() if best_route is not None else []
        distance = float(self._algorithm.best_distance)
        if math.isinf(distance):
            distance = 0.0
        self.best_distance = distance
        self.current_iteration = self._algorithm.current_iteration

    @PyQt5.QtCore.pyqtSlot(str, int, float, float)
    def start_tsp_algorithm(self, dataset_name, population_size, mutation_rate, crossover_rate):
        if not self.has_finished:
            return
        if dataset_name not in self.dataset_dict:
            return

        cities = self.dataset_dict[dataset_name]
        self._algorithm.reset(cities=cities, population_size=population_size,
                              mutation_rate=mutation_rate, crossover_rate=crossover_rate)
        self.current_dataset_name = dataset_name
        self.current_route = []
        self.best_route = []
        self.best_distance = 0.0
        self.current_iteration = 0
        self.has_finished = False
        self._timer.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp_algorithm(self):
        if self.has_finished:
            return
        self._timer.stop()
        self.has_finished = True

    def _on_timeout(self):
        should_continue = self._algorithm.step()
        self._push_state()
        if not should_continue:
            self._timer.stop()
            self.has_finished = True