"""
优化算法实现：
1. 最速下降法（Steepest Descent）
2. 牛顿法（Newton's Method）
3. 共轭梯度法（Conjugate Gradient）
"""

import numpy as np
from typing import Callable, List, Tuple


class OptimizationAlgorithm:
    """优化算法基类"""
    
    def __init__(self, func: Callable, grad: Callable, hessian: Callable = None):
        """
        初始化优化算法
        
        Args:
            func: 目标函数
            grad: 梯度函数
            hessian: Hessian矩阵函数（牛顿法需要）
        """
        self.func = func
        self.grad = grad
        self.hessian = hessian
        
    def optimize(self, x0: np.ndarray, max_iter: int = 100, 
                 tol: float = 1e-6) -> Tuple[List[np.ndarray], List[float]]:
        """
        执行优化
        
        Args:
            x0: 初始点
            max_iter: 最大迭代次数
            tol: 收敛容差
            
        Returns:
            path: 优化路径（所有迭代点）
            values: 每个点的函数值
        """
        raise NotImplementedError


class SteepestDescent(OptimizationAlgorithm):
    """最速下降法"""
    
    def optimize(self, x0: np.ndarray, max_iter: int = 100, 
                 tol: float = 1e-6) -> Tuple[List[np.ndarray], List[float]]:
        """
        最速下降法优化
        使用Armijo线搜索确定步长
        """
        path = [x0.copy()]
        values = [self.func(x0)]
        x = x0.copy()
        
        for i in range(max_iter):
            # 计算梯度
            g = self.grad(x)
            
            # 检查收敛
            if np.linalg.norm(g) < tol:
                break
            
            # 搜索方向（负梯度方向）
            d = -g
            
            # Armijo线搜索
            alpha = self._line_search(x, d)
            
            # 更新
            x = x + alpha * d
            
            path.append(x.copy())
            values.append(self.func(x))
        
        return path, values
    
    def _line_search(self, x: np.ndarray, d: np.ndarray, 
                     alpha_init: float = 1.0, rho: float = 0.5, 
                     c: float = 1e-4) -> float:
        """
        Armijo线搜索
        
        Args:
            x: 当前点
            d: 搜索方向
            alpha_init: 初始步长
            rho: 步长缩减因子
            c: Armijo常数
            
        Returns:
            alpha: 步长
        """
        alpha = alpha_init
        f_x = self.func(x)
        grad_x = self.grad(x)
        m = np.dot(grad_x, d)
        
        while self.func(x + alpha * d) > f_x + c * alpha * m:
            alpha *= rho
            if alpha < 1e-10:  # 防止步长过小
                break
        
        return alpha


class NewtonMethod(OptimizationAlgorithm):
    """牛顿法"""
    
    def optimize(self, x0: np.ndarray, max_iter: int = 100, 
                 tol: float = 1e-6) -> Tuple[List[np.ndarray], List[float]]:
        """
        牛顿法优化
        """
        if self.hessian is None:
            raise ValueError("牛顿法需要提供Hessian矩阵函数")
        
        path = [x0.copy()]
        values = [self.func(x0)]
        x = x0.copy()
        
        for i in range(max_iter):
            # 计算梯度和Hessian矩阵
            g = self.grad(x)
            H = self.hessian(x)
            
            # 检查收敛
            if np.linalg.norm(g) < tol:
                break
            
            try:
                # 求解牛顿方程: H * d = -g
                # 添加正则化以确保Hessian正定
                d = np.linalg.solve(H + 1e-6 * np.eye(len(x)), -g)
            except np.linalg.LinAlgError:
                # 如果Hessian奇异，使用梯度下降方向
                d = -g
            
            # 检查是否为下降方向
            if np.dot(g, d) > 0:
                d = -g  # 如果不是下降方向，使用梯度下降
            
            # 线搜索
            alpha = self._line_search(x, d)
            
            # 更新
            x = x + alpha * d
            
            path.append(x.copy())
            values.append(self.func(x))
        
        return path, values
    
    def _line_search(self, x: np.ndarray, d: np.ndarray, 
                     alpha_init: float = 1.0, rho: float = 0.5, 
                     c: float = 1e-4) -> float:
        """Armijo线搜索"""
        alpha = alpha_init
        f_x = self.func(x)
        grad_x = self.grad(x)
        m = np.dot(grad_x, d)
        
        # 如果不是下降方向，返回小步长
        if m >= 0:
            return 0.01
        
        while self.func(x + alpha * d) > f_x + c * alpha * m:
            alpha *= rho
            if alpha < 1e-10:
                break
        
        return alpha


class ConjugateGradient(OptimizationAlgorithm):
    """共轭梯度法（Fletcher-Reeves方法）"""
    
    def optimize(self, x0: np.ndarray, max_iter: int = 100, 
                 tol: float = 1e-6) -> Tuple[List[np.ndarray], List[float]]:
        """
        共轭梯度法优化（Fletcher-Reeves公式）
        """
        path = [x0.copy()]
        values = [self.func(x0)]
        x = x0.copy()
        
        # 初始梯度和搜索方向
        g = self.grad(x)
        d = -g
        
        for i in range(max_iter):
            # 检查收敛
            if np.linalg.norm(g) < tol:
                break
            
            # 线搜索
            alpha = self._line_search(x, d)
            
            # 更新位置
            x_new = x + alpha * d
            g_new = self.grad(x_new)
            
            # Fletcher-Reeves公式计算beta
            beta = np.dot(g_new, g_new) / (np.dot(g, g) + 1e-10)
            
            # 每n步重启（其中n是维度）
            if (i + 1) % len(x) == 0:
                beta = 0
            
            # 更新搜索方向
            d = -g_new + beta * d
            
            # 更新
            x = x_new
            g = g_new
            
            path.append(x.copy())
            values.append(self.func(x))
        
        return path, values
    
    def _line_search(self, x: np.ndarray, d: np.ndarray, 
                     alpha_init: float = 1.0, rho: float = 0.5, 
                     c: float = 1e-4) -> float:
        """Armijo线搜索"""
        alpha = alpha_init
        f_x = self.func(x)
        grad_x = self.grad(x)
        m = np.dot(grad_x, d)
        
        # 如果不是下降方向，使用梯度下降
        if m >= 0:
            d = -grad_x
            m = np.dot(grad_x, d)
        
        while self.func(x + alpha * d) > f_x + c * alpha * m:
            alpha *= rho
            if alpha < 1e-10:
                break
        
        return alpha


# 预定义测试函数
class TestFunctions:
    """常用测试函数"""
    
    @staticmethod
    def rosenbrock(x):
        """Rosenbrock函数: f(x,y) = (1-x)^2 + 100(y-x^2)^2"""
        return (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2
    
    @staticmethod
    def rosenbrock_grad(x):
        """Rosenbrock函数的梯度"""
        dx = -2*(1-x[0]) - 400*x[0]*(x[1]-x[0]**2)
        dy = 200*(x[1]-x[0]**2)
        return np.array([dx, dy])
    
    @staticmethod
    def rosenbrock_hessian(x):
        """Rosenbrock函数的Hessian矩阵"""
        h11 = 2 - 400*x[1] + 1200*x[0]**2
        h12 = -400*x[0]
        h21 = -400*x[0]
        h22 = 200
        return np.array([[h11, h12], [h21, h22]])
    
    @staticmethod
    def quadratic(x):
        """二次函数: f(x,y) = x^2 + y^2"""
        return x[0]**2 + x[1]**2
    
    @staticmethod
    def quadratic_grad(x):
        """二次函数的梯度"""
        return 2 * x
    
    @staticmethod
    def quadratic_hessian(x):
        """二次函数的Hessian矩阵"""
        return 2 * np.eye(2)
    
    @staticmethod
    def beale(x):
        """Beale函数: f(x,y) = (1.5-x+xy)^2 + (2.25-x+xy^2)^2 + (2.625-x+xy^3)^2"""
        term1 = (1.5 - x[0] + x[0]*x[1])**2
        term2 = (2.25 - x[0] + x[0]*x[1]**2)**2
        term3 = (2.625 - x[0] + x[0]*x[1]**3)**2
        return term1 + term2 + term3
    
    @staticmethod
    def beale_grad(x):
        """Beale函数的梯度"""
        term1 = 1.5 - x[0] + x[0]*x[1]
        term2 = 2.25 - x[0] + x[0]*x[1]**2
        term3 = 2.625 - x[0] + x[0]*x[1]**3
        
        dx = 2*term1*(-1+x[1]) + 2*term2*(-1+x[1]**2) + 2*term3*(-1+x[1]**3)
        dy = 2*term1*x[0] + 2*term2*x[0]*2*x[1] + 2*term3*x[0]*3*x[1]**2
        return np.array([dx, dy])
    
    @staticmethod
    def beale_hessian(x):
        """Beale函数的Hessian矩阵（数值近似）"""
        eps = 1e-5
        grad = TestFunctions.beale_grad
        
        h11 = (grad(x + np.array([eps, 0]))[0] - grad(x)[0]) / eps
        h12 = (grad(x + np.array([0, eps]))[0] - grad(x)[0]) / eps
        h21 = (grad(x + np.array([eps, 0]))[1] - grad(x)[1]) / eps
        h22 = (grad(x + np.array([0, eps]))[1] - grad(x)[1]) / eps
        
        return np.array([[h11, h12], [h21, h22]])
    
    @staticmethod
    def booth(x):
        """Booth函数: f(x,y) = (x+2y-7)^2 + (2x+y-5)^2"""
        return (x[0] + 2*x[1] - 7)**2 + (2*x[0] + x[1] - 5)**2
    
    @staticmethod
    def booth_grad(x):
        """Booth函数的梯度"""
        dx = 2*(x[0] + 2*x[1] - 7) + 4*(2*x[0] + x[1] - 5)
        dy = 4*(x[0] + 2*x[1] - 7) + 2*(2*x[0] + x[1] - 5)
        return np.array([dx, dy])
    
    @staticmethod
    def booth_hessian(x):
        """Booth函数的Hessian矩阵"""
        return np.array([[10, 8], [8, 10]])

