import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: '最小二乘(OLS)'

    ColumnLayout {
        GroupBox {
            title: '数据集'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(olsBridge.dataset_dict).filter(k => k.startsWith('ols_'))
                enabled: olsBridge.has_finished
                onActivated: () => {
                    if (currentText && currentText.length > 0) {
                        olsBridge.current_dataset_name = currentText
                        dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                    }
                }
                Component.onCompleted: () => {
                    if (model.length > 0) {
                        olsBridge.current_dataset_name = currentText
                        dataChart.updateDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                    }
                }
            }
        }

        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label { text: '训练总轮数'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: totalEpoches
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 20
                    to: 999999
                    onValueChanged: olsBridge.total_epoches = value
                    Component.onCompleted: olsBridge.total_epoches = value
                    Layout.fillWidth: true
                }

                Label { text: '学习率'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.05 * 100
                    from: 0.001 * 100
                    to: 1.0 * 100
                    onValueChanged: olsBridge.learning_rate = value / 100
                    Component.onCompleted: olsBridge.learning_rate = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '批大小(0=全量)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0
                    to: 99999
                    onValueChanged: olsBridge.batch_size = value
                    Component.onCompleted: olsBridge.batch_size = value
                    Layout.fillWidth: true
                }

                Label { text: 'UI刷新间隔（秒）'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: olsBridge.has_finished
                    editable: true
                    value: 0.02 * 100
                    from: 0 * 100
                    to: 1.0 * 100
                    onValueChanged: olsBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: olsBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '标准化数据'; Layout.alignment: Qt.AlignHCenter }
                CheckBox {
                    id: normalizeCheck
                    enabled: olsBridge.has_finished
                    checked: true
                    onCheckedChanged: olsBridge.normalize_data = checked
                    Component.onCompleted: olsBridge.normalize_data = checked
                    Layout.alignment: Qt.AlignLeft
                }
            }
        }

        GroupBox {
            title: '信息'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2

                ExecutionControls {
                    startButton.enabled: olsBridge.has_finished
                    startButton.onClicked: () => {
                        olsBridge.start_ols()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(olsBridge.dataset_dict[datasetCombobox.currentText])
                        lossChart.reset()
                    }
                    stopButton.enabled: !olsBridge.has_finished
                    stopButton.onClicked: olsBridge.stop_ols()
                    progressBar.value: (olsBridge.current_epoch) / totalEpoches.value
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: '当前轮次'; Layout.alignment: Qt.AlignHCenter }
                Label { text: olsBridge.current_epoch; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '当前迭代'; Layout.alignment: Qt.AlignHCenter }
                Label { text: olsBridge.current_iteration; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '当前损失(MSE)'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: (Number.isFinite(olsBridge.current_loss))
                        ? olsBridge.current_loss.toFixed(6)
                        : (olsBridge.current_loss || 0)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label { text: '回归参数(w0, w1)'; Layout.alignment: Qt.AlignHCenter }
                Label { text: '(' + olsBridge.w0.toFixed(4) + ', ' + olsBridge.w1.toFixed(4) + ')'; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
            }
        }
    }

    ColumnLayout {
        DataChart {
            id: dataChart
            property var olsLine
            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true

            function updateLineSeries() {
                if (olsLine) {
                    removeSeries(olsLine)
                }
                // 基于当前坐标轴边界，绘制拟合直线
                const x1 = xAxis.min
                const x2 = xAxis.max
                const y1 = olsBridge.w0 + olsBridge.w1 * x1
                const y2 = olsBridge.w0 + olsBridge.w1 * x2
                olsLine = createSeries(ChartView.SeriesTypeLine, 'OLS', xAxis, yAxis)
                olsLine.useOpenGL = true
                olsLine.append(x1, y1)
                olsLine.append(x2, y2)
            }
        }

        // 简单损失曲线（基于文本刷新）
        ChartView {
            id: lossChart
            Layout.fillWidth: true
            Layout.fillHeight: true
            antialiasing: true
            legend.visible: false

            ValueAxis { id: lx; min: 0; max: 100 }
            ValueAxis { id: ly; min: 0; max: 1 }

            LineSeries {
                id: lossSeries
                axisX: lx
                axisY: ly
                color: 'blue'
                width: 2
            }

            function reset() {
                lossSeries.clear()
                lx.max = 100
                ly.min = 0
                ly.max = 1
            }

            function appendLoss(iteration, loss) {
                lossSeries.append(iteration, Math.max(0, loss))
                lx.max = Math.max(lx.max, iteration)
                if (loss > 0) {
                    ly.max = Math.max(ly.max, loss * 1.5)
                }
            }
        }
    }

    Connections {
        target: olsBridge
        function onCurrent_iterationChanged() {
            dataChart.updateLineSeries()
            lossChart.appendLoss(olsBridge.current_iteration, olsBridge.current_loss)
        }
    }
}


