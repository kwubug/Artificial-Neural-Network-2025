import time

import PyQt5.QtCore
import numpy as np

from nn_sandbox.backend.algorithms import HopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    """Hopfield 网络前后端桥接类"""
    
    # 定义所有需要同步到 QML 的属性
    ui_refresh_interval = BridgeProperty(0.0)
    energy = BridgeProperty(0.0)
    iteration = BridgeProperty(0)
    converged = BridgeProperty(False)
    similarity = BridgeProperty(0.0)
    current_state = BridgeProperty([])
    weights_matrix = BridgeProperty([])
    patterns = BridgeProperty([])
    pattern_count = BridgeProperty(0)
    state_history = BridgeProperty([])
    num_neurons = BridgeProperty(100)
    retrieval_in_progress = BridgeProperty(False)
    
    def __init__(self, num_neurons=100):
        super().__init__()
        self._num_neurons = num_neurons
        self._hopfield_algorithm = HopfieldAlgorithm(
            num_neurons=num_neurons,
            ui_refresh_interval=self.ui_refresh_interval
        )
        
        # 初始化属性
        self.num_neurons = num_neurons
        self.energy = 0.0
        self.iteration = 0
        self.converged = False
        self.similarity = 0.0
        self.pattern_count = 0

    @PyQt5.QtCore.pyqtSlot(list)
    def store_pattern(self, pattern):
        """
        存储一个模式
        
        Args:
            pattern: list，长度应为 num_neurons，值为 ±1
        """
        try:
            pattern_array = np.array(pattern, dtype=np.float64)
            
            # 验证输入
            if len(pattern_array) != self._num_neurons:
                raise ValueError(
                    f"Pattern length {len(pattern_array)} != {self._num_neurons}"
                )
            
            # 确保值为 ±1
            pattern_array = np.sign(pattern_array)
            pattern_array[pattern_array == 0] = 1
            
            # 存储模式
            self._hopfield_algorithm.store_pattern(pattern_array)
            
            # 更新 Bridge 属性（触发 QML 更新）
            self.patterns = self._hopfield_algorithm.get_patterns()
            self.pattern_count = self._hopfield_algorithm._pattern_count
            
        except Exception as e:
            print(f"Error storing pattern: {e}")

    @PyQt5.QtCore.pyqtSlot(result=list)
    def generate_random_pattern(self):
        """生成随机模式"""
        pattern = np.random.choice([-1.0, 1.0], size=self._num_neurons)
        return pattern.tolist()

    @PyQt5.QtCore.pyqtSlot()
    def clear_patterns(self):
        """清空所有模式"""
        self._hopfield_algorithm.clear_patterns()
        self.patterns = []
        self.pattern_count = 0
        self.current_state = []
        self.state_history = []
        self.energy = 0.0
        self.iteration = 0
        self.converged = False
        self.similarity = 0.0

    @PyQt5.QtCore.pyqtSlot(list)
    def set_initial_state(self, state):
        """
        设置初始状态
        
        Args:
            state: list，长度应为 num_neurons
        """
        try:
            state_array = np.array(state, dtype=np.float64)
            state_array = np.sign(state_array)
            state_array[state_array == 0] = 1
            
            self._hopfield_algorithm.set_initial_state(state_array)
            
            # 同步属性到 Bridge
            self._sync_state_from_backend()
            
        except Exception as e:
            print(f"Error setting initial state: {e}")

    @PyQt5.QtCore.pyqtSlot(int, float)
    def create_noisy_pattern(self, pattern_index, noise_rate):
        """
        创建带噪声的模式（用于检索测试）
        
        Args:
            pattern_index: 存储模式的索引
            noise_rate: 噪声比例 (0.0 ~ 1.0)
        """
        try:
            if pattern_index >= len(self._hopfield_algorithm._patterns):
                raise ValueError(f"Pattern index {pattern_index} out of range")
            
            pattern = (
                self._hopfield_algorithm._patterns[pattern_index].copy()
            )
            
            # 添加噪声
            num_flips = int(self._num_neurons * noise_rate)
            if num_flips > 0:
                flip_indices = np.random.choice(
                    self._num_neurons, num_flips, replace=False
                )
                pattern[flip_indices] *= -1
            
            self.set_initial_state(pattern)
            
        except Exception as e:
            print(f"Error creating noisy pattern: {e}")

    @PyQt5.QtCore.pyqtSlot(str)
    def step(self, update_rule='async'):
        """
        执行一步更新
        
        Args:
            update_rule: 'sync' 或 'async'
        """
        try:
            self._hopfield_algorithm.step(update_rule=update_rule)
            
            # 同步所有属性
            self._sync_state_from_backend()
            
            # 防止 UI 阻塞
            time.sleep(self.ui_refresh_interval)
            
        except Exception as e:
            print(f"Error in step: {e}")

    @PyQt5.QtCore.pyqtSlot(int, str)
    def retrieve(self, max_iterations=1000, update_rule='async'):
        """
        完整检索过程
        
        Args:
            max_iterations: 最大迭代次数
            update_rule: 'sync' 或 'async'
        """
        try:
            self.retrieval_in_progress = True
            self._hopfield_algorithm.retrieve(
                max_iterations=max_iterations,
                update_rule=update_rule
            )
            
            # 同步所有属性
            self._sync_state_from_backend()
            self.retrieval_in_progress = False
            
        except Exception as e:
            print(f"Error in retrieval: {e}")
            self.retrieval_in_progress = False

    @PyQt5.QtCore.pyqtSlot(float)
    def add_noise(self, noise_rate):
        """
        向当前状态添加噪声
        
        Args:
            noise_rate: 噪声比例
        """
        try:
            self._hopfield_algorithm.add_noise(noise_rate=noise_rate)
            self._sync_state_from_backend()
            
        except Exception as e:
            print(f"Error adding noise: {e}")

    @PyQt5.QtCore.pyqtSlot(result=int)
    def calculate_pattern_capacity(self):
        """
        计算网络容量（理论值）
        """
        return self._hopfield_algorithm.calculate_capacity()

    @PyQt5.QtCore.pyqtSlot(result=list)
    def get_weights(self):
        """获取权重矩阵"""
        return self._hopfield_algorithm.get_weights_matrix()

    @PyQt5.QtCore.pyqtSlot(result=list)
    def get_patterns(self):
        """获取所有存储的模式"""
        return self._hopfield_algorithm.get_patterns()

    @PyQt5.QtCore.pyqtSlot(result=list)
    def get_current_state(self):
        """获取当前状态"""
        return self._hopfield_algorithm.get_state_vector()

    @PyQt5.QtCore.pyqtSlot(result=str)
    def get_network_info(self):
        """
        获取网络信息摘要
        返回格式化的信息字符串
        """
        patterns = self._hopfield_algorithm._patterns
        if len(patterns) == 0:
            return "No patterns stored"
        
        # 计算模式间的平均相似度
        if len(patterns) > 1:
            similarities = []
            for i in range(len(patterns)):
                for j in range(i + 1, len(patterns)):
                    sim = np.dot(patterns[i], patterns[j]) / self._num_neurons
                    similarities.append(abs(sim))
            avg_similarity = np.mean(similarities)
            return f"Patterns: {len(patterns)}, Avg Similarity: {avg_similarity:.3f}"
        else:
            return f"Patterns: {len(patterns)}"

    def _sync_state_from_backend(self):
        """
        从后端同步所有状态到 Bridge（内部方法）
        """
        self.energy = self._hopfield_algorithm._energy
        self.iteration = self._hopfield_algorithm._iteration
        self.converged = self._hopfield_algorithm._converged
        self.similarity = self._hopfield_algorithm._similarity
        self.current_state = self._hopfield_algorithm.get_state_vector()
        self.state_history = self._hopfield_algorithm.get_state_history()
