# som_app_final.py
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
import imageio
import os
import pandas as pd

st.set_page_config(page_title="SOM 可视化", layout="wide")
st.title("5×5 自组织映射 (SOM) 可视化")

# 输入模式
patterns = np.array([
    [1,0,0,0],
    [1,1,0,0],
    [1,1,1,0],
    [0,1,0,0],
    [1,1,1,1]
], dtype=float)

grid_h = grid_w = 5
coords = np.array([(i,j) for i in range(grid_h) for j in range(grid_w)])
n_neurons = grid_h * grid_w

# Sidebar 控件
st.sidebar.header("参数设置")
total_steps = st.sidebar.slider("总训练步数", 1000, 10000, 10000, 1000)
save_every = st.sidebar.slider("保存间隔（步）", 100, 2000, 200)
speed = st.sidebar.slider("动画速度（秒/帧）", 0.2, 2.0, 1.0, 0.1)

# 初始权重
np.random.seed(0)
weights = np.random.rand(n_neurons, patterns.shape[1])

# -------------------------
# 学习率与邻域半径定义
# -------------------------
def learning_rate(t):
    if t <= 1000:
        return 0.5 + (0.04 - 0.5) * (t / 1000.0)
    else:
        # 从 0.04 到 0，直到 total_steps
        return 0.04 * (1 - (t - 1000) / (total_steps - 1000))

def neighborhood_radius(t):
    if t <= 1000:
        return 2.0 * (1 - t / 1000.0)
    else:
        return 0.0

def neighborhood_strength(bmu_idx, sigma):
    if sigma <= 0:
        v = np.zeros(n_neurons)
        v[bmu_idx] = 1.0
        return v
    d2 = np.sum((coords - coords[bmu_idx])**2, axis=1)
    return np.exp(-d2 / (2 * (sigma**2)))

def label_map_from_weights(w):
    labels = np.zeros(n_neurons, dtype=int)
    for ni in range(n_neurons):
        d = np.linalg.norm(patterns - w[ni], axis=1)
        labels[ni] = int(np.argmin(d) + 1)
    return labels.reshape((grid_h, grid_w))

# 临时帧文件夹
frames_dir = "som_frames"
os.makedirs(frames_dir, exist_ok=True)

# -------------------------
# 训练与可视化
# -------------------------
if st.button("开始训练并可视化"):
    st.write("开始训练中，请稍候...")
    progress = st.progress(0)
    snapshots = {}
    snapshots[0] = weights.copy()
    eta_values, sigma_values = [], []

    for t in range(1, total_steps+1):
        p = patterns[np.random.randint(0, patterns.shape[0])]
        dists = np.linalg.norm(weights - p, axis=1)
        bmu = np.argmin(dists)
        eta = learning_rate(t)
        sigma = neighborhood_radius(t)
        neigh = neighborhood_strength(bmu, sigma)
        weights += (eta * neigh[:,None]) * (p - weights)

        eta_values.append(eta)
        sigma_values.append(sigma)

        if t % save_every == 0 or t == total_steps:
            snapshots[t] = weights.copy()
        if t % 100 == 0:
            progress.progress(t / total_steps)
    progress.empty()
    st.success("训练完成！")

    # -------------------------
    # 生成帧图与 GIF 动画
    # -------------------------
    st.write("正在生成")
    frame_files = []
    for step in sorted(snapshots.keys()):
        label_map = label_map_from_weights(snapshots[step])
        fig, ax = plt.subplots(figsize=(4,4))
        ax.imshow(label_map, origin='lower', interpolation='none')
        ax.set_title(f"Step {step}")
        ax.set_xticks(range(grid_w)); ax.set_yticks(range(grid_h))
        for i in range(grid_h):
            for j in range(grid_w):
                ax.text(j, i, str(label_map[i,j]), ha='center', va='center', fontsize=10)
        fname = os.path.join(frames_dir, f"frame_{step:05d}.png")
        fig.tight_layout()
        fig.savefig(fname)
        plt.close(fig)
        frame_files.append(fname)

    # 生成 GIF
    gif_path = "som_training.gif"
    images = [imageio.v2.imread(f) for f in frame_files]
    imageio.mimsave(gif_path, images, duration=speed)
    st.success("生成完成！")

    # -------------------------
    # 显示动画与静态快照
    # -------------------------
    st.subheader("SOM 训练演化动画")
    st.image(gif_path, caption=f"播放速度：每帧 {speed:.2f} 秒")

    st.subheader("不同迭代步的映射快照")
    cols = st.columns(3)
    for idx, step in enumerate(sorted(snapshots.keys())):
        with cols[idx % 3]:
            st.image(frame_files[idx], caption=f"Step {step}")

    # -------------------------
    # 最终映射
    # -------------------------
    final_weights = weights.copy()
    def map_input_to_grid(inp, wts):
        d = np.linalg.norm(wts - inp, axis=1)
        b = np.argmin(d)
        return coords[b], b

    mapping = {}
    for i, p in enumerate(patterns, start=1):
        coord, idx = map_input_to_grid(p, final_weights)
        mapping[i] = {'pattern': p.copy(), 'coord': tuple(coord.tolist()), 'index': int(idx)}

    st.subheader("最终映射结果")
    fig, ax = plt.subplots(figsize=(5,5))
    ax.set_xlim(-0.5, grid_w-0.5); ax.set_ylim(-0.5, grid_h-0.5)
    ax.set_xticks(range(grid_w)); ax.set_yticks(range(grid_h))
    ax.set_title("Final mapping of 5 inputs")
    for (i,j) in coords:
        ax.plot(j, i, marker='s', markersize=30, markeredgecolor='black', markerfacecolor='none')
    markers = ['o','v','s','P','*']
    for i in range(1,6):
        coord = mapping[i]['coord']
        ax.plot(coord[1], coord[0], marker=markers[i-1], markersize=16, label=f"P{i} → {coord}")
    ax.legend(loc='upper right', bbox_to_anchor=(1.25,1.05))
    st.pyplot(fig)
    st.table(mapping)

    # -------------------------
    # η(t) 与 σ(t) 变化曲线
    # -------------------------
    st.subheader("学习率 η(t) 与 邻域半径 σ(t) 变化曲线")
    steps = np.arange(1, total_steps+1)
    df = pd.DataFrame({
        "Step": steps,
        "Learning Rate η(t)": eta_values,
        "Neighborhood Radius σ(t)": sigma_values
    })
    st.line_chart(df.set_index("Step"))

else:
    st.info("请在左侧设置参数后，点击“开始训练并生成动画”。")
