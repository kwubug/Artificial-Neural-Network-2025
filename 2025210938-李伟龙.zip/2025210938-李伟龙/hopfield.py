import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.gridspec import GridSpec

# 设置后端和字体
plt.switch_backend('TkAgg')
plt.rcParams["font.family"] = ["SimHei", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号


class DiscreteHopfieldNetwork:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))
        self.state = np.zeros(num_neurons)

    def train(self, patterns):
        for pattern in patterns:
            if not set(np.unique(pattern)).issubset({-1, 1}):
                raise ValueError("模式必须是bipolar类型（仅包含-1和1）")

        num_patterns = len(patterns)
        for i in range(self.num_neurons):
            for j in range(self.num_neurons):
                if i != j:
                    self.weights[i, j] = (1 / self.num_neurons) * sum(
                        patterns[p][i] * patterns[p][j] for p in range(num_patterns)
                    )

    def asynchronous_update(self):
        neuron_idx = random.randint(0, self.num_neurons - 1)
        input_sum = np.dot(self.weights[neuron_idx], self.state)
        old_state = self.state[neuron_idx]
        self.state[neuron_idx] = 1 if input_sum >= 0 else -1
        return old_state != self.state[neuron_idx], neuron_idx

    def find_attractor(self, initial_state, max_iter=100):
        """找到吸引子并记录状态历史，直到稳定"""
        self.state = np.copy(initial_state)
        state_history = [np.copy(self.state)]
        energy_history = [self.energy()]
        stable_count = 0  # 记录连续稳定的次数
        stable_threshold = 2  # 连续2次稳定则判定为稳定状态

        for _ in range(max_iter):
            changed, _ = self.asynchronous_update()
            state_history.append(np.copy(self.state))
            energy_history.append(self.energy())

            # 检测稳定状态：连续两次状态不变
            if len(state_history) >= 2 and np.array_equal(state_history[-1], state_history[-2]):
                stable_count += 1
                if stable_count >= stable_threshold:
                    break  # 达到稳定，停止迭代
            else:
                stable_count = 0  # 状态变化，重置计数器

        return np.copy(self.state), len(state_history) - 1, state_history, energy_history

    def energy(self, state=None):
        if state is None:
            state = self.state
        return -0.5 * np.sum(self.weights * np.outer(state, state))

    def animate_evolution(self, initial_state, original_pattern=None, hold_time=5):
        """hold_time: 稳定后保持显示的时间（秒）"""
        self.state = np.copy(initial_state)
        attractor, iterations, state_history, energy_history = self.find_attractor(initial_state)

        # 计算需要添加的重复帧数（假设每帧interval=100ms，hold_time秒需要hold_time*10帧）
        interval = 100  # 每帧间隔100ms
        hold_frames = int(hold_time * 1000 / interval)  # 保持时间对应的帧数
        stable_state = state_history[-1]
        stable_energy = energy_history[-1]

        # 添加重复的稳定状态帧，实现保持效果
        for _ in range(hold_frames):
            state_history.append(stable_state)
            energy_history.append(stable_energy)

        # 创建图形
        fig = plt.figure(figsize=(12, 8))
        gs = GridSpec(2, 1, height_ratios=[3, 1])

        # 神经元状态图（上部分）
        ax1 = fig.add_subplot(gs[0])
        ax1.set_title('神经元状态演化 (红色表示更新的神经元)')
        ax1.set_ylim(-0.5, self.num_neurons - 0.5)
        ax1.set_xlim(-1.2, 1.2)
        ax1.set_yticks(range(self.num_neurons))
        ax1.set_yticklabels([f'神经元 {i + 1}' for i in range(self.num_neurons)])
        ax1.set_xlabel('状态值')

        # 能量变化图（下部分）
        ax2 = fig.add_subplot(gs[1])
        ax2.set_title('网络能量变化')
        ax2.set_xlabel('迭代次数')
        ax2.set_ylabel('能量')
        ax2.set_xlim(0, len(energy_history))
        ax2.set_ylim(min(energy_history) - 0.5, max(energy_history) + 0.5)

        # 初始化图形元素
        scatter = ax1.scatter([], [], c=[], cmap='coolwarm', s=100)
        energy_line, = ax2.plot([], [], 'b-')
        iter_text = ax1.text(0.02, 0.98, '', transform=ax1.transAxes,
                             verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        energy_text = ax2.text(0.02, 0.98, '', transform=ax2.transAxes,
                               verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

        # 原始模式参考线
        if original_pattern is not None:
            for i in range(self.num_neurons):
                ax1.axhline(y=i, xmin=0, xmax=1, color='gray', linestyle='--', alpha=0.3)
                ax1.text(original_pattern[i], i, f'目标: {original_pattern[i]}',
                         verticalalignment='center', color='green', alpha=0.7)

        # 动画初始化
        def init():
            scatter.set_offsets(np.empty((0, 2)))
            scatter.set_array(np.array([]))
            energy_line.set_data([], [])
            iter_text.set_text('')
            energy_text.set_text('')
            return scatter, energy_line, iter_text, energy_text

        # 动画更新函数
        def update(frame):
            state = state_history[frame]
            x = state
            y = np.arange(self.num_neurons)
            offsets = np.column_stack((x, y))

            # 确定更新的神经元（仅在稳定前标记）
            if frame < len(state_history) - hold_frames - 1:  # 稳定前的帧
                prev_state = state_history[frame - 1] if frame > 0 else state
                changed = (state != prev_state)
                colors = np.where(changed, 1, 0.5)
            else:  # 稳定后的帧（不再更新，颜色统一）
                colors = np.full(self.num_neurons, 0.5)

            scatter.set_offsets(offsets)
            scatter.set_array(colors)
            energy_line.set_data(range(frame + 1), energy_history[:frame + 1])
            iter_text.set_text(f'迭代次数: {frame}')
            energy_text.set_text(f'当前能量: {energy_history[frame]:.4f}')

            # 稳定状态标记
            if frame == len(state_history) - hold_frames - 1:
                ax1.text(0, -0.5, f'已稳定',
                         ha='center', va='top', bbox=dict(boxstyle='round', facecolor='red', alpha=0.5))

            return scatter, energy_line, iter_text, energy_text

        # 创建动画（每帧100ms，加快播放速度）
        anim = FuncAnimation(fig, update, frames=len(state_history), init_func=init,
                             interval=interval, blit=True, repeat=False)

        plt.tight_layout()
        return anim


# 示例使用
if __name__ == "__main__":
    # 1. 创建示例模式
    pattern1 = np.array([1, 1, 1, 1, -1, -1, -1, -1, 1, 1])
    pattern2 = np.array([1, 1, -1, -1, 1, 1, -1, -1, 1, -1])
    patterns = [pattern1, pattern2]

    # 2. 训练网络
    hopfield = DiscreteHopfieldNetwork(num_neurons=10)
    hopfield.train(patterns)
    print("训练完成！")

    # 3. 创建带噪声的测试模式
    noisy_pattern1 = np.copy(pattern1)
    noise_indices = random.sample(range(10), 4)  # 中等噪声
    for idx in noise_indices:
        noisy_pattern1[idx] *= -1
    print("\n带噪声的模式1：", noisy_pattern1)
    print("原始模式1：     ", pattern1)

    # 4. 显示动画（稳定后保持5秒）
    anim = hopfield.animate_evolution(noisy_pattern1, original_pattern=pattern1, hold_time=5)
    plt.show()