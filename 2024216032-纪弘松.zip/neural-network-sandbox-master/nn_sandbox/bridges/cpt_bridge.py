from PyQt5.QtCore import pyqtSignal, QThread, pyqtProperty, pyqtSlot, QVariant
import numpy as np

class CompetitiveNNBridge(QThread):
    # 定义信号
    classifyResult = pyqtSignal(int)        # 分类结果信号，发送分类的类别索引
    weightsUpdated = pyqtSignal()           # 权重更新信号
    trainingComplete = pyqtSignal()         # 训练完成信号

    inputSizeChanged = pyqtSignal()
    numNeuronsChanged = pyqtSignal()
    classificationChanged = pyqtSignal()


    def __init__(self, parent=None):
        super().__init__(parent)
        self.input_size = 3                 # 输入样本大小
        self.num_neurons = 3                # 神经元数量
        self.learning_rate = 0.1
        self.epochs = 100
        self.weights = np.random.rand(self.num_neurons, self.input_size)  # 初始化权向量
        self._classification = -1

    # 属性：输入大小
    @pyqtProperty(int, notify=inputSizeChanged)
    def inputSize(self):
        return self.input_size

    # 属性：神经元数量
    @pyqtProperty(int, notify=numNeuronsChanged)
    def numNeurons(self):
        return self.num_neurons

    # 权重列表属性
    @pyqtProperty(QVariant, notify=weightsUpdated)
    def weightsList(self):
        """获取权重列表并转换为 QVariantList 格式"""
        return [QVariant([float(w) for w in weight_row]) for weight_row in self.weights.tolist()]

    # 分类结果
    @pyqtProperty(int, notify=classificationChanged)
    def classification(self):
        return self._classification

    @classification.setter
    def classification(self, value):
        if self._classification != value:
            self._classification = value
            self.classificationChanged.emit()



    def train_network(self):
        """训练网络"""
        inputs = np.array([
            [1, 0, 0],  # 样本 1
            [0, 1, 0],  # 样本 2
            [0, 0, 1],  # 样本 3
        ])
        # 开始训练
        for epoch in range(self.epochs):
            for input_vector in inputs:
                distances = np.linalg.norm(self.weights - input_vector, axis=1)
                winner = np.argmin(distances)
                # 更新权重
                self.weights[winner] += self.learning_rate * (input_vector - self.weights[winner])
                norm = np.linalg.norm(self.weights[winner])
                if norm != 0:  # 避免除以0
                    self.weights[winner] /= norm
        self.weightsUpdated.emit()
        self.trainingComplete.emit()

    @pyqtSlot(list)
    def classifySample(self, sample):
        """对输入样本进行分类"""
        sample = np.array(sample)
        if len(sample) != self.input_size:
            print("输入样本大小错误，应为:", self.input_size)
            return
        distances = np.linalg.norm(self.weights - sample, axis=1)
        self.classification = int(np.argmin(distances))
        self.classifyResult.emit(self.classification)

    @pyqtSlot(list)
    def classifySampleWithNoise(self, sample):
        """对带有噪声的输入样本进行分类"""
        sample = np.array(sample)
        noisy_sample = self.add_noise(sample)
        distances = np.linalg.norm(self.weights - noisy_sample, axis=1)
        self.classification = int(np.argmin(distances))
        self.classifyResult.emit(self.classification)

    def add_noise(self, sample):
        """为样本添加噪声"""
        noisy_sample = sample.copy()
        index = np.random.choice(len(sample))
        noisy_sample[index] = 1 - noisy_sample[index]  # 改变该元素的值
        return noisy_sample

    def run(self):
        """开始训练过程"""
        self.train_network()
