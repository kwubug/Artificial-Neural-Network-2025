import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.patches as patches
from PIL import Image
import io

# 基础配置（避免字体警告）
plt.rcParams["font.family"] = ["SimHei", "SimSun"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams['animation.ffmpeg_path'] = 'ffmpeg.exe'  # 若有ffmpeg可启用，无则用PIL生成GIF


class TSPSandboxGIF:
    def __init__(self, num_cities=10):
        # 1. TSP问题初始化
        self.num_cities = num_cities
        self.cities = self.generate_random_cities()
        self.path = list(range(num_cities))
        self.total_distance = self.calculate_total_distance()

        # 2. 记录历史数据（用于生成动图）
        self.path_history = [self.path.copy()]
        self.distance_history = [self.total_distance]

        # 3. 创建可视化界面（非交互式，仅用于生成帧）
        self.fig, (self.ax_map, self.ax_distance) = plt.subplots(1, 2, figsize=(14, 6))
        self.fig.suptitle('TSP问题优化过程（贪心+2-opt）', fontsize=16)

        # 4. 初始化可视化元素
        self.init_map_plot()
        self.init_distance_plot()

        # 5. 存储动图帧
        self.frames = []

    def generate_random_cities(self):
        """生成随机城市坐标（固定种子，可复现）"""
        np.random.seed(42)
        return np.random.rand(self.num_cities, 2) * 10

    def calculate_distance(self, city1, city2):
        """欧氏距离计算"""
        return np.sqrt(np.sum((self.cities[city1] - self.cities[city2]) ** 2))

    def calculate_total_distance(self, path=None):
        """计算闭合路径总距离"""
        if path is None:
            path = self.path
        total = 0
        n = len(path)
        for i in range(n):
            total += self.calculate_distance(path[i], path[(i + 1) % n])
        return total

    def greedy_initialization(self):
        """贪心算法生成初始路径"""
        unvisited = set(range(self.num_cities))
        start = 0
        path = [start]
        unvisited.remove(start)

        while unvisited:
            current = path[-1]
            min_dist = float('inf')
            next_city = None
            for city in unvisited:
                dist = self.calculate_distance(current, city)
                if dist < min_dist:
                    min_dist = dist
                    next_city = city
            path.append(next_city)
            unvisited.remove(next_city)

        self.path = path
        self.total_distance = self.calculate_total_distance()
        self.path_history = [self.path.copy()]
        self.distance_history = [self.total_distance]

    def two_opt_optimize(self):
        """2-opt优化（核心优化逻辑）"""
        n = len(self.path)
        best_path = self.path.copy()
        best_dist = self.total_distance
        improved = True

        while improved:
            improved = False
            for i in range(1, n - 1):
                for j in range(i + 1, n):
                    # 反转i到j的路径片段
                    new_path = best_path.copy()
                    new_path[i:j + 1] = new_path[i:j + 1][::-1]
                    new_dist = self.calculate_total_distance(new_path)

                    if new_dist < best_dist - 1e-6:
                        best_path = new_path
                        best_dist = new_dist
                        improved = True
                        self.path_history.append(best_path.copy())
                        self.distance_history.append(best_dist)

        self.path = best_path
        self.total_distance = best_dist

    def init_map_plot(self):
        """路径地图初始化"""
        # 绘制城市
        self.ax_map.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, edgecolor='black', zorder=5)
        for i, (x, y) in enumerate(self.cities):
            self.ax_map.text(x + 0.1, y + 0.1, str(i), fontsize=12, fontweight='bold')

        # 路径线条
        self.path_line, = self.ax_map.plot([], [], 'b-', linewidth=2, alpha=0.8)
        self.optimize_edge, = self.ax_map.plot([], [], 'r--', linewidth=3, alpha=0.9)

        self.ax_map.set_xlim(-0.5, 10.5)
        self.ax_map.set_ylim(-0.5, 10.5)
        self.ax_map.set_xlabel('X坐标', fontsize=12)
        self.ax_map.set_ylabel('Y坐标', fontsize=12)
        self.ax_map.grid(alpha=0.3)

    def init_distance_plot(self):
        """距离曲线初始化"""
        self.distance_line, = self.ax_distance.plot([], [], 'b-', linewidth=2, label='总距离')
        self.ax_distance.set_xlabel('优化步数', fontsize=12)
        self.ax_distance.set_ylabel('总距离', fontsize=12)
        self.ax_distance.legend()
        self.ax_distance.grid(alpha=0.3)

    def update_frame(self, frame):
        """更新单帧图像"""
        if frame >= len(self.path_history):
            frame = len(self.path_history) - 1

        current_path = self.path_history[frame]
        current_dist = self.distance_history[frame]

        # 更新路径（闭合）
        path_x = [self.cities[city][0] for city in current_path] + [self.cities[current_path[0]][0]]
        path_y = [self.cities[city][1] for city in current_path] + [self.cities[current_path[0]][1]]
        self.path_line.set_data(path_x, path_y)

        # 突出优化的边
        if frame > 0:
            prev_path = self.path_history[frame - 1]
            diff_idx = next(i for i in range(len(current_path)) if current_path[i] != prev_path[i])
            if diff_idx is not None:
                i = diff_idx
                j = (diff_idx + 1) % len(current_path)
                opt_x = [self.cities[current_path[i]][0], self.cities[current_path[j]][0]]
                opt_y = [self.cities[current_path[i]][1], self.cities[current_path[j]][1]]
                self.optimize_edge.set_data(opt_x, opt_y)
        else:
            self.optimize_edge.set_data([], [])

        # 更新距离曲线
        self.distance_line.set_data(range(frame + 1), self.distance_history[:frame + 1])
        self.ax_distance.set_xlim(0, len(self.path_history))
        self.ax_distance.set_ylim(0, max(self.distance_history) * 1.2)

        # 更新标题
        self.ax_map.set_title(f'路径（优化步数：{frame}）\n总距离：{current_dist:.2f}', fontsize=12)
        self.fig.suptitle(f'TSP问题优化过程（城市数：{self.num_cities}）', fontsize=16)

        # 保存当前帧为图像
        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
        buf.seek(0)
        self.frames.append(Image.open(buf))

    def generate_gif(self, filename='tsp_optimization.gif', duration=300):
        """生成GIF文件"""
        # 保存GIF（最后一帧重复5次，让动画结尾停留）
        self.frames += [self.frames[-1]] * 5
        self.frames[0].save(
            filename,
            save_all=True,
            append_images=self.frames[1:],
            duration=duration,  # 每帧时长（毫秒）
            loop=0  # 0表示无限循环
        )
        print(f"GIF动图已保存为：{filename}")

    def run(self):
        """完整流程：优化→生成帧→保存GIF"""
        print("1. 贪心算法生成初始路径...")
        self.greedy_initialization()

        print("2. 2-opt算法优化路径...")
        self.two_opt_optimize()

        print("3. 生成动画帧...")
        # 遍历所有优化步骤，生成帧
        for frame in range(len(self.path_history)):
            self.update_frame(frame)
            if frame % 10 == 0:
                print(f"已生成 {frame}/{len(self.path_history)} 帧")

        print("4. 保存GIF动图...")
        self.generate_gif()

        # 显示最终结果图
        plt.show()
        print(f"\n优化完成！")
        print(f"最优路径：{self.path} → {self.path[0]}")
        print(f"最优总距离：{self.total_distance:.4f}")


if __name__ == "__main__":
    # 初始化并运行（城市数可调整，建议5-15）
    tsp_gif = TSPSandboxGIF(num_cities=10)
    tsp_gif.run()