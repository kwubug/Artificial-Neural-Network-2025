import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.hopfield_algorithm import HopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    # 输入参数
    patterns = BridgeProperty([])
    max_iterations = BridgeProperty(20000)
    ui_refresh_interval = BridgeProperty(0.0)
    initial_state = BridgeProperty([])
    noise_flip_ratio = BridgeProperty(0.0)

    # 运行状态
    has_finished = BridgeProperty(True)
    current_iteration = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    energy_history = BridgeProperty([])
    current_state = BridgeProperty([])
    
    # 吸引子
    attractor_state = BridgeProperty([])
    attractor_energy = BridgeProperty(0.0)
    all_attractors = BridgeProperty([])
    
    # 网络信息
    weights = BridgeProperty([])
    
    # 能量统计
    min_energy = BridgeProperty(0.0)
    max_energy = BridgeProperty(0.0)
    energy_variance = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self._algo = None

    @PyQt5.QtCore.pyqtSlot()
    def start_hopfield(self):
        self._algo = ObservableHopfieldAlgorithm(
            self,
            patterns=self.patterns,
            max_iterations=self.max_iterations,
            ui_refresh_interval=self.ui_refresh_interval,
            initial_state=(self.initial_state if self.initial_state else None),
            noise_flip_ratio=self.noise_flip_ratio
        )
        self._algo.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_hopfield(self):
        if self._algo:
            self._algo.stop()


class ObservableHopfieldAlgorithm(Observable, HopfieldAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        object.__setattr__(self, '_obs_ready', False)
        HopfieldAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, '_obs_ready', True)
        
        # 初始化推送
        self.notify('weights', self.weights.tolist())
        self.notify('current_state', self.state.tolist())
        self.notify('current_energy', self.current_energy)
        self.notify('all_attractors', [])

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_obs_ready', False):
            return
        if name in ('current_iteration', 'current_energy'):
            self.notify(name, value)
            # 推送状态与能量序列
            try:
                self.notify('current_state', self.state.tolist())
            except Exception:
                pass
        elif name in ('has_finished', 'attractor_state', 'attractor_energy'):
            if name == 'attractor_state' and value is not None:
                try:
                    self.notify('attractor_state', value.tolist())
                except Exception:
                    self.notify('attractor_state', value)
            else:
                self.notify(name, value)
        elif name in ('min_energy', 'max_energy', 'energy_variance'):
            self.notify(name, value)

    def run(self):
        # 开始运行
        self.notify('has_finished', False)
        self.notify('energy_history', [])
        self.notify('all_attractors', [])
        
        # 执行算法
        super().run()
        
        # 完成后推送最终结果
        self.notify('current_state', self.state.tolist())
        self.notify('current_energy', self.current_energy)
        self.notify('energy_history', self.energy_history)
        self.notify('attractor_state', self.attractor_state.tolist())
        self.notify('attractor_energy', self.attractor_energy)
        
        # 能量统计
        self.notify('min_energy', self.min_energy)
        self.notify('max_energy', self.max_energy)
        self.notify('energy_variance', self.energy_variance)
        
        # 吸引子列表
        attractors_list = [
            {
                'state': att['state'].tolist(),
                'energy': att['energy'],
                'count': att['count']
            }
            for att in self.all_attractors
        ]
        self.notify('all_attractors', attractors_list)
        
        self.notify('has_finished', True)

