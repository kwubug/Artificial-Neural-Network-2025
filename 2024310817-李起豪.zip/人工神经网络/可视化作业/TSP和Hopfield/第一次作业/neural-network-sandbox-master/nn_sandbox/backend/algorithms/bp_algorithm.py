import collections
import math
import random

import numpy as np

from . import PredictiveAlgorithm


class BPAlgorithm(PredictiveAlgorithm):
    """
    三层前馈神经网络的BP学习算法实现
    根据题目要求实现以下功能：
    1. 允许选择各层节点数
    2. 允许选用不同的学习率η
    3. 能对权值进行初始化，初始化用[-1,1]区间的随机数
    4. 允许选用单极性或双极性两种不同Sigmoid型变换函数
    """

    def __init__(self, dataset, total_epoches=1000, most_correct_rate=None,
                 initial_learning_rate=0.1, search_iteration_constant=10000,
                 test_ratio=0.3, 
                 # 新增参数
                 input_nodes=2, hidden_nodes=5, output_nodes=1,
                 sigmoid_type='unipolar',  # 'unipolar' 或 'bipolar'
                 convergence_threshold=0.01):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        # 网络结构参数
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.sigmoid_type = sigmoid_type
        self.convergence_threshold = convergence_threshold
        
        # 网络权重和偏置
        self.weights_input_hidden = None  # 输入层到隐藏层权重
        self.weights_hidden_output = None  # 隐藏层到输出层权重
        self.bias_hidden = None  # 隐藏层偏置
        self.bias_output = None  # 输出层偏置
        
        # 用于存储前一次权重更新（动量项）
        self.prev_delta_weights_input_hidden = None
        self.prev_delta_weights_hidden_output = None
        self.prev_delta_bias_hidden = None
        self.prev_delta_bias_output = None
        
        # 训练历史
        self.training_errors = []
        self.current_epoch = 0
        self.converged = False

    def _initialize_neurons(self):
        """初始化网络权重和偏置，使用[-1,1]区间的随机数"""
        # 初始化权重矩阵
        self.weights_input_hidden = np.random.uniform(-1, 1, (self.input_nodes, self.hidden_nodes))
        self.weights_hidden_output = np.random.uniform(-1, 1, (self.hidden_nodes, self.output_nodes))
        
        # 初始化偏置
        self.bias_hidden = np.random.uniform(-1, 1, (1, self.hidden_nodes))
        self.bias_output = np.random.uniform(-1, 1, (1, self.output_nodes))
        
        # 初始化动量项
        self.prev_delta_weights_input_hidden = np.zeros_like(self.weights_input_hidden)
        self.prev_delta_weights_hidden_output = np.zeros_like(self.weights_hidden_output)
        self.prev_delta_bias_hidden = np.zeros_like(self.bias_hidden)
        self.prev_delta_bias_output = np.zeros_like(self.bias_output)

    def _sigmoid(self, x):
        """Sigmoid激活函数"""
        if self.sigmoid_type == 'unipolar':
            # 单极性Sigmoid函数: f(x) = 1/(1+e^(-x))
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))  # 防止溢出
        else:  # bipolar
            # 双极性Sigmoid函数: f(x) = 2/(1+e^(-x)) - 1
            return 2 / (1 + np.exp(-np.clip(x, -500, 500))) - 1

    def _sigmoid_derivative(self, x):
        """Sigmoid函数的导数"""
        if self.sigmoid_type == 'unipolar':
            # 单极性Sigmoid导数: f'(x) = f(x) * (1 - f(x))
            return x * (1 - x)
        else:  # bipolar
            # 双极性Sigmoid导数: f'(x) = 0.5 * (1 + f(x)) * (1 - f(x))
            return 0.5 * (1 + x) * (1 - x)

    def _forward_propagation(self, inputs):
        """前向传播"""
        # 输入层到隐藏层
        hidden_input = np.dot(inputs, self.weights_input_hidden) + self.bias_hidden
        hidden_output = self._sigmoid(hidden_input)
        
        # 隐藏层到输出层
        output_input = np.dot(hidden_output, self.weights_hidden_output) + self.bias_output
        output = self._sigmoid(output_input)
        
        return hidden_output, output

    def _backward_propagation(self, inputs, hidden_output, output, target):
        """反向传播计算误差信号"""
        # 输出层误差
        output_error = target - output
        output_delta = output_error * self._sigmoid_derivative(output)
        
        # 隐藏层误差
        hidden_error = np.dot(output_delta, self.weights_hidden_output.T)
        hidden_delta = hidden_error * self._sigmoid_derivative(hidden_output)
        
        return hidden_delta, output_delta

    def _update_weights(self, inputs, hidden_output, hidden_delta, output_delta, learning_rate, momentum=0.9):
        """更新权重和偏置"""
        # 计算权重更新量
        delta_weights_hidden_output = learning_rate * np.dot(hidden_output.T, output_delta)
        delta_weights_input_hidden = learning_rate * np.dot(inputs.T, hidden_delta)
        
        delta_bias_output = learning_rate * output_delta
        delta_bias_hidden = learning_rate * hidden_delta
        
        # 添加动量项
        delta_weights_hidden_output += momentum * self.prev_delta_weights_hidden_output
        delta_weights_input_hidden += momentum * self.prev_delta_weights_input_hidden
        delta_bias_output += momentum * self.prev_delta_bias_output
        delta_bias_hidden += momentum * self.prev_delta_bias_hidden
        
        # 更新权重和偏置
        self.weights_hidden_output += delta_weights_hidden_output
        self.weights_input_hidden += delta_weights_input_hidden
        self.bias_output += delta_bias_output
        self.bias_hidden += delta_bias_hidden
        
        # 保存本次更新量用于下次动量计算
        self.prev_delta_weights_hidden_output = delta_weights_hidden_output
        self.prev_delta_weights_input_hidden = delta_weights_input_hidden
        self.prev_delta_bias_output = delta_bias_output
        self.prev_delta_bias_hidden = delta_bias_hidden

    def _iterate(self):
        """单次迭代（处理一个样本）"""
        # 获取当前样本
        sample = self.current_data
        inputs = np.array(sample[:-1]).reshape(1, -1)  # 输入特征
        target = np.array(sample[-1]).reshape(1, -1)   # 目标输出
        
        # 前向传播
        hidden_output, output = self._forward_propagation(inputs)
        
        # 反向传播
        hidden_delta, output_delta = self._backward_propagation(inputs, hidden_output, output, target)
        
        # 更新权重
        self._update_weights(inputs, hidden_output, hidden_delta, output_delta, self.current_learning_rate)

    def run(self):
        """运行BP训练算法，按照流程图实现批训练"""
        self._initialize_neurons()
        
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
                
            self.current_epoch = epoch
            epoch_error = 0
            
            # 打乱训练数据
            np.random.shuffle(self.training_dataset)
            
            # 批训练：处理所有训练样本
            for sample in self.training_dataset:
                inputs = np.array(sample[:-1]).reshape(1, -1)
                target = np.array(sample[-1]).reshape(1, -1)
                
                # 前向传播
                hidden_output, output = self._forward_propagation(inputs)
                
                # 计算误差
                error = 0.5 * np.sum((target - output) ** 2)
                epoch_error += error
                
                # 反向传播
                hidden_delta, output_delta = self._backward_propagation(inputs, hidden_output, output, target)
                
                # 更新权重
                self._update_weights(inputs, hidden_output, hidden_delta, output_delta, self.current_learning_rate)
            
            # 计算平均误差
            avg_error = epoch_error / len(self.training_dataset)
            self.training_errors.append(avg_error)
            
            # 检查收敛条件
            if avg_error < self.convergence_threshold:
                self.converged = True
                break
            
            # 更新当前迭代次数（用于学习率衰减）
            self.current_iterations = epoch * len(self.training_dataset)
            
            # 保存最佳模型
            self._save_best_neurons()
            
            # 检查是否达到目标正确率
            if self._most_correct_rate and self.best_correct_rate >= self._most_correct_rate:
                break

    def _correct_rate(self, dataset):
        """计算正确率"""
        if self.weights_input_hidden is None:
            return 0
            
        correct_count = 0
        for sample in dataset:
            inputs = np.array(sample[:-1]).reshape(1, -1)
            target = sample[-1]
            
            # 前向传播
            _, output = self._forward_propagation(inputs)
            predicted = output[0, 0]
            
            # 根据激活函数类型判断预测结果
            if self.sigmoid_type == 'unipolar':
                # 单极性：输出接近1表示正类，接近0表示负类
                predicted_class = 1 if predicted > 0.5 else 0
            else:
                # 双极性：输出接近1表示正类，接近-1表示负类
                predicted_class = 1 if predicted > 0 else -1
            
            # 检查预测是否正确
            if abs(predicted_class - target) < 0.1:  # 允许小的误差
                correct_count += 1
        
        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def predict(self, inputs):
        """预测函数"""
        if self.weights_input_hidden is None:
            return None
            
        inputs = np.array(inputs).reshape(1, -1)
        _, output = self._forward_propagation(inputs)
        return output[0, 0]

    def get_training_info(self):
        """获取训练信息"""
        return {
            'current_epoch': self.current_epoch,
            'converged': self.converged,
            'final_error': self.training_errors[-1] if self.training_errors else 0,
            'training_errors': self.training_errors.copy()
        }
