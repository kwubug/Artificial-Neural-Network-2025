import time
import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.ols_algorithm import OlsAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsBridge(Bridge):
    # 可视化与训练参数
    ui_refresh_interval = BridgeProperty(0.05)
    total_epoches = BridgeProperty(1000)
    learning_rate = BridgeProperty(0.01)

    # 数据与模型参数
    points = BridgeProperty([])  # [[x, y], ...]
    w = BridgeProperty(0.0)
    b = BridgeProperty(0.0)
    loss = BridgeProperty(0.0)
    current_iterations = BridgeProperty(0)
    has_finished = BridgeProperty(True)

    # 解析解 (用于对比显示)
    best_w = BridgeProperty(0.0)
    best_b = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self._algorithm = None

    @PyQt5.QtCore.pyqtSlot(float, float)
    def add_point(self, x, y):
        pts = list(self.points)
        pts.append([float(x), float(y)])
        self.points = pts
        self._update_analytical_solution()

    @PyQt5.QtCore.pyqtSlot()
    def clear_points(self):
        self.points = []
        self._update_analytical_solution()

    @PyQt5.QtCore.pyqtSlot()
    def reset_params(self):
        self.w = 0.0
        self.b = 0.0
        self.loss = 0.0
        self.current_iterations = 0

    @PyQt5.QtCore.pyqtSlot()
    def start_ols_algorithm(self):
        self._algorithm = ObservableOlsAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.points,
            total_epoches=self.total_epoches,
            initial_learning_rate=self.learning_rate
        )
        # 初始同步参数
        self._algorithm.set_params(self.w, self.b)
        self._algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols_algorithm(self):
        if self._algorithm is not None:
            self._algorithm.stop()

    def _update_analytical_solution(self):
        # 使用 numpy.polyfit 求解析解直线 (最小二乘)
        try:
            pts = np.array(self.points)
            if pts.shape[0] >= 2:
                m, c = np.polyfit(pts[:, 0], pts[:, 1], 1)
                self.best_w = float(m)
                self.best_b = float(c)
            else:
                self.best_w = 0.0
                self.best_b = 0.0
        except Exception:
            self.best_w = 0.0
            self.best_b = 0.0


class ObservableOlsAlgorithm(Observable, OlsAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        OlsAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 迭代时更新 UI
        if name == 'current_iterations':
            self.notify(name, value)
        elif name in ('w', 'b', 'loss'):
            self.notify(name, value)

    def run(self):
        # 通知 UI 已开始
        self.notify('has_finished', False)
        try:
            super().run()
        finally:
            # 通知 UI 已结束
            self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 避免阻塞 UI
        time.sleep(self.ui_refresh_interval)