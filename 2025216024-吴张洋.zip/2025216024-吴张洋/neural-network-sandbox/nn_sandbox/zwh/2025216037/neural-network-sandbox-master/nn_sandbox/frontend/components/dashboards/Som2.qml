import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'SOM2'

    ColumnLayout {
        // 左侧控制面板
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            Label {
                anchors.fill: parent
                text: '5×5 Fixed Input Patterns'
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }

        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label {
                    text: 'Total Training Steps'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalSteps
                    enabled: som2Bridge ? som2Bridge.has_finished : false
                    editable: true
                    value: 10000
                    from: 1000
                    to: 50000
                    onValueChanged: if(som2Bridge) som2Bridge.total_epoches = value
                    Component.onCompleted: if(som2Bridge) som2Bridge.total_epoches = value
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Initial Learning Rate η(0)'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: som2Bridge ? som2Bridge.has_finished : false
                    editable: true
                    value: 0.50 * 100
                    from: 0.01 * 100
                    to: 1.00 * 100
                    onValueChanged: if(som2Bridge) som2Bridge.initial_learning_rate = value / 100
                    Component.onCompleted: if(som2Bridge) som2Bridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Initial Neighborhood σ(0)'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: som2Bridge ? som2Bridge.has_finished : false
                    editable: true
                    value: 2.0 * 100
                    from: 0.5 * 100
                    to: 5.0 * 100
                    onValueChanged: if(som2Bridge) som2Bridge.initial_standard_deviation = value / 100
                    Component.onCompleted: if(som2Bridge) som2Bridge.initial_standard_deviation = value / 100
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Topology Shape'
                    Layout.alignment: Qt.AlignHCenter
                }
                RowLayout {
                    Layout.fillWidth: true
                    SpinBox {
                        enabled: false
                        value: 5
                        Layout.fillWidth: true
                    }
                    Label { text: '×' }
                    SpinBox {
                        enabled: false
                        value: 5
                        Layout.fillWidth: true
                    }
                }

                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: som2Bridge ? som2Bridge.has_finished : false
                    editable: true
                    value: 0.05 * 100
                    from: 0 * 100
                    to: 0.5 * 100
                    onValueChanged: if(som2Bridge) som2Bridge.ui_refresh_interval = value / 100
                    Component.onCompleted: if(som2Bridge) som2Bridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: 'Training Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2

                ExecutionControls {
                    startButton.enabled: som2Bridge ? som2Bridge.has_finished : false
                    startButton.onClicked: if(som2Bridge) som2Bridge.start_som2_algorithm()
                    stopButton.enabled: som2Bridge ? !som2Bridge.has_finished : false
                    stopButton.onClicked: if(som2Bridge) som2Bridge.stop_som2_algorithm()
                    progressBar.value: som2Bridge ? (som2Bridge.current_iterations / totalSteps.value) : 0
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Current Step'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: som2Bridge ? som2Bridge.current_iterations : "0"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Current η(t)'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: som2Bridge ? som2Bridge.current_learning_rate.toFixed(6) : "0.000000"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label {
                    text: 'Current σ(t)'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: som2Bridge ? som2Bridge.current_standard_deviation.toFixed(6) : "0.000000"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label {
                    text: '衰减到0.04时的步数'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: '10000步'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label {
                    text: '保存的映射图数量'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: som2Bridge ? Math.floor(som2Bridge.current_iterations / 200) : "0"
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }

        // 输入模式映射结果
        GroupBox {
            title: '输入模式映射结果'
            Layout.fillWidth: true

            RowLayout {
                anchors.fill: parent
                spacing: 5

                Repeater {
                    model: 5

                    Rectangle {
                        width: 60
                        height: 60
                        color: ["#ff6b6b", "#4dabf7", "#51cf66", "#ffd43b", "#ff63e6"][index]
                        radius: 5

                        ColumnLayout {
                            anchors.centerIn: parent
                            spacing: 2

                            Label {
                                text: "X" + (index + 1)
                                color: "white"
                                font.bold: true
                                font.pixelSize: 16
                                horizontalAlignment: Text.AlignHCenter
                                Layout.alignment: Qt.AlignHCenter
                            }

                            Label {
                                id: mappingLabel
                                property int mappingRow: -1
                                property int mappingCol: -1
                                text: "?"
                                color: "white"
                                font.pixelSize: 12
                                horizontalAlignment: Text.AlignHCenter
                                Layout.alignment: Qt.AlignHCenter
                            }
                        }
                    }
                }
            }
        }
    }

    // 右侧图表
    ColumnLayout {
        DataChart {
            id: dataChart
            property var neuronScatter
            property var neuronTopology: []
            property var inputPatterns: []

            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true

            // 初始化时设置数据集
            Component.onCompleted: {
                // 设置初始数据（5个输入模式）
                const initialData = [
                    [1, 0, 0, 0],
                    [1, 1, 0, 0],
                    [1, 1, 1, 0],
                    [0, 1, 0, 0],
                    [1, 1, 1, 1]
                ]
                dataChart.updateDataset(initialData)

                // 监听权重更新
                if (som2Bridge && som2Bridge.current_synaptic_weights.length > 0) {
                    dataChart.updateNeuron()
                }
            }

            // 监听权重变化
            Connections {
                target: som2Bridge
                function onCurrent_iterationsChanged() {
                    if(dataChart) dataChart.updateNeuron()
                }
            }

            // 将所有函数定义为DataChart的方法
            function updateNeuron() {
                if (!som2Bridge || som2Bridge.current_synaptic_weights.length === 0) {
                    return
                }
                updateNeuronTopology()
                updateNeuronScatter()
                updateInputPatterns()
            }

            function updateNeuronScatter() {
                if (neuronScatter) {
                    removeSeries(neuronScatter)
                }

                const weights = som2Bridge ? som2Bridge.current_synaptic_weights : []
                if (!weights || weights.length === 0) return

                neuronScatter = createHoverableScatterSeries('SOM2 Neurons')
                neuronScatter.color = 'black'
                neuronScatter.markerSize = 8

                // 只显示前2维
                for (let row of weights) {
                    for (let synaptic_weight of row) {
                        if (synaptic_weight && synaptic_weight.length >= 2) {
                            neuronScatter.append(synaptic_weight[0], synaptic_weight[1])
                        }
                    }
                }
            }

            function updateNeuronTopology() {
                neuronTopology.forEach(line => {removeSeries(line)})
                neuronTopology = []

                const weights = som2Bridge ? som2Bridge.current_synaptic_weights : []
                if (!weights || weights.length === 0) return

                // 提取前2维用于可视化
                let weights2D = []
                for (let row of weights) {
                    let row2D = []
                    for (let weight of row) {
                        if (weight && weight.length >= 2) {
                            row2D.push([weight[0], weight[1]])
                        }
                    }
                    if (row2D.length > 0) {
                        weights2D.push(row2D)
                    }
                }

                if (weights2D.length > 0) {
                    createMapLines(weights2D)
                    if (weights2D[0]) {
                        const transposed = weights2D[0].map(
                            (col, i) => weights2D.map(row => row[i])
                        )
                        createMapLines(transposed)
                    }
                }
            }

            function updateInputPatterns() {
                // 清除旧的输入模式标记
                inputPatterns.forEach(pattern => {removeSeries(pattern)})
                inputPatterns = []

                const weights = som2Bridge ? som2Bridge.current_synaptic_weights : []
                if (!weights || weights.length === 0) return

                const patterns = [
                    [1, 0, 0, 0],
                    [1, 1, 0, 0],
                    [1, 1, 1, 0],
                    [0, 1, 0, 0],
                    [1, 1, 1, 1]
                ]

                const colors = ["#ff6b6b", "#4dabf7", "#51cf66", "#ffd43b", "#ff63e6"]
                const names = ["X¹", "X²", "X³", "X⁴", "X⁵"]

                for (let i = 0; i < patterns.length; i++) {
                    // 找到最佳匹配单元
                    const bmu = findBMU(patterns[i])
                    if (bmu !== null) {
                        const weight = weights[bmu.row][bmu.col]
                        if (weight && weight.length >= 2) {
                            const scatter = createHoverableScatterSeries(names[i])
                            scatter.color = colors[i]
                            scatter.markerSize = 16
                            scatter.borderWidth = 2
                            scatter.borderColor = 'white'
                            scatter.append(weight[0], weight[1])
                            inputPatterns.push(scatter)

                            // 更新映射标签
                            updateMappingLabel(i, bmu.row, bmu.col)
                        }
                    }
                }
            }

            function findBMU(pattern) {
                const weights = som2Bridge ? som2Bridge.current_synaptic_weights : []
                if (!weights || weights.length === 0) return null

                let minDist = Infinity
                let bmuRow = 0
                let bmuCol = 0

                for (let i = 0; i < weights.length; i++) {
                    for (let j = 0; j < weights[i].length; j++) {
                        if (weights[i][j] && weights[i][j].length >= 4) {
                            let dist = 0
                            for (let k = 0; k < 4; k++) {
                                dist += Math.pow(pattern[k] - weights[i][j][k], 2)
                            }
                            dist = Math.sqrt(dist)

                            if (dist < minDist) {
                                minDist = dist
                                bmuRow = i
                                bmuCol = j
                            }
                        }
                    }
                }

                return {row: bmuRow, col: bmuCol}
            }

            function updateMappingLabel(index, row, col) {
                // 更新输入模式映射结果框中的标签
                const mappingBox = parent.parent.children[0].children[3]
                if (mappingBox && mappingBox.children[0] && mappingBox.children[0].children[index]) {
                    const rect = mappingBox.children[0].children[index]
                    if (rect && rect.children[0] && rect.children[0].children[1]) {
                        rect.children[0].children[1].text = "(" + row + "," + col + ")"
                        rect.children[0].children[1].mappingRow = row
                        rect.children[0].children[1].mappingCol = col
                    }
                }
            }

            function createMapLines(synaptic_weights) {
                for (let row of synaptic_weights) {
                    const line = createSeries(
                        ChartView.SeriesTypeLine, '', xAxis, yAxis
                    )
                    line.color = 'grey'
                    neuronTopology.push(line)
                    for (let synaptic_weight of row) {
                        if (synaptic_weight && synaptic_weight.length >= 2) {
                            line.append(synaptic_weight[0], synaptic_weight[1])
                        }
                    }
                }
            }

            function clear() {
                removeAllSeries()
                scatterSeriesMap = {}
                neuronTopology = []
                inputPatterns = []
            }
        }
    }
}