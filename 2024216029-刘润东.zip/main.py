import os
import sys

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets

from nn_sandbox.bridges import (PerceptronBridge, MlpBridge, RbfnBridge, SomBridge,
                                 BmBridge, HopfieldBridge, TspBridge, BPnetworkBridge,
                                 SteepestDescentBridge, NewtonBridge, ConjugateGradientBridge,
                                 OLSBridge)
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    # XXX: Why I Have To Use QApplication instead of QGuiApplication? It seams
    # QGuiApplication cannot load QML Chart libs!
    app = PyQt5.QtWidgets.QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    # 创建原有的bridges（需要dataset_dict）
    dataset_bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'BPnetworkBridge': BPnetworkBridge(),
        'olsBridge': OLSBridge()
    }
    
    # 创建新增的bridges（不需要dataset_dict）
    new_bridges = {
        'bmBridge': BmBridge(),
        'hopfieldBridge': HopfieldBridge(),
        'tspBridge': TspBridge(),
        'steepestDescentBridge': SteepestDescentBridge(),
        'newtonBridge': NewtonBridge(),
        'conjugateGradientBridge': ConjugateGradientBridge()
    }
    
    # 为原有bridges设置dataset_dict
    dataset_dict = nn_sandbox.backend.utils.read_data()
    for name, bridge in dataset_bridges.items():
        bridge.dataset_dict = dataset_dict
        engine.rootContext().setContextProperty(name, bridge)
    
    # 注册新bridges
    for name, bridge in new_bridges.items():
        engine.rootContext().setContextProperty(name, bridge)

    engine.load('./nn_sandbox/frontend/main.qml')
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())
