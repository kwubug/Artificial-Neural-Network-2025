import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3

Item {
    id: root
    property string name: "梯度下降"
    property var gradientDescentBridge

    // 添加标志位防止重复更新
    property bool isUpdating: false

    ColumnLayout {
        anchors.fill: parent
        spacing: 10

        // 标题
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: "优化算法可视化"
            font.pixelSize: 18
            font.bold: true
        }

        // 控制面板
        GroupBox {
            Layout.fillWidth: true
            title: "算法设置"

            RowLayout {
                width: parent.width

                Label { text: "算法类型:" }
                ComboBox {
                    id: algorithmCombo
                    model: ["最速下降法", "牛顿法", "共轭梯度法"]
                    onCurrentIndexChanged: {
                        var types = ["steepest_descent", "newton_method", "conjugate_gradient"]
                        gradientDescentBridge.setAlgorithmType(types[currentIndex])
                    }
                }

                Label { text: "迭代次数:" }
                SpinBox {
                    id: iterationsSpin
                    from: 10
                    to: 1000
                    value: 100
                    onValueChanged: gradientDescentBridge.setIterations(value)
                }

                Button {
                    id: startButton
                    text: "开始优化"
                    onClicked: {
                        startButton.enabled = false
                        gradientDescentBridge.startVisualization()
                        // 延迟启用按钮，避免重复点击
                        enableTimer.start()
                    }
                }
            }
        }

        // 图表区域
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10

            // 损失函数图表
            ChartView {
                Layout.preferredWidth: parent.width / 2
                Layout.fillHeight: true
                title: "损失函数收敛曲线"
                antialiasing: true

                ValueAxis {
                    id: axisX1
                    min: 0
                    max: 100
                    titleText: "迭代次数"
                }

                ValueAxis {
                    id: axisY1
                    min: 0
                    max: 50
                    titleText: "损失值"
                }

                LineSeries {
                    id: lossSeries
                    name: "损失值"
                    axisX: axisX1
                    axisY: axisY1
                }
            }

            // 梯度变化图表
            ChartView {
                Layout.preferredWidth: parent.width / 2
                Layout.fillHeight: true
                title: "梯度范数变化曲线"
                antialiasing: true

                ValueAxis {
                    id: axisX2
                    min: 0
                    max: 100
                    titleText: "迭代次数"
                }

                ValueAxis {
                    id: axisY2
                    min: 0
                    max: 50
                    titleText: "梯度范数"
                }

                LineSeries {
                    id: gradientSeries
                    name: "梯度范数"
                    axisX: axisX2
                    axisY: axisY2
                    color: "red"
                }
            }
        }

        // 状态信息
        GroupBox {
            Layout.fillWidth: true
            title: "优化信息"

            Text {
                id: statusText
                text: gradientDescentBridge.currentStatus
                font.pixelSize: 14
                color: gradientDescentBridge.isRunning ? "orange" : "green"
            }
        }
    }

    // 启用按钮的定时器
    Timer {
        id: enableTimer
        interval: 1000
        onTriggered: startButton.enabled = true
    }

    // 图表更新定时器 - 添加安全保护
    Timer {
        id: updateTimer
        interval: 500  // 降低更新频率
        running: false
        repeat: true
        onTriggered: {
            if (!isUpdating) {
                isUpdating = true
                updateCharts()
                isUpdating = false
            }
        }
    }

    // 连接桥接器的信号
    Connections {
        target: gradientDescentBridge
        function onIsRunningChanged() {
            if (gradientDescentBridge.isRunning) {
                updateTimer.running = true
            } else {
                updateTimer.running = false
                updateCharts() // 最终更新一次
                startButton.enabled = true
            }
        }
    }

    function updateCharts() {
        try {
            // 安全地更新图表
            if (gradientDescentBridge.lossHistory.length === 0) return;

            // 更新损失图表
            lossSeries.clear()
            var losses = gradientDescentBridge.lossHistory
            var maxPoints = Math.min(100, losses.length) // 限制点数

            for (var i = 0; i < maxPoints; i++) {
                var idx = Math.floor(i * losses.length / maxPoints)
                lossSeries.append(idx, losses[idx])
            }

            // 更新梯度图表
            gradientSeries.clear()
            var gradients = gradientDescentBridge.gradientNorms
            maxPoints = Math.min(100, gradients.length)

            for (var j = 0; j < maxPoints; j++) {
                var idx2 = Math.floor(j * gradients.length / maxPoints)
                gradientSeries.append(idx2, gradients[idx2])
            }

        } catch (error) {
            console.log("图表更新错误:", error)
        }
    }

    Component.onCompleted: {
        algorithmCombo.currentIndex = 0
        iterationsSpin.value = 100
    }
}