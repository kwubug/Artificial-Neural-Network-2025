import time
import threading
import numpy as np

from . import TraningAlgorithm


class HopfieldAlgorithm(TraningAlgorithm):
    """
    离散Hopfield神经网络
    
    核心功能：
    1. 异步更新：每次随机选择一个神经元更新
    2. 吸引子检测：自动检测网络收敛到的稳定状态
    3. 能量计算：E = -1/2 * s^T * W * s
    
    网络特性：
    - 状态：{-1, +1}
    - 权重：通过Hebb规则学习 W = sum(p * p^T)，对角线为0
    - 更新规则：s_i = sign(sum(W_ij * s_j))
    """

    def __init__(
        self,
        patterns,
        max_iterations=20000,
        ui_refresh_interval=0.0,
        initial_state=None,
        noise_flip_ratio=0.0
    ):
        """
        初始化Hopfield网络
        
        参数：
            patterns: 要存储的模式列表，每个模式是一个向量
            max_iterations: 最大迭代次数
            ui_refresh_interval: UI刷新间隔（秒）
            initial_state: 初始状态（可选）
            noise_flip_ratio: 噪声翻转比例（0-1）
        """
        super().__init__(dataset=[], total_epoches=1)
        
        # 存储模式并构建权重
        self._patterns = self._normalize_patterns(np.array(patterns, dtype=float))
        self._n = self._patterns.shape[1]  # 神经元数量
        self._weights = self._build_hebb_weights(self._patterns)
        
        # 运行参数
        self._max_iterations = int(max_iterations)
        self._ui_refresh_interval = float(ui_refresh_interval)
        
        # 初始化状态
        if initial_state is not None:
            self._state = self._bipolarize(np.array(initial_state, dtype=float))
            if self._state.shape[0] != self._n:
                raise ValueError(f'初始状态维度不匹配：期望{self._n}，得到{self._state.shape[0]}')
        else:
            self._state = np.random.choice([-1.0, 1.0], size=self._n)
        
        # 添加噪声
        if noise_flip_ratio > 0:
            flip_mask = np.random.rand(self._n) < float(noise_flip_ratio)
            self._state[flip_mask] *= -1.0
        
        # 运行状态
        self.current_iteration = 0
        self.current_energy = self._energy(self._state)
        self.energy_history = []
        self.attractor_state = None
        self.attractor_energy = None
        self.has_finished = True
        
        # 吸引子记录
        self.all_attractors = []
        
        # 能量统计
        self.min_energy = float('inf')
        self.max_energy = float('-inf')
        self.energy_variance = 0.0
        
        # 线程安全（使用RLock允许同一线程多次获取锁）
        self._lock = threading.RLock()
        self._stable_count = 0
        self._stable_threshold = 50  # 连续50步不变则认为稳定
        self._last_state = self._state.copy()

    @staticmethod
    def _bipolarize(x):
        """将输入转换为{-1, +1}"""
        x = np.array(x, dtype=float)
        return np.where(x > 0, 1.0, -1.0)
    
    def _normalize_patterns(self, patterns):
        """标准化所有模式为{-1, +1}"""
        return np.array([self._bipolarize(p) for p in patterns])
    
    def _build_hebb_weights(self, patterns):
        """使用Hebb规则构建权重矩阵
        
        W = (1/n) * sum(p * p^T)，对角线为0
        """
        n = patterns.shape[1]
        W = np.zeros((n, n), dtype=float)
        for p in patterns:
            W += np.outer(p, p)
        np.fill_diagonal(W, 0.0)
        return W / n  # 归一化增强稳定性
    
    def _energy(self, state):
        """计算当前状态的能量
        
        E = -1/2 * s^T * W * s
        """
        return float(-0.5 * state.T.dot(self._weights).dot(state))
    
    def _is_stable(self):
        """检查是否达到稳定状态（吸引子）"""
        return self._stable_count >= self._stable_threshold
    
    def _add_attractor(self, state, energy):
        """记录吸引子"""
        # 检查是否已存在
        for att in self.all_attractors:
            if np.array_equal(att['state'], state):
                att['count'] += 1
                return
        
        # 添加新吸引子
        self.all_attractors.append({
            'state': state.copy(),
            'energy': energy,
            'count': 1
        })
    
    def _update_energy_statistics(self):
        """更新能量统计"""
        if len(self.energy_history) > 0:
            self.min_energy = float(np.min(self.energy_history))
            self.max_energy = float(np.max(self.energy_history))
            self.energy_variance = float(np.var(self.energy_history))

    def run(self):
        """运行Hopfield网络直到收敛到吸引子"""
        with self._lock:
            self.has_finished = False
            self.energy_history = []
            self.all_attractors = []
            self.current_iteration = 0
        
        # 主循环：异步更新
        for iteration in range(1, self._max_iterations + 1):
            if self._should_stop:
                break
            
            with self._lock:
                self.current_iteration = iteration
                
                # 异步更新：随机选择一个神经元
                i = np.random.randint(0, self._n)
                
                # 计算该神经元的输入
                net_i = np.dot(self._weights[i], self._state)
                
                # 更新状态
                new_value = 1.0 if net_i >= 0 else -1.0
                self._state[i] = new_value
                
                # 计算能量
                self.current_energy = self._energy(self._state)
                self.energy_history.append(self.current_energy)
                
                # 检测稳定性
                if np.array_equal(self._state, self._last_state):
                    self._stable_count += 1
                else:
                    self._stable_count = 0
                    self._last_state = self._state.copy()
                
                # 达到吸引子
                if self._is_stable():
                    self.attractor_state = self._state.copy()
                    self.attractor_energy = self.current_energy
                    self._add_attractor(self.attractor_state, self.attractor_energy)
                    break
            
            # UI刷新控制
            if self._ui_refresh_interval > 0:
                time.sleep(self._ui_refresh_interval)
            else:
                # 每次迭代都释放GIL，确保UI响应
                time.sleep(0.0001)
        
        # 完成
        with self._lock:
            if self.attractor_state is None:
                # 未收敛，使用当前状态作为吸引子
                self.attractor_state = self._state.copy()
                self.attractor_energy = self.current_energy
                self._add_attractor(self.attractor_state, self.attractor_energy)
            
            self._update_energy_statistics()
            self.has_finished = True

    @property
    def weights(self):
        """获取权重矩阵"""
        return self._weights.copy()
    
    @property
    def state(self):
        """获取当前状态"""
        with self._lock:
            return self._state.copy()
    
    @property
    def n(self):
        """获取神经元数量"""
        return self._n
    
    @property
    def patterns(self):
        """获取存储的模式"""
        return self._patterns.copy()
