import sys
import numpy as np
import random
import math
from sklearn.datasets import make_classification, make_moons, make_circles
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QSplitter, QProgressBar,
                             QComboBox, QCheckBox, QSpinBox)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

class BPNeuralNetwork:
    """BP神经网络算法"""
    
    def __init__(self, layers, learning_rate=0.1):
        self.layers = layers  # 网络结构，如 [2, 4, 1]
        self.learning_rate = learning_rate
        self.weights = []
        self.biases = []
        self.initialize_weights()
        
        # 训练历史记录
        self.loss_history = []
        self.accuracy_history = []
        self.weights_history = []
        self.gradients_history = []
        
    def initialize_weights(self):
        """初始化权重和偏置"""
        self.weights = []
        self.biases = []
        
        for i in range(len(self.layers) - 1):
            # Xavier初始化
            limit = np.sqrt(6 / (self.layers[i] + self.layers[i+1]))
            weight = np.random.uniform(-limit, limit, (self.layers[i], self.layers[i+1]))
            bias = np.zeros((1, self.layers[i+1]))
            
            self.weights.append(weight)
            self.biases.append(bias)
    
    def sigmoid(self, x):
        """Sigmoid激活函数"""
        return 1 / (1 + np.exp(-np.clip(x, -250, 250)))
    
    def sigmoid_derivative(self, x):
        """Sigmoid导数"""
        return x * (1 - x)
    
    def relu(self, x):
        """ReLU激活函数"""
        return np.maximum(0, x)
    
    def relu_derivative(self, x):
        """ReLU导数"""
        return (x > 0).astype(float)
    
    def tanh(self, x):
        """Tanh激活函数"""
        return np.tanh(x)
    
    def tanh_derivative(self, x):
        """Tanh导数"""
        return 1 - x**2
    
    def softmax(self, x):
        """Softmax激活函数"""
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def forward(self, X, activation='sigmoid'):
        """前向传播"""
        self.activations = [X]
        self.z_values = []
        
        for i in range(len(self.weights)):
            z = np.dot(self.activations[-1], self.weights[i]) + self.biases[i]
            self.z_values.append(z)
            
            if i == len(self.weights) - 1:  # 输出层
                if self.layers[-1] == 1:  # 二分类
                    a = self.sigmoid(z)
                else:  # 多分类
                    a = self.softmax(z)
            else:  # 隐藏层
                if activation == 'sigmoid':
                    a = self.sigmoid(z)
                elif activation == 'relu':
                    a = self.relu(z)
                elif activation == 'tanh':
                    a = self.tanh(z)
            
            self.activations.append(a)
        
        return self.activations[-1]
    
    def compute_loss(self, y_true, y_pred):
        """计算损失函数"""
        epsilon = 1e-8
        y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
        
        if self.layers[-1] == 1:  # 二分类，使用交叉熵
            return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
        else:  # 多分类，使用交叉熵
            return -np.mean(np.sum(y_true * np.log(y_pred), axis=1))
    
    def compute_accuracy(self, y_true, y_pred):
        """计算准确率"""
        if self.layers[-1] == 1:  # 二分类
            predictions = (y_pred > 0.5).astype(int)
            return np.mean(predictions == y_true)
        else:  # 多分类
            predictions = np.argmax(y_pred, axis=1)
            true_labels = np.argmax(y_true, axis=1)
            return np.mean(predictions == true_labels)
    
    def backward(self, X, y, activation='sigmoid'):
        """反向传播"""
        m = X.shape[0]
        deltas = [None] * len(self.weights)
        
        # 输出层误差
        if self.layers[-1] == 1:  # 二分类
            delta_output = self.activations[-1] - y
        else:  # 多分类
            delta_output = self.activations[-1] - y
        
        deltas[-1] = delta_output
        
        # 隐藏层误差
        for i in range(len(self.weights) - 2, -1, -1):
            if activation == 'sigmoid':
                derivative = self.sigmoid_derivative(self.activations[i+1])
            elif activation == 'relu':
                derivative = self.relu_derivative(self.activations[i+1])
            elif activation == 'tanh':
                derivative = self.tanh_derivative(self.activations[i+1])
            
            delta = np.dot(deltas[i+1], self.weights[i+1].T) * derivative
            deltas[i] = delta
        
        # 计算梯度
        gradients_w = []
        gradients_b = []
        
        for i in range(len(self.weights)):
            grad_w = np.dot(self.activations[i].T, deltas[i]) / m
            grad_b = np.mean(deltas[i], axis=0, keepdims=True)
            
            gradients_w.append(grad_w)
            gradients_b.append(grad_b)
        
        return gradients_w, gradients_b
    
    def update_weights(self, gradients_w, gradients_b):
        """更新权重和偏置"""
        for i in range(len(self.weights)):
            self.weights[i] -= self.learning_rate * gradients_w[i]
            self.biases[i] -= self.learning_rate * gradients_b[i]
    
    def train_batch(self, X_batch, y_batch, activation='sigmoid'):
        """训练一个批次"""
        # 前向传播
        y_pred = self.forward(X_batch, activation)
        
        # 计算损失和准确率
        loss = self.compute_loss(y_batch, y_pred)
        accuracy = self.compute_accuracy(y_batch, y_pred)
        
        # 反向传播
        gradients_w, gradients_b = self.backward(X_batch, y_batch, activation)
        
        # 更新权重
        self.update_weights(gradients_w, gradients_b)
        
        # 记录历史
        self.loss_history.append(loss)
        self.accuracy_history.append(accuracy)
        self.weights_history.append([w.copy() for w in self.weights])
        self.gradients_history.append([np.linalg.norm(gw) for gw in gradients_w])
        
        return loss, accuracy, gradients_w, gradients_b

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class BPVisualizer(QMainWindow):
    """BP神经网络算法PyQt可视化器"""
    
    def __init__(self):
        super().__init__()
        self.model = None
        self.X_train = None
        self.y_train = None
        self.X_test = None
        self.y_test = None
        self.training = False
        self.current_step = 0
        self.total_steps = 1000
        self.timer = QTimer()
        self.timer.timeout.connect(self.train_step)
        
        self.init_ui()
        self.generate_data()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("BP神经网络算法可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 3)
        
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """创建控制面板"""
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)
        
        # 标题
        title_label = QLabel("BP神经网络控制台")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # 网络结构设置
        network_group = QGroupBox("网络结构")
        network_layout = QVBoxLayout(network_group)
        
        # 输入层大小
        input_layout = QHBoxLayout()
        input_label = QLabel("输入维度:")
        self.input_spin = QSpinBox()
        self.input_spin.setRange(1, 10)
        self.input_spin.setValue(2)
        input_layout.addWidget(input_label)
        input_layout.addWidget(self.input_spin)
        network_layout.addLayout(input_layout)
        
        # 隐藏层1
        hidden1_layout = QHBoxLayout()
        hidden1_label = QLabel("隐藏层1:")
        self.hidden1_spin = QSpinBox()
        self.hidden1_spin.setRange(1, 20)
        self.hidden1_spin.setValue(8)
        hidden1_layout.addWidget(hidden1_label)
        hidden1_layout.addWidget(self.hidden1_spin)
        network_layout.addLayout(hidden1_layout)
        
        # 隐藏层2
        hidden2_layout = QHBoxLayout()
        hidden2_label = QLabel("隐藏层2:")
        self.hidden2_spin = QSpinBox()
        self.hidden2_spin.setRange(0, 20)
        self.hidden2_spin.setValue(4)
        hidden2_layout.addWidget(hidden2_label)
        hidden2_layout.addWidget(self.hidden2_spin)
        network_layout.addLayout(hidden2_layout)
        
        # 输出层
        output_layout = QHBoxLayout()
        output_label = QLabel("输出维度:")
        self.output_spin = QSpinBox()
        self.output_spin.setRange(1, 10)
        self.output_spin.setValue(1)
        output_layout.addWidget(output_label)
        output_layout.addWidget(self.output_spin)
        network_layout.addLayout(output_layout)
        
        control_layout.addWidget(network_group)
        
        # 参数设置
        params_group = QGroupBox("训练参数")
        params_layout = QVBoxLayout(params_group)
        
        # 学习率
        lr_layout = QHBoxLayout()
        lr_label = QLabel("学习率:")
        self.lr_input = QLineEdit("0.1")
        lr_layout.addWidget(lr_label)
        lr_layout.addWidget(self.lr_input)
        params_layout.addLayout(lr_layout)
        
        # 样本数量
        samples_layout = QHBoxLayout()
        samples_label = QLabel("样本数量:")
        self.samples_input = QLineEdit("200")
        samples_layout.addWidget(samples_label)
        samples_layout.addWidget(self.samples_input)
        params_layout.addLayout(samples_layout)
        
        # 训练步数
        steps_layout = QHBoxLayout()
        steps_label = QLabel("训练步数:")
        self.steps_input = QLineEdit("1000")
        steps_layout.addWidget(steps_label)
        steps_layout.addWidget(self.steps_input)
        params_layout.addLayout(steps_layout)
        
        # 批次大小
        batch_layout = QHBoxLayout()
        batch_label = QLabel("批次大小:")
        self.batch_input = QLineEdit("32")
        batch_layout.addWidget(batch_label)
        batch_layout.addWidget(self.batch_input)
        params_layout.addLayout(batch_layout)
        
        # 激活函数选择
        activation_layout = QHBoxLayout()
        activation_label = QLabel("激活函数:")
        self.activation_combo = QComboBox()
        self.activation_combo.addItems(["sigmoid", "relu", "tanh"])
        activation_layout.addWidget(activation_label)
        activation_layout.addWidget(self.activation_combo)
        params_layout.addLayout(activation_layout)
        
        # 数据集选择
        dataset_layout = QHBoxLayout()
        dataset_label = QLabel("数据集:")
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems(["线性可分", "月亮数据", "圆圈数据"])
        dataset_layout.addWidget(dataset_label)
        dataset_layout.addWidget(self.dataset_combo)
        params_layout.addLayout(dataset_layout)
        
        control_layout.addWidget(params_group)
        
        # 控制按钮
        buttons_group = QGroupBox("训练控制")
        buttons_layout = QVBoxLayout(buttons_group)
        
        self.start_button = QPushButton("开始训练")
        self.start_button.clicked.connect(self.start_training)
        buttons_layout.addWidget(self.start_button)
        
        self.pause_button = QPushButton("暂停训练")
        self.pause_button.clicked.connect(self.pause_training)
        self.pause_button.setEnabled(False)
        buttons_layout.addWidget(self.pause_button)
        
        self.reset_button = QPushButton("重置模型")
        self.reset_button.clicked.connect(self.reset_model)
        buttons_layout.addWidget(self.reset_button)
        
        control_layout.addWidget(buttons_group)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        control_layout.addWidget(self.progress_bar)
        
        # 训练信息
        info_group = QGroupBox("训练信息")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 损失函数标签页
        loss_tab = QWidget()
        loss_layout = QVBoxLayout(loss_tab)
        self.loss_canvas = MplCanvas(self, width=8, height=4)
        loss_layout.addWidget(self.loss_canvas)
        visualization_widget.addTab(loss_tab, "损失函数")
        
        # 准确率标签页
        accuracy_tab = QWidget()
        accuracy_layout = QVBoxLayout(accuracy_tab)
        self.accuracy_canvas = MplCanvas(self, width=8, height=4)
        accuracy_layout.addWidget(self.accuracy_canvas)
        visualization_widget.addTab(accuracy_tab, "准确率")
        
        # 决策边界标签页
        decision_tab = QWidget()
        decision_layout = QVBoxLayout(decision_tab)
        self.decision_canvas = MplCanvas(self, width=8, height=6)
        decision_layout.addWidget(self.decision_canvas)
        visualization_widget.addTab(decision_tab, "决策边界")
        
        # 权重可视化标签页
        weights_tab = QWidget()
        weights_layout = QVBoxLayout(weights_tab)
        self.weights_canvas = MplCanvas(self, width=8, height=6)
        weights_layout.addWidget(self.weights_canvas)
        visualization_widget.addTab(weights_tab, "权重矩阵")
        
        # 梯度可视化标签页
        gradients_tab = QWidget()
        gradients_layout = QVBoxLayout(gradients_tab)
        self.gradients_canvas = MplCanvas(self, width=8, height=4)
        gradients_layout.addWidget(self.gradients_canvas)
        visualization_widget.addTab(gradients_tab, "梯度变化")
        
        return visualization_widget
    
    def generate_data(self):
        """生成训练数据"""
        n_samples = int(self.samples_input.text())
        dataset_type = self.dataset_combo.currentText()
        
        if dataset_type == "线性可分":
            self.X_train, self.y_train = make_classification(
                n_samples=n_samples, n_features=2, n_redundant=0, n_informative=2,
                n_clusters_per_class=1, random_state=42)
        elif dataset_type == "月亮数据":
            self.X_train, self.y_train = make_moons(n_samples=n_samples, noise=0.2, random_state=42)
        elif dataset_type == "圆圈数据":
            self.X_train, self.y_train = make_circles(n_samples=n_samples, noise=0.2, factor=0.5, random_state=42)
        
        # 确保输出维度匹配
        if self.output_spin.value() == 1:
            self.y_train = self.y_train.reshape(-1, 1)
        else:
            # 转换为one-hot编码
            y_one_hot = np.zeros((len(self.y_train), self.output_spin.value()))
            y_one_hot[np.arange(len(self.y_train)), self.y_train] = 1
            self.y_train = y_one_hot
        
        # 重置模型
        self.reset_model()
        
        # 绘制初始数据分布
        self.plot_decision_boundary()
        
        self.info_text.append(f"生成了 {n_samples} 个 {dataset_type} 样本")
    
    def reset_model(self):
        """重置模型"""
        # 构建网络结构
        layers = [self.input_spin.value()]
        if self.hidden1_spin.value() > 0:
            layers.append(self.hidden1_spin.value())
        if self.hidden2_spin.value() > 0:
            layers.append(self.hidden2_spin.value())
        layers.append(self.output_spin.value())
        
        learning_rate = float(self.lr_input.text())
        self.model = BPNeuralNetwork(layers, learning_rate)
        
        self.current_step = 0
        self.progress_bar.setValue(0)
        self.info_text.clear()
        self.info_text.append(f"模型已重置，网络结构: {layers}")
        self.update_plots()
    
    def start_training(self):
        """开始训练"""
        if not self.training:
            self.total_steps = int(self.steps_input.text())
            self.training = True
            self.start_button.setEnabled(False)
            self.pause_button.setEnabled(True)
            self.timer.start(50)  # 每50ms训练一步
            self.info_text.append("训练开始...")
    
    def pause_training(self):
        """暂停训练"""
        if self.training:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("训练暂停...")
    
    def train_step(self):
        """训练一步"""
        if self.current_step >= self.total_steps or self.model is None:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("训练完成!")
            return
        
        # 使用完整数据集进行训练（实际应用中应该使用小批次）
        batch_size = int(self.batch_input.text())
        if batch_size >= len(self.X_train):
            indices = range(len(self.X_train))
        else:
            indices = np.random.choice(len(self.X_train), batch_size, replace=False)
        
        X_batch = self.X_train[indices]
        y_batch = self.y_train[indices]
        
        # 训练模型
        activation = self.activation_combo.currentText()
        loss, accuracy, gradients_w, gradients_b = self.model.train_batch(X_batch, y_batch, activation)
        
        # 更新进度
        self.current_step += 1
        progress = int((self.current_step / self.total_steps) * 100)
        self.progress_bar.setValue(progress)
        
        # 更新信息显示
        if self.current_step % 10 == 0 or self.current_step == self.total_steps:
            self.info_text.append(f"步数: {self.current_step}, 损失: {loss:.4f}, 准确率: {accuracy:.4f}")
        
        # 更新图表
        self.update_plots()
    
    def update_plots(self):
        """更新所有图表"""
        self.plot_loss()
        self.plot_accuracy()
        self.plot_decision_boundary()
        self.plot_weights()
        self.plot_gradients()
        
        self.loss_canvas.draw()
        self.accuracy_canvas.draw()
        self.decision_canvas.draw()
        self.weights_canvas.draw()
        self.gradients_canvas.draw()
    
    def plot_loss(self):
        """绘制损失函数曲线"""
        self.loss_canvas.fig.clear()
        ax = self.loss_canvas.fig.add_subplot(111)
        
        if self.model and len(self.model.loss_history) > 0:
            ax.plot(range(len(self.model.loss_history)), self.model.loss_history, 'b-', linewidth=2)
            ax.set_title('Loss Curve', fontsize=12, color='white')
            ax.set_xlabel('Training Steps', color='white')
            ax.set_ylabel('Loss', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.loss_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.loss_canvas.draw()
    
    def plot_accuracy(self):
        """绘制准确率曲线"""
        self.accuracy_canvas.fig.clear()
        ax = self.accuracy_canvas.fig.add_subplot(111)
        
        if self.model and len(self.model.accuracy_history) > 0:
            ax.plot(range(len(self.model.accuracy_history)), self.model.accuracy_history, 'g-', linewidth=2)
            ax.set_title('Accuracy Curve', fontsize=12, color='white')
            ax.set_xlabel('Training Steps', color='white')
            ax.set_ylabel('Accuracy', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.accuracy_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.accuracy_canvas.draw()
    
    def plot_decision_boundary(self):
        """绘制决策边界"""
        self.decision_canvas.fig.clear()
        ax = self.decision_canvas.fig.add_subplot(111)
        
        if self.X_train is not None:
            # 创建网格点
            x_min, x_max = self.X_train[:, 0].min() - 0.5, self.X_train[:, 0].max() + 0.5
            y_min, y_max = self.X_train[:, 1].min() - 0.5, self.X_train[:, 1].max() + 0.5
            xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                                np.linspace(y_min, y_max, 100))
            
            # 预测网格点
            if self.model and self.model.weights:
                grid_points = np.c_[xx.ravel(), yy.ravel()]
                activation = self.activation_combo.currentText()
                Z = self.model.forward(grid_points, activation)
                
                if self.output_spin.value() == 1:
                    Z = Z.reshape(xx.shape)
                else:
                    Z = np.argmax(Z, axis=1).reshape(xx.shape)
                
                # 绘制决策边界
                cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
                cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])
                
                ax.contourf(xx, yy, Z, alpha=0.8, cmap=cmap_light)
            
            # 绘制数据点
            scatter = ax.scatter(self.X_train[:, 0], self.X_train[:, 1], 
                               c=self.y_train.flatten() if self.output_spin.value() == 1 else np.argmax(self.y_train, axis=1),
                               cmap=cmap_bold, edgecolors='k', s=20)
            
            ax.set_title('Decision Boundary', fontsize=12, color='white')
            ax.set_xlabel('Feature 1', color='white')
            ax.set_ylabel('Feature 2', color='white')
            ax.set_facecolor('#2b2b2b')
            self.decision_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.decision_canvas.draw()
    
    def plot_weights(self):
        """绘制权重矩阵热力图"""
        self.weights_canvas.fig.clear()
        
        if self.model and self.model.weights:
            n_layers = len(self.model.weights)
            fig, axes = plt.subplots(1, n_layers, figsize=(4*n_layers, 4))
            
            if n_layers == 1:
                axes = [axes]
            
            for i, (weight, ax) in enumerate(zip(self.model.weights, axes)):
                im = ax.imshow(weight, cmap='coolwarm', aspect='auto')
                ax.set_title(f'Weight Matrix {i+1}', fontsize=10, color='white')
                ax.set_xlabel('Output Dimension', color='white')
                ax.set_ylabel('Input Dimension', color='white')
                ax.set_facecolor('#2b2b2b')
                ax.tick_params(colors='white')
                plt.colorbar(im, ax=ax)
            
            self.weights_canvas.fig = fig
            self.weights_canvas.draw()
    
    def plot_gradients(self):
        """绘制梯度变化曲线"""
        self.gradients_canvas.fig.clear()
        ax = self.gradients_canvas.fig.add_subplot(111)
        
        if self.model and len(self.model.gradients_history) > 0:
            gradients_array = np.array(self.model.gradients_history)
            
            for i in range(gradients_array.shape[1]):
                ax.plot(range(len(gradients_array)), gradients_array[:, i], 
                       label=f'层 {i+1}', linewidth=2)
            
            ax.set_title('Gradient Variation Curve', fontsize=12, color='white')
            ax.set_xlabel('Training Steps', color='white')
            ax.set_ylabel('Gradient Norm', color='white')
            ax.legend()
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.gradients_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.gradients_canvas.draw()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = BPVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()