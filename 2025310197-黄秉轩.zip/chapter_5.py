# file: som_5x5_four_dim.py
from __future__ import annotations
import os
import math
from dataclasses import dataclass
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt

DATA = np.array([
    [1.0, 0.0, 0.0, 0.0],  # X1
    [1.0, 1.0, 0.0, 0.0],  # X2
    [1.0, 1.0, 1.0, 0.0],  # X3
    [0.0, 1.0, 0.0, 0.0],  # X4
    [1.0, 1.0, 1.0, 1.0],  # X5
], dtype=np.float64)

LABELS = ["X1", "X2", "X3", "X4", "X5"]

@dataclass
class SOMConfig:
    m: int = 5
    n: int = 5
    dim: int = 4
    steps: int = 10_000
    lr_start: float = 0.5
    lr_mid: float = 0.04
    sigma_start: float = 2.0  # 初始邻域半径
    decay_boundary: int = 1_000  # 在此之后，半径 = 0，学习率衰减至 0
    snapshot_every: int = 200
    out_dir: str = "som_outputs"

class SOM:
    def __init__(self, cfg: SOMConfig, rng: np.random.Generator | None = None) -> None:
        self.cfg = cfg
        self.rng = rng or np.random.default_rng(42)
        # 在 [0,1] 范围内初始化权重；小的随机值有助于打破对称性
        self.W = self.rng.random((cfg.m, cfg.n, cfg.dim), dtype=np.float64)
        # 网格坐标
        xs, ys = np.meshgrid(np.arange(cfg.m, dtype=np.float64),
                             np.arange(cfg.n, dtype=np.float64), indexing='ij')
        self.coords = np.stack([xs, ys], axis=-1)  # (m,n,2)
        os.makedirs(cfg.out_dir, exist_ok=True)

    def lr(self, t: int) -> float:
        c = self.cfg
        if t <= c.decay_boundary:
            # 从 lr_start 线性过渡到 lr_mid
            return c.lr_start + (c.lr_mid - c.lr_start) * (t / c.decay_boundary)
        # 从边界处的 lr_mid 线性变化 -> 到步长处为 0
        remaining = max(0, c.steps - c.decay_boundary)
        frac = 0.0 if remaining == 0 else (t - c.decay_boundary) / remaining
        return max(0.0, c.lr_mid * (1.0 - frac))

    def sigma(self, t: int) -> float:
        c = self.cfg
        if t <= c.decay_boundary:
            # 从 sigma_start 线性变化到 0
            return max(0.0, c.sigma_start * (1.0 - t / c.decay_boundary))
        return 0.0

    def bmu(self, x: np.ndarray) -> Tuple[int, int]:

        diff = self.W - x[None, None, :]
        dist2 = np.einsum('ijk,ijk->ij', diff, diff)
        idx = np.unravel_index(np.argmin(dist2), dist2.shape)
        return int(idx[0]), int(idx[1])

    def neighborhood(self, bmu_idx: Tuple[int, int], sigma: float) -> np.ndarray:
        if sigma <= 0.0:
            h = np.zeros((self.cfg.m, self.cfg.n), dtype=np.float64)
            h[bmu_idx] = 1.0
            return h
        # 欧几里得网格距离上的高斯核函数
        d = self.coords - np.array(bmu_idx, dtype=np.float64)
        dist2 = np.sum(d * d, axis=-1)
        return np.exp(-dist2 / (2.0 * sigma * sigma))

    def step(self, x: np.ndarray, t: int) -> None:
        eta = self.lr(t)
        sig = self.sigma(t)
        b = self.bmu(x)
        h = self.neighborhood(b, sig)
        self.W += eta * h[..., None] * (x[None, None, :] - self.W)

    def _save_weights(self, step_idx: int) -> None:
        out_npy = os.path.join(self.cfg.out_dir, f"weights_step_{step_idx:05d}.npy")
        np.save(out_npy, self.W)

    def _save_heatmaps(self, step_idx: int) -> None:
        fig, axes = plt.subplots(2, 2, figsize=(8, 7), constrained_layout=True)
        axes = axes.ravel()
        for k in range(self.cfg.dim):
            ax = axes[k]
            # 调整颜色映射为 coolwarm 的反向，并设置数值范围（示例）
            im = ax.imshow(
                self.W[:, :, k],
                origin='lower',
                cmap='coolwarm_r',  # 反向冷暖色
                vmin=self.W.min(),  # 用数据最小值作为范围起点
                vmax=self.W.max()  # 用数据最大值作为范围终点
            )
            ax.set_title(f"Dim {k + 1} @ step {step_idx}")
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.suptitle(f"SOM weights heatmaps (step {step_idx})")
        fig.savefig(os.path.join(self.cfg.out_dir, f"heatmap_step_{step_idx:05d}.png"), dpi=150)
        plt.close(fig)

    def train(self, data: np.ndarray) -> None:
        c = self.cfg
        order = np.arange(len(data))
        for t in range(1, c.steps + 1):
            # 循环处理数据以确保稳定性
            x = data[order[(t - 1) % len(order)]]
            self.step(x, t)
            if t % c.snapshot_every == 0 or t in (1, c.decay_boundary, c.steps):
                self._save_weights(t)
                self._save_heatmaps(t)
        np.save(os.path.join(c.out_dir, "weights_final.npy"), self.W)

    def map_inputs(self, data: np.ndarray) -> List[Tuple[int, int]]:
        mapping = []
        for x in data:
            mapping.append(self.bmu(x))
        return mapping

    def plot_mapping(self, mapping: List[Tuple[int, int]], labels: List[str]) -> str:
        # 每个输入的最佳匹配单元（BMUs）在 5x5 网格上的散点图（红紫色系）
        fig, ax = plt.subplots(figsize=(6, 6))

        # 生成SOM网格坐标
        xs, ys = np.meshgrid(np.arange(self.cfg.m), np.arange(self.cfg.n), indexing='ij')

        # 1. 网格背景点：浅紫色（红紫色系的浅色调）
        ax.scatter(xs.ravel(), ys.ravel(), s=20, color='#E6E6FA')  # 淡紫色

        # 2. 样本BMU点：紫红色（红紫色系的深色调，与背景区分）
        for (i, j), name in zip(mapping, labels):
            # 深紫红色圆点，边缘加白色边框增强对比
            ax.scatter([i], [j], s=150, marker='o', color='#C71585', edgecolors='white', linewidths=1.5)
            # 标签文字颜色：深紫色（与点呼应）
            ax.text(i + 0.05, j + 0.05, name, color='#800080', fontsize=9)

        # 图表标题和坐标轴设置（保持不变）
        ax.set_title("SOM mapping of 5 input patterns (final)", color='#4B0082')  # 标题用靛蓝色（红紫偏蓝）
        ax.set_xlabel("i", color='#800080')  # x轴标签：深紫色
        ax.set_ylabel("j", color='#800080')  # y轴标签：深紫色
        ax.set_xticks(np.arange(self.cfg.m))
        ax.set_yticks(np.arange(self.cfg.n))
        ax.set_xlim(-0.5, self.cfg.m - 0.5)
        ax.set_ylim(-0.5, self.cfg.n - 0.5)
        ax.grid(True, linestyle=':', color='#DDA0DD')  # 网格线：淡紫色

        # 保存图片
        out_path = os.path.join(self.cfg.out_dir, "mapping_final.png")
        fig.savefig(out_path, dpi=160)
        plt.close(fig)
        return out_path

def main() -> None:
    cfg = SOMConfig()
    som = SOM(cfg)
    som.train(DATA)
    mapping = som.map_inputs(DATA)
    out_map = som.plot_mapping(mapping, LABELS)
    print("Final BMU mapping (i,j) for each input:")
    for name, (i, j) in zip(LABELS, mapping):
        print(f"{name}: ({i}, {j})")
    print(f"Saved outputs to: {cfg.out_dir}")
    print(f"Final mapping figure: {out_map}")

if __name__ == "__main__":
    main()
