import sys
import numpy as np
from sklearn.datasets import make_classification
import time
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QSplitter, QProgressBar)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

class OSL:
    """在线序列学习算法 (Online Sequential Learning)"""
    
    def __init__(self, input_dim, output_dim, learning_rate=0.01):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.learning_rate = learning_rate
        self.weights = np.random.randn(input_dim, output_dim) * 0.1
        self.bias = np.zeros(output_dim)
        self.loss_history = []
        self.weights_history = []
        self.gradient_history = []
        
    def sigmoid(self, x):
        """Sigmoid激活函数"""
        return 1 / (1 + np.exp(-np.clip(x, -250, 250)))
    
    def forward(self, X):
        """前向传播"""
        return self.sigmoid(np.dot(X, self.weights) + self.bias)
    
    def compute_loss(self, y_true, y_pred):
        """计算损失函数（交叉熵）"""
        epsilon = 1e-8
        y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
        return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
    
    def update_weights(self, X, y, y_pred):
        """在线更新权重"""
        error = y - y_pred
        gradient_w = np.dot(X.T, error) / len(X)
        gradient_b = np.mean(error, axis=0)
        
        self.weights += self.learning_rate * gradient_w
        self.bias += self.learning_rate * gradient_b
        
        return gradient_w, gradient_b
    
    def train_online(self, X_batch, y_batch):
        """在线训练一个批次"""
        y_pred = self.forward(X_batch)
        loss = self.compute_loss(y_batch, y_pred)
        gradient_w, gradient_b = self.update_weights(X_batch, y_batch, y_pred)
        
        # 记录历史数据用于可视化
        self.loss_history.append(loss)
        self.weights_history.append(self.weights.copy())
        self.gradient_history.append(np.linalg.norm(gradient_w))
        
        return loss, gradient_w, gradient_b

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class OSLVisualizer(QMainWindow):
    """OSL算法PyQt可视化器"""
    
    def __init__(self):
        super().__init__()
        self.model = None
        self.X = None
        self.y = None
        self.training = False
        self.current_step = 0
        self.total_steps = 100
        self.timer = QTimer()
        self.timer.timeout.connect(self.train_step)
        
        self.init_ui()
        self.generate_data()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("OSL在线序列学习算法可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 3)
        
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """创建控制面板"""
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)
        
        # 标题
        title_label = QLabel("OSL算法控制台")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # 参数设置
        params_group = QGroupBox("参数设置")
        params_layout = QVBoxLayout(params_group)
        
        # 学习率
        lr_layout = QHBoxLayout()
        lr_label = QLabel("学习率:")
        self.lr_input = QLineEdit("0.1")
        lr_layout.addWidget(lr_label)
        lr_layout.addWidget(self.lr_input)
        params_layout.addLayout(lr_layout)
        
        # 样本数量
        samples_layout = QHBoxLayout()
        samples_label = QLabel("样本数量:")
        self.samples_input = QLineEdit("200")
        samples_layout.addWidget(samples_label)
        samples_layout.addWidget(self.samples_input)
        params_layout.addLayout(samples_layout)
        
        # 训练步数
        steps_layout = QHBoxLayout()
        steps_label = QLabel("训练步数:")
        self.steps_input = QLineEdit("100")
        steps_layout.addWidget(steps_label)
        steps_layout.addWidget(self.steps_input)
        params_layout.addLayout(steps_layout)
        
        # 批次大小
        batch_layout = QHBoxLayout()
        batch_label = QLabel("批次大小:")
        self.batch_input = QLineEdit("10")
        batch_layout.addWidget(batch_label)
        batch_layout.addWidget(self.batch_input)
        params_layout.addLayout(batch_layout)
        
        control_layout.addWidget(params_group)
        
        # 控制按钮
        buttons_group = QGroupBox("训练控制")
        buttons_layout = QVBoxLayout(buttons_group)
        
        self.start_button = QPushButton("开始训练")
        self.start_button.clicked.connect(self.start_training)
        buttons_layout.addWidget(self.start_button)
        
        self.pause_button = QPushButton("暂停训练")
        self.pause_button.clicked.connect(self.pause_training)
        self.pause_button.setEnabled(False)
        buttons_layout.addWidget(self.pause_button)
        
        self.reset_button = QPushButton("重置模型")
        self.reset_button.clicked.connect(self.reset_model)
        buttons_layout.addWidget(self.reset_button)
        
        control_layout.addWidget(buttons_group)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        control_layout.addWidget(self.progress_bar)
        
        # 训练信息
        info_group = QGroupBox("训练信息")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 损失函数标签页
        loss_tab = QWidget()
        loss_layout = QVBoxLayout(loss_tab)
        self.loss_canvas = MplCanvas(self, width=8, height=4)
        loss_layout.addWidget(self.loss_canvas)
        visualization_widget.addTab(loss_tab, "损失函数")
        
        # 权重可视化标签页
        weights_tab = QWidget()
        weights_layout = QVBoxLayout(weights_tab)
        self.weights_canvas = MplCanvas(self, width=8, height=4)
        weights_layout.addWidget(self.weights_canvas)
        visualization_widget.addTab(weights_tab, "权重矩阵")
        
        # 预测结果标签页
        predictions_tab = QWidget()
        predictions_layout = QVBoxLayout(predictions_tab)
        self.predictions_canvas = MplCanvas(self, width=8, height=4)
        predictions_layout.addWidget(self.predictions_canvas)
        visualization_widget.addTab(predictions_tab, "预测结果")
        
        # 决策边界标签页
        decision_tab = QWidget()
        decision_layout = QVBoxLayout(decision_tab)
        self.decision_canvas = MplCanvas(self, width=8, height=4)
        decision_layout.addWidget(self.decision_canvas)
        visualization_widget.addTab(decision_tab, "决策边界")
        
        # 数据分布标签页
        data_tab = QWidget()
        data_layout = QVBoxLayout(data_tab)
        self.data_canvas = MplCanvas(self, width=8, height=4)
        data_layout.addWidget(self.data_canvas)
        visualization_widget.addTab(data_tab, "数据分布")
        
        return visualization_widget
    
    def generate_data(self):
        """生成演示数据"""
        n_samples = int(self.samples_input.text())
        self.X, self.y = make_classification(n_samples=n_samples, n_features=2, 
                                            n_redundant=0, n_informative=2,
                                            n_clusters_per_class=1, random_state=42)
        self.y = self.y.reshape(-1, 1)
        
        # 初始化模型
        self.reset_model()
        
        # 绘制初始数据分布
        self.plot_data_distribution()
    
    def reset_model(self):
        """重置模型"""
        learning_rate = float(self.lr_input.text())
        self.model = OSL(input_dim=2, output_dim=1, learning_rate=learning_rate)
        self.current_step = 0
        self.progress_bar.setValue(0)
        self.info_text.clear()
        self.info_text.append("模型已重置，准备开始训练...")
        self.update_plots()
    
    def start_training(self):
        """开始训练"""
        if not self.training:
            self.total_steps = int(self.steps_input.text())
            self.training = True
            self.start_button.setEnabled(False)
            self.pause_button.setEnabled(True)
            self.timer.start(100)  # 每100ms训练一步
            self.info_text.append("训练开始...")
    
    def pause_training(self):
        """暂停训练"""
        if self.training:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("训练暂停...")
    
    def train_step(self):
        """训练一步"""
        if self.current_step >= self.total_steps:
            self.training = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("训练完成!")
            return
        
        # 随机选择批次进行训练
        batch_size = int(self.batch_input.text())
        indices = np.random.choice(len(self.X), batch_size, replace=False)
        X_batch = self.X[indices]
        y_batch = self.y[indices]
        
        # 训练模型
        loss, grad_w, grad_b = self.model.train_online(X_batch, y_batch)
        
        # 更新进度
        self.current_step += 1
        progress = int((self.current_step / self.total_steps) * 100)
        self.progress_bar.setValue(progress)
        
        # 更新信息显示
        if self.current_step % 10 == 0:
            accuracy = self.calculate_accuracy()
            self.info_text.append(f"步数: {self.current_step}, 损失: {loss:.4f}, 准确率: {accuracy:.4f}")
        
        # 更新图表
        self.update_plots()
    
    def calculate_accuracy(self):
        """计算当前准确率"""
        predictions = self.model.forward(self.X)
        predicted_labels = (predictions > 0.5).astype(int)
        accuracy = np.mean(predicted_labels == self.y)
        return accuracy
    
    def update_plots(self):
        """更新所有图表"""
        self.plot_loss()
        self.plot_weights()
        self.plot_predictions()
        self.plot_decision_boundary()
        self.loss_canvas.draw()
        self.weights_canvas.draw()
        self.predictions_canvas.draw()
        self.decision_canvas.draw()
    
    def plot_loss(self):
        """绘制损失函数曲线"""
        self.loss_canvas.fig.clear()
        ax = self.loss_canvas.fig.add_subplot(111)
        
        if len(self.model.loss_history) > 0:
            ax.plot(range(len(self.model.loss_history)), self.model.loss_history, 'b-', linewidth=2)
            ax.set_title('Loss Curve', fontsize=12, color='white')
            ax.set_xlabel('Training_Steps', color='white')
            ax.set_ylabel('Loss', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.loss_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.loss_canvas.draw()
    
    def plot_weights(self):
        """绘制权重矩阵热力图"""
        self.weights_canvas.fig.clear()
        ax = self.weights_canvas.fig.add_subplot(111)
        
        if self.model.weights is not None:
            im = ax.imshow(self.model.weights, cmap='coolwarm', aspect='auto')
            ax.set_title('Weights Heatmap', fontsize=12, color='white')
            ax.set_xlabel('Output_Dim', color='white')
            ax.set_ylabel('Input_Dim', color='white')
            self.weights_canvas.fig.colorbar(im, ax=ax)
            ax.set_facecolor('#2b2b2b')
            self.weights_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.weights_canvas.draw()
    
    def plot_predictions(self):
        """绘制预测结果"""
        self.predictions_canvas.fig.clear()
        ax = self.predictions_canvas.fig.add_subplot(111)
        
        if self.model.weights is not None:
            # 使用完整数据集进行预测
            full_predictions = self.model.forward(self.X)
            ax.scatter(self.y.flatten(), full_predictions.flatten(), alpha=0.6, c='blue')
            ax.plot([0, 1], [0, 1], 'r--', alpha=0.8)
            ax.set_title('Predicted Probabilities vs True Labels', fontsize=12, color='white')
            ax.set_xlabel('True_Labels', color='white')
            ax.set_ylabel('Predicted_Probabilities', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.predictions_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.predictions_canvas.draw()
    
    def plot_decision_boundary(self):
        """绘制决策边界"""
        self.decision_canvas.fig.clear()
        ax = self.decision_canvas.fig.add_subplot(111)
        
        if self.model.weights is not None:
            # 创建网格点
            x_min, x_max = self.X[:, 0].min() - 0.5, self.X[:, 0].max() + 0.5
            y_min, y_max = self.X[:, 1].min() - 0.5, self.X[:, 1].max() + 0.5
            xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50),
                                np.linspace(y_min, y_max, 50))
            
            # 预测网格点
            grid_points = np.c_[xx.ravel(), yy.ravel()]
            Z = self.model.forward(grid_points)
            Z = Z.reshape(xx.shape)
            
            # 绘制决策边界
            contour = ax.contourf(xx, yy, Z, alpha=0.8, cmap='viridis')
            scatter = ax.scatter(self.X[:, 0], self.X[:, 1], c=self.y.flatten(), 
                               cmap='viridis', edgecolors='k')
            ax.set_title(f'Decision Boundary (Step: {self.current_step})', fontsize=12, color='white')
            ax.set_xlabel('Feature_1', color='white')
            ax.set_ylabel('Feature_2', color='white')
            ax.set_facecolor('#2b2b2b')
            self.decision_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.decision_canvas.draw()
    
    def plot_data_distribution(self):
        """绘制数据分布"""
        self.data_canvas.fig.clear()
        ax = self.data_canvas.fig.add_subplot(111)
        
        if self.X is not None:
            scatter = ax.scatter(self.X[:, 0], self.X[:, 1], c=self.y.flatten(), 
                               cmap='viridis', alpha=0.6)
            ax.set_title('Training Data Distribution', fontsize=12, color='white')
            ax.set_xlabel('Feature_1', color='white')
            ax.set_ylabel('Feature_2', color='white')
            ax.set_facecolor('#2b2b2b')
            self.data_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.data_canvas.draw()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = OSLVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()