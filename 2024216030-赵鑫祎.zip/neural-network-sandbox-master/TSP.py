import sys
import math
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, 
                             QPushButton, QVBoxLayout, QHBoxLayout, QLabel)
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor
from PyQt5.QtCore import Qt, QPoint, QTimer

# --- 算法状态 ---
STATE_IDLE = 0       # 空闲
STATE_START_STEP = 1 # 准备开始搜索（刚到达一个新城市）
STATE_CHECKING = 2   # 正在遍历候选城市
STATE_MOVE = 3       # 已找到最近的，准备移动
STATE_DONE = 4       # 全部完成

# --- 辅助函数 ---
def calculate_distance(p1: QPoint, p2: QPoint) -> float:
    return math.sqrt((p1.x() - p2.x())**2 + (p1.y() - p2.y())**2)

# --- 绘图组件 ---

class DrawWidget(QWidget):
    """用于绘制城市和路径的自定义组件"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.cities = []  # 存储 QPoint 对象的列表
        self.path = []    # 存储城市索引的列表，表示 *已确定* 的路径
        
        # --- 算法和可视化状态变量 ---
        self.state = STATE_IDLE
        self.unvisited = []
        self.current_city_idx = -1   # 当前所在的城市 (绿色高亮)
        self.check_index = 0         # 正在检查 unvisited 列表中的第几个
        self.current_check_idx = -1  # 正在检查的候选城市 (灰色细线)
        self.best_candidate_idx = -1 # 当前找到的最近邻居 (绿色虚线)
        self.min_dist_so_far = 0.0
        self.total_distance = 0.0

        # --- QTimer ---
        self.solve_timer = QTimer(self)
        self.solve_timer.timeout.connect(self._algorithm_step)
        
        self.setMinimumSize(600, 400)
        self.setStyleSheet("background-color: white;")

    def mousePressEvent(self, event):
        """在鼠标点击的位置添加一个城市"""
        if event.button() == Qt.LeftButton and self.state == STATE_IDLE:
            self.cities.append(event.pos())
            self.path = []
            self.update()

    def paintEvent(self, event):
        """重绘事件，用于绘制所有内容"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 1. 绘制已确定的路径 (蓝色实线)
        if len(self.path) > 1:
            pen = QPen(Qt.blue, 2)
            painter.setPen(pen)
            for i in range(len(self.path) - 1):
                p1 = self.cities[self.path[i]]
                p2 = self.cities[self.path[i+1]]
                painter.drawLine(p1, p2)
        
        # 2. 绘制城市 (红点)
        painter.setBrush(QBrush(Qt.red))
        painter.setPen(QPen(Qt.red, 5))
        for i, city in enumerate(self.cities):
            # 如果是当前城市，则不大力绘制，让高亮更明显
            if i != self.current_city_idx:
                painter.drawEllipse(city, 5, 5)

        # --- 绘制算法细节 (如果正在运行) ---
        if self.state in [STATE_CHECKING, STATE_MOVE, STATE_START_STEP]:
            current_city_pos = self.cities[self.current_city_idx]

            # 3. 高亮当前城市 (绿色大圈)
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(0, 180, 0), 3)) # 亮绿色
            painter.drawEllipse(current_city_pos, 10, 10)
            
            # 4. 绘制“正在检查”的线 (灰色细线)
            if self.current_check_idx != -1:
                check_city_pos = self.cities[self.current_check_idx]
                painter.setPen(QPen(Qt.gray, 1))
                painter.drawLine(current_city_pos, check_city_pos)

            # 5. 绘制“当前最优”的线 (绿色虚线)
            if self.best_candidate_idx != -1:
                best_city_pos = self.cities[self.best_candidate_idx]
                pen = QPen(QColor(0, 180, 0), 2, Qt.DashLine)
                painter.setPen(pen)
                painter.drawLine(current_city_pos, best_city_pos)

        # 6. 如果已完成，绘制闭合路径
        if self.state == STATE_DONE and len(self.path) > 1:
            painter.setPen(QPen(Qt.blue, 2))
            p_start = self.cities[self.path[0]]
            p_end = self.cities[self.path[-1]]
            painter.drawLine(p_end, p_start)


    def clear_all(self):
        """清除所有内容并重置状态"""
        self.solve_timer.stop()
        self.state = STATE_IDLE
        self.cities = []
        self.path = []
        self.unvisited = []
        self.current_city_idx = -1
        self.current_check_idx = -1
        self.best_candidate_idx = -1
        
        if self.parent() and hasattr(self.parent(), 'enable_buttons'):
            self.parent().enable_buttons()
        self.update()

    def start_solve_tsp(self):
        """开始解算TSP：初始化状态机并启动定时器"""
        if self.state != STATE_IDLE or len(self.cities) < 2:
            return

        if self.parent() and hasattr(self.parent(), 'disable_buttons'):
            self.parent().disable_buttons()
        
        # 1. 重置路径和状态
        self.path = []
        self.unvisited = list(range(len(self.cities)))
        self.total_distance = 0.0

        # 2. 从第一个城市 (索引 0) 开始
        start_idx = 0
        self.current_city_idx = start_idx
        self.unvisited.remove(start_idx)
        self.path.append(start_idx)
        
        # 3. 设置状态机到“开始第一步”
        self.state = STATE_START_STEP
        
        # 4. 启动定时器（较快，例如100ms）
        self.solve_timer.start(100) # 100毫秒

    def _algorithm_step(self):
        """算法状态机的“心跳” (由QTimer调用)"""
        
        # 状态 1: 刚到达一个新城市，准备开始搜索
        if self.state == STATE_START_STEP:
            print(f"\n--- 正在搜索 (从城市 {self.current_city_idx}) ---")
            
            # 检查是否完成
            if not self.unvisited:
                self.state = STATE_DONE
                self.update() # 触发重绘
                return

            # 初始化搜索变量
            self.check_index = 0       # 从 unvisited 列表的第一个开始检查
            self.min_dist_so_far = float('inf')
            self.best_candidate_idx = -1
            self.current_check_idx = -1
            self.state = STATE_CHECKING
            # (立即进入下一个状态，不需要重绘)

        # 状态 2: 正在遍历所有未访问的城市
        elif self.state == STATE_CHECKING:
            
            # 检查是否已遍历完所有候选
            if self.check_index >= len(self.unvisited):
                self.state = STATE_MOVE # 遍历完成，进入“移动”状态
                self.update()
                return

            # 获取下一个要检查的候选城市
            city_to_check_idx = self.unvisited[self.check_index]
            self.current_check_idx = city_to_check_idx # 用于绘制灰线
            
            current_city_pos = self.cities[self.current_city_idx]
            check_city_pos = self.cities[city_to_check_idx]
            dist = calculate_distance(current_city_pos, check_city_pos)
            
            print(f"  > 正在检查: {city_to_check_idx} (距离: {dist:.2f})", end="")

            # 比较，看是否是新的“最近”
            if dist < self.min_dist_so_far:
                self.min_dist_so_far = dist
                self.best_candidate_idx = city_to_check_idx
                print(f" -> *新最优*")
            else:
                print("") # 换行
            
            self.check_index += 1
            self.update() # 重绘，展示灰线和可能的绿虚线

        # 状态 3: 遍历完成，执行“移动”
        elif self.state == STATE_MOVE:
            if self.best_candidate_idx == -1:
                # 理论上不应该发生，但作为安全检查
                self.state = STATE_DONE
                return
                
            print(f"--- 决策: 移动到 {self.best_candidate_idx} ---")
            
            # 1. 将“最优”城市添加到永久路径
            self.path.append(self.best_candidate_idx)
            self.unvisited.remove(self.best_candidate_idx)
            self.total_distance += self.min_dist_so_far
            
            # 2. 将“最优”城市设为新的“当前”城市
            self.current_city_idx = self.best_candidate_idx
            
            # 3. 清理可视化变量
            self.current_check_idx = -1
            self.best_candidate_idx = -1
            
            # 4. 回到“开始搜索”状态，准备下一次迭代
            self.state = STATE_START_STEP
            self.update() # 重绘，显示新的蓝色实线

        # 状态 4: 全部完成
        elif self.state == STATE_DONE:
            self.solve_timer.stop()
            
            # 计算回到起点的最后距离
            last_dist = calculate_distance(self.cities[self.path[-1]], self.cities[self.path[0]])
            self.total_distance += last_dist
            
            print("\n--- 求解完成 ---")
            print(f"路径 (索引): {self.path}")
            print(f"总距离: {self.total_distance:.2f}")

            # 清理最后的临时变量
            self.current_city_idx = -1
            self.current_check_idx = -1
            self.best_candidate_idx = -1

            if self.parent() and hasattr(self.parent(), 'enable_buttons'):
                self.parent().enable_buttons()
            
            self.update() # 触发最后一次重绘（画上闭合线）


# --- 主窗口 ---

class TSPVisualizer(QMainWindow):
    """主窗口类"""
    def __init__(self):
        super().__init__()
        self.setWindowTitle('TSP可视化 ')
        self.setGeometry(100, 100, 700, 550)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        main_layout = QVBoxLayout()
        self.central_widget.setLayout(main_layout)

        self.draw_widget = DrawWidget(self)

        self.solve_button = QPushButton('开始演示 (Start)')
        self.solve_button.clicked.connect(self.draw_widget.start_solve_tsp)

        self.clear_button = QPushButton('清除 (Clear)')
        self.clear_button.clicked.connect(self.draw_widget.clear_all)

        self.info_label = QLabel('\n1.红点表示城市。\n2. 绿色：当前城市，灰色：检查中，绿色虚线：当前最优')
        self.info_label.setWordWrap(True)
        self.info_label.setStyleSheet("padding: 10px; border: 1px solid #ccc; background-color: #f0f0f0;")

        button_layout = QHBoxLayout()
        button_layout.addWidget(self.solve_button)
        button_layout.addWidget(self.clear_button)
        
        main_layout.addWidget(self.info_label)
        main_layout.addLayout(button_layout)
        main_layout.addWidget(self.draw_widget)

    def disable_buttons(self):
        self.solve_button.setEnabled(False)
        self.clear_button.setEnabled(False)

    def enable_buttons(self):
        self.solve_button.setEnabled(True)
        self.clear_button.setEnabled(True)

# --- 程序入口 ---
if __name__ == '__main__':
    if hasattr(Qt, 'AA_EnableHighDpiScaling'):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    window = TSPVisualizer()
    window.show()
    sys.exit(app.exec_()) 