import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
rcParams['axes.unicode_minus'] = False


class SOM:
    def __init__(self, grid_size, input_dim, learning_rate_schedule, neighborhood_schedule):
        self.grid_size = grid_size
        self.input_dim = input_dim
        self.learning_rate_schedule = learning_rate_schedule
        self.neighborhood_schedule = neighborhood_schedule
        self.weights = np.random.rand(grid_size, grid_size, input_dim)

        self.neuron_positions = np.array([[i, j] for i in range(grid_size) for j in range(grid_size)])
        self.neuron_positions = self.neuron_positions.reshape(grid_size, grid_size, 2)

    def get_learning_rate(self, t):
        """根据训练步数获取学习率"""
        if t <= 1000:
            return 0.5 - (0.5 - 0.04) * (t / 1000)
        elif t <= 10000:
            return 0.04 * (1 - (t - 1000) / 9000)
        else:
            return 0

    def get_neighborhood_radius(self, t):
        """根据训练步数获取邻域半径"""
        if t <= 1000:
            # 前1000步从2线性下降至0
            return 2 * (1 - t / 1000)
        else:
            return 0

    def find_bmu(self, x):
        """找到最佳匹配单元(BMU)"""
        distances = np.sum((self.weights - x) ** 2, axis=2)
        bmu_idx = np.unravel_index(np.argmin(distances), distances.shape)
        return bmu_idx

    def neighborhood_function(self, distance, radius):
        """邻域函数 - 高斯函数"""
        if radius == 0:
            return 1.0 if distance == 0 else 0.0
        return np.exp(-distance ** 2 / (2 * radius ** 2))

    def train(self, data, total_steps=10000, save_interval=200):
        """训练SOM网络"""
        saved_weights = []

        for t in range(total_steps + 1):

            x = data[np.random.randint(len(data))]

            lr = self.get_learning_rate(t)
            radius = self.get_neighborhood_radius(t)

            bmu_i, bmu_j = self.find_bmu(x)
            bmu_pos = np.array([bmu_i, bmu_j])

            for i in range(self.grid_size):
                for j in range(self.grid_size):

                    distance_to_bmu = np.linalg.norm(np.array([i, j]) - bmu_pos)

                    influence = self.neighborhood_function(distance_to_bmu, radius)

                    self.weights[i, j] += lr * influence * (x - self.weights[i, j])
            if t % save_interval == 0:
                saved_weights.append(self.weights.copy())
                if t % 1000 == 0:
                    print(f"步骤 {t}: 学习率 = {lr:.4f}, 邻域半径 = {radius:.4f}")

        return saved_weights

    def map_data(self, data):
        """将数据映射到输出平面"""
        mappings = []
        for x in data:
            bmu_i, bmu_j = self.find_bmu(x)
            mappings.append((bmu_i, bmu_j))
        return mappings

X1 = np.array([1, 0, 0, 0])
X2 = np.array([1, 1, 0, 0])
X3 = np.array([1, 1, 0, 0])
X4 = np.array([0, 1, 0, 0])
X5 = np.array([1, 1, 1, 1])

data = np.array([X1, X2, X3, X4, X5])
labels = ['X1', 'X2', 'X3', 'X4', 'X5']

grid_size = 5
input_dim = 4

def learning_rate_schedule(t):
    if t <= 1000:
        return 0.5 - (0.5 - 0.04) * (t / 1000)
    elif t <= 10000:
        return 0.04 * (1 - (t - 1000) / 9000)
    else:
        return 0
def neighborhood_schedule(t):
    if t <= 1000:
        return 2 * (1 - t / 1000)
    else:
        return 0
som = SOM(grid_size, input_dim, learning_rate_schedule, neighborhood_schedule)
print("开始训练SOM网络...")
saved_weights = som.train(data, total_steps=10000, save_interval=200)
final_mappings = som.map_data(data)
plt.figure(figsize=(15, 10))
plt.subplot(2, 3, 1)
for i in range(grid_size):
    for j in range(grid_size):
        plt.plot(j, i, 'ko', markersize=8, alpha=0.3)
colors = ['red', 'blue', 'green', 'orange', 'purple']
markers = ['o', 's', '^', 'D', 'v']  # 不同形状的标记
for idx, (i, j) in enumerate(final_mappings):
    plt.plot(j, i, marker=markers[idx], color=colors[idx], markersize=15,
             label=f'{labels[idx]} ({i},{j})', markeredgecolor='black', markeredgewidth=1)
    plt.text(j + 0.15, i + 0.15, labels[idx], fontsize=12, fontweight='bold')

plt.xlim(-0.5, grid_size - 0.5)
plt.ylim(-0.5, grid_size - 0.5)
plt.gca().invert_yaxis()  # 反转y轴以符合常规坐标
plt.grid(True, alpha=0.3)
plt.title('SOM最终映射结果', fontsize=14, fontweight='bold')
plt.xlabel('X坐标', fontsize=12)
plt.ylabel('Y坐标', fontsize=12)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.subplot(2, 3, 2)
steps = np.arange(0, 10001, 100)
learning_rates = [learning_rate_schedule(t) for t in steps]
plt.plot(steps, learning_rates, 'b-', linewidth=2)
plt.title('学习率变化曲线', fontsize=14, fontweight='bold')
plt.xlabel('训练步数', fontsize=12)
plt.ylabel('学习率', fontsize=12)
plt.grid(True, alpha=0.3)
plt.subplot(2, 3, 3)
neighborhood_radii = [neighborhood_schedule(t) for t in steps]
plt.plot(steps, neighborhood_radii, 'r-', linewidth=2)
plt.title('邻域半径变化曲线', fontsize=14, fontweight='bold')
plt.xlabel('训练步数', fontsize=12)
plt.ylabel('邻域半径', fontsize=12)
plt.grid(True, alpha=0.3)
plt.subplot(2, 3, 4)
weight_magnitude = np.linalg.norm(som.weights, axis=2)
im = plt.imshow(weight_magnitude, cmap='hot', interpolation='nearest')
plt.colorbar(im, label='权重模长')
plt.title('最终权重模长热力图', fontsize=14, fontweight='bold')
plt.xlabel('X坐标', fontsize=12)
plt.ylabel('Y坐标', fontsize=12)
plt.subplot(2, 3, 5)
feature_names = ['特征1', '特征2', '特征3', '特征4']
x_pos = np.arange(len(feature_names))
width = 0.15

for i, (pattern, label) in enumerate(zip(data, labels)):
    plt.bar(x_pos + i * width, pattern, width, label=label, alpha=0.7)

plt.title('输入模式特征分布', fontsize=14, fontweight='bold')
plt.xlabel('特征维度', fontsize=12)
plt.ylabel('特征值', fontsize=12)
plt.xticks(x_pos + width * 2, feature_names)
plt.legend()

plt.subplot(2, 3, 6)
distance_matrix = np.zeros((grid_size, grid_size))
for i in range(grid_size):
    for j in range(grid_size):
        for k in range(grid_size):
            for l in range(grid_size):
                distance_matrix[i, j] += np.linalg.norm(som.weights[i, j] - som.weights[k, l])
        distance_matrix[i, j] /= (grid_size * grid_size)  # 平均距离

im = plt.imshow(distance_matrix, cmap='coolwarm', interpolation='nearest')
plt.colorbar(im, label='平均权重距离')
plt.title('神经元间平均距离', fontsize=14, fontweight='bold')
plt.xlabel('X坐标', fontsize=12)
plt.ylabel('Y坐标', fontsize=12)

for idx, (i, j) in enumerate(final_mappings):
    plt.plot(j, i, marker=markers[idx], color=colors[idx], markersize=10,
             markeredgecolor='black', markeredgewidth=1)

plt.tight_layout()
plt.show()

print("\n" + "=" * 50)
print("最终映射结果:")
print("=" * 50)
for idx, (label, mapping, pattern) in enumerate(zip(labels, final_mappings, data)):
    print(f"{label}: 映射到神经元位置 ({mapping[0]}, {mapping[1]})")
    print(f"     输入模式: {pattern}")
    print(f"     对应权重: {som.weights[mapping[0], mapping[1]]}")
    print()

print("训练过程中的权重变化:")
print("步骤\t平均权重模长")
for i, weights in enumerate(saved_weights[::5]):
    step = i * 1000
    weight_norm = np.mean(np.linalg.norm(weights, axis=2))
    print(f"{step}\t{weight_norm:.4f}")

plt.figure(figsize=(15, 8))
selected_steps = [0, 1000, 2000, 5000, 10000]
selected_indices = [step // 200 for step in selected_steps]

for idx, step in enumerate(selected_steps):
    if step // 200 < len(saved_weights):
        temp_som = SOM(grid_size, input_dim, learning_rate_schedule, neighborhood_schedule)
        temp_som.weights = saved_weights[step // 200].copy()
        mappings_step = temp_som.map_data(data)

        plt.subplot(2, 5, idx + 1)
        for i in range(grid_size):
            for j in range(grid_size):
                plt.plot(j, i, 'ko', markersize=4, alpha=0.3)

        for pattern_idx, (i, j) in enumerate(mappings_step):
            plt.plot(j, i, marker=markers[pattern_idx], color=colors[pattern_idx],
                     markersize=10, markeredgecolor='black', markeredgewidth=0.5)
            plt.text(j + 0.1, i + 0.1, labels[pattern_idx], fontsize=9)

        plt.xlim(-0.5, grid_size - 0.5)
        plt.ylim(-0.5, grid_size - 0.5)
        plt.gca().invert_yaxis()
        plt.title(f'第 {step} 步', fontsize=12, fontweight='bold')
        plt.xlabel('X坐标', fontsize=10)
        plt.ylabel('Y坐标', fontsize=10)
        plt.grid(True, alpha=0.3)

plt.suptitle('训练过程中映射位置的变化', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()
plt.figure(figsize=(10, 8))
u_matrix = np.zeros((grid_size, grid_size))
for i in range(grid_size):
    for j in range(grid_size):
        distances = []
        neighbors = [(i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)]
        for ni, nj in neighbors:
            if 0 <= ni < grid_size and 0 <= nj < grid_size:
                distances.append(np.linalg.norm(som.weights[i, j] - som.weights[ni, nj]))
        u_matrix[i, j] = np.mean(distances) if distances else 0

plt.imshow(u_matrix, cmap='bone', interpolation='nearest')
plt.colorbar(label='邻域距离')

for pattern_idx, (i, j) in enumerate(final_mappings):
    plt.plot(j, i, marker=markers[pattern_idx], color=colors[pattern_idx],
             markersize=12, markeredgecolor='white', markeredgewidth=2,
             label=f'{labels[pattern_idx]} ({i},{j})')
    plt.text(j + 0.1, i + 0.1, labels[pattern_idx], fontsize=10,
             fontweight='bold', color='white')
plt.title('U-Matrix 可视化\n(颜色越深表示神经元间距离越大)', fontsize=14, fontweight='bold')
plt.xlabel('X坐标', fontsize=12)
plt.ylabel('Y坐标', fontsize=12)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()