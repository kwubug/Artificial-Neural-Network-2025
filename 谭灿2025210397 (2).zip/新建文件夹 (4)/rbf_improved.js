// RBF神经网络类
class RBFNetwork {
    constructor(M, inputDim = 1) {
        this.M = M; // 隐层节点数
        this.inputDim = inputDim;
        
        // 初始化参数
        this.centers = []; // 数据中心
        this.widths = [];  // 扩展常数
        this.weights = []; // 输出权重
        this.bias = 0;     // 偏置项
        
        this.initialized = false;
    }
    
    // 初始化网络参数
    initialize() {
        this.centers = [];
        this.widths = [];
        this.weights = [];
        
        // 随机初始化参数
        for (let i = 0; i < this.M; i++) {
            // 数据中心在 [-4.0, 4.0] 内随机
            this.centers.push((Math.random() * 8) - 4);
            
            // 扩展常数在 [0.1, 0.3] 内随机
            this.widths.push(0.1 + Math.random() * 0.2);
            
            // 权重在 [-0.1, 0.1] 内随机
            this.weights.push((Math.random() * 0.2) - 0.1);
        }
        
        // 偏置项也在 [-0.1, 0.1] 内随机
        this.bias = (Math.random() * 0.2) - 0.1;
        
        this.initialized = true;
    }
    
    // RBF基函数（高斯函数）
    gaussian(x, center, width) {
        const distance = Math.pow(x - center, 2);
        return Math.exp(-distance / (2 * Math.pow(width, 2)));
    }
    
    // 前向传播
    forward(x) {
        if (!this.initialized) {
            throw new Error("网络未初始化");
        }
        
        let output = this.bias;
        
        for (let i = 0; i < this.M; i++) {
            const phi = this.gaussian(x, this.centers[i], this.widths[i]);
            output += this.weights[i] * phi;
        }
        
        return output;
    }
    
    // 计算所有基函数的输出
    getBasisOutputs(x) {
        const outputs = [];
        for (let i = 0; i < this.M; i++) {
            outputs.push(this.gaussian(x, this.centers[i], this.widths[i]));
        }
        return outputs;
    }
    
    // 梯度下降训练
    train(x, y, learningRate) {
        if (!this.initialized) {
            throw new Error("网络未初始化");
        }
        
        // 前向传播
        const output = this.forward(x);
        const error = output - y;
        
        // 计算基函数输出
        const basisOutputs = this.getBasisOutputs(x);
        
        // 更新权重和偏置
        for (let i = 0; i < this.M; i++) {
            // 权重梯度
            const weightGradient = error * basisOutputs[i];
            this.weights[i] -= learningRate * weightGradient;
            
            // 数据中心梯度
            const centerGradient = error * this.weights[i] * basisOutputs[i] * 
                                 (x - this.centers[i]) / Math.pow(this.widths[i], 2);
            this.centers[i] -= learningRate * centerGradient;
            
            // 扩展常数梯度
            const widthGradient = error * this.weights[i] * basisOutputs[i] * 
                                Math.pow(x - this.centers[i], 2) / Math.pow(this.widths[i], 3);
            this.widths[i] -= learningRate * widthGradient;
        }
        
        // 偏置梯度
        this.bias -= learningRate * error;
        
        return error;
    }
    
    // 获取网络参数
    getParameters() {
        return {
            centers: [...this.centers],
            widths: [...this.widths],
            weights: [...this.weights],
            bias: this.bias
        };
    }
}

// Hermit多项式函数
function hermitFunction(x) {
    return 1.1 * (1 - x + 2 * Math.pow(x, 2)) * Math.exp(-Math.pow(x, 2) / 2);
}

// 生成训练样本
function generateTrainingData(P, noiseStd) {
    const data = [];
    
    for (let i = 0; i < P; i++) {
        // 在 [-4, 4] 内均匀分布的输入
        const x = (Math.random() * 8) - 4;
        
        // 真实输出
        const trueY = hermitFunction(x);
        
        // 添加高斯噪声
        const noise = noiseStd * (Math.random() * 2 - 1) * Math.sqrt(3); // 近似正态分布
        const y = trueY + noise;
        
        data.push({ x, y, trueY });
    }
    
    return data;
}

// 计算均方误差
function calculateMSE(network, data) {
    let totalError = 0;
    
    for (const point of data) {
        const output = network.forward(point.x);
        const error = output - point.y;
        totalError += Math.pow(error, 2);
    }
    
    return totalError / data.length;
}

// 全局变量
let rbfNetwork = null;
let trainingData = [];
let isTraining = false;
let trainingInterval = null;
let currentEpoch = 0;
let startTime = null;
let errorHistory = [];
let animationFrameId = null;
let lastChartUpdate = 0;

// 初始化图表
let chart = null;
function initializeChart() {
    const ctx = document.getElementById('chart').getContext('2d');
    
    if (chart) {
        chart.destroy();
    }
    
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [
                {
                    label: '真实函数 F(x)',
                    data: [],
                    borderColor: '#ff6b6b',
                    backgroundColor: 'rgba(255, 107, 107, 0.1)',
                    borderWidth: 2,
                    fill: false,
                    pointRadius: 0
                },
                {
                    label: 'RBF网络输出',
                    data: [],
                    borderColor: '#4ecdc4',
                    backgroundColor: 'rgba(78, 205, 196, 0.1)',
                    borderWidth: 2,
                    fill: false,
                    pointRadius: 0
                },
                {
                    label: '训练样本点',
                    data: [],
                    borderColor: '#45b7d1',
                    backgroundColor: '#45b7d1',
                    borderWidth: 0,
                    pointRadius: 3,
                    showLine: false
                },
                {
                    label: 'RBF基函数',
                    data: [],
                    borderColor: '#96ceb4',
                    backgroundColor: 'rgba(150, 206, 180, 0.3)',
                    borderWidth: 1,
                    fill: false,
                    pointRadius: 0,
                    borderDash: [5, 5]
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 300, // 添加动画效果
                easing: 'easeOutQuart'
            },
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom',
                    title: {
                        display: true,
                        text: 'x'
                    },
                    min: -4,
                    max: 4
                },
                y: {
                    title: {
                        display: true,
                        text: 'F(x)'
                    },
                    min: -2,
                    max: 3
                }
            },
            plugins: {
                legend: {
                    display: true, // 显示图例
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            }
        }
    });
}

// 平滑更新图表（使用requestAnimationFrame实现动画效果）
function smoothUpdateChart() {
    if (!chart || !rbfNetwork) return;
    
    const now = Date.now();
    // 限制更新频率，避免过度渲染
    if (now - lastChartUpdate < 100) { // 每100ms更新一次
        return;
    }
    lastChartUpdate = now;
    
    // 生成真实函数数据点
    const trueFunctionData = [];
    for (let x = -4; x <= 4; x += 0.1) {
        trueFunctionData.push({ x, y: hermitFunction(x) });
    }
    
    // 生成RBF网络输出数据点
    const rbfOutputData = [];
    for (let x = -4; x <= 4; x += 0.1) {
        rbfOutputData.push({ x, y: rbfNetwork.forward(x) });
    }
    
    // 生成所有基函数数据点（显示前3个基函数）
    const basisFunctionData = [];
    const maxBasisToShow = Math.min(3, rbfNetwork.M);
    
    for (let i = 0; i < maxBasisToShow; i++) {
        const basisPoints = [];
        for (let x = -4; x <= 4; x += 0.1) {
            const phi = rbfNetwork.gaussian(x, rbfNetwork.centers[i], rbfNetwork.widths[i]);
            // 缩放并偏移以便在图表中显示
            basisPoints.push({ x, y: phi * 1.5 + 0.5 });
        }
        basisFunctionData.push(basisPoints);
    }
    
    // 更新图表数据
    chart.data.datasets[0].data = trueFunctionData;
    chart.data.datasets[1].data = rbfOutputData;
    chart.data.datasets[2].data = trainingData.map(point => ({ x: point.x, y: point.y }));
    
    // 动态更新基函数显示
    while (chart.data.datasets.length > 3 + maxBasisToShow) {
        chart.data.datasets.pop();
    }
    
    while (chart.data.datasets.length < 3 + maxBasisToShow) {
        chart.data.datasets.push({
            label: `基函数 ${chart.data.datasets.length - 2}`,
            data: [],
            borderColor: `hsl(${(chart.data.datasets.length - 3) * 60}, 70%, 60%)`,
            backgroundColor: 'transparent',
            borderWidth: 1,
            fill: false,
            pointRadius: 0,
            borderDash: [5, 5]
        });
    }
    
    for (let i = 0; i < maxBasisToShow; i++) {
        chart.data.datasets[3 + i].data = basisFunctionData[i];
    }
    
    chart.update();
}

// 添加日志
function addLog(message, type = 'info') {
    const logContainer = document.getElementById('errorLog');
    const logItem = document.createElement('div');
    logItem.className = `error-item ${type}`;
    logItem.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    
    logContainer.appendChild(logItem);
    logContainer.scrollTop = logContainer.scrollHeight;
    
    // 限制日志数量
    if (logContainer.children.length > 50) {
        logContainer.removeChild(logContainer.firstChild);
    }
}

// 开始训练
function startTraining() {
    if (isTraining) return;
    
    // 获取参数
    const learningRate = parseFloat(document.getElementById('learningRate').value);
    const M = parseInt(document.getElementById('hiddenNodes').value);
    const maxEpochs = parseInt(document.getElementById('maxEpochs').value);
    const targetError = parseFloat(document.getElementById('targetError').value);
    const P = parseInt(document.getElementById('sampleSize').value);
    const noiseStd = parseFloat(document.getElementById('noiseStd').value);
    
    // 验证参数
    if (isNaN(learningRate) || learningRate <= 0) {
        addLog('学习率必须大于0', 'error');
        return;
    }
    
    // 初始化网络
    rbfNetwork = new RBFNetwork(M);
    rbfNetwork.initialize();
    
    // 生成训练数据
    trainingData = generateTrainingData(P, noiseStd);
    
    // 初始化图表
    initializeChart();
    
    // 重置状态
    currentEpoch = 0;
    errorHistory = [];
    startTime = Date.now();
    isTraining = true;
    lastChartUpdate = 0;
    
    // 更新UI
    document.getElementById('startBtn').disabled = true;
    document.getElementById('pauseBtn').disabled = false;
    document.getElementById('trainingStatus').textContent = '训练中';
    
    addLog(`开始训练RBF网络: M=${M}, η=${learningRate}, P=${P}`);
    
    // 立即显示初始状态
    smoothUpdateChart();
    
    // 开始训练循环
    trainingInterval = setInterval(() => {
        if (!isTraining) return;
        
        // 执行一次训练迭代
        let epochError = 0;
        
        // 随机打乱数据顺序
        const shuffledData = [...trainingData].sort(() => Math.random() - 0.5);
        
        for (const point of shuffledData) {
            const error = rbfNetwork.train(point.x, point.y, learningRate);
            epochError += Math.pow(error, 2);
        }
        
        const mse = epochError / trainingData.length;
        errorHistory.push(mse);
        currentEpoch++;
        
        // 更新UI
        document.getElementById('currentEpoch').textContent = currentEpoch;
        document.getElementById('currentError').textContent = mse.toFixed(4);
        
        const elapsedTime = (Date.now() - startTime) / 1000;
        document.getElementById('trainingTime').textContent = `${elapsedTime.toFixed(1)}s`;
        
        const progress = Math.min((currentEpoch / maxEpochs) * 100, 100);
        document.getElementById('progressFill').style.width = `${progress}%`;
        
        // 每次迭代都更新图表（使用平滑动画）
        smoothUpdateChart();
        
        // 检查停止条件
        if (mse <= targetError || currentEpoch >= maxEpochs) {
            stopTraining();
            
            if (mse <= targetError) {
                addLog(`训练完成！达到目标误差 ${mse.toFixed(4)} <= ${targetError}`, 'success');
                document.getElementById('trainingStatus').textContent = '训练完成';
            } else {
                addLog(`训练完成！达到最大迭代次数 ${currentEpoch}`, 'success');
                document.getElementById('trainingStatus').textContent = '达到最大迭代';
            }
        }
        
        // 每100次迭代记录一次日志
        if (currentEpoch % 100 === 0) {
            addLog(`迭代 ${currentEpoch}: MSE = ${mse.toFixed(4)}`);
        }
        
    }, 50); // 每50ms执行一次迭代（降低频率以提供更好的动画效果）
}

// 暂停训练
function pauseTraining() {
    if (!isTraining) return;
    
    isTraining = false;
    document.getElementById('pauseBtn').textContent = '继续训练';
    document.getElementById('trainingStatus').textContent = '已暂停';
    addLog('训练已暂停');
}

// 继续训练
function continueTraining() {
    if (isTraining) return;
    
    isTraining = true;
    document.getElementById('pauseBtn').textContent = '暂停训练';
    document.getElementById('trainingStatus').textContent = '训练中';
    addLog('训练继续');
}

// 停止训练
function stopTraining() {
    isTraining = false;
    
    if (trainingInterval) {
        clearInterval(trainingInterval);
        trainingInterval = null;
    }
    
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
    
    document.getElementById('startBtn').disabled = false;
    document.getElementById('pauseBtn').disabled = true;
    document.getElementById('pauseBtn').textContent = '暂停训练';
}

// 重置训练
function resetTraining() {
    stopTraining();
    
    rbfNetwork = null;
    trainingData = [];
    currentEpoch = 0;
    errorHistory = [];
    
    // 重置UI
    document.getElementById('currentEpoch').textContent = '0';
    document.getElementById('currentError').textContent = '-';
    document.getElementById('trainingStatus').textContent = '等待开始';
    document.getElementById('trainingTime').textContent = '0s';
    document.getElementById('progressFill').style.width = '0%';
    
    // 清空图表
    if (chart) {
        chart.data.datasets.forEach(dataset => dataset.data = []);
        chart.update();
    }
    
    // 清空日志
    const logContainer = document.getElementById('errorLog');
    logContainer.innerHTML = '<div class="error-item success">系统已重置，点击"开始训练"按钮开始RBF网络训练</div>';
    
    addLog('系统已重置');
}

// 导出结果
function exportResults() {
    if (!rbfNetwork || errorHistory.length === 0) {
        addLog('没有训练结果可导出', 'error');
        return;
    }
    
    const results = {
        parameters: rbfNetwork.getParameters(),
        trainingHistory: {
            epochs: currentEpoch,
            finalError: errorHistory[errorHistory.length - 1],
            errorHistory: errorHistory,
            trainingData: trainingData
        },
        timestamp: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(results, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `rbf_training_results_${new Date().getTime()}.json`;
    link.click();
    
    addLog('训练结果已导出');
}

// 暂停/继续训练切换
function togglePauseTraining() {
    if (isTraining) {
        pauseTraining();
    } else {
        continueTraining();
    }
}

// 页面加载完成后初始化
window.addEventListener('DOMContentLoaded', function() {
    // 初始化图表
    initializeChart();
    
    // 添加事件监听器
    document.getElementById('pauseBtn').addEventListener('click', togglePauseTraining);
    
    addLog('RBF网络系统初始化完成');
});

// 页面卸载时清理
window.addEventListener('beforeunload', function() {
    if (trainingInterval) {
        clearInterval(trainingInterval);
    }
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
    }
});