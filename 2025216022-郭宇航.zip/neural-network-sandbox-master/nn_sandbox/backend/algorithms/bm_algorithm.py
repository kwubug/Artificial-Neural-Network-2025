"""
Boltzmann Machine (BM) Algorithm Implementation

A probabilistic recurrent neural network that can learn patterns and sample
from learned distributions through stochastic updates governed by temperature.

This implementation focuses on a 3-neuron network for clear visualization of:
- Boltzmann distribution and thermal equilibrium
- Gibbs sampling process
- Temperature-dependent state transitions
- Energy landscape exploration
"""

import numpy as np
from typing import List, Tuple, Callable


class BoltzmannMachine:
    """
    Three-neuron Boltzmann Machine with temperature-based probabilistic updates.
    
    Key differences from Hopfield:
    1. Updates are probabilistic (stochastic), not deterministic
    2. Temperature controls randomness: high T = chaotic, low T = deterministic
    3. System reaches Boltzmann distribution, not single attractor
    4. Can escape local minima through thermal noise
    
    Mathematical basis:
    - Energy: E(x) = -0.5 * sum(W_ij * x_i * x_j) - sum(b_i * x_i)
    - Boltzmann distribution: P(x) = exp(-E(x)/T) / Z
    - Gibbs sampling: P(x_i=1 | others, T) = sigmoid(energy_diff / T)
    """
    
    def __init__(self, num_neurons: int = 3):
        """
        Initialize Boltzmann Machine.
        
        Args:
            num_neurons: Number of neurons (default: 3 for visualization)
        """
    # no base class initialization required
        
        # Network parameters
        self._num_neurons = num_neurons
        self._num_states = 2 ** num_neurons  # Total possible states
        
        # Initialize weights (symmetric, no self-connections)
        self._weights = np.zeros((num_neurons, num_neurons))
        self._biases = np.zeros(num_neurons)
        self._initialize_weights()
        
        # Current state (binary: 0 or 1)
        self._state = np.random.randint(0, 2, num_neurons)
        
        # Temperature parameter
        self._temperature = 1.0
        
        # Energy and probabilities
        self._energy = self._calculate_energy(self._state)
        self._probabilities = np.zeros(self._num_states)
        self._update_all_probabilities()
        
        # Statistics and history
        self._iteration = 0
        self._state_history = []  # List of state indices (0-7 for 3 neurons)
        self._visit_count = np.zeros(self._num_states)
        self._energy_history = []
        self._temperature_history = []
        
        # Convergence tracking
        self._thermal_equilibrium = False
        self._converged_iteration = -1
        
        # For computing thermal equilibrium
        self._equilibrium_threshold = 0.95  # Threshold for state distribution convergence
        self._check_equilibrium_interval = 10  # Check every N steps
        
    # no observer pattern in backend; bridge pulls state when needed
    
    def _initialize_weights(self):
        """Initialize weights with small random values."""
        # Generate symmetric random weights
        random_vals = np.random.randn(self._num_neurons, self._num_neurons) * 0.5
        self._weights = (random_vals + random_vals.T) / 2
        
        # Set diagonal to zero (no self-connections in typical BM)
        np.fill_diagonal(self._weights, 0)
        
        # Initialize biases
        self._biases = np.random.randn(self._num_neurons) * 0.3
    
    def _calculate_energy(self, state: np.ndarray) -> float:
        """
        Calculate energy of a given state.
        
        E(x) = -0.5 * sum_ij(W_ij * x_i * x_j) - sum_i(b_i * x_i)
        
        Args:
            state: Binary state vector [x_1, x_2, ..., x_n]
            
        Returns:
            Energy value (float)
        """
        # Quadratic term from weights
        energy = -0.5 * np.dot(state, np.dot(self._weights, state))
        
        # Linear term from biases
        energy -= np.dot(self._biases, state)
        
        return float(energy)
    
    def _state_to_index(self, state: np.ndarray) -> int:
        """Convert binary state vector to state index (0 to 2^n-1)."""
        index = 0
        for i, bit in enumerate(state):
            index += int(bit) * (2 ** i)
        return index
    
    def _index_to_state(self, index: int) -> np.ndarray:
        """Convert state index back to binary state vector."""
        state = np.zeros(self._num_neurons, dtype=int)
        for i in range(self._num_neurons):
            state[i] = (index >> i) & 1
        return state
    
    def _update_all_probabilities(self):
        """
        Calculate probability of all states under current temperature.
        Uses Boltzmann distribution: P(s) = exp(-E(s)/T) / Z
        
        Note: For numerical stability, we subtract the minimum energy.
        """
        energies = np.zeros(self._num_states)
        
        # Calculate energy for each possible state
        for state_idx in range(self._num_states):
            state = self._index_to_state(state_idx)
            energies[state_idx] = self._calculate_energy(state)
        
        # Numerical stability: subtract minimum energy
        min_energy = np.min(energies)
        
        # Calculate unnormalized probabilities
        if self._temperature > 0:
            exp_energies = np.exp(-(energies - min_energy) / self._temperature)
        else:
            # At T=0, only minimum energy state has non-zero probability
            exp_energies = np.zeros(self._num_states)
            min_idx = np.argmin(energies)
            exp_energies[min_idx] = 1.0
        
        # Normalize to get probabilities
        partition_function = np.sum(exp_energies)
        if partition_function > 0:
            self._probabilities = exp_energies / partition_function
        else:
            self._probabilities = np.ones(self._num_states) / self._num_states
    
    def gibbs_step(self):
        """
        Execute one Gibbs sampling step.
        
        1. Randomly select a neuron i
        2. Calculate probability P(x_i = 1 | other neurons, T)
        3. Sample new state from Bernoulli(P)
        4. Update state and statistics
        """
        # Randomly select a neuron to update
        neuron_idx = np.random.randint(0, self._num_neurons)
        
        # Calculate the contribution from other neurons
        input_sum = np.dot(self._weights[neuron_idx], self._state) + self._biases[neuron_idx]
        
        # Calculate activation probability using sigmoid with temperature
        # Use numerically stable sigmoid: if x is very large/small, prob ≈ 0 or 1
        if self._temperature > 0:
            scaled_input = 2.0 * input_sum / self._temperature
            # Clamp scaled input to avoid overflow in exp()
            scaled_input = np.clip(scaled_input, -500, 500)
            prob = 1.0 / (1.0 + np.exp(-scaled_input))
        else:
            # At very low temperature, use deterministic rule
            prob = 1.0 if input_sum > 0 else 0.0
        
        # Clamp probability to valid range [0, 1]
        prob = np.clip(prob, 0.0, 1.0)
        
        # Sample new state for this neuron
        self._state[neuron_idx] = 1 if np.random.random() < prob else 0
        
        # Update energy
        self._energy = self._calculate_energy(self._state)
        
        # Update statistics
        state_idx = self._state_to_index(self._state)
        self._state_history.append(state_idx)
        self._visit_count[state_idx] += 1
        self._energy_history.append(self._energy)
        
        self._iteration += 1
    
    def step(self):
        """Execute one algorithm step (Gibbs sampling)."""
        self.gibbs_step()
        
        # Check for thermal equilibrium periodically
        if self._iteration % self._check_equilibrium_interval == 0:
            self._check_thermal_equilibrium()
        # bridge should synchronize state after calling step()
    
    def _check_thermal_equilibrium(self):
        """
        Check if system has reached thermal equilibrium.
        
        Strategy: Compare current state distribution (last N steps) 
        with theoretical Boltzmann distribution.
        """
        if self._iteration < 50:
            return
        
        # Get recent state distribution
        window_size = min(50, self._iteration)
        recent_states = self._state_history[-window_size:]
        recent_dist = np.zeros(self._num_states)
        for state_idx in recent_states:
            recent_dist[state_idx] += 1
        recent_dist /= (window_size + 1e-10)
        
        # Calculate theoretical distribution
        self._update_all_probabilities()
        theoretical_dist = self._probabilities
        
        # Calculate KL divergence (simple similarity check)
        # If distributions are similar, system is in thermal equilibrium
        # Use safe log: add small epsilon to avoid log(0)
        epsilon = 1e-10
        with np.errstate(divide='ignore', invalid='ignore'):
            kl_div = np.sum(
                np.where(
                    (recent_dist > epsilon) & (theoretical_dist > epsilon),
                    recent_dist * np.log((recent_dist + epsilon) / (theoretical_dist + epsilon)),
                    0
                )
            )
        
        # Handle NaN
        if np.isnan(kl_div):
            kl_div = float('inf')
        
        # Consider equilibrium reached if KL divergence is small
        if kl_div < 0.1 and not self._thermal_equilibrium:
            self._thermal_equilibrium = True
            self._converged_iteration = self._iteration
        elif kl_div > 0.2:
            self._thermal_equilibrium = False
    
    def anneal(self, initial_temp: float = 3.0, 
               final_temp: float = 0.01, 
               cooling_rate: float = 0.05,
               steps_per_temp: int = 10) -> dict:
        """
        Run simulated annealing from high to low temperature.
        
        This demonstrates how temperature affects state exploration:
        - High T: chaotic exploration of all states
        - Low T: convergence to low-energy states
        
        Args:
            initial_temp: Starting temperature
            final_temp: Target final temperature
            cooling_rate: Rate of temperature decrease per iteration
            steps_per_temp: Gibbs steps to take at each temperature
            
        Returns:
            Dictionary with annealing statistics
        """
        self._temperature = initial_temp
        self._temperature_history = []
        total_steps = 0
        
        while self._temperature > final_temp:
            # Take multiple Gibbs steps at current temperature
            for _ in range(steps_per_temp):
                self.gibbs_step()
                total_steps += 1
            
            # Record temperature
            self._temperature_history.append(self._temperature)
            
            # Cool down: T = T / (1 + cooling_rate * iteration)
            self._temperature *= 1.0 / (1.0 + cooling_rate)
        
        # Final temperature
        self._temperature = final_temp

        # Check final equilibrium
        self._check_thermal_equilibrium()
        # bridge should synchronize state after anneal()

        return {
            'total_steps': total_steps,
            'final_temperature': self._temperature,
            'final_energy': float(self._energy),
            'thermal_equilibrium': self._thermal_equilibrium,
            'converged_at_iteration': self._converged_iteration
        }
    
    def set_temperature(self, temperature: float):
        """
        Set temperature and update probabilities.
        
        Args:
            temperature: New temperature value (must be > 0)
        """
        self._temperature = max(0.01, temperature)  # Avoid zero temperature
        self._update_all_probabilities()
    
    def set_state(self, state: List[int]):
        """
        Set the network state directly.
        
        Args:
            state: List of binary values [0 or 1, ...]
        """
        self._state = np.array(state, dtype=int)
        self._energy = self._calculate_energy(self._state)
        self._update_all_probabilities()
        
        # Record in history
        state_idx = self._state_to_index(self._state)
        self._state_history.append(state_idx)
        self._visit_count[state_idx] += 1
    
    def randomize_state(self):
        """Randomly initialize the network state."""
        self._state = np.random.randint(0, 2, self._num_neurons)
        self._energy = self._calculate_energy(self._state)
        
        state_idx = self._state_to_index(self._state)
        self._state_history.append(state_idx)
        self._visit_count[state_idx] += 1
    
    def set_weights_and_biases(self, weights: np.ndarray, biases: np.ndarray):
        """
        Set custom weights and biases.
        
        Args:
            weights: Symmetric weight matrix (n x n)
            biases: Bias vector (n,)
        """
        self._weights = np.array(weights, dtype=float)
        self._biases = np.array(biases, dtype=float)
        
        # Recalculate with new weights
        self._energy = self._calculate_energy(self._state)
        self._update_all_probabilities()
        # bridge should call get_* methods to refresh UI
    
    def reset(self):
        """Reset to initial state."""
        self._initialize_weights()
        self._state = np.random.randint(0, 2, self._num_neurons)
        self._temperature = 1.0
        self._iteration = 0
        self._state_history = []
        self._visit_count = np.zeros(self._num_states)
        self._energy_history = []
        self._temperature_history = []
        self._thermal_equilibrium = False
        self._converged_iteration = -1
        
        self._energy = self._calculate_energy(self._state)
        self._update_all_probabilities()
        # bridge should call get_* methods to refresh UI
    
    # ==================== Properties for observation ====================
    
    def get_state_vector(self) -> List[int]:
        """Get current state as list."""
        return self._state.tolist()
    
    def get_current_energy(self) -> float:
        """Get current energy."""
        return float(self._energy)
    
    def get_temperature(self) -> float:
        """Get current temperature."""
        return float(self._temperature)
    
    def get_probabilities(self) -> List[float]:
        """Get Boltzmann distribution probabilities for all states."""
        return self._probabilities.tolist()
    
    def get_state_index(self) -> int:
        """Get current state as index (0 to 2^n-1)."""
        return self._state_to_index(self._state)
    
    def get_visit_counts(self) -> List[int]:
        """Get visit count for each state."""
        return self._visit_count.tolist()
    
    def get_state_history(self) -> List[int]:
        """Get history of visited states."""
        return self._state_history.copy()
    
    def get_energy_history(self) -> List[float]:
        """Get history of energy values."""
        return [float(e) for e in self._energy_history]
    
    def get_temperature_history(self) -> List[float]:
        """Get history of temperature values."""
        return [float(t) for t in self._temperature_history]
    
    def get_iteration_count(self) -> int:
        """Get total number of iterations."""
        return self._iteration
    
    def get_thermal_equilibrium_status(self) -> bool:
        """Check if system is in thermal equilibrium."""
        return self._thermal_equilibrium
    
    def get_weights_matrix(self) -> List[List[float]]:
        """Get weight matrix."""
        return self._weights.tolist()
    
    def get_biases_vector(self) -> List[float]:
        """Get biases vector."""
        return self._biases.tolist()
    
    def get_statistics(self) -> dict:
        """Get comprehensive statistics."""
        total_visits = np.sum(self._visit_count)
        visited_states = np.sum(self._visit_count > 0)
        
        return {
            'iteration': self._iteration,
            'temperature': float(self._temperature),
            'energy': float(self._energy),
            'thermal_equilibrium': self._thermal_equilibrium,
            'visited_states': int(visited_states),
            'total_possible_states': self._num_states,
            'total_visits': int(total_visits),
            'state': self.get_state_vector(),
            'state_index': self.get_state_index()
        }
    
    def get_energy_landscape(self) -> dict:
        """
        Get energy and probability for all possible states.
        
        Useful for visualization of energy landscape.
        """
        energies = []
        probabilities = []
        
        for state_idx in range(self._num_states):
            state = self._index_to_state(state_idx)
            energy = self._calculate_energy(state)
            prob = self._probabilities[state_idx]
            
            # Ensure values are finite
            if not np.isfinite(energy):
                energy = 0.0
            if not np.isfinite(prob):
                prob = 0.0
            
            energies.append(float(energy))
            probabilities.append(float(prob))
        
        return {
            'energies': energies,
            'probabilities': probabilities,
            'num_states': self._num_states
        }
