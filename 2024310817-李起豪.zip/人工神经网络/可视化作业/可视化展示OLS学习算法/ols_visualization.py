"""
可视化展示普通最小二乘（OLS）学习过程。

脚本会：
1. 生成一组线性数据并加入噪声；
2. 使用批量梯度下降迭代逼近OLS最优参数，记录损失与参数轨迹；
3. 绘制散点图与多条回归直线、损失下降曲线、参数轨迹；
4. 保存图像与文本总结到当前目录。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

import matplotlib.pyplot as plt
import numpy as np


np.random.seed(7)


@dataclass(frozen=True)
class OLSConfig:
    sample_size: int = 120
    noise_std: float = 1.2
    true_weight: float = 2.5
    true_bias: float = -1.0
    learning_rate: float = 0.03
    iterations: int = 240


def generate_data(config: OLSConfig) -> Tuple[np.ndarray, np.ndarray]:
    x = np.random.uniform(-5, 5, size=config.sample_size)
    noise = np.random.normal(0.0, config.noise_std, size=config.sample_size)
    y = config.true_weight * x + config.true_bias + noise
    return x, y


def gradient_descent(
    x: np.ndarray, y: np.ndarray, config: OLSConfig
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    weight, bias = 0.0, 0.0
    weights, biases, losses = [], [], []
    n = x.size
    for _ in range(config.iterations):
        predictions = weight * x + bias
        residuals = predictions - y
        loss = np.mean(residuals**2) / 2.0
        grad_w = np.mean(residuals * x)
        grad_b = np.mean(residuals)
        weight -= config.learning_rate * grad_w
        bias -= config.learning_rate * grad_b
        weights.append(weight)
        biases.append(bias)
        losses.append(loss)
    return np.array(weights), np.array(biases), np.array(losses)


def plot_learning_process(
    x: np.ndarray,
    y: np.ndarray,
    weights: np.ndarray,
    biases: np.ndarray,
    losses: np.ndarray,
    config: OLSConfig,
    output_path: Path,
) -> None:
    fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(15, 4.8))

    axes[0].scatter(x, y, color="tab:blue", alpha=0.6, s=22, label="样本数据")
    step_indices = [0, len(weights) // 2, len(weights) - 1]
    colors = ["tab:orange", "tab:green", "tab:red"]
    labels = ["初始迭代", "中期迭代", "最终迭代"]
    x_grid = np.linspace(x.min() - 0.5, x.max() + 0.5, 120)
    for idx, color, label in zip(step_indices, colors, labels):
        y_grid = weights[idx] * x_grid + biases[idx]
        axes[0].plot(x_grid, y_grid, color=color, linewidth=1.6, label=f"{label} (w={weights[idx]:.2f}, b={biases[idx]:.2f})")
    axes[0].set_title("OLS学习过程中回归直线演化")
    axes[0].set_xlabel("x")
    axes[0].set_ylabel("y")
    axes[0].grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    axes[1].plot(np.arange(1, losses.size + 1), losses, color="tab:purple", linewidth=1.4)
    axes[1].set_title("损失函数下降曲线")
    axes[1].set_xlabel("迭代次数")
    axes[1].set_ylabel("半均方误差")
    axes[1].grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    axes[2].plot(weights, biases, color="tab:brown", linewidth=1.4)
    axes[2].scatter(weights[0], biases[0], color="tab:orange", s=40, label="起点")
    axes[2].scatter(weights[-1], biases[-1], color="tab:red", s=40, label="终点")
    axes[2].set_title("参数轨迹（w-b平面）")
    axes[2].set_xlabel("权重 w")
    axes[2].set_ylabel("偏置 b")
    axes[2].grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    legend_handles, legend_labels = [], []
    for ax in axes:
        handles, labels = ax.get_legend_handles_labels()
        legend_handles.extend(handles)
        legend_labels.extend(labels)
    fig.legend(
        legend_handles,
        legend_labels,
        loc="center right",
        bbox_to_anchor=(1.03, 0.5),
        frameon=False,
    )
    fig.tight_layout(rect=(0, 0, 0.92, 1))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def export_summary(
    summary_path: Path,
    weights: np.ndarray,
    biases: np.ndarray,
    losses: np.ndarray,
    config: OLSConfig,
) -> None:
    summary_lines = [
        "OLS学习算法可视化结果摘要",
        f"样本数量: {config.sample_size}",
        f"噪声标准差: {config.noise_std}",
        f"真实参数: weight={config.true_weight}, bias={config.true_bias}",
        f"学习率: {config.learning_rate}",
        f"迭代次数: {config.iterations}",
        f"最终学习到的参数: weight={weights[-1]:.4f}, bias={biases[-1]:.4f}",
        f"最终损失: {losses[-1]:.6f}",
        f"损失最小值: {losses.min():.6f}",
    ]
    summary_path.write_text("\n".join(summary_lines), encoding="utf-8")


def main() -> None:
    config = OLSConfig()
    x, y = generate_data(config)
    weights, biases, losses = gradient_descent(x, y, config)

    output_dir = Path(__file__).parent
    figure_path = output_dir / "ols_learning_visualization.png"
    summary_path = output_dir / "ols_learning_summary.txt"

    plot_learning_process(
        x=x,
        y=y,
        weights=weights,
        biases=biases,
        losses=losses,
        config=config,
        output_path=figure_path,
    )
    export_summary(
        summary_path=summary_path,
        weights=weights,
        biases=biases,
        losses=losses,
        config=config,
    )

    print(f"最终参数: weight={weights[-1]:.4f}, bias={biases[-1]:.4f}")


if __name__ == "__main__":
    main()



