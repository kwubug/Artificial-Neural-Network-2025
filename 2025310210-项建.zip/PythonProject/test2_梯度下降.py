import numpy as np
import matplotlib
matplotlib.use('TkAgg')  # 关键：启用动态后端
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from mpl_toolkits.mplot3d import Axes3D

# ---------- 目标函数 ----------
a, b = 1.0, 5.0
A = np.diag([a, b])

def f_xy(xy):
    x, y = xy
    return 0.5 * (a*x*x + b*y*y)

def grad_xy(xy):
    x, y = xy
    return np.array([a*x, b*y])

# ---------- 最速下降 ----------
def path_steepest_descent(x0, iters=30):
    xs = [x0.copy()]
    x = x0.copy()
    for _ in range(iters):
        g = grad_xy(x)
        denom = g @ (A @ g)
        if denom <= 1e-15: break
        alpha = (g @ g) / denom
        x = x - alpha * g
        xs.append(x.copy())
        if np.linalg.norm(g) < 1e-8: break
    return np.array(xs)

# ---------- 牛顿法 ----------
def path_newton(x0, iters=5):
    xs = [x0.copy()]
    x = x0.copy()
    for _ in range(iters):
        g = grad_xy(x)
        if np.linalg.norm(g) < 1e-12: break
        step = np.linalg.solve(A, g)
        x = x - step
        xs.append(x.copy())
    return np.array(xs)

# ---------- 共轭梯度 ----------
def path_conjugate_gradient(x0, iters=30):
    xs = [x0.copy()]
    x = x0.copy()
    r = -A @ x
    p = r.copy()
    rr = r @ r
    for _ in range(iters):
        Ap = A @ p
        denom = p @ Ap
        if abs(denom) < 1e-15: break
        alpha = rr / denom
        x = x + alpha * p
        xs.append(x.copy())
        r_new = r - alpha * Ap
        rr_new = r_new @ r_new
        if np.sqrt(rr_new) < 1e-12: break
        beta = rr_new / rr
        p = r_new + beta * p
        r, rr = r_new, rr_new
    return np.array(xs)

# ---------- 准备路径 ----------
x0 = np.array([1.5, 1.5])
P_sd = path_steepest_descent(x0, iters=40)
P_nt = path_newton(x0, iters=3)
P_cg = path_conjugate_gradient(x0, iters=5)

# ---------- 创建3D图形 ----------
X = np.linspace(-2.0, 2.0, 120)
Y = np.linspace(-2.0, 2.0, 120)
XX, YY = np.meshgrid(X, Y)
ZZ = 0.5 * (a * XX**2 + b * YY**2)

fig = plt.figure(figsize=(15, 5))
ax1 = fig.add_subplot(131, projection='3d')
ax2 = fig.add_subplot(132, projection='3d')
ax3 = fig.add_subplot(133, projection='3d')

for ax, title in [(ax1, 'Steepest Descent'),
                  (ax2, "Newton's Method"),
                  (ax3, 'Conjugate Gradient')]:
    ax.plot_surface(XX, YY, ZZ, alpha=0.35)
    ax.contour(XX, YY, ZZ, 20, offset=0, zdir='z', alpha=0.6)
    ax.set_xlim(-2, 2)
    ax.set_ylim(-2, 2)
    ax.set_zlim(0, 8)
    ax.set_title(title)
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('f(x,y)')

# 三条路径
line_sd, = ax1.plot([], [], [], lw=2, color='r')
pt_sd,   = ax1.plot([], [], [], 'ro')
line_nt, = ax2.plot([], [], [], lw=2, color='g')
pt_nt,   = ax2.plot([], [], [], 'go')
line_cg, = ax3.plot([], [], [], lw=2, color='b')
pt_cg,   = ax3.plot([], [], [], 'bo')

max_len = max(len(P_sd), len(P_nt), len(P_cg))

def interpolate(P, k):
    idx = min(k, len(P)-1)
    xs = P[:idx+1, 0]
    ys = P[:idx+1, 1]
    zs = 0.5 * (a*xs**2 + b*ys**2)
    return xs, ys, zs, P[idx]

def init():
    for ln, pt in [(line_sd, pt_sd), (line_nt, pt_nt), (line_cg, pt_cg)]:
        ln.set_data([], []); ln.set_3d_properties([])
        pt.set_data([], []); pt.set_3d_properties([])
    return line_sd, pt_sd, line_nt, pt_nt, line_cg, pt_cg

def update(frame):
    for (P, ln, pt) in [(P_sd, line_sd, pt_sd), (P_nt, line_nt, pt_nt), (P_cg, line_cg, pt_cg)]:
        xs, ys, zs, last = interpolate(P, frame)
        ln.set_data(xs, ys)
        ln.set_3d_properties(zs)
        pt.set_data([last[0]], [last[1]])
        pt.set_3d_properties([f_xy(last)])
    return line_sd, pt_sd, line_nt, pt_nt, line_cg, pt_cg

ani = animation.FuncAnimation(fig, update, frames=max_len, init_func=init,
                              blit=False, interval=400)

plt.show()
