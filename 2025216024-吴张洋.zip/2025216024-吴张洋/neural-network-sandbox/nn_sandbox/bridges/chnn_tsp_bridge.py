import time
import numpy as np
import PyQt5.QtCore
import threading

from nn_sandbox.backend.algorithms import CHNNTSPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class CHNNTSPBridge(Bridge):
    # 网络参数
    n_cities = BridgeProperty(8)
    A = BridgeProperty(500)
    B = BridgeProperty(500)
    C = BridgeProperty(200)
    D = BridgeProperty(500)
    dt = BridgeProperty(0.0001)
    max_iterations = BridgeProperty(5000)
    ui_refresh_interval = BridgeProperty(0.05)
    
    # 城市位置
    city_positions = BridgeProperty([])
    distance_matrix = BridgeProperty([])
    
    # 神经元状态
    neuron_matrix = BridgeProperty([])  # N×N 矩阵
    
    # 当前状态
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    current_distance = BridgeProperty(0.0)
    is_valid_solution = BridgeProperty(False)
    
    # 历史记录
    energy_history = BridgeProperty([])
    distance_history = BridgeProperty([])
    
    # 最优解
    best_tour = BridgeProperty([])
    best_distance = BridgeProperty(float('inf'))
    
    # 当前路径（实时显示，不一定是最优）
    current_tour = BridgeProperty([])
    
    # 状态
    has_finished = BridgeProperty(True)
    
    def __init__(self):
        super().__init__()
        self.chnn_algorithm = None
        self._init_random_cities()
    
    def _init_random_cities(self):
        """初始化随机城市"""
        np.random.seed(42)
        positions = np.random.rand(self.n_cities, 2).tolist()
        self.city_positions = positions
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_n_cities(self, n):
        """设置城市数量"""
        self.n_cities = n
        self._init_random_cities()
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_A(self, value):
        self.A = value
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_B(self, value):
        self.B = value
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_C(self, value):
        self.C = value
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_D(self, value):
        self.D = value
    
    @PyQt5.QtCore.pyqtSlot()
    def generate_random_cities(self):
        """生成随机城市"""
        np.random.seed(int(time.time()))
        positions = np.random.rand(self.n_cities, 2).tolist()
        self.city_positions = positions
    
    @PyQt5.QtCore.pyqtSlot()
    def start_solving(self):
        """开始求解TSP"""
        self.chnn_algorithm = ObservableCHNNTSPAlgorithm(
            self,
            self.ui_refresh_interval,
            n_cities=self.n_cities,
            A=self.A,
            B=self.B,
            C=self.C,
            D=self.D,
            dt=self.dt,
            max_iterations=self.max_iterations
        )
        
        # 使用当前城市位置
        if self.city_positions and len(self.city_positions) > 0:
            self.chnn_algorithm.set_cities(self.city_positions)
        
        self.chnn_algorithm.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_algorithm(self):
        """停止算法"""
        if self.chnn_algorithm:
            self.chnn_algorithm.stop()
            if self.chnn_algorithm.is_alive():
                self.chnn_algorithm.join(timeout=1.0)
            self.chnn_algorithm = None


class ObservableCHNNTSPAlgorithm(Observable, CHNNTSPAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        object.__setattr__(self, '_init_done', False)
        Observable.__init__(self, observer)
        CHNNTSPAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, 'ui_refresh_interval', ui_refresh_interval)
        object.__setattr__(self, '_init_done', True)
        self.daemon = True
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_init_done', False) or not hasattr(self, '_observer'):
            return
        
        if name == 'current_iterations':
            self.notify(name, value)
        elif name == 'current_energy':
            self.notify(name, value)
        elif name == 'current_distance':
            self.notify(name, value)
        elif name == 'is_valid_solution':
            self.notify(name, value)
    
    def run(self):
        try:
            self.notify('has_finished', False)
            
            # 清空历史
            self.notify('energy_history', [])
            self.notify('distance_history', [])
            self.notify('best_tour', [])
            self.notify('best_distance', float('inf'))
            
            # 初始化
            super()._initialize_neurons()
            
            # 通知初始城市位置和距离矩阵
            self.notify('city_positions', self.city_positions.tolist())
            self.notify('distance_matrix', self.distance_matrix.tolist())
            
            last_notify_time = time.time()
            
            # 迭代求解
            while self.current_iterations < self.max_iterations and not self._should_stop:
                self._iterate()
                
                current_time = time.time()
                
                # 按UI刷新间隔批量更新所有UI数据
                if current_time - last_notify_time >= self.ui_refresh_interval:
                    # 通知神经元矩阵状态
                    self.notify('neuron_matrix', self.get_current_tour_matrix())
                    
                    # 更新当前路径（实时显示）
                    if hasattr(self, 'current_tour') and self.current_tour is not None and len(self.current_tour) > 0:
                        self.notify('current_tour', list(self.current_tour))
                    
                    # 更新历史记录
                    energy_list = [float(e) for e in self.energy_history]
                    distance_list = [float(d) for d in self.distance_history]
                    self.notify('energy_history', energy_list)
                    self.notify('distance_history', distance_list)
                    
                    # 通知最优路径
                    if self.best_tour is not None and len(self.best_tour) > 0:
                        self.notify('best_tour', list(self.best_tour))
                        self.notify('best_distance', float(self.best_distance))
                    
                    last_notify_time = current_time

            # 通知最终结果
            if not self._should_stop:
                # 最终更新当前路径
                if hasattr(self, 'current_tour') and self.current_tour is not None and len(self.current_tour) > 0:
                    self.notify('current_tour', list(self.current_tour))
                elif self.best_tour is not None and len(self.best_tour) > 0:
                    self.notify('current_tour', list(self.best_tour))
                
                self.notify('energy_history', [float(e) for e in self.energy_history])
                self.notify('distance_history', [float(d) for d in self.distance_history])
                self.notify('neuron_matrix', self.get_current_tour_matrix())
                
                if self.best_tour is not None:
                    self.notify('best_tour', list(self.best_tour))
                    self.notify('best_distance', float(self.best_distance))
        except Exception as e:
            print(f"算法运行出错: {e}")
            import traceback
            traceback.print_exc()
        finally:
            try:
                self.notify('has_finished', True)
            except:
                pass


