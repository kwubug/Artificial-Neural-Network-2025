import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtQuick.Shapes 1.12

Rectangle {
    id: networkTopology
    color: "#f8f9fa"
    border.color: "#dee2e6"
    border.width: 1
    radius: 8
    
    property var inputHiddenWeights: []
    property var hiddenOutputWeights: []
    property var hiddenBias: []
    property var outputBias: []
    property var hiddenOutputs: []
    property var finalOutputs: []
    property var inputNodes: 2
    property var hiddenNodes: 5
    property var outputNodes: 3
    property var activationType: "unipolar"
    
    // 动画属性
    property real animationProgress: 0.0
    property bool showBackpropagation: false
    property int currentBackpropLayer: 0
    property var errorValues: []
    
    // 误差反传定时器
    Timer {
        id: backpropTimer
        interval: 1200
        repeat: true
        running: false
        onTriggered: {
            if (showBackpropagation) {
                currentBackpropLayer++
                if (currentBackpropLayer > 2) {
                    currentBackpropLayer = 0
                    showBackpropagation = false
                    backpropTimer.running = false
                }
                networkCanvas.requestPaint()
            }
        }
    }
    
    // 脉冲动画定时器
    Timer {
        id: pulseTimer
        interval: 200
        repeat: true
        running: showBackpropagation
        onTriggered: {
            if (showBackpropagation) {
                networkCanvas.requestPaint()
            }
        }
    }
    
    // 网络参数（进一步放大）
    property real nodeRadius: 45
    property real layerSpacing: 300
    property real nodeSpacing: 120
    property real connectionWidth: 4
    
    // 颜色定义
    readonly property color inputColor: "#4CAF50"
    readonly property color hiddenColor: "#2196F3"
    readonly property color outputColor: "#FF9800"
    readonly property color connectionColor: "#757575"
    readonly property color activeConnectionColor: "#E91E63"
    readonly property color biasColor: "#9C27B0"
    
    
    // 标题
    Text {
        id: titleText
        text: "神经网络拓扑结构"
        font.pixelSize: 24
        font.bold: true
        color: "#333333"
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.margins: 20
    }
    
    // 说明区域
    Rectangle {
        id: explanationArea
        anchors.top: titleText.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 15
        height: 80
        color: "#f8f9fa"
        border.color: "#dee2e6"
        border.width: 1
        radius: 6
        
        Row {
            anchors.fill: parent
            anchors.margins: 15
            spacing: 20
            
            // 正权重图示
            Row {
                spacing: 8
                Rectangle {
                    width: 30
                    height: 4
                    color: "#4CAF50"
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: "正权重"
                    font.pixelSize: 18
                    color: "#333333"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            
            // 负权重图示
            Row {
                spacing: 8
                Rectangle {
                    width: 30
                    height: 4
                    color: "#F44336"
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: "负权重"
                    font.pixelSize: 18
                    color: "#333333"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            
            // 权重大小图示
            Row {
                spacing: 8
                Rectangle {
                    width: 20
                    height: 2
                    color: "#757575"
                    anchors.verticalCenter: parent.verticalCenter
                }
                Rectangle {
                    width: 30
                    height: 4
                    color: "#757575"
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: "权重大小"
                    font.pixelSize: 18
                    color: "#333333"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            
            // 激活值图示
            Row {
                spacing: 8
                Rectangle {
                    width: 20
                    height: 20
                    color: "#2196F3"
                    opacity: 0.3
                    radius: 10
                    anchors.verticalCenter: parent.verticalCenter
                }
                Rectangle {
                    width: 20
                    height: 20
                    color: "#2196F3"
                    opacity: 0.8
                    radius: 10
                    anchors.verticalCenter: parent.verticalCenter
                }
                Text {
                    text: "激活值大小"
                    font.pixelSize: 18
                    color: "#333333"
                    anchors.verticalCenter: parent.verticalCenter
                }
            }
            
            // 误差反传按钮
            Button {
                text: showBackpropagation ? "停止误差反传" : "演示误差反传"
                onClicked: {
                    if (showBackpropagation) {
                        showBackpropagation = false
                        backpropTimer.running = false
                        currentBackpropLayer = 0
                    } else {
                        showBackpropagation = true
                        currentBackpropLayer = 0
                        backpropTimer.running = true
                        // 生成模拟误差值
                        generateErrorValues()
                    }
                    networkCanvas.requestPaint()
                }
                background: Rectangle {
                    color: showBackpropagation ? "#FF5722" : "#4CAF50"
                    radius: 4
                }
                contentItem: Text {
                    text: parent.text
                    font.pixelSize: 16
                    color: "white"
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }
    }
    
    // 网络结构画布
    Canvas {
        id: networkCanvas
        anchors.fill: parent
        anchors.topMargin: 140
        anchors.margins: 30
        
        onPaint: {
            var ctx = getContext("2d")
            ctx.clearRect(0, 0, width, height)
            drawNetwork(ctx)
        }
        
        function drawNetwork(ctx) {
            var centerX = width / 2
            var centerY = height / 2
            
            // 计算各层位置
            var inputLayerX = centerX - layerSpacing
            var hiddenLayerX = centerX
            var outputLayerX = centerX + layerSpacing
            
            // 绘制连接线
            drawConnections(ctx, inputLayerX, hiddenLayerX, outputLayerX, centerY)
            
            // 绘制节点
            drawNodes(ctx, inputLayerX, hiddenLayerX, outputLayerX, centerY)
            
            // 绘制偏置节点
            drawBiasNodes(ctx, hiddenLayerX, outputLayerX, centerY)
        }
        
        function drawConnections(ctx, inputX, hiddenX, outputX, centerY) {
            ctx.strokeStyle = connectionColor
            ctx.lineWidth = connectionWidth
            
            // 输入层到隐藏层连接
            for (let i = 0; i < inputNodes; i++) {
                let inputY = centerY + (i - (inputNodes - 1) / 2) * nodeSpacing
                for (let j = 0; j < hiddenNodes; j++) {
                    let hiddenY = centerY + (j - (hiddenNodes - 1) / 2) * nodeSpacing
                    
                    // 根据权重值设置连接颜色和粗细
                    let weight = 0
                    if (inputHiddenWeights.length > i && inputHiddenWeights[i].length > j) {
                        weight = inputHiddenWeights[i][j]
                    }
                    
                    let alpha = Math.abs(weight)
                    let color = weight >= 0 ? "#4CAF50" : "#F44336"
                    
                    // 误差反传时改变连接颜色
                    if (showBackpropagation && currentBackpropLayer >= 1) {
                        color = "#FF9800" // 橙色表示误差反传
                        alpha = 0.8
                        
                        // 绘制误差反传箭头
                        let arrowX = (inputX + hiddenX) / 2
                        let arrowY = (inputY + hiddenY) / 2
                        drawErrorArrow(ctx, arrowX, arrowY, inputX, inputY)
                    }
                    
                    ctx.strokeStyle = color
                    ctx.lineWidth = Math.max(1, Math.abs(weight) * 8)
                    ctx.globalAlpha = Math.max(0.2, alpha)
                    
                    ctx.beginPath()
                    ctx.moveTo(inputX + nodeRadius, inputY)
                    ctx.lineTo(hiddenX - nodeRadius, hiddenY)
                    ctx.stroke()
                    
                    // 在连接线中点显示权重值
                    let midX = (inputX + hiddenX) / 2
                    let midY = (inputY + hiddenY) / 2
                    ctx.fillStyle = "#000000"
                    ctx.font = "18px sans-serif"
                    ctx.textAlign = "center"
                    ctx.textBaseline = "middle"
                    ctx.globalAlpha = 1.0
                    ctx.fillText(weight.toFixed(2), midX, midY)
                }
            }
            
            // 隐藏层到输出层连接
            for (let i = 0; i < hiddenNodes; i++) {
                let hiddenY = centerY + (i - (hiddenNodes - 1) / 2) * nodeSpacing
                for (let j = 0; j < outputNodes; j++) {
                    let outputY = centerY + (j - (outputNodes - 1) / 2) * nodeSpacing
                    
                    let weight = 0
                    if (hiddenOutputWeights.length > i && hiddenOutputWeights[i].length > j) {
                        weight = hiddenOutputWeights[i][j]
                    }
                    
                    let alpha = Math.abs(weight)
                    let color = weight >= 0 ? "#4CAF50" : "#F44336"
                    
                    // 误差反传时改变连接颜色
                    if (showBackpropagation && currentBackpropLayer >= 0) {
                        color = "#FF9800" // 橙色表示误差反传
                        alpha = 0.8
                        
                        // 绘制误差反传箭头
                        let arrowX = (hiddenX + outputX) / 2
                        let arrowY = (hiddenY + outputY) / 2
                        drawErrorArrow(ctx, arrowX, arrowY, hiddenX, hiddenY)
                    }
                    
                    ctx.strokeStyle = color
                    ctx.lineWidth = Math.max(1, Math.abs(weight) * 8)
                    ctx.globalAlpha = Math.max(0.2, alpha)
                    
                    ctx.beginPath()
                    ctx.moveTo(hiddenX + nodeRadius, hiddenY)
                    ctx.lineTo(outputX - nodeRadius, outputY)
                    ctx.stroke()
                    
                    // 在连接线中点显示权重值
                    let midX = (hiddenX + outputX) / 2
                    let midY = (hiddenY + outputY) / 2
                    ctx.fillStyle = "#000000"
                    ctx.font = "18px sans-serif"
                    ctx.textAlign = "center"
                    ctx.textBaseline = "middle"
                    ctx.globalAlpha = 1.0
                    ctx.fillText(weight.toFixed(2), midX, midY)
                }
            }
            
            // 偏置连接
            drawBiasConnections(ctx, hiddenX, outputX, centerY)
            
            ctx.globalAlpha = 1.0
        }
        
        function drawBiasConnections(ctx, hiddenX, outputX, centerY) {
            ctx.strokeStyle = biasColor
            ctx.lineWidth = 1
            ctx.globalAlpha = 0.7
            
            // 偏置到隐藏层
            let biasY = centerY - (hiddenNodes + 1) * nodeSpacing / 2
            for (let j = 0; j < hiddenNodes; j++) {
                let hiddenY = centerY + (j - (hiddenNodes - 1) / 2) * nodeSpacing
                ctx.beginPath()
                ctx.moveTo(hiddenX, biasY + nodeRadius)
                ctx.lineTo(hiddenX, hiddenY - nodeRadius)
                ctx.stroke()
            }
            
            // 偏置到输出层
            for (let j = 0; j < outputNodes; j++) {
                let outputY = centerY + (j - (outputNodes - 1) / 2) * nodeSpacing
                ctx.beginPath()
                ctx.moveTo(outputX, biasY + nodeRadius)
                ctx.lineTo(outputX, outputY - nodeRadius)
                ctx.stroke()
            }
            
            ctx.globalAlpha = 1.0
        }
        
        function drawNodes(ctx, inputX, hiddenX, outputX, centerY) {
            // 输入层节点
            for (let i = 0; i < inputNodes; i++) {
                let y = centerY + (i - (inputNodes - 1) / 2) * nodeSpacing
                drawNode(ctx, inputX, y, inputColor, `I${i+1}`)
            }
            
            // 隐藏层节点
            for (let i = 0; i < hiddenNodes; i++) {
                let y = centerY + (i - (hiddenNodes - 1) / 2) * nodeSpacing
                let activation = 0
                if (hiddenOutputs.length > i) {
                    activation = hiddenOutputs[i]
                }
                drawNode(ctx, hiddenX, y, hiddenColor, `H${i+1}`, activation)
            }
            
            // 输出层节点
            for (let i = 0; i < outputNodes; i++) {
                let y = centerY + (i - (outputNodes - 1) / 2) * nodeSpacing
                let activation = 0
                if (finalOutputs.length > i) {
                    activation = finalOutputs[i]
                }
                drawNode(ctx, outputX, y, outputColor, `O${i+1}`, activation)
            }
        }
        
        function drawBiasNodes(ctx, hiddenX, outputX, centerY) {
            let biasY = centerY - (hiddenNodes + 1) * nodeSpacing / 2
            
            // 隐藏层偏置
            drawNode(ctx, hiddenX, biasY, biasColor, "B1")
            
            // 输出层偏置
            drawNode(ctx, outputX, biasY, biasColor, "B2")
        }
        
        function drawErrorArrow(ctx, fromX, fromY, toX, toY) {
            // 绘制误差反传箭头
            ctx.strokeStyle = "#FF5722"
            ctx.fillStyle = "#FF5722"
            ctx.lineWidth = 3
            ctx.globalAlpha = 0.9
            
            // 计算箭头方向
            let dx = toX - fromX
            let dy = toY - fromY
            let length = Math.sqrt(dx * dx + dy * dy)
            let unitX = dx / length
            let unitY = dy / length
            
            // 箭头大小
            let arrowSize = 15
            
            // 绘制箭头
            ctx.beginPath()
            ctx.moveTo(fromX, fromY)
            ctx.lineTo(fromX + unitX * arrowSize, fromY + unitY * arrowSize)
            
            // 箭头头部
            let headX = fromX + unitX * arrowSize
            let headY = fromY + unitY * arrowSize
            let headAngle = Math.PI / 6
            let headLength = 8
            
            ctx.moveTo(headX, headY)
            ctx.lineTo(
                headX - unitX * headLength + unitY * headLength * Math.tan(headAngle),
                headY - unitY * headLength - unitX * headLength * Math.tan(headAngle)
            )
            
            ctx.moveTo(headX, headY)
            ctx.lineTo(
                headX - unitX * headLength - unitY * headLength * Math.tan(headAngle),
                headY - unitY * headLength + unitX * headLength * Math.tan(headAngle)
            )
            
            ctx.stroke()
            ctx.globalAlpha = 1.0
        }
        
        function drawNode(ctx, x, y, color, label, activation) {
            // 节点圆圈
            ctx.fillStyle = color
            ctx.globalAlpha = activation ? Math.max(0.3, Math.abs(activation)) : 0.3
            ctx.beginPath()
            ctx.arc(x, y, nodeRadius, 0, 2 * Math.PI)
            ctx.fill()
            
            // 节点边框
            ctx.strokeStyle = color
            ctx.lineWidth = 2
            ctx.globalAlpha = 1.0
            ctx.beginPath()
            ctx.arc(x, y, nodeRadius, 0, 2 * Math.PI)
            ctx.stroke()
            
            // 误差反传时添加脉冲效果
            if (showBackpropagation) {
                // 多层脉冲效果
                for (let i = 0; i < 3; i++) {
                    ctx.strokeStyle = "#FF5722"
                    ctx.lineWidth = 6 - i * 2
                    ctx.globalAlpha = 0.8 - i * 0.2
                    ctx.beginPath()
                    ctx.arc(x, y, nodeRadius + 10 + i * 8, 0, 2 * Math.PI)
                    ctx.stroke()
                }
                ctx.globalAlpha = 1.0
            }
            
            // 节点标签
            ctx.fillStyle = "#000000"
            ctx.font = "20px sans-serif"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText(label, x, y)
            
            // 激活值
            if (activation !== undefined) {
                ctx.font = "16px sans-serif"
                ctx.fillText(activation.toFixed(3), x, y + 25)
            }
        }
    }
    
    // 信息显示
    Rectangle {
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 15
        height: 80
        color: "#ffffff"
        border.color: "#dee2e6"
        border.width: 1
        radius: 4
        
        Column {
            anchors.fill: parent
            anchors.margins: 15
            spacing: 8
            
            Text {
                text: `网络结构: ${inputNodes} → ${hiddenNodes} → ${outputNodes}`
                font.bold: true
                font.pixelSize: 18
                color: "#333333"
            }
            
            Text {
                text: `激活函数: ${activationType === 'unipolar' ? '单极性Sigmoid' : '双极性Sigmoid'}`
                font.pixelSize: 16
                color: "#666666"
            }
            
            Text {
                text: showBackpropagation ? `误差反传状态: 第${currentBackpropLayer + 1}层` : "误差反传状态: 停止"
                font.pixelSize: 16
                color: showBackpropagation ? "#FF5722" : "#666666"
            }
            
            Text {
                text: showBackpropagation ? 
                    (currentBackpropLayer === 0 ? "→ 输出层误差计算" : 
                     currentBackpropLayer === 1 ? "→ 隐藏层误差反传" : 
                     "→ 输入层误差反传") : 
                    "点击按钮开始误差反传演示"
                font.pixelSize: 14
                color: showBackpropagation ? "#FF5722" : "#999999"
                font.bold: showBackpropagation
            }
        }
    }
    
    function updateNetworkWeights() {
        if (!bpBridge || !bpBridge.network_weights) return
        
        const weights = bpBridge.network_weights
        
        inputHiddenWeights = weights.input_hidden_weights || []
        hiddenOutputWeights = weights.hidden_output_weights || []
        hiddenBias = weights.hidden_bias || []
        outputBias = weights.output_bias || []
        hiddenOutputs = weights.hidden_outputs || []
        finalOutputs = weights.final_outputs || []
        
        inputNodes = bpBridge.input_nodes || 2
        hiddenNodes = bpBridge.hidden_nodes || 5
        outputNodes = bpBridge.output_nodes || 1
        activationType = bpBridge.activation_type || "unipolar"
        
        networkCanvas.requestPaint()
    }
    
    function generateErrorValues() {
        // 生成模拟误差值用于演示
        errorValues = []
        for (let i = 0; i < outputNodes; i++) {
            errorValues.push((Math.random() - 0.5) * 2) // -1 到 1 之间的随机误差
        }
    }
    
    function reset() {
        inputHiddenWeights = []
        hiddenOutputWeights = []
        hiddenBias = []
        outputBias = []
        hiddenOutputs = []
        finalOutputs = []
        animationProgress = 0.0
        showBackpropagation = false
        currentBackpropLayer = 0
        backpropTimer.running = false
        networkCanvas.requestPaint()
    }
    
    Component.onCompleted: reset()
}
