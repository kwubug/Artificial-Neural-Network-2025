import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield（离散）'

    ColumnLayout {
        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label { text: '预设模式'; Layout.alignment: Qt.AlignHCenter }
                ComboBox {
                    id: presetCombobox
                    enabled: hopfieldBridge.has_finished
                    model: ['三比特(2模式)', '八比特(3模式)']
                    currentIndex: 0
                    onActivated: {
                        applyPreset()
                    }
                    Component.onCompleted: applyPreset()
                }

                Label { text: '初始状态噪声翻转比例'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0.0 * 100
                    from: 0 * 100
                    to: 0.5 * 100
                    onValueChanged: hopfieldBridge.noise_flip_ratio = value / 100
                    Component.onCompleted: hopfieldBridge.noise_flip_ratio = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '最大迭代'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 20000
                    to: 999999
                    onValueChanged: hopfieldBridge.max_iterations = value
                    Component.onCompleted: hopfieldBridge.max_iterations = value
                    Layout.fillWidth: true
                }

                Label { text: 'UI刷新间隔（秒）'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0.02 * 100
                    from: 0 * 100
                    to: 0.2 * 100
                    onValueChanged: hopfieldBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: hopfieldBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: '控制与信息'
            Layout.fillWidth: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2

                ExecutionControls {
                    startButton.enabled: hopfieldBridge.has_finished
                    startButton.onClicked: () => {
                        hopfieldBridge.start_hopfield()
                        energyChart.reset()
                    }
                    stopButton.enabled: !hopfieldBridge.has_finished
                    stopButton.onClicked: hopfieldBridge.stop_hopfield()
                    progressBar.value: hopfieldBridge.current_iteration / Math.max(1, hopfieldBridge.max_iterations)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: '当前迭代'; Layout.alignment: Qt.AlignHCenter }
                Label { text: hopfieldBridge.current_iteration; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '当前能量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldBridge.current_energy) ? hopfieldBridge.current_energy.toFixed(6) : hopfieldBridge.current_energy; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '当前状态'; Layout.alignment: Qt.AlignHCenter }
                Label { text: JSON.stringify(hopfieldBridge.current_state); horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '吸引子状态'; Layout.alignment: Qt.AlignHCenter }
                Label { text: JSON.stringify(hopfieldBridge.attractor_state); horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '吸引子能量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldBridge.attractor_energy) ? hopfieldBridge.attractor_energy.toFixed(6) : hopfieldBridge.attractor_energy; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                
                Label { text: '最小能量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldBridge.min_energy) ? hopfieldBridge.min_energy.toFixed(6) : '-'; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '最大能量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldBridge.max_energy) ? hopfieldBridge.max_energy.toFixed(6) : '-'; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '能量方差'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldBridge.energy_variance) ? hopfieldBridge.energy_variance.toFixed(6) : '-'; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '发现的吸引子数'; Layout.alignment: Qt.AlignHCenter }
                Label { text: hopfieldBridge.all_attractors.length; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
            }
        }

        GroupBox {
            title: '所有吸引子详情'
            Layout.fillWidth: true
            ScrollView {
                anchors.fill: parent
                clip: true
                TextArea {
                    id: attractorsTextArea
                    readOnly: true
                    wrapMode: TextEdit.Wrap
                    text: formatAttractors()
                    font.family: 'Consolas'
                    font.pixelSize: 12
                }
            }
        }

    }

    ColumnLayout {
        // 能量曲线
        ChartView {
            id: energyChart
            Layout.fillWidth: true
            Layout.fillHeight: true
            antialiasing: true
            legend.visible: false

            ValueAxis { id: ex; min: 0; max: 100 }
            ValueAxis { id: ey; min: -10; max: 10 }

            LineSeries {
                id: energySeries
                axisX: ex
                axisY: ey
                color: 'red'
                width: 2
            }

            function reset() {
                energySeries.clear()
                ex.max = 100
                ey.min = -10
                ey.max = 10
            }

            function updateData(history) {
                energySeries.clear()
                if (!history || history.length === 0) return
                let minE = Math.min(...history)
                let maxE = Math.max(...history)
                ey.min = Math.min(ey.min, minE * 1.2)
                ey.max = Math.max(ey.max, maxE * 1.2)
                ex.max = Math.max(history.length, 100)
                for (let i = 0; i < history.length; i++) {
                    energySeries.append(i + 1, history[i])
                }
            }

            function appendPoint(iteration, energy) {
                if (!Number.isFinite(energy)) return
                energySeries.append(iteration, energy)
                ex.max = Math.max(ex.max, iteration)
                ey.min = Math.min(ey.min, energy * 1.2)
                ey.max = Math.max(ey.max, energy * 1.2)
            }
        }
    }

    Connections {
        target: hopfieldBridge
        function onEnergy_historyChanged() {
            energyChart.updateData(hopfieldBridge.energy_history)
        }
        function onCurrent_iterationChanged() {
            energyChart.appendPoint(hopfieldBridge.current_iteration, hopfieldBridge.current_energy)
        }
    }

    function applyPreset() {
        // 两组简单预设：
        if (presetCombobox.currentIndex === 0) {
            // 三比特，存储两个模式，例如 [1,1,1], [1,-1,-1]
            hopfieldBridge.patterns = [
                [1, 1, 1],
                [1, -1, -1]
            ]
            hopfieldBridge.initial_state = [1, -1, 1]
        } else {
            // 八比特，举例三个模式
            hopfieldBridge.patterns = [
                [1, 1, 1, 1, -1, -1, -1, -1],
                [1, -1, 1, -1, 1, -1, 1, -1],
                [-1, -1, 1, 1, -1, -1, 1, 1]
            ]
            hopfieldBridge.initial_state = [1, 1, -1, -1, -1, 1, -1, 1]
        }
    }

    function formatAttractors() {
        if (!hopfieldBridge.all_attractors || hopfieldBridge.all_attractors.length === 0) {
            return '还未发现吸引子'
        }
        let result = ''
        for (let i = 0; i < hopfieldBridge.all_attractors.length; i++) {
            let att = hopfieldBridge.all_attractors[i]
            result += `吸引子 ${i + 1}:\n`
            result += `  状态: ${JSON.stringify(att.state)}\n`
            result += `  能量: ${att.energy.toFixed(6)}\n`
            result += `  发现次数: ${att.count}\n\n`
        }
        return result
    }

    Connections {
        target: hopfieldBridge
        function onAll_attractorsChanged() {
            attractorsTextArea.text = formatAttractors()
        }
    }
}


