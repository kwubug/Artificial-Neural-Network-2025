
import sys
import os
import matplotlib.pyplot as plt
import matplotlib as mpl

plt.rcParams['axes.unicode_minus'] = False

# 解决中文显示问题（优先使用系统存在的中文字体，避免字体不存在导致的问题）
# 自动检测系统可用中文字体（Windows/macOS/Linux通用）
def get_system_chinese_font():
    """自动获取系统可用的中文字体"""
    font_names = [
        'SimHei',          # Windows：黑体
        'Microsoft YaHei',  # Windows：微软雅黑
        'DengXian',        # Windows：等线
        'KaiTi',           # Windows：楷体
        'Songti SC',       # macOS：宋体
        'Heiti SC',        # macOS：黑体
        'WenQuanYi Micro Hei',  # Linux：文泉驿微米黑
        'Noto Sans CJK SC',     # Linux：思源黑体
        'Arial Unicode MS'      # 通用 fallback
    ]
    # 筛选系统中实际存在的字体
    available_fonts = set([f.name for f in mpl.font_manager.fontManager.ttflist])
    for font in font_names:
        if font in available_fonts:
            return font
    # 如果没有找到，返回默认无衬线字体
    return 'sans-serif'

# 设置全局字体
chinese_font = get_system_chinese_font()
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = [chinese_font, 'Arial', 'Helvetica', 'DejaVu Sans']

# 其他优化配置
plt.rcParams['figure.figsize'] = (10, 6)  # 默认图大小
plt.rcParams['figure.dpi'] = 100          # 默认分辨率
plt.rcParams['axes.grid'] = True          # 默认显示网格
#plt.rcParams['axes.grid.alpha'] = 0.3     # 网格透明度
plt.rcParams['savefig.dpi'] = 150         # 保存图片分辨率
#plt.rcParams['savefig.bbox_inches'] = 'tight'  # 保存时不截断标签
plt.rcParams['figure.max_open_warning'] = 0  # 关闭最大打开图形警告
# -------------------------- 全局配置结束 --------------------------

from PySide6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget,
                             QVBoxLayout, QLabel, QPushButton, QTextEdit,
                             QGridLayout, QDoubleSpinBox, QSpinBox, QComboBox,
                             QGroupBox, QHBoxLayout, QFileDialog, QMessageBox)
from PySide6.QtCore import Qt, Signal, Slot
from PySide6.QtGui import QFont, QIntValidator, QDoubleValidator
import numpy as np
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# 确保输出目录存在（如果需要保存图片）
def ensure_output_dir():
    """确保输出目录存在，如果不存在则创建"""
    output_dir = 'outputs'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

# 在程序启动时创建输出目录
ensure_output_dir()

# 导入各个算法的界面（确保每个子界面都正确定义了对应的类）
from ols_rbf_window import OLSRBFWindow
from gradient_descent_window import GradientDescentWindow
from hopfield_window import HopfieldWindow
from bp_neural_network_window import BPNeuralNetworkWindow
from hopfield_tsp_window import HopfieldTSPWindow
from bm_window import BoltzmannMachineWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("神经网络算法集成软件")
        self.setGeometry(100, 100, 1200, 800)

        # 设置窗口图标（可选）
        # self.setWindowIcon(QIcon('icon.png'))

        # 创建主部件和布局
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        # 创建Tab控件
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabPosition(QTabWidget.North)  # Tab栏在顶部
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #C2C7CB;
                border-radius: 4px;
                background: #f0f0f0;
            }
            QTabBar::tab {
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
                                            stop:0 #E1E1E1, stop:0.4 #DDDDDD,
                                            stop:0.5 #D8D8D8, stop:1.0 #D3D3D3);
                border: 1px solid #C4C4C3;
                border-bottom-color: #C2C7CB;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                min-width: 8ex;
                padding: 5px;
                margin-right: 2px;
            }
            QTabBar::tab:selected, QTabBar::tab:hover {
                background: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
                                            stop:0 #fafafa, stop:0.4 #f4f4f4,
                                            stop:0.5 #e7e7e7, stop:1.0 #fafafa);
            }
        """)

        # 创建各个算法的界面实例
        self.ols_rbf_window = OLSRBFWindow()
        self.gradient_descent_window = GradientDescentWindow()
        self.hopfield_window = HopfieldWindow()
        self.bp_neural_network_window = BPNeuralNetworkWindow()
        self.hopfield_tsp_window = HopfieldTSPWindow()
        self.bm_window = BoltzmannMachineWindow()

        # 添加Tab页
        self.tab_widget.addTab(self.ols_rbf_window, "OLS神经网络")
        self.tab_widget.addTab(self.gradient_descent_window, "梯度下降算法")
        self.tab_widget.addTab(self.hopfield_window, "Hopfield神经网络")
        self.tab_widget.addTab(self.bp_neural_network_window, "BP神经网络")
        self.tab_widget.addTab(self.hopfield_tsp_window, "Hopfield-TSP")
        self.tab_widget.addTab(self.bm_window, "玻尔兹曼机")

        # 设置主布局
        main_layout = QVBoxLayout(self.central_widget)
        main_layout.addWidget(self.tab_widget)

        # 添加状态栏
        self.statusBar().showMessage("准备就绪")

        # 连接Tab切换信号
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

    @Slot(int)
    def on_tab_changed(self, index):
        """当Tab页切换时触发"""
        tab_text = self.tab_widget.tabText(index)
        self.statusBar().showMessage(f"当前页面: {tab_text}")

        # 可以在这里添加页面切换时的初始化代码
        if index == 0:
            self.ols_rbf_window.initialize_plot()
        elif index == 1:
            self.gradient_descent_window.initialize_plot()
        elif index == 2:
            self.hopfield_window.initialize_plot()
        elif index == 3:
            self.bp_neural_network_window.initialize_plot()
        elif index == 4:
            self.hopfield_tsp_window.initialize_plot()
        elif index == 5:
            self.bm_window.initialize_plot()


# 自定义异常处理
def handle_exception(exc_type, exc_value, exc_traceback):
    """全局异常处理函数"""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return

    print(f"\n出现未处理的异常: {exc_type.__name__}: {exc_value}")
    import traceback
    traceback.print_tb(exc_traceback)

    # 显示错误对话框
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Critical)
    msg_box.setWindowTitle("程序错误")
    msg_box.setText(f"出现错误: {exc_type.__name__}")
    msg_box.setInformativeText(str(exc_value))
    msg_box.setDetailedText("".join(traceback.format_tb(exc_traceback)))
    msg_box.setStandardButtons(QMessageBox.Ok)
    msg_box.exec()


sys.excepthook = handle_exception

if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 设置应用程序样式
    app.setStyle('Fusion')  # 可以尝试 'Windows', 'WindowsXP', 'WindowsVista', 'Fusion'

    # 设置全局字体
    font = QFont()
    font.setPointSize(10)
    app.setFont(font)

    window = MainWindow()
    window.show()

    # 添加启动信息
    print("=" * 50)
    print("神经网络算法集成软件启动成功")
    print(f"Python版本: {sys.version}")
    print(f"PySide6版本: {sys.modules['PySide6'].__version__}")
    print(f"NumPy版本: {np.__version__}")
    print("=" * 50)

    sys.exit(app.exec())