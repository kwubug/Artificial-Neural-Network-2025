import sys
import math
import random
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QSlider, QPushButton, QComboBox,
                             QSpinBox, QDoubleSpinBox, QGroupBox, QCheckBox, QTextEdit,
                             QMessageBox, QSplitter)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor, QFont, QLinearGradient, QPolygonF
from PyQt5.QtCore import QPointF


class RBFNeuron:
    """RBF神经元"""

    def __init__(self, center, width, weight=0.0):
        self.center = np.array(center, dtype=np.float64)
        self.width = width
        self.weight = weight
        self.activation = 0.0
        self.output = 0.0


class RBFNetwork:
    """RBF神经网络模型"""

    def __init__(self, input_dim=1, hidden_units=5, output_dim=1):
        self.input_dim = input_dim
        self.hidden_units = hidden_units
        self.output_dim = output_dim
        self.hidden_neurons = []
        self.output_weights = np.random.randn(hidden_units, output_dim) * 0.1
        self.output_bias = np.zeros(output_dim)
        self.learning_rate = 0.1
        self.iteration = 0
        self.max_iterations = 1000
        self.current_error = 0.0
        self.error_history = []
        self.initialize_network()

    def initialize_network(self):
        """初始化网络"""
        self.hidden_neurons = []

        # 在输入空间均匀分布中心点
        for i in range(self.hidden_units):
            if self.input_dim == 1:
                center = [i / (self.hidden_units - 1) if self.hidden_units > 1 else 0.5]
            else:
                center = [random.random() for _ in range(self.input_dim)]

            # 设置宽度，确保有合理的重叠
            width = 0.3 + random.random() * 0.2
            neuron = RBFNeuron(center, width)
            self.hidden_neurons.append(neuron)

        self.output_weights = np.random.randn(self.hidden_units, self.output_dim) * 0.1
        self.output_bias = np.zeros(self.output_dim)
        self.iteration = 0
        self.error_history = []

    def gaussian_rbf(self, x, center, width):
        """高斯径向基函数"""
        return math.exp(-np.sum((x - center) ** 2) / (2 * width ** 2))

    def forward(self, x):
        """前向传播"""
        x = np.array(x, dtype=np.float64)

        # 隐藏层激活
        hidden_outputs = []
        for neuron in self.hidden_neurons:
            activation = self.gaussian_rbf(x, neuron.center, neuron.width)
            neuron.activation = activation
            hidden_outputs.append(activation)

        hidden_outputs = np.array(hidden_outputs)

        # 输出层
        output = np.dot(hidden_outputs, self.output_weights) + self.output_bias
        return output, hidden_outputs

    def train_step(self, x, y_target):
        """单次训练步骤"""
        x = np.array(x, dtype=np.float64)
        y_target = np.array(y_target, dtype=np.float64)

        # 前向传播
        y_pred, hidden_outputs = self.forward(x)

        # 计算误差
        error = y_target - y_pred
        self.current_error = np.mean(error ** 2)
        self.error_history.append(self.current_error)

        # 更新输出层权重（简单梯度下降）
        for i in range(self.hidden_units):
            for j in range(self.output_dim):
                gradient = -error[j] * hidden_outputs[i]
                self.output_weights[i, j] -= self.learning_rate * gradient

        # 更新偏置
        for j in range(self.output_dim):
            self.output_bias[j] -= self.learning_rate * (-error[j])

        self.iteration += 1
        return y_pred, error

    def generate_training_data(self, num_samples=100):
        """生成训练数据（正弦函数）"""
        if self.input_dim == 1:
            x_data = np.linspace(0, 1, num_samples)
            y_data = np.sin(x_data * 2 * math.pi) * 0.5 + 0.5  # 归一化到[0,1]
            return [(x,) for x in x_data], [[y] for y in y_data]
        else:
            # 对于高维输入，生成随机数据
            x_data = np.random.rand(num_samples, self.input_dim)
            y_data = np.sin(np.sum(x_data, axis=1) * 2 * math.pi) * 0.5 + 0.5
            return x_data.tolist(), [[y] for y in y_data]


class NetworkCanvas(QWidget):
    """网络结构可视化画布"""

    def __init__(self, network):
        super().__init__()
        self.network = network
        self.node_radius = 15
        self.layer_spacing = 120
        self.node_spacing = 40
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate_network)
        self.is_training = False
        self.training_data = []
        self.target_data = []
        self.current_sample = 0
        self.show_activations = True
        self.setMinimumSize(600, 400)

        # 生成训练数据
        self.training_data, self.target_data = self.network.generate_training_data(50)

    def animate_network(self):
        """训练动画"""
        if self.current_sample >= len(self.training_data):
            self.current_sample = 0

        x = self.training_data[self.current_sample]
        y_target = self.target_data[self.current_sample]

        y_pred, error = self.network.train_step(x, y_target)

        self.current_sample += 1

        if self.network.iteration >= self.network.max_iterations:
            self.stop_training()
            QMessageBox.information(self, "训练完成",
                                    f"RBF网络训练完成！共进行了{self.network.iteration}次迭代。\n最终误差: {self.network.current_error:.6f}")

        self.update()

    def start_training(self):
        """开始训练"""
        self.is_training = True
        self.animation_timer.start(100)

    def stop_training(self):
        """停止训练"""
        self.is_training = False
        self.animation_timer.stop()

    def reset_network(self):
        """重置网络"""
        self.stop_training()
        self.network.initialize_network()
        self.current_sample = 0
        self.update()

    def set_training_speed(self, speed):
        """设置训练速度"""
        interval = 200 - speed * 1.8  # 20-200 ms
        self.animation_timer.setInterval(max(20, int(interval)))

    def toggle_activations(self, checked):
        """切换激活值显示"""
        self.show_activations = checked
        self.update()

    def paintEvent(self, event):
        """绘制网络结构"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 设置背景
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(250, 252, 255))
        gradient.setColorAt(1, QColor(240, 245, 250))
        painter.fillRect(self.rect(), gradient)

        # 计算各层位置
        input_x = 100
        hidden_x = self.width() / 2
        output_x = self.width() - 100

        # 绘制连接线
        painter.setPen(QPen(QColor(180, 180, 200, 100), 1))

        # 输入层到隐藏层连接
        for i in range(self.network.input_dim):
            input_y = self.height() / 2 + (i - (self.network.input_dim - 1) / 2) * self.node_spacing

            for j, neuron in enumerate(self.network.hidden_neurons):
                hidden_y = self.height() / 2 + (j - (len(self.network.hidden_neurons) - 1) / 2) * self.node_spacing

                # 简单的权重可视化（颜色深浅）
                weight_value = 0.5  # 输入到隐藏层的权重固定为1（在RBF中）
                alpha = int(100 + weight_value * 100)
                painter.setPen(QPen(QColor(100, 100, 200, alpha), 1))
                painter.drawLine(int(input_x), int(input_y), int(hidden_x), int(hidden_y))

        # 隐藏层到输出层连接
        for i, neuron in enumerate(self.network.hidden_neurons):
            hidden_y = self.height() / 2 + (i - (len(self.network.hidden_neurons) - 1) / 2) * self.node_spacing

            for j in range(self.network.output_dim):
                output_y = self.height() / 2 + (j - (self.network.output_dim - 1) / 2) * self.node_spacing

                # 使用权重值决定线条粗细和颜色
                weight_value = self.network.output_weights[i, j]
                line_width = max(1, abs(weight_value) * 3)
                alpha = min(200, int(100 + abs(weight_value) * 100))

                if weight_value > 0:
                    painter.setPen(QPen(QColor(0, 150, 0, alpha), line_width))
                else:
                    painter.setPen(QPen(QColor(150, 0, 0, alpha), line_width))

                painter.drawLine(int(hidden_x), int(hidden_y), int(output_x), int(output_y))

        # 绘制输入层节点
        for i in range(self.network.input_dim):
            y = self.height() / 2 + (i - (self.network.input_dim - 1) / 2) * self.node_spacing

            painter.setPen(QPen(QColor(50, 50, 100), 2))
            painter.setBrush(QBrush(QColor(200, 220, 255)))
            painter.drawEllipse(int(input_x - self.node_radius), int(y - self.node_radius),
                                int(self.node_radius * 2), int(self.node_radius * 2))

            painter.setPen(QColor(0, 0, 0))
            painter.setFont(QFont("Arial", 10, QFont.Bold))
            painter.drawText(int(input_x - 10), int(y + 5), f"X{i + 1}")

        # 绘制隐藏层节点（RBF神经元）
        for i, neuron in enumerate(self.network.hidden_neurons):
            y = self.height() / 2 + (i - (len(self.network.hidden_neurons) - 1) / 2) * self.node_spacing

            # 根据激活值设置颜色
            if self.show_activations:
                activation_color = int(neuron.activation * 255)
                node_color = QColor(255, 255 - activation_color, 255 - activation_color)
            else:
                node_color = QColor(200, 230, 255)

            painter.setPen(QPen(QColor(80, 80, 150), 2))
            painter.setBrush(QBrush(node_color))
            painter.drawEllipse(int(hidden_x - self.node_radius), int(y - self.node_radius),
                                int(self.node_radius * 2), int(self.node_radius * 2))

            painter.setPen(QColor(0, 0, 0))
            painter.setFont(QFont("Arial", 9))
            painter.drawText(int(hidden_x - 15), int(y + 5), f"RBF{i + 1}")

            if self.show_activations:
                activation_text = f"{neuron.activation:.2f}"
                painter.setFont(QFont("Arial", 7))
                painter.drawText(int(hidden_x - 15), int(y - self.node_radius - 5), 30, 10,
                                 Qt.AlignCenter, activation_text)

        # 绘制输出层节点
        for i in range(self.network.output_dim):
            y = self.height() / 2 + (i - (self.network.output_dim - 1) / 2) * self.node_spacing

            painter.setPen(QPen(QColor(100, 50, 50), 2))
            painter.setBrush(QBrush(QColor(255, 200, 200)))
            painter.drawEllipse(int(output_x - self.node_radius), int(y - self.node_radius),
                                int(self.node_radius * 2), int(self.node_radius * 2))

            painter.setPen(QColor(0, 0, 0))
            painter.setFont(QFont("Arial", 10, QFont.Bold))
            painter.drawText(int(output_x - 10), int(y + 5), f"Y{i + 1}")

        # 绘制标题和信息
        painter.setPen(QColor(30, 30, 30))
        painter.setFont(QFont("Arial", 14, QFont.Bold))
        painter.drawText(10, 25, "RBF神经网络结构")

        painter.setFont(QFont("Arial", 10))
        info_text = f"迭代: {self.network.iteration}/{self.network.max_iterations} | 当前误差: {self.network.current_error:.6f}"
        painter.drawText(10, 45, info_text)

        status_text = "状态: " + ("训练中" if self.is_training else "已停止")
        painter.drawText(10, 65, status_text)


class FunctionCanvas(QWidget):
    """函数逼近可视化画布"""

    def __init__(self, network):
        super().__init__()
        self.network = network
        self.show_rbf_functions = True
        self.show_approximation = True
        self.setMinimumSize(600, 400)

    def paintEvent(self, event):
        """绘制函数逼近效果"""
        if self.network.input_dim != 1:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 设置背景
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(255, 255, 255))
        gradient.setColorAt(1, QColor(245, 245, 245))
        painter.fillRect(self.rect(), gradient)

        # 绘制坐标轴
        painter.setPen(QPen(QColor(100, 100, 100), 2))
        margin = 50
        graph_width = self.width() - 2 * margin
        graph_height = self.height() - 2 * margin

        # x轴
        painter.drawLine(margin, self.height() - margin, self.width() - margin, self.height() - margin)
        # y轴
        painter.drawLine(margin, margin, margin, self.height() - margin)

        # 坐标轴标签
        painter.setFont(QFont("Arial", 10))
        painter.drawText(margin - 20, margin - 10, "f(x)")
        painter.drawText(self.width() - margin + 10, self.height() - margin + 20, "x")

        # 生成测试点
        x_test = np.linspace(0, 1, 100)
        y_target = np.sin(x_test * 2 * math.pi) * 0.5 + 0.5

        # 计算网络输出
        y_pred = []
        for x in x_test:
            output, _ = self.network.forward([x])
            y_pred.append(output[0, 0] if hasattr(output[0], '__len__') else output[0])

        # 绘制目标函数（正弦波）
        painter.setPen(QPen(QColor(0, 100, 200), 3))
        path_target = []
        for i, x in enumerate(x_test):
            px = margin + x * graph_width
            py = self.height() - margin - y_target[i] * graph_height
            path_target.append(QPointF(px, py))

        for i in range(len(path_target) - 1):
            painter.drawLine(path_target[i], path_target[i + 1])

        # 绘制网络逼近
        if self.show_approximation:
            painter.setPen(QPen(QColor(200, 0, 0), 3))
            path_pred = []
            for i, x in enumerate(x_test):
                px = margin + x * graph_width
                py = self.height() - margin - y_pred[i] * graph_height
                path_pred.append(QPointF(px, py))

            for i in range(len(path_pred) - 1):
                painter.drawLine(path_pred[i], path_pred[i + 1])

        # 绘制RBF函数
        if self.show_rbf_functions:
            colors = [QColor(0, 150, 0), QColor(150, 150, 0), QColor(0, 150, 150),
                      QColor(150, 0, 150), QColor(100, 100, 100)]

            for i, neuron in enumerate(self.network.hidden_neurons):
                color = colors[i % len(colors)]
                painter.setPen(QPen(color, 2))

                rbf_values = []
                for x in x_test:
                    activation = self.network.gaussian_rbf([x], neuron.center, neuron.width)
                    # 缩放RBF函数以便显示
                    scaled_activation = activation * 0.3 + 0.1
                    rbf_values.append(scaled_activation)

                path_rbf = []
                for j, x in enumerate(x_test):
                    px = margin + x * graph_width
                    py = self.height() - margin - rbf_values[j] * graph_height
                    path_rbf.append(QPointF(px, py))

                for j in range(len(path_rbf) - 1):
                    painter.drawLine(path_rbf[j], path_rbf[j + 1])

        # 绘制图例
        legend_x = self.width() - 150
        legend_y = 30

        painter.setFont(QFont("Arial", 9))

        # 目标函数图例
        painter.setPen(QPen(QColor(0, 100, 200), 2))
        painter.drawLine(legend_x, legend_y, legend_x + 30, legend_y)
        painter.drawText(legend_x + 35, legend_y + 5, "目标函数: sin(2πx)")

        # 逼近函数图例
        if self.show_approximation:
            painter.setPen(QPen(QColor(200, 0, 0), 2))
            painter.drawLine(legend_x, legend_y + 20, legend_x + 30, legend_y + 20)
            painter.drawText(legend_x + 35, legend_y + 25, "RBF网络逼近")

        # RBF函数图例
        if self.show_rbf_functions:
            painter.setPen(QPen(QColor(0, 150, 0), 2))
            painter.drawLine(legend_x, legend_y + 40, legend_x + 30, legend_y + 40)
            painter.drawText(legend_x + 35, legend_y + 45, "RBF基函数")

        # 标题
        painter.setPen(QColor(30, 30, 30))
        painter.setFont(QFont("Arial", 12, QFont.Bold))
        painter.drawText(10, 25, "RBF网络函数逼近效果")


class ErrorCanvas(QWidget):
    """误差曲线画布"""

    def __init__(self, network):
        super().__init__()
        self.network = network
        self.setMinimumSize(600, 200)

    def paintEvent(self, event):
        """绘制误差曲线"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 设置背景
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(255, 255, 255))
        gradient.setColorAt(1, QColor(245, 245, 245))
        painter.fillRect(self.rect(), gradient)

        if len(self.network.error_history) == 0:
            return

        # 绘制坐标轴
        painter.setPen(QPen(QColor(100, 100, 100), 2))
        margin = 50
        graph_width = self.width() - 2 * margin
        graph_height = self.height() - 2 * margin

        # x轴
        painter.drawLine(margin, self.height() - margin, self.width() - margin, self.height() - margin)
        # y轴
        painter.drawLine(margin, margin, margin, self.height() - margin)

        # 坐标轴标签
        painter.setFont(QFont("Arial", 10))
        painter.drawText(margin - 40, margin + 5, "误差")
        painter.drawText(self.width() - margin + 10, self.height() - margin + 20, "迭代")

        # 绘制误差曲线
        max_error = max(self.network.error_history) if max(self.network.error_history) > 0 else 1
        min_error = min(self.network.error_history)

        # 使用对数坐标（如果误差变化很大）
        use_log_scale = max_error / min_error > 100 if min_error > 0 else False

        painter.setPen(QPen(QColor(200, 0, 0), 2))
        path_error = []

        for i, error in enumerate(self.network.error_history):
            if use_log_scale and error > 0:
                log_error = math.log10(error)
                log_max = math.log10(max_error)
                log_min = math.log10(min_error) if min_error > 0 else log_max - 5
                normalized_error = (log_error - log_min) / (log_max - log_min) if log_max != log_min else 0.5
            else:
                normalized_error = (error - min_error) / (max_error - min_error) if max_error != min_error else 0.5

            x = margin + (i / len(self.network.error_history)) * graph_width
            y = self.height() - margin - normalized_error * graph_height
            path_error.append(QPointF(x, y))

        for i in range(len(path_error) - 1):
            painter.drawLine(path_error[i], path_error[i + 1])

        # 标题和统计信息
        painter.setPen(QColor(30, 30, 30))
        painter.setFont(QFont("Arial", 12, QFont.Bold))
        painter.drawText(10, 25, "训练误差曲线")

        painter.setFont(QFont("Arial", 9))
        scale_info = "（对数坐标）" if use_log_scale else "（线性坐标）"
        info_text = f"最小误差: {min_error:.6f} | 最大误差: {max_error:.6f} | 当前误差: {self.network.current_error:.6f} {scale_info}"
        painter.drawText(margin, 25, info_text)


class ControlPanel(QWidget):
    """控制面板"""

    def __init__(self, network_canvas, function_canvas, error_canvas):
        super().__init__()
        self.network_canvas = network_canvas
        self.function_canvas = function_canvas
        self.error_canvas = error_canvas
        self.network = network_canvas.network
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(10)

        # 网络参数控制
        params_group = QGroupBox("网络参数配置")
        params_layout = QVBoxLayout()

        # 输入维度
        input_layout = QHBoxLayout()
        input_layout.addWidget(QLabel("输入维度:"))
        self.input_spin = QSpinBox()
        self.input_spin.setRange(1, 3)
        self.input_spin.setValue(1)
        self.input_spin.valueChanged.connect(self.change_network_params)
        input_layout.addWidget(self.input_spin)
        params_layout.addLayout(input_layout)

        # 隐藏单元数
        hidden_layout = QHBoxLayout()
        hidden_layout.addWidget(QLabel("RBF神经元数:"))
        self.hidden_spin = QSpinBox()
        self.hidden_spin.setRange(3, 20)
        self.hidden_spin.setValue(5)
        self.hidden_spin.valueChanged.connect(self.change_network_params)
        hidden_layout.addWidget(self.hidden_spin)
        params_layout.addLayout(hidden_layout)

        # 学习率
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("学习率:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.001, 1.0)
        self.lr_spin.setSingleStep(0.01)
        self.lr_spin.setValue(0.1)
        self.lr_spin.valueChanged.connect(self.change_learning_rate)
        lr_layout.addWidget(self.lr_spin)
        params_layout.addLayout(lr_layout)

        # 最大迭代次数
        iter_layout = QHBoxLayout()
        iter_layout.addWidget(QLabel("最大迭代次数:"))
        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(100, 10000)
        self.iter_spin.setSingleStep(100)
        self.iter_spin.setValue(1000)
        self.iter_spin.valueChanged.connect(self.change_max_iterations)
        iter_layout.addWidget(self.iter_spin)
        params_layout.addLayout(iter_layout)

        params_group.setLayout(params_layout)
        layout.addWidget(params_group)

        # 训练控制
        training_group = QGroupBox("训练控制")
        training_layout = QVBoxLayout()

        # 训练按钮
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始训练")
        self.stop_btn = QPushButton("停止训练")
        self.reset_btn = QPushButton("重置网络")
        self.start_btn.clicked.connect(self.network_canvas.start_training)
        self.stop_btn.clicked.connect(self.network_canvas.stop_training)
        self.reset_btn.clicked.connect(self.reset_network)
        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.stop_btn)
        button_layout.addWidget(self.reset_btn)
        training_layout.addLayout(button_layout)

        # 训练速度
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("训练速度:"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(1, 100)
        self.speed_slider.setValue(50)
        self.speed_slider.valueChanged.connect(self.network_canvas.set_training_speed)
        speed_layout.addWidget(self.speed_slider)
        training_layout.addLayout(speed_layout)

        training_group.setLayout(training_layout)
        layout.addWidget(training_group)

        # 显示设置
        display_group = QGroupBox("显示设置")
        display_layout = QVBoxLayout()

        # 网络显示选项
        network_options = QHBoxLayout()
        self.activation_check = QCheckBox("显示激活值")
        self.activation_check.setChecked(True)
        self.activation_check.toggled.connect(self.network_canvas.toggle_activations)
        network_options.addWidget(self.activation_check)
        display_layout.addLayout(network_options)

        # 函数显示选项
        function_options = QHBoxLayout()
        self.rbf_check = QCheckBox("显示RBF函数")
        self.rbf_check.setChecked(True)
        self.rbf_check.toggled.connect(self.toggle_rbf_display)
        function_options.addWidget(self.rbf_check)

        self.approx_check = QCheckBox("显示逼近结果")
        self.approx_check.setChecked(True)
        self.approx_check.toggled.connect(self.toggle_approx_display)
        function_options.addWidget(self.approx_check)
        display_layout.addLayout(function_options)

        display_group.setLayout(display_layout)
        layout.addWidget(display_group)

        # 信息显示
        info_group = QGroupBox("网络信息")
        info_layout = QVBoxLayout()
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        layout.addStretch()
        self.setLayout(layout)
        self.update_info()

    def change_network_params(self):
        """改变网络参数"""
        input_dim = self.input_spin.value()
        hidden_units = self.hidden_spin.value()

        self.network_canvas.stop_training()
        self.network.input_dim = input_dim
        self.network.hidden_units = hidden_units
        self.network.initialize_network()
        self.network_canvas.training_data, self.network_canvas.target_data = self.network.generate_training_data(50)
        self.network_canvas.current_sample = 0
        self.network_canvas.update()
        self.function_canvas.update()
        self.error_canvas.update()
        self.update_info()

    def change_learning_rate(self, value):
        """改变学习率"""
        self.network.learning_rate = value
        self.update_info()

    def change_max_iterations(self, value):
        """改变最大迭代次数"""
        self.network.max_iterations = value
        self.update_info()

    def reset_network(self):
        """重置网络"""
        self.network_canvas.reset_network()
        self.function_canvas.update()
        self.error_canvas.update()
        self.update_info()

    def toggle_rbf_display(self, checked):
        """切换RBF函数显示"""
        self.function_canvas.show_rbf_functions = checked
        self.function_canvas.update()

    def toggle_approx_display(self, checked):
        """切换逼近结果显示"""
        self.function_canvas.show_approximation = checked
        self.function_canvas.update()

    def update_info(self):
        """更新网络信息"""
        info = f"网络结构: {self.network.input_dim}-{self.network.hidden_units}-{self.network.output_dim}\n"
        info += f"学习率: {self.network.learning_rate:.3f}\n"
        info += f"训练进度: {self.network.iteration}/{self.network.max_iterations}\n"
        info += f"当前误差: {self.network.current_error:.6f}\n"

        if len(self.network.error_history) > 0:
            min_error = min(self.network.error_history)
            max_error = max(self.network.error_history)
            info += f"最小误差: {min_error:.6f}\n"
            info += f"最大误差: {max_error:.6f}\n"

        info += f"训练状态: {'训练中' if self.network_canvas.is_training else '已停止'}"

        self.info_text.setText(info)


class RBFVisualizer(QMainWindow):
    """RBF网络可视化主窗口"""

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('RBF径向基函数网络可视化工具')
        self.setGeometry(100, 100, 1400, 900)

        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 创建主布局
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # 创建左侧可视化区域
        left_widget = QWidget()
        left_layout = QVBoxLayout()
        left_widget.setLayout(left_layout)

        # 创建RBF网络和画布
        self.network = RBFNetwork(input_dim=1, hidden_units=5, output_dim=1)
        self.network_canvas = NetworkCanvas(self.network)
        self.function_canvas = FunctionCanvas(self.network)
        self.error_canvas = ErrorCanvas(self.network)

        # 添加网络结构可视化
        left_layout.addWidget(QLabel("网络结构可视化:"))
        left_layout.addWidget(self.network_canvas)

        # 添加函数逼近可视化
        left_layout.addWidget(QLabel("函数逼近效果:"))
        left_layout.addWidget(self.function_canvas)

        # 添加误差曲线
        left_layout.addWidget(QLabel("训练误差曲线:"))
        left_layout.addWidget(self.error_canvas)

        # 创建控制面板
        self.control_panel = ControlPanel(self.network_canvas, self.function_canvas, self.error_canvas)
        self.control_panel.setFixedWidth(300)

        # 使用分割器
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(left_widget)
        splitter.addWidget(self.control_panel)
        splitter.setSizes([1100, 300])

        main_layout.addWidget(splitter)

        # 状态栏
        self.statusBar().showMessage('RBF网络可视化工具已就绪 - 点击"开始训练"观察学习过程')

        # 创建定时器更新信息
        self.info_timer = QTimer(self)
        self.info_timer.timeout.connect(self.control_panel.update_info)
        self.info_timer.start(500)


def main():

    app = QApplication(sys.argv)

    app.setStyle('Fusion')

    visualizer = RBFVisualizer()
    visualizer.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
