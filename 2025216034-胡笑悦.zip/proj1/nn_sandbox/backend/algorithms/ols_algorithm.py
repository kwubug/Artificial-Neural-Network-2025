
import time

import numpy as np

from .base_algorithm import BaseAlgorithm


class OlsAlgorithm(BaseAlgorithm):
    """
    Ordinary Least Squares using online gradient descent on y = a * x + b.

    Dataset format is expected as [[x, y, ...], ...]. Any extra columns (e.g., labels)
    are ignored. Training/testing split and iteration scheduling are handled by BaseAlgorithm.
    """

    def __init__(self, dataset, total_epoches, most_correct_rate,
                 initial_learning_rate, search_iteration_constant, test_ratio,
                 ui_refresh_interval: float = 0.0):
        super().__init__(dataset=dataset,
                         total_epoches=total_epoches,
                         most_correct_rate=most_correct_rate,
                         initial_learning_rate=initial_learning_rate,
                         search_iteration_constant=search_iteration_constant,
                         test_ratio=test_ratio)
        self.a = 0.0
        self.b = 0.0
        self._ui_refresh_interval = ui_refresh_interval

    def _initialize_neurons(self):
        # Initialize parameters a, b to zeros
        self.a = 0.0
        self.b = 0.0

    def _iterate(self):
        # Stochastic gradient descent on a single sample
        x, y = self.current_data[0], self.current_data[1]
        y_hat = self.a * x + self.b
        error = (y_hat - y)

        lr = self.current_learning_rate
        # Gradients for MSE (without 1/N factor): d/da = 2*error*x, d/db = 2*error
        self.a -= lr * (2.0 * error * x)
        self.b -= lr * (2.0 * error)

        # pacing is handled in Observable wrapper

    def _correct_rate(self, dataset):
        # Use R^2 as a "correct rate" for regression visualization
        if dataset is None or len(dataset) == 0:
            return 0.0
        data = np.asarray(dataset)
        x = data[:, 0]
        y = data[:, 1]
        y_hat = self.a * x + self.b
        ss_res = float(np.sum((y - y_hat) ** 2))
        ss_tot = float(np.sum((y - np.mean(y)) ** 2))
        if ss_tot == 0.0:
            return 1.0 if ss_res == 0.0 else 0.0
        r2 = 1.0 - ss_res / ss_tot
        # clamp to [0, 1] for chart consistency
        return max(0.0, min(1.0, r2))