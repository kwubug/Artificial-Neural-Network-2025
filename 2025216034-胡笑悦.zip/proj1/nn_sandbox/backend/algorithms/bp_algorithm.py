import numpy as np
from nn_sandbox.backend.algorithms.base_algorithm import PredictiveAlgorithm
from nn_sandbox.backend.utils import sigmoid


class Perceptron:
    """基础感知器类"""
    def __init__(self, activation_func, mode='unipolar'):
        self.activation_func = lambda x: activation_func(x, mode)
        self.synaptic_weight = None  # 包含偏置的权重数组

    def forward(self, inputs):
        """前向传播（自动加偏置项）"""
        inputs_with_bias = np.append(inputs, 1.0)
        total = np.dot(self.synaptic_weight, inputs_with_bias)
        return self.activation_func(total)


class BpAlgorithm(PredictiveAlgorithm):
    """带动量机制 + 支持多种优化算法的 BP 算法（修正版：改进 Newton 与 CG 实现）"""

    def __init__(self, *args,
                 network_shape=(6,),          # 隐藏层结构
                 optimizer='sgd',             # 新增：优化算法类型
                 momentum_weight=0.9,         # 动量系数
                 activation_mode='unipolar',  # 激活函数模式
                 newton_damping=1e-3,         # 牛顿法阻尼项（Levenberg 风格）
                 cg_restart_interval=50,      # 共轭梯度重启间隔（iterations）
                 cg_normalize=True,           # 是否对 CG 方向做归一化，避免步长过大
                 max_step_norm=5.0,           # 单步权重更新范数上限（防止爆发）
                 **kwargs):
        """
        network_shape: tuple，例如 (6,) 表示单隐藏层6个神经元；
        optimizer: 'sgd' | 'momentum' | 'newton' | 'cg'
        momentum_weight: 动量项权重，用于平滑梯度下降。
        activation_mode: 激活函数模式，'unipolar' 或 'bipolar'。
        newton_damping: 牛顿法阻尼项，数值越大越保守。
        cg_restart_interval: 每隔多少次迭代强制重启 CG（防止方向退化）。
        cg_normalize: 是否归一化 CG 方向向量（推荐 True）。
        max_step_norm: 限制单次权重更新的范数，避免不稳定跳跃。
        """
        super().__init__(*args, **kwargs)
        self.network_shape = network_shape
        self.optimizer = optimizer.lower()
        self.momentum_weight = momentum_weight
        self.activation_mode = activation_mode

        # Newton & CG 相关可调参数
        self.newton_damping = newton_damping
        self.cg_restart_interval = cg_restart_interval
        self.cg_normalize = cg_normalize
        self.max_step_norm = max_step_norm

        # 内部缓存
        self._prev_weight_updates = None
        self._prev_gradients = None
        self._conjugate_directions = None

        # 记录迭代次数，用于 CG 重启策略
        self._iter_count = 0

    # ========================= 初始化神经元 =========================
    def _initialize_neurons(self):
        """初始化每层神经元及权重"""
        input_size = len(self.training_dataset[0]) - 1
        output_size = len(self.group_types)
        layer_sizes = [input_size] + list(self.network_shape) + [output_size]

        self._neurons = []

        for i in range(1, len(layer_sizes)):
            layer = []
            prev_layer_size = layer_sizes[i - 1]
            for _ in range(layer_sizes[i]):
                neuron = Perceptron(sigmoid, mode=self.activation_mode)
                neuron.synaptic_weight = np.random.uniform(-0.5, 0.5, prev_layer_size + 1)
                layer.append(neuron)
            self._neurons.append(layer)

        # 初始化动量缓存
        self._prev_weight_updates = [
            [np.zeros_like(neuron.synaptic_weight) for neuron in layer]
            for layer in self._neurons
        ]

        # 初始化 CG/gradient 缓存（按层按神经元保存向量）
        self._prev_gradients = [
            [np.zeros_like(neuron.synaptic_weight) for neuron in layer]
            for layer in self._neurons
        ]
        self._conjugate_directions = [
            [np.zeros_like(neuron.synaptic_weight) for neuron in layer]
            for layer in self._neurons
        ]

        # 迭代计数重置
        self._iter_count = 0

    # ========================= 前向传播 =========================
    def _pass_forward(self, inputs):
        """计算每层输出"""
        activations = [inputs]
        for layer in self._neurons:
            outputs = [neuron.forward(activations[-1]) for neuron in layer]
            activations.append(np.array(outputs))
        return activations

    # ========================= 反向传播（多算法支持） =========================
    def _pass_backward(self, y, activations):
        """反向传播误差 + 多种优化算法（改进 Newton & CG）"""
        outputs = activations[-1]

        # 构建目标向量
        target = np.full(len(self.group_types),
                         -1.0 if self.activation_mode == 'bipolar' else 0.0)
        target[y] = 1.0

        # 激活函数导数（输入为神经元输出值 z）
        def activation_derivative(z):
            if self.activation_mode == 'bipolar':
                return 0.5 * (1.0 - np.square(z))
            else:
                return z * (1.0 - z)

        deltas = [None] * len(self._neurons)

        # 输出层 delta (向量化)
        deltas[-1] = activation_derivative(outputs) * (target - outputs)

        # 隐层 delta（反向传播）
        for i in reversed(range(len(self._neurons) - 1)):
            next_layer = self._neurons[i + 1]
            # 取出下一层每个神经元的权重（去掉偏置）
            next_weights = np.array([n.synaptic_weight[:-1] for n in next_layer])  # shape (next_layer_size, this_layer_size)
            error = np.dot(next_weights.T, deltas[i + 1])  # shape (this_layer_size,)
            layer_output = activations[i + 1]
            deltas[i] = activation_derivative(layer_output) * error

        # ========== 更新权重部分 ==========
        eps = 1e-8
        # 每次反向传播完成后计数（用于 CG 重启）
        self._iter_count += 1

        for i, layer in enumerate(self._neurons):
            inputs = np.append(activations[i], 1.0)  # 输入向量（含偏置）
            for j, neuron in enumerate(layer):
                # gradient 为与权重同形状的向量（对每个权重的偏导）
                gradient = deltas[i][j] * inputs  # shape matches neuron.synaptic_weight

                # ========== 不同优化器的更新策略 ==========
                if self.optimizer == 'sgd':
                    # 最速下降（小步长）
                    delta_w = self.current_learning_rate * gradient

                elif self.optimizer == 'momentum':
                    # 动量法
                    delta_w = (self.current_learning_rate * gradient +
                               self.momentum_weight * self._prev_weight_updates[i][j])

                elif self.optimizer == 'newton':
                    # ---------- 牛顿法（对角 Hessian 近似 + 阻尼/正则化） ----------
                    # 说明：
                    #  - gradient = dL/dw （与原实现一致）
                    #  - 用对角近似的 Hessian：h ≈ max(|grad|, eps) + damping
                    #  - Levenberg 风格阻尼：增加 newton_damping 以防止震荡
                    h_approx = np.maximum(np.abs(gradient), 1e-6) + self.newton_damping
                    # 用 division 而不是乘以 1/h 的原因是与牛顿方向对应：step ~ grad / h
                    delta_w = self.current_learning_rate * (gradient / (h_approx + eps))

                    # 限制单步更新的范数，防止牛顿步过大导致震荡
                    step_norm = np.linalg.norm(delta_w)
                    if step_norm > self.max_step_norm:
                        delta_w = delta_w * (self.max_step_norm / (step_norm + eps))

                elif self.optimizer == 'cg':
                    # ---------- 共轭梯度法（向量化按单个神经元的权重向量处理） ----------
                    # gradient, prev_grad, prev_dir 都是与权重同形的向量
                    prev_grad = self._prev_gradients[i][j]
                    prev_dir = self._conjugate_directions[i][j]

                    g_dot_g = np.dot(gradient, gradient)
                    prev_g_dot_prev_g = np.dot(prev_grad, prev_grad)

                    # 如果 prev_grad 接近 0 或者到达重启间隔，则重启 CG（direction = gradient）
                    restart_condition = (
                        prev_g_dot_prev_g < 1e-12 or
                        (self.cg_restart_interval is not None and self._iter_count % self.cg_restart_interval == 0)
                    )

                    if restart_condition:
                        beta = 0.0
                    else:
                        # Fletcher-Reeves beta: beta = (g_k^T g_k) / (g_{k-1}^T g_{k-1})
                        beta = g_dot_g / (prev_g_dot_prev_g + 1e-12)

                        # 有时 beta 可能数值不稳定（非常大或为 nan），做保护
                        if not np.isfinite(beta) or beta < 0 or beta > 1e6:
                            beta = 0.0

                    # 共轭方向（这里与原实现一致的“正向”方向，因为我们使用正的 learning_rate * direction）
                    direction = gradient + beta * prev_dir

                    # 当方向为 0（数值退化）时退回到梯度方向
                    if np.linalg.norm(direction) < 1e-12:
                        direction = gradient.copy()
                        beta = 0.0

                    # 可选：对方向做归一化以避免步长过大（通常可提高稳定性）
                    if self.cg_normalize:
                        dir_norm = np.linalg.norm(direction)
                        if dir_norm > 0:
                            direction = direction / (dir_norm + eps)

                    # 学习步（注意保留原 sign：使用正的 current_learning_rate * direction，这与我们构造 gradient = deltas * inputs 保持方向一致）
                    delta_w = self.current_learning_rate * direction

                    # 限制步长范数
                    step_norm = np.linalg.norm(delta_w)
                    if step_norm > self.max_step_norm:
                        delta_w = delta_w * (self.max_step_norm / (step_norm + eps))

                    # 更新缓存
                    self._prev_gradients[i][j] = gradient.copy()
                    self._conjugate_directions[i][j] = direction.copy()

                else:
                    raise ValueError(f"未知优化算法: {self.optimizer}")

                # 应用更新并保存上次权重更新（用于 momentum）
                neuron.synaptic_weight += delta_w
                self._prev_weight_updates[i][j] = delta_w

    # ========================= 主训练迭代 =========================
    def _iterate(self):
        """单次迭代"""
        x, raw_label = self.current_data[:-1], self.current_data[-1]
        label = np.where(self.group_types == raw_label)[0][0]
        activations = self._pass_forward(x)
        self._pass_backward(label, activations)

    # ========================= 准确率计算 =========================
    def _correct_rate(self, dataset):
        correct = 0
        for data in dataset:
            x, raw_label = data[:-1], data[-1]
            label = np.where(self.group_types == raw_label)[0][0]
            prediction = self.predict(x)
            if prediction == label:
                correct += 1
        return correct / len(dataset)

    # ========================= 预测函数 =========================
    def predict(self, inputs):
        activations = self._pass_forward(inputs)
        outputs = activations[-1]
        return int(np.argmax(outputs))

# import numpy as np
# from nn_sandbox.backend.algorithms.base_algorithm import PredictiveAlgorithm
# from nn_sandbox.backend.utils import sigmoid
#
#
# class Perceptron:
#     """基础感知器类"""
#     # def __init__(self, activation_func):
#     #     self.activation_func = activation_func
#     #     self.synaptic_weight = None  # 包含偏置的权重数组
#     def __init__(self, activation_func, mode='unipolar'):
#         self.activation_func = lambda x: activation_func(x, mode)  # 使用模式传递给sigmoid
#         self.synaptic_weight = None  # 包含偏置的权重数组
#
#     def forward(self, inputs):
#         """前向传播（自动加偏置项）"""
#         inputs_with_bias = np.append(inputs, 1.0)
#         total = np.dot(self.synaptic_weight, inputs_with_bias)
#         return self.activation_func(total)
#
#
# class BpAlgorithm(PredictiveAlgorithm):
#     """带动量机制 + 支持多层结构的 BP 算法"""
#
#     def __init__(self, *args,
#                  network_shape=(6,),         # 隐藏层结构，例如 (8,4)
#                  momentum_weight=0.9,        # 动量系数
#                  activation_mode='unipolar',  # 激活函数模式
#                  **kwargs):
#         """
#         network_shape: tuple，例如 (6,) 表示单隐藏层6个神经元；
#                        (8, 4) 表示两层隐藏层分别为8和4个神经元。
#         momentum_weight: 动量项权重，用于平滑梯度下降。
#         activation_mode: 激活函数模式，'unipolar' 或 'bipolar'，默认 'unipolar'
#         """
#         super().__init__(*args, **kwargs)
#         self.network_shape = network_shape
#         self.momentum_weight = momentum_weight
#         self.activation_mode = activation_mode
#         self._prev_weight_updates = None
#
#     # ========================= 初始化神经元 =========================
#     def _initialize_neurons(self):
#         """初始化每层神经元及权重"""
#         input_size = len(self.training_dataset[0]) - 1
#         output_size = len(self.group_types)
#         layer_sizes = [input_size] + list(self.network_shape) + [output_size]
#
#         self._neurons = []
#
#         # 构建每一层
#         for i in range(1, len(layer_sizes)):
#             layer = []
#             prev_layer_size = layer_sizes[i - 1]
#             for _ in range(layer_sizes[i]):
#                 # neuron = Perceptron(sigmoid)
#                 neuron = Perceptron(sigmoid, mode=self.activation_mode)
#                 neuron.synaptic_weight = np.random.uniform(-0.5, 0.5, prev_layer_size + 1)
#                 layer.append(neuron)
#             self._neurons.append(layer)
#
#         # 初始化动量缓存（同形状）
#         self._prev_weight_updates = [
#             [np.zeros_like(neuron.synaptic_weight) for neuron in layer]
#             for layer in self._neurons
#         ]
#
#     # ========================= 主训练迭代 =========================
#     def _iterate(self):
#         """单次迭代"""
#         x, raw_label = self.current_data[:-1], self.current_data[-1]
#         # 把真实标签映射到 group_types 索引
#         label = np.where(self.group_types == raw_label)[0][0]
#
#         activations = self._pass_forward(x)
#         self._pass_backward(label, activations)
#
#     # ========================= 前向传播 =========================
#     def _pass_forward(self, inputs):
#         """计算每层输出"""
#         activations = [inputs]
#         for layer in self._neurons:
#             outputs = [neuron.forward(activations[-1]) for neuron in layer]
#             activations.append(np.array(outputs))
#         return activations
#
#     # ========================= 反向传播（带动量） =========================
#     def _pass_backward(self, y, activations):
#         """反向传播误差 + 更新权重"""
#         # 输出层真实输出
#         outputs = activations[-1]
#         # 按激活函数模式生成目标向量
#         target = np.full(len(self.group_types), -1.0 if self.activation_mode == 'bipolar' else 0.0)
#         target[y] = 1.0
#
#         def activation_derivative(z):
#             if self.activation_mode == 'bipolar':
#                 return 0.5 * (1.0 - np.square(z))
#             else:
#                 return z * (1.0 - z)
#
#         deltas = [None] * len(self._neurons)
#
#         # 输出层 delta
#         deltas[-1] = activation_derivative(outputs) * (target - outputs)
#
#         # 隐层 delta
#         for i in reversed(range(len(self._neurons) - 1)):
#             next_layer = self._neurons[i + 1]
#             next_weights = np.array([n.synaptic_weight[:-1] for n in next_layer])
#             error = np.dot(next_weights.T, deltas[i + 1])
#             layer_output = activations[i + 1]
#             deltas[i] = activation_derivative(layer_output) * error
#
#         # 更新权重（带动量）
#         for i, layer in enumerate(self._neurons):
#             inputs = np.append(activations[i], 1.0)
#             for j, neuron in enumerate(layer):
#                 gradient = deltas[i][j] * inputs
#                 delta_w = self.current_learning_rate * gradient + \
#                           self.momentum_weight * self._prev_weight_updates[i][j]
#                 neuron.synaptic_weight += delta_w
#                 self._prev_weight_updates[i][j] = delta_w
#
#     # ========================= 准确率计算 =========================
#     def _correct_rate(self, dataset):
#         correct = 0
#         for data in dataset:
#             x, raw_label = data[:-1], data[-1]
#             label = np.where(self.group_types == raw_label)[0][0]
#             prediction = self.predict(x)
#             if prediction == label:
#                 correct += 1
#         return correct / len(dataset)
#
#     # ========================= 预测函数 =========================
#     def predict(self, inputs):
#         activations = self._pass_forward(inputs)
#         outputs = activations[-1]
#         return int(np.argmax(outputs))
