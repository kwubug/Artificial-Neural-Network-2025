import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.gridspec import GridSpec
import itertools


class AnimatedHopfieldNetwork:
    def __init__(self, n_neurons):
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.energy_history = []
        self.states_history = []
        self.current_iteration = 0

    def train(self, patterns):
        """Train network using Hebbian learning rule"""
        for pattern in patterns:
            pattern = np.array(pattern).reshape(-1, 1)
            self.weights += np.dot(pattern, pattern.T)
        np.fill_diagonal(self.weights, 0)
        self.weights = self.weights / len(patterns)

    def energy(self, state):
        """Calculate network energy"""
        return -0.5 * np.dot(state.T, np.dot(self.weights, state))[0, 0]

    def async_update_animated(self, initial_state, max_iter=100):
        """Asynchronous update for animation"""
        state = initial_state.copy()
        self.energy_history = [self.energy(state)]
        self.states_history = [state.copy()]
        self.current_iteration = 0

        for iteration in range(max_iter):
            # Randomly select neuron to update
            neuron_idx = np.random.randint(self.n_neurons)

            # Calculate net input
            net_input = np.dot(self.weights[neuron_idx, :], state)

            # Update neuron state
            new_state = 1 if net_input >= 0 else -1
            if state[neuron_idx, 0] != new_state:
                state[neuron_idx, 0] = new_state
                self.states_history.append(state.copy())
                self.energy_history.append(self.energy(state))

            # Check for convergence
            if len(self.states_history) > 1 and np.array_equal(self.states_history[-1], self.states_history[-2]):
                break

        return state


def create_hopfield_animation():
    """Create Hopfield network animation"""
    # Define training patterns (5x5 images)
    patterns = [
        # Pattern 1: H
        [-1, -1, 1, -1, -1,
         -1, -1, 1, -1, -1,
         1, 1, 1, 1, 1,
         -1, -1, 1, -1, -1,
         -1, -1, 1, -1, -1],

        # Pattern 2: X
        [1, -1, -1, -1, 1,
         -1, 1, -1, 1, -1,
         -1, -1, 1, -1, -1,
         -1, 1, -1, 1, -1,
         1, -1, -1, -1, 1]
    ]

    # Create and train network
    hopfield_net = AnimatedHopfieldNetwork(25)
    hopfield_net.train(patterns)

    # Test pattern (noisy H)
    test_pattern = np.array([-1, 1, 1, -1, -1,
                             -1, -1, 1, -1, -1,
                             1, 1, 1, 1, 1,
                             -1, -1, 1, -1, -1,
                             -1, -1, 1, -1, -1]).reshape(-1, 1)

    # Perform update
    final_state = hopfield_net.async_update_animated(test_pattern, max_iter=50)

    # Create animation
    fig = plt.figure(figsize=(15, 10))
    gs = GridSpec(3, 3, figure=fig)

    # Create subplots
    ax1 = fig.add_subplot(gs[0, 0])  # Weight matrix
    ax2 = fig.add_subplot(gs[0, 1])  # Current state
    ax3 = fig.add_subplot(gs[0, 2])  # Target pattern
    ax4 = fig.add_subplot(gs[1, :])  # Energy evolution
    ax5 = fig.add_subplot(gs[2, :])  # State evolution

    # Initialize plots
    n_side = int(np.sqrt(hopfield_net.n_neurons))

    # Weight matrix
    im_weights = ax1.imshow(hopfield_net.weights, cmap='coolwarm', aspect='auto', animated=True)
    ax1.set_title('Weight Matrix')
    plt.colorbar(im_weights, ax=ax1)

    # Current state
    current_state_img = ax2.imshow(hopfield_net.states_history[0].reshape(n_side, n_side),
                                   cmap='binary', vmin=-1, vmax=1, animated=True)
    ax2.set_title('Current State')
    ax2.axis('off')

    # Target pattern
    target_pattern = patterns[0]  # Use first training pattern as target
    target_img = ax3.imshow(np.array(target_pattern).reshape(n_side, n_side),
                            cmap='binary', vmin=-1, vmax=1)
    ax3.set_title('Target Pattern (H)')
    ax3.axis('off')

    # Energy evolution
    energy_line, = ax4.plot([], [], 'b-', linewidth=2, label='Energy')
    ax4.set_xlim(0, len(hopfield_net.energy_history))
    ax4.set_ylim(min(hopfield_net.energy_history) - 1, max(hopfield_net.energy_history) + 1)
    ax4.set_xlabel('Iteration')
    ax4.set_ylabel('Energy')
    ax4.set_title('Energy Evolution')
    ax4.legend()
    ax4.grid(True, alpha=0.3)

    # Network state evolution (show recent states)
    state_axes = []
    state_imgs = []
    n_show_states = 6

    for i in range(n_show_states):
        row = i // 3
        col = i % 3
        ax = fig.add_subplot(gs[2, col])
        state_axes.append(ax)
        img = ax.imshow(np.zeros((n_side, n_side)), cmap='binary', vmin=-1, vmax=1, animated=True)
        state_imgs.append(img)
        ax.set_title(f'Iter {i}')
        ax.axis('off')

    # Information text
    info_text = fig.text(0.5, 0.02, '', ha='center', fontsize=12)

    def animate(frame):
        # Update current state
        if frame < len(hopfield_net.states_history):
            current_state = hopfield_net.states_history[frame]
            current_state_img.set_array(current_state.reshape(n_side, n_side))

            # Update energy curve
            if frame < len(hopfield_net.energy_history):
                energy_line.set_data(range(frame + 1), hopfield_net.energy_history[:frame + 1])

            # Update state evolution
            for i in range(min(n_show_states, frame + 1)):
                if frame - i >= 0:
                    state_idx = max(0, frame - (n_show_states - 1) + i)
                    if state_idx < len(hopfield_net.states_history):
                        state_imgs[i].set_array(hopfield_net.states_history[state_idx].reshape(n_side, n_side))
                        state_axes[i].set_title(f'Iter {state_idx}')

            # Update information text
            info_text.set_text(f'Iteration: {frame}/{len(hopfield_net.states_history) - 1} | '
                               f'Energy: {hopfield_net.energy_history[frame]:.2f} | '
                               f'Changed Neuron: {frame if frame < len(hopfield_net.states_history) - 1 else "Converged"}')

        return [current_state_img, energy_line] + state_imgs + [info_text]

    # Create animation
    anim = animation.FuncAnimation(
        fig, animate, frames=len(hopfield_net.states_history),
        interval=500, blit=False, repeat=True
    )

    plt.tight_layout()
    plt.show()

    return anim


# Run Hopfield animation
print("Creating Hopfield Network Animation...")
hopfield_anim = create_hopfield_animation()