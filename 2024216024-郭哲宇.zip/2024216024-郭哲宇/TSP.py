import itertools
import matplotlib.pyplot as plt

def calculate_distance(city1, city2):
    return ((city1[0] - city2[0]) ** 2 + (city1[1] - city2[1]) ** 2) ** 0.5

def total_distance(route, cities):
    distance = 0
    for i in range(len(route) - 1):
        distance += calculate_distance(cities[route[i]], cities[route[i + 1]])
    distance += calculate_distance(cities[route[-1]], cities[route[0]])  # 返回起点
    return distance

def tsp_brute_force(cities):
    n = len(cities)
    min_distance = float('inf')
    best_route = None
    
    for route in itertools.permutations(range(n)):
        current_distance = total_distance(route, cities)
        if current_distance < min_distance:
            min_distance = current_distance
            best_route = route
            
    return best_route, min_distance

def plot_route(cities, route):
    # 绘制城市和路径
    plt.figure(figsize=(10, 6))
    x = [cities[i][0] for i in route] + [cities[route[0]][0]]  # 加回到起点
    y = [cities[i][1] for i in route] + [cities[route[0]][1]]  # 加回到起点

    plt.plot(x, y, marker='o', linestyle='-', color='b')
    
    # 标注城市
    for i, (x_coord, y_coord) in enumerate(cities):
        plt.text(x_coord, y_coord, f'City {i}', fontsize=12, ha='right')

    plt.title('Traveling Salesman Problem (TSP) Solution')
    plt.xlabel('X Coordinate')
    plt.ylabel('Y Coordinate')
    plt.grid()
    plt.show()

# 示例：城市坐标
cities = [(0, 0), (1, 2), (2, 4), (3, 1), (4, 0)]
best_route, min_distance = tsp_brute_force(cities)

print("最短路径:", best_route)
print("最短距离:", min_distance)

# 可视化
plot_route(cities, best_route)
