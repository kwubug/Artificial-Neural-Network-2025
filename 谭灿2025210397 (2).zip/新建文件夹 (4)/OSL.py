import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider
import scipy.stats as stats
from sklearn.metrics import r2_score, mean_squared_error
import pandas as pd

# 设置matplotlib使用TkAgg后端
import matplotlib

matplotlib.use('TkAgg')

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class OLSRegression:
    def __init__(self, n_samples=100, noise_level=1.0, true_slope=2.0, true_intercept=5.0):
        """
        初始化OLS回归模型
        """
        self.n_samples = n_samples
        self.noise_level = noise_level
        self.true_slope = true_slope
        self.true_intercept = true_intercept

        # 生成数据
        self.generate_data()

        # 模型参数
        self.slope = 0.0
        self.intercept = 0.0
        self.r_squared = 0.0
        self.mse = 0.0

        # 训练历史记录
        self.history = {
            'slopes': [],
            'intercepts': [],
            'r_squared': [],
            'mse': []
        }

    def generate_data(self):
        """
        生成模拟数据
        """
        np.random.seed(42)  # 设置随机种子以保证可重复性

        # 生成自变量X（均匀分布）
        self.X = np.random.uniform(0, 10, self.n_samples)

        # 生成因变量y（带有噪声的线性关系）
        self.y_true = self.true_slope * self.X + self.true_intercept
        noise = np.random.normal(0, self.noise_level, self.n_samples)
        self.y = self.y_true + noise

        # 计算统计量
        self.X_mean = np.mean(self.X)
        self.y_mean = np.mean(self.y)

    def fit(self):
        """
        使用OLS方法拟合模型
        """
        # 计算斜率和截距
        numerator = np.sum((self.X - self.X_mean) * (self.y - self.y_mean))
        denominator = np.sum((self.X - self.X_mean) ** 2)

        self.slope = numerator / denominator
        self.intercept = self.y_mean - self.slope * self.X_mean

        # 计算预测值
        self.y_pred = self.slope * self.X + self.intercept

        # 计算统计指标
        self.calculate_statistics()

        # 记录历史
        self.history['slopes'].append(self.slope)
        self.history['intercepts'].append(self.intercept)
        self.history['r_squared'].append(self.r_squared)
        self.history['mse'].append(self.mse)

    def calculate_statistics(self):
        """
        计算统计指标
        """
        # 计算R平方
        ss_res = np.sum((self.y - self.y_pred) ** 2)
        ss_tot = np.sum((self.y - self.y_mean) ** 2)
        self.r_squared = 1 - (ss_res / ss_tot)

        # 计算均方误差
        self.mse = mean_squared_error(self.y, self.y_pred)

        # 计算标准误差
        n = len(self.X)
        self.slope_se = np.sqrt(self.mse / np.sum((self.X - self.X_mean) ** 2))
        self.intercept_se = self.slope_se * np.sqrt(np.sum(self.X ** 2) / n)

        # 计算t统计量和p值
        self.slope_t = self.slope / self.slope_se
        self.intercept_t = self.intercept / self.intercept_se

        self.slope_p = 2 * (1 - stats.t.cdf(np.abs(self.slope_t), n - 2))
        self.intercept_p = 2 * (1 - stats.t.cdf(np.abs(self.intercept_t), n - 2))

    def predict(self, X):
        """
        使用训练好的模型进行预测
        """
        return self.slope * X + self.intercept

    def get_summary(self):
        """
        获取模型摘要统计信息
        """
        summary = {
            'coefficients': {
                'slope': self.slope,
                'intercept': self.intercept
            },
            'standard_errors': {
                'slope': self.slope_se,
                'intercept': self.intercept_se
            },
            't_statistics': {
                'slope': self.slope_t,
                'intercept': self.intercept_t
            },
            'p_values': {
                'slope': self.slope_p,
                'intercept': self.intercept_p
            },
            'goodness_of_fit': {
                'r_squared': self.r_squared,
                'mse': self.mse
            },
            'true_parameters': {
                'true_slope': self.true_slope,
                'true_intercept': self.true_intercept
            }
        }
        return summary

    def update_parameters(self, n_samples=None, noise_level=None, true_slope=None, true_intercept=None):
        """
        更新模型参数并重新生成数据
        """
        if n_samples is not None:
            self.n_samples = n_samples
        if noise_level is not None:
            self.noise_level = noise_level
        if true_slope is not None:
            self.true_slope = true_slope
        if true_intercept is not None:
            self.true_intercept = true_intercept

        self.generate_data()
        self.fit()


class OLSVisualizer:
    def __init__(self, ols_model):
        """
        初始化OLS可视化界面
        """
        self.ols = ols_model
        self.fig = plt.figure(figsize=(15, 10))
        self.setup_layout()
        self.setup_widgets()

        # 初始拟合
        self.ols.fit()
        self.update_all_plots()

    def setup_layout(self):
        """
        设置可视化布局
        """
        # 创建所有子图使用绝对坐标
        # 第一行
        self.ax_scatter = self.fig.add_axes([0.05, 0.6, 0.4, 0.35])  # 散点图和回归线
        self.ax_residuals = self.fig.add_axes([0.55, 0.6, 0.4, 0.35])  # 残差图

        # 第二行
        self.ax_qq = self.fig.add_axes([0.05, 0.3, 0.25, 0.25])  # Q-Q图
        self.ax_hist = self.fig.add_axes([0.35, 0.3, 0.25, 0.25])  # 残差直方图
        self.ax_stats = self.fig.add_axes([0.65, 0.3, 0.3, 0.25])  # 统计信息

        # 控件区域
        self.ax_controls = self.fig.add_axes([0.05, 0.05, 0.9, 0.2])  # 控件区域
        self.ax_controls.axis('off')  # 隐藏控件区域的坐标轴

        self.fig.suptitle('普通最小二乘法(OLS)回归可视化', fontsize=16, fontweight='bold')

    def setup_widgets(self):
        """
        设置交互控件
        """
        # 控制按钮
        ax_button_fit = self.fig.add_axes([0.1, 0.15, 0.1, 0.04])
        ax_button_new_data = self.fig.add_axes([0.1, 0.10, 0.1, 0.04])

        # 参数滑块
        ax_slider_samples = self.fig.add_axes([0.3, 0.15, 0.2, 0.02])
        ax_slider_noise = self.fig.add_axes([0.3, 0.12, 0.2, 0.02])
        ax_slider_slope = self.fig.add_axes([0.3, 0.09, 0.2, 0.02])
        ax_slider_intercept = self.fig.add_axes([0.3, 0.06, 0.2, 0.02])

        # 创建按钮
        self.button_fit = Button(ax_button_fit, '重新拟合')
        self.button_new_data = Button(ax_button_new_data, '新数据')

        # 创建滑块
        self.slider_samples = Slider(ax_slider_samples, '样本数', 10, 500, valinit=self.ols.n_samples)
        self.slider_noise = Slider(ax_slider_noise, '噪声水平', 0.1, 5.0, valinit=self.ols.noise_level)
        self.slider_slope = Slider(ax_slider_slope, '真实斜率', -5.0, 5.0, valinit=self.ols.true_slope)
        self.slider_intercept = Slider(ax_slider_intercept, '真实截距', -10.0, 10.0, valinit=self.ols.true_intercept)

        # 绑定事件
        self.button_fit.on_clicked(self.refit_model)
        self.button_new_data.on_clicked(self.generate_new_data)

        self.slider_samples.on_changed(self.update_parameters)
        self.slider_noise.on_changed(self.update_parameters)
        self.slider_slope.on_changed(self.update_parameters)
        self.slider_intercept.on_changed(self.update_parameters)

    def refit_model(self, event):
        """
        重新拟合模型
        """
        self.ols.fit()
        self.update_all_plots()

    def generate_new_data(self, event):
        """
        生成新数据并重新拟合
        """
        self.ols.generate_data()
        self.ols.fit()
        self.update_all_plots()

    def update_parameters(self, val):
        """
        更新模型参数
        """
        self.ols.update_parameters(
            n_samples=int(self.slider_samples.val),
            noise_level=self.slider_noise.val,
            true_slope=self.slider_slope.val,
            true_intercept=self.slider_intercept.val
        )
        self.update_all_plots()

    def update_all_plots(self):
        """
        更新所有子图
        """
        self.plot_scatter()
        self.plot_residuals()
        self.plot_qq()
        self.plot_histogram()
        self.plot_statistics()

    def plot_scatter(self):
        """
        绘制散点图和回归线
        """
        self.ax_scatter.clear()

        # 绘制原始数据点
        self.ax_scatter.scatter(self.ols.X, self.ols.y, alpha=0.7, color='blue', label='观测数据')

        # 绘制真实关系线（如果知道真实参数）
        x_range = np.linspace(min(self.ols.X), max(self.ols.X), 100)
        true_line = self.ols.true_slope * x_range + self.ols.true_intercept
        self.ax_scatter.plot(x_range, true_line, 'g--', linewidth=2, alpha=0.7, label='真实关系')

        # 绘制拟合回归线
        pred_line = self.ols.slope * x_range + self.ols.intercept
        self.ax_scatter.plot(x_range, pred_line, 'r-', linewidth=2, label='OLS拟合')

        # 添加图例和标签
        self.ax_scatter.legend()
        self.ax_scatter.set_xlabel('自变量 (X)')
        self.ax_scatter.set_ylabel('因变量 (y)')
        self.ax_scatter.set_title('OLS回归拟合效果')
        self.ax_scatter.grid(True, alpha=0.3)

        # 添加统计信息文本
        stats_text = f'R² = {self.ols.r_squared:.4f}\n斜率 = {self.ols.slope:.4f}\n截距 = {self.ols.intercept:.4f}'
        self.ax_scatter.text(0.05, 0.95, stats_text, transform=self.ax_scatter.transAxes,
                             fontsize=12, verticalalignment='top',
                             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    def plot_residuals(self):
        """
        绘制残差图
        """
        self.ax_residuals.clear()

        # 计算残差
        residuals = self.ols.y - self.ols.y_pred

        # 绘制残差散点图
        self.ax_residuals.scatter(self.ols.y_pred, residuals, alpha=0.7, color='purple')

        # 添加零参考线
        self.ax_residuals.axhline(y=0, color='red', linestyle='--', alpha=0.7)

        self.ax_residuals.set_xlabel('预测值')
        self.ax_residuals.set_ylabel('残差')
        self.ax_residuals.set_title('残差图')
        self.ax_residuals.grid(True, alpha=0.3)

        # 添加残差统计信息
        residual_stats = f'残差均值: {np.mean(residuals):.4f}\n残差标准差: {np.std(residuals):.4f}'
        self.ax_residuals.text(0.05, 0.95, residual_stats, transform=self.ax_residuals.transAxes,
                               fontsize=10, verticalalignment='top',
                               bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    def plot_qq(self):
        """
        绘制Q-Q图（检验残差正态性）
        """
        self.ax_qq.clear()

        # 计算标准化残差
        residuals = self.ols.y - self.ols.y_pred
        standardized_residuals = (residuals - np.mean(residuals)) / np.std(residuals)

        # 生成理论分位数
        theoretical_quantiles = stats.norm.ppf(np.linspace(0.01, 0.99, len(standardized_residuals)))

        # 绘制Q-Q图
        self.ax_qq.scatter(theoretical_quantiles, np.sort(standardized_residuals), alpha=0.7, color='orange')

        # 添加参考线
        min_val = min(theoretical_quantiles.min(), standardized_residuals.min())
        max_val = max(theoretical_quantiles.max(), standardized_residuals.max())
        self.ax_qq.plot([min_val, max_val], [min_val, max_val], 'r--', alpha=0.7)

        self.ax_qq.set_xlabel('理论分位数')
        self.ax_qq.set_ylabel('样本分位数')
        self.ax_qq.set_title('Q-Q图 (正态性检验)')
        self.ax_qq.grid(True, alpha=0.3)

    def plot_histogram(self):
        """
        绘制残差直方图
        """
        self.ax_hist.clear()

        # 计算残差
        residuals = self.ols.y - self.ols.y_pred

        # 绘制直方图
        n, bins, patches = self.ax_hist.hist(residuals, bins=15, alpha=0.7, color='teal', density=True)

        # 添加正态分布曲线
        x = np.linspace(residuals.min(), residuals.max(), 100)
        pdf = stats.norm.pdf(x, np.mean(residuals), np.std(residuals))
        self.ax_hist.plot(x, pdf, 'r-', linewidth=2, label='正态分布')

        self.ax_hist.set_xlabel('残差')
        self.ax_hist.set_ylabel('密度')
        self.ax_hist.set_title('残差分布')
        self.ax_hist.legend()
        self.ax_hist.grid(True, alpha=0.3)

    def plot_statistics(self):
        """
        显示统计信息
        """
        self.ax_stats.clear()

        # 获取模型摘要
        summary = self.ols.get_summary()

        # 创建统计信息文本
        stats_text = (
            "=== OLS回归结果 ===\n\n"
            f"样本数量: {self.ols.n_samples}\n"
            f"噪声水平: {self.ols.noise_level:.2f}\n\n"
            "=== 系数估计 ===\n"
            f"斜率: {summary['coefficients']['slope']:.4f}\n"
            f"  标准误: {summary['standard_errors']['slope']:.4f}\n"
            f"  t统计量: {summary['t_statistics']['slope']:.4f}\n"
            f"  p值: {summary['p_values']['slope']:.4f}\n\n"
            f"截距: {summary['coefficients']['intercept']:.4f}\n"
            f"  标准误: {summary['standard_errors']['intercept']:.4f}\n"
            f"  t统计量: {summary['t_statistics']['intercept']:.4f}\n"
            f"  p值: {summary['p_values']['intercept']:.4f}\n\n"
            "=== 拟合优度 ===\n"
            f"R²: {summary['goodness_of_fit']['r_squared']:.4f}\n"
            f"均方误差(MSE): {summary['goodness_of_fit']['mse']:.4f}\n\n"
            "=== 真实参数 ===\n"
            f"真实斜率: {summary['true_parameters']['true_slope']:.2f}\n"
            f"真实截距: {summary['true_parameters']['true_intercept']:.2f}"
        )

        self.ax_stats.text(0.02, 0.98, stats_text, fontsize=10, va='top',
                           bbox=dict(boxstyle="round", facecolor="lightblue", alpha=0.7))
        self.ax_stats.axis('off')


def demonstrate_ols():
    """
    演示OLS算法的完整过程
    """
    print("=== 普通最小二乘法(OLS)学习算法演示 ===\n")

    # 创建OLS模型
    ols_model = OLSRegression(n_samples=100, noise_level=1.0, true_slope=2.0, true_intercept=5.0)

    print("1. 数据生成:")
    print(f"   - 生成了 {ols_model.n_samples} 个样本点")
    print(f"   - 真实关系: y = {ols_model.true_slope} * x + {ols_model.true_intercept}")
    print(f"   - 添加了噪声水平: {ols_model.noise_level}")
    print(f"   - X范围: [{min(ols_model.X):.2f}, {max(ols_model.X):.2f}]")
    print(f"   - y范围: [{min(ols_model.y):.2f}, {max(ols_model.y):.2f}]")

    # 拟合模型
    ols_model.fit()
    summary = ols_model.get_summary()

    print("\n2. 模型训练完成:")
    print(f"   - 估计斜率: {summary['coefficients']['slope']:.4f}")
    print(f"   - 估计截距: {summary['coefficients']['intercept']:.4f}")

    print("\n3. 统计指标:")
    print(f"   - R平方值: {summary['goodness_of_fit']['r_squared']:.4f}")
    print(f"   - 均方误差(MSE): {summary['goodness_of_fit']['mse']:.4f}")

    print("\n4. 系数显著性检验:")
    print(f"   - 斜率t统计量: {summary['t_statistics']['slope']:.4f}")
    print(f"   - 斜率p值: {summary['p_values']['slope']:.4f}")
    print(f"   - 截距t统计量: {summary['t_statistics']['intercept']:.4f}")
    print(f"   - 截距p值: {summary['p_values']['intercept']:.4f}")

    # 创建可视化界面
    visualizer = OLSVisualizer(ols_model)

    print("\n5. 可视化界面已启动!")
    print("   使用界面控件可以:")
    print("   - 调整样本数量和噪声水平")
    print("   - 修改真实参数观察拟合效果")
    print("   - 生成新数据重新拟合")
    print("   - 查看残差分析和统计检验")

    plt.show()


if __name__ == "__main__":
    demonstrate_ols()