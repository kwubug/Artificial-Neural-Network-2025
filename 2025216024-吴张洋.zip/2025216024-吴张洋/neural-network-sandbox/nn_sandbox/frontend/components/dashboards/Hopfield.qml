import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield'
    
    // 使用上下布局，与参考实现的左右布局不同
    ColumnLayout {
        spacing: 10
        
        // 顶部：控制面板（卡片式设计）
        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 150
            spacing: 10
            
            // 左侧：数据集和参数设置
            GroupBox {
                title: '⚙️ 网络配置'
                Layout.fillWidth: true
                Layout.preferredHeight: 140
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    columnSpacing: 10
                    
                    Label {
                        text: '📁 数据集'
                        Layout.alignment: Qt.AlignRight
                    }
                    ComboBox {
                        id: datasetCombobox
                        enabled: hopfieldBridge && hopfieldBridge.has_finished
                        model: Object.keys(hopfieldBridge.dataset_dict)
                        onActivated: () => {
                            hopfieldBridge.current_dataset_name = currentText
                            updatePatterns()
                        }
                        Component.onCompleted: () => {
                            if (currentText) {
                                hopfieldBridge.current_dataset_name = currentText
                                updatePatterns()
                            }
                        }
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '🔄 最大迭代'
                        Layout.alignment: Qt.AlignRight
                    }
                    SpinBox {
                        id: maxIterations
                        enabled: hopfieldBridge && hopfieldBridge.has_finished
                        value: 1000
                        from: 100
                        to: 10000
                        onValueChanged: hopfieldBridge.max_iterations = value
                        Component.onCompleted: hopfieldBridge.max_iterations = value
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '🎯 收敛阈值'
                        Layout.alignment: Qt.AlignRight
                    }
                    DoubleSpinBox {
                        enabled: hopfieldBridge && hopfieldBridge.has_finished
                        value: 0.001 * 10000
                        from: 1
                        to: 10000
                        onValueChanged: hopfieldBridge.convergence_threshold = value / 10000
                        Component.onCompleted: hopfieldBridge.convergence_threshold = value / 10000
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '⏱️ 刷新间隔'
                        Layout.alignment: Qt.AlignRight
                    }
                    DoubleSpinBox {
                        enabled: hopfieldBridge && hopfieldBridge.has_finished
                        value: 0.05 * 100
                        from: 0
                        to: 500
                        onValueChanged: hopfieldBridge.ui_refresh_interval = value / 100
                        Component.onCompleted: hopfieldBridge.ui_refresh_interval = value / 100
                        Layout.fillWidth: true
                    }
                }
            }
            
            // 中间：操作按钮
            GroupBox {
                title: '🎮 操作控制'
                Layout.preferredWidth: 200
                Layout.preferredHeight: 140
                
                ColumnLayout {
                    anchors.fill: parent
                    spacing: 8
                    
                    Button {
                        text: '🚀 训练网络'
                        enabled: hopfieldBridge && hopfieldBridge.has_finished
                        onClicked: () => {
                            hopfieldBridge.start_hopfield_algorithm()
                            energyChart.reset()
                            stateDisplay.clear()
                        }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '🔍 测试模式'
                        enabled: hopfieldBridge && hopfieldBridge.has_finished && 
                                 hopfieldBridge.weights.length > 0
                        onClicked: () => {
                            testWithNoise()
                        }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '⏹️ 停止'
                        enabled: hopfieldBridge && !hopfieldBridge.has_finished
                        onClicked: hopfieldBridge.stop_hopfield_algorithm()
                        Layout.fillWidth: true
                    }
                }
            }
            
            // 右侧：实时信息（使用卡片样式）
            GroupBox {
                title: '📊 实时状态'
                Layout.preferredWidth: 250
                Layout.preferredHeight: 140
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    columnSpacing: 8
                    
                    Label {
                        text: '迭代次数'
                        font.pixelSize: 11
                    }
                    Label {
                        text: hopfieldBridge.current_iterations + 1
                        font.bold: true
                        color: '#2196F3'
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '网络能量'
                        font.pixelSize: 11
                    }
                    Label {
                        id: energyLabel
                        text: hopfieldBridge.current_energy.toFixed(4)
                        font.bold: true
                        color: energyColor()
                        Layout.fillWidth: true
                        
                        function energyColor() {
                            const energy = hopfieldBridge.current_energy
                            if (energy < -50) return '#4CAF50'  // 绿色 - 低能量
                            if (energy < -20) return '#FF9800'  // 橙色 - 中等能量
                            return '#F44336'  // 红色 - 高能量
                        }
                    }
                    
                    Label {
                        text: '收敛状态'
                        font.pixelSize: 11
                    }
                    Label {
                        text: hopfieldBridge.has_converged ? '✓ 已收敛' : '⏳ 运行中'
                        font.bold: true
                        color: hopfieldBridge.has_converged ? '#4CAF50' : '#FF9800'
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '吸引子'
                        font.pixelSize: 11
                    }
                    Label {
                        text: hopfieldBridge.attractor_state.length > 0 ? '✓ 已找到' : '—'
                        font.bold: true
                        color: hopfieldBridge.attractor_state.length > 0 ? '#2196F3' : '#9E9E9E'
                        Layout.fillWidth: true
                    }
                }
            }
        }
        
        // 中间：主要可视化区域（使用Tab布局，与参考实现不同）
        TabBar {
            id: tabBar
            Layout.fillWidth: true
            
            TabButton { text: '🎨 网络状态' }
            TabButton { text: '📈 能量变化' }
            TabButton { text: '🎯 吸引子' }
        }
        
        StackLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 300
            Layout.maximumHeight: 350
            currentIndex: tabBar.currentIndex
            
            // Tab 1: 网络状态可视化（使用热力图风格）
            GroupBox {
                title: '当前网络状态（点击神经元切换状态）'
                
                ScrollView {
                    anchors.fill: parent
                    clip: true
                            
                            Grid {
                                id: stateDisplay
                                anchors.centerIn: parent
                                columns: 0
                                spacing: 3
                                
                                property int gridSize: 0
                                
                                function clear() {
                                    for (let i = children.length - 1; i >= 0; i--) {
                                        children[i].destroy()
                                    }
                                }
                                
                                function update() {
                                    clear()
                                    const state = hopfieldBridge.current_state
                                    if (!state || state.length === 0) return
                                    
                                    gridSize = Math.sqrt(state.length)
                                    if (gridSize * gridSize !== state.length) {
                                        gridSize = Math.ceil(Math.sqrt(state.length))
                                    }
                                    columns = gridSize
                                    
                                    for (let i = 0; i < state.length; i++) {
                                        const cell = stateCell.createObject(stateDisplay, {
                                            index: i,
                                            value: state[i]
                                        })
                                    }
                                }
                                
                                Component {
                                    id: stateCell
                                    Rectangle {
                                        property int index: 0
                                        property int value: 0
                                        width: 25
                                        height: 25
                                        
                                        // 使用渐变色，与参考实现的纯黑白不同
                                        gradient: Gradient {
                                            GradientStop { 
                                                position: 0.0
                                                color: value > 0 ? '#1E88E5' : '#E0E0E0'
                                            }
                                            GradientStop { 
                                                position: 1.0
                                                color: value > 0 ? '#1565C0' : '#BDBDBD'
                                            }
                                        }
                                        
                                        border.color: '#424242'
                                        border.width: 1
                                        radius: 3
                                        
                                        // 添加动画效果
                                        Behavior on color {
                                            ColorAnimation { duration: 200 }
                                        }
                                        
                                        MouseArea {
                                            anchors.fill: parent
                                            enabled: hopfieldBridge.has_finished && 
                                                     hopfieldBridge.weights.length > 0
                                            cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                            
                                            onClicked: () => {
                                                const state = hopfieldBridge.current_state.slice()
                                                state[index] = -state[index]
                                                hopfieldBridge.test_pattern(state)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
            
            // Tab 2: 能量变化图表（使用面积图，与参考实现的折线图不同）
            GroupBox {
                title: '能量变化曲线'
                
                ChartView {
                    id: energyChart
                    anchors.fill: parent
                    antialiasing: true
                    
                    property var energySeries: null
                    
                    ValueAxis {
                        id: xAxis
                        titleText: '迭代次数'
                        min: 0
                        max: 100
                    }
                    
                    ValueAxis {
                        id: yAxis
                        titleText: '能量值'
                        min: -100
                        max: 0
                    }
                    
                    function updateAxes(point) {
                        xAxis.max = Math.max(xAxis.max, point.x + 10)
                        yAxis.max = Math.max(yAxis.max, point.y * 1.1)
                        yAxis.min = Math.min(yAxis.min, point.y * 1.1)
                    }
                    
                    function reset() {
                        removeAllSeries()
                        const series = createSeries(
                            ChartView.SeriesTypeArea, '能量', xAxis, yAxis
                        )
                        if (series) {
                            series.borderWidth = 2
                            series.borderColor = '#2196F3'
                            series.color = '#E3F2FD'
                            energySeries = series
                            if (series.pointAdded) {
                                series.pointAdded.connect((index) => {
                                    if (series && series.at) {
                                        updateAxes(series.at(index))
                                    }
                                })
                            }
                        }
                        xAxis.max = 100
                        yAxis.min = -100
                        yAxis.max = 0
                    }
                    
                    Component.onCompleted: reset()
                }
            }
            
            // Tab 3: 吸引子展示（使用卡片式布局，与参考实现的列表不同）
            ScrollView {
                clip: true
                
                Flow {
                    width: parent.width - 20
                    spacing: 15
                    padding: 10
                    
                    Repeater {
                        model: hopfieldBridge.attractor_state.length > 0 ? 1 : 0
                        
                        Rectangle {
                            width: 200
                            height: 250
                            border.color: '#2196F3'
                            border.width: 2
                            radius: 8
                            color: '#F5F5F5'
                            
                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 10
                                spacing: 8
                                
                                Label {
                                    text: '🎯 吸引子状态'
                                    font.bold: true
                                    font.pixelSize: 14
                                    Layout.alignment: Qt.AlignHCenter
                                }
                                
                                Grid {
                                    id: attractorGrid
                                    Layout.alignment: Qt.AlignHCenter
                                    columns: 0
                                    spacing: 2
                                    
                                    Component.onCompleted: update()
                                    onVisibleChanged: if (visible) update()
                                    
                                    function update() {
                                        // 清除现有子元素
                                        for (let i = children.length - 1; i >= 0; i--) {
                                            children[i].destroy()
                                        }
                                        
                                        const state = hopfieldBridge.attractor_state
                                        if (!state || state.length === 0) {
                                            columns = 0
                                            return
                                        }
                                        
                                        const gridSize = Math.sqrt(state.length)
                                        const size = gridSize * gridSize === state.length ? gridSize : Math.ceil(Math.sqrt(state.length))
                                        columns = size
                                        
                                        for (let i = 0; i < state.length; i++) {
                                            const cell = attractorCell.createObject(attractorGrid, {
                                                value: state[i]
                                            })
                                        }
                                    }
                                    
                                    Component {
                                        id: attractorCell
                                        Rectangle {
                                            property int value: 0
                                            width: 20
                                            height: 20
                                            
                                            gradient: Gradient {
                                                GradientStop { 
                                                    position: 0.0
                                                    color: value > 0 ? '#4CAF50' : '#E0E0E0'
                                                }
                                                GradientStop { 
                                                    position: 1.0
                                                    color: value > 0 ? '#2E7D32' : '#BDBDBD'
                                                }
                                            }
                                            
                                            border.color: '#424242'
                                            border.width: 1
                                            radius: 2
                                        }
                                    }
                                }
                                
                                Item { Layout.fillHeight: true }
                                
                                Label {
                                    text: '能量: ' + hopfieldBridge.current_energy.toFixed(4)
                                    font.pixelSize: 12
                                    Layout.alignment: Qt.AlignHCenter
                                }
                            }
                        }
                    }
                    
                    // 如果没有吸引子，显示提示
                    Label {
                        visible: hopfieldBridge.attractor_state.length === 0
                        text: '暂无吸引子\n请先训练网络并测试模式'
                        horizontalAlignment: Text.AlignHCenter
                        color: '#9E9E9E'
                        width: parent.width
                        height: 100
                    }
                }
            }
        }
        
    }
    
    function updatePatterns() {
        stateDisplay.update()
    }
    
    function testWithNoise() {
        const dataset = hopfieldBridge.dataset_dict[datasetCombobox.currentText]
        if (dataset && dataset.length > 0) {
            const pattern = dataset[0].slice()
            // 添加20%噪声
            for (let i = 0; i < Math.floor(pattern.length * 0.2); i++) {
                const idx = Math.floor(Math.random() * pattern.length)
                pattern[idx] = -pattern[idx]
            }
            hopfieldBridge.test_pattern(pattern)
        }
    }
    
    Connections {
        target: hopfieldBridge
        function onCurrent_stateChanged() {
            stateDisplay.update()
        }
        function onAttractor_stateChanged() {
            // 吸引子状态变化时，如果正在查看吸引子标签页，则更新显示
            // 注意：由于attractorGrid在StackLayout中，我们需要确保它在可见时更新
        }
        function onEnergy_historyChanged() {
            if (hopfieldBridge.energy_history && hopfieldBridge.energy_history.length > 0) {
                if (energyChart.energySeries) {
                    energyChart.energySeries.clear()
                    for (let i = 0; i < hopfieldBridge.energy_history.length; i++) {
                        energyChart.energySeries.append(i + 1, hopfieldBridge.energy_history[i])
                    }
                }
            }
        }
        function onHas_finishedChanged() {
            if (hopfieldBridge.has_finished) {
                stateDisplay.update()
            }
        }
    }
}
