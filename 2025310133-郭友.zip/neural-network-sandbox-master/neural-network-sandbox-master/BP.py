import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import random


class NeuralNetwork:
    def __init__(self, input_nodes, hidden_nodes, output_nodes, learning_rate, activation_func):
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.learning_rate = learning_rate
        self.activation_func = activation_func  # 'single' or 'double'

        # 权值初始化 [-1, 1] 区间随机数
        self.weights_ih = np.random.uniform(-1, 1, (hidden_nodes, input_nodes))
        self.weights_ho = np.random.uniform(-1, 1, (output_nodes, hidden_nodes))

        # 偏置初始化
        self.bias_h = np.random.uniform(-1, 1, (hidden_nodes, 1))
        self.bias_o = np.random.uniform(-1, 1, (output_nodes, 1))

        self.loss_history = []

    def sigmoid(self, x):
        """Sigmoid激活函数"""
        if self.activation_func == 'single':
            # 单线性Sigmoid
            return 1 / (1 + np.exp(-x))
        else:
            # 双线性Sigmoid (tanh)
            return np.tanh(x)

    def sigmoid_derivative(self, x):
        """Sigmoid导数"""
        if self.activation_func == 'single':
            s = self.sigmoid(x)
            return s * (1 - s)
        else:
            # tanh导数
            return 1 - np.tanh(x) ** 2

    def feedforward(self, inputs):
        """前向传播"""
        inputs = np.array(inputs).reshape(-1, 1)

        # 隐藏层计算
        self.hidden = self.sigmoid(np.dot(self.weights_ih, inputs) + self.bias_h)

        # 输出层计算
        self.output = self.sigmoid(np.dot(self.weights_ho, self.hidden) + self.bias_o)

        return self.output

    def train(self, inputs, targets):
        """反向传播训练"""
        inputs = np.array(inputs).reshape(-1, 1)
        targets = np.array(targets).reshape(-1, 1)

        # 前向传播
        self.feedforward(inputs)

        # 计算输出层误差
        output_errors = targets - self.output

        # 计算损失 (MSE)
        loss = np.mean(output_errors ** 2)
        self.loss_history.append(loss)

        # 计算输出层梯度
        output_gradients = output_errors * self.sigmoid_derivative(self.output)
        output_gradients *= self.learning_rate

        # 计算隐藏层误差
        hidden_errors = np.dot(self.weights_ho.T, output_errors)

        # 计算隐藏层梯度
        hidden_gradients = hidden_errors * self.sigmoid_derivative(self.hidden)
        hidden_gradients *= self.learning_rate

        # 更新权重
        self.weights_ho += np.dot(output_gradients, self.hidden.T)
        self.weights_ih += np.dot(hidden_gradients, inputs.T)

        # 更新偏置
        self.bias_o += output_gradients
        self.bias_h += hidden_gradients

        return loss


class NeuralNetworkGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("三层前馈神经网络BP算法")
        self.root.geometry("800x600")

        self.nn = None
        self.setup_gui()

    def setup_gui(self):
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 参数设置区域
        params_frame = ttk.LabelFrame(main_frame, text="网络参数设置", padding="10")
        params_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        # 输入层节点数
        ttk.Label(params_frame, text="输入层节点数:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.input_nodes = ttk.Entry(params_frame, width=10)
        self.input_nodes.grid(row=0, column=1, pady=2)
        self.input_nodes.insert(0, "2")

        # 隐藏层节点数
        ttk.Label(params_frame, text="隐藏层节点数:").grid(row=0, column=2, sticky=tk.W, pady=2)
        self.hidden_nodes = ttk.Entry(params_frame, width=10)
        self.hidden_nodes.grid(row=0, column=3, pady=2)
        self.hidden_nodes.insert(0, "4")

        # 输出层节点数
        ttk.Label(params_frame, text="输出层节点数:").grid(row=0, column=4, sticky=tk.W, pady=2)
        self.output_nodes = ttk.Entry(params_frame, width=10)
        self.output_nodes.grid(row=0, column=5, pady=2)
        self.output_nodes.insert(0, "1")

        # 学习率
        ttk.Label(params_frame, text="学习率:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.learning_rate = ttk.Entry(params_frame, width=10)
        self.learning_rate.grid(row=1, column=1, pady=2)
        self.learning_rate.insert(0, "0.1")

        # 激活函数选择
        ttk.Label(params_frame, text="激活函数:").grid(row=1, column=2, sticky=tk.W, pady=2)
        self.activation_var = tk.StringVar(value="single")
        ttk.Radiobutton(params_frame, text="单线性Sigmoid", variable=self.activation_var,
                        value="single").grid(row=1, column=3, pady=2)
        ttk.Radiobutton(params_frame, text="双线性Sigmoid", variable=self.activation_var,
                        value="double").grid(row=1, column=4, pady=2)

        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=1, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="初始化网络", command=self.initialize_network).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="随机初始化权值", command=self.randomize_weights).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="训练网络", command=self.train_network).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="测试网络", command=self.test_network).pack(side=tk.LEFT, padx=5)

        # 训练参数区域
        train_frame = ttk.LabelFrame(main_frame, text="训练参数", padding="10")
        train_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)

        ttk.Label(train_frame, text="训练次数:").grid(row=0, column=0, sticky=tk.W)
        self.epochs = ttk.Entry(train_frame, width=10)
        self.epochs.grid(row=0, column=1)
        self.epochs.insert(0, "1000")

        # 结果显示区域
        result_frame = ttk.LabelFrame(main_frame, text="网络状态和结果", padding="10")
        result_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)

        self.result_text = tk.Text(result_frame, height=10, width=70)
        self.result_text.pack(fill=tk.BOTH, expand=True)

        # 损失曲线区域
        self.fig, self.ax = plt.subplots(figsize=(6, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=main_frame)
        self.canvas.get_tk_widget().grid(row=4, column=0, columnspan=2, pady=10)

        # 配置权重和偏置显示
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(3, weight=1)

    def initialize_network(self):
        try:
            input_nodes = int(self.input_nodes.get())
            hidden_nodes = int(self.hidden_nodes.get())
            output_nodes = int(self.output_nodes.get())
            learning_rate = float(self.learning_rate.get())
            activation_func = self.activation_var.get()

            self.nn = NeuralNetwork(input_nodes, hidden_nodes, output_nodes,
                                    learning_rate, activation_func)

            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"神经网络初始化成功！\n")
            self.result_text.insert(tk.END, f"网络结构: {input_nodes}-{hidden_nodes}-{output_nodes}\n")
            self.result_text.insert(tk.END, f"学习率: {learning_rate}\n")
            self.result_text.insert(tk.END,
                                    f"激活函数: {'单线性Sigmoid' if activation_func == 'single' else '双线性Sigmoid'}\n")
            self.result_text.insert(tk.END, f"权值已用[-1,1]区间随机数初始化\n")

        except ValueError as e:
            messagebox.showerror("输入错误", "请检查输入参数是否为有效数字")

    def randomize_weights(self):
        if self.nn:
            self.nn.weights_ih = np.random.uniform(-1, 1, (self.nn.hidden_nodes, self.nn.input_nodes))
            self.nn.weights_ho = np.random.uniform(-1, 1, (self.nn.output_nodes, self.nn.hidden_nodes))
            self.nn.bias_h = np.random.uniform(-1, 1, (self.nn.hidden_nodes, 1))
            self.nn.bias_o = np.random.uniform(-1, 1, (self.nn.output_nodes, 1))
            self.result_text.insert(tk.END, "权值和偏置已重新随机初始化\n")
        else:
            messagebox.showwarning("警告", "请先初始化网络")

    def train_network(self):
        if not self.nn:
            messagebox.showwarning("警告", "请先初始化网络")
            return

        try:
            epochs = int(self.epochs.get())

            # 使用简单的XOR问题作为训练示例
            training_data = [
                ([0, 0], [0]),
                ([0, 1], [1]),
                ([1, 0], [1]),
                ([1, 1], [0])
            ]

            self.nn.loss_history = []

            for i in range(epochs):
                # 随机选择训练样本
                data = random.choice(training_data)
                inputs, targets = data
                loss = self.nn.train(inputs, targets)

                if i % 100 == 0:
                    self.result_text.insert(tk.END, f"迭代 {i}: 损失 = {loss:.6f}\n")
                    self.result_text.see(tk.END)

            # 绘制损失曲线
            self.ax.clear()
            self.ax.plot(self.nn.loss_history)
            self.ax.set_title('Training Loss Curve')
            self.ax.set_xlabel('Number of iterations')
            self.ax.set_ylabel('loss')
            self.ax.grid(True)
            self.canvas.draw()

            self.result_text.insert(tk.END, f"\n训练完成！最终损失 = {loss:.6f}\n")

        except ValueError as e:
            messagebox.showerror("输入错误", "请检查训练次数是否为有效数字")

    def test_network(self):
        if not self.nn:
            messagebox.showwarning("警告", "请先初始化并训练网络")
            return

        self.result_text.insert(tk.END, "\n=== 网络测试 ===\n")

        # 测试XOR问题的所有情况
        test_cases = [
            ([0, 0], 0),
            ([0, 1], 1),
            ([1, 0], 1),
            ([1, 1], 0)
        ]

        for inputs, expected in test_cases:
            output = self.nn.feedforward(inputs)
            self.result_text.insert(tk.END,
                                    f"输入: {inputs} -> 输出: {output[0][0]:.4f} (期望: {expected})\n")

        # 显示当前权值和偏置
        self.result_text.insert(tk.END, "\n=== 当前权值和偏置 ===\n")
        self.result_text.insert(tk.END, f"输入到隐藏层权值:\n{self.nn.weights_ih}\n")
        self.result_text.insert(tk.END, f"隐藏层偏置:\n{self.nn.bias_h}\n")
        self.result_text.insert(tk.END, f"隐藏层到输出层权值:\n{self.nn.weights_ho}\n")
        self.result_text.insert(tk.END, f"输出层偏置:\n{self.nn.bias_o}\n")


def main():
    root = tk.Tk()
    app = NeuralNetworkGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()