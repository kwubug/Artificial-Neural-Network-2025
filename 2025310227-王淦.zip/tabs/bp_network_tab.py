import sys
import numpy as np
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QDoubleSpinBox,
                               QTextEdit, QFormLayout, QLineEdit, QComboBox)
from PySide6.QtCore import Qt, QThread, Signal
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class BPNetworkTab(QWidget):
    def __init__(self):
        super().__init__()
        self.network = None
        self.training_thread = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 网络参数设置
        param_group = QGroupBox("网络参数设置")
        param_layout = QFormLayout()

        self.input_nodes = QSpinBox()
        self.input_nodes.setRange(1, 20)
        self.input_nodes.setValue(2)

        self.hidden_nodes = QSpinBox()
        self.hidden_nodes.setRange(1, 50)
        self.hidden_nodes.setValue(3)

        self.output_nodes = QSpinBox()
        self.output_nodes.setRange(1, 20)
        self.output_nodes.setValue(1)

        self.learning_rate = QDoubleSpinBox()
        self.learning_rate.setRange(0.001, 1.0)
        self.learning_rate.setValue(0.1)
        self.learning_rate.setSingleStep(0.01)

        self.activation_combo = QComboBox()
        self.activation_combo.addItems(["单极性Sigmoid", "双极性Sigmoid"])

        param_layout.addRow("输入层节点数:", self.input_nodes)
        param_layout.addRow("隐藏层节点数:", self.hidden_nodes)
        param_layout.addRow("输出层节点数:", self.output_nodes)
        param_layout.addRow("学习率:", self.learning_rate)
        param_layout.addRow("激活函数:", self.activation_combo)

        param_group.setLayout(param_layout)

        # 训练参数
        train_group = QGroupBox("训练参数")
        train_layout = QFormLayout()

        self.epochs = QSpinBox()
        self.epochs.setRange(10, 100000)
        self.epochs.setValue(1000)

        self.error_threshold = QDoubleSpinBox()
        self.error_threshold.setRange(0.0001, 1.0)
        self.error_threshold.setValue(0.01)

        train_layout.addRow("最大迭代次数:", self.epochs)
        train_layout.addRow("误差阈值:", self.error_threshold)

        train_group.setLayout(train_layout)

        # 训练数据
        data_group = QGroupBox("训练数据")
        data_layout = QVBoxLayout()

        data_label = QLabel("每行一组，输入与输出用分号分隔 (例如: 0,0;0)")
        self.data_edit = QTextEdit()
        self.data_edit.setPlainText("0,0;0\n0,1;1\n1,0;1\n1,1;0")

        data_layout.addWidget(data_label)
        data_layout.addWidget(self.data_edit)
        data_group.setLayout(data_layout)

        # 按钮区域
        button_layout = QHBoxLayout()
        self.init_button = QPushButton("初始化网络")
        self.train_button = QPushButton("开始训练")
        self.stop_button = QPushButton("停止训练")
        self.test_button = QPushButton("测试网络")

        self.init_button.clicked.connect(self.init_network)
        self.train_button.clicked.connect(self.start_training)
        self.stop_button.clicked.connect(self.stop_training)
        self.test_button.clicked.connect(self.test_network)

        button_layout.addWidget(self.init_button)
        button_layout.addWidget(self.train_button)
        button_layout.addWidget(self.stop_button)
        button_layout.addWidget(self.test_button)

        # 结果显示
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(10, 4)))

        # 布局
        layout.addWidget(param_group)
        layout.addWidget(train_group)
        layout.addWidget(data_group)
        layout.addLayout(button_layout)
        layout.addWidget(self.result_text)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def init_network(self):
        try:
            input_nodes = self.input_nodes.value()
            hidden_nodes = self.hidden_nodes.value()
            output_nodes = self.output_nodes.value()
            learning_rate = self.learning_rate.value()
            activation_type = "single" if self.activation_combo.currentText() == "单极性Sigmoid" else "double"

            self.network = BPNeuralNetwork(input_nodes, hidden_nodes, output_nodes,
                                           learning_rate, activation_type)
            self.result_text.append("网络初始化成功！")

        except Exception as e:
            self.result_text.append(f"初始化错误: {e}")

    def parse_training_data(self):
        try:
            data_text = self.data_edit.toPlainText()
            lines = [line.strip() for line in data_text.split('\n') if line.strip()]

            training_data = []
            input_nodes = self.input_nodes.value()
            output_nodes = self.output_nodes.value()

            for line in lines:
                if ';' not in line:
                    raise ValueError(f"数据格式错误: {line}")

                inputs_str, targets_str = line.split(';', 1)
                inputs = [float(x.strip()) for x in inputs_str.split(',')]
                targets = [float(x.strip()) for x in targets_str.split(',')]

                if len(inputs) != input_nodes:
                    raise ValueError(f"输入维度错误: {line}")
                if len(targets) != output_nodes:
                    raise ValueError(f"输出维度错误: {line}")

                training_data.append((inputs, targets))

            return training_data

        except Exception as e:
            self.result_text.append(f"数据解析错误: {e}")
            return None

    def start_training(self):
        if not self.network:
            self.result_text.append("请先初始化网络！")
            return

        training_data = self.parse_training_data()
        if not training_data:
            return

        self.training_thread = TrainingThread(
            self.network, training_data,
            self.epochs.value(), self.error_threshold.value()
        )
        self.training_thread.update_signal.connect(self.update_training)
        self.training_thread.finish_signal.connect(self.training_finished)
        self.training_thread.start()

        self.train_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.result_text.append("开始训练...")

    def stop_training(self):
        if self.training_thread and self.training_thread.isRunning():
            self.training_thread.stop()
            self.training_thread.wait()

    def training_finished(self):
        self.train_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.result_text.append("训练完成！")

        # 更新误差曲线
        if hasattr(self.network, 'error_history') and self.network.error_history:
            self.canvas.figure.clear()
            ax = self.canvas.figure.add_subplot(111)
            ax.plot(self.network.error_history)
            ax.set_title('训练误差曲线')
            ax.set_xlabel('迭代次数')
            ax.set_ylabel('平均误差')
            ax.grid(True, alpha=0.3)
            self.canvas.draw()

    def update_training(self, error, epoch):
        if epoch % 10 == 0:  # 每10次更新一次显示
            self.result_text.append(f"迭代: {epoch}, 误差: {error:.6f}")

    def test_network(self):
        if not self.network:
            self.result_text.append("请先训练网络！")
            return

        training_data = self.parse_training_data()
        if not training_data:
            return

        self.result_text.append("=== 测试结果 ===")
        for inputs, targets in training_data:
            output = self.network.forward(inputs)
            output_flat = output.flatten()
            self.result_text.append(
                f"输入: {inputs} -> 输出: {[f'{x:.4f}' for x in output_flat]} (期望: {targets})"
            )


# BP神经网络类（简化版）
class BPNeuralNetwork:
    def __init__(self, input_nodes, hidden_nodes, output_nodes, learning_rate, sigmoid_type):
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.learning_rate = learning_rate
        self.sigmoid_type = sigmoid_type
        self.error_history = []

        # 初始化权重
        self.weights_input_hidden = np.random.uniform(-1, 1, (hidden_nodes, input_nodes))
        self.weights_hidden_output = np.random.uniform(-1, 1, (output_nodes, hidden_nodes))

    def sigmoid(self, x):
        if self.sigmoid_type == 'single':
            return 1 / (1 + np.exp(-x))
        else:
            return (1 - np.exp(-x)) / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        if self.sigmoid_type == 'single':
            s = self.sigmoid(x)
            return s * (1 - s)
        else:
            s = self.sigmoid(x)
            return 0.5 * (1 - s ** 2)

    def forward(self, inputs):
        inputs = np.array(inputs).reshape(-1, 1)
        hidden_inputs = np.dot(self.weights_input_hidden, inputs)
        self.hidden_outputs = self.sigmoid(hidden_inputs)

        final_inputs = np.dot(self.weights_hidden_output, self.hidden_outputs)
        self.final_outputs = self.sigmoid(final_inputs)
        return self.final_outputs

    def train_step(self, inputs, targets):
        inputs = np.array(inputs).reshape(-1, 1)
        targets = np.array(targets).reshape(-1, 1)

        # 前向传播
        self.forward(inputs)

        # 计算误差
        output_errors = targets - self.final_outputs

        # 反向传播
        output_gradients = self.sigmoid_derivative(self.final_outputs)
        output_gradients = output_errors * output_gradients

        hidden_errors = np.dot(self.weights_hidden_output.T, output_errors)
        hidden_gradients = self.sigmoid_derivative(self.hidden_outputs)
        hidden_gradients = hidden_errors * hidden_gradients

        # 更新权重
        self.weights_hidden_output += self.learning_rate * np.dot(
            output_gradients, self.hidden_outputs.T)
        self.weights_input_hidden += self.learning_rate * np.dot(
            hidden_gradients, inputs.T)

        return np.sum(output_errors ** 2) / 2


class TrainingThread(QThread):
    update_signal = Signal(float, int)
    finish_signal = Signal()

    def __init__(self, network, training_data, epochs, error_threshold):
        super().__init__()
        self.network = network
        self.training_data = training_data
        self.epochs = epochs
        self.error_threshold = error_threshold
        self.running = True

    def run(self):
        for epoch in range(self.epochs):
            if not self.running:
                break

            total_error = 0
            for inputs, targets in self.training_data:
                error = self.network.train_step(inputs, targets)
                total_error += error

            avg_error = total_error / len(self.training_data)
            self.network.error_history.append(avg_error)

            if epoch % 10 == 0:
                self.update_signal.emit(avg_error, epoch)

            if avg_error < self.error_threshold:
                break

        self.finish_signal.emit()

    def stop(self):
        self.running = False