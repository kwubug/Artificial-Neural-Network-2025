import sys
import random
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QPushButton, QLabel, QGridLayout,
                             QProgressBar, QTextEdit, QGroupBox)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QColor, QFont, QPalette


class BoltzmannMachine:

    def __init__(self):
        self.reset()

    def reset(self):
        self.neurons = [random.choice([-1, 1]) for _ in range(3)]
        self.weights = np.array([
            [0, 0.5, -0.3],
            [0.5, 0, 0.2],
            [-0.3, 0.2, 0]
        ], dtype=np.float32)
        self.biases = np.array([0.1, -0.1, 0.05], dtype=np.float32)
        self.temperature = 1.0
        self.max_steps = 100
        self.stable_threshold = 20
        self.current_step = 0
        self.stable_count = 0
        self.is_balanced = False
        self.energy_history = []

    def energy(self):
        """计算当前系统能量"""
        return -0.5 * np.sum(self.weights * np.outer(self.neurons, self.neurons)) - np.dot(self.biases, self.neurons)

    def update_neuron(self, i):
        """更新单个神经元状态"""
        field = np.dot(self.weights[i], self.neurons) + self.biases[i]
        prob = 1 / (1 + np.exp(-2 * field / self.temperature))
        if random.random() < prob:
            self.neurons[i] = 1
        else:
            self.neurons[i] = -1

    def step(self):
        """执行一步Gibbs采样"""
        if self.is_balanced or self.current_step >= self.max_steps:
            return False

        prev_energy = self.energy()
        for i in random.sample(range(3), 3):
            self.update_neuron(i)

        self.current_step += 1
        current_energy = self.energy()
        self.energy_history.append(current_energy)

        # 检查稳定性
        if abs(current_energy - prev_energy) < 1e-5:
            self.stable_count += 1
            if self.stable_count >= self.stable_threshold:
                self.is_balanced = True
        else:
            self.stable_count = 0

        return True


class BMVisualizer(QMainWindow):
    """主可视化"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("玻尔兹曼机 (3神经元) 可视化")
        self.setGeometry(100, 100, 800, 600)
        self.bm = BoltzmannMachine()
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        title = QLabel("玻尔兹曼机运行过程可视化")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(title)

        neuron_group = QGroupBox("神经元状态")
        neuron_layout = QHBoxLayout(neuron_group)
        self.neuron_labels = []
        for i in range(3):
            frame = QWidget()
            frame.setFixedSize(150, 150)
            frame.setStyleSheet("background-color: white; border-radius: 10px;")
            vbox = QVBoxLayout(frame)

            label = QLabel(f"神经元 {i + 1}")
            label.setAlignment(Qt.AlignCenter)
            label.setFont(QFont("Arial", 12))
            vbox.addWidget(label)

            state = QLabel("?")
            state.setAlignment(Qt.AlignCenter)
            state.setFont(QFont("Arial", 24, QFont.Bold))
            vbox.addWidget(state)

            neuron_layout.addWidget(frame)
            self.neuron_labels.append(state)
        layout.addWidget(neuron_group)

        param_group = QGroupBox("网络参数")
        param_layout = QGridLayout(param_group)

        self.weight_labels = []
        for i in range(3):
            for j in range(3):
                label = QLabel(f"w{i + 1}{j + 1}: {self.bm.weights[i][j]:.2f}")
                label.setAlignment(Qt.AlignCenter)
                param_layout.addWidget(label, i, j)
                self.weight_labels.append(label)

        bias_layout = QHBoxLayout()
        for i in range(3):
            label = QLabel(f"b{i + 1}: {self.bm.biases[i]:.2f}")
            label.setAlignment(Qt.AlignCenter)
            bias_layout.addWidget(label)
        param_layout.addLayout(bias_layout, 3, 0, 1, 3)

        layout.addWidget(param_group)

        # 控制按钮区
        btn_frame = QWidget()
        btn_layout = QHBoxLayout(btn_frame)

        self.start_btn = QPushButton("开始模拟")
        self.start_btn.clicked.connect(self.start_simulation)
        btn_layout.addWidget(self.start_btn)

        self.reset_btn = QPushButton("重置")
        self.reset_btn.clicked.connect(self.reset_simulation)
        btn_layout.addWidget(self.reset_btn)

        self.pause_btn = QPushButton("暂停")
        self.pause_btn.clicked.connect(self.pause_simulation)
        self.pause_btn.setEnabled(False)
        btn_layout.addWidget(self.pause_btn)

        layout.addWidget(btn_frame)

        # 状态信息区
        info_frame = QWidget()
        info_layout = QHBoxLayout(info_frame)

        self.step_label = QLabel("步数: 0")
        info_layout.addWidget(self.step_label)

        self.energy_label = QLabel("能量: 0.00")
        info_layout.addWidget(self.energy_label)

        self.status_label = QLabel("状态: 未开始")
        info_layout.addWidget(self.status_label)

        layout.addWidget(info_frame)

        # 进度条
        self.progress = QProgressBar()
        self.progress.setRange(0, self.bm.max_steps)
        layout.addWidget(self.progress)

        # 日志
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

        # 定时器
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_simulation)

        self.update_display()

    def update_display(self):
        """更新界面显示"""
        # 更新神经元状态
        for i, label in enumerate(self.neuron_labels):
            state = self.bm.neurons[i]
            label.setText(str(state))
            label.setStyleSheet(f"color: {'green' if state == 1 else 'red'};")

        for i in range(3):
            for j in range(3):
                idx = i * 3 + j
                self.weight_labels[idx].setText(f"w{i + 1}{j + 1}: {self.bm.weights[i][j]:.2f}")

        self.step_label.setText(f"步数: {self.bm.current_step}")
        self.energy_label.setText(f"能量: {self.bm.energy():.2f}")

        if self.bm.is_balanced:
            self.status_label.setText("状态: 已平衡")
            self.status_label.setStyleSheet("color: green; font-weight: bold;")
        else:
            self.status_label.setText("状态: 运行中")
            self.status_label.setStyleSheet("color: blue; font-weight: bold;")

        self.progress.setValue(self.bm.current_step)

    def log_message(self, msg):
        """添加日志信息"""
        self.log.append(msg)

    def start_simulation(self):
        """开始模拟"""
        self.bm.reset()
        self.start_btn.setEnabled(False)
        self.reset_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.timer.start(100)  # 每200ms更新一次
        self.log_message("=== 模拟开始 ===")
        self.log_message(f"初始状态: {self.bm.neurons}")
        self.log_message(f"初始能量: {self.bm.energy():.2f}")

    def pause_simulation(self):
        """暂停/继续模拟"""
        if self.timer.isActive():
            self.timer.stop()
            self.pause_btn.setText("继续")
            self.log_message("模拟暂停")
        else:
            self.timer.start()
            self.pause_btn.setText("暂停")
            self.log_message("模拟继续")

    def reset_simulation(self):
        """重置模拟"""
        self.timer.stop()
        self.bm.reset()
        self.update_display()
        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.pause_btn.setText("暂停")
        self.log_message("=== 模拟重置 ===")

    def update_simulation(self):
        """更新模拟状态"""
        if not self.bm.step():
            self.timer.stop()
            self.start_btn.setEnabled(True)
            self.pause_btn.setEnabled(False)
            self.log_message("=== 模拟结束 ===")
            self.log_message(f"最终状态: {self.bm.neurons}")
            self.log_message(f"最终能量: {self.bm.energy():.2f}")
            if self.bm.is_balanced:
                self.log_message("系统已达到热平衡状态")
            else:
                self.log_message("达到最大步数，未达到平衡")

        self.update_display()
        if self.bm.current_step % 10 == 0:
            self.log_message(f"步数 {self.bm.current_step}: 状态={self.bm.neurons}, 能量={self.bm.energy():.2f}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = BMVisualizer()
    window.show()
    sys.exit(app.exec_())
