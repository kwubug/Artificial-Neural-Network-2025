import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(100)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.5)
    search_iteration_constant = BridgeProperty(10000)
    test_ratio = BridgeProperty(0.3)
    input_nodes = BridgeProperty(2)
    hidden_nodes = BridgeProperty(5)
    output_nodes = BridgeProperty(3)
    activation_type = BridgeProperty('unipolar')  # 'unipolar' or 'bipolar'
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    network_weights = BridgeProperty({})

    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        self.bp_algorithm = ObservableBpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
            input_nodes=self.input_nodes,
            hidden_nodes=self.hidden_nodes,
            output_nodes=self.output_nodes,
            activation_type=self.activation_type
        )
        self.bp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        self.bp_algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableBpAlgorithm(Observable, BpAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            # 只有在权重已经初始化后才调用test()
            if hasattr(self, 'weights_input_hidden') and self.weights_input_hidden is not None:
                test_rate = self.test()
                self.notify('test_correct_rate', test_rate)
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 更新网络权重信息
        self.notify('network_weights', self.get_network_weights())
        # 更新学习率
        self.notify('current_learning_rate', self.current_learning_rate)
        # 保持GUI不阻塞
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
