import numpy as np
import matplotlib.pyplot as plt

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class TSPHopfieldNetwork:
    def __init__(self, n_cities, A=500, B=500, C=500, D=500):
        """
        初始化TSP的Hopfield神经网络
        :param n_cities: 城市数量
        :param A, B, C, D: 能量函数参数
        """
        self.n_cities = n_cities
        self.A = A
        self.B = B
        self.C = C
        self.D = D

        # 初始化神经元网络 (n_cities x n_cities)
        # neurons[i,j] = 1 表示第j个位置访问第i个城市
        self.neurons = np.random.randint(0, 2, (n_cities, n_cities))

        # 初始化距离矩阵
        self.distances = None

    def set_distances(self, distances):
        """
        设置城市间距离矩阵
        :param distances: 距离矩阵
        """
        self.distances = distances

    def generate_random_cities(self):
        """
        生成随机城市坐标
        """
        np.random.seed(42)
        cities = np.random.rand(self.n_cities, 2) * 100
        # 计算距离矩阵
        distances = np.zeros((self.n_cities, self.n_cities))
        for i in range(self.n_cities):
            for j in range(self.n_cities):
                distances[i, j] = np.sqrt(np.sum((cities[i] - cities[j]) ** 2))
        self.distances = distances
        return cities

    def energy(self):
        """
        计算当前状态的能量
        """
        # 约束能量项
        A_term = 0  # 每个城市只访问一次
        B_term = 0  # 每个位置只访问一个城市
        C_term = 0  # 总共访问n个城市
        D_term = 0  # 路径距离最小化

        # A项: 每个城市只能访问一次
        for i in range(self.n_cities):
            sum_v = np.sum(self.neurons[i, :])
            A_term += (sum_v - 1) ** 2
        A_term *= self.A / 2

        # B项: 每个位置只能访问一个城市
        for j in range(self.n_cities):
            sum_u = np.sum(self.neurons[:, j])
            B_term += (sum_u - 1) ** 2
        B_term *= self.B / 2

        # C项: 总共访问n个城市
        sum_all = np.sum(self.neurons)
        C_term = self.C / 2 * (sum_all - self.n_cities) ** 2

        # D项: 路径距离最小化
        for i in range(self.n_cities):
            for j in range(self.n_cities):
                if self.distances is not None:
                    for k in range(self.n_cities):
                        kp1 = (k + 1) % self.n_cities
                        D_term += self.distances[i, j] * self.neurons[i, k] * self.neurons[j, kp1]
        D_term *= self.D / 2

        return A_term + B_term + C_term + D_term

    def update_neuron(self, i, j):
        """
        更新单个神经元
        """
        # 计算输入电流
        input_current = -self.A * (np.sum(self.neurons[i, :]) - 1) \
                        - self.B * (np.sum(self.neurons[:, j]) - 1) \
                        - self.C * (np.sum(self.neurons) - self.n_cities)

        # 添加距离项
        if self.distances is not None:
            prev_pos = (j - 1) % self.n_cities
            next_pos = (j + 1) % self.n_cities
            for k in range(self.n_cities):
                if k != i:
                    input_current -= self.D * self.distances[i, k] * \
                                     (self.neurons[k, prev_pos] + self.neurons[k, next_pos])

        # 使用sigmoid函数更新神经元状态
        sigmoid_val = 1 / (1 + np.exp(-input_current))
        # 添加一些随机性以避免局部最小值
        return 1 if sigmoid_val + np.random.normal(0, 0.01) > 0.5 else 0

    def update_network(self, max_iterations=1000):
        """
        更新网络直到收敛
        """
        energy_history = []
        valid_solutions = []

        for iteration in range(max_iterations):
            # 随机选择神经元进行更新
            i, j = np.random.randint(0, self.n_cities, 2)
            old_state = self.neurons[i, j]
            self.neurons[i, j] = self.update_neuron(i, j)

            # 计算能量
            current_energy = self.energy()
            energy_history.append(current_energy)

            # 检查是否为有效解（每个城市访问一次，每个位置一个城市）
            if self.is_valid_solution():
                path = self.get_path()
                path_distance = self.calculate_path_distance(path)
                valid_solutions.append((path, path_distance, iteration))

        return energy_history, valid_solutions

    def is_valid_solution(self):
        """
        检查当前状态是否为有效解
        """
        # 每行和每列都应该恰好有一个1
        for i in range(self.n_cities):
            if np.sum(self.neurons[i, :]) != 1:
                return False
            if np.sum(self.neurons[:, i]) != 1:
                return False
        return True

    def get_path(self):
        """
        从神经元状态提取路径
        """
        path = []
        for j in range(self.n_cities):
            for i in range(self.n_cities):
                if self.neurons[i, j] == 1:
                    path.append(i)
                    break
        return path

    def calculate_path_distance(self, path):
        """
        计算路径总距离
        """
        if self.distances is None or len(path) == 0:
            return float('inf')

        distance = 0
        for i in range(len(path)):
            from_city = path[i]
            to_city = path[(i + 1) % len(path)]
            distance += self.distances[from_city, to_city]
        return distance


def visualize_cities(cities, path=None, title="城市分布"):
    """
    可视化城市和路径
    """
    plt.figure(figsize=(10, 8))
    plt.scatter(cities[:, 0], cities[:, 1], c='red', s=100, zorder=2)

    # 标注城市编号
    for i, (x, y) in enumerate(cities):
        plt.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points', fontsize=12)

    # 如果提供了路径，则绘制路径
    if path is not None and len(path) > 0:
        # 绘制路径
        for i in range(len(path)):
            from_city = path[i]
            to_city = path[(i + 1) % len(path)]
            plt.plot([cities[from_city, 0], cities[to_city, 0]],
                     [cities[from_city, 1], cities[to_city, 1]],
                     'b-', linewidth=2, alpha=0.7)

        # 标注路径方向
        for i in range(len(path)):
            from_city = path[i]
            to_city = path[(i + 1) % len(path)]
            mid_x = (cities[from_city, 0] + cities[to_city, 0]) / 2
            mid_y = (cities[from_city, 1] + cities[to_city, 1]) / 2
            plt.annotate('', xy=(cities[to_city, 0], cities[to_city, 1]),
                         xytext=(cities[from_city, 0], cities[from_city, 1]),
                         arrowprops=dict(arrowstyle='->', color='blue', lw=1.5, alpha=0.7))

    plt.title(title)
    plt.xlabel('X坐标')
    plt.ylabel('Y坐标')
    plt.grid(True, alpha=0.3)
    plt.axis('equal')
    plt.show()


def visualize_energy_convergence(energy_history):
    """
    可视化能量收敛过程
    """
    plt.figure(figsize=(10, 6))
    plt.plot(energy_history, 'b-', linewidth=1)
    plt.title('Hopfield网络能量收敛过程')
    plt.xlabel('迭代次数')
    plt.ylabel('能量')
    plt.grid(True, alpha=0.3)
    plt.show()


def main():
    print("使用Hopfield神经网络解决TSP问题")
    print("=" * 40)

    # 设置城市数量
    n_cities = 6
    print(f"城市数量: {n_cities}")

    # 创建TSP Hopfield网络
    tsp_net = TSPHopfieldNetwork(n_cities)

    # 生成随机城市
    cities = tsp_net.generate_random_cities()
    print("城市坐标:")
    for i, (x, y) in enumerate(cities):
        print(f"城市 {i}: ({x:.2f}, {y:.2f})")

    # 可视化城市分布
    visualize_cities(cities, title="TSP分布图")

    # 显示距离矩阵
    print("\n城市间距离矩阵:")
    print(tsp_net.distances)

    # 更新网络寻找解决方案
    print("\n开始网络优化...")
    energy_history, valid_solutions = tsp_net.update_network(max_iterations=2000)

    # 显示能量收敛过程
    visualize_energy_convergence(energy_history)

    # 显示结果
    print(f"\n找到的有效解数量: {len(valid_solutions)}")

    if valid_solutions:
        # 找到最短路径
        best_solution = min(valid_solutions, key=lambda x: x[1])
        best_path, best_distance, iteration = best_solution

        print(f"\n最佳路径 (迭代 {iteration} 次后找到):")
        print(f"路径: {' -> '.join(map(str, best_path))} -> {best_path[0]}")
        print(f"总距离: {best_distance:.2f}")

        # 可视化最佳路径
        visualize_cities(cities, best_path, title=f"最佳TSP路径 (距离: {best_distance:.2f})")

        # 显示前几个解
        print("\n前5个找到的解:")
        for i, (path, distance, iter_num) in enumerate(valid_solutions[:5]):
            print(f"{i + 1}. 距离: {distance:.2f}, 迭代: {iter_num}, 路径: {' -> '.join(map(str, path))}")
    else:
        print("未找到有效解，请调整参数或增加迭代次数")

        # 显示最终状态
        print("\n最终神经元状态:")
        print(tsp_net.neurons)

        # 尝试提取路径（即使不是有效解）
        path = tsp_net.get_path()
        if path:
            distance = tsp_net.calculate_path_distance(path)
            print(f"最终路径: {' -> '.join(map(str, path))}")
            print(f"路径距离: {distance:.2f}")
            visualize_cities(cities, path, title=f"最终路径 (距离: {distance:.2f})")


if __name__ == "__main__":
    main()
