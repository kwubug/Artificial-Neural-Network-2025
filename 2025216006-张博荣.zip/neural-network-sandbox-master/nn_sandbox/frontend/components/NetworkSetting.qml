import QtQuick 2.13
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

GridLayout {
    property int totalLayers: 6
    property var shape: []

    anchors.fill: parent
    columns: 3
    Label {
        text: 'Number of Layers'
        Layout.alignment: Qt.AlignHCenter
    }
    Slider {
        id: slider
        from: 1
        to: totalLayers
        value: 2
        stepSize: 1
        onValueChanged: updateShape()
        Layout.fillWidth: true
    }
    Label {
        text: slider.value
        Layout.alignment: Qt.AlignHCenter
    }
    Label {
        text: 'Number of Neurons each Layer'
        Layout.alignment: Qt.AlignHCenter
        Layout.columnSpan: 3
    }
    GridLayout {
        columns: totalLayers / 2
        Repeater {
            id: repeater
            model: totalLayers
            RowLayout {
                property alias neuronCount: spinbox.value
                enabled: slider.value >= index + 1
                Label { text: index + 1 }
                SpinBox {
                    id: spinbox
                    from: 1
                    to: 100
                    value: 5
                    onValueChanged: updateShape()
                    Layout.fillWidth: true
                }
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
        Layout.columnSpan: 3
        Layout.fillWidth: true
        Layout.fillHeight: true
    }
    // 新增激活函数选择下拉框
    Label {
        text: '激活函数类型'
        Layout.alignment: Qt.AlignHCenter
        Layout.columnSpan: 3
    }
    ComboBox {
        id: activationCombo
        model: ["单极性Sigmoid", "双极性Sigmoid"]
        currentIndex: 0
        onCurrentIndexChanged: {
            mlpBridge.activationType = currentIndex === 0 ? "single" : "double"
        }
        Layout.columnSpan: 3
        Layout.fillWidth: true
    }
    function updateShape() {
        const newShape = []
        for (let i = 0; i < slider.value; i++) {
            newShape.push(repeater.itemAt(i).neuronCount)
        }
        shape = newShape
    }
    Component.onCompleted: updateShape()
}