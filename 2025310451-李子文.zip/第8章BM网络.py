# -*- coding: utf-8 -*-
"""
Boltzmann Machine（3 神经元，Ising 编码）动态可视化（点击按钮后才开始）
- 左：能量 E(t) 实时曲线（2000 步内从 T_start 线性降至 T_end，并结束）
- 右：三角形网络（3 个神经元），节点颜色/文本显示 s_i∈{-1,+1}，
     本帧被更新的节点用加粗外圈高亮；
- 只有在点击“开始运行”按钮后，才创建并启动动画；未点击前完全静止。
依赖：numpy、matplotlib
"""

import numpy as np
import math
import itertools
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import Circle
from matplotlib.lines import Line2D
from matplotlib.widgets import Button

# 尝试更好显示中文（无该字体也能正常运行）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'Noto Sans CJK SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# ---------------- 参数区（可改） ----------------
rng = np.random.default_rng(42)
W = np.array([[0.0, 1.2, -0.8],
              [1.2, 0.0, 0.5],
              [-0.8, 0.5, 0.0]], dtype=float)
theta = np.array([0.0, 0.2, -0.1], dtype=float)

T_start, T_end = 5.0, 0.2      # 起止温度
steps = 2000                   # 总步数（从 6000 压缩到 2000）
interval_ms = 10               # 动画速度（毫秒/帧），数值越小越快

# ---------------- 基础函数 ----------------
def energy_Ising(s: np.ndarray) -> float:
    """E(s) = -0.5 * s^T W s - theta^T s"""
    return -0.5 * float(s.T @ W @ s) - float(theta @ s)

def gibbs_update_return_i(s: np.ndarray, beta: float) -> int:
    """Gibbs 更新一次，返回被更新的神经元索引 i"""
    i = rng.integers(0, len(s))
    h_i = float(W[i] @ s + theta[i])
    # P(s_i=+1 | 其余) = sigmoid(2*beta*h_i)
    p_plus = 1.0 / (1.0 + math.exp(-2.0 * beta * h_i))
    s[i] = +1 if rng.random() < p_plus else -1
    return i

def enumerate_all_states(n=3):
    for bits in itertools.product([-1, +1], repeat=n):
        yield np.array(bits, dtype=int)

def temperature(t: int) -> float:
    """线性降温：确保最后一步 t=steps-1 正好为 T_end"""
    return T_start + (T_end - T_start) * (t / max(1, steps - 1))

# 估计能量 y 轴范围（把 8 个全局状态能量算一遍）
all_E = np.array([energy_Ising(s) for s in enumerate_all_states(3)])
ymin, ymax = float(all_E.min()) - 0.5, float(all_E.max()) + 0.5

# ---------------- 画布与布局 ----------------
fig = plt.figure(figsize=(11.5, 5.2))
gs = fig.add_gridspec(nrows=1, ncols=2, width_ratios=[2.3, 1.2])

# 左侧：能量曲线
axE = fig.add_subplot(gs[0, 0])
axE.set_title("模拟退火能量动态轨迹")
axE.set_xlabel("迭代步")
axE.set_ylabel("能量 E(s)")
axE.set_xlim(0, steps)
axE.set_ylim(ymin, ymax)
axE.grid(True, linestyle="--", alpha=0.5)
line_energy, = axE.plot([], [], lw=1.2)

# 左图信息板（t, T, s, E）
txt_info = axE.text(0.98, 0.98, "", transform=axE.transAxes,
                    ha="right", va="top", fontsize=10)

# 右侧：三角网络（3 个单元）
axN = fig.add_subplot(gs[0, 1])
axN.set_title("3 个神经元")
axN.set_aspect('equal')
axN.set_xticks([]); axN.set_yticks([])
axN.set_xlim(-1.4, 1.4); axN.set_ylim(-1.2, 1.2)
axN.set_facecolor((0.98, 0.98, 0.98))

# 节点坐标（等边三角形）
node_pos = np.array([
    [0.0,  0.95],         # 节点 0（顶点）
    [-0.95, -0.55],       # 节点 1（左下）
    [0.95, -0.55],        # 节点 2（右下）
])

# 画边（线宽按 |w_ij|），并在中点标注权值
edges = [(0,1), (0,2), (1,2)]
for i, j in edges:
    wij = W[i, j]
    lw = 1.0 + 1.8 * abs(wij)          # 线宽反映权重强弱
    line = Line2D([node_pos[i,0], node_pos[j,0]],
                  [node_pos[i,1], node_pos[j,1]],
                  lw=lw, color="gray", alpha=0.8)
    axN.add_line(line)
    mid = 0.5 * (node_pos[i] + node_pos[j])
    axN.text(mid[0], mid[1], f"{wij:+.1f}", fontsize=10, ha="center", va="center",
             bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="lightgray", alpha=0.9))

# 画 3 个节点（Circle），初始状态随机
s = rng.choice([-1, +1], size=3)
node_patches = []
node_texts = []
for k in range(3):
    c = Circle(tuple(node_pos[k]), radius=0.22,
               facecolor=("#4C78A8" if s[k] == +1 else "#E0E0E0"),
               edgecolor="black", lw=1.5)
    axN.add_patch(c)
    node_patches.append(c)
    txt = axN.text(node_pos[k,0], node_pos[k,1],
                   f"s{k+1}={int(s[k])}", fontsize=12, ha="center", va="center",
                   color="white" if s[k]==+1 else "black")
    node_texts.append(txt)

# 右下角固定显示 W 与 theta（提示运行阶段它们不变）
axN.text(0.02, 0.02, f"W=\n{W}\n\ntheta={theta}",
         transform=axN.transAxes, va="bottom", ha="left", fontsize=9,
         bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="lightgray", alpha=0.9))

# 运行轨迹缓存
E_series, X_series = [], []

# --------- 动画函数（注意：此处只定义，不创建动画实例） ---------
def init_anim():
    line_energy.set_data([], [])
    txt_info.set_text("")
    return (line_energy, *node_patches, *node_texts, txt_info)

def update_anim(t: int):
    # 当前温度 & Gibbs 更新（返回这一步被更新的节点 i）
    T = temperature(t)
    beta = 1.0 / T
    i_updated = gibbs_update_return_i(s, beta)

    # 记录能量曲线
    E = energy_Ising(s)
    E_series.append(E)
    X_series.append(t)
    line_energy.set_data(X_series, E_series)

    # 更新右侧 3 节点显示：颜色/文本；被更新的节点加粗高亮
    for k in range(3):
        node_patches[k].set_facecolor("#4C78A8" if s[k] == +1 else "#E0E0E0")
        node_patches[k].set_linewidth(3.0 if k == i_updated else 1.5)
        node_texts[k].set_text(f"s{k+1}={int(s[k])}")
        node_texts[k].set_color("white" if s[k] == +1 else "black")

    # 左图信息板（t, T, s, E）
    txt_info.set_text(
        f"步数 t = {t}\n"
        f"T = {T:.4f}\n"
        f"s = {list(s)}\n"
        f"E(s) = {E:+.3f}"
    )

    # 结束时把按钮文字改成“完成”
    if t == steps - 1:
        try:
            btn.label.set_text("完成")
            btn.ax.figure.canvas.draw_idle()
        except Exception:
            pass

    return (line_energy, *node_patches, *node_texts, txt_info)

# ---------------- “开始运行”按钮 ----------------
btn_ax = fig.add_axes([0.83, 0.03, 0.14, 0.07])  # [left, bottom, width, height] (figure 坐标)
btn = Button(btn_ax, "开始运行", hovercolor="0.9")

_state = {"started": False, "ani": None}  # 保存动画对象以防被垃圾回收

def on_click(event):
    if _state["started"]:
        return
    _state["started"] = True
    btn.label.set_text("运行中…")
    btn.ax.figure.canvas.draw_idle()
    # 只有点击时才创建动画（之前完全静止、不计算）
    _state["ani"] = FuncAnimation(
        fig, update_anim, frames=range(steps),
        init_func=init_anim, blit=True, interval=interval_ms, repeat=False
    )

btn.on_clicked(on_click)

plt.tight_layout()
plt.show()
