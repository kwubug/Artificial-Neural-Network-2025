import numpy as np

class ThreeLayerFFNN:
    #training_done = pyqtSignal(list)
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.1):
        # 初始化网络结构
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate

        # 初始化权重和偏置
        self.w1 = np.random.randn(self.input_size, self.hidden_size)  # 输入层到隐藏层的权重
        self.b1 = np.zeros((1, self.hidden_size))  # 隐藏层的偏置
        self.w2 = np.random.randn(self.hidden_size, self.output_size)  # 隐藏层到输出层的权重
        self.b2 = np.zeros((1, self.output_size))  # 输出层的偏置

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))  # Sigmoid激活函数

    def sigmoid_derivative(self, x):
        return x * (1 - x)  # Sigmoid的导数

    def forward(self, X):
        # 前向传播
        self.z1 = np.dot(X, self.w1) + self.b1
        self.a1 = self.sigmoid(self.z1)  # 隐藏层激活
        self.z2 = np.dot(self.a1, self.w2) + self.b2
        self.a2 = self.sigmoid(self.z2)  # 输出层激活
        return self.a2

    def backward(self, X, y):
        # 反向传播
        m = X.shape[0]  # 样本数量

        # 计算误差
        output_error = self.a2 - y  # 输出层的误差
        hidden_error = output_error.dot(self.w2.T) * self.sigmoid_derivative(self.a1)  # 隐藏层的误差

        # 更新权重和偏置
        self.w2 -= (self.a1.T.dot(output_error) / m) * self.learning_rate
        self.b2 -= np.sum(output_error, axis=0, keepdims=True) / m * self.learning_rate
        self.w1 -= (X.T.dot(hidden_error) / m) * self.learning_rate
        self.b1 -= np.sum(hidden_error, axis=0, keepdims=True) / m * self.learning_rate

    def train(self, X, y, epochs=1000, progress_callback=None):
        # 训练神经网络
        print_interval = max(1, epochs // 10)  # 每10%打印一次进度
        for i in range(epochs):
            self.forward(X)  # 前向传播
            self.backward(X, y)  # 反向传播
            
            # 每隔一定间隔打印进度
            if (i + 1) % print_interval == 0 or i == 0 or i == epochs - 1:
                # 计算损失（均方误差）
                loss = np.mean(np.square(y - self.a2))
                print(f"Epoch {i+1}/{epochs}, Loss: {loss:.6f}")
                
                # 如果提供了进度回调函数，则调用它
                if progress_callback:
                    try:
                        progress_callback.emit(float(i+1), float(loss))
                    except Exception as e:
                        print(f"Warning: Could not emit progress signal: {e}")
        
        print("Training finished!")