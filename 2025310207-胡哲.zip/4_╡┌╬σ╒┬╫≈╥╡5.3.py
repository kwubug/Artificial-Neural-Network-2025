# -*- coding: utf-8 -*-
"""
RBF approximation of F(x) with two training schemes per the prompt:

F(x) = 1.1 * (1 - x + 2 x^2) * exp(-x^2 / 2)

(1) 聚类法：
    - 训练样本：x ~ U[-4,4]，P=100；y = F(x) + e, e ~ N(0, 0.1^2)
    - 隐节点数 M=10
    - 初始聚类中心取前 10 个训练样本
    - 用 1D K-means 求数据中心
    - 扩展常数（宽度）σ_j = λ * d_nearest_j / sqrt(2)，λ=1
    - 输出权值 w 用伪逆法求解

(2) 梯度法：
    - 学习率 η=0.001，M=10
    - 初始权值 w ~ U[-0.1, 0.1]
    - 初始中心 c ~ U[-4.0, 4.0]
    - 初始 σ ~ U[0.1, 0.3]
    - 目标误差（训练 MSE）= 0.9，最大训练次数 = 5000
"""

import numpy as np
import matplotlib.pyplot as plt
from numpy.linalg import pinv

# 固定随机种子保证可复现
rng = np.random.default_rng(42)

# ---------------------
# 目标函数与数据生成
# ---------------------
def F(x: np.ndarray) -> np.ndarray:
    return 1.1 * (1 - x + 2 * x**2) * np.exp(-x**2 / 2.0)

def make_data(P=100, x_low=-4.0, x_high=4.0, noise_std=0.1, rng=rng):
    x = rng.uniform(x_low, x_high, size=P)
    y = F(x) + rng.normal(0.0, noise_std, size=P)
    return x, y

# ---------------------
# RBF工具函数
# ---------------------
def gaussian_design_matrix(x, centers, sigmas):
    """
    x: (N,)
    centers: (M,)
    sigmas: (M,)
    return: Phi (N, M)
    """
    x = x.reshape(-1, 1)            # (N,1)
    centers = centers.reshape(1, -1) # (1,M)
    sigmas = sigmas.reshape(1, -1)   # (1,M)
    Phi = np.exp(- (x - centers)**2 / (2.0 * (sigmas**2)))
    return Phi

def mse(a, b) -> float:
    return float(np.mean((a - b)**2))

# ---------------------
# (1) 1D K-means + 伪逆
# ---------------------
def kmeans_1d(x, M, init_centers, max_iter=100, tol=1e-6, rng=rng):
    centers = np.array(init_centers, dtype=float).copy()
    for _ in range(max_iter):
        dists = np.abs(x.reshape(-1,1) - centers.reshape(1,-1))  # (N,M)
        labels = np.argmin(dists, axis=1)
        new_centers = centers.copy()
        for j in range(M):
            pts = x[labels == j]
            if len(pts) > 0:
                new_centers[j] = np.mean(pts)
            else:
                # 避免空簇：随机放回某个样本点
                new_centers[j] = x[rng.integers(0, len(x))]
        if np.max(np.abs(new_centers - centers)) < tol:
            centers = new_centers
            break
        centers = new_centers
    return np.sort(centers)

def nearest_neighbor_widths(centers, lam=1.0):
    centers = np.array(centers, dtype=float)
    M = len(centers)
    sigmas = np.empty(M, dtype=float)
    for j in range(M):
        d = np.abs(centers[j] - centers[np.arange(M) != j])
        dn = np.min(d) if d.size > 0 else 1.0
        if dn == 0.0:
            # 退化处理：用平均间距或默认1.0
            diffs = np.abs(np.diff(np.sort(centers)))
            dn = np.mean(diffs) if diffs.size > 0 else 1.0
            if dn == 0.0:
                dn = 1.0
        sigmas[j] = lam * dn / np.sqrt(2.0)
    return sigmas

def train_rbf_pinv(x_train, y_train, M=10, lam=1.0):
    init_centers = x_train[:M]
    centers = kmeans_1d(x_train, M, init_centers=init_centers)
    sigmas  = nearest_neighbor_widths(centers, lam=lam)
    Phi = gaussian_design_matrix(x_train, centers, sigmas)
    w = pinv(Phi) @ y_train
    return centers, sigmas, w

# ---------------------
# (2) 全参数梯度训练
# ---------------------
def forward(x, centers, sigmas, w):
    Phi = gaussian_design_matrix(x, centers, sigmas)
    y_hat = Phi @ w
    return y_hat, Phi

def train_rbf_gd(
    x_train, y_train,
    M=10, eta=0.001, target_mse=0.9, max_epochs=5000,
    rng=rng
):
    # 初始化
    w = rng.uniform(-0.1, 0.1, size=M)
    centers = rng.uniform(-4.0, 4.0, size=M)
    sigmas = rng.uniform(0.1, 0.3, size=M)
    history = []

    for epoch in range(max_epochs):
        y_hat, Phi = forward(x_train, centers, sigmas, w)
        err = y_train - y_hat
        N = len(x_train)

        # ---- 梯度（采用MSE = (1/N) Σ (y - ŷ)^2）
        # 对 w：∂MSE/∂w = -(2/N) Φ^T err
        grad_w = -(2.0 / N) * (Phi.T @ err)  # (M,)

        # 对 centers & sigmas 的梯度（逐元素）
        x = x_train.reshape(-1, 1)          # (N,1)
        c = centers.reshape(1, -1)          # (1,M)
        s = sigmas.reshape(1, -1)           # (1,M)
        Phi_full = np.exp(- (x - c)**2 / (2.0 * s**2))

        # dφ/dc = φ * (x - c) / s^2  =>  dŷ/dc_j = w_j * dφ_j/dc
        tmp_c = (x - c) / (s**2)            # (N,M)
        grad_c = -(2.0 / N) * np.sum( err.reshape(-1,1) * (w.reshape(1,-1) * Phi_full) * tmp_c, axis=0 )

        # dφ/dσ = φ * ((x - c)^2) / s^3  =>  dŷ/dσ_j = w_j * dφ_j/dσ
        tmp_s = ((x - c)**2) / (s**3)       # (N,M)
        grad_s = -(2.0 / N) * np.sum( err.reshape(-1,1) * (w.reshape(1,-1) * Phi_full) * tmp_s, axis=0 )

        # ---- 参数更新
        w      -= eta * grad_w
        centers-= eta * grad_c
        sigmas -= eta * grad_s
        sigmas = np.clip(sigmas, 1e-3, None)  # 保证 σ 为正

        # ---- 记录与早停
        mse_epoch = mse(y_hat, y_train)
        history.append(mse_epoch)
        if mse_epoch <= target_mse:
            break

    return centers, sigmas, w, history

# ---------------------
# 主流程
# ---------------------
if __name__ == "__main__":
    # 生成数据
    P = 100
    x_train, y_train = make_data(P=P, x_low=-4.0, x_high=4.0, noise_std=0.1, rng=rng)

    # 可视化网格
    x_grid = np.linspace(-4.0, 4.0, 1000)
    y_true = F(x_grid)

    # (1) 聚类 + 伪逆
    M = 10
    lam = 1.0
    centers_km, sigmas_km, w_km = train_rbf_pinv(x_train, y_train, M=M, lam=lam)
    Phi_train_km = gaussian_design_matrix(x_train, centers_km, sigmas_km)
    y_train_km = Phi_train_km @ w_km
    train_mse_km = mse(y_train_km, y_train)
    # 网格拟合
    y_grid_km = gaussian_design_matrix(x_grid, centers_km, sigmas_km) @ w_km

    # (2) 全参数梯度训练
    eta = 0.001
    target_mse = 0.9
    max_epochs = 5000
    centers_gd, sigmas_gd, w_gd, history = train_rbf_gd(
        x_train, y_train,
        M=M, eta=eta, target_mse=target_mse, max_epochs=max_epochs, rng=rng
    )
    y_train_gd = gaussian_design_matrix(x_train, centers_gd, sigmas_gd) @ w_gd
    train_mse_gd = mse(y_train_gd, y_train)
    y_grid_gd = gaussian_design_matrix(x_grid, centers_gd, sigmas_gd) @ w_gd

    # ---------------------
    # 可视化
    # ---------------------
    # 训练数据与真实函数
    plt.figure()
    plt.scatter(x_train, y_train, s=15, alpha=0.7, label="Train (noisy)")
    plt.plot(x_grid, y_true, label="True F(x)")
    plt.title("Training data & True function")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.show()

    # 方法(1) 拟合
    plt.figure()
    plt.plot(x_grid, y_true, label="True F(x)")
    plt.plot(x_grid, y_grid_km, label="RBF (K-means + pinv)")
    plt.title("Method (1): Clustering + Pseudoinverse Fit")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.show()

    # 方法(2) 拟合
    plt.figure()
    plt.plot(x_grid, y_true, label="True F(x)")
    plt.plot(x_grid, y_grid_gd, label="RBF (Full gradient training)")
    plt.title("Method (2): Gradient-Trained RBF Fit")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.show()

    # 梯度法训练曲线
    plt.figure()
    plt.plot(np.arange(1, len(history)+1), history)
    plt.title("Method (2): Training MSE")
    plt.xlabel("Epoch")
    plt.ylabel("MSE")
    plt.show()

    # ---------------------
    # 结果摘要
    # ---------------------
    print("=== Results Summary ===")
    print(f"(1) Clustering + pinv: train MSE = {train_mse_km:.6f}, M = {len(centers_km)}")
    print(f"    centers (first 5) = {np.round(centers_km[:5], 3)} ...")
    print(f"    sigmas  (first 5) = {np.round(sigmas_km[:5], 3)} ...\n")

    print(f"(2) Gradient training: train MSE = {train_mse_gd:.6f}, epochs = {len(history)} (target={target_mse})")
    print(f"    centers (first 5) = {np.round(np.sort(centers_gd)[:5], 3)} ...")
    print(f"    sigmas  (first 5) = {np.round(np.sort(sigmas_gd)[:5], 3)} ...")
