# -*- coding: utf-8 -*-
"""
OLS(一元线性回归) — 梯度下降动态可视化（单画布 + 开始按钮）
- 左：散点 + 当前回归直线（动态）
- 右：MSE 损失曲线（动态）
- 底部：开始按钮（不点不算）

依赖：numpy, matplotlib
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import gridspec
from matplotlib.widgets import Button
from matplotlib import rcParams

# ------- 动画节奏（已放慢） -------
UPDATES_PER_FRAME = 1   # 每帧只更新1次GD（更慢更细腻）
INTERVAL_MS = 100       # 帧间隔 100ms（更慢）

# ------- 中文显示修复 -------
rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'PingFang SC']
rcParams['axes.unicode_minus'] = False

# ------- 数据与超参数 -------
np.random.seed(42)
X = 2 * np.random.rand(100, 1)
y = 4 + 3 * X + np.random.randn(100, 1)

learning_rate = 0.1
iterations = 50  # 最大迭代步数

# 初值
beta_0 = 0.0
beta_1 = 0.0

# 记录历史（这里只需要损失）
mse_hist = []

# 为画直线更平滑：按 x 排序一次
order = np.argsort(X[:, 0])
X_sorted = X[order]
y_sorted = y[order]

# ------- 画布布局（两块） -------
fig = plt.figure(figsize=(12, 7.2))
gs = gridspec.GridSpec(1, 2, width_ratios=[1.35, 1.0])

# 左：散点 + 拟合线（动态）
ax_data = fig.add_subplot(gs[0, 0])
ax_data.scatter(X, y, s=18, color='tab:blue', label='数据点', alpha=0.85)
line_fit, = ax_data.plot(X_sorted, beta_0 + beta_1 * X_sorted, color='tab:red', lw=2.0, label='当前拟合线')
ax_data.set_title('动态拟合：散点与当前回归直线')
ax_data.set_xlabel('X'); ax_data.set_ylabel('y')

# ↓↓↓ 图例下移，避免与其他元素重合 ↓↓↓
ax_data.legend(loc='upper left',
               bbox_to_anchor=(0.02, 0.78),  # 左侧 2% 、纵向 78% 处锚点
               borderaxespad=0.8,
               framealpha=0.9,
               labelspacing=0.4)

# 固定坐标范围（避免抖动）
x_min, x_max = X.min(), X.max()
y_min, y_max = y.min(), y.max()
pad_x = 0.05 * (x_max - x_min)
pad_y = 0.10 * (y_max - y_min)
ax_data.set_xlim(x_min - pad_x, x_max + pad_x)
ax_data.set_ylim(y_min - pad_y, y_max + pad_y)

txt_title = ax_data.text(0.02, 0.98, '', transform=ax_data.transAxes, va='top', ha='left',
                         fontsize=11, bbox=dict(boxstyle='round,pad=0.3', fc='white', alpha=0.7))

# 右：MSE 损失曲线（动态）
ax_loss = fig.add_subplot(gs[0, 1])
ax_loss.set_title('损失下降（MSE）')
ax_loss.set_xlabel('迭代步')
ax_loss.set_ylabel('MSE')
ax_loss.grid(True, alpha=0.35)
line_loss, = ax_loss.plot([], [], color='tab:green', lw=1.8)
ax_loss.set_xlim(0, iterations)

# 按钮预留空间
fig.tight_layout(rect=[0, 0.09, 1, 1])

# ------- 梯度下降一步 -------
step_state = {'k': 0, 'running': False}

def gd_step():
    """执行一次梯度下降更新，返回是否仍需继续"""
    global beta_0, beta_1
    # 预测
    y_pred = beta_0 + beta_1 * X
    # 误差与损失
    err = y_pred - y
    mse = float(np.mean(err**2))
    # 梯度
    N = len(X)
    g0 = 2.0 * np.sum(err) / N
    g1 = 2.0 * np.sum(err * X) / N
    # 参数更新
    beta_0 -= learning_rate * g0
    beta_1 -= learning_rate * g1
    # 记录
    mse_hist.append(mse)

    step_state['k'] += 1
    return step_state['k'] < iterations

# ------- 动画更新（计时器驱动） -------
timer = fig.canvas.new_timer(interval=INTERVAL_MS)

def update_frame(*args):
    if not step_state['running']:
        return

    # 每帧执行若干步（已设置为1步）
    cont = True
    for _ in range(UPDATES_PER_FRAME):
        cont = gd_step()
        if not cont:
            break

    # 更新左侧拟合线
    y_line = beta_0 + beta_1 * X_sorted
    line_fit.set_data(X_sorted, y_line)

    # 标题信息
    cur_mse = mse_hist[-1] if mse_hist else float('nan')
    txt_title.set_text(f'迭代 {step_state["k"]}/{iterations}  |  β0={beta_0:.3f}  β1={beta_1:.3f}  |  MSE={cur_mse:.4f}')

    # 更新右侧损失曲线
    x_loss = np.arange(1, len(mse_hist) + 1, dtype=int)
    line_loss.set_data(x_loss, mse_hist)
    if len(mse_hist) >= 1:
        ymin, ymax = min(mse_hist), max(mse_hist)
        if ymax - ymin < 1e-12:
            ax_loss.set_ylim(ymin - 1.0, ymax + 1.0)
        else:
            pad = 0.08 * (ymax - ymin)
            ax_loss.set_ylim(ymin - pad, ymax + pad)

    fig.canvas.draw_idle()

    # 结束条件
    if not cont:
        timer.stop()
        btn_start.label.set_text('已完成')
        btn_start.ax.set_facecolor('#cccccc')
        btn_start.hovercolor = '#cccccc'
        btn_start.eventson = False
        fig.canvas.draw_idle()

timer.add_callback(update_frame)
timer.start()  # 定时器开启，但 running=False，不会推进

# ------- 开始按钮 -------
btn_ax = fig.add_axes([0.80, 0.015, 0.16, 0.06])
btn_start = Button(btn_ax, '开始计算', color='#efefef', hovercolor='#dddddd')

def on_start(event):
    if not step_state['running']:
        step_state['running'] = True
        btn_start.label.set_text('运行中...')
        btn_start.ax.set_facecolor('#cccccc')
        btn_start.hovercolor = '#cccccc'
        btn_start.eventson = False  # 禁止重复点击
        fig.canvas.draw_idle()

btn_start.on_clicked(on_start)

plt.show()
