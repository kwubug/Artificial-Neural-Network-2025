import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation  # For dynamic display

# 1. Generate sample data (simulate nonlinear function)
np.random.seed(42)
x = np.linspace(-3, 3, 50)  # Input: 50 uniformly distributed points
y_true = np.sin(x) + 0.5 * x  # True function: sine curve + linear term
noise = np.random.normal(0, 0.2, len(x))  # Gaussian noise
y = y_true + noise  # Target output with noise

# 2. RBF network parameter settings
M_list = [3, 5, 8, 12]  # Different numbers of hidden nodes (show OLS adaptation to complexity)
sigma = 1.0  # Spread constant (fixed, controls basis function width)


# 3. Define radial basis function (Gaussian function)
def rbf(x, c, sigma):
    """Calculate single radial basis function value"""
    return np.exp(-(x - c) **2 / (2 * sigma** 2))


# 4. OLS solving function (calculate weights and bias)
def ols_train(x, y, centers, sigma):
    """
    x: Input samples
    y: Target output
    centers: Hidden node centers
    sigma: Spread constant
    Returns: Weights w and bias b
    """
    M = len(centers)
    # Construct basis function matrix Φ (N×M)
    Phi = np.zeros((len(x), M))
    for m in range(M):
        Phi[:, m] = rbf(x, centers[m], sigma)
    # Construct augmented matrix (add all-1 column for bias b)
    Phi_aug = np.hstack((Phi, np.ones((len(x), 1))))  # N×(M+1)
    # OLS solution: w_aug = (Φ^TΦ)^(-1)Φ^T y
    w_aug = np.linalg.inv(Phi_aug.T @ Phi_aug) @ Phi_aug.T @ y
    w = w_aug[:-1]  # Weights
    b = w_aug[-1]  # Bias
    return w, b, Phi


# 5. Visualize OLS learning effect (static multi-subplot comparison)
plt.figure(figsize=(12, 8))
for i, M in enumerate(M_list, 1):
    # Generate hidden node centers (uniformly distributed in input range)
    centers = np.linspace(min(x), max(x), M)
    # OLS training
    w, b, Phi = ols_train(x, y, centers, sigma)
    # Prediction
    y_pred = Phi @ w + b
    # Calculate mean squared error
    mse = np.mean((y_pred - y) **2)

    # Plotting
    plt.subplot(2, 2, i)
    plt.plot(x, y_true, 'b--', label='True Function')
    plt.scatter(x, y, c='orange', s=30, alpha=0.6, label='Noisy Samples')
    plt.plot(x, y_pred, 'r-', linewidth=2, label='OLS Fit')
    plt.scatter(centers, np.zeros_like(centers), c='green', marker='*', s=80, label='Hidden Node Centers')
    plt.title(f'Number of Hidden Nodes M={M}, MSE={mse:.4f}')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid(alpha=0.3)

plt.tight_layout()
plt.show()

# 6. Dynamically show OLS fitting process with increasing hidden nodes
fig, ax = plt.subplots(figsize=(8, 5))
line_true, = ax.plot(x, y_true, 'b--', label='True Function')
scatter_data = ax.scatter(x, y, c='orange', s=30, alpha=0.6, label='Noisy Samples')
line_pred, = ax.plot(x, np.zeros_like(x), 'r-', linewidth=2, label='OLS Fit')
scatter_centers, = ax.plot([], [], 'g*', markersize=10, label='Hidden Node Centers')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('OLS Fitting Process (Increasing Hidden Nodes)')
ax.legend()
ax.grid(alpha=0.3)
ax.set_ylim(-2, 3)  # Fix y-axis range for better observation


def update(M):
    """Animation update function: update fitting curve with increasing M"""
    centers = np.linspace(min(x), max(x), M)
    w, b, Phi = ols_train(x, y, centers, sigma)
    y_pred = Phi @ w + b
    line_pred.set_ydata(y_pred)
    scatter_centers.set_data(centers, np.zeros_like(centers))
    ax.set_title(f'Number of Hidden Nodes M={M}')
    return line_pred, scatter_centers


# Generate animation (M increases from 2 to 15)
ani = FuncAnimation(fig, update, frames=range(2, 16), interval=500, blit=True)
plt.show()