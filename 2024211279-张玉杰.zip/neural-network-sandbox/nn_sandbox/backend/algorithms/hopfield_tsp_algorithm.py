import numpy as np
import time
from .base_algorithm import TraningAlgorithm


class HopfieldTspAlgorithm(TraningAlgorithm):
    """
    Continuous Hopfield network for TSP (A, B, C penalty terms).
    Emits live updates for cities, path, energy, and V heatmap.
    """
    def __init__(self, n_cities=8, seed=42, A=50.0, B=50.0, C=0.1,
                 lam=1.0, dt=0.001, max_iter=5000, update_freq=50,
                 ui_refresh_interval=0.0):
        super().__init__(dataset=[], total_epoches=1)
        self.n = int(n_cities)
        self.seed = int(seed)
        self.A = float(A)
        self.B = float(B)
        self.C = float(C)
        self.lam = float(lam)
        self.dt = float(dt)
        self.max_iter = int(max_iter)
        self.update_freq = int(update_freq)
        self.ui_refresh_interval = float(ui_refresh_interval)

        self.cities = None
        self.D = None
        self.U = None
        self.V = None

        self.current_iter = 0
        self.current_energy = 0.0
        self.energy_history = []
        self.has_finished = True

    def _generate_cities(self):
        rng = np.random.default_rng(self.seed)
        return rng.uniform(0, 100, (self.n, 2))

    def _distance_matrix(self, cities):
        N = cities.shape[0]
        D = np.zeros((N, N))
        for x in range(N):
            for y in range(N):
                if x != y:
                    dx = cities[x, 0] - cities[y, 0]
                    dy = cities[x, 1] - cities[y, 1]
                    D[x, y] = (dx * dx + dy * dy) ** 0.5
        return D

    def _sigmoid(self, u):
        return 1.0 / (1.0 + np.exp(-u / self.lam))

    def _energy(self, V):
        # E_A
        E_A = (self.A / 2.0) * np.sum((np.sum(V, axis=1) - 1.0) ** 2)
        # E_B
        E_B = (self.B / 2.0) * np.sum((np.sum(V, axis=0) - 1.0) ** 2)
        # E_C
        n = self.n
        E_C = 0.0
        for x in range(n):
            for y in range(n):
                if x != y:
                    for i in range(n):
                        i_plus_1 = (i + 1) % n
                        E_C += self.D[x, y] * V[x, i] * V[y, i_plus_1]
        E_C = (self.C / 2.0) * E_C
        return E_A + E_B + E_C

    def _decode_path(self, V):
        n = self.n
        path_order = np.argmax(V, axis=1)  # city x at position i
        path_sequence = np.argsort(path_order)
        city_indices = list(path_sequence)
        city_indices.append(city_indices[0])
        x_coords = self.cities[city_indices, 0]
        y_coords = self.cities[city_indices, 1]
        total_distance = 0.0
        for k in range(n):
            total_distance += self.D[city_indices[k], city_indices[k + 1]]
        return x_coords, y_coords, total_distance, city_indices

    def _update_once(self):
        n = self.n
        V = self.V
        sum_V_row = np.sum(V, axis=1)
        sum_V_col = np.sum(V, axis=0)
        dU_dt = np.zeros_like(self.U)
        for x in range(n):
            for i in range(n):
                dE_A = self.A * (sum_V_row[x] - 1.0)
                dE_B = self.B * (sum_V_col[i] - 1.0)
                dE_C = 0.0
                for y in range(n):
                    if x != y:
                        i_plus_1 = (i + 1) % n
                        i_minus_1 = (i - 1 + n) % n
                        dE_C += self.D[x, y] * (V[y, i_plus_1] + V[y, i_minus_1])
                dE_C = self.C * dE_C
                # Dissipation term
                dissipation = self.U[x, i]
                dU_dt[x, i] = - (dE_A + dE_B + dE_C) - dissipation
        self.U = self.U + self.dt * dU_dt
        self.V = self._sigmoid(self.U)

    def run(self):
        self.has_finished = False
        # init data
        self.cities = self._generate_cities()
        self.D = self._distance_matrix(self.cities)
        self.U = np.random.uniform(-0.1, 0.1, (self.n, self.n))
        self.V = self._sigmoid(self.U)
        self.energy_history = []
        self.current_iter = 0
        # notify initial
        if hasattr(self, 'notify'):
            self.notify('cities', self.cities.tolist())
            self.notify('n', self.n)
            self.notify('current_iter', self.current_iter)
        # iterate
        for k in range(self.max_iter):
            if self._should_stop:
                break
            E = self._energy(self.V)
            self.energy_history.append(float(E))
            self.current_energy = float(E)
            self.current_iter = k
            self._update_once()
            if k % self.update_freq == 0 or k == self.max_iter - 1:
                x_path, y_path, total_distance, seq = self._decode_path(self.V)
                if hasattr(self, 'notify'):
                    self.notify('current_iter', self.current_iter)
                    self.notify('current_energy', self.current_energy)
                    self.notify('V', self.V.tolist())
                    self.notify('x_path', x_path.tolist())
                    self.notify('y_path', y_path.tolist())
                    self.notify('total_distance', float(total_distance))
                if self.ui_refresh_interval:
                    time.sleep(self.ui_refresh_interval)
            # simple convergence check
            if k > self.update_freq:
                if abs(self.energy_history[-1] - self.energy_history[-self.update_freq]) < 1e-6:
                    break
        # final
        x_path, y_path, total_distance, seq = self._decode_path(self.V)
        if hasattr(self, 'notify'):
            self.notify('current_iter', self.current_iter)
            self.notify('current_energy', self.current_energy)
            self.notify('V', self.V.tolist())
            self.notify('x_path', x_path.tolist())
            self.notify('y_path', y_path.tolist())
            self.notify('total_distance', float(total_distance))
            self.notify('has_finished', True)
        self.has_finished = True


