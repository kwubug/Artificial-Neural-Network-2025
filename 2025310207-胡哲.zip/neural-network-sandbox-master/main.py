import os
import sys

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets

from nn_sandbox.bridges import PerceptronBridge, MlpBridge, RbfnBridge, SomBridge, BPBridge
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    # 设置Qt插件路径
    import PyQt5

    pyqt5_path = os.path.dirname(PyQt5.__file__)

    # 尝试多个可能的插件路径
    possible_plugin_paths = [
        os.path.join(pyqt5_path, 'Qt5', 'plugins'),
        os.path.join(pyqt5_path, 'plugins'),
        os.path.join(os.path.dirname(pyqt5_path), 'PyQt5', 'Qt5', 'plugins'),
        os.path.join(os.path.dirname(pyqt5_path), 'PyQt5', 'plugins')
    ]

    # 查找存在的插件路径
    for plugin_path in possible_plugin_paths:
        if os.path.exists(plugin_path):
            os.environ['QT_PLUGIN_PATH'] = plugin_path
            print(f"设置Qt插件路径: {plugin_path}")
            break
    else:
        # 如果找不到插件路径，尝试使用conda环境中的Qt
        conda_qt_path = os.path.join(os.path.dirname(pyqt5_path), '..', 'Library', 'plugins')
        if os.path.exists(conda_qt_path):
            os.environ['QT_PLUGIN_PATH'] = conda_qt_path
            print(f"使用conda Qt插件路径: {conda_qt_path}")
        else:
            print("警告: 未找到Qt插件路径，应用程序可能无法正常启动")

    # 获取当前脚本所在目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    qml_path = os.path.join(current_dir, 'nn_sandbox', 'frontend', 'main.qml')

    print(f"尝试加载QML文件: {qml_path}")
    print(f"QML文件是否存在: {os.path.exists(qml_path)}")

    # XXX: Why I Have To Use QApplication instead of QGuiApplication? It seams
    # QGuiApplication cannot load QML Chart libs!
    app = PyQt5.QtWidgets.QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'bpBridge': BPBridge()
    }
    for name in bridges:
        bridges[name].dataset_dict = nn_sandbox.backend.utils.read_data()
        engine.rootContext().setContextProperty(name, bridges[name])


    # 添加QML加载错误处理
    def handle_object_created(obj, obj_url):
        if obj is None:
            print(f"无法创建QML对象: {obj_url}")
            sys.exit(-1)
        else:
            print(f"成功加载QML对象: {obj_url}")


    engine.objectCreated.connect(handle_object_created)

    engine.load(qml_path)

    if not engine.rootObjects():
        print("错误: 没有根对象被创建")
        # 打印更详细的错误信息
        for error in engine.errors():
            print(f"QML错误: {error.toString()}")
        sys.exit(-1)

    sys.exit(app.exec_())