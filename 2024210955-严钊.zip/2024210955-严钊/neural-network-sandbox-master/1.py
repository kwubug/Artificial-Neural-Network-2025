"""
五口井 + Petrel 兼容版 SEG-Y 生成脚本
---------------------------------
功能：
- 从 .mat 地震文件生成 SEG-Y 文件（带 CDP_X, CDP_Y, INLINE, CROSSLINE）
- 自动写入地震道头信息（符合 Petrel 要求）
- 从五个位置生成对应的井 LAS 文件（含 VP 与 RHO）
- 输出 wells_location.txt 以供 Petrel 井定位

作者：严钊专用版
"""

import os
import numpy as np
import scipy.io as sio
import segyio
import lasio

# ---------------- 参数 ----------------
vp_dir = r"F:\严钊软件\MatLab_project\4\VP_2_full_depth"
seis_dir = r"F:\严钊软件\MatLab_project\4\record_vp_2_rc"
out_dir = r"E:\wenjian\for_HRS_inversion"

os.makedirs(out_dir, exist_ok=True)
os.makedirs(os.path.join(out_dir, 'wells'), exist_ok=True)

n_traces = 201
dt = 0.002          # s
t0 = 0.2
nt = 249
dz = 0.1            # m
dx = 5.0            # m
y_fixed = 0         # 固定剖面在 Y=0
five_indices = np.linspace(0, n_traces - 1, 5, dtype=int).tolist()  # 五口井索引
print("Selected wells (0-based):", five_indices)

# ---------------- 读取地震数据 ----------------
seis_matrix = np.zeros((nt, n_traces), dtype='float32')
for i in range(1, n_traces + 1):
    fname = os.path.join(seis_dir, f"seismic_data_cut_{i}.mat")
    if not os.path.exists(fname):
        raise FileNotFoundError(f"Seismic file not found: {fname}")
    m = sio.loadmat(fname)
    key = 'Seismo' if 'Seismo' in m else 'Ssismo'
    trace = m[key].squeeze()
    if trace.size != nt:
        raise ValueError(f"Trace length mismatch in {fname}")
    seis_matrix[:, i - 1] = trace
print("Loaded seismic matrix:", seis_matrix.shape)

# ---------------- 写 SEG-Y ----------------
segy_path = os.path.join(out_dir, "seismic_synthetic_meters_petrel.sgy")
spec = segyio.spec()
spec.samples = list(t0 + np.arange(nt) * dt)
spec.ilines = list(range(1, n_traces + 1))
spec.xlines = [1]
spec.tracecount = n_traces
spec.format = 5  # IEEE 32-bit float

def safe_set(hdr, field, val):
    """兼容不同版本 segyio 的道头写入"""
    try:
        if hasattr(segyio.TraceField, field):
            hdr[getattr(segyio.TraceField, field)] = int(val)
            return True
    except Exception:
        return False
    return False

with segyio.create(segy_path, spec) as f:
    f.text[0] = segyio.tools.create_text_header([
        "Synthetic seismic (FD modeling)",
        "Distance spacing = 5m, dt = 2ms, Petrel-compatible",
        "Contains CDP_X/Y, INLINE, CROSSLINE info"
    ])
    f.bin[segyio.BinField.Traces] = n_traces
    f.bin[segyio.BinField.Samples] = nt
    f.bin[segyio.BinField.Interval] = int(dt * 1e6)
    f.bin[segyio.BinField.Format] = 5
    f.bin[segyio.BinField.SortingCode] = 1
    f.bin[segyio.BinField.MeasurementSystem] = 1  # 1=m

    for i in range(n_traces):
        f.trace[i] = seis_matrix[:, i]
        x_pos = i * dx
        hdr = f.header[i]

        # 常见字段
        safe_set(hdr, 'TRACE_SEQUENCE_LINE', i + 1)
        safe_set(hdr, 'CDP', i + 1)
        safe_set(hdr, 'INLINE_3D', 1000)  # 固定 inline 编号
        safe_set(hdr, 'CROSSLINE_3D', i + 1)

        # 坐标
        safe_set(hdr, 'CDP_X', x_pos)
        safe_set(hdr, 'CDP_Y', y_fixed)
        safe_set(hdr, 'SOURCE_X', x_pos)
        safe_set(hdr, 'SOURCE_Y', y_fixed)
        safe_set(hdr, 'GROUP_X', x_pos)
        safe_set(hdr, 'GROUP_Y', y_fixed)
        safe_set(hdr, 'OFFSET', 0)

print("Wrote SEG-Y:", segy_path)

# ---------------- 写五口井 LAS ----------------
wells_loc_lines = []
for wi, idx in enumerate(five_indices, start=1):
    trace_idx = idx + 1
    vp_fname = os.path.join(vp_dir, f"velocity_depth_{trace_idx}.mat")
    if not os.path.exists(vp_fname):
        raise FileNotFoundError(f"Velocity file not found: {vp_fname}")
    m = sio.loadmat(vp_fname)
    vp = m['velocity_depth'].squeeze().astype('float32')
    nz = vp.size
    depth = np.arange(nz) * dz
    rho = 0.31 * np.power(vp, 0.25)

    las = lasio.LASFile()
    well_name = f"well_{wi:03d}"
    las.well['WELL'] = lasio.HeaderItem('WELL', well_name, '', 'Well name')
    las.well['STRT'] = lasio.HeaderItem('STRT', float(depth[0]), 'm', '')
    las.well['STOP'] = lasio.HeaderItem('STOP', float(depth[-1]), 'm', '')
    las.well['STEP'] = lasio.HeaderItem('STEP', float(dz), 'm', '')
    las.append_curve("DEPT", depth, unit="m", descr="Depth")
    las.append_curve("VP", vp, unit="m/s", descr="Velocity")
    las.append_curve("RHO", rho, unit="g/cc", descr="Density")

    las_path = os.path.join(out_dir, 'wells', f"{well_name}.las")
    las.write(las_path, version=2.0)

    x_coord = idx * dx
    wells_loc_lines.append((well_name, x_coord, y_fixed, trace_idx))
    print(f"Wrote LAS: {las_path}")

# 井位记录
loc_path = os.path.join(out_dir, "wells_location.txt")
with open(loc_path, 'w', encoding='utf-8') as f:
    f.write("UWI\tWellName\tX\tY\tCDP\n")
    for name, x, y, cdp in wells_loc_lines:
        f.write(f"{name}\t{name}\t{int(x)}\t{int(y)}\t{cdp}\n")
print("Wrote wells location:", loc_path)

# ---------------- 打印头验证 ----------------
print("\n--- 前 5 道头部信息 ---")
with segyio.open(segy_path, "r", ignore_geometry=True) as f:
    for i in range(5):
        hdr = f.header[i]
        print(f"\nTrace {i+1}: CDP={hdr.get(segyio.TraceField.CDP, 'N/A')}, "
              f"CDP_X={hdr.get(segyio.TraceField.CDP_X, 'N/A')}, "
              f"INLINE={hdr.get(segyio.TraceField.INLINE_3D, 'N/A')}, "
              f"CROSSLINE={hdr.get(segyio.TraceField.CROSSLINE_3D, 'N/A')}")
print("\nAll outputs in:", out_dir)
