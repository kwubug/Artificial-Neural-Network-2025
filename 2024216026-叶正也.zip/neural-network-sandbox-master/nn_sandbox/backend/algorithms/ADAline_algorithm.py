import collections
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid

class ADAlineAlgorithm(PredictiveAlgorithm):
    """ Adaptive Linear Neuron (Adaline) with Least Mean Squares (LMS) training. """

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.01, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight

        # Default network shape for Adaline is a simple single layer with one output neuron
        self.network_shape = network_shape if network_shape else (5,)

        # For momentum (to store weight changes)
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _initialize_neurons(self):
        """ Build the neuron network with a simple linear activation function (no sigmoid). """
        self._neurons = tuple((Perceptron(None),) * size  # No activation function for ADAline
                              for size in list(self.network_shape) + [1])

    def _iterate(self):
        """ Perform one iteration (epoch) of training. """
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
        self._adjust_synaptic_weights(deltas)

    def _feed_forward(self, data):
        """ Feed forward through the network (linear output). """
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron (LMS error). """
        deltas = {}
        error = expect - result
        deltas[self._neurons[-1][0]] = error  # No sigmoid, direct error propagation

        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                deltas[neuron] = sum(deltas[n] * n.synaptic_weight[neuron_idx] for n in self._neurons[layer_idx + 1])
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        """ Adjust synaptic weights based on the deltas. """
        for neuron in deltas:
            # Update the weights with momentum and the delta
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    def _correct_rate(self, dataset):
        """ Calculate the correct rate of the network on the dataset. """
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            expect = data[-1]
            if abs(result - expect) < 0.1:  # 调整为一个更合理的容差
                correct_count += 1
        return correct_count / len(dataset)

    def _normalize(self, value):
        """ Normalize the expected output for Adaline. """
        return value  # No actual normalization needed for Adaline

def get_layer_results(layer, data):
    """ Get the output of a layer of neurons. """
    for neuron in layer:
        neuron.data = data
    return np.fromiter((np.dot(neuron.synaptic_weight, neuron.data) for neuron in layer), dtype=float)
