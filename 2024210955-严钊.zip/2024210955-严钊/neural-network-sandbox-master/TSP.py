import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import random
from math import sqrt, exp


class AnimatedTSPSolver:
    def __init__(self, cities, temperature=1000, cooling_rate=0.995):
        self.cities = cities
        self.n_cities = len(cities)
        self.temperature = temperature
        self.cooling_rate = cooling_rate
        self.initial_temperature = temperature

        # Animation data storage
        self.tour_history = []
        self.distance_history = []
        self.temperature_history = []
        self.accepted_history = []

    def distance(self, city1, city2):
        """Calculate Euclidean distance between two cities"""
        return sqrt((city1[0] - city2[0]) ** 2 + (city1[1] - city2[1]) ** 2)

    def total_distance(self, tour):
        """Calculate total tour distance"""
        total = 0
        for i in range(self.n_cities):
            total += self.distance(self.cities[tour[i]], self.cities[tour[(i + 1) % self.n_cities]])
        return total

    def initial_solution(self):
        """Generate initial solution"""
        return list(range(self.n_cities))

    def generate_neighbor(self, tour):
        """Generate neighbor solution: 2-opt swap"""
        new_tour = tour.copy()
        i, j = random.sample(range(self.n_cities), 2)
        i, j = min(i, j), max(i, j)
        new_tour[i:j + 1] = reversed(new_tour[i:j + 1])
        return new_tour

    def simulated_annealing_animated(self, max_iterations=2000):
        """Simulated annealing algorithm for animation"""
        current_tour = self.initial_solution()
        random.shuffle(current_tour)
        current_distance = self.total_distance(current_tour)

        best_tour = current_tour.copy()
        best_distance = current_distance

        # Record initial state
        self.tour_history.append(current_tour.copy())
        self.distance_history.append(current_distance)
        self.temperature_history.append(self.temperature)
        self.accepted_history.append(True)

        for iteration in range(max_iterations):
            # Generate neighbor solution
            new_tour = self.generate_neighbor(current_tour)
            new_distance = self.total_distance(new_tour)

            # Calculate energy difference
            delta_energy = new_distance - current_distance

            # Acceptance criterion
            accepted = False
            if delta_energy < 0:
                accepted = True
                current_tour = new_tour
                current_distance = new_distance
            elif random.random() < exp(-delta_energy / self.temperature):
                accepted = True
                current_tour = new_tour
                current_distance = new_distance

            # Update best solution
            if current_distance < best_distance:
                best_tour = current_tour.copy()
                best_distance = current_distance

            # Record history
            self.tour_history.append(current_tour.copy())
            self.distance_history.append(current_distance)
            self.temperature_history.append(self.temperature)
            self.accepted_history.append(accepted)

            # Cooling
            self.temperature *= self.cooling_rate

            # Early termination
            if self.temperature < 1e-10:
                break

        return best_tour, best_distance


def create_tsp_animation():
    """Create TSP problem animation"""
    # Create random cities
    np.random.seed(42)  # For reproducibility
    n_cities = 12
    cities = [(np.random.uniform(0, 100), np.random.uniform(0, 100)) for _ in range(n_cities)]

    # Solve TSP problem
    tsp_solver = AnimatedTSPSolver(cities, temperature=1000, cooling_rate=0.995)
    best_tour, best_distance = tsp_solver.simulated_annealing_animated(max_iterations=1000)

    # Create animation
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 6))

    # Set axis limits
    cities_array = np.array(cities)
    x_min, x_max = cities_array[:, 0].min(), cities_array[:, 0].max()
    y_min, y_max = cities_array[:, 1].min(), cities_array[:, 1].max()
    x_margin = (x_max - x_min) * 0.1
    y_margin = (y_max - y_min) * 0.1

    # Initialize plots
    # 1. Tour plot
    scatter = ax1.scatter([], [], c='red', s=100, zorder=5)
    path_line, = ax1.plot([], [], 'b-', linewidth=2, alpha=0.7, zorder=4)
    current_point, = ax1.plot([], [], 'go', markersize=10, zorder=6)

    ax1.set_xlim(x_min - x_margin, x_max + x_margin)
    ax1.set_ylim(y_min - y_margin, y_max + y_margin)
    ax1.set_xlabel('X Coordinate')
    ax1.set_ylabel('Y Coordinate')
    ax1.set_title('TSP Route Optimization')
    ax1.grid(True, alpha=0.3)

    # Add city labels
    for i, (x, y) in enumerate(cities):
        ax1.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points', fontsize=8)

    # 2. Distance convergence curve
    distance_line, = ax2.plot([], [], 'b-', alpha=0.7, label='Current Distance')
    best_distance_line, = ax2.plot([], [], 'r-', alpha=0.7, label='Best Distance')
    ax2.set_xlim(0, len(tsp_solver.distance_history))
    ax2.set_ylim(min(tsp_solver.distance_history) * 0.9, max(tsp_solver.distance_history) * 1.1)
    ax2.set_xlabel('Iteration')
    ax2.set_ylabel('Tour Distance')
    ax2.set_title('Distance Convergence')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    # 3. Temperature and acceptance rate
    temp_line, = ax3.plot([], [], 'r-', alpha=0.7, label='Temperature')
    ax3_twin = ax3.twinx()
    accept_rate_line, = ax3_twin.plot([], [], 'g-', alpha=0.7, label='Acceptance Rate')

    ax3.set_xlim(0, len(tsp_solver.temperature_history))
    ax3.set_ylim(0, tsp_solver.initial_temperature * 1.1)
    ax3.set_xlabel('Iteration')
    ax3.set_ylabel('Temperature', color='r')
    ax3_twin.set_ylabel('Acceptance Rate', color='g')
    ax3.set_title('Temperature and Acceptance Rate')
    ax3.legend(loc='upper left')
    ax3_twin.legend(loc='upper right')
    ax3.grid(True, alpha=0.3)

    # Information text
    info_text = fig.text(0.5, 0.02, '', ha='center', fontsize=12,
                         bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))

    def animate(frame):
        if frame >= len(tsp_solver.tour_history):
            frame = len(tsp_solver.tour_history) - 1

        current_tour = tsp_solver.tour_history[frame]
        current_distance = tsp_solver.distance_history[frame]

        # Update tour plot
        tour_cities = [cities[i] for i in current_tour] + [cities[current_tour[0]]]
        tour_array = np.array(tour_cities)

        scatter.set_offsets(cities_array)
        path_line.set_data(tour_array[:, 0], tour_array[:, 1])

        # Highlight current changing edge (if any)
        if frame > 0 and frame < len(tsp_solver.tour_history):
            current_point.set_data([], [])

        # Update distance curve
        x_data = list(range(frame + 1))
        distance_line.set_data(x_data, tsp_solver.distance_history[:frame + 1])

        # Update best distance curve
        best_distances = [min(tsp_solver.distance_history[:i + 1]) for i in range(frame + 1)]
        best_distance_line.set_data(x_data, best_distances)

        # Update temperature curve
        temp_line.set_data(x_data, tsp_solver.temperature_history[:frame + 1])

        # Update acceptance rate curve (sliding window)
        window_size = min(50, frame + 1)
        if window_size > 0:
            recent_accepts = tsp_solver.accepted_history[max(0, frame - window_size + 1):frame + 1]
            accept_rate = sum(recent_accepts) / len(recent_accepts) if len(recent_accepts) > 0 else 0
            accept_rate_line.set_data(x_data,
                                      [sum(tsp_solver.accepted_history[max(0, i - 50 + 1):i + 1]) /
                                       min(50, i + 1) for i in range(frame + 1)])

        # Update information text
        info_text.set_text(f'Iteration: {frame}/{len(tsp_solver.tour_history) - 1} | '
                           f'Current Distance: {current_distance:.2f} | '
                           f'Best Distance: {min(tsp_solver.distance_history[:frame + 1]):.2f} | '
                           f'Temperature: {tsp_solver.temperature_history[frame]:.2f} | '
                           f'Acceptance Rate: {accept_rate:.2%}')

        return [scatter, path_line, current_point, distance_line, best_distance_line,
                temp_line, accept_rate_line, info_text]

    # Create animation
    anim = animation.FuncAnimation(
        fig, animate, frames=len(tsp_solver.tour_history),
        interval=100, blit=False, repeat=True
    )

    plt.tight_layout()
    plt.show()

    return anim


# Run TSP animation
print("Creating TSP Animation...")
tsp_anim = create_tsp_animation()

# Optional: Save animations
# hopfield_anim.save('hopfield_animation.gif', writer='pillow', fps=2)
# tsp_anim.save('tsp_animation.gif', writer='pillow', fps=10)

print("Animations created successfully!")