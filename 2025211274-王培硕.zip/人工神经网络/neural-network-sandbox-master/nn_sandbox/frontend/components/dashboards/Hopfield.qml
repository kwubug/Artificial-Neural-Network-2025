import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'Hopfield'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(hopfieldBridge.dataset_dict)
                enabled: hopfieldBridge.has_finished
                onActivated: () => {
                    hopfieldBridge.current_dataset_name = currentText
                    dataChart.updateDataset(hopfieldBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    hopfieldBridge.current_dataset_name = currentText
                    dataChart.updateDataset(hopfieldBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: 'Total Training Epoches'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 10
                    to: 999999
                    onValueChanged: hopfieldBridge.total_epoches = value
                    Component.onCompleted: hopfieldBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Initial Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0.8 * 100
                    onValueChanged: hopfieldBridge.initial_learning_rate = value / 100
                    Component.onCompleted: hopfieldBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Test-Train Ratio'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: hopfieldBridge.test_ratio = value / 100
                    Component.onCompleted: hopfieldBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: hopfieldBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: hopfieldBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
                CheckBox {
                    id: asynchronousUpdateCheckBox
                    enabled: hopfieldBridge.has_finished
                    text: 'Asynchronous Update'
                    checked: true
                    onCheckedChanged: hopfieldBridge.asynchronous_update = checked
                    Component.onCompleted: hopfieldBridge.asynchronous_update = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: 'Max Iterations'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 1000
                    to: 999999
                    onValueChanged: hopfieldBridge.max_iterations = value
                    Component.onCompleted: hopfieldBridge.max_iterations = value
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: hopfieldBridge.has_finished
                    startButton.onClicked: () => {
                        hopfieldBridge.start_hopfield_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(hopfieldBridge.training_dataset)
                        dataChart.updateTestingDataset(hopfieldBridge.testing_dataset)
                        rateChart.reset()
                    }
                    stopButton.enabled: !hopfieldBridge.has_finished
                    stopButton.onClicked: hopfieldBridge.stop_hopfield_algorithm()
                    progressBar.value: hopfieldBridge.current_iterations / (totalEpoches.value * Math.max(1, hopfieldBridge.training_dataset.length))
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Epoch'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const epoch = Math.floor(hopfieldBridge.current_iterations / Math.max(1, hopfieldBridge.training_dataset.length)) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: 'Current Training Iteration'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        rateChart.bestCorrectRate.append(
                            hopfieldBridge.current_iterations + 1,
                            hopfieldBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            hopfieldBridge.current_iterations + 1,
                            hopfieldBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            hopfieldBridge.current_iterations + 1,
                            hopfieldBridge.test_correct_rate
                        )
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.current_learning_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Network Energy'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.current_energy !== undefined ? hopfieldBridge.current_energy.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Best Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.best_correct_rate !== undefined ? hopfieldBridge.best_correct_rate.toFixed(toFixedValue) : '0.00'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.current_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Testing Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: hopfieldBridge.test_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
        RateChart {
            id: rateChart
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
    }
}