from PyQt5.QtCore import pyqtSlot
from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.bm_algorithm import ObservableBmAlgorithm


class BmBridge(Bridge):
    """
    Boltzmann Machine的Bridge类
    连接BM算法和QML界面
    """
    
    # 定义Bridge属性
    current_iteration = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    statistics = BridgeProperty({})
    is_running = BridgeProperty(False)
    
    def __init__(self):
        super().__init__()
        self.algorithm = None
        
    @pyqtSlot(int, float, int)
    def start(self, num_neurons, temperature, max_iterations):
        """启动BM算法"""
        if self.algorithm and self.algorithm.is_alive():
            self.algorithm.stop()
            self.algorithm.join()
            
        self.algorithm = ObservableBmAlgorithm(
            observer=self,
            num_neurons=num_neurons,
            temperature=temperature,
            max_iterations=max_iterations
        )
        self.is_running = True
        
        # 立即发送初始统计信息
        self.statistics = self.algorithm.get_statistics()
        
        self.algorithm.start()
        
    @pyqtSlot()
    def stop(self):
        """停止BM算法"""
        if self.algorithm:
            self.algorithm.stop()
            self.is_running = False

