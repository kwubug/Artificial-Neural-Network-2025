#!/usr/bin/env python3
"""
简化版牛顿法测试
"""

import numpy as np
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nn_sandbox.backend.algorithms.newton_mlp_algorithm import NewtonMlpAlgorithm

def simple_test():
    """简单测试牛顿法MLP"""
    print("=== 简化牛顿法MLP测试 ===")
    
    # 创建简单的XOR数据集
    dataset = np.array([
        [0, 0, 0],
        [0, 1, 1], 
        [1, 0, 1],
        [1, 1, 0]
    ])
    
    # 创建牛顿法MLP实例
    mlp = NewtonMlpAlgorithm(
        dataset=dataset,
        total_epoches=10,  # 减少轮次用于快速测试
        network_shape=(4,),
        activation_function='sigmoid',
        newton_update_frequency=3,  # 每3次迭代使用一次牛顿法
        initial_learning_rate=0.5,
        test_ratio=0.0  # 不使用测试集，全部用于训练
    )
    
    print("数据集:", dataset)
    print("网络形状:", mlp.network_shape)
    print("激活函数:", mlp.activation_function)
    print("牛顿更新频率:", mlp.newton_update_frequency)
    print("训练数据集大小:", len(mlp.training_dataset))
    
    # 初始化神经元
    mlp._initialize_neurons()
    print("神经元初始化完成")
    
    # 测试前向传播
    test_input = [0, 1]
    result = mlp._feed_forward(test_input)
    print(f"前向传播测试 - 输入: {test_input}, 输出: {result:.4f}")
    
    # 训练过程
    print("\n开始训练...")
    
    # 手动模拟训练过程
    for epoch in range(10):  # 10个epoch
        # 每个epoch中遍历所有训练数据
        for data_idx in range(len(mlp.training_dataset)):
            # 设置当前迭代次数（模拟自动选择数据）
            mlp.current_iterations = epoch * len(mlp.training_dataset) + data_idx
            
            # 执行一次迭代（会自动使用current_data属性选择数据）
            mlp._iterate()
        
        # 计算当前正确率
        correct_rate = mlp._correct_rate(mlp.training_dataset)
        print(f"轮次 {epoch}: 正确率 = {correct_rate:.4f}")
        
        # 显示一些权重信息
        if hasattr(mlp, '_neurons') and mlp._neurons:
            for i, layer in enumerate(mlp._neurons):
                for j, neuron in enumerate(layer):
                    if neuron.synaptic_weight is not None:
                        print(f"  层{i}神经元{j}权重范数: {np.linalg.norm(neuron.synaptic_weight):.4f}")
    
    # 最终测试
    final_correct_rate = mlp._correct_rate(mlp.training_dataset)
    print(f"\n最终正确率: {final_correct_rate:.4f}")
    
    # 测试预测
    print("\n预测测试:")
    for data in dataset:
        prediction = mlp._feed_forward(data[:-1])
        expected = mlp._normalize(data[-1])
        print(f"输入: {data[:-1]}, 期望: {expected:.1f}, 预测: {prediction:.4f}")

if __name__ == "__main__":
    simple_test()