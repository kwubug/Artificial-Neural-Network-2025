import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '../'

Page {
    name: "霍普菲尔德网络 (Hopfield)"

    ColumnLayout {
        spacing: 10
        // 删除此行: anchors.fill: parent
        Layout.fillWidth: true
        Layout.fillHeight: true

        // 控制面板
        GroupBox {
            title: "Hopfield Network 控制面板"
            Layout.fillWidth: true

            ColumnLayout {
                spacing: 10

                // 网络参数
                GroupBox {
                    title: "网络参数"
                    Layout.fillWidth: true

                    GridLayout {
                        columns: 4
                        rowSpacing: 10
                        columnSpacing: 10

                        Label { text: "网络大小:" }
                        ComboBox {
                            model: ["4x4 (16)", "5x5 (25)", "6x6 (36)", "8x8 (64)"]
                            currentIndex: 1
                            Layout.preferredWidth: 150
                        }

                        Label { text: "更新速度(ms):" }
                        SpinBox {
                            from: 10
                            to: 1000
                            value: 100
                            stepSize: 10
                            Layout.preferredWidth: 100
                        }

                        Label { text: "最大迭代次数:" }
                        SpinBox {
                            from: 10
                            to: 1000
                            value: 100
                            stepSize: 10
                            Layout.preferredWidth: 100
                        }
                    }
                }

                // 模式管理
                GroupBox {
                    title: "模式管理"
                    Layout.fillWidth: true

                    ColumnLayout {
                        spacing: 5

                        ScrollView {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 60

                            TextArea {
                                readOnly: true
                                text: "已训练模式: " + hopfieldBridge.trained_patterns + " 个"
                            }
                        }

                        RowLayout {
                            Layout.alignment: Qt.AlignHCenter
                            spacing: 15

                            Button {
                                text: "添加示例模式"
                                onClicked: {
                                    console.log("添加示例模式")
                                    hopfieldBridge.add_sample_patterns()
                                }
                            }

                            Button {
                                text: "清除模式"
                                onClicked: {
                                    console.log("清除所有模式")
                                    hopfieldBridge.clear_patterns()
                                }
                            }
                        }
                    }
                }

                // 训练控制
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 15

                    Button {
                        text: "训练网络"
                        onClicked: {
                            console.log("训练 Hopfield 网络")
                            hopfieldBridge.train_network()
                        }
                    }

                    Button {
                        text: "寻找吸引子"
                        onClicked: {
                            console.log("寻找吸引子")
                            hopfieldBridge.find_attractors()
                        }
                    }
                }

                // 模拟控制
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 15

                    Button {
                        text: "开始模拟"
                        onClicked: {
                            console.log("开始 Hopfield 网络模拟")
                            hopfieldBridge.start_simulation()
                        }
                    }

                    Button {
                        text: "停止模拟"
                        enabled: hopfieldBridge.is_running
                        onClicked: {
                            console.log("停止 Hopfield 网络模拟")
                            hopfieldBridge.stop_simulation()
                        }
                    }

                    Button {
                        text: "单步执行"
                        onClicked: {
                            console.log("执行 Hopfield 网络单步")
                            hopfieldBridge.single_step()
                        }
                    }

                    Button {
                        text: "重置网络"
                        onClicked: {
                            console.log("重置 Hopfield 网络")
                            hopfieldBridge.reset_network()
                        }
                    }

                    Button {
                        text: "随机状态"
                        onClicked: {
                            console.log("设置随机状态")
                            hopfieldBridge.random_state()
                        }
                    }
                }

                // 网络信息
                GroupBox {
                    title: "网络信息"
                    Layout.fillWidth: true

                    ColumnLayout {
                        spacing: 5

                        ScrollView {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 100

                            TextArea {
                                readOnly: true
                                text: "网络大小: " + hopfieldBridge.grid_width + "x" + hopfieldBridge.grid_height + 
                                      " (" + hopfieldBridge.network_size + " 神经元)\n" +
                                      "训练模式: " + hopfieldBridge.trained_patterns + " 个\n" +
                                      "发现吸引子: " + hopfieldBridge.found_attractors + " 个\n" +
                                      "当前能量: " + hopfieldBridge.current_energy.toFixed(2) + "\n" +
                                      "模拟运行中: " + (hopfieldBridge.is_running ? "是" : "否")
                            }
                        }

                        ProgressBar {
                            Layout.fillWidth: true
                            value: 0  // 进度条可以根据需要更新
                        }
                    }
                }
            }
        }

        // 可视化区域
        GroupBox {
            title: "Hopfield Network 可视化"
            Layout.fillWidth: true
            Layout.fillHeight: true

            TabBar {
                id: tabBar
                width: parent.width

                TabButton { text: "当前状态" }
                TabButton { text: "能量景观" }
                TabButton { text: "吸引子" }
                TabButton { text: "训练模式" }
            }

            StackLayout {
                width: parent.width
                height: parent.height - tabBar.height
                currentIndex: tabBar.currentIndex
                anchors.top: tabBar.bottom

                // 当前状态图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "当前网络状态可视化区域"
                    }
                }

                // 能量景观图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "能量景观可视化区域"
                    }
                }

                // 吸引子图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "吸引子可视化区域"
                    }
                }

                // 训练模式图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "训练模式可视化区域"
                    }
                }
            }
        }
    }
}