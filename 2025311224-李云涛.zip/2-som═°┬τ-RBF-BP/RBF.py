import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import Rbf

# ---------------------- 1. 径向基函数（RBF）曲线可视化 ----------------------
plt.figure(figsize=(12, 4))

# 生成距离r的取值范围
r = np.linspace(0, 5, 200)
epsilon = 1.0  # 形状参数

# 绘制3种常见RBF
plt.subplot(1, 3, 1)
gaussian = np.exp(-(epsilon * r) ** 2)  # 高斯函数
plt.plot(r, gaussian, 'b-', linewidth=2, label='Gaussian')
plt.xlabel('r (距离)')
plt.ylabel('φ(r) (函数值)')
plt.title('高斯径向基函数')
plt.grid(True, alpha=0.3)
plt.legend()

plt.subplot(1, 3, 2)
multiquadric = np.sqrt(1 + (epsilon * r) ** 2)  # 多二次函数
plt.plot(r, multiquadric, 'r-', linewidth=2, label='Multiquadric')
plt.xlabel('r (距离)')
plt.ylabel('φ(r) (函数值)')
plt.title('多二次径向基函数')
plt.grid(True, alpha=0.3)
plt.legend()

plt.subplot(1, 3, 3)
inv_multiquadric = 1 / np.sqrt(1 + (epsilon * r) ** 2)  # 逆多二次函数
plt.plot(r, inv_multiquadric, 'g-', linewidth=2, label='Inverse Multiquadric')
plt.xlabel('r (距离)')
plt.ylabel('φ(r) (函数值)')
plt.title('逆多二次径向基函数')
plt.grid(True, alpha=0.3)
plt.legend()

plt.tight_layout()
plt.savefig('rbf_functions.png', dpi=300, bbox_inches='tight')
plt.show()

# ---------------------- 2. 2D RBF插值效果可视化 ----------------------
# 生成原始样本点
np.random.seed(42)
n_samples = 50
x = np.random.uniform(-3, 3, n_samples)
y = np.random.uniform(-3, 3, n_samples)
z = np.sin(np.sqrt(x**2 + y**2))  # 真实函数：z = sin(到原点的距离)

# 创建RBF插值模型（高斯函数）
rbf_interp = Rbf(x, y, z, function='gaussian', epsilon=1.2)

# 生成密集网格用于插值
xi, yi = np.mgrid[-3:3:100j, -3:3:100j]
zi = rbf_interp(xi, yi)  # 插值结果

# 绘制插值效果
plt.figure(figsize=(10, 8))
# 插值后的等高面
contour = plt.pcolor(xi, yi, zi, cmap='viridis', shading='auto')
plt.colorbar(contour, label='z = sin(√(x²+y²))')
# 原始样本点（红色边框突出）
plt.scatter(x, y, c=z, edgecolors='red', s=50, cmap='viridis', marker='o')
plt.xlabel('x')
plt.ylabel('y')
plt.title('2D RBF插值效果（高斯核）')
plt.xlim(-3, 3)
plt.ylim(-3, 3)
plt.savefig('rbf_interpolation_2d.png', dpi=300, bbox_inches='tight')
plt.show()

# ---------------------- 3. RBF神经网络拟合效果可视化 ----------------------
class RBFNetwork:
    def __init__(self, n_centers, sigma=1.0):
        self.n_centers = n_centers  # 隐藏层中心数
        self.sigma = sigma  # 高斯函数宽度
        self.centers = None
        self.weights = None

    def _gaussian(self, x, c):
        # 高斯径向基激活函数
        r = np.linalg.norm(x - c, axis=1)
        return np.exp(-0.5 * (r / self.sigma) ** 2)

    def fit(self, X, y):
        # 随机选择中心点（简化版，实际可用品K-means优化）
        idx = np.random.choice(X.shape[0], self.n_centers, replace=False)
        self.centers = X[idx]
        # 计算隐藏层输出（设计矩阵）
        G = np.array([self._gaussian(self.centers, x) for x in X])
        # 最小二乘求解输出层权重
        self.weights = np.linalg.pinv(G) @ y

    def predict(self, X):
        G = np.array([self._gaussian(self.centers, x) for x in X])
        return G @ self.weights

# 生成训练数据（拟合正弦函数）
X = np.linspace(0, 2*np.pi, 100).reshape(-1, 1)  # 输入：0~2π的100个点
y_true = np.sin(X).ravel()  # 真实标签：sin(x)

# 训练RBF神经网络
rbf_net = RBFNetwork(n_centers=15, sigma=0.6)
rbf_net.fit(X, y_true)
y_pred = rbf_net.predict(X)  # 预测结果

# 绘制拟合效果
plt.figure(figsize=(10, 6))
plt.plot(X, y_true, 'b-', linewidth=2, label='真实函数：y = sin(x)')
plt.plot(X, y_pred, 'r--', linewidth=2, label='RBF神经网络拟合')
plt.scatter(rbf_net.centers, np.sin(rbf_net.centers),
            c='orange', s=100, marker='*', label='RBF中心点')
plt.xlabel('x')
plt.ylabel('y')
plt.title('RBF神经网络拟合正弦函数')
plt.legend()
plt.grid(True, alpha=0.3)
plt.savefig('rbf_neural_network_fitting.png', dpi=300, bbox_inches='tight')
plt.show()