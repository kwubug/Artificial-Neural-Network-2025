import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
import os


# 定义目标函数 f(x1, x2) = x1^2 + 25x2^2
def f(x):
    return x[0] ** 2 + 25 * x[1] ** 2


# 计算目标函数的梯度
def grad_f(x):
    return np.array([2 * x[0], 50 * x[1]])


# 计算目标函数的海森矩阵（Hessian Matrix）
def hessian_f(x):
    return np.array([[2, 0], [0, 50]])


# 牛顿法
def newton_method(start, max_iter=50, tol=1e-6):
    x = start
    path = [x.copy()]

    for i in range(max_iter):
        grad = grad_f(x)
        H = hessian_f(x)

        # 计算更新方向
        try:
            H_inv = np.linalg.inv(H)  # 计算海森矩阵的逆
        except np.linalg.LinAlgError:
            print("海森矩阵不可逆")
            break

        # 使用牛顿法更新
        x = x - np.dot(H_inv, grad)
        path.append(x.copy())

        # 如果梯度足够小，则停止迭代
        if np.linalg.norm(grad) < tol:
            break

        # 每5个时间步保存一次图像
        if i % (max_iter // 5) == 0:
            plot_newton(np.array(path), i)

        # 如果梯度足够小，则停止迭代
        if np.linalg.norm(grad) < tol:
            break
    return np.array(path)


# 绘制牛顿法优化路径
def plot_newton(path, step):
    x_vals = np.linspace(-6, 6, 100)
    y_vals = np.linspace(-6, 6, 100)
    X, Y = np.meshgrid(x_vals, y_vals)
    Z = X ** 2 + 25 * Y ** 2  # 目标函数值

    plt.contour(X, Y, Z, 50, cmap=cm.coolwarm)
    plt.colorbar()
    plt.plot(path[:, 0], path[:, 1], marker='o', label="Newton Method", color='red')
    plt.title(f'Newton Method Optimization Path - Step {step}')
    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.grid(True)
    plt.legend()
    plt.show()


# 设置初始猜测点
start_point = np.array([5, 5])

# 进行牛顿法优化
path_newton = newton_method(start_point)

# 最终返回的路径包含了所有迭代步骤的结果
print("牛顿法过程中的图像已保存。")
