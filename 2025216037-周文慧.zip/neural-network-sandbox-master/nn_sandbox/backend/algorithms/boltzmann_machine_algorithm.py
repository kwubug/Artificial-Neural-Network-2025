import numpy as np
from . import TraningAlgorithm


class BoltzmannMachineAlgorithm(TraningAlgorithm):
    """Boltzmann Machine - 3个神经元的可视化"""
    
    def __init__(self, temperature=1.0, max_iterations=1000, total_epoches=1):
        """
        Args:
            temperature: 温度参数 T（控制随机性）
            max_iterations: 最大迭代次数
            total_epoches: 训练轮数
        """
        super().__init__(dataset=[], total_epoches=total_epoches)
        
        self.n_neurons = 3  # 固定3个神经元
        self.temperature = temperature
        self.max_iterations = max_iterations
        
        # 权重矩阵（对称，对角线为0）
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        self.bias = np.zeros(self.n_neurons)  # 偏置
        
        # 当前状态 (0 或 1)
        self.current_state = np.random.randint(0, 2, size=self.n_neurons)
        
        # 历史记录
        self.state_history = []  # 状态历史
        self.energy_history = []  # 能量历史
        self.probability_history = []  # 每个神经元的激活概率历史
        
        # 统计信息
        self.state_counts = {}  # 统计每个状态出现的次数
        self.equilibrium_distribution = {}  # 热平衡分布
        
        self.current_iterations = 0
        self.is_equilibrium = False
        
    def _initialize_neurons(self):
        """初始化权重矩阵和偏置"""
        self._neurons = []  # 兼容基类
        
        # 初始化权重矩阵（对称）
        # 示例：设置一些有趣的连接
        self.weights = np.array([
            [0.0,  1.5, -1.0],  # 神经元0的连接
            [1.5,  0.0,  0.5],  # 神经元1的连接
            [-1.0, 0.5,  0.0]   # 神经元2的连接
        ])
        
        # 偏置
        self.bias = np.array([0.5, -0.3, 0.2])
        
        # 随机初始状态
        self.current_state = np.random.randint(0, 2, size=self.n_neurons)
        self.state_history = [self.current_state.copy()]
        self.energy_history = [self.calculate_energy(self.current_state)]
        self.state_counts = {}
        self.equilibrium_distribution = {}
        
    def set_weights(self, weights, bias):
        """手动设置权重和偏置"""
        self.weights = np.array(weights)
        self.bias = np.array(bias)
        
    def set_initial_state(self, state):
        """设置初始状态"""
        self.current_state = np.array(state)
        self.state_history = [self.current_state.copy()]
        self.energy_history = [self.calculate_energy(self.current_state)]
        self.current_iterations = 0
        self.is_equilibrium = False
        self.state_counts = {}
        
    def _iterate(self):
        """单次迭代：随机选择一个神经元进行更新"""
        # 随机选择一个神经元
        neuron_idx = np.random.randint(0, self.n_neurons)
        
        # 计算该神经元的输入
        net_input = np.dot(self.weights[neuron_idx], self.current_state) + self.bias[neuron_idx]
        
        # 计算激活概率（sigmoid函数，温度T）
        activation_prob = self.sigmoid(net_input / self.temperature)
        
        # 概率性更新（Boltzmann分布）
        self.current_state[neuron_idx] = 1 if np.random.random() < activation_prob else 0
        
        # 记录历史
        self.state_history.append(self.current_state.copy())
        current_energy = self.calculate_energy(self.current_state)
        self.energy_history.append(current_energy)
        
        # 统计状态
        state_key = tuple(self.current_state)
        self.state_counts[state_key] = self.state_counts.get(state_key, 0) + 1
        
        # 检查是否达到热平衡（简单判断：最近100次迭代状态分布稳定）
        if self.current_iterations > 500 and self.current_iterations % 100 == 0:
            self.check_equilibrium()
        
        self.current_iterations += 1
        
    def run(self):
        """运行直到达到最大迭代次数"""
        self._initialize_neurons()
        
        while self.current_iterations < self.max_iterations and not self._should_stop:
            self._iterate()
        
        # 计算最终的热平衡分布
        self.calculate_equilibrium_distribution()
        self.is_equilibrium = True
        
    def sigmoid(self, x):
        """Sigmoid函数（带温度的激活函数）"""
        return 1.0 / (1.0 + np.exp(-x))
    
    def calculate_energy(self, state):
        """计算能量：E = -0.5 * s^T * W * s - b^T * s"""
        energy = -0.5 * np.dot(state, np.dot(self.weights, state)) - np.dot(self.bias, state)
        return float(energy)
    
    def check_equilibrium(self):
        """检查是否达到热平衡"""
        # 简单判断：最近一段时间内状态分布相对稳定
        if len(self.state_history) < 200:
            return False
        
        # 计算最近100次和之前100次的状态分布
        recent_states = self.state_history[-100:]
        previous_states = self.state_history[-200:-100]
        
        recent_dist = self._calculate_distribution(recent_states)
        previous_dist = self._calculate_distribution(previous_states)
        
        # 比较两个分布的差异
        diff = sum(abs(recent_dist.get(k, 0) - previous_dist.get(k, 0)) for k in set(recent_dist) | set(previous_dist))
        
        if diff < 0.1:  # 差异小于阈值
            self.is_equilibrium = True
        
        return self.is_equilibrium
    
    def _calculate_distribution(self, states):
        """计算状态分布"""
        counts = {}
        for state in states:
            key = tuple(state)
            counts[key] = counts.get(key, 0) + 1
        
        total = len(states)
        return {k: v / total for k, v in counts.items()}
    
    def calculate_equilibrium_distribution(self):
        """计算热平衡状态分布"""
        if len(self.state_history) < 100:
            return
        
        # 使用最后500次迭代的统计
        recent_states = self.state_history[-500:] if len(self.state_history) >= 500 else self.state_history
        
        counts = {}
        for state in recent_states:
            key = tuple(state)
            counts[key] = counts.get(key, 0) + 1
        
        total = len(recent_states)
        self.equilibrium_distribution = {k: v / total for k, v in counts.items()}
        
    def get_theoretical_distribution(self):
        """计算理论上的Boltzmann分布（用于对比）"""
        # 枚举所有可能的状态（2^3 = 8种）
        all_states = []
        energies = []
        
        for i in range(2**self.n_neurons):
            state = np.array([(i >> j) & 1 for j in range(self.n_neurons)])
            all_states.append(state)
            energies.append(self.calculate_energy(state))
        
        # Boltzmann分布：P(s) = exp(-E(s)/T) / Z
        energies = np.array(energies)
        exp_energies = np.exp(-energies / self.temperature)
        Z = np.sum(exp_energies)  # 配分函数
        
        probabilities = exp_energies / Z
        
        theoretical_dist = {}
        for state, prob in zip(all_states, probabilities):
            theoretical_dist[tuple(state)] = float(prob)
        
        return theoretical_dist
    
    def get_all_possible_states(self):
        """获取所有可能的状态及其能量"""
        states = []
        for i in range(2**self.n_neurons):
            state = [(i >> j) & 1 for j in range(self.n_neurons)]
            energy = self.calculate_energy(np.array(state))
            states.append({
                'state': state,
                'energy': energy
            })
        return states