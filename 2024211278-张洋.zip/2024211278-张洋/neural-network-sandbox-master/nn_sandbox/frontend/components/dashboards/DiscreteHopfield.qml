import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Discrete Hopfield'

    ColumnLayout {
        GroupBox {
            title: '网络设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                
                Label { text: '图像边长 M:'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: discreteHopfieldBridge.has_finished
                    editable: true
                    value: 4
                    from: 4; to: 4  // 固定为4x4
                    onValueChanged: discreteHopfieldBridge.M = value
                    Component.onCompleted: discreteHopfieldBridge.M = value
                    Layout.fillWidth: true
                }
                
                Label { text: '初始模式:'; Layout.alignment: Qt.AlignHCenter }
                ComboBox {
                    id: patternCombo
                    enabled: discreteHopfieldBridge.has_finished
                    model: ['P1', 'P2', 'P3']
                    currentIndex: 0
                    onCurrentIndexChanged: discreteHopfieldBridge.initial_pattern_index = currentIndex
                    Component.onCompleted: discreteHopfieldBridge.initial_pattern_index = 0
                    Layout.fillWidth: true
                }
                
                Label { text: '噪声比例:'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: discreteHopfieldBridge.has_finished
                    editable: true
                    value: 20
                    from: 0; to: 50
                    onValueChanged: discreteHopfieldBridge.noise_level = value / 100
                    Component.onCompleted: discreteHopfieldBridge.noise_level = value / 100
                    Layout.fillWidth: true
                }
                
                Label { text: '最大迭代次数:'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: discreteHopfieldBridge.has_finished
                    editable: true
                    value: 2000
                    from: 100; to: 5000
                    onValueChanged: discreteHopfieldBridge.max_iter = value
                    Component.onCompleted: discreteHopfieldBridge.max_iter = value
                    Layout.fillWidth: true
                }
                
                Label { text: '更新频率:'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: discreteHopfieldBridge.has_finished
                    editable: true
                    value: 5
                    from: 1; to: 50
                    onValueChanged: discreteHopfieldBridge.update_freq = value
                    Component.onCompleted: discreteHopfieldBridge.update_freq = value
                    Layout.fillWidth: true
                }
                
                Label { text: 'UI刷新间隔 (秒):'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: discreteHopfieldBridge.has_finished
                    editable: true
                    value: 1
                    from: 0; to: 10
                    onValueChanged: discreteHopfieldBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: discreteHopfieldBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        
        GroupBox {
            title: '控制'
            Layout.fillWidth: true
            ExecutionControls {
                startButton.enabled: discreteHopfieldBridge.has_finished
                startButton.text: "开始联想"
                startButton.onClicked: () => {
                    energySeries.clear()
                    eAxisX.max = 100
                    discreteHopfieldBridge.start()
                }
                stopButton.enabled: !discreteHopfieldBridge.has_finished
                stopButton.onClicked: discreteHopfieldBridge.stop()
                progressBar.from: 0
                progressBar.to: discreteHopfieldBridge.max_iter
                progressBar.value: discreteHopfieldBridge.current_iteration
                Layout.fillWidth: true
            }
        }
        
        // 当前状态显示
        GroupBox {
            title: '联想记忆过程'
            Layout.fillWidth: true
            RowLayout {
                anchors.fill: parent
                
                // 初始模式
                ColumnLayout {
                    Layout.preferredWidth: parent.width * 0.3
                    Label { 
                        text: '初始存储模式'
                        font.bold: true
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Canvas {
                        id: initialPatternCanvas
                        Layout.preferredWidth: 120
                        Layout.preferredHeight: 120
                        Layout.alignment: Qt.AlignHCenter
                        
                        onPaint: {
                            if (!discreteHopfieldBridge.initial_pattern || 
                                discreteHopfieldBridge.initial_pattern.length === 0) return
                            
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            
                            var M = 4
                            var cellW = width / M
                            var cellH = height / M
                            
                            for (var i = 0; i < M; i++) {
                                for (var j = 0; j < M; j++) {
                                    var idx = i * M + j
                                    var val = discreteHopfieldBridge.initial_pattern[idx]
                                    ctx.fillStyle = val > 0 ? 'white' : 'black'
                                    ctx.fillRect(j * cellW, i * cellH, cellW, cellH)
                                    ctx.strokeStyle = '#888'
                                    ctx.strokeRect(j * cellW, i * cellH, cellW, cellH)
                                }
                            }
                        }
                    }
                }
                
                // 带噪声输入
                ColumnLayout {
                    Layout.preferredWidth: parent.width * 0.3
                    Label { 
                        text: '带噪声输入'
                        font.bold: true
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Canvas {
                        id: noisyInputCanvas
                        Layout.preferredWidth: 120
                        Layout.preferredHeight: 120
                        Layout.alignment: Qt.AlignHCenter
                        
                        onPaint: {
                            if (!discreteHopfieldBridge.initial_state || 
                                discreteHopfieldBridge.initial_state.length === 0) return
                            
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            
                            var M = 4
                            var cellW = width / M
                            var cellH = height / M
                            
                            for (var i = 0; i < M; i++) {
                                for (var j = 0; j < M; j++) {
                                    var idx = i * M + j
                                    var val = discreteHopfieldBridge.initial_state[idx]
                                    ctx.fillStyle = val > 0 ? 'white' : 'black'
                                    ctx.fillRect(j * cellW, i * cellH, cellW, cellH)
                                    ctx.strokeStyle = '#888'
                                    ctx.strokeRect(j * cellW, i * cellH, cellW, cellH)
                                }
                            }
                        }
                    }
                }
                
                // 当前状态
                ColumnLayout {
                    Layout.preferredWidth: parent.width * 0.3
                    Label { 
                        text: '当前状态 (Step=' + discreteHopfieldBridge.current_iteration + ')'
                        font.bold: true
                        color: '#cc0000'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Canvas {
                        id: currentStateCanvas
                        Layout.preferredWidth: 120
                        Layout.preferredHeight: 120
                        Layout.alignment: Qt.AlignHCenter
                        
                        onPaint: {
                            if (!discreteHopfieldBridge.current_state || 
                                discreteHopfieldBridge.current_state.length === 0) return
                            
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            
                            var M = 4
                            var cellW = width / M
                            var cellH = height / M
                            
                            for (var i = 0; i < M; i++) {
                                for (var j = 0; j < M; j++) {
                                    var idx = i * M + j
                                    var val = discreteHopfieldBridge.current_state[idx]
                                    ctx.fillStyle = val > 0 ? 'white' : 'black'
                                    ctx.fillRect(j * cellW, i * cellH, cellW, cellH)
                                    ctx.strokeStyle = '#cc0000'
                                    ctx.lineWidth = 2
                                    ctx.strokeRect(j * cellW, i * cellH, cellW, cellH)
                                }
                            }
                        }
                    }
                    Label {
                        text: 'E = ' + discreteHopfieldBridge.current_energy.toFixed(4)
                        font.bold: true
                        Layout.alignment: Qt.AlignHCenter
                    }
                }
            }
        }
        
        // 能量曲线
        GroupBox {
            title: '能量变化曲线 E(t) - 单调递减至吸引子'
            Layout.fillWidth: true
            Layout.preferredHeight: 250
            ChartView {
                anchors.fill: parent
                antialiasing: true
                legend.visible: true
                legend.alignment: Qt.AlignBottom
                theme: ChartView.ChartThemeLight
                
                ValueAxis { 
                    id: eAxisX
                    min: 0
                    max: 100
                    titleText: '异步更新步数 (Step)'
                    labelFormat: '%d'
                    tickCount: 6
                }
                ValueAxis { 
                    id: eAxisY
                    min: -50
                    max: 0
                    titleText: '能量 E'
                    labelFormat: '%.2f'
                    tickCount: 6
                }
                LineSeries {
                    id: energySeries
                    name: '系统能量 E (单调递减)'
                    axisX: eAxisX
                    axisY: eAxisY
                    color: '#0066cc'
                    width: 2
                }
            }
        }
        
        // 运行结果信息
        GroupBox {
            title: '运行结果'
            Layout.fillWidth: true
            GridLayout {
                columns: 2
                anchors.fill: parent
                
                Label { text: '当前迭代步数:' }
                Label { 
                    text: discreteHopfieldBridge.current_iteration
                    font.bold: true
                }
                
                Label { text: '当前能量:' }
                Label { 
                    text: discreteHopfieldBridge.current_energy.toFixed(4)
                    font.bold: true
                }
                
                Label { text: '收敛状态:' }
                Label { 
                    text: discreteHopfieldBridge.is_stable ? '已收敛到吸引子' : '运行中...'
                    font.bold: true
                    color: discreteHopfieldBridge.is_stable ? '#00aa00' : '#888'
                }
            }
        }
    }
    
    Connections {
        target: discreteHopfieldBridge
        
        function onInitial_patternChanged() {
            initialPatternCanvas.requestPaint()
        }
        
        function onInitial_stateChanged() {
            noisyInputCanvas.requestPaint()
        }
        
        function onCurrent_iterationChanged() {
            if (discreteHopfieldBridge.current_iteration > 0) {
                currentStateCanvas.requestPaint()
                
                // 更新能量曲线
                energySeries.append(
                    discreteHopfieldBridge.current_iteration, 
                    discreteHopfieldBridge.current_energy
                )
                
                // 动态调整坐标轴范围
                if (discreteHopfieldBridge.current_iteration > eAxisX.max - 20) {
                    eAxisX.max = discreteHopfieldBridge.current_iteration + 50
                }
                
                if (discreteHopfieldBridge.current_energy < eAxisY.min) {
                    eAxisY.min = discreteHopfieldBridge.current_energy - 10
                }
            }
        }
    }
}

