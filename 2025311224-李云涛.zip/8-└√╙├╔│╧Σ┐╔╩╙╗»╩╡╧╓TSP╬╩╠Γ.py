import numpy as np
import matplotlib.pyplot as plt
import random
import math
from matplotlib.animation import FuncAnimation

# 设置全局字体为黑体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


class TSPSolver:
    def __init__(self, num_cities=20, map_size=(100, 100)):
        """
        初始化TSP求解器

        参数:
        num_cities: 城市数量
        map_size: 地图尺寸 (宽度, 高度)
        """
        self.num_cities = num_cities
        self.map_size = map_size
        self.cities = self.generate_cities()
        self.distance_matrix = self.calculate_distance_matrix()
        self.best_solution = None
        self.best_distance = float('inf')
        self.history = []

    def generate_cities(self):
        """随机生成城市坐标"""
        np.random.seed(42)  # 固定随机种子以便重现结果
        cities = np.random.rand(self.num_cities, 2)
        cities[:, 0] *= self.map_size[0]
        cities[:, 1] *= self.map_size[1]
        return cities

    def calculate_distance_matrix(self):
        """计算城市之间的距离矩阵"""
        matrix = np.zeros((self.num_cities, self.num_cities))
        for i in range(self.num_cities):
            for j in range(i + 1, self.num_cities):
                dist = np.linalg.norm(self.cities[i] - self.cities[j])
                matrix[i, j] = dist
                matrix[j, i] = dist
        return matrix

    def calculate_total_distance(self, route):
        """计算路径总距离"""
        total_distance = 0
        for i in range(len(route)):
            from_city = route[i]
            to_city = route[(i + 1) % len(route)]
            total_distance += self.distance_matrix[from_city, to_city]
        return total_distance

    def generate_initial_solution(self):
        """生成初始解（随机路径）"""
        return list(np.random.permutation(self.num_cities))

    def generate_neighbor(self, route):
        """生成邻居解（通过交换两个城市）"""
        new_route = route.copy()
        i, j = random.sample(range(self.num_cities), 2)
        new_route[i], new_route[j] = new_route[j], new_route[i]
        return new_route

    def simulated_annealing(self, initial_temperature=1000, cooling_rate=0.995,
                            max_iterations=10000, stop_temperature=1e-3):
        """
        模拟退火算法求解TSP

        参数:
        initial_temperature: 初始温度
        cooling_rate: 冷却率
        max_iterations: 最大迭代次数
        stop_temperature: 停止温度
        """
        print("开始模拟退火算法求解TSP问题...")

        # 初始化
        current_route = self.generate_initial_solution()
        current_distance = self.calculate_total_distance(current_route)
        temperature = initial_temperature

        # 记录最佳解
        self.best_solution = current_route
        self.best_distance = current_distance

        # 记录历史
        self.history = [{
            'iteration': 0,
            'temperature': temperature,
            'current_distance': current_distance,
            'best_distance': self.best_distance,
            'route': current_route.copy()
        }]

        iteration = 0
        while temperature > stop_temperature and iteration < max_iterations:
            # 生成邻居解
            new_route = self.generate_neighbor(current_route)
            new_distance = self.calculate_total_distance(new_route)

            # 计算能量差
            delta_energy = new_distance - current_distance

            # 决定是否接受新解
            if delta_energy < 0 or random.random() < math.exp(-delta_energy / temperature):
                current_route = new_route
                current_distance = new_distance

                # 更新最佳解
                if current_distance < self.best_distance:
                    self.best_solution = current_route.copy()
                    self.best_distance = current_distance

            # 降温
            temperature *= cooling_rate
            iteration += 1

            # 记录历史
            if iteration % 100 == 0:
                self.history.append({
                    'iteration': iteration,
                    'temperature': temperature,
                    'current_distance': current_distance,
                    'best_distance': self.best_distance,
                    'route': current_route.copy()
                })

        print(f"算法完成，共迭代 {iteration} 次")
        print(f"最优路径长度: {self.best_distance:.2f}")

        return self.best_solution, self.best_distance

    def visualize_cities(self):
        """可视化城市分布"""
        plt.figure(figsize=(10, 8))
        plt.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, alpha=0.7)

        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            plt.annotate(f'城市{i}', (x, y), xytext=(5, 5), textcoords='offset points',
                         fontsize=10, fontweight='bold')

        plt.xlabel('X坐标', fontsize=12, fontweight='bold')
        plt.ylabel('Y坐标', fontsize=12, fontweight='bold')
        plt.title('TSP问题 - 城市分布图', fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

    def visualize_initial_solution(self):
        """可视化初始解"""
        initial_route = self.generate_initial_solution()
        initial_distance = self.calculate_total_distance(initial_route)

        plt.figure(figsize=(10, 8))

        # 绘制城市点
        plt.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, alpha=0.7)

        # 绘制路径
        for i in range(len(initial_route)):
            start_city = initial_route[i]
            end_city = initial_route[(i + 1) % len(initial_route)]
            plt.plot([self.cities[start_city, 0], self.cities[end_city, 0]],
                     [self.cities[start_city, 1], self.cities[end_city, 1]],
                     'b-', alpha=0.6, linewidth=1)

        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            plt.annotate(f'{i}', (x, y), xytext=(5, 5), textcoords='offset points',
                         fontsize=10, fontweight='bold')

        plt.xlabel('X坐标', fontsize=12, fontweight='bold')
        plt.ylabel('Y坐标', fontsize=12, fontweight='bold')
        plt.title(f'TSP问题 - 初始解 (路径长度: {initial_distance:.2f})', fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

        return initial_route, initial_distance

    def visualize_final_solution(self):
        """可视化最终解"""
        if self.best_solution is None:
            print("请先运行模拟退火算法!")
            return

        plt.figure(figsize=(10, 8))

        # 绘制城市点
        plt.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, alpha=0.7)

        # 绘制最优路径
        for i in range(len(self.best_solution)):
            start_city = self.best_solution[i]
            end_city = self.best_solution[(i + 1) % len(self.best_solution)]
            plt.plot([self.cities[start_city, 0], self.cities[end_city, 0]],
                     [self.cities[start_city, 1], self.cities[end_city, 1]],
                     'g-', alpha=0.8, linewidth=2)

        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            plt.annotate(f'{i}', (x, y), xytext=(5, 5), textcoords='offset points',
                         fontsize=10, fontweight='bold')

        plt.xlabel('X坐标', fontsize=12, fontweight='bold')
        plt.ylabel('Y坐标', fontsize=12, fontweight='bold')
        plt.title(f'TSP问题 - 最优解 (路径长度: {self.best_distance:.2f})', fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

    def visualize_optimization_process(self):
        """可视化优化过程"""
        if not self.history:
            print("请先运行模拟退火算法!")
            return

        iterations = [h['iteration'] for h in self.history]
        temperatures = [h['temperature'] for h in self.history]
        current_distances = [h['current_distance'] for h in self.history]
        best_distances = [h['best_distance'] for h in self.history]

        # 创建图形1 - 温度变化
        plt.figure(figsize=(10, 6))
        plt.semilogy(iterations, temperatures, 'r-', linewidth=2)
        plt.xlabel('迭代次数', fontsize=12, fontweight='bold')
        plt.ylabel('温度 (对数尺度)', fontsize=12, fontweight='bold')
        plt.title('模拟退火算法 - 温度下降过程', fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

        # 创建图形2 - 距离变化
        plt.figure(figsize=(10, 6))
        plt.plot(iterations, current_distances, 'b-', alpha=0.7, linewidth=1, label='当前解距离')
        plt.plot(iterations, best_distances, 'r-', linewidth=2, label='最优解距离')
        plt.xlabel('迭代次数', fontsize=12, fontweight='bold')
        plt.ylabel('路径长度', fontsize=12, fontweight='bold')
        plt.title('模拟退火算法 - 路径长度优化过程', fontsize=14, fontweight='bold')
        plt.legend(fontsize=12)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

    def visualize_distance_matrix(self):
        """可视化距离矩阵"""
        plt.figure(figsize=(8, 6))
        plt.imshow(self.distance_matrix, cmap='hot', interpolation='nearest')
        plt.colorbar(label='距离')
        plt.title('城市间距离矩阵', fontsize=14, fontweight='bold')
        plt.xlabel('城市索引', fontsize=12, fontweight='bold')
        plt.ylabel('城市索引', fontsize=12, fontweight='bold')
        plt.tight_layout()
        plt.show()

    def visualize_solution_comparison(self):
        """可视化初始解与最终解的对比"""
        if self.best_solution is None:
            print("请先运行模拟退火算法!")
            return

        initial_route, initial_distance = self.visualize_initial_solution()

        # 创建对比图
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # 初始解
        ax1.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, alpha=0.7)
        for i in range(len(initial_route)):
            start_city = initial_route[i]
            end_city = initial_route[(i + 1) % len(initial_route)]
            ax1.plot([self.cities[start_city, 0], self.cities[end_city, 0]],
                     [self.cities[start_city, 1], self.cities[end_city, 1]],
                     'b-', alpha=0.6, linewidth=1)

        for i, (x, y) in enumerate(self.cities):
            ax1.annotate(f'{i}', (x, y), xytext=(5, 5), textcoords='offset points',
                         fontsize=10, fontweight='bold')

        ax1.set_xlabel('X坐标', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Y坐标', fontsize=12, fontweight='bold')
        ax1.set_title(f'初始解 (路径长度: {initial_distance:.2f})', fontsize=14, fontweight='bold')
        ax1.grid(True, alpha=0.3)

        # 最终解
        ax2.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, alpha=0.7)
        for i in range(len(self.best_solution)):
            start_city = self.best_solution[i]
            end_city = self.best_solution[(i + 1) % len(self.best_solution)]
            ax2.plot([self.cities[start_city, 0], self.cities[end_city, 0]],
                     [self.cities[start_city, 1], self.cities[end_city, 1]],
                     'g-', alpha=0.8, linewidth=2)

        for i, (x, y) in enumerate(self.cities):
            ax2.annotate(f'{i}', (x, y), xytext=(5, 5), textcoords='offset points',
                         fontsize=10, fontweight='bold')

        ax2.set_xlabel('X坐标', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Y坐标', fontsize=12, fontweight='bold')
        ax2.set_title(f'最优解 (路径长度: {self.best_distance:.2f})', fontsize=14, fontweight='bold')
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

        improvement = ((initial_distance - self.best_distance) / initial_distance) * 100
        print(f"优化改进: {improvement:.2f}%")


def demonstrate_tsp_solver():
    """
    演示TSP求解器的功能
    """
    print("=" * 60)
    print("旅行商问题(TSP)求解演示")
    print("=" * 60)

    # 创建TSP求解器
    tsp_solver = TSPSolver(num_cities=15, map_size=(100, 100))

    # 显示基本信息
    print(f"城市数量: {tsp_solver.num_cities}")
    print(f"地图尺寸: {tsp_solver.map_size}")

    # 可视化城市分布
    print("\n" + "=" * 40)
    print("城市分布可视化")
    print("=" * 40)
    tsp_solver.visualize_cities()

    # 可视化距离矩阵
    print("\n" + "=" * 40)
    print("距离矩阵可视化")
    print("=" * 40)
    tsp_solver.visualize_distance_matrix()

    # 可视化初始解
    print("\n" + "=" * 40)
    print("初始解可视化")
    print("=" * 40)
    initial_route, initial_distance = tsp_solver.visualize_initial_solution()
    print(f"初始路径长度: {initial_distance:.2f}")

    # 运行模拟退火算法
    print("\n" + "=" * 40)
    print("模拟退火算法求解")
    print("=" * 40)
    best_route, best_distance = tsp_solver.simulated_annealing(
        initial_temperature=1000,
        cooling_rate=0.995,
        max_iterations=5000
    )

    # 可视化优化过程
    print("\n" + "=" * 40)
    print("优化过程可视化")
    print("=" * 40)
    tsp_solver.visualize_optimization_process()

    # 可视化最终解
    print("\n" + "=" * 40)
    print("最终解可视化")
    print("=" * 40)
    tsp_solver.visualize_final_solution()

    # 可视化对比
    print("\n" + "=" * 40)
    print("初始解与最终解对比")
    print("=" * 40)
    tsp_solver.visualize_solution_comparison()

    # 显示详细结果
    print("\n" + "=" * 40)
    print("详细结果")
    print("=" * 40)
    print(f"最优路径: {best_route}")
    print(f"最优路径长度: {best_distance:.2f}")

    # 计算改进百分比
    improvement = ((initial_distance - best_distance) / initial_distance) * 100
    print(f"优化改进: {improvement:.2f}%")


if __name__ == "__main__":
    demonstrate_tsp_solver()