import numpy as np
import matplotlib.pyplot as plt
import random
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QDoubleSpinBox,
                               QTextEdit, QFormLayout, QCheckBox)
from PySide6.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class HopfieldNetworkTab(QWidget):
    def __init__(self):
        super().__init__()
        self.network = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 控制面板
        control_group = QGroupBox("Hopfield网络参数")
        control_layout = QFormLayout()

        self.neuron_spin = QSpinBox()
        self.neuron_spin.setRange(4, 100)
        self.neuron_spin.setValue(25)

        self.iterations_spin = QSpinBox()
        self.iterations_spin.setRange(10, 5000)
        self.iterations_spin.setValue(1000)

        self.threshold_spin = QDoubleSpinBox()
        self.threshold_spin.setRange(0.0001, 0.1)
        self.threshold_spin.setValue(0.001)
        self.threshold_spin.setDecimals(4)

        control_layout.addRow("神经元数量:", self.neuron_spin)
        control_layout.addRow("最大迭代次数:", self.iterations_spin)
        control_layout.addRow("收敛阈值:", self.threshold_spin)

        control_group.setLayout(control_layout)

        # 按钮区域
        button_layout = QHBoxLayout()
        self.train_button = QPushButton("训练网络")
        self.test_button = QPushButton("测试网络")
        self.train_button.clicked.connect(self.train_network)
        self.test_button.clicked.connect(self.test_network)
        button_layout.addWidget(self.train_button)
        button_layout.addWidget(self.test_button)

        # 结果显示
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(10, 8)))

        # 布局
        layout.addWidget(control_group)
        layout.addWidget(QLabel("操作:"))
        layout.addLayout(button_layout)
        layout.addWidget(self.result_text)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def train_network(self):
        try:
            n_neurons = self.neuron_spin.value()
            self.network = DiscreteHopfieldNetwork(n_neurons)

            # 创建训练模式（简单的图案）
            patterns = self.create_patterns(n_neurons)
            self.network.train(patterns)

            self.result_text.append("Hopfield网络训练完成！")
            self.result_text.append(f"已训练 {len(patterns)} 个模式")

        except Exception as e:
            self.result_text.append(f"训练错误: {e}")

    def create_patterns(self, n_neurons):
        """创建训练模式"""
        patterns = []
        size = int(np.sqrt(n_neurons))

        if size * size != n_neurons:
            # 如果不是平方数，创建一维模式
            # 横线模式
            pattern1 = [1 if i < n_neurons // 2 else 0 for i in range(n_neurons)]
            # 竖线模式（交替）
            pattern2 = [1 if i % 2 == 0 else 0 for i in range(n_neurons)]
            patterns = [pattern1, pattern2]
        else:
            # 创建二维模式
            # 横线
            pattern1 = []
            for i in range(size):
                for j in range(size):
                    pattern1.append(1 if i == size // 2 else 0)

            # 竖线
            pattern2 = []
            for i in range(size):
                for j in range(size):
                    pattern2.append(1 if j == size // 2 else 0)

            patterns = [pattern1, pattern2]

        return patterns

    def test_network(self):
        if self.network is None:
            self.result_text.append("请先训练网络！")
            return

        try:
            n_neurons = self.neuron_spin.value()
            max_iter = self.iterations_spin.value()
            threshold = self.threshold_spin.value()

            # 创建有噪声的输入
            if n_neurons == 25:
                # 使用5x5的测试模式
                noisy_pattern = [1, 1, 1, 0, 1,
                                 0, 1, 0, 0, 0,
                                 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0]
            else:
                # 创建随机噪声模式
                base_pattern = [1] * (n_neurons // 3) + [0] * (n_neurons - n_neurons // 3)
                noisy_pattern = base_pattern.copy()
                # 添加噪声
                for i in range(n_neurons // 4):
                    idx = random.randint(0, n_neurons - 1)
                    noisy_pattern[idx] = 1 - noisy_pattern[idx]

            initial_energy = self.network.calculate_energy(noisy_pattern)
            self.result_text.append(f"初始状态能量: {initial_energy:.4f}")

            final_state, energy_history = self.network.asynchronous_update(
                noisy_pattern, max_iter, threshold)

            final_energy = self.network.calculate_energy(final_state)
            self.result_text.append(f"最终状态能量: {final_energy:.4f}")
            self.result_text.append(f"迭代次数: {len(energy_history)}")

            # 可视化结果
            self.visualize_results(noisy_pattern, final_state, energy_history, n_neurons)

        except Exception as e:
            self.result_text.append(f"测试错误: {e}")

    def visualize_results(self, initial_state, final_state, energy_history, n_neurons):
        self.canvas.figure.clear()

        # 计算网格尺寸
        size = int(np.sqrt(n_neurons))
        if size * size == n_neurons:
            # 二维显示
            ax1 = self.canvas.figure.add_subplot(221)
            ax2 = self.canvas.figure.add_subplot(222)
            ax3 = self.canvas.figure.add_subplot(212)

            # 显示初始状态
            initial_grid = np.array(initial_state).reshape(size, size)
            ax1.imshow(initial_grid, cmap='gray', interpolation='nearest')
            ax1.set_title('初始状态 (有噪声)')
            ax1.set_xticks([])
            ax1.set_yticks([])

            # 显示最终状态
            final_grid = np.array(final_state).reshape(size, size)
            ax2.imshow(final_grid, cmap='gray', interpolation='nearest')
            ax2.set_title('收敛后状态')
            ax2.set_xticks([])
            ax2.set_yticks([])

        else:
            # 一维显示
            ax1 = self.canvas.figure.add_subplot(221)
            ax2 = self.canvas.figure.add_subplot(222)
            ax3 = self.canvas.figure.add_subplot(212)

            ax1.plot(initial_state, 'bo-')
            ax1.set_title('初始状态 (有噪声)')
            ax1.set_xlabel('神经元索引')
            ax1.set_ylabel('状态')

            ax2.plot(final_state, 'ro-')
            ax2.set_title('收敛后状态')
            ax2.set_xlabel('神经元索引')
            ax2.set_ylabel('状态')

        # 绘制能量变化
        ax3.plot(energy_history, 'g-', linewidth=2)
        ax3.set_title('能量收敛过程')
        ax3.set_xlabel('迭代次数')
        ax3.set_ylabel('能量')
        ax3.grid(True, alpha=0.3)

        self.canvas.figure.tight_layout()
        self.canvas.draw()


class DiscreteHopfieldNetwork:
    def __init__(self, n_neurons):
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.energy_history = []

    def train(self, patterns):
        """训练网络使用Hebb规则"""
        for pattern in patterns:
            pattern = np.array(pattern)
            pattern[pattern == 0] = -1  # 转换为±1表示
            self.weights += np.outer(pattern, pattern)
        np.fill_diagonal(self.weights, 0)  # 对角线置零

    def asynchronous_update(self, state, iterations=100, convergence_threshold=0.001):
        """异步更新"""
        state = state.copy()
        state[state == 0] = -1
        energy_history = []

        for i in range(iterations):
            # 随机选择神经元更新
            neuron_idx = np.random.randint(self.n_neurons)
            activation = np.dot(self.weights[neuron_idx], state)
            new_value = 1 if activation >= 0 else -1

            if new_value != state[neuron_idx]:
                state[neuron_idx] = new_value

            # 计算能量
            energy = -0.5 * np.dot(state, np.dot(self.weights, state))
            energy_history.append(energy)

            # 检查是否达到稳定状态
            if i > 10 and len(set(energy_history[-10:])) == 1:
                break

            # 检查能量变化是否小于阈值
            if i > 10 and abs(energy_history[-1] - energy_history[-2]) < convergence_threshold:
                break

        self.energy_history = energy_history
        state[state == -1] = 0
        return state, energy_history

    def calculate_energy(self, state):
        """计算状态能量"""
        state = np.array(state)
        state[state == 0] = -1
        return -0.5 * np.dot(state, np.dot(self.weights, state))