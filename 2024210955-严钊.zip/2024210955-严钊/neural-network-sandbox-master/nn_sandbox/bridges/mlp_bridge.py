# import time
#
# import PyQt5.QtCore
#
# from nn_sandbox.backend.algorithms import MlpAlgorithm
# from . import Bridge, BridgeProperty
# from .observer import Observable
#
#
# class MlpBridge(Bridge):
#     ui_refresh_interval = BridgeProperty(0.0)
#     dataset_dict = BridgeProperty({})
#     training_dataset = BridgeProperty([])
#     testing_dataset = BridgeProperty([])
#     current_dataset_name = BridgeProperty('')
#     total_epoches = BridgeProperty(10)
#     most_correct_rate_checkbox = BridgeProperty(True)
#     most_correct_rate = BridgeProperty(0.98)
#     initial_learning_rate = BridgeProperty(0.8)
#     search_iteration_constant = BridgeProperty(10000)
#     momentum_weight = BridgeProperty(0.5)
#     test_ratio = BridgeProperty(0.3)
#     network_shape = BridgeProperty([5, 5])
#     current_iterations = BridgeProperty(0)
#     current_learning_rate = BridgeProperty(0.0)
#     best_correct_rate = BridgeProperty(0.0)
#     current_correct_rate = BridgeProperty(0.0)
#     test_correct_rate = BridgeProperty(0.0)
#     has_finished = BridgeProperty(True)
#
#     def __init__(self):
#         super().__init__()
#         self.mlp_algorithm = None
#
#     @PyQt5.QtCore.pyqtSlot()
#     def start_mlp_algorithm(self):
#         self.mlp_algorithm = ObservableMlpAlgorithm(
#             self,
#             self.ui_refresh_interval,
#             dataset=self.dataset_dict[self.current_dataset_name],
#             total_epoches=self.total_epoches,
#             most_correct_rate=self._most_correct_rate,
#             initial_learning_rate=self.initial_learning_rate,
#             search_iteration_constant=self.search_iteration_constant,
#             momentum_weight=self.momentum_weight,
#             test_ratio=self.test_ratio,
#             network_shape=self.network_shape
#         )
#         self.mlp_algorithm.start()
#
#     @PyQt5.QtCore.pyqtSlot()
#     def stop_mlp_algorithm(self):
#         self.mlp_algorithm.stop()
#
#     @property
#     def _most_correct_rate(self):
#         if self.most_correct_rate_checkbox:
#             return self.most_correct_rate
#         return None
#
#
# class ObservableMlpAlgorithm(Observable, MlpAlgorithm):
#     def __init__(self, observer, ui_refresh_interval, **kwargs):
#         Observable.__init__(self, observer)
#         MlpAlgorithm.__init__(self, **kwargs)
#         self.ui_refresh_interval = ui_refresh_interval
#
#     def __setattr__(self, name, value):
#         super().__setattr__(name, value)
#         if name == 'current_iterations':
#             self.notify(name, value)
#             self.notify('test_correct_rate', self.test())
#         elif name in ('best_correct_rate', 'current_correct_rate'):
#             self.notify(name, value)
#         elif name in ('training_dataset', 'testing_dataset') and value is not None:
#             self.notify(name, value.tolist())
#
#     def run(self):
#         self.notify('has_finished', False)
#         self.notify('test_correct_rate', 0)
#         super().run()
#         self.notify('test_correct_rate', self.test())
#         self.notify('has_finished', True)
#
#     def _iterate(self):
#         super()._iterate()
#         # the following line keeps the GUI from blocking
#         time.sleep(self.ui_refresh_interval)
#
#     @property
#     def current_learning_rate(self):
#         ret = super().current_learning_rate
#         self.notify('current_learning_rate', ret)
#         return ret


# import time
# import PyQt5.QtCore
#
# from nn_sandbox.backend.algorithms import MlpAlgorithm
# from . import Bridge, BridgeProperty
# from .observer import Observable
#
#
# class MlpBridge(Bridge):
#     ui_refresh_interval = BridgeProperty(0.0)
#     dataset_dict = BridgeProperty({})
#     training_dataset = BridgeProperty([])
#     testing_dataset = BridgeProperty([])
#     current_dataset_name = BridgeProperty('')
#     total_epoches = BridgeProperty(10)
#     most_correct_rate_checkbox = BridgeProperty(True)
#     most_correct_rate = BridgeProperty(0.98)
#     initial_learning_rate = BridgeProperty(0.8)
#     search_iteration_constant = BridgeProperty(10000)
#     momentum_weight = BridgeProperty(0.5)
#     test_ratio = BridgeProperty(0.3)
#
#     # 新增：各层节点数配置
#     network_shape = BridgeProperty([5, 5])
#     input_layer_size = BridgeProperty(2)  # 根据数据集自动调整
#     hidden_layer1_size = BridgeProperty(5)
#     hidden_layer2_size = BridgeProperty(5)
#     output_layer_size = BridgeProperty(1)
#
#     # 新增：各层学习率
#     input_layer_lr = BridgeProperty(0.8)
#     hidden_layer1_lr = BridgeProperty(0.8)
#     hidden_layer2_lr = BridgeProperty(0.8)
#     output_layer_lr = BridgeProperty(0.8)
#
#     # 新增：权重初始化范围
#     weight_init_min = BridgeProperty(-1.0)
#     weight_init_max = BridgeProperty(1.0)
#
#     current_iterations = BridgeProperty(0)
#     current_learning_rate = BridgeProperty(0.0)
#     best_correct_rate = BridgeProperty(0.0)
#     current_correct_rate = BridgeProperty(0.0)
#     test_correct_rate = BridgeProperty(0.0)
#     has_finished = BridgeProperty(True)
#
#     def __init__(self):
#         super().__init__()
#         self.mlp_algorithm = None
#
#     @PyQt5.QtCore.pyqtSlot()
#     def start_mlp_algorithm(self):
#         # 构建网络结构
#         network_shape = []
#         if self.hidden_layer1_size > 0:
#             network_shape.append(self.hidden_layer1_size)
#         if self.hidden_layer2_size > 0:
#             network_shape.append(self.hidden_layer2_size)
#
#         # 构建各层学习率
#         learning_rates = [
#             self.input_layer_lr,
#             self.hidden_layer1_lr,
#             self.hidden_layer2_lr,
#             self.output_layer_lr
#         ]
#
#         self.mlp_algorithm = ObservableMlpAlgorithm(
#             self,
#             self.ui_refresh_interval,
#             dataset=self.dataset_dict[self.current_dataset_name],
#             total_epoches=self.total_epoches,
#             most_correct_rate=self._most_correct_rate,
#             initial_learning_rate=self.initial_learning_rate,
#             search_iteration_constant=self.search_iteration_constant,
#             momentum_weight=self.momentum_weight,
#             test_ratio=self.test_ratio,
#             network_shape=network_shape,
#             learning_rates=learning_rates,
#             weight_init_range=(self.weight_init_min, self.weight_init_max)
#         )
#         self.mlp_algorithm.start()
#
#     @PyQt5.QtCore.pyqtSlot()
#     def stop_mlp_algorithm(self):
#         if self.mlp_algorithm:
#             self.mlp_algorithm.stop()
#
#     @property
#     def _most_correct_rate(self):
#         if self.most_correct_rate_checkbox:
#             return self.most_correct_rate
#         return None
#
#
# class ObservableMlpAlgorithm(Observable, MlpAlgorithm):
#     def __init__(self, observer, ui_refresh_interval, **kwargs):
#         Observable.__init__(self, observer)
#         MlpAlgorithm.__init__(self, **kwargs)
#         self.ui_refresh_interval = ui_refresh_interval
#
#     def __setattr__(self, name, value):
#         super().__setattr__(name, value)
#         if name == 'current_iterations':
#             self.notify(name, value)
#             self.notify('test_correct_rate', self.test())
#         elif name in ('best_correct_rate', 'current_correct_rate'):
#             self.notify(name, value)
#         elif name in ('training_dataset', 'testing_dataset') and value is not None:
#             self.notify(name, value.tolist())
#
#     def run(self):
#         self.notify('has_finished', False)
#         self.notify('test_correct_rate', 0)
#         super().run()
#         self.notify('test_correct_rate', self.test())
#         self.notify('has_finished', True)
#
#     def _iterate(self):
#         super()._iterate()
#         # the following line keeps the GUI from blocking
#         time.sleep(self.ui_refresh_interval)
#
#     @property
#     def current_learning_rate(self):
#         ret = super().current_learning_rate
#         self.notify('current_learning_rate', ret)
#         return ret

import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import MlpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class MlpBridge(Bridge):
    """Bridge between QML UI and MLP algorithm."""

    # -------------------- QML 可绑定属性 --------------------
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    momentum_weight = BridgeProperty(0.5)
    test_ratio = BridgeProperty(0.3)
    network_shape = BridgeProperty([5, 5])  # 支持 QML 输入任意层结构，如 [10, 8]
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.mlp_algorithm = None

    # -------------------- 启动算法 --------------------
    @PyQt5.QtCore.pyqtSlot()
    def start_mlp_algorithm(self):
        self.mlp_algorithm = ObservableMlpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            momentum_weight=self.momentum_weight,
            test_ratio=self.test_ratio,
            network_shape=self.network_shape
        )
        self.mlp_algorithm.start()

    # -------------------- 停止算法 --------------------
    @PyQt5.QtCore.pyqtSlot()
    def stop_mlp_algorithm(self):
        if self.mlp_algorithm:
            self.mlp_algorithm.stop()

    # -------------------- 可选的最优正确率设置 --------------------
    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableMlpAlgorithm(Observable, MlpAlgorithm):
    """Observable version of MLP algorithm for UI notification."""

    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        MlpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 同步 UI 状态更新
        if name == 'current_iterations':
            self.notify(name, value)
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 防止阻塞 UI
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
