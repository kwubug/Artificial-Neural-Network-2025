"""测试三种优化算法"""
import numpy as np
from bp_optimizers import BPNeuralNetwork, generate_classification_data, generate_xor_data
import matplotlib.pyplot as plt


def test_optimizer(optimizer_name, epochs=50):
    """测试单个优化器"""
    print(f"\n{'='*50}")
    print(f"测试优化器: {optimizer_name}")
    print(f"{'='*50}")
    
    # 生成数据
    X, y = generate_classification_data(n_samples=100)
    
    # 创建网络
    network = BPNeuralNetwork(
        input_size=2,
        hidden_size=4,
        output_size=1,
        optimizer=optimizer_name,
        learning_rate=0.1
    )
    
    # 训练
    losses = []
    accuracies = []
    
    for epoch in range(epochs):
        loss = network.train_step(X, y)
        
        # 计算准确率
        predictions = network.predict(X)
        accuracy = np.mean((predictions > 0.5) == y)
        
        losses.append(loss)
        accuracies.append(accuracy)
        
        if (epoch + 1) % 10 == 0:
            print(f"Epoch {epoch+1}/{epochs} - Loss: {loss:.6f}, Accuracy: {accuracy*100:.2f}%")
    
    print(f"\n最终结果:")
    print(f"  损失: {losses[-1]:.6f}")
    print(f"  准确率: {accuracies[-1]*100:.2f}%")
    
    return losses, accuracies


def compare_optimizers():
    """比较三种优化器"""
    optimizers = ['gradient_descent', 'newton', 'conjugate_gradient']
    results = {}
    
    for opt in optimizers:
        losses, accuracies = test_optimizer(opt, epochs=100)
        results[opt] = {'losses': losses, 'accuracies': accuracies}
    
    # 绘制比较图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # 损失曲线
    for opt in optimizers:
        label_map = {
            'gradient_descent': '梯度下降法',
            'newton': '牛顿法',
            'conjugate_gradient': '共轭梯度法'
        }
        ax1.plot(results[opt]['losses'], label=label_map[opt], linewidth=2)
    
    ax1.set_xlabel('训练轮次', fontsize=12)
    ax1.set_ylabel('损失值', fontsize=12)
    ax1.set_title('三种优化算法的损失曲线比较', fontsize=14, fontweight='bold')
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)
    ax1.set_yscale('log')
    
    # 准确率曲线
    for opt in optimizers:
        label_map = {
            'gradient_descent': '梯度下降法',
            'newton': '牛顿法',
            'conjugate_gradient': '共轭梯度法'
        }
        ax2.plot([acc * 100 for acc in results[opt]['accuracies']], 
                label=label_map[opt], linewidth=2)
    
    ax2.set_xlabel('训练轮次', fontsize=12)
    ax2.set_ylabel('准确率 (%)', fontsize=12)
    ax2.set_title('三种优化算法的准确率比较', fontsize=14, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)
    ax2.set_ylim([0, 105])
    
    plt.tight_layout()
    plt.savefig('/home/irelia/app/GradientDescentViz/optimizer_comparison.png', dpi=150)
    print(f"\n比较图已保存至: optimizer_comparison.png")
    plt.show()


if __name__ == "__main__":
    print("BP神经网络优化算法测试")
    print("="*50)
    
    # 比较三种优化器
    compare_optimizers()
    
    print("\n测试完成！")

