import os
import warnings
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib')
import torch
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


class DiscreteHopfieldNetwork:
    def __init__(self, n_neurons):
        self.n_neurons = n_neurons
        self.weights = torch.zeros((n_neurons, n_neurons))
        self.energy_history = []
        self.state_history = []

    def hebbian_learning(self, patterns):
        n_patterns = patterns.shape[0]
        self.weights = torch.zeros((self.n_neurons, self.n_neurons))

        # w_ij = Σ x_i * x_j (i ≠ j)
        for pattern in patterns:
            pattern = pattern.unsqueeze(1)
            self.weights += pattern @ pattern.T

        self.weights.fill_diagonal_(0)
        self.weights /= n_patterns

    def energy(self, state):
        """E = -½ ΣΣ w_ij s_i s_j"""
        return -0.5 * torch.sum(self.weights * torch.outer(state, state))

    def async_update(self, state, max_iterations=100, update_order='random'):
        current_state = state.clone()
        self.energy_history = [self.energy(current_state).item()]
        self.state_history = [current_state.clone()]

        for iteration in range(max_iterations):
            if update_order == 'random':
                update_sequence = torch.randperm(self.n_neurons)
            else:
                update_sequence = torch.arange(self.n_neurons)

            state_changed = False
            for neuron_idx in update_sequence:
                input_sum = torch.sum(self.weights[neuron_idx] * current_state)
                new_state = 1 if input_sum >= 0 else -1

                if new_state != current_state[neuron_idx]:
                    current_state[neuron_idx] = new_state
                    state_changed = True

            self.energy_history.append(self.energy(current_state).item())
            self.state_history.append(current_state.clone())

            if not state_changed:
                break

        return current_state


def create_letter_patterns():
    patterns = []

    A = torch.tensor([
        1, 1, 1, 1,
        1, -1, -1, 1,
        1, 1, 1, 1,
        1, -1, -1, 1
    ], dtype=torch.float32)

    B = torch.tensor([
        1, 1, 1, -1,
        1, -1, -1, 1,
        1, 1, 1, -1,
        1, -1, -1, 1
    ], dtype=torch.float32)

    C = torch.tensor([
        1, 1, 1, 1,
        1, -1, -1, -1,
        1, -1, -1, -1,
        1, 1, 1, 1
    ], dtype=torch.float32)

    patterns = torch.stack([A, B, C])
    return patterns


def visualize_patterns(patterns, title="Stored Patterns"):
    n_patterns = patterns.shape[0]

    fig, axes = plt.subplots(1, n_patterns, figsize=(4 * n_patterns, 4))
    if n_patterns == 1:
        axes = [axes]

    letters = ['A', 'B', 'C']
    for i, ax in enumerate(axes):
        pattern_matrix = patterns[i].reshape(4, 4)
        im = ax.imshow(pattern_matrix, cmap='binary', vmin=-1, vmax=1)
        ax.set_title(f'Letter {letters[i]}')
        ax.set_xticks([])
        ax.set_yticks([])

        for j in range(4):
            for k in range(4):
                color = 'white' if pattern_matrix[j, k] == 1 else 'black'
                symbol = '■' if pattern_matrix[j, k] == 1 else '□'
                ax.text(k, j, symbol, ha='center', va='center',
                        color=color, fontsize=16, fontweight='bold')

    plt.suptitle(title, fontsize=16)
    plt.tight_layout()
    plt.show()


def visualize_energy_dynamics(hopfield_net):
    plt.figure(figsize=(15, 5))
    plt.subplot(1, 3, 1)
    plt.plot(hopfield_net.energy_history, 'b-o', linewidth=2, markersize=4)
    plt.xlabel('Iteration')
    plt.ylabel('Energy')
    plt.title('Energy Evolution Over Time')
    plt.grid(True, alpha=0.3)

    plt.subplot(1, 3, 2)
    state_matrix = torch.stack(hopfield_net.state_history).numpy()
    plt.imshow(state_matrix, cmap='coolwarm', aspect='auto', interpolation='nearest')
    plt.colorbar(label='Neuron State')
    plt.xlabel('Neuron Index')
    plt.ylabel('Iteration')
    plt.title('State Evolution Heatmap')

    plt.subplot(1, 3, 3)
    final_state = hopfield_net.state_history[-1]
    pattern_matrix = final_state.reshape(4, 4)
    plt.imshow(pattern_matrix, cmap='binary', vmin=-1, vmax=1)
    plt.title('Final Attractor State')
    plt.xticks([])
    plt.yticks([])

    for i in range(4):
        for j in range(4):
            color = 'white' if pattern_matrix[i, j] == 1 else 'black'
            symbol = '■' if pattern_matrix[i, j] == 1 else '□'
            plt.text(j, i, symbol, ha='center', va='center',
                     color=color, fontsize=16, fontweight='bold')

    plt.tight_layout()
    plt.show()


def test_pattern_recovery(hopfield_net, patterns):
    for i, pattern in enumerate(patterns):
        noise_level = 0.3
        noisy_pattern = pattern.clone()
        noise_mask = torch.rand_like(noisy_pattern) < noise_level
        noisy_pattern[noise_mask] *= -1

        recovered = hopfield_net.async_update(noisy_pattern, max_iterations=50)

        accuracy = torch.mean((pattern == recovered).float()).item()

        visualize_recovery_process(pattern, noisy_pattern, recovered, hopfield_net, i)


def visualize_recovery_process(original, noisy, recovered, hopfield_net, pattern_idx):
    fig, axes = plt.subplots(1, 4, figsize=(16, 4))

    patterns = [original, noisy, recovered]
    titles = ['Original Pattern', 'Noisy Pattern', 'Recovered Pattern']
    letters = ['A', 'B', 'C']

    for i, ax in enumerate(axes[:3]):
        pattern_matrix = patterns[i].reshape(4, 4)
        ax.imshow(pattern_matrix, cmap='binary', vmin=-1, vmax=1)
        ax.set_title(f'{titles[i]}\nLetter {letters[pattern_idx]}')
        ax.set_xticks([])
        ax.set_yticks([])

        for j in range(4):
            for k in range(4):
                color = 'white' if pattern_matrix[j, k] == 1 else 'black'
                symbol = '■' if pattern_matrix[j, k] == 1 else '□'
                ax.text(k, j, symbol, ha='center', va='center',
                        color=color, fontsize=12, fontweight='bold')

    axes[3].plot(hopfield_net.energy_history, 'r-o', linewidth=2)
    axes[3].set_xlabel('Iteration')
    axes[3].set_ylabel('Energy')
    axes[3].set_title('Energy Convergence Process')
    axes[3].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


def create_attractor_basin_analysis(hopfield_net, n_test=100):
    test_patterns = torch.randint(0, 2, (n_test, 16)) * 2 - 1
    attractors = {}
    basin_sizes = {}

    for i, pattern in enumerate(test_patterns):
        final_state = hopfield_net.async_update(pattern.clone(), max_iterations=50)
        state_str = ''.join(str(int(x)) for x in final_state)

        if state_str not in attractors:
            attractors[state_str] = final_state
            basin_sizes[state_str] = 1
        else:
            basin_sizes[state_str] += 1

    print(f"Found {len(attractors)} attractors")

    visualize_attractors(attractors, basin_sizes)


def visualize_attractors(attractors, basin_sizes):
    n_attractors = len(attractors)

    fig, axes = plt.subplots(1, n_attractors, figsize=(4 * n_attractors, 4))
    if n_attractors == 1:
        axes = [axes]

    for i, (state_str, attractor) in enumerate(attractors.items()):
        basin_size = basin_sizes[state_str]
        pattern_matrix = attractor.reshape(4, 4)

        axes[i].imshow(pattern_matrix, cmap='binary', vmin=-1, vmax=1)
        axes[i].set_title(f'Attractor {i + 1}\nBasin Size: {basin_size}')
        axes[i].set_xticks([])
        axes[i].set_yticks([])

        for j in range(4):
            for k in range(4):
                color = 'white' if pattern_matrix[j, k] == 1 else 'black'
                symbol = '■' if pattern_matrix[j, k] == 1 else '□'
                axes[i].text(k, j, symbol, ha='center', va='center',
                             color=color, fontsize=12, fontweight='bold')

    plt.suptitle('Attractors and Their Basins', fontsize=16)
    plt.tight_layout()
    plt.show()


def create_animated_convergence(hopfield_net, pattern, noise_level=0.4):
    noisy_pattern = pattern.clone()
    noise_mask = torch.rand_like(noisy_pattern) < noise_level
    noisy_pattern[noise_mask] *= -1

    final_state = hopfield_net.async_update(noisy_pattern, max_iterations=100)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    def animate(frame):
        ax1.clear()
        ax2.clear()

        current_state = hopfield_net.state_history[frame]
        pattern_matrix = current_state.reshape(4, 4)

        ax1.imshow(pattern_matrix, cmap='binary', vmin=-1, vmax=1)
        ax1.set_title(f'Pattern Convergence\nIteration: {frame}')
        ax1.set_xticks([])
        ax1.set_yticks([])

        for j in range(4):
            for k in range(4):
                color = 'white' if pattern_matrix[j, k] == 1 else 'black'
                symbol = '■' if pattern_matrix[j, k] == 1 else '□'
                ax1.text(k, j, symbol, ha='center', va='center',
                         color=color, fontsize=12, fontweight='bold')

        ax2.plot(hopfield_net.energy_history[:frame + 1], 'b-o', linewidth=2)
        ax2.set_xlim(0, len(hopfield_net.energy_history))
        ax2.set_ylim(min(hopfield_net.energy_history), max(hopfield_net.energy_history))
        ax2.set_xlabel('Iteration')
        ax2.set_ylabel('Energy')
        ax2.set_title('Energy Convergence')
        ax2.grid(True, alpha=0.3)

        return ax1, ax2

    anim = FuncAnimation(fig, animate, frames=len(hopfield_net.state_history),
                         interval=500, repeat=False)

    plt.tight_layout()
    plt.show()

    return anim


def main():
    patterns = create_letter_patterns()
    visualize_patterns(patterns)

    hopfield_net = DiscreteHopfieldNetwork(16)
    hopfield_net.hebbian_learning(patterns)

    test_pattern_recovery(hopfield_net, patterns)

    create_attractor_basin_analysis(hopfield_net, n_test=50)

    demo_pattern = patterns[0].clone()

    noise_mask = torch.rand_like(demo_pattern) < 0.4
    demo_pattern[noise_mask] *= -1

    final_state = hopfield_net.async_update(demo_pattern, max_iterations=100)
    visualize_energy_dynamics(hopfield_net)

    create_animated_convergence(hopfield_net, patterns[0])

if __name__ == "__main__":
    main()