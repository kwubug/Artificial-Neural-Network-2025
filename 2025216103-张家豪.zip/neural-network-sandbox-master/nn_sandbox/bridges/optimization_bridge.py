import time
import numpy as np

import PyQt5.QtCore

from nn_sandbox.backend.algorithms.optimization_algorithm import (
    OptimizationAlgorithm, TestFunctions
)
from . import Bridge, BridgeProperty
from .observer import Observable


class OptimizationBridge(Bridge):
    """优化算法桥接类"""
    
    ui_refresh_interval = BridgeProperty(0.05)
    
    # 算法参数
    max_iterations = BridgeProperty(100)
    tolerance = BridgeProperty(1e-6)
    initial_x = BridgeProperty(-1.0)
    initial_y = BridgeProperty(1.0)
    optimization_method = BridgeProperty('steepest')  # 'steepest', 'newton', 'conjugate'
    test_function = BridgeProperty('rosenbrock')  # 'rosenbrock', 'sphere', 'beale', 'booth'
    
    # 状态信息
    current_iteration = BridgeProperty(0)
    current_x = BridgeProperty(0.0)
    current_y = BridgeProperty(0.0)
    current_loss = BridgeProperty(0.0)
    current_gradient_norm = BridgeProperty(0.0)
    has_converged = BridgeProperty(False)
    has_finished = BridgeProperty(True)
    
    # 优化轨迹
    trajectory = BridgeProperty([])
    loss_history = BridgeProperty([])
    gradient_norm_history = BridgeProperty([])
    
    def __init__(self):
        super().__init__()
        self.optimization_algorithm = None
    
    @PyQt5.QtCore.pyqtSlot()
    def start_optimization(self):
        """开始优化"""
        # 获取目标函数和梯度
        func_map = {
            'rosenbrock': (TestFunctions.rosenbrock, 
                          TestFunctions.rosenbrock_gradient,
                          TestFunctions.rosenbrock_hessian),
            'sphere': (TestFunctions.sphere, 
                      TestFunctions.sphere_gradient,
                      TestFunctions.sphere_hessian),
            'beale': (TestFunctions.beale, 
                     TestFunctions.beale_gradient,
                     TestFunctions.beale_hessian),
            'booth': (TestFunctions.booth, 
                     TestFunctions.booth_gradient,
                     TestFunctions.booth_hessian),
        }
        
        obj_func, grad_func, hess_func = func_map[self.test_function]
        initial_point = np.array([self.initial_x, self.initial_y])
        
        self.optimization_algorithm = ObservableOptimizationAlgorithm(
            self,
            self.ui_refresh_interval,
            objective_func=obj_func,
            gradient_func=grad_func,
            hessian_func=hess_func,
            initial_point=initial_point,
            max_iterations=self.max_iterations,
            tolerance=self.tolerance,
            method=self.optimization_method
        )
        self.optimization_algorithm.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_optimization(self):
        """停止优化"""
        if self.optimization_algorithm:
            self.optimization_algorithm.stop()
    
    @PyQt5.QtCore.pyqtSlot(float, float, result=float)
    def evaluate_function(self, x, y):
        """评估函数值（用于绘制3D曲面）"""
        func_map = {
            'rosenbrock': TestFunctions.rosenbrock,
            'sphere': TestFunctions.sphere,
            'beale': TestFunctions.beale,
            'booth': TestFunctions.booth,
        }
        
        obj_func = func_map[self.test_function]
        return float(obj_func(np.array([x, y])))


class ObservableOptimizationAlgorithm(Observable, OptimizationAlgorithm):
    """可观察的优化算法"""
    
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        OptimizationAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        
        if name == 'current_iteration':
            self.notify(name, value)
        elif name == 'current_point' and value is not None:
            self.notify('current_x', float(value[0]))
            self.notify('current_y', float(value[1]))
        elif name == 'current_loss':
            self.notify(name, float(value))
        elif name == 'current_gradient_norm':
            self.notify(name, float(value))
        elif name == 'has_converged':
            self.notify(name, value)
        elif name == 'trajectory' and isinstance(value, list) and len(value) > 0:
            # 转换为可以传给QML的格式
            trajectory_list = [[float(p[0]), float(p[1])] for p in value]
            self.notify(name, trajectory_list)
        elif name == 'loss_history' and isinstance(value, list):
            self.notify(name, [float(v) for v in value])
        elif name == 'gradient_norm_history' and isinstance(value, list):
            self.notify(name, [float(v) for v in value])
    
    def run(self):
        """运行优化算法"""
        self.notify('has_finished', False)
        self.notify('has_converged', False)
        self.notify('trajectory', [])
        self.notify('loss_history', [])
        self.notify('gradient_norm_history', [])
        
        super().run()
        
        # 通知最终结果
        if self.trajectory:
            trajectory_list = [[float(p[0]), float(p[1])] for p in self.trajectory]
            self.notify('trajectory', trajectory_list)
        if self.loss_history:
            self.notify('loss_history', [float(v) for v in self.loss_history])
        if self.gradient_norm_history:
            self.notify('gradient_norm_history', [float(v) for v in self.gradient_norm_history])
        
        self.notify('has_finished', True)
        time.sleep(0.1)  # 确保UI有时间更新
    
    def _steepest_descent(self):
        """重写最速下降法以添加UI刷新"""
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            grad = self.gradient_func(x)
            grad_norm = np.linalg.norm(grad)
            
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            alpha = self._armijo_line_search(x, -grad)
            x = x - alpha * grad
            
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
            
            # UI刷新延迟
            time.sleep(self.ui_refresh_interval)
    
    def _newton_method(self):
        """重写牛顿法以添加UI刷新"""
        if self.hessian_func is None:
            raise ValueError("Newton method requires hessian function")
            
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            grad = self.gradient_func(x)
            hess = self.hessian_func(x)
            
            grad_norm = np.linalg.norm(grad)
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            try:
                hess_reg = hess + 1e-6 * np.eye(len(x))
                direction = -np.linalg.solve(hess_reg, grad)
            except np.linalg.LinAlgError:
                direction = -grad
            
            alpha = self._armijo_line_search(x, direction)
            x = x + alpha * direction
            
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
            
            # UI刷新延迟
            time.sleep(self.ui_refresh_interval)
    
    def _conjugate_gradient(self):
        """重写共轭梯度法以添加UI刷新"""
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        grad = self.gradient_func(x)
        direction = -grad.copy()
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            grad_norm = np.linalg.norm(grad)
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            alpha = self._armijo_line_search(x, direction)
            x_new = x + alpha * direction
            grad_new = self.gradient_func(x_new)
            
            beta = np.dot(grad_new, grad_new) / (np.dot(grad, grad) + 1e-10)
            direction = -grad_new + beta * direction
            
            x = x_new
            grad = grad_new
            
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
            
            # UI刷新延迟
            time.sleep(self.ui_refresh_interval)



