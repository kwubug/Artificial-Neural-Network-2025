import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import time

plt.rcParams['font.sans-serif'] = ['SimHei']
class ConjugateGradient:
    def __init__(self, A, b, x0=None):
        """
        共轭梯度法求解 Ax = b

        参数:
        A: 对称正定矩阵
        b: 右侧向量
        x0: 初始解 (默认为零向量)
        """
        self.A = np.array(A)
        self.b = np.array(b)
        self.n = len(b)

        if x0 is None:
            self.x0 = np.zeros(self.n)
        else:
            self.x0 = np.array(x0)

        # 验证矩阵对称正定性
        if not np.allclose(self.A, self.A.T):
            print("警告: 矩阵A不是对称矩阵")

        self.history = {'x': [], 'residual': [], 'gradient': []}

    def solve(self, max_iter=1000, tol=1e-6):
        """
        执行共轭梯度法

        参数:
        max_iter: 最大迭代次数
        tol: 收敛容差

        返回:
        x: 最优解
        """
        x = self.x0.copy()
        r = self.b - self.A @ x  # 残差
        p = r.copy()  # 搜索方向

        self.history['x'].append(x.copy())
        self.history['residual'].append(np.linalg.norm(r))
        self.history['gradient'].append(r.copy())

        for k in range(max_iter):
            Ap = self.A @ p
            alpha = np.dot(r, r) / np.dot(p, Ap)
            x_new = x + alpha * p
            r_new = r - alpha * Ap

            # 记录历史
            self.history['x'].append(x_new.copy())
            self.history['residual'].append(np.linalg.norm(r_new))
            self.history['gradient'].append(r_new.copy())

            # 检查收敛
            if np.linalg.norm(r_new) < tol:
                print(f"在 {k + 1} 次迭代后收敛")
                break

            beta = np.dot(r_new, r_new) / np.dot(r, r)
            p = r_new + beta * p

            x = x_new
            r = r_new
        else:
            print(f"达到最大迭代次数 {max_iter}")

        return x

    def plot_convergence_2d(self, true_solution=None):
        """绘制二维问题的收敛过程"""
        if self.n != 2:
            print("只能绘制二维问题的收敛过程")
            return

        # 创建等高线图
        x1 = np.linspace(-2, 2, 100)
        x2 = np.linspace(-2, 2, 100)
        X1, X2 = np.meshgrid(x1, x2)

        # 计算二次型函数值
        Z = np.zeros_like(X1)
        for i in range(len(x1)):
            for j in range(len(x2)):
                x_vec = np.array([X1[i, j], X2[i, j]])
                Z[i, j] = 0.5 * x_vec.T @ self.A @ x_vec - self.b.T @ x_vec

        plt.figure(figsize=(15, 5))

        # 子图1: 等高线图和优化路径
        plt.subplot(1, 3, 1)
        contours = plt.contour(X1, X2, Z, levels=20, alpha=0.6)
        plt.clabel(contours, inline=True, fontsize=8)

        x_history = np.array(self.history['x'])
        plt.plot(x_history[:, 0], x_history[:, 1], 'ro-', markersize=4, linewidth=1, label='优化路径')
        plt.plot(x_history[0, 0], x_history[0, 1], 'go', markersize=8, label='起始点')
        plt.plot(x_history[-1, 0], x_history[-1, 1], 'bo', markersize=8, label='最终点')

        if true_solution is not None:
            plt.plot(true_solution[0], true_solution[1], 'k*', markersize=12, label='真实解')

        plt.xlabel('x1')
        plt.ylabel('x2')
        plt.title('共轭梯度法优化路径')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.axis('equal')

        # 子图2: 残差收敛
        plt.subplot(1, 3, 2)
        residuals = self.history['residual']
        plt.semilogy(range(len(residuals)), residuals, 'b-', linewidth=2)
        plt.xlabel('迭代次数')
        plt.ylabel('残差范数 (log scale)')
        plt.title('残差收敛')
        plt.grid(True, alpha=0.3)

        # 子图3: 梯度范数
        plt.subplot(1, 3, 3)
        gradients = [np.linalg.norm(g) for g in self.history['gradient']]
        plt.semilogy(range(len(gradients)), gradients, 'r-', linewidth=2)
        plt.xlabel('迭代次数')
        plt.ylabel('梯度范数 (log scale)')
        plt.title('梯度范数变化')
        plt.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def plot_3d_surface(self):
        """绘制三维曲面（仅适用于二维问题）"""
        if self.n != 2:
            print("只能绘制二维问题的三维曲面")
            return

        x1 = np.linspace(-2, 2, 50)
        x2 = np.linspace(-2, 2, 50)
        X1, X2 = np.meshgrid(x1, x2)

        Z = np.zeros_like(X1)
        for i in range(len(x1)):
            for j in range(len(x2)):
                x_vec = np.array([X1[i, j], X2[i, j]])
                Z[i, j] = 0.5 * x_vec.T @ self.A @ x_vec - self.b.T @ x_vec

        fig = plt.figure(figsize=(12, 5))

        # 3D曲面
        ax1 = fig.add_subplot(1, 2, 1, projection='3d')
        surf = ax1.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.8)

        x_history = np.array(self.history['x'])
        z_history = [0.5 * x.T @ self.A @ x - self.b.T @ x for x in x_history]

        ax1.plot(x_history[:, 0], x_history[:, 1], z_history, 'ro-', linewidth=2, markersize=4)
        ax1.plot(x_history[0, 0], x_history[0, 1], z_history[0], 'go', markersize=8, label='起始点')
        ax1.plot(x_history[-1, 0], x_history[-1, 1], z_history[-1], 'bo', markersize=8, label='最终点')

        ax1.set_xlabel('x1')
        ax1.set_ylabel('x2')
        ax1.set_zlabel('f(x)')
        ax1.set_title('目标函数曲面和优化路径')
        ax1.legend()

        # 等高线图
        ax2 = fig.add_subplot(1, 2, 2)
        contours = ax2.contour(X1, X2, Z, levels=20)
        ax2.clabel(contours, inline=True, fontsize=8)
        ax2.plot(x_history[:, 0], x_history[:, 1], 'ro-', markersize=4, linewidth=1)
        ax2.plot(x_history[0, 0], x_history[0, 1], 'go', markersize=8, label='起始点')
        ax2.plot(x_history[-1, 0], x_history[-1, 1], 'bo', markersize=8, label='最终点')

        ax2.set_xlabel('x1')
        ax2.set_ylabel('x2')
        ax2.set_title('等高线图和优化路径')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        ax2.axis('equal')

        plt.tight_layout()
        plt.show()

    def animate_optimization(self, interval=200):
        """创建优化过程动画（仅适用于二维问题）"""
        if self.n != 2:
            print("只能为二维问题创建动画")
            return

        x1 = np.linspace(-2, 2, 100)
        x2 = np.linspace(-2, 2, 100)
        X1, X2 = np.meshgrid(x1, x2)

        Z = np.zeros_like(X1)
        for i in range(len(x1)):
            for j in range(len(x2)):
                x_vec = np.array([X1[i, j], X2[i, j]])
                Z[i, j] = 0.5 * x_vec.T @ self.A @ x_vec - self.b.T @ x_vec

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # 设置等高线图
        contours = ax1.contour(X1, X2, Z, levels=20, alpha=0.6)
        ax1.clabel(contours, inline=True, fontsize=8)
        ax1.set_xlabel('x1')
        ax1.set_ylabel('x2')
        ax1.set_title('共轭梯度法优化过程')
        ax1.grid(True, alpha=0.3)
        ax1.axis('equal')

        # 设置残差图
        ax2.set_xlabel('迭代次数')
        ax2.set_ylabel('残差范数')
        ax2.set_title('残差收敛')
        ax2.grid(True, alpha=0.3)
        ax2.set_yscale('log')

        # 初始化动画元素
        line, = ax1.plot([], [], 'ro-', markersize=4, linewidth=1)
        current_point, = ax1.plot([], [], 'bo', markersize=8)
        residual_line, = ax2.plot([], [], 'b-', linewidth=2)

        x_history = np.array(self.history['x'])
        residuals = self.history['residual']

        def init():
            line.set_data([], [])
            current_point.set_data([], [])
            residual_line.set_data([], [])
            return line, current_point, residual_line

        def update(frame):
            # 更新优化路径
            line.set_data(x_history[:frame + 1, 0], x_history[:frame + 1, 1])
            current_point.set_data([x_history[frame, 0]], [x_history[frame, 1]])

            # 更新残差图
            residual_line.set_data(range(frame + 1), residuals[:frame + 1])
            ax2.relim()
            ax2.autoscale_view()

            return line, current_point, residual_line

        anim = FuncAnimation(fig, update, frames=len(x_history),
                             init_func=init, blit=True, interval=interval)

        plt.tight_layout()
        plt.show()

        return anim


# 示例使用
if __name__ == "__main__":
    print("=== 共轭梯度法演示 ===\n")

    # 示例1: 简单的2x2系统
    print("示例1: 2x2 线性系统")
    A1 = np.array([[4, 1], [1, 3]])
    b1 = np.array([1, 2])
    true_solution = np.linalg.solve(A1, b1)

    print(f"矩阵 A:\n{A1}")
    print(f"向量 b: {b1}")
    print(f"真实解: {true_solution}")

    # 创建共轭梯度求解器
    cg = ConjugateGradient(A1, b1, x0=np.array([-1, -1]))

    # 求解
    start_time = time.time()
    solution = cg.solve(max_iter=100, tol=1e-8)
    end_time = time.time()

    print(f"共轭梯度法解: {solution}")
    print(f"误差: {np.linalg.norm(solution - true_solution):.2e}")
    print(f"计算时间: {end_time - start_time:.4f} 秒")
    print(f"迭代次数: {len(cg.history['x']) - 1}")

    # 可视化
    print("\n生成可视化...")
    cg.plot_convergence_2d(true_solution=true_solution)
    cg.plot_3d_surface()

    # 示例2: 更大的系统
    print("\n示例2: 10x10 对角占优系统")
    n = 10
    np.random.seed(42)
    A2 = np.random.randn(n, n)
    A2 = A2.T @ A2 + n * np.eye(n)  # 确保对称正定
    b2 = np.random.randn(n)

    cg2 = ConjugateGradient(A2, b2)
    solution2 = cg2.solve()
    true_solution2 = np.linalg.solve(A2, b2)

    print(f"系统维度: {n}")
    print(f"共轭梯度法误差: {np.linalg.norm(solution2 - true_solution2):.2e}")
    print(f"迭代次数: {len(cg2.history['x']) - 1}")

    # 绘制残差收敛
    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    residuals = cg2.history['residual']
    plt.semilogy(range(len(residuals)), residuals, 'b-', linewidth=2)
    plt.xlabel('迭代次数')
    plt.ylabel('残差范数')
    plt.title('10x10系统残差收敛')
    plt.grid(True, alpha=0.3)

    plt.subplot(1, 2, 2)
    gradients = [np.linalg.norm(g) for g in cg2.history['gradient']]
    plt.semilogy(range(len(gradients)), gradients, 'r-', linewidth=2)
    plt.xlabel('迭代次数')
    plt.ylabel('梯度范数')
    plt.title('10x10系统梯度范数')
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    print("\n演示完成!")