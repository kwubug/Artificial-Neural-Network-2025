"""
Boltzmann Machine sandbox visualization for a 3-neuron network.

This script simulates the stochastic dynamics of a fully connected
Boltzmann Machine (BM) with three binary neurons, records its trajectory,
estimates the thermal equilibrium distribution, and exports a figure that
summarizes the energy evolution and the state probabilities.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np


np.random.seed(42)


@dataclass(frozen=True)
class SimulationConfig:
    steps: int = 4000
    burn_in: int = 500
    beta_min: float = 0.5
    beta_max: float = 1.5


class BoltzmannMachine:
    def __init__(self, weights: np.ndarray, biases: np.ndarray) -> None:
        self.weights = np.array(weights, dtype=np.float64)
        self.biases = np.array(biases, dtype=np.float64)
        if self.weights.shape[0] != self.weights.shape[1]:
            raise ValueError("Weight matrix must be square.")
        if self.weights.shape[0] != self.biases.shape[0]:
            raise ValueError("Bias vector and weight matrix size mismatch.")
        if not np.allclose(self.weights, self.weights.T, atol=1e-9):
            raise ValueError("Weight matrix must be symmetric.")
        np.fill_diagonal(self.weights, 0.0)
        self.n_units = self.weights.shape[0]

    def energy(self, state: np.ndarray) -> float:
        return -0.5 * state @ self.weights @ state - self.biases @ state

    def sample(self, state: np.ndarray, beta: float) -> np.ndarray:
        updated = state.copy()
        for idx in np.random.permutation(self.n_units):
            total_input = self.weights[idx] @ updated + self.biases[idx]
            prob_on = 1.0 / (1.0 + np.exp(-beta * total_input))
            updated[idx] = 1 if np.random.rand() < prob_on else 0
        return updated

    def run(
        self,
        config: SimulationConfig,
        initial_state: np.ndarray | None = None,
        beta_schedule: Iterable[float] | None = None,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        state = (
            initial_state.copy()
            if initial_state is not None
            else np.random.randint(0, 2, size=self.n_units)
        )
        betas = (
            np.linspace(config.beta_min, config.beta_max, config.steps)
            if beta_schedule is None
            else np.fromiter(beta_schedule, dtype=np.float64, count=config.steps)
        )
        states: List[np.ndarray] = []
        energies: List[float] = []
        for step in range(config.steps):
            beta = betas[step]
            state = self.sample(state, beta)
            states.append(state.copy())
            energies.append(self.energy(state))
        return np.vstack(states), np.asarray(energies), betas


def state_to_str(state: np.ndarray) -> str:
    return "".join(str(bit) for bit in state.astype(int))


def estimate_equilibrium(
    states: np.ndarray, energies: np.ndarray, config: SimulationConfig
) -> Tuple[str, float, List[Tuple[str, float]]]:
    effective_states = states[config.burn_in :]
    counts = {}
    for state in effective_states:
        key = state_to_str(state)
        counts[key] = counts.get(key, 0) + 1
    total = effective_states.shape[0]
    distribution = sorted(
        ((state, count / total) for state, count in counts.items()),
        key=lambda item: item[1],
        reverse=True,
    )
    top_state, top_prob = distribution[0]
    return top_state, top_prob, distribution


def plot_results(
    energies: np.ndarray,
    states: np.ndarray,
    distribution: List[Tuple[str, float]],
    config: SimulationConfig,
    output_path: Path,
) -> None:
    iterations = np.arange(1, energies.size + 1)
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(12, 5))

    axes[0].plot(iterations, energies, color="tab:blue", linewidth=1.2)
    axes[0].axvline(config.burn_in, color="tab:orange", linestyle="--", linewidth=1.0)
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Energy")
    axes[0].set_title("Energy Trajectory")
    axes[0].grid(True, linewidth=0.4, alpha=0.5)

    labels = [item[0] for item in distribution]
    probabilities = [item[1] for item in distribution]
    axes[1].bar(np.arange(len(labels)), probabilities, color="tab:green")
    axes[1].set_xticks(np.arange(len(labels)))
    axes[1].set_xticklabels(labels)
    axes[1].set_xlabel("State (binary)")
    axes[1].set_ylabel("Probability")
    axes[1].set_title("Equilibrium Distribution (post burn-in)")
    axes[1].grid(True, axis="y", linewidth=0.4, alpha=0.5)

    handles = [
        axes[0].lines[0],
        axes[0].lines[1],
    ]
    labels = ["Energy", f"Burn-in ({config.burn_in})"]
    fig.legend(
        handles,
        labels,
        loc="center right",
        bbox_to_anchor=(1.04, 0.5),
        frameon=False,
    )

    fig.tight_layout(rect=(0, 0, 0.92, 1))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def export_summary(
    summary_path: Path,
    config: SimulationConfig,
    top_state: str,
    top_prob: float,
    distribution: List[Tuple[str, float]],
    energies: np.ndarray,
) -> None:
    summary_lines = [
        "Boltzmann Machine (3 units) equilibrium analysis",
        f"Total iterations: {config.steps}",
        f"Burn-in: {config.burn_in}",
        f"Most probable state: {top_state}",
        f"Probability (post burn-in): {top_prob:.4f}",
        f"Mean energy (post burn-in): {np.mean(energies[config.burn_in:]):.4f}",
        "State probabilities (descending):",
    ]
    summary_lines.extend(
        f"  {state}: {prob:.4f}" for state, prob in distribution
    )
    summary_path.write_text("\n".join(summary_lines), encoding="utf-8")


def main() -> None:
    output_dir = Path(__file__).parent
    figure_path = output_dir / "bm_three_neurons_equilibrium.png"
    summary_path = output_dir / "bm_three_neurons_equilibrium.txt"

    weights = np.array(
        [
            [0.0, 1.2, -0.8],
            [1.2, 0.0, 0.6],
            [-0.8, 0.6, 0.0],
        ]
    )
    biases = np.array([-0.4, 0.2, 0.1])
    config = SimulationConfig()

    bm = BoltzmannMachine(weights=weights, biases=biases)
    states, energies, _ = bm.run(config=config)
    top_state, top_prob, distribution = estimate_equilibrium(states, energies, config)
    plot_results(
        energies=energies,
        states=states,
        distribution=distribution,
        config=config,
        output_path=figure_path,
    )
    export_summary(
        summary_path=summary_path,
        config=config,
        top_state=top_state,
        top_prob=top_prob,
        distribution=distribution,
        energies=energies,
    )
    print(f"Equilibrium state: {top_state} (probability {top_prob:.4f})")


if __name__ == "__main__":
    main()


