import numpy as np


class Perceptron:
    def __init__(self, activation_function):
        self._data: np.ndarray = None
        self.synaptic_weight: np.ndarray = None
        self.activation_function = activation_function

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        if self._data is None:
            self._data = value
            self._data = np.insert(self._data, 0, -1)
        else:
            self._data[1:] = value
        if self.synaptic_weight is None:
            # 使用Xavier初始化，权重范围更小，避免梯度爆炸
            fan_in = len(self.data)
            limit = np.sqrt(6.0 / fan_in)  # Xavier uniform initialization
            self.synaptic_weight = np.random.uniform(-limit, limit, len(self.data))

    @property
    def result(self):
        return self.activation_function(np.dot(self.synaptic_weight, self.data))
