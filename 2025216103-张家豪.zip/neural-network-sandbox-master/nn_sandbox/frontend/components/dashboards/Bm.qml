import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'BM（三神经元）'

    ColumnLayout {
        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label { text: '初始温度'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 2.0 * 100
                    from: 0.01 * 100
                    to: 10.0 * 100
                    onValueChanged: bmBridge.initial_temperature = value / 100
                    Component.onCompleted: bmBridge.initial_temperature = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '最低温度'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 0.05 * 100
                    from: 0.01 * 100
                    to: 1.0 * 100
                    onValueChanged: bmBridge.min_temperature = value / 100
                    Component.onCompleted: bmBridge.min_temperature = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '冷却率'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 0.99 * 100
                    from: 0.5 * 100
                    to: 1.0 * 100
                    onValueChanged: bmBridge.cooling_rate = value / 100
                    Component.onCompleted: bmBridge.cooling_rate = value / 100
                    Layout.fillWidth: true
                }

                Label { text: '最大迭代'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 5000
                    to: 999999
                    onValueChanged: bmBridge.max_iterations = value
                    Component.onCompleted: bmBridge.max_iterations = value
                    Layout.fillWidth: true
                }

                Label { text: 'UI刷新间隔（秒）'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 1.0 * 100
                    onValueChanged: bmBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: bmBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: '权重（3×3，对称，对角为0）与偏置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 4

                Repeater {
                    model: 3
                    delegate: RowLayout {
                        property int row: index
                        Label { text: row === 0 ? '权重 第0行' : row === 1 ? '权重 第1行' : '权重 第2行'; Layout.alignment: Qt.AlignRight }
                        Repeater {
                            model: 3
                            delegate: DoubleSpinBox {
                                enabled: bmBridge.has_finished
                                editable: true
                                value: (row === 0 && index === 1) ? 1.0 * 100 :
                                       (row === 0 && index === 2) ? 1.0 * 100 :
                                       (row === 1 && index === 0) ? 1.0 * 100 :
                                       (row === 1 && index === 2) ? 1.0 * 100 :
                                       (row === 2 && index === 0) ? 1.0 * 100 :
                                       (row === 2 && index === 1) ? 1.0 * 100 : 0.0
                                from: -5.0 * 100
                                to: 5.0 * 100
                                onValueChanged: {
                                    let w = JSON.parse(JSON.stringify(bmBridge.weights))
                                    w[row][index] = value / 100
                                    // 保持对称与零对角
                                    if (row !== index) w[index][row] = value / 100
                                    if (row === index) w[row][index] = 0.0
                                    bmBridge.weights = w
                                }
                                Component.onCompleted: {
                                    let w = JSON.parse(JSON.stringify(bmBridge.weights))
                                    w[row][index] = value / 100
                                    if (row !== index) w[index][row] = value / 100
                                    if (row === index) w[row][index] = 0.0
                                    bmBridge.weights = w
                                }
                            }
                        }
                    }
                }

                Label { text: '偏置'; Layout.alignment: Qt.AlignRight }
                Repeater {
                    model: 3
                    delegate: DoubleSpinBox {
                        enabled: bmBridge.has_finished
                        editable: true
                        value: 0.0
                        from: -5.0 * 100
                        to: 5.0 * 100
                        onValueChanged: {
                            let b = JSON.parse(JSON.stringify(bmBridge.biases))
                            b[index] = value / 100
                            bmBridge.biases = b
                        }
                        Component.onCompleted: {
                            let b = JSON.parse(JSON.stringify(bmBridge.biases))
                            b[index] = value / 100
                            bmBridge.biases = b
                        }
                    }
                }
            }
        }

        GroupBox {
            title: '控制'
            Layout.fillWidth: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2

                ExecutionControls {
                    startButton.enabled: bmBridge.has_finished
                    startButton.onClicked: () => {
                        bmBridge.start_bm()
                    }
                    stopButton.enabled: !bmBridge.has_finished
                    stopButton.onClicked: bmBridge.stop_bm()
                    progressBar.value: (bmBridge.max_iterations > 0)
                        ? (bmBridge.current_iterations / bmBridge.max_iterations)
                        : 0
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: '当前迭代'; Layout.alignment: Qt.AlignHCenter }
                Label { text: bmBridge.current_iterations; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '当前温度'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: (Number.isFinite(bmBridge.current_temperature))
                        ? bmBridge.current_temperature.toFixed(3)
                        : (bmBridge.current_temperature || 0)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label { text: '当前能量'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: (Number.isFinite(bmBridge.current_energy))
                        ? bmBridge.current_energy.toFixed(6)
                        : (bmBridge.current_energy || 0)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label { text: '当前状态'; Layout.alignment: Qt.AlignHCenter }
                Label { text: JSON.stringify(bmBridge.current_state); horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                Label { text: '热平衡状态'; Layout.alignment: Qt.AlignHCenter }
                Label { text: JSON.stringify(bmBridge.equilibrium_state); horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
            }
        }
    }
}


