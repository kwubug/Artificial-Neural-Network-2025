import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'BP'
    ColumnLayout {
        GroupBox {
            title: '数据集'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(bpBridge.dataset_dict)
                enabled: bpBridge && bpBridge.has_finished
                onActivated: () => {
                    bpBridge.current_dataset_name = currentText
                    dataChart.updateDataset(bpBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    bpBridge.current_dataset_name = currentText
                    dataChart.updateDataset(bpBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: '网络设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: '输入层节点数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: inputNodes
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 2
                    from: 1
                    to: 10
                    onValueChanged: bpBridge.input_nodes = value
                    Component.onCompleted: bpBridge.input_nodes = value
                    Layout.fillWidth: true
                }
                Label {
                    text: '隐藏层节点数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: hiddenNodes
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 5
                    from: 1
                    to: 20
                    onValueChanged: bpBridge.hidden_nodes = value
                    Component.onCompleted: bpBridge.hidden_nodes = value
                    Layout.fillWidth: true
                }
                Label {
                    text: '输出层节点数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: outputNodes
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 3
                    from: 1
                    to: 5
                    onValueChanged: bpBridge.output_nodes = value
                    Component.onCompleted: bpBridge.output_nodes = value
                    Layout.fillWidth: true
                }
                Label {
                    text: '激活函数类型'
                    Layout.alignment: Qt.AlignHCenter
                }
                ComboBox {
                    id: activationType
                    enabled: bpBridge && bpBridge.has_finished
                    model: ['单极性Sigmoid', '双极性Sigmoid']
                    currentIndex: 0
                    onActivated: {
                        bpBridge.activation_type = currentIndex === 0 ? 'unipolar' : 'bipolar'
                    }
                    Component.onCompleted: bpBridge.activation_type = 'unipolar'
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: '训练设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: '总训练轮数'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 100
                    to: 999999
                    onValueChanged: bpBridge.total_epoches = value
                    Component.onCompleted: bpBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                CheckBox {
                    id: mostCorrectRateCheckBox
                    enabled: bpBridge && bpBridge.has_finished
                    text: '最高正确率'
                    checked: true
                    onCheckedChanged: bpBridge.most_correct_rate_checkbox = checked
                    Component.onCompleted: bpBridge.most_correct_rate_checkbox = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: mostCorrectRateCheckBox.checked && bpBridge && bpBridge.has_finished
                    editable: true
                    value: 0.98 * 100
                    onValueChanged: bpBridge.most_correct_rate = value / 100
                    Component.onCompleted: bpBridge.most_correct_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '学习率'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 0.5 * 100
                    from: 1
                    to: 100
                    onValueChanged: bpBridge.initial_learning_rate = value / 100
                    Component.onCompleted: bpBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '测试-训练比例'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: bpBridge.test_ratio = value / 100
                    Component.onCompleted: bpBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: '界面刷新间隔'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge && bpBridge.has_finished
                    editable: true
                    value: 0.1 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: bpBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: bpBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: '训练信息'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: bpBridge && bpBridge.has_finished
                    startButton.onClicked: () => {
                        bpBridge.start_bp_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(bpBridge.training_dataset)
                        dataChart.updateTestingDataset(bpBridge.testing_dataset)
                        rateChart.reset()
                        networkTopologyChart.reset()
                    }
                    stopButton.enabled: bpBridge && !bpBridge.has_finished
                    stopButton.onClicked: bpBridge.stop_bp_algorithm()
                    progressBar.value: (bpBridge.current_iterations + 1) / (totalEpoches.value * bpBridge.training_dataset.length)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前训练轮次'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const epoch = Math.floor(bpBridge.current_iterations / bpBridge.training_dataset.length) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: '当前训练迭代'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        rateChart.bestCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.test_correct_rate
                        )
                        networkTopologyChart.updateNetworkWeights()
                        dataChart.updateNetworkWeights()
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前学习率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_learning_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '最佳训练正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.best_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前训练正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: '当前测试正确率'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.test_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            width: 600
            Layout.fillWidth: true
            Layout.fillHeight: true
            inputNodes: bpBridge.input_nodes
            hiddenNodes: bpBridge.hidden_nodes
            outputNodes: bpBridge.output_nodes
            activationType: bpBridge.activation_type
            networkWeights: bpBridge.network_weights
        }
        RowLayout {
            RateChart {
                id: rateChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
            NetworkTopologyChart {
                id: networkTopologyChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }

    Connections {
        target: bpBridge
        function onHas_finishedChanged() {
            networkTopologyChart.updateNetworkWeights()
            // 训练结束后更新分类区域显示最佳效果
            dataChart.updateClassificationAreas()
        }
    }
}
