import QtQuick 2.13
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

Page {
    id: bpPage
    property string name: "BP Network"
    property var bridge: bpBridge

    ScrollView {
        anchors.fill: parent

        ColumnLayout {
            width: parent.width
            spacing: 10

            // 数据集选择
            GroupBox {
                title: "Dataset Selection"
                Layout.fillWidth: true

                ColumnLayout {
                    width: parent.width

                    ComboBox {
                        id: datasetComboBox
                        Layout.fillWidth: true
                        model: bridge && bridge.dataset_dict ? Object.keys(bridge.dataset_dict) : []
                        onCurrentTextChanged: {
                            if (currentText && bridge) {
                                bridge.current_dataset_name = currentText
                            }
                        }
                    }
                }
            }

            // 训练参数
            GroupBox {
                title: "Training Parameters"
                Layout.fillWidth: true

                GridLayout {
                    columns: 2
                    width: parent.width

                    Label { text: "Total Epoches:" }
                    SpinBox {
                        from: 1
                        to: 1000
                        value: bridge ? bridge.total_epoches : 100
                        onValueChanged: {
                            if (bridge) bridge.total_epoches = value
                        }
                    }

                    Label { text: "Hidden Neurons:" }
                    SpinBox {
                        from: 1
                        to: 20
                        value: bridge ? bridge.hidden_neurons_count : 4
                        onValueChanged: {
                            if (bridge) bridge.hidden_neurons_count = value
                        }
                    }

                    Label { text: "Learning Rate:" }
                    SpinBox {
                        from: 1
                        to: 100
                        value: bridge ? bridge.initial_learning_rate * 100 : 10
                        onValueChanged: {
                            if (bridge) bridge.initial_learning_rate = value / 100
                        }
                        textFromValue: function(value) {
                            return (value / 100).toFixed(2)
                        }
                    }

                    Label { text: "Test Ratio:" }
                    SpinBox {
                        from: 1
                        to: 50
                        value: bridge ? bridge.test_ratio * 100 : 30
                        onValueChanged: {
                            if (bridge) bridge.test_ratio = value / 100
                        }
                        textFromValue: function(value) {
                            return (value / 100).toFixed(2)
                        }
                    }
                }
            }

            // 控制按钮
            GroupBox {
                title: "Control"
                Layout.fillWidth: true

                RowLayout {
                    width: parent.width

                    Button {
                        text: "Start Training"
                        enabled: bridge ? bridge.has_finished : false
                        onClicked: {
                            if (bridge) bridge.start_bp_algorithm()
                        }
                    }

                    Button {
                        text: "Stop"
                        enabled: bridge ? !bridge.has_finished : false
                        onClicked: {
                            if (bridge) bridge.stop_bp_algorithm()
                        }
                    }

                    Item { Layout.fillWidth: true }

                    Label {
                        text: "Refresh:"
                        font.pixelSize: 12
                    }

                    Slider {
                        id: refreshSlider
                        from: 0
                        to: 100
                        value: bridge ? bridge.ui_refresh_interval * 1000 : 0
                        onValueChanged: {
                            if (bridge) bridge.ui_refresh_interval = value / 1000
                        }
                    }

                    Label {
                        text: (refreshSlider.value / 1000).toFixed(1) + "s"
                        font.pixelSize: 12
                    }
                }
            }

            // 训练状态
            GroupBox {
                title: "Training Status"
                Layout.fillWidth: true

                GridLayout {
                    columns: 2
                    width: parent.width

                    Label { text: "Current Iteration:" }
                    Label { text: bridge ? bridge.current_iterations : "0" }

                    Label { text: "Current Learning Rate:" }
                    Label { text: bridge ? bridge.current_learning_rate.toFixed(4) : "0.0000" }

                    Label { text: "Current Correct Rate:" }
                    Label {
                        text: bridge ? (bridge.current_correct_rate * 100).toFixed(2) + "%" : "0%"
                        color: bridge && bridge.current_correct_rate > 0.8 ? "green" :
                               bridge && bridge.current_correct_rate > 0.6 ? "orange" : "red"
                    }

                    Label { text: "Best Correct Rate:" }
                    Label {
                        text: bridge ? (bridge.best_correct_rate * 100).toFixed(2) + "%" : "0%"
                        color: "blue"
                    }

                    Label { text: "Test Correct Rate:" }
                    Label {
                        text: bridge ? (bridge.test_correct_rate * 100).toFixed(2) + "%" : "0%"
                        color: "purple"
                    }

                    Label { text: "Current Loss:" }
                    Label {
                        text: bridge ? bridge.current_loss.toFixed(6) : "0.000000"
                        color: bridge && bridge.current_loss < 0.1 ? "green" :
                               bridge && bridge.current_loss < 0.3 ? "orange" : "red"
                    }

                    Label { text: "Status:" }
                    Label {
                        text: bridge ? (bridge.has_finished ? "Finished" : "Training...") : "Ready"
                        color: bridge && bridge.has_finished ? "green" : "blue"
                        font.bold: true
                    }
                }
            }

            // 权重显示
            GroupBox {
                title: "Network Weights"
                Layout.fillWidth: true

                TabBar {
                    id: weightsTabBar
                    width: parent.width

                    TabButton { text: "Hidden Weights" }
                    TabButton { text: "Output Weights" }
                }

                StackLayout {
                    width: parent.width
                    height: 120
                    currentIndex: weightsTabBar.currentIndex

                    // 隐藏层权重
                    ScrollView {
                        width: parent.width
                        height: parent.height

                        TextArea {
                            width: parent.width
                            height: parent.height
                            text: bridge && bridge.hidden_weights ?
                                  formatWeights(bridge.hidden_weights) : "Weights will appear during training"
                            readOnly: true
                            wrapMode: TextArea.Wrap
                            font.family: "Courier"
                            font.pixelSize: 10
                        }
                    }

                    // 输出层权重
                    ScrollView {
                        width: parent.width
                        height: parent.height

                        TextArea {
                            width: parent.width
                            height: parent.height
                            text: bridge && bridge.output_weights ?
                                  formatWeights(bridge.output_weights) : "Weights will appear during training"
                            readOnly: true
                            wrapMode: TextArea.Wrap
                            font.family: "Courier"
                            font.pixelSize: 10
                        }
                    }
                }
            }

            // 数据图表
            GroupBox {
                title: "Data Visualization"
                Layout.fillWidth: true

                ColumnLayout {
                    width: parent.width

                    TabBar {
                        id: chartTabBar
                        Layout.fillWidth: true

                        TabButton { text: "Training Data" }
                        TabButton { text: "Testing Data" }
                    }

                    StackLayout {
                        Layout.fillWidth: true
                        height: 250
                        currentIndex: chartTabBar.currentIndex

                        // 训练数据可视化
                        Rectangle {
                            width: parent.width
                            height: parent.height
                            color: "#f8f9fa"
                            border.color: "#dee2e6"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 10

                                Label {
                                    text: "Training Data Points"
                                    font.bold: true
                                    Layout.alignment: Qt.AlignHCenter
                                }

                                // 简单的数据点显示
                                Canvas {
                                    id: trainingCanvas
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true

                                    onPaint: {
                                        var ctx = getContext("2d")
                                        ctx.clearRect(0, 0, width, height)

                                        // 绘制坐标轴
                                        ctx.strokeStyle = "#6c757d"
                                        ctx.lineWidth = 1
                                        ctx.beginPath()
                                        ctx.moveTo(10, height/2)
                                        ctx.lineTo(width-10, height/2)
                                        ctx.moveTo(width/2, 10)
                                        ctx.lineTo(width/2, height-10)
                                        ctx.stroke()

                                        // 绘制数据点（如果有数据）
                                        if (bridge && bridge.training_dataset && bridge.training_dataset.length > 0) {
                                            var dataset = bridge.training_dataset
                                            for (var i = 0; i < Math.min(dataset.length, 50); i++) {
                                                var point = dataset[i]
                                                if (point && point.length >= 2) {
                                                    var x = (point[0] + 1) * (width - 20) / 2 + 10
                                                    var y = (1 - point[1]) * (height - 20) / 2 + 10

                                                    ctx.fillStyle = point.length > 2 ? getColorForClass(point[2]) : "blue"
                                                    ctx.beginPath()
                                                    ctx.arc(x, y, 4, 0, Math.PI * 2)
                                                    ctx.fill()
                                                }
                                            }
                                        } else {
                                            // 显示提示信息
                                            ctx.fillStyle = "#6c757d"
                                            ctx.font = "12px Arial"
                                            ctx.textAlign = "center"
                                            ctx.fillText("Training data will be displayed here", width/2, height/2)
                                        }
                                    }
                                }
                            }
                        }

                        // 测试数据可视化
                        Rectangle {
                            width: parent.width
                            height: parent.height
                            color: "#f8f9fa"
                            border.color: "#dee2e6"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 10

                                Label {
                                    text: "Testing Data Points"
                                    font.bold: true
                                    Layout.alignment: Qt.AlignHCenter
                                }

                                Canvas {
                                    id: testingCanvas
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true

                                    onPaint: {
                                        var ctx = getContext("2d")
                                        ctx.clearRect(0, 0, width, height)

                                        // 绘制坐标轴
                                        ctx.strokeStyle = "#6c757d"
                                        ctx.lineWidth = 1
                                        ctx.beginPath()
                                        ctx.moveTo(10, height/2)
                                        ctx.lineTo(width-10, height/2)
                                        ctx.moveTo(width/2, 10)
                                        ctx.lineTo(width/2, height-10)
                                        ctx.stroke()

                                        // 绘制数据点（如果有数据）
                                        if (bridge && bridge.testing_dataset && bridge.testing_dataset.length > 0) {
                                            var dataset = bridge.testing_dataset
                                            for (var i = 0; i < Math.min(dataset.length, 50); i++) {
                                                var point = dataset[i]
                                                if (point && point.length >= 2) {
                                                    var x = (point[0] + 1) * (width - 20) / 2 + 10
                                                    var y = (1 - point[1]) * (height - 20) / 2 + 10

                                                    ctx.fillStyle = point.length > 2 ? getColorForClass(point[2]) : "red"
                                                    ctx.beginPath()
                                                    ctx.arc(x, y, 4, 0, Math.PI * 2)
                                                    ctx.fill()
                                                }
                                            }
                                        } else {
                                            // 显示提示信息
                                            ctx.fillStyle = "#6c757d"
                                            ctx.font = "12px Arial"
                                            ctx.textAlign = "center"
                                            ctx.fillText("Testing data will be displayed here", width/2, height/2)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 训练进度
            GroupBox {
                title: "Training Progress"
                Layout.fillWidth: true

                ProgressBar {
                    Layout.fillWidth: true
                    from: 0
                    to: bridge ? Math.max(bridge.total_epoches, 1) : 1
                    value: bridge ? bridge.current_iterations : 0
                }

                Label {
                    text: {
                        if (!bridge) return "Progress: 0 / 0 (0%)"
                        var total = bridge.total_epoches
                        var current = bridge.current_iterations
                        var percent = total > 0 ? (current / total * 100).toFixed(1) : "0"
                        return "Progress: " + current + " / " + total + " (" + percent + "%)"
                    }
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }

    // 格式化权重函数
    function formatWeights(weights) {
        if (!weights || weights.length === 0) return "No weights available"

        var result = ""
        for (var i = 0; i < weights.length; i++) {
            result += "Neuron " + (i + 1) + ": ["
            if (weights[i] && weights[i].length > 0) {
                for (var j = 0; j < weights[i].length; j++) {
                    result += weights[i][j].toFixed(4)
                    if (j < weights[i].length - 1) {
                        result += ", "
                    }
                }
            }
            result += "]\n"
        }
        return result
    }

    // 根据类别获取颜色
    function getColorForClass(classValue) {
        var colors = ["#007bff", "#dc3545", "#28a745", "#ffc107", "#6f42c1", "#fd7e14"]
        var index = Math.abs(classValue) % colors.length
        return colors[index]
    }

    // 当数据更新时重绘Canvas
    Connections {
        target: bridge
        onTraining_datasetChanged: {
            trainingCanvas.requestPaint()
        }
        onTesting_datasetChanged: {
            testingCanvas.requestPaint()
        }
    }
}