import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import numpy as np
import math


class SingleNeuronNetwork:
    def __init__(self, input_size=6):
        self.weights = np.random.uniform(-0.5, 0.5, input_size)
        self.bias = np.random.uniform(-0.5, 0.5)
        self.input_size = input_size
        self.learning_rate = 0.1
        self.learning_rule = "continuous_perceptron"
        self.activation_func = "sigmoid"

    def set_learning_rule(self, rule_name):
        self.learning_rule = rule_name.lower()

    def set_activation_function(self, func_name):
        self.activation_func = func_name.lower()

    def set_learning_rate(self, rate):
        self.learning_rate = rate

    def activation(self, net_input):
        """应用变换函数"""
        if self.activation_func == "linear":
            return net_input
        elif self.activation_func == "step":
            return 1 if net_input >= 0 else 0
        elif self.activation_func == "sigmoid":
            return 1 / (1 + math.exp(-net_input))
        elif self.activation_func == "relu":
            return max(0, net_input)
        elif self.activation_func == "tanh":
            return math.tanh(net_input)
        else:
            raise ValueError("未知的变换函数")

    def derivative(self, output):
        """变换函数的导数"""
        if self.activation_func == "linear":
            return 1
        elif self.activation_func == "step":
            return 0
        elif self.activation_func == "sigmoid":
            return output * (1 - output)
        elif self.activation_func == "relu":
            return 1 if output > 0 else 0
        elif self.activation_func == "tanh":
            return 1 - output ** 2
        else:
            raise ValueError("未知的变换函数")

    def calculate_net_input(self, inputs):
        """计算净输入"""
        return np.dot(inputs, self.weights) + self.bias

    def update_weights(self, inputs, target=None, output=None):
        """根据学习规则更新权重"""
        net_input = self.calculate_net_input(inputs)
        if output is None:
            output = self.activation(net_input)

        if self.learning_rule == "hebbian":
            delta_w = self.learning_rate * inputs * output
            delta_b = self.learning_rate * output

        elif self.learning_rule == "discrete_perceptron":
            if target is None:
                raise ValueError("离散感知器规则需要目标输出")
            delta_w = self.learning_rate * (target - output) * inputs
            delta_b = self.learning_rate * (target - output)

        elif self.learning_rule == "continuous_perceptron":
            if target is None:
                raise ValueError("连续感知器规则需要目标输出")
            derivative = self.derivative(output)
            delta_w = self.learning_rate * (target - output) * derivative * inputs
            delta_b = self.learning_rate * (target - output) * derivative

        elif self.learning_rule == "lms":
            if target is None:
                raise ValueError("LMS规则需要目标输出")
            delta_w = self.learning_rate * (target - output) * inputs
            delta_b = self.learning_rate * (target - output)

        elif self.learning_rule == "correlation":
            if target is None:
                raise ValueError("相关学习规则需要目标输出")
            delta_w = self.learning_rate * target * inputs
            delta_b = self.learning_rate * target

        elif self.learning_rule == "winner_take_all":
            delta_w = self.learning_rate * inputs * output
            delta_b = self.learning_rate * output

        elif self.learning_rule == "oja":
            delta_w = self.learning_rate * (output * inputs - output ** 2 * self.weights)
            delta_b = self.learning_rate * (output - output ** 2 * self.bias)

        else:
            raise ValueError("未知的学习规则")

        # 更新权重和偏置
        self.weights += delta_w
        self.bias += delta_b

        return net_input, delta_w, delta_b

    def train(self, training_data, targets=None, epochs=1):
        """训练神经网络"""
        results = []
        for epoch in range(epochs):
            epoch_results = []

            for i, sample in enumerate(training_data):
                target = targets[i] if targets is not None else None

                net_input = self.calculate_net_input(sample)
                output = self.activation(net_input)

                weights_before = self.weights.copy()
                bias_before = self.bias

                net_input, delta_w, delta_b = self.update_weights(sample, target, output)

                result = {
                    "sample": sample,
                    "target": target,
                    "net_input": net_input,
                    "output": output,
                    "weights_before": weights_before,
                    "bias_before": bias_before,
                    "delta_w": delta_w,
                    "delta_b": delta_b,
                    "weights_after": self.weights.copy(),
                    "bias_after": self.bias
                }
                epoch_results.append(result)

            results.append(epoch_results)
        return results


class NeuralNetworkGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("单节点神经网络训练器")
        self.root.geometry("1000x700")

        self.network = None
        self.training_results = []

        self.setup_ui()

    def setup_ui(self):
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)

        # 左侧控制面板
        self.setup_control_panel(main_frame)

        # 右侧结果显示区域
        self.setup_result_area(main_frame)

    def setup_control_panel(self, parent):
        # 控制面板框架
        control_frame = ttk.LabelFrame(parent, text="网络配置", padding="10")
        control_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))

        # 网络参数配置
        params_frame = ttk.LabelFrame(control_frame, text="基本参数", padding="5")
        params_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(params_frame, text="输入维度:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.input_size_var = tk.StringVar(value="6")
        ttk.Entry(params_frame, textvariable=self.input_size_var, width=10).grid(row=0, column=1, sticky=tk.W, pady=2,
                                                                                 padx=(5, 0))

        ttk.Label(params_frame, text="学习率:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.learning_rate_var = tk.StringVar(value="0.1")
        ttk.Entry(params_frame, textvariable=self.learning_rate_var, width=10).grid(row=1, column=1, sticky=tk.W,
                                                                                    pady=2, padx=(5, 0))

        ttk.Label(params_frame, text="训练轮数:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.epochs_var = tk.StringVar(value="1")
        ttk.Entry(params_frame, textvariable=self.epochs_var, width=10).grid(row=2, column=1, sticky=tk.W, pady=2,
                                                                             padx=(5, 0))

        # 学习规则和激活函数
        rules_frame = ttk.LabelFrame(control_frame, text="算法选择", padding="5")
        rules_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(rules_frame, text="学习规则:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.learning_rule_var = tk.StringVar(value="continuous_perceptron")
        learning_rules = ["hebbian", "discrete_perceptron", "continuous_perceptron",
                          "lms", "correlation", "winner_take_all", "oja"]
        rule_combo = ttk.Combobox(rules_frame, textvariable=self.learning_rule_var,
                                  values=learning_rules, width=25, state="readonly")
        rule_combo.grid(row=0, column=1, sticky=tk.W, pady=2, padx=(5, 0))

        ttk.Label(rules_frame, text="激活函数:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.activation_var = tk.StringVar(value="sigmoid")
        activations = ["linear", "step", "sigmoid", "relu", "tanh"]
        activation_combo = ttk.Combobox(rules_frame, textvariable=self.activation_var,
                                        values=activations, width=25, state="readonly")
        activation_combo.grid(row=1, column=1, sticky=tk.W, pady=2, padx=(5, 0))

        # 训练数据输入区域
        data_frame = ttk.LabelFrame(control_frame, text="训练数据", padding="5")
        data_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        ttk.Label(data_frame, text="输入数据 (每行一个样本，用逗号分隔):").pack(anchor=tk.W)
        self.input_data_text = scrolledtext.ScrolledText(data_frame, height=8, width=35)
        self.input_data_text.pack(fill=tk.BOTH, expand=True, pady=2)
        self.input_data_text.insert(tk.END,
                                    "0.1,0.2,0.3,0.4,0.5,0.6\n0.6,0.5,0.4,0.3,0.2,0.1\n0.9,0.1,0.8,0.2,0.7,0.3\n0.3,0.7,0.2,0.8,0.1,0.9")

        ttk.Label(data_frame, text="目标输出 (用逗号分隔，可选):").pack(anchor=tk.W, pady=(10, 0))
        self.target_data_text = tk.Text(data_frame, height=2, width=35)
        self.target_data_text.pack(fill=tk.X, pady=2)
        self.target_data_text.insert(tk.END, "0.8,0.4,0.6,0.2")

        # 按钮区域
        button_frame = ttk.Frame(control_frame)
        button_frame.pack(fill=tk.X, pady=10)

        ttk.Button(button_frame, text="初始化网络", command=self.initialize_network).pack(fill=tk.X, pady=2)
        ttk.Button(button_frame, text="开始训练", command=self.start_training).pack(fill=tk.X, pady=2)
        ttk.Button(button_frame, text="重置网络", command=self.reset_network).pack(fill=tk.X, pady=2)
        ttk.Button(button_frame, text="清空结果", command=self.clear_results).pack(fill=tk.X, pady=2)

        # 添加学习规则说明
        info_frame = ttk.LabelFrame(control_frame, text="学习规则说明", padding="5")
        info_frame.pack(fill=tk.X, pady=(10, 0))

        info_text = tk.Text(info_frame, height=6, width=35, wrap=tk.WORD, font=("Arial", 8))
        info_text.pack(fill=tk.X)
        info_text.insert(tk.END,
                         "• Hebbian: 无监督，同时激活的连接增强\n"
                         "• 离散感知器: 监督学习，基于输出误差\n"
                         "• 连续感知器: 监督学习，考虑激活函数导数\n"
                         "• LMS: 最小均方误差学习\n"
                         "• 相关学习: 基于输入输出相关性\n"
                         "• 胜者为王: 竞争学习规则\n"
                         "• Oja: 主成分分析学习规则")
        info_text.config(state=tk.DISABLED)

    def setup_result_area(self, parent):
        # 结果显示区域
        result_frame = ttk.LabelFrame(parent, text="训练结果详情", padding="10")
        result_frame.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)

        # 创建带滚动条的文本框
        text_frame = ttk.Frame(result_frame)
        text_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)

        self.result_text = scrolledtext.ScrolledText(text_frame, wrap=tk.WORD, font=("Consolas", 10))
        self.result_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # 添加快速操作按钮
        button_frame = ttk.Frame(result_frame)
        button_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(10, 0))

        ttk.Button(button_frame, text="保存结果", command=self.save_results).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(button_frame, text="复制结果", command=self.copy_results).pack(side=tk.LEFT)

    def initialize_network(self):
        try:
            input_size = int(self.input_size_var.get())
            learning_rate = float(self.learning_rate_var.get())

            self.network = SingleNeuronNetwork(input_size)
            self.network.set_learning_rate(learning_rate)
            self.network.set_learning_rule(self.learning_rule_var.get())
            self.network.set_activation_function(self.activation_var.get())

            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "=" * 60 + "\n")
            self.result_text.insert(tk.END, "           单节点神经网络初始化完成\n")
            self.result_text.insert(tk.END, "=" * 60 + "\n\n")

            self.result_text.insert(tk.END, f"网络配置:\n")
            self.result_text.insert(tk.END, f"  输入维度: {input_size}\n")
            self.result_text.insert(tk.END, f"  学习率: {learning_rate}\n")
            self.result_text.insert(tk.END, f"  学习规则: {self.learning_rule_var.get()}\n")
            self.result_text.insert(tk.END, f"  激活函数: {self.activation_var.get()}\n\n")

            self.result_text.insert(tk.END, f"初始参数:\n")
            self.result_text.insert(tk.END,
                                    f"  权重向量: {np.array2string(self.network.weights, precision=4, separator=', ')}\n")
            self.result_text.insert(tk.END, f"  偏置: {self.network.bias:.4f}\n\n")
            self.result_text.insert(tk.END, "-" * 60 + "\n\n")

            self.result_text.see(tk.END)

        except ValueError as e:
            messagebox.showerror("错误", f"参数错误: {str(e)}")

    def start_training(self):
        if self.network is None:
            messagebox.showwarning("警告", "请先初始化网络!")
            return

        try:
            # 解析输入数据
            input_lines = self.input_data_text.get("1.0", tk.END).strip().split('\n')
            training_data = []
            for line in input_lines:
                if line.strip():
                    row = [float(x.strip()) for x in line.split(',')]
                    training_data.append(row)
            training_data = np.array(training_data)

            # 解析目标数据
            target_text = self.target_data_text.get("1.0", tk.END).strip()
            targets = None
            if target_text:
                targets = np.array([float(x.strip()) for x in target_text.split(',')])

            epochs = int(self.epochs_var.get())

            # 开始训练
            self.result_text.insert(tk.END, f"开始训练 (共{epochs}轮)...\n")
            self.result_text.insert(tk.END, "=" * 60 + "\n\n")

            results = self.network.train(training_data, targets, epochs)
            self.training_results = results

            # 显示详细训练结果
            for epoch_idx, epoch_results in enumerate(results):
                self.result_text.insert(tk.END, f"第 {epoch_idx + 1} 轮训练结果:\n")
                self.result_text.insert(tk.END, "=" * 40 + "\n")

                for i, result in enumerate(epoch_results):
                    self.result_text.insert(tk.END, f"\n【样本 {i + 1}】\n")
                    self.result_text.insert(tk.END,
                                            f"输入向量: {np.array2string(result['sample'], precision=3, separator=', ')}\n")

                    if result['target'] is not None:
                        self.result_text.insert(tk.END, f"目标输出: {result['target']:.4f}\n")

                    self.result_text.insert(tk.END, f"净输入值: {result['net_input']:.6f}\n")
                    self.result_text.insert(tk.END, f"神经元输出: {result['output']:.6f}\n")

                    if result['target'] is not None:
                        error = result['target'] - result['output']
                        self.result_text.insert(tk.END, f"输出误差: {error:.6f}\n")

                    self.result_text.insert(tk.END, f"\n权重调整:\n")
                    self.result_text.insert(tk.END,
                                            f"  调整前: {np.array2string(result['weights_before'], precision=6, separator=', ')}\n")
                    self.result_text.insert(tk.END,
                                            f"  调整量: {np.array2string(result['delta_w'], precision=6, separator=', ')}\n")
                    self.result_text.insert(tk.END,
                                            f"  调整后: {np.array2string(result['weights_after'], precision=6, separator=', ')}\n")

                    self.result_text.insert(tk.END, f"\n偏置调整:\n")
                    self.result_text.insert(tk.END, f"  调整前: {result['bias_before']:.6f}\n")
                    self.result_text.insert(tk.END, f"  调整量: {result['delta_b']:.6f}\n")
                    self.result_text.insert(tk.END, f"  调整后: {result['bias_after']:.6f}\n")

                    self.result_text.insert(tk.END, "-" * 30 + "\n")

            self.result_text.insert(tk.END, f"\n训练完成!\n")
            self.result_text.insert(tk.END, "=" * 40 + "\n")
            self.result_text.insert(tk.END,
                                    f"最终权重向量: {np.array2string(self.network.weights, precision=6, separator=', ')}\n")
            self.result_text.insert(tk.END, f"最终偏置: {self.network.bias:.6f}\n")
            self.result_text.see(tk.END)

        except Exception as e:
            messagebox.showerror("错误", f"训练过程中出现错误: {str(e)}")

    def reset_network(self):
        if self.network:
            input_size = self.network.input_size
            learning_rate = self.network.learning_rate
            self.network = SingleNeuronNetwork(input_size)
            self.network.set_learning_rate(learning_rate)
            self.network.set_learning_rule(self.learning_rule_var.get())
            self.network.set_activation_function(self.activation_var.get())

            self.result_text.insert(tk.END, f"\n网络已重置!\n")
            self.result_text.insert(tk.END,
                                    f"新的权重向量: {np.array2string(self.network.weights, precision=4, separator=', ')}\n")
            self.result_text.insert(tk.END, f"新的偏置: {self.network.bias:.4f}\n")
            self.result_text.insert(tk.END, "-" * 50 + "\n\n")
            self.result_text.see(tk.END)
        else:
            messagebox.showwarning("警告", "请先初始化网络!")

    def clear_results(self):
        self.result_text.delete(1.0, tk.END)
        self.training_results = []

    def save_results(self):
        if not self.result_text.get(1.0, tk.END).strip():
            messagebox.showwarning("警告", "没有结果可保存!")
            return

        from tkinter import filedialog
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")]
        )

        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(self.result_text.get(1.0, tk.END))
                messagebox.showinfo("成功", f"结果已保存到: {filename}")
            except Exception as e:
                messagebox.showerror("错误", f"保存失败: {str(e)}")

    def copy_results(self):
        if not self.result_text.get(1.0, tk.END).strip():
            messagebox.showwarning("警告", "没有结果可复制!")
            return

        self.root.clipboard_clear()
        self.root.clipboard_append(self.result_text.get(1.0, tk.END))
        messagebox.showinfo("成功", "结果已复制到剪贴板!")


if __name__ == "__main__":
    root = tk.Tk()
    app = NeuralNetworkGUI(root)
    root.mainloop()