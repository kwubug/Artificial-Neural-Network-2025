import numpy as np
import matplotlib.pyplot as plt
import time


# --- Hopfield 网络类定义 ---
class HopfieldNetwork:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))

    def train(self, patterns):
        for p in patterns:
            p = p.reshape(self.num_neurons, 1)
            self.weights += np.dot(p, p.T)
        np.fill_diagonal(self.weights, 0)
        self.weights /= len(patterns)

    def energy(self, state):
        return -0.5 * np.dot(state.T, np.dot(self.weights, state))

    def update_async(self, state):
        # 异步更新：每次随机选一个神经元更新
        i = np.random.randint(0, self.num_neurons)
        net_input = np.dot(self.weights[i], state)
        state[i] = 1 if net_input >= 0 else -1
        return state


# --- 初始化部分 ---
patterns = np.array([
    [1, -1, 1],  # 模式1
    [-1, 1, -1],  # 模式2
])

hopfield = HopfieldNetwork(num_neurons=3)
hopfield.train(patterns)

# 初始化随机状态
state = np.random.choice([-1, 1], size=3)
print(f"初始状态: {state}")

energies = []
states = [state.copy()]

# --- 动态可视化 ---
plt.ion()
fig, ax = plt.subplots(1, 2, figsize=(8, 4))

for epoch in range(20):
    energy = hopfield.energy(state)
    energies.append(energy)
    states.append(state.copy())

    ax[0].cla()
    ax[0].set_title("Hopfield 神经元状态 (异步更新)")
    ax[0].imshow(state.reshape(1, -1), cmap='coolwarm', vmin=-1, vmax=1)
    ax[0].set_xticks(range(3))
    ax[0].set_xticklabels([f'N{i + 1}' for i in range(3)])
    ax[0].set_yticks([])

    ax[1].cla()
    ax[1].set_title("能量变化曲线")
    ax[1].plot(energies, 'o-', label="Energy")
    ax[1].set_xlabel("迭代次数")
    ax[1].set_ylabel("能量")
    ax[1].legend()

    plt.pause(0.5)
    state = hopfield.update_async(state)

plt.ioff()
plt.show()

print(f"最终状态: {state}")
print(f"最终能量: {hopfield.energy(state)}")
