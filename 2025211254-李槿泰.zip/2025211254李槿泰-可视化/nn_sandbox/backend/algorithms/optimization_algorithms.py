import numpy as np
import math
from abc import ABC, abstractmethod
from typing import List, Tuple, Callable


class OptimizationAlgorithm(ABC):
    """优化算法基类"""
    
    def __init__(self, objective_function: Callable, gradient_function: Callable, 
                 hessian_function: Callable = None, max_iterations: int = 100, 
                 tolerance: float = 1e-6):
        self.objective_function = objective_function
        self.gradient_function = gradient_function
        self.hessian_function = hessian_function
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.path = []  # 存储优化路径
        self.function_values = []  # 存储函数值
        
    @abstractmethod
    def optimize(self, initial_point: np.ndarray) -> Tuple[np.ndarray, List[np.ndarray], List[float]]:
        """执行优化，返回最优解、路径和函数值"""
        pass


class GradientDescent(OptimizationAlgorithm):
    """标准梯度下降法"""
    
    def __init__(self, objective_function: Callable, gradient_function: Callable,
                 learning_rate: float = 0.01, **kwargs):
        super().__init__(objective_function, gradient_function, **kwargs)
        self.learning_rate = learning_rate
        
    def optimize(self, initial_point: np.ndarray) -> Tuple[np.ndarray, List[np.ndarray], List[float]]:
        """梯度下降优化"""
        self.path = [initial_point.copy()]
        self.function_values = [self.objective_function(initial_point)]
        
        current_point = initial_point.copy()
        
        for iteration in range(self.max_iterations):
            gradient = self.gradient_function(current_point)
            
            # 检查收敛条件
            if np.linalg.norm(gradient) < self.tolerance:
                break
                
            # 更新参数
            current_point = current_point - self.learning_rate * gradient
            
            # 记录路径和函数值
            self.path.append(current_point.copy())
            self.function_values.append(self.objective_function(current_point))
            
        return current_point, self.path, self.function_values


class NewtonMethod(OptimizationAlgorithm):
    """牛顿法"""
    
    def __init__(self, objective_function: Callable, gradient_function: Callable,
                 hessian_function: Callable, **kwargs):
        super().__init__(objective_function, gradient_function, hessian_function, **kwargs)
        
    def optimize(self, initial_point: np.ndarray) -> Tuple[np.ndarray, List[np.ndarray], List[float]]:
        """牛顿法优化"""
        self.path = [initial_point.copy()]
        self.function_values = [self.objective_function(initial_point)]
        
        current_point = initial_point.copy()
        
        for iteration in range(self.max_iterations):
            gradient = self.gradient_function(current_point)
            hessian = self.hessian_function(current_point)
            
            # 检查收敛条件
            if np.linalg.norm(gradient) < self.tolerance:
                break
                
            try:
                # 计算牛顿步长: -H^(-1) * g
                newton_step = -np.linalg.solve(hessian, gradient)
                current_point = current_point + newton_step
            except np.linalg.LinAlgError:
                # 如果Hessian矩阵奇异，使用梯度下降作为备选
                current_point = current_point - 0.01 * gradient
            
            # 记录路径和函数值
            self.path.append(current_point.copy())
            self.function_values.append(self.objective_function(current_point))
            
        return current_point, self.path, self.function_values


class ConjugateGradient(OptimizationAlgorithm):
    """共轭梯度法"""
    
    def __init__(self, objective_function: Callable, gradient_function: Callable,
                 **kwargs):
        super().__init__(objective_function, gradient_function, **kwargs)
        
    def optimize(self, initial_point: np.ndarray) -> Tuple[np.ndarray, List[np.ndarray], List[float]]:
        """共轭梯度法优化"""
        self.path = [initial_point.copy()]
        self.function_values = [self.objective_function(initial_point)]
        
        current_point = initial_point.copy()
        gradient = self.gradient_function(current_point)
        direction = -gradient  # 初始搜索方向
        
        for iteration in range(self.max_iterations):
            # 检查收敛条件
            if np.linalg.norm(gradient) < self.tolerance:
                break
                
            # 线搜索找到最优步长（这里使用简单的固定步长）
            alpha = 0.01
            new_point = current_point + alpha * direction
            
            # 计算新的梯度
            new_gradient = self.gradient_function(new_point)
            
            # 计算共轭梯度系数 (Polak-Ribiere公式)
            beta = max(0, np.dot(new_gradient, new_gradient - gradient) / np.dot(gradient, gradient))
            
            # 更新搜索方向
            direction = -new_gradient + beta * direction
            
            current_point = new_point
            gradient = new_gradient
            
            # 记录路径和函数值
            self.path.append(current_point.copy())
            self.function_values.append(self.objective_function(current_point))
            
        return current_point, self.path, self.function_values


# 预定义的目标函数
def rosenbrock_function(x):
    """Rosenbrock函数 - 经典的优化测试函数"""
    return 100 * (x[1] - x[0]**2)**2 + (1 - x[0])**2


def rosenbrock_gradient(x):
    """Rosenbrock函数的梯度"""
    return np.array([
        -400 * x[0] * (x[1] - x[0]**2) - 2 * (1 - x[0]),
        200 * (x[1] - x[0]**2)
    ])


def rosenbrock_hessian(x):
    """Rosenbrock函数的Hessian矩阵"""
    return np.array([
        [1200 * x[0]**2 - 400 * x[1] + 2, -400 * x[0]],
        [-400 * x[0], 200]
    ])


def sphere_function(x):
    """球函数 - 简单的二次函数"""
    return np.sum(x**2)


def sphere_gradient(x):
    """球函数的梯度"""
    return 2 * x


def sphere_hessian(x):
    """球函数的Hessian矩阵"""
    return 2 * np.eye(len(x))


def rastrigin_function(x):
    """Rastrigin函数 - 多模态函数"""
    n = len(x)
    return 10 * n + np.sum(x**2 - 10 * np.cos(2 * np.pi * x))


def rastrigin_gradient(x):
    """Rastrigin函数的梯度"""
    return 2 * x + 20 * np.pi * np.sin(2 * np.pi * x)


def rastrigin_hessian(x):
    """Rastrigin函数的Hessian矩阵"""
    n = len(x)
    hessian = np.zeros((n, n))
    for i in range(n):
        hessian[i, i] = 2 + 40 * np.pi**2 * np.cos(2 * np.pi * x[i])
    return hessian
