"""
OLS (Orthogonal Least Squares) Algorithm for RBF Network Center Selection

Reference: Chen, S., Cowan, C. F. N., & Grant, P. M. (1991). 
Orthogonal least squares learning algorithm for radial basis function networks.
IEEE Transactions on Neural Networks, 2(2), 302-309.
"""

import numpy as np
from . import PredictiveAlgorithm
from ..neurons import RbfNeuron
from ..utils import gaussian


class OlsAlgorithm(PredictiveAlgorithm):
    """
    RBF网络的OLS（正交最小二乘）算法实现
    
    该算法通过正交化过程自动选择最优的RBF中心，避免了随机选择中心
    和K-means聚类方法可能导致的网络性能差、规模过大或数值病态问题。
    """
    
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 acceptable_range=0.5, initial_learning_rate=0.8,
                 search_iteration_constant=10000, max_centers=None,
                 err_threshold=0.001, initial_sigma=1.0, test_ratio=0.3,
                 adaptive_sigma=True, regularization_lambda=0.0001,
                 backward_elimination=True, min_err_contribution=0.0001):
        """
        初始化OLS算法
        
        Args:
            dataset: 训练数据集
            total_epoches: 总训练轮数
            most_correct_rate: 目标正确率
            acceptable_range: 可接受的输出误差范围
            initial_learning_rate: 初始学习率
            search_iteration_constant: 搜索迭代常数
            max_centers: 最大中心数量（默认为训练集大小的一半）
            err_threshold: ERR阈值，用于自动停止中心选择
            initial_sigma: 初始标准差（当adaptive_sigma=False时使用）
            test_ratio: 测试集比例
            adaptive_sigma: 是否使用自适应sigma选择（根据最近邻距离）
            regularization_lambda: L2正则化系数，防止过拟合
            backward_elimination: 是否使用后向剔除优化中心选择
            min_err_contribution: 后向剔除时的最小ERR贡献阈值
        """
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.acceptable_range = acceptable_range
        self.max_centers = max_centers
        self.err_threshold = err_threshold
        self.initial_sigma = initial_sigma
        self.adaptive_sigma = adaptive_sigma
        self.regularization_lambda = regularization_lambda
        self.backward_elimination = backward_elimination
        self.min_err_contribution = min_err_contribution
        
        # OLS特有属性
        self.selected_centers = []
        self.selected_sigmas = []
        self.err_ratios = []
        self.center_count = 0
        
        # 用于存储正交化过程的中间结果
        self.orthogonal_basis = None
        self.projection_coefficients = None
        
        # 详细计算过程记录（用于可视化）
        self.calculation_steps = []  # 记录每一步的详细信息
        self.gram_schmidt_steps = []  # Gram-Schmidt正交化步骤
        self.err_calculation_details = []  # ERR计算详情
        
    def _iterate(self):
        """单次迭代训练"""
        result = self._feed_forward(self.current_data[:-1])
        self._adjust_neurons(result)

    def _initialize_neurons(self):
        """使用OLS算法选择中心并初始化神经元"""
        # 设置最大中心数
        if self.max_centers is None:
            self.max_centers = min(len(self.training_dataset) // 2, 50)
        
        # 准备候选中心（使用所有训练数据点）
        candidate_centers = self.training_dataset[:, :-1]
        targets = self.training_dataset[:, -1]
        
        # 初始化ERR列表
        self.err_ratios = []
        self.selected_centers = []
        self.selected_sigmas = []
        self.calculation_steps = []
        self.gram_schmidt_steps = []
        self.err_calculation_details = []
        
        # 执行OLS中心选择
        self._ols_center_selection(candidate_centers, targets)
        
        # 根据选择的中心创建RBF神经元
        self._neurons = []
        for center, sigma in zip(self.selected_centers, self.selected_sigmas):
            neuron = RbfNeuron(center, sigma, gaussian, is_threshold=False)
            self._neurons.append(neuron)
        
        # 添加阈值神经元
        self._neurons.insert(0, RbfNeuron(is_threshold=True))
        
        # 使用最小二乘法计算初始权重
        self._initialize_weights_with_least_squares()

    def _ols_center_selection(self, candidates, targets):
        """
        OLS正交最小二乘中心选择算法
        
        通过Gram-Schmidt正交化过程逐步选择最有贡献的RBF中心
        
        算法基于公式：
        d = Xa + e
        其中通过Gram-Schmidt正交化：
        u₁ = x₁
        α_ik = (u_i^T x_k) / (u_i^T u_i), 1 ≤ i < k
        u_k = x_k - Σ(α_ik u_i), k = 1, 2, ..., M
        """
        n_samples = len(candidates)
        n_candidates = len(candidates)
        
        # 构建初始回归矩阵 X（所有候选中心的激活值）
        # phi[:, i] 对应 x_i（第i个回归变量）
        phi = np.zeros((n_samples, n_candidates))
        for i, center in enumerate(candidates):
            for j, data in enumerate(self.training_dataset[:, :-1]):
                phi[j, i] = gaussian(data, center, self.initial_sigma)
        
        # 初始化
        self.selected_centers = []
        self.selected_sigmas = []
        self.err_ratios = []
        selected_indices = []
        
        # 正交化矩阵 w（u向量）和系数矩阵 a（α系数）
        w = np.zeros((n_samples, n_candidates))
        a = np.zeros((n_candidates, n_candidates))
        
        # 初始化第一列：u₁ = x₁
        w[:, :] = phi[:, :]
        
        # 记录初始化步骤
        step_info = {
            'step': 0,
            'description': '初始化回归矩阵',
            'phi_shape': phi.shape,
            'n_candidates': n_candidates,
            'n_samples': n_samples
        }
        self.calculation_steps.append(step_info)
        
        # 迭代选择中心
        for m in range(min(self.max_centers, n_candidates)):
            # 计算每个候选中心的ERR（误差减少比）
            err_values = np.zeros(n_candidates)
            g_values = np.zeros(n_candidates)
            
            for i in range(n_candidates):
                if i in selected_indices:
                    continue
                    
                # 计算投影系数 g_i = (u_i^T d) / (u_i^T u_i)
                w_norm_sq = np.dot(w[:, i], w[:, i])
                if w_norm_sq < 1e-10:
                    continue
                    
                g_i = np.dot(w[:, i], targets) / w_norm_sq
                g_values[i] = g_i
                
                # 计算ERR = (g_i^2 * u_i^T u_i) / (d^T d)
                err_i = (g_i ** 2 * w_norm_sq) / (np.dot(targets, targets) + 1e-10)
                err_values[i] = err_i
            
            # 选择ERR最大的中心
            max_idx = np.argmax(err_values)
            max_err = err_values[max_idx]
            
            # 如果ERR低于阈值，停止选择
            if max_err < self.err_threshold:
                stop_info = {
                    'step': m + 1,
                    'description': 'ERR低于阈值，停止选择',
                    'threshold': float(self.err_threshold),
                    'max_err': float(max_err)
                }
                self.calculation_steps.append(stop_info)
                break
            
            # 记录选择的中心
            selected_indices.append(max_idx)
            self.selected_centers.append(candidates[max_idx].copy())
            self.selected_sigmas.append(self.initial_sigma)
            self.err_ratios.append(max_err)
            
            # 记录详细的ERR计算过程
            err_detail = {
                'step': m + 1,
                'center_index': int(max_idx),
                'err_value': float(max_err),
                'g_value': float(g_values[max_idx]),
                'w_norm_sq': float(np.dot(w[:, max_idx], w[:, max_idx])),
                'target_norm_sq': float(np.dot(targets, targets)),
                'description': f'选择中心#{m+1}: 候选索引{max_idx}, ERR={max_err:.6f}'
            }
            self.err_calculation_details.append(err_detail)
            self.calculation_steps.append(err_detail)
            
            # Gram-Schmidt正交化：更新所有未选择的向量
            # 对每个 x_j，计算 u_j = x_j - Σ(α_ij u_i)（减去所有已选向量的投影）
            if m < self.max_centers - 1:
                gs_step = {
                    'step': m + 1,
                    'description': f'Gram-Schmidt正交化步骤#{m+1}',
                    'selected_index': int(max_idx),
                    'orthogonalized_count': 0,
                    'alphas': []
                }
                
                for j in range(n_candidates):
                    if j not in selected_indices:
                        # 计算 α_ik = (u_i^T x_k) / (u_i^T u_i)
                        w_max_norm_sq = np.dot(w[:, max_idx], w[:, max_idx])
                        if w_max_norm_sq > 1e-10:
                            alpha_mj = np.dot(w[:, max_idx], phi[:, j]) / w_max_norm_sq
                            a[max_idx, j] = alpha_mj
                            # 更新 w[:, j]（即 u_j）：减去在 u_max_idx 上的投影
                            w[:, j] = w[:, j] - alpha_mj * w[:, max_idx]
                            
                            gs_step['orthogonalized_count'] += 1
                            if len(gs_step['alphas']) < 5:  # 只记录前5个α系数
                                gs_step['alphas'].append({
                                    'candidate_index': int(j),
                                    'alpha': float(alpha_mj)
                                })
                
                self.gram_schmidt_steps.append(gs_step)
                self.calculation_steps.append(gs_step)
        
        self.center_count = len(self.selected_centers)
        
        # 如果没有选择任何中心，使用数据集的均值
        if self.center_count == 0:
            self.selected_centers = [np.mean(candidates, axis=0)]
            self.selected_sigmas = [self.initial_sigma]
            self.center_count = 1
            # 如果没有选择中心，ERR值设为0
            if len(self.err_ratios) == 0:
                self.err_ratios = [0.0]
        
        # 确保err_ratios是Python列表（而不是numpy数组）
        self.err_ratios = [float(err) for err in self.err_ratios]

    def _initialize_weights_with_least_squares(self):
        """使用最小二乘法计算初始权重"""
        n_samples = len(self.training_dataset)
        n_neurons = len(self._neurons)
        
        # 构建设计矩阵
        phi = np.zeros((n_samples, n_neurons))
        for i, data in enumerate(self.training_dataset):
            for j, neuron in enumerate(self._neurons):
                if neuron.is_threshold:
                    phi[i, j] = 1.0
                else:
                    phi[i, j] = gaussian(data[:-1], neuron.mean, neuron.standard_deviation)
        
        # 目标值
        targets = self.training_dataset[:, -1]
        
        # 最小二乘解：w = (Phi^T * Phi)^(-1) * Phi^T * y
        try:
            weights = np.linalg.lstsq(phi, targets, rcond=None)[0]
            for i, neuron in enumerate(self._neurons):
                neuron.synaptic_weight = weights[i]
        except np.linalg.LinAlgError:
            # 如果奇异矩阵，使用随机初始化
            pass

    def _feed_forward(self, data):
        """前向传播"""
        for neuron in self._neurons:
            neuron.data = data
        return sum(neuron.result for neuron in self._neurons)

    def _adjust_neurons(self, output):
        """调整神经元参数"""
        expect = self.current_data[-1]
        for neuron in self._neurons:
            new_synaptic_weight_diff = self._get_synaptic_weight_diff(
                output, expect, neuron
            )
            
            # 更新中心和标准差（仅对非阈值神经元）
            if not neuron.is_threshold and neuron.standard_deviation != 0:
                data_mean_diff = neuron.data - neuron.mean
                
                # 梯度下降更新均值
                new_mean = (neuron.mean
                           + new_synaptic_weight_diff
                           * neuron.synaptic_weight
                           * data_mean_diff
                           / (neuron.standard_deviation**2 + 1e-10))
                
                # 梯度下降更新标准差
                new_standard_deviation = (neuron.standard_deviation
                                         + new_synaptic_weight_diff
                                         * neuron.synaptic_weight
                                         * data_mean_diff.dot(data_mean_diff)
                                         / (neuron.standard_deviation**3 + 1e-10))
                
                # 防止标准差过小
                new_standard_deviation = max(new_standard_deviation, 0.01)
                
                neuron.mean = new_mean
                neuron.standard_deviation = new_standard_deviation
            
            # 更新权重
            neuron.synaptic_weight += new_synaptic_weight_diff

    def _get_synaptic_weight_diff(self, output, expect, neuron):
        """计算权重变化量"""
        if neuron.is_threshold:
            return self.current_learning_rate * (expect - output)
        
        activation = neuron.activation_function(
            neuron.data, neuron.mean, neuron.standard_deviation
        )
        return self.current_learning_rate * (expect - output) * activation

    def _correct_rate(self, dataset):
        """计算正确率"""
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            if data[-1] - self.acceptable_range < result < data[-1] + self.acceptable_range:
                correct_count += 1
        
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

