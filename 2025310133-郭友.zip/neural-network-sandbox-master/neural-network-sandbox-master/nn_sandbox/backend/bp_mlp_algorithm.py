# nn_sandbox/backend/bp_mlp_algorithm.py
import numpy as np
import time
from nn_sandbox.backend.bp_from_scratch import MLP, one_hot, accuracy


class BpMlpAlgorithm:
    def __init__(self, observer, total_epoches=300, lr=0.5, test_ratio=0.2, layer_sizes=[16, 12, 8, 3]):
        self.observer = observer
        self.total_epoches = total_epoches
        self.lr = lr
        self.test_ratio = test_ratio
        self.layer_sizes = layer_sizes
        self.has_finished = True
        self.best_correct_rate = 0.0
        self.current_correct_rate = 0.0
        self.test_correct_rate = 0.0

    def notify(self, name, value):
        """通知前端刷新"""
        self.observer.notify(name, value)

    def start(self):
        self.has_finished = False
        self.notify('has_finished', False)
        self.run()
        self.has_finished = True
        self.notify('has_finished', True)

    def run(self):
        n_features = self.layer_sizes[0]
        n_classes = self.layer_sizes[-1]
        n_samples = 120
        X = np.random.randn(n_features, n_samples)
        labels = np.random.randint(0, n_classes, n_samples)
        Y = one_hot(labels, n_classes)

        split = int(n_samples * (1 - self.test_ratio))
        X_train, X_val = X[:, :split], X[:, split:]
        Y_train, Y_val = Y[:, :split], Y[:, split:]
        y_val_idx = labels[split:]

        model = MLP(self.layer_sizes, activation='sigmoid', lr=self.lr)
        for epoch in range(1, self.total_epoches + 1):
            model.fit(X_train, Y_train, epochs=1, batch_size=16, verbose=False)
            y_pred_val = model.predict(X_val)
            acc = accuracy(y_val_idx, y_pred_val)
            self.current_correct_rate = acc
            if acc > self.best_correct_rate:
                self.best_correct_rate = acc
            self.notify('current_correct_rate', self.current_correct_rate)
            self.notify('best_correct_rate', self.best_correct_rate)
            self.notify('current_iterations', epoch)
            time.sleep(0.05)  # 控制刷新速度
        self.test_correct_rate = self.best_correct_rate
        self.notify('test_correct_rate', self.test_correct_rate)
