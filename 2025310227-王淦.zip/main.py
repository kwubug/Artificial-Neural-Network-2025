import sys
import os
import importlib.util
from PySide6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget,
                               QVBoxLayout, QMessageBox)
from PySide6.QtCore import Qt
import matplotlib

matplotlib.use('Qt5Agg')

# 导入各个模块
from tabs.ols_regression_tab import OLSRegressionTab
from tabs.tsp_solver_tab import TSPSolverTab
from tabs.hopfield_network_tab import HopfieldNetworkTab
from tabs.bp_network_tab import BPNetworkTab
from tabs.boltzmann_machine_tab import BoltzmannMachineTab
from tabs.optimization_tab import OptimizationTab


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("机器学习算法工具箱")
        self.setGeometry(100, 100, 1200, 800)

        # 创建中央部件和布局
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # 创建标签页控件
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabPosition(QTabWidget.North)
        self.tab_widget.setMovable(True)

        # 创建各个标签页
        self.ols_tab = OLSRegressionTab()
        self.tsp_tab = TSPSolverTab()
        self.hopfield_tab = HopfieldNetworkTab()
        self.bp_tab = BPNetworkTab()
        self.boltzmann_tab = BoltzmannMachineTab()
        self.optimization_tab = OptimizationTab()

        # 添加标签页
        self.tab_widget.addTab(self.ols_tab, "OLS线性回归")
        self.tab_widget.addTab(self.tsp_tab, "TSP求解器")
        self.tab_widget.addTab(self.hopfield_tab, "Hopfield网络")
        self.tab_widget.addTab(self.bp_tab, "BP神经网络")
        self.tab_widget.addTab(self.boltzmann_tab, "Boltzmann机")
        self.tab_widget.addTab(self.optimization_tab, "梯度下降优化算法")

        layout.addWidget(self.tab_widget)

        # 连接标签页切换信号
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

    def on_tab_changed(self, index):
        """标签页切换时的处理"""
        current_tab = self.tab_widget.widget(index)
        current_tab_name = self.tab_widget.tabText(index)
        print(f"切换到标签页: {current_tab_name}")


def main():
    # 创建应用实例
    app = QApplication(sys.argv)

    # 设置应用样式
    app.setStyle('Fusion')

    # 创建并显示主窗口
    window = MainWindow()
    window.show()

    # 运行应用
    sys.exit(app.exec())


if __name__ == "__main__":
    main()