import PyQt5.QtCore

from .bridge import Bridge, BridgeProperty
from .perceptron_bridge import PerceptronBridge
from .mlp_bridge import MlpBridge
from .rbfn_bridge import RbfnBridge
from .som_bridge import SomBridge
from .bp_bridge import BpBridge
from .hopfield_bridge import HopfieldBridge
from .tsp_bridge import TSPBridge
from .bm_bridge import BMBridge