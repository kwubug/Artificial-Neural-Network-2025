import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QGroupBox, QLabel, QLineEdit,
                             QPushButton, QComboBox, QTextEdit, QSpinBox,
                             QDoubleSpinBox, QSplitter, QProgressBar, QTabWidget,
                             QFormLayout, QFrame, QScrollArea, QGridLayout)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QPalette, QColor
import time


class TrainingThread(QThread):
    update_signal = pyqtSignal(int, float)
    finished_signal = pyqtSignal(int, float)
    log_signal = pyqtSignal(str)  # 日志信息

    def __init__(self, nn, X, T, n_input, n_hidden, n_output, learning_rate, activation_type):
        super().__init__()
        self.nn = nn
        self.X = X
        self.T = T
        self.n_input = n_input
        self.n_hidden = n_hidden
        self.n_output = n_output
        self.learning_rate = learning_rate
        self.activation_type = activation_type
        self.is_running = True

    def run(self):
        """训练线程主函数"""
        try:
            # 初始化权重
            self.nn.initialize_weights(self.n_input, self.n_hidden, self.n_output)
            self.nn.history = []

            # 根据激活函数类型调整目标输出范围
            if self.activation_type == 'unipolar':
                T_adj = np.clip(self.T, 0.1, 0.9)  # 避免饱和区
            else:
                T_adj = np.clip(self.T, -0.9, 0.9)

            n_samples = self.X.shape[0]
            max_epochs = 10000
            error_threshold = 1e-5

            self.log_signal.emit(f"开始训练神经网络...")
            self.log_signal.emit(f"网络结构: {self.n_input}-{self.n_hidden}-{self.n_output}")
            self.log_signal.emit(f"学习率: {self.learning_rate}")
            self.log_signal.emit(f"激活函数: {self.activation_type}")

            for epoch in range(max_epochs):
                if not self.is_running:
                    break

                total_error = 0

                for i in range(n_samples):
                    # 前向传播
                    h_out, o_out, x_bias, h_bias, net_h, net_o = self.nn.forward(self.X[i], self.activation_type)

                    # 计算误差
                    error = 0.5 * np.sum((T_adj[i] - o_out) ** 2)
                    total_error += error

                    # 反向传播
                    # 输出层误差
                    delta_o = (T_adj[i] - o_out) * self.nn.dsigmoid(net_o, self.activation_type)

                    # 隐藏层误差
                    delta_h = np.dot(self.nn.W2[:, :-1].T, delta_o) * self.nn.dsigmoid(net_h, self.activation_type)

                    # 权重更新
                    self.nn.W2 += self.learning_rate * np.outer(delta_o, h_bias)
                    self.nn.W1 += self.learning_rate * np.outer(delta_h, x_bias)

                # 计算平均误差
                avg_error = total_error / n_samples
                self.nn.history.append(avg_error)

                # 发送更新信号
                progress = int((epoch + 1) / max_epochs * 100)
                self.update_signal.emit(progress, avg_error)

                # 检查收敛
                if avg_error < error_threshold:
                    self.log_signal.emit(f"训练收敛于第 {epoch + 1} 轮")
                    break

                # 降低更新频率，避免界面卡顿
                if epoch % 10 == 0:
                    time.sleep(0.01)

            self.finished_signal.emit(epoch + 1, avg_error)

        except Exception as e:
            self.log_signal.emit(f"训练错误: {str(e)}")

    def stop(self):
        """停止训练"""
        self.is_running = False


class NeuralNetwork:
    """三层前馈神经网络BP算法实现"""

    def __init__(self):
        self.W1 = None  # 输入层到隐藏层权重
        self.W2 = None  # 隐藏层到输出层权重
        self.history = []  # 训练历史记录

    def sigmoid(self, x, activation_type):
        """Sigmoid激活函数"""
        if activation_type == 'unipolar':
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))  # 防止数值溢出
        else:  # bipolar
            return (1 - np.exp(-np.clip(x, -500, 500))) / (1 + np.exp(-np.clip(x, -500, 500)))

    def dsigmoid(self, x, activation_type):
        """Sigmoid激活函数的导数"""
        if activation_type == 'unipolar':
            s = self.sigmoid(x, 'unipolar')
            return s * (1 - s)
        else:  # bipolar
            s = self.sigmoid(x, 'bipolar')
            return 0.5 * (1 - s ** 2)

    def initialize_weights(self, n_input, n_hidden, n_output):
        """初始化权重矩阵"""
        # 输入层到隐藏层 (包含偏置)
        self.W1 = np.random.uniform(-1, 1, (n_hidden, n_input + 1))
        # 隐藏层到输出层 (包含偏置)
        self.W2 = np.random.uniform(-1, 1, (n_output, n_hidden + 1))
        return self.W1, self.W2

    def forward(self, x, activation_type):
        """前向传播"""
        # 输入层到隐藏层
        x_bias = np.concatenate([x, [1]])  # 添加偏置
        net_h = np.dot(self.W1, x_bias)
        h_out = self.sigmoid(net_h, activation_type)

        # 隐藏层到输出层
        h_bias = np.concatenate([h_out, [1]])  # 添加偏置
        net_o = np.dot(self.W2, h_bias)
        o_out = self.sigmoid(net_o, activation_type)

        return h_out, o_out, x_bias, h_bias, net_h, net_o

    def predict(self, X, activation_type):
        """预测函数"""
        predictions = []
        for x in X:
            _, o_out, _, _, _, _ = self.forward(x, activation_type)
            predictions.append(o_out)
        return np.array(predictions)


class NeuralNetworkGUI(QMainWindow):
    """神经网络可视化界面"""

    def __init__(self):
        super().__init__()
        self.nn = NeuralNetwork()
        self.training_thread = None
        self.init_ui()

    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("三层前馈神经网络BP算法可视化 - 优化版")
        self.setGeometry(100, 100, 1400, 900)

        # 设置样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f7fa;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #bdc3c7;
                border-radius: 5px;
                margin-top: 1ex;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                color: #2c3e50;
            }
            QPushButton {
                background-color: #3498db;
                border: none;
                color: white;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
            }
            QTextEdit {
                border: 1px solid #bdc3c7;
                border-radius: 4px;
                background-color: white;
            }
            QSpinBox, QDoubleSpinBox, QComboBox {
                padding: 5px;
                border: 1px solid #bdc3c7;
                border-radius: 4px;
                background-color: white;
            }
        """)

        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 主布局
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # 左侧控制面板
        control_panel = self.create_control_panel()
        # 右侧显示面板
        display_panel = self.create_display_panel()

        # 使用分割器
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(control_panel)
        splitter.addWidget(display_panel)
        splitter.setSizes([400, 1000])

        main_layout.addWidget(splitter)

    def create_control_panel(self):
        """控制面板设置 """
        panel = QWidget()
        panel.setMaximumWidth(450)
        layout = QVBoxLayout()

        # 标题
        title_label = QLabel("神经网络配置")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setStyleSheet("color: #2c3e50; margin: 10px;")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # 网络参数设置
        param_group = QGroupBox("网络参数设置")
        param_layout = QFormLayout()

        # 输入层节点数
        self.input_nodes = QSpinBox()
        self.input_nodes.setRange(1, 100)
        self.input_nodes.setValue(2)
        param_layout.addRow("输入层节点数:", self.input_nodes)

        # 隐藏层节点数
        self.hidden_nodes = QSpinBox()
        self.hidden_nodes.setRange(1, 100)
        self.hidden_nodes.setValue(4)
        param_layout.addRow("隐藏层节点数:", self.hidden_nodes)

        # 输出层节点数
        self.output_nodes = QSpinBox()
        self.output_nodes.setRange(1, 100)
        self.output_nodes.setValue(1)
        param_layout.addRow("输出层节点数:", self.output_nodes)

        # 学习率
        self.learning_rate = QDoubleSpinBox()
        self.learning_rate.setRange(0.001, 1.0)
        self.learning_rate.setValue(0.5)
        self.learning_rate.setSingleStep(0.1)
        self.learning_rate.setDecimals(3)
        param_layout.addRow("学习率:", self.learning_rate)

        # 激活函数
        self.activation_combo = QComboBox()
        self.activation_combo.addItems(["单极性Sigmoid", "双极性Sigmoid"])
        param_layout.addRow("激活函数:", self.activation_combo)

        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        # 数据集选择
        data_group = QGroupBox("数据集配置")
        data_layout = QFormLayout()

        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems(["异或问题", "与门问题", "或门问题", "自定义数据"])
        data_layout.addRow("数据集:", self.dataset_combo)

        data_group.setLayout(data_layout)
        layout.addWidget(data_group)

        # 训练控制
        train_group = QGroupBox("训练控制")
        train_layout = QVBoxLayout()

        # 训练按钮
        self.train_btn = QPushButton("开始训练")
        self.train_btn.clicked.connect(self.start_training)
        train_layout.addWidget(self.train_btn)

        # 停止按钮
        self.stop_btn = QPushButton("停止训练")
        self.stop_btn.clicked.connect(self.stop_training)
        self.stop_btn.setEnabled(False)
        train_layout.addWidget(self.stop_btn)

        # 测试按钮
        self.test_btn = QPushButton("测试网络")
        self.test_btn.clicked.connect(self.test_network)
        train_layout.addWidget(self.test_btn)

        # 重置按钮
        self.reset_btn = QPushButton("重置网络")
        self.reset_btn.clicked.connect(self.reset_network)
        train_layout.addWidget(self.reset_btn)

        train_group.setLayout(train_layout)
        layout.addWidget(train_group)

        # 训练进度
        progress_group = QGroupBox("训练进度")
        progress_layout = QVBoxLayout()

        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        progress_layout.addWidget(self.progress_bar)

        self.status_label = QLabel("准备就绪")
        self.status_label.setAlignment(Qt.AlignCenter)
        progress_layout.addWidget(self.status_label)

        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)

        # 网络信息
        info_group = QGroupBox("网络信息")
        info_layout = QFormLayout()

        self.epoch_label = QLabel("0")
        info_layout.addRow("当前迭代:", self.epoch_label)

        self.error_label = QLabel("0.000000")
        info_layout.addRow("当前误差:", self.error_label)

        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        # 日志显示
        log_group = QGroupBox("训练日志")
        log_layout = QVBoxLayout()
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(200)
        log_layout.addWidget(self.log_text)
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)

        layout.addStretch()
        panel.setLayout(layout)
        return panel

    def create_display_panel(self):
        """创建显示面板"""
        panel = QWidget()
        layout = QVBoxLayout()

        # 创建标签页
        self.tab_widget = QTabWidget()

        # 误差曲线标签页
        self.error_tab = QWidget()
        error_layout = QVBoxLayout()
        self.figure_error = Figure(figsize=(10, 6))
        self.canvas_error = FigureCanvas(self.figure_error)
        self.ax_error = self.figure_error.add_subplot(111)
        error_layout.addWidget(self.canvas_error)
        self.error_tab.setLayout(error_layout)

        # 网络结构标签页
        self.structure_tab = QWidget()
        structure_layout = QVBoxLayout()
        self.figure_structure = Figure(figsize=(10, 6))
        self.canvas_structure = FigureCanvas(self.figure_structure)
        self.ax_structure = self.figure_structure.add_subplot(111)
        structure_layout.addWidget(self.canvas_structure)
        self.structure_tab.setLayout(structure_layout)

        # 权重分布标签页
        self.weights_tab = QWidget()
        weights_layout = QVBoxLayout()
        self.figure_weights = Figure(figsize=(10, 6))
        self.canvas_weights = FigureCanvas(self.figure_weights)
        self.ax_weights = self.figure_weights.add_subplot(111)
        weights_layout.addWidget(self.canvas_weights)
        self.weights_tab.setLayout(weights_layout)

        self.tab_widget.addTab(self.error_tab, "误差曲线")
        self.tab_widget.addTab(self.structure_tab, "网络结构")
        self.tab_widget.addTab(self.weights_tab, "权重分布")

        layout.addWidget(self.tab_widget)
        panel.setLayout(layout)

        # 初始化图表
        self.update_structure_plot()
        self.update_weights_plot()

        return panel

    def update_structure_plot(self):
        """更新网络结构图"""
        self.ax_structure.clear()

        n_input = self.input_nodes.value()
        n_hidden = self.hidden_nodes.value()
        n_output = self.output_nodes.value()

        # 网络结构
        layer_spacing = 2.0
        neuron_radius = 0.2

        # 输入层
        for i in range(n_input):
            circle = plt.Circle((0, -i), neuron_radius, fill=True, color='lightblue', ec='black')
            self.ax_structure.add_patch(circle)
            self.ax_structure.text(0, -i, f'x{i + 1}', ha='center', va='center', fontsize=8)

        # 隐藏层
        for i in range(n_hidden):
            circle = plt.Circle((layer_spacing, -i * max(1, n_hidden / n_input)), neuron_radius,
                                fill=True, color='lightgreen', ec='black')
            self.ax_structure.add_patch(circle)
            self.ax_structure.text(layer_spacing, -i * max(1, n_hidden / n_input), f'h{i + 1}',
                                   ha='center', va='center', fontsize=8)

        # 输出层
        for i in range(n_output):
            circle = plt.Circle((2 * layer_spacing, -i * max(1, n_output / n_input)), neuron_radius,
                                fill=True, color='lightcoral', ec='black')
            self.ax_structure.add_patch(circle)
            self.ax_structure.text(2 * layer_spacing, -i * max(1, n_output / n_input), f'y{i + 1}',
                                   ha='center', va='center', fontsize=8)

        self.ax_structure.set_xlim(-0.5, 2 * layer_spacing + 0.5)
        self.ax_structure.set_ylim(-max(n_input, n_hidden, n_output) - 0.5, 0.5)
        self.ax_structure.set_aspect('equal')
        self.ax_structure.axis('off')
        self.ax_structure.set_title('神经网络结构示意图')

        self.canvas_structure.draw()

    def update_weights_plot(self):
        """更新权重分布图"""
        self.ax_weights.clear()

        if self.nn.W1 is not None and self.nn.W2 is not None:
            # 合并所有权重
            all_weights = np.concatenate([self.nn.W1.flatten(), self.nn.W2.flatten()])

            # 绘制权重分布直方图
            self.ax_weights.hist(all_weights, bins=50, alpha=0.7, color='skyblue', edgecolor='black')
            self.ax_weights.set_xlabel('权重值')
            self.ax_weights.set_ylabel('频数')
            self.ax_weights.set_title('权重分布直方图')
            self.ax_weights.grid(True, alpha=0.3)

        self.canvas_weights.draw()

    def get_training_data(self):
        """获取训练数据"""
        dataset = self.dataset_combo.currentText()
        activation_type = 'unipolar' if self.activation_combo.currentText() == '单极性Sigmoid' else 'bipolar'

        if dataset == "异或问题":
            X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
            if activation_type == 'unipolar':
                T = np.array([[0], [1], [1], [0]])
            else:
                T = np.array([[-1], [1], [1], [-1]])
        elif dataset == "与门问题":
            X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
            if activation_type == 'unipolar':
                T = np.array([[0], [0], [0], [1]])
            else:
                T = np.array([[-1], [-1], [-1], [1]])
        elif dataset == "或门问题":
            X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
            if activation_type == 'unipolar':
                T = np.array([[0], [1], [1], [1]])
            else:
                T = np.array([[-1], [1], [1], [1]])
        else:
            X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
            if activation_type == 'unipolar':
                T = np.array([[0], [1], [1], [0]])
            else:
                T = np.array([[-1], [1], [1], [-1]])

        return X, T

    def start_training(self):
        """开始训练网络"""
        if self.training_thread and self.training_thread.isRunning():
            return

        try:
            # 获取参数
            n_input = self.input_nodes.value()
            n_hidden = self.hidden_nodes.value()
            n_output = self.output_nodes.value()
            learning_rate = self.learning_rate.value()
            activation_type = 'unipolar' if self.activation_combo.currentText() == '单极性Sigmoid' else 'bipolar'

            # 获取训练数据
            X, T = self.get_training_data()

            # 更新网络结构图
            self.update_structure_plot()

            # 初始化网络
            self.nn = NeuralNetwork()

            # 创建训练线程
            self.training_thread = TrainingThread(
                self.nn, X, T, n_input, n_hidden, n_output, learning_rate, activation_type
            )

            # 连接信号
            self.training_thread.update_signal.connect(self.update_training_progress)
            self.training_thread.finished_signal.connect(self.training_finished)
            self.training_thread.log_signal.connect(self.log_text.append)

            # 更新按钮状态
            self.train_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.test_btn.setEnabled(False)
            self.reset_btn.setEnabled(False)

            # 开始训练
            self.training_thread.start()

        except Exception as e:
            self.log_text.append(f"训练错误: {str(e)}")

    def stop_training(self):
        """停止训练"""
        if self.training_thread and self.training_thread.isRunning():
            self.training_thread.stop()
            self.training_thread.wait()
            self.log_text.append("训练已停止")

            # 更新按钮状态
            self.train_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)
            self.test_btn.setEnabled(True)
            self.reset_btn.setEnabled(True)

    def reset_network(self):
        """重置网络"""
        self.nn = NeuralNetwork()
        self.progress_bar.setValue(0)
        self.status_label.setText("网络已重置")
        self.epoch_label.setText("0")
        self.error_label.setText("0.000000")
        self.log_text.append("网络权重已重置")

        # 清空误差曲线
        self.ax_error.clear()
        self.ax_error.set_xlabel('迭代次数')
        self.ax_error.set_ylabel('平均误差')
        self.ax_error.set_title('训练误差曲线')
        self.ax_error.grid(True)
        self.canvas_error.draw()

        # 更新权重分布图
        self.update_weights_plot()

    def update_training_progress(self, progress, error):
        """更新训练进度"""
        self.progress_bar.setValue(progress)
        self.error_label.setText(f"{error:.6f}")
        self.epoch_label.setText(str(len(self.nn.history)))

        # 每10次迭代更新一次误差曲线，避免界面卡顿
        if len(self.nn.history) % 10 == 0:
            self.update_error_plot()

    def training_finished(self, epochs, final_error):
        self.progress_bar.setValue(100)
        self.status_label.setText("训练完成")
        self.epoch_label.setText(str(epochs))
        self.error_label.setText(f"{final_error:.6f}")

        # 更新误差曲线
        self.update_error_plot()

        # 更新权重分布图
        self.update_weights_plot()

        # 更新按钮状态
        self.train_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.test_btn.setEnabled(True)
        self.reset_btn.setEnabled(True)

        self.log_text.append(f"训练完成! 迭代次数: {epochs}, 最终误差: {final_error:.6f}")

    def update_error_plot(self):
        """更新误差曲线图"""
        self.ax_error.clear()

        if len(self.nn.history) > 0:
            self.ax_error.plot(self.nn.history, 'b-', linewidth=2)
            self.ax_error.set_xlabel('迭代次数')
            self.ax_error.set_ylabel('平均误差')
            self.ax_error.set_title('训练误差曲线')
            self.ax_error.grid(True)
            self.ax_error.set_yscale('log')

        self.canvas_error.draw()

    def test_network(self):
        """测试网络性能"""
        try:
            activation_type = 'unipolar' if self.activation_combo.currentText() == '单极性Sigmoid' else 'bipolar'

            # 测试数据
            X_test, T_test = self.get_training_data()

            predictions = self.nn.predict(X_test, activation_type)

            self.log_text.append("网络测试结果:")
            for i, (x, t, pred) in enumerate(zip(X_test, T_test, predictions)):
                expected = t[0]
                actual = pred[0]
                error = abs(expected - actual)
                self.log_text.append(f"输入: {x} -> 期望: {expected:.1f}, 实际: {actual:.4f}, 误差: {error:.4f}")

        except Exception as e:
            self.log_text.append(f"测试错误: {str(e)}")


def main():
    app = QApplication(sys.argv)

    app.setStyle('Fusion')

    window = NeuralNetworkGUI()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
