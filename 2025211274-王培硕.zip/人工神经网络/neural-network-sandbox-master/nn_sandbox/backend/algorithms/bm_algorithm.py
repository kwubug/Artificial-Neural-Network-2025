import numpy as np
import copy
import threading
import time
import random
from collections import defaultdict


class BMAlgorithm:
    """Boltzmann Machine（玻尔兹曼机）实现"""
    
    def __init__(self, num_units=10, visible_units=None, learning_rate=0.1, 
                 temperature=1.0, momentum=0.9, batch_size=10):
        """
        初始化Boltzmann Machine
        
        Args:
            num_units: 总单元数（包括可见单元和隐藏单元）
            visible_units: 可见单元数，如果为None则使用num_units的一半
            learning_rate: 学习率
            temperature: 温度参数
            momentum: 动量参数
            batch_size: 批量大小
        """
        self.num_units = num_units
        self.visible_units = visible_units if visible_units else num_units // 2
        self.hidden_units = num_units - self.visible_units
        self.learning_rate = learning_rate
        self.temperature = temperature
        self.momentum = momentum
        self.batch_size = batch_size
        
        # 初始化权重和偏置
        self.weights = np.random.randn(num_units, num_units) * 0.01
        np.fill_diagonal(self.weights, 0)  # 无自连接
        self.visible_bias = np.zeros(self.visible_units)
        self.hidden_bias = np.zeros(self.hidden_units)
        
        # 动量相关
        self.weight_velocity = np.zeros_like(self.weights)
        self.visible_velocity = np.zeros_like(self.visible_bias)
        self.hidden_velocity = np.zeros_like(self.hidden_bias)
        
        # 训练历史
        self.energy_history = []
        self.reconstruction_error_history = []
        self.current_energy = 0.0
        self.current_reconstruction_error = 1.0
        
        self._should_stop = False
        self.training_data = None
    
    def stop(self):
        """停止训练"""
        self._should_stop = True
    
    def sigmoid(self, x):
        """Sigmoid激活函数"""
        return 1.0 / (1.0 + np.exp(-x / self.temperature))
    
    def energy(self, visible_state, hidden_state):
        """计算系统能量
        
        E = -sum(i,j) w_ij * v_i * h_j - sum(i) b_i * v_i - sum(j) c_j * h_j
        """
        visible_state = np.array(visible_state)
        hidden_state = np.array(hidden_state)
        
        # 可见单元和隐藏单元之间的能量
        vh_energy = -np.dot(np.dot(visible_state, 
                                  self.weights[:self.visible_units, self.visible_units:]),
                           hidden_state)
        
        # 偏置能量
        visible_energy = -np.dot(self.visible_bias, visible_state)
        hidden_energy = -np.dot(self.hidden_bias, hidden_state)
        
        return vh_energy + visible_energy + hidden_energy
    
    def sample_hidden(self, visible_state):
        """根据可见状态采样隐藏状态"""
        activation = np.dot(visible_state, 
                           self.weights[:self.visible_units, self.visible_units:]) + self.hidden_bias
        prob = self.sigmoid(activation)
        hidden_state = (np.random.random(self.hidden_units) < prob).astype(float)
        return hidden_state, prob
    
    def sample_visible(self, hidden_state):
        """根据隐藏状态采样可见状态"""
        activation = np.dot(hidden_state, 
                           self.weights[:self.visible_units, self.visible_units:].T) + self.visible_bias
        prob = self.sigmoid(activation)
        visible_state = (np.random.random(self.visible_units) < prob).astype(float)
        return visible_state, prob
    
    def gibbs_sampling(self, visible_state, k=1):
        """Gibbs采样"""
        v = copy.copy(visible_state)
        
        for _ in range(k):
            h, _ = self.sample_hidden(v)
            v, _ = self.sample_visible(h)
        
        return v
    
    def contrastive_divergence(self, data_batch, k=1):
        """对比散度算法"""
        batch_size = len(data_batch)
        data_batch = np.array(data_batch)
        
        # Positive phase
        pos_hidden_probs = np.zeros((batch_size, self.hidden_units))
        pos_hidden_states = np.zeros((batch_size, self.hidden_units))
        pos_associations = np.zeros((self.visible_units, self.hidden_units))
        
        for i, visible_state in enumerate(data_batch):
            hidden_state, hidden_prob = self.sample_hidden(visible_state)
            pos_hidden_probs[i] = hidden_prob
            pos_hidden_states[i] = hidden_state
            pos_associations += np.outer(visible_state, hidden_prob)
        
        # Negative phase
        neg_visible_states = np.zeros_like(data_batch)
        neg_hidden_probs = np.zeros((batch_size, self.hidden_units))
        neg_associations = np.zeros((self.visible_units, self.hidden_units))
        
        for i in range(batch_size):
            # 从数据重构的可见状态开始Gibbs采样
            neg_visible_state = self.gibbs_sampling(data_batch[i], k)
            neg_visible_states[i] = neg_visible_state
            
            _, hidden_prob = self.sample_hidden(neg_visible_state)
            neg_hidden_probs[i] = hidden_prob
            neg_associations += np.outer(neg_visible_state, hidden_prob)
        
        # 计算梯度
        batch_size = float(batch_size)
        dW = (pos_associations - neg_associations) / batch_size
        dv = np.mean(data_batch - neg_visible_states, axis=0)
        dh = np.mean(pos_hidden_probs - neg_hidden_probs, axis=0)
        
        # 更新权重和偏置（使用动量）- 只处理可见和隐藏单元之间的连接
        # 获取当前可见-隐藏部分的速度
        visible_hidden_velocity = self.weight_velocity[:self.visible_units, self.visible_units:]
        # 计算新的速度
        new_velocity = self.momentum * visible_hidden_velocity + self.learning_rate * dW
        # 更新权重矩阵
        self.weights[:self.visible_units, self.visible_units:] += new_velocity
        self.weights[self.visible_units:, :self.visible_units] += new_velocity.T
        # 更新速度矩阵
        self.weight_velocity[:self.visible_units, self.visible_units:] = new_velocity
        
        # 更新偏置的速度和值
        self.visible_velocity = self.momentum * self.visible_velocity + self.learning_rate * dv
        self.hidden_velocity = self.momentum * self.hidden_velocity + self.learning_rate * dh
        
        self.visible_bias += self.visible_velocity
        self.hidden_bias += self.hidden_velocity
        
        # 计算重构误差
        reconstruction_error = np.mean((data_batch - neg_visible_states) ** 2)
        
        return reconstruction_error
    
    def train(self, training_data, epochs=100, k=1):
        """训练Boltzmann Machine
        
        Args:
            training_data: 训练数据列表，每个样本是一个二进制向量
            epochs: 训练轮数
            k: Gibbs采样步数
            
        Returns:
            bool: 训练是否成功完成
        """
        self.training_data = training_data
        self.energy_history = []
        self.reconstruction_error_history = []
        
        num_samples = len(training_data)
        
        for epoch in range(epochs):
            if self._should_stop:
                break
            
            # 随机打乱数据
            np.random.shuffle(training_data)
            
            epoch_errors = []
            epoch_energies = []
            
            # 分批训练
            for i in range(0, num_samples, self.batch_size):
                if self._should_stop:
                    break
                
                batch = training_data[i:i + self.batch_size]
                if len(batch) < self.batch_size:
                    continue
                
                # 执行对比散度
                reconstruction_error = self.contrastive_divergence(batch, k)
                epoch_errors.append(reconstruction_error)
                
                # 计算平均能量
                avg_energy = 0
                for sample in batch:
                    hidden_state, _ = self.sample_hidden(sample)
                    energy = self.energy(sample, hidden_state)
                    avg_energy += energy
                avg_energy /= len(batch)
                epoch_energies.append(avg_energy)
            
            # 记录epoch统计信息
            avg_error = np.mean(epoch_errors) if epoch_errors else 1.0
            avg_energy = np.mean(epoch_energies) if epoch_energies else 0.0
            
            self.reconstruction_error_history.append(avg_error)
            self.energy_history.append(avg_energy)
            self.current_reconstruction_error = avg_error
            self.current_energy = avg_energy
            
            # 模拟延迟以支持实时可视化
            time.sleep(0.01)
        
        return not self._should_stop
    
    def reconstruct(self, visible_state, k=10):
        """重构可见状态"""
        return self.gibbs_sampling(visible_state, k)
    
    def get_visualization_data(self):
        """获取可视化数据
        
        Returns:
            dict: 包含能量历史、重构误差历史、权重等可视化所需数据
        """
        return {
            'weights': self.weights,
            'visible_bias': self.visible_bias,
            'hidden_bias': self.hidden_bias,
            'energy_history': self.energy_history,
            'reconstruction_error_history': self.reconstruction_error_history,
            'current_energy': self.current_energy,
            'current_reconstruction_error': self.current_reconstruction_error,
            'num_units': self.num_units,
            'visible_units': self.visible_units,
            'hidden_units': self.hidden_units
        }