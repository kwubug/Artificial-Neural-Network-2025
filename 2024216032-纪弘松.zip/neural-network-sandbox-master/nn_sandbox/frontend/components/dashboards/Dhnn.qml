import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import '..'

Page {
    name: 'DHNN'

    // 直接绑定到 Python 中的属性
    property var currentState: DHNN.currentState
    property bool attractorFound: DHNN.attractorFound
    property real energy: DHNN.energy

    ColumnLayout {
        GroupBox {
            title: "Initial State"
            Layout.fillWidth: true
            RowLayout {
                TextField {
                    id: stateInput
                    width: 200
                    placeholderText: "Enter initial state (comma separated)"
                }
                Button {
                    text: "Run DHNN"
                    onClicked: {
                        // 获取输入框的值，并将其转换为整数数组
                        var initialState = stateInput.text.split(",").map(function(x) { return parseInt(x.trim()); });

                        // 确保输入有效
                        if (initialState.length > 0) {
                            // 调用后端方法设置初始状态
                            DHNN.setInitialState(initialState);
                            DHNN.start();  // 启动线程
                        } else {
                            console.log("Invalid initial state input");
                        }
                    }
                }
            }
        }

        GroupBox {
            title: "Information"
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2

                Label {
                    text: "Current State"
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentState.join(", ")
                    Layout.fillWidth: true
                }

                Label {
                    text: "Attractor Found"
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: attractorFound ? "Yes" : "No"
                    Layout.fillWidth: true
                }

                Label {
                    text: "Energy"
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: energy
                    Layout.fillWidth: true
                }
            }
        }
    }

}

