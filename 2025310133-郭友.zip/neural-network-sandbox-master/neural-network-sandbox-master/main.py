# 在main.py中
import sys
import os
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QApplication
from PyQt5.QtQml import QQmlApplicationEngine
from nn_sandbox.bridges.TSPBridgeSimple import TSPBridgeSimple
from nn_sandbox.bridges import PerceptronBridge, MlpBridge, RbfnBridge, SomBridge
import nn_sandbox.backend.utils

def main():
    app = QApplication(sys.argv)
    engine = QQmlApplicationEngine()

    # 创建所有桥接对象
    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge()
    }

    # 为需要数据集的桥接设置数据
    for name, bridge in bridges.items():
        if hasattr(bridge, 'dataset_dict'):
            bridge.dataset_dict = nn_sandbox.backend.utils.read_data()
        # 注册到QML上下文
        engine.rootContext().setContextProperty(name, bridge)

    # 加载QML文件
    engine.load(QUrl.fromLocalFile(os.path.abspath('./nn_sandbox/frontend/main.qml')))

    if not engine.rootObjects():
        sys.exit(-1)

    return app.exec_()

if __name__ == '__main__':
    sys.exit(main())
