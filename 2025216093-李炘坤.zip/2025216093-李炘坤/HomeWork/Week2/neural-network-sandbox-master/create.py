import numpy as np


def generate_samples_to_file(filename, P=100, noise_std=0.1):
    # 生成均匀分布的输入样本
    x1 = np.random.uniform(-4, 4, P)
    x2 = np.random.uniform(-4, 4, P)

    # 定义 F(x1, x2) 函数
    F_x = 1.1 * (1 - x1 + 2 * x2 ** 2) * np.exp(-x1 ** 2 / 2)

    # 生成噪声
    noise = np.random.normal(0, noise_std, P)

    # 输出样本
    y = F_x + noise  # 目标输出

    # 保存到文件
    with open(filename, 'w') as f:
        f.write("x1 x2 y\n")  # 添加表头
        for i in range(P):
            f.write(f"{x1[i]:.5f} {x2[i]:.5f} {y[i]:.5f}\n")  # 格式化输出


# 使用示例
filename = 'nn_sandbox/assets/data/rbf.txt'  # 输出文件名
generate_samples_to_file(filename, P=100, noise_std=0.1)
print(f"生成的样本已保存到 {filename}")