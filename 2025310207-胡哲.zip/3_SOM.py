import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# Set fonts to avoid warnings
plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class SOM:
    def __init__(self, grid_size, input_dim):
        self.grid_size = grid_size
        self.input_dim = input_dim
        # Initialize weight matrix with small random values
        self.weights = np.random.rand(grid_size[0], grid_size[1], input_dim)

    def find_bmu(self, x):
        """Find Best Matching Unit (BMU)"""
        min_dist = float('inf')
        bmu_idx = (0, 0)

        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                dist = np.linalg.norm(x - self.weights[i, j])
                if dist < min_dist:
                    min_dist = dist
                    bmu_idx = (i, j)
        return bmu_idx

    def get_neighborhood(self, center, radius):
        """Get neuron indices within neighborhood"""
        neighbors = []
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                dist = np.sqrt((i - center[0]) ** 2 + (j - center[1]) ** 2)
                if dist <= radius:
                    neighbors.append((i, j))
        return neighbors

    def train(self, data, epochs, initial_lr, final_lr, initial_radius, final_radius):
        """Train SOM network and save weights every 200 steps"""
        n_samples = data.shape[0]
        weight_history = []
        step_count = 0

        print("Training progress:")
        for epoch in range(epochs):
            # Calculate current learning rate and neighborhood radius
            if epoch < 1000:
                lr = initial_lr - (initial_lr - 0.04) * (epoch / 1000)
                radius = initial_radius - (initial_radius - final_radius) * (epoch / 1000)
            else:
                lr = 0.04 - (0.04 - final_lr) * ((epoch - 1000) / (epochs - 1000))
                radius = final_radius

            # Randomly select a sample
            idx = np.random.randint(n_samples)
            x = data[idx]

            # Find BMU
            bmu = self.find_bmu(x)

            # Get neighborhood
            neighbors = self.get_neighborhood(bmu, radius)

            # Update weights
            for neuron in neighbors:
                i, j = neuron
                influence = np.exp(-((i - bmu[0]) ** 2 + (j - bmu[1]) ** 2) / (2 * radius ** 2 + 1e-8))
                self.weights[i, j] += lr * influence * (x - self.weights[i, j])

            # Save weight history every 200 steps
            if epoch % 200 == 0:
                weight_history.append({
                    'step': epoch,
                    'weights': self.weights.copy(),
                    'lr': lr,
                    'radius': radius
                })

                # Print progress
                if epoch % 1000 == 0:
                    print(f"Step {epoch}: LR={lr:.4f}, Radius={radius:.4f}")

            step_count += 1

        # Save final weights
        weight_history.append({
            'step': epochs,
            'weights': self.weights.copy(),
            'lr': 0.0,
            'radius': 0.0
        })

        return weight_history


def plot_mapping(som, data, labels):
    """Plot input patterns mapping on output plane"""
    fig, ax = plt.subplots(1, 1, figsize=(8, 8))

    # Create grid
    for i in range(som.grid_size[0]):
        for j in range(som.grid_size[1]):
            rect = plt.Rectangle((j - 0.5, i - 0.5), 1, 1,
                                 fill=False, edgecolor='gray', linewidth=1)
            ax.add_patch(rect)

    # Find BMU for each input pattern and mark it
    colors_list = ['red', 'blue', 'green', 'orange', 'purple']
    markers = ['o', 's', 'D', '^', 'v']

    for idx, (x, label) in enumerate(zip(data, labels)):
        bmu = som.find_bmu(x)
        ax.plot(bmu[1], bmu[0], markers[idx],
                markersize=15, color=colors_list[idx],
                label=f'{label}', markeredgecolor='black', markeredgewidth=2)
        ax.text(bmu[1], bmu[0], label,
                ha='center', va='center', fontsize=12, fontweight='bold')

    ax.set_xlim(-0.5, som.grid_size[1] - 0.5)
    ax.set_ylim(som.grid_size[0] - 0.5, -0.5)
    ax.set_aspect('equal')
    ax.set_xlabel('Column Index')
    ax.set_ylabel('Row Index')
    ax.set_title('SOM Network - Final Mapping', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.legend(loc='upper right', bbox_to_anchor=(1.15, 1))

    plt.tight_layout()
    plt.show()


def plot_weight_evolution(weight_history, data, labels):
    """Plot weight evolution during training at saved steps"""
    # Select key training steps for visualization
    selected_indices = [0, 5, 10, 25, 40, 50]  # 0, 1000, 2000, 5000, 8000, 10000 steps

    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    for idx, hist_idx in enumerate(selected_indices):
        if hist_idx < len(weight_history):
            ax = axes[idx]
            step_info = weight_history[hist_idx]
            weights = step_info['weights']
            step = step_info['step']
            lr = step_info['lr']
            radius = step_info['radius']

            # Draw grid
            for i in range(weights.shape[0]):
                for j in range(weights.shape[1]):
                    rect = plt.Rectangle((j - 0.5, i - 0.5), 1, 1,
                                         fill=False, edgecolor='gray', linewidth=1)
                    ax.add_patch(rect)

            # Mark BMU for each input pattern
            for data_idx, x in enumerate(data):
                min_dist = float('inf')
                bmu = (0, 0)
                for i in range(weights.shape[0]):
                    for j in range(weights.shape[1]):
                        dist = np.linalg.norm(x - weights[i, j])
                        if dist < min_dist:
                            min_dist = dist
                            bmu = (i, j)

                ax.plot(bmu[1], bmu[0], 'o', markersize=10,
                        color=plt.cm.Set1(data_idx))
                ax.text(bmu[1], bmu[0], labels[data_idx],
                        ha='center', va='center', fontsize=10, fontweight='bold')

            ax.set_xlim(-0.5, weights.shape[1] - 0.5)
            ax.set_ylim(weights.shape[0] - 0.5, -0.5)
            ax.set_aspect('equal')
            ax.set_title(f'Step: {step}\nLR: {lr:.4f}, Radius: {radius:.4f}')
            ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


def analyze_weight_changes(weight_history, data, labels):
    """Analyze and display weight changes during training"""
    print("\n=== Weight Vector Analysis ===")

    # Analyze weight changes for specific neurons over time
    neurons_to_analyze = [(0, 0), (2, 2), (4, 4)]  # Some sample neurons

    for neuron in neurons_to_analyze:
        i, j = neuron
        print(f"\nNeuron ({i + 1}, {j + 1}) weight vector changes:")

        # Print weights at selected steps
        selected_steps = [0, 5, 10, 25, 40, 50]
        for step_idx in selected_steps:
            if step_idx < len(weight_history):
                step_info = weight_history[step_idx]
                weights = step_info['weights']
                step = step_info['step']
                print(f"  Step {step}: {np.round(weights[i, j], 4)}")

    # Analyze mapping stability
    print("\n=== Mapping Stability Analysis ===")
    mapping_changes = {label: [] for label in labels}

    for step_idx, step_info in enumerate(weight_history):
        weights = step_info['weights']
        step = step_info['step']

        for data_idx, (x, label) in enumerate(zip(data, labels)):
            min_dist = float('inf')
            bmu = (0, 0)
            for i in range(weights.shape[0]):
                for j in range(weights.shape[1]):
                    dist = np.linalg.norm(x - weights[i, j])
                    if dist < min_dist:
                        min_dist = dist
                        bmu = (i, j)
            mapping_changes[label].append((step, bmu))

    # Print final mappings and changes
    print("\nFinal Mappings:")
    final_step = weight_history[-1]
    final_weights = final_step['weights']
    for data_idx, (x, label) in enumerate(zip(data, labels)):
        bmu = som.find_bmu(x)
        print(f"  {label} -> Neuron ({bmu[0] + 1}, {bmu[1] + 1})")

    # Show mapping changes for each pattern
    print("\nMapping Changes During Training:")
    for label in labels:
        mappings = mapping_changes[label]
        unique_mappings = set(mappings)
        if len(unique_mappings) > 1:
            print(f"  {label}: Changed positions {len(unique_mappings)} times")
            # Show first and last mapping
            first_step, first_pos = mappings[0]
            last_step, last_pos = mappings[-1]
            print(f"    Step {first_step}: ({first_pos[0] + 1}, {first_pos[1] + 1}) -> "
                  f"Step {last_step}: ({last_pos[0] + 1}, {last_pos[1] + 1})")


def print_distance_matrix(data, labels):
    """Print distance matrix between input patterns"""
    print("\n=== Euclidean Distance Matrix ===")
    distance_matrix = np.zeros((5, 5))
    for i in range(5):
        for j in range(5):
            distance_matrix[i, j] = np.linalg.norm(data[i] - data[j])

    print("     " + "   ".join(labels))
    for i, label in enumerate(labels):
        print(f"{label}  " + "  ".join(f"{dist:5.2f}" for dist in distance_matrix[i]))


# Main program
if __name__ == "__main__":
    # Set random seed for reproducibility
    np.random.seed(42)

    # Define input patterns
    data = np.array([
        [1, 0, 0, 0],  # X1
        [1, 1, 0, 0],  # X2
        [1, 1, 1, 0],  # X3
        [0, 1, 0, 0],  # X4
        [1, 1, 1, 1]  # X5
    ])
    labels = ['X1', 'X2', 'X3', 'X4', 'X5']

    # Create and train SOM network
    som = SOM(grid_size=(5, 5), input_dim=4)

    print("Starting SOM network training...")
    print(f"Total training steps: 10000")
    print(f"Saving weights every 200 steps")
    print(f"Learning rate: 0.5 -> 0.04 (first 1000 steps) -> 0.0 (10000 steps)")
    print(f"Neighborhood radius: 2.0 -> 0.0 (first 1000 steps)")

    weight_history = som.train(
        data=data,
        epochs=10000,
        initial_lr=0.5,
        final_lr=0.0,
        initial_radius=2.0,
        final_radius=0.0
    )

    print(f"\nTraining completed!")
    print(f"Total weight snapshots saved: {len(weight_history)}")

    # Display detailed analysis
    analyze_weight_changes(weight_history, data, labels)

    # Plot final mapping
    plot_mapping(som, data, labels)

    # Plot weight evolution during training
    plot_weight_evolution(weight_history, data, labels)

    # Calculate and display similarity between input patterns
    print_distance_matrix(data, labels)

    # Save weight history to file for further analysis
    np.save('weight_history.npy', weight_history)
    print(f"\nWeight history saved to 'weight_history.npy'")