import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3   // 收敛曲线

Page {
    id: root
    objectName: "MlpPage"
    title: qsTr("MLP")

    // 便捷函数：当前数据集名与大小
    function currentDatasetName() {
        return mlpBridge.current_dataset_name && mlpBridge.current_dataset_name.length > 0
               ? mlpBridge.current_dataset_name
               : (mlpBridge.dataset_dict ? Object.keys(mlpBridge.dataset_dict)[0] : "");
    }
    function currentDatasetSize() {
        var name = currentDatasetName();
        var dict = mlpBridge.dataset_dict;
        if (!dict || !name || !(name in dict)) return 0;
        var ds = dict[name];
        return ds ? ds.length : 0;
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 12

        /* -------------------- Dataset -------------------- */
        GroupBox {
            title: qsTr("Dataset")
            Layout.fillWidth: true

            RowLayout {
                spacing: 12
                Layout.fillWidth: true

                Label { text: qsTr("Select") }
                ComboBox {
                    id: dsBox
                    Layout.preferredWidth: 220
                    enabled: mlpBridge.has_finished
                    model: mlpBridge.dataset_dict ? Object.keys(mlpBridge.dataset_dict) : []
                    onActivated: {
                        mlpBridge.current_dataset_name = currentText;
                    }
                    Component.onCompleted: {
                        // 若还没选过，默认选第一个（与后端逻辑一致）
                        if (model.length > 0 && (!mlpBridge.current_dataset_name || mlpBridge.current_dataset_name.length === 0)) {
                            currentIndex = 0;
                            mlpBridge.current_dataset_name = model[0];
                        } else {
                            // 若已有选择，则把下拉框同步到该项
                            var keys = model;
                            var idx = keys.indexOf(mlpBridge.current_dataset_name);
                            if (idx >= 0) currentIndex = idx;
                        }
                    }
                }

                Label {
                    text: qsTr("Total: ") + currentDatasetSize()
                }
                Label {
                    text: qsTr("Train: ") + (mlpBridge.training_dataset ? mlpBridge.training_dataset.length : 0)
                }
                Label {
                    text: qsTr("Test: ") + (mlpBridge.testing_dataset ? mlpBridge.testing_dataset.length : 0)
                }

                Item { Layout.fillWidth: true }
            }
        }

        /* -------------------- Network -------------------- */
        GroupBox {
            title: qsTr("Network")
            Layout.fillWidth: true

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 12

                /* 隐藏层神经元个数（仅三层BP需要这个） */
                RowLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    Label { text: qsTr("Hidden neurons") }
                    SpinBox {
                        id: hiddenSpin
                        from: 1; to: 128
                        value: (mlpBridge.network_shape && mlpBridge.network_shape.length > 0)
                                ? mlpBridge.network_shape[0] : 5
                        onValueModified: mlpBridge.network_shape = [value]   // 只取第一项作为隐藏层宽度
                        enabled: mlpBridge.has_finished
                        Layout.preferredWidth: 120
                    }
                }

                /* 激活函数 + 一键随机初始化权值 */
                RowLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    Label { text: qsTr("Activation") }
                    ComboBox {
                        id: actBox
                        model: ["unipolar", "bipolar"]
                        enabled: mlpBridge.has_finished
                        onActivated: mlpBridge.activation = currentText
                        Component.onCompleted: mlpBridge.activation = currentText
                        Layout.preferredWidth: 140
                    }
                    Button {
                        text: qsTr("随机初始化权值")
                        enabled: mlpBridge.has_finished
                        onClicked: mlpBridge.reset_weights()
                        Layout.preferredWidth: 140
                    }
                    Item { Layout.fillWidth: true } // 拉伸占位
                }
            }
        }

        /* -------------------- Training -------------------- */
        GroupBox {
            title: qsTr("Training")
            Layout.fillWidth: true

            ColumnLayout {
                spacing: 12
                Layout.fillWidth: true

                GridLayout {
                    columns: 4
                    columnSpacing: 12
                    rowSpacing: 8
                    Layout.fillWidth: true

                    Label { text: qsTr("Initial Learning Rate") }
                    TextField {
                        text: String(mlpBridge.initial_learning_rate)
                        validator: DoubleValidator { bottom: 0.000001; top: 10.0; decimals: 6 }
                        onEditingFinished: mlpBridge.initial_learning_rate = parseFloat(text)
                        Layout.preferredWidth: 120
                    }

                    Label { text: qsTr("Epochs") }
                    SpinBox {
                        value: mlpBridge.total_epoches
                        from: 1; to: 10000
                        onValueModified: mlpBridge.total_epoches = value
                        Layout.preferredWidth: 120
                    }

                    Label { text: qsTr("Momentum") }
                    TextField {
                        text: String(mlpBridge.momentum_weight)
                        validator: DoubleValidator { bottom: 0.0; top: 0.99; decimals: 3 }
                        onEditingFinished: mlpBridge.momentum_weight = parseFloat(text)
                        Layout.preferredWidth: 120
                    }

                    Label { text: qsTr("Test Ratio") }
                    TextField {
                        text: String(mlpBridge.test_ratio)
                        validator: DoubleValidator { bottom: 0.0; top: 0.95; decimals: 2 }
                        onEditingFinished: mlpBridge.test_ratio = parseFloat(text)
                        Layout.preferredWidth: 120
                    }
                }

                RowLayout {
                    spacing: 12
                    Layout.fillWidth: true

                    Button {
                        text: qsTr("Start")
                        enabled: mlpBridge.has_finished
                        onClicked: mlpBridge.start_mlp_algorithm()
                        Layout.preferredWidth: 100
                    }
                    Button {
                        text: qsTr("Stop")
                        enabled: !mlpBridge.has_finished
                        onClicked: mlpBridge.stop_mlp_algorithm()
                        Layout.preferredWidth: 100
                    }
                    Label {
                        text: qsTr("Test Acc: ") + (mlpBridge.test_correct_rate * 100).toFixed(2) + "%"
                        Layout.fillWidth: true
                        horizontalAlignment: Text.AlignLeft
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }

        /* -------------------- Convergence Chart -------------------- */
        GroupBox {
            title: qsTr("Convergence")
            Layout.fillWidth: true
            Layout.fillHeight: true

            ChartView {
                id: chart
                anchors.fill: parent
                antialiasing: true
                legend.alignment: Qt.AlignTop

                ValueAxis { id: axisX; min: 0; max: 1; titleText: qsTr("Iterations") }
                ValueAxis { id: axisY; min: 0; max: 1; titleText: qsTr("Correct Rate") }

                LineSeries { id: trainSeries; name: qsTr("Training"); axisX: axisX; axisY: axisY }
                LineSeries { id: testSeries;  name: qsTr("Testing");  axisX: axisX; axisY: axisY }
                LineSeries { id: bestSeries;  name: qsTr("Best Training"); axisX: axisX; axisY: axisY }
            }

            // 监听桥接属性变化，动态追加点
            Connections {
                target: mlpBridge

                // 开始训练时清空曲线
                function onHas_finishedChanged() {
                    if (!mlpBridge.has_finished) {
                        trainSeries.clear();
                        testSeries.clear();
                        bestSeries.clear();
                        axisX.min = 0;
                        axisX.max = 1;
                    }
                }

                function onIterationChanged() {
                    axisX.max = Math.max(axisX.max, mlpBridge.iteration);
                }

                function onTraining_correct_rateChanged() {
                    trainSeries.append(mlpBridge.iteration, mlpBridge.training_correct_rate);
                }
                function onTest_correct_rateChanged() {
                    testSeries.append(mlpBridge.iteration, mlpBridge.test_correct_rate);
                }
                function onBest_training_correct_rateChanged() {
                    bestSeries.append(mlpBridge.iteration, mlpBridge.best_training_correct_rate);
                }
            }
        }
    }
}
