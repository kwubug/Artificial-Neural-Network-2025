"""
可视化梯度下降：非线性支持向量机（SVM）三种梯度下降算法
==========================================================

参考书籍：参考书1 第9章 9.2节（非线性支持向量机）

该脚本生成一个非线性数据集，通过随机傅里叶特征近似 RBF 核，将问题映射到
高维空间，随后在软间隔 SVM 的原始形式上使用三种不同的梯度下降策略进行训练：

1. 批量梯度下降（Batch Gradient Descent, GD）
2. 随机梯度下降（Stochastic Gradient Descent, SGD）
3. 小批量梯度下降（Mini-batch Gradient Descent, MBGD）

脚本会输出：
 - loss_curves.png：三种算法的损失曲线对比
 - decision_boundary_<algorithm>.png：每种算法的决策边界与数据分布
 - summary.txt：关键超参数、收敛指标与训练时间

运行方法：
    python nonlinear_svm_visualization.py
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np


# --------------------------------------------------------------------------------------
# 数据集与特征变换
# --------------------------------------------------------------------------------------


def make_moons(n_samples: int = 200, noise: float = 0.2, random_state: int | None = 0) -> Tuple[np.ndarray, np.ndarray]:
    """生成近似 sklearn.datasets.make_moons 的二维非线性数据集。"""

    rng = np.random.default_rng(random_state)
    n_samples = int(n_samples)
    n_samples_out = n_samples // 2
    n_samples_in = n_samples - n_samples_out

    outer_theta = np.linspace(0, np.pi, n_samples_out)
    inner_theta = np.linspace(0, np.pi, n_samples_in)

    outer_circ_x = np.cos(outer_theta)
    outer_circ_y = np.sin(outer_theta)
    inner_circ_x = 1 - np.cos(inner_theta)
    inner_circ_y = 1 - np.sin(inner_theta) - 0.5

    X_outer = np.stack([outer_circ_x, outer_circ_y], axis=1)
    X_inner = np.stack([inner_circ_x, inner_circ_y], axis=1)
    X = np.vstack([X_outer, X_inner])
    X += rng.normal(scale=noise, size=X.shape)

    y = np.hstack([np.ones(n_samples_out), -np.ones(n_samples_in)])
    return X, y


class RBFTransformer:
    """随机傅里叶特征近似 RBF 核。"""

    def __init__(self, gamma: float = 1.0, n_components: int = 200, random_state: int | None = 0) -> None:
        self.gamma = gamma
        self.n_components = n_components
        self.random_state = random_state
        self.random_weights: np.ndarray | None = None
        self.random_offset: np.ndarray | None = None

    def fit(self, X: np.ndarray) -> "RBFTransformer":
        rng = np.random.default_rng(self.random_state)
        n_features = X.shape[1]
        self.random_weights = rng.normal(
            loc=0.0,
            scale=np.sqrt(2 * self.gamma),
            size=(n_features, self.n_components),
        )
        self.random_offset = rng.uniform(0, 2 * np.pi, size=self.n_components)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.random_weights is None or self.random_offset is None:
            raise RuntimeError("Transformer must be fitted before calling transform.")
        projection = X @ self.random_weights + self.random_offset
        return np.sqrt(2.0 / self.n_components) * np.cos(projection)


# --------------------------------------------------------------------------------------
# SVM 模型与优化
# --------------------------------------------------------------------------------------


@dataclass
class TrainingSnapshot:
    iteration: int
    loss: float
    accuracy: float
    w: np.ndarray
    b: float


@dataclass
class TrainingHistory:
    name: str
    iterations: List[int] = field(default_factory=list)
    losses: List[float] = field(default_factory=list)
    accuracies: List[float] = field(default_factory=list)
    snapshots: List[TrainingSnapshot] = field(default_factory=list)
    wall_time: float = 0.0

    def record(
        self,
        iteration: int,
        loss: float,
        accuracy: float,
        w: np.ndarray,
        b: float,
        snapshot_epochs: Iterable[int],
    ) -> None:
        self.iterations.append(iteration)
        self.losses.append(loss)
        self.accuracies.append(accuracy)
        if iteration in snapshot_epochs:
            self.snapshots.append(TrainingSnapshot(iteration, loss, accuracy, w.copy(), float(b)))


class NonlinearSoftMarginSVM:
    def __init__(self, transformer: RBFTransformer, C: float = 1.0) -> None:
        self.transformer = transformer
        self.C = C
        self.w: np.ndarray | None = None
        self.b: float = 0.0

    def initialize(self) -> None:
        self.w = np.zeros(self.transformer.n_components, dtype=np.float64)
        self.b = 0.0

    # ----------------------- 前向与评估 ----------------------- #

    def decision_function(self, X: np.ndarray) -> np.ndarray:
        assert self.w is not None
        Z = self.transformer.transform(X)
        return Z @ self.w + self.b

    def predict(self, X: np.ndarray) -> np.ndarray:
        return np.sign(self.decision_function(X))

    def compute_loss_and_grad(self, Z: np.ndarray, y: np.ndarray) -> Tuple[float, np.ndarray, float]:
        """返回损失及其梯度。"""
        assert self.w is not None
        scores = Z @ self.w + self.b
        margins = 1 - y * scores
        mask = (margins > 0).astype(np.float64)

        loss = 0.5 * np.dot(self.w, self.w) + self.C * np.mean(np.maximum(0, margins))
        factor = self.C / Z.shape[0]
        grad_w = self.w - factor * (Z.T @ (mask * y))
        grad_b = -factor * np.sum(mask * y)
        return loss, grad_w, grad_b

    def compute_accuracy(self, Z: np.ndarray, y: np.ndarray) -> float:
        preds = np.sign(Z @ self.w + self.b)
        return float(np.mean(preds == y))


# --------------------------------------------------------------------------------------
# 三种梯度下降算法
# --------------------------------------------------------------------------------------


def batch_gradient_descent(
    model: NonlinearSoftMarginSVM,
    Z: np.ndarray,
    y: np.ndarray,
    lr: float,
    epochs: int,
    snapshot_epochs: Iterable[int],
) -> TrainingHistory:
    history = TrainingHistory("Batch Gradient Descent")
    start = time.perf_counter()

    for epoch in range(epochs):
        loss, grad_w, grad_b = model.compute_loss_and_grad(Z, y)
        assert model.w is not None
        model.w -= lr * grad_w
        model.b -= lr * grad_b
        accuracy = model.compute_accuracy(Z, y)
        history.record(epoch, loss, accuracy, model.w, model.b, snapshot_epochs)
    if not history.snapshots or history.snapshots[-1].iteration != epochs - 1:
        history.snapshots.append(
            TrainingSnapshot(epochs - 1, history.losses[-1], history.accuracies[-1], model.w.copy(), float(model.b))
        )
    history.wall_time = time.perf_counter() - start
    return history


def stochastic_gradient_descent(
    model: NonlinearSoftMarginSVM,
    Z: np.ndarray,
    y: np.ndarray,
    lr: float,
    epochs: int,
    snapshot_epochs: Iterable[int],
    random_state: int = 0,
) -> TrainingHistory:
    history = TrainingHistory("Stochastic Gradient Descent")
    rng = np.random.default_rng(random_state)
    n_samples = Z.shape[0]
    start = time.perf_counter()

    for epoch in range(epochs):
        indices = rng.permutation(n_samples)
        for idx in indices:
            z_i = Z[idx : idx + 1]
            y_i = y[idx : idx + 1]
            loss, grad_w, grad_b = model.compute_loss_and_grad(z_i, y_i)
            assert model.w is not None
            model.w -= lr * grad_w
            model.b -= lr * grad_b
        full_loss, _, _ = model.compute_loss_and_grad(Z, y)
        accuracy = model.compute_accuracy(Z, y)
        history.record(epoch, full_loss, accuracy, model.w, model.b, snapshot_epochs)
    if not history.snapshots or history.snapshots[-1].iteration != epochs - 1:
        history.snapshots.append(
            TrainingSnapshot(epochs - 1, history.losses[-1], history.accuracies[-1], model.w.copy(), float(model.b))
        )
    history.wall_time = time.perf_counter() - start
    return history


def mini_batch_gradient_descent(
    model: NonlinearSoftMarginSVM,
    Z: np.ndarray,
    y: np.ndarray,
    lr: float,
    epochs: int,
    batch_size: int,
    snapshot_epochs: Iterable[int],
    random_state: int = 0,
) -> TrainingHistory:
    history = TrainingHistory(f"Mini-batch Gradient Descent (batch={batch_size})")
    rng = np.random.default_rng(random_state)
    n_samples = Z.shape[0]
    start = time.perf_counter()

    for epoch in range(epochs):
        indices = rng.permutation(n_samples)
        for start_idx in range(0, n_samples, batch_size):
            batch_idx = indices[start_idx : start_idx + batch_size]
            z_batch = Z[batch_idx]
            y_batch = y[batch_idx]
            loss, grad_w, grad_b = model.compute_loss_and_grad(z_batch, y_batch)
            assert model.w is not None
            model.w -= lr * grad_w
            model.b -= lr * grad_b
        full_loss, _, _ = model.compute_loss_and_grad(Z, y)
        accuracy = model.compute_accuracy(Z, y)
        history.record(epoch, full_loss, accuracy, model.w, model.b, snapshot_epochs)
    if not history.snapshots or history.snapshots[-1].iteration != epochs - 1:
        history.snapshots.append(
            TrainingSnapshot(epochs - 1, history.losses[-1], history.accuracies[-1], model.w.copy(), float(model.b))
        )
    history.wall_time = time.perf_counter() - start
    return history


# --------------------------------------------------------------------------------------
# 可视化
# --------------------------------------------------------------------------------------


def plot_loss_curves(histories: List[TrainingHistory], output_dir: Path) -> Path:
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for history in histories:
        ax.plot(history.iterations, history.losses, label=history.name)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Objective Loss")
    ax.set_title("SVM Loss Curves under Different Gradient Descent Strategies")
    ax.grid(True, linestyle="--", linewidth=0.6, alpha=0.5)
    ax.legend()
    fig.tight_layout()
    path = output_dir / "loss_curves.png"
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_decision_boundary(
    history: TrainingHistory,
    transformer: RBFTransformer,
    X: np.ndarray,
    y: np.ndarray,
    output_dir: Path,
) -> Path:
    if not history.snapshots:
        raise ValueError("Training history contains no parameter snapshots for visualization.")
    final_snapshot = history.snapshots[-1]
    w = final_snapshot.w
    b = final_snapshot.b
    grid_res = 200
    x_min, x_max = X[:, 0].min() - 0.8, X[:, 0].max() + 0.8
    y_min, y_max = X[:, 1].min() - 0.8, X[:, 1].max() + 0.8
    xs = np.linspace(x_min, x_max, grid_res)
    ys = np.linspace(y_min, y_max, grid_res)
    xx, yy = np.meshgrid(xs, ys)
    grid_points = np.column_stack([xx.ravel(), yy.ravel()])
    scores = transformer.transform(grid_points) @ w + b
    decision = scores.reshape(xx.shape)

    fig, ax = plt.subplots(figsize=(5.5, 5))
    ax.scatter(X[y == 1, 0], X[y == 1, 1], color="#1f77b4", s=30, alpha=0.8, label="Class +1")
    ax.scatter(X[y == -1, 0], X[y == -1, 1], color="#d62728", s=30, alpha=0.8, label="Class -1")
    ax.contour(xx, yy, decision, levels=[0], colors="k", linewidths=2)
    ax.contourf(xx, yy, decision, levels=np.linspace(decision.min(), decision.max(), 20), alpha=0.25, cmap="coolwarm")
    ax.set_title(f"{history.name} Decision Boundary")
    ax.set_xlabel("x₁")
    ax.set_ylabel("x₂")
    ax.legend(loc="upper right")
    ax.set_aspect("equal", "box")
    fig.tight_layout()
    safe_name = history.name.replace(" ", "_").replace("(", "").replace(")", "").replace("=", "")
    path = output_dir / f"decision_boundary_{safe_name}.png"
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return path


# --------------------------------------------------------------------------------------
# 运行入口
# --------------------------------------------------------------------------------------


def main() -> None:
    output_dir = Path(__file__).resolve().parent
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. 数据准备
    X, y = make_moons(n_samples=240, noise=0.2, random_state=13)
    transformer = RBFTransformer(gamma=1.0, n_components=250, random_state=42).fit(X)
    Z = transformer.transform(X)

    # 2. 训练配置
    C = 1.5
    epochs = 120
    snapshot_epochs = set(np.linspace(0, epochs - 1, num=5, dtype=int))

    histories: List[TrainingHistory] = []

    # Batch GD
    svm_gd = NonlinearSoftMarginSVM(transformer, C=C)
    svm_gd.initialize()
    history_gd = batch_gradient_descent(svm_gd, Z, y, lr=0.08, epochs=epochs, snapshot_epochs=snapshot_epochs)
    histories.append(history_gd)

    # SGD
    svm_sgd = NonlinearSoftMarginSVM(transformer, C=C)
    svm_sgd.initialize()
    history_sgd = stochastic_gradient_descent(
        svm_sgd,
        Z,
        y,
        lr=0.01,
        epochs=epochs,
        snapshot_epochs=snapshot_epochs,
        random_state=24,
    )
    histories.append(history_sgd)

    # Mini-batch GD
    svm_mbgd = NonlinearSoftMarginSVM(transformer, C=C)
    svm_mbgd.initialize()
    history_mbgd = mini_batch_gradient_descent(
        svm_mbgd,
        Z,
        y,
        lr=0.05,
        epochs=epochs,
        batch_size=32,
        snapshot_epochs=snapshot_epochs,
        random_state=99,
    )
    histories.append(history_mbgd)

    # 3. 可视化输出
    loss_path = plot_loss_curves(histories, output_dir)
    boundary_paths = [plot_decision_boundary(hist, transformer, X, y, output_dir) for hist in histories]

    # 4. 汇总报告
    summary_lines = [
        "非线性 SVM 梯度下降实验摘要",
        f"数据集样本数: {X.shape[0]}, 特征维度: {X.shape[1]}",
        f"随机傅里叶特征组件数: {transformer.n_components}, RBF gamma: {transformer.gamma}",
        f"正则化系数 C: {C}",
        "",
        "各算法最终结果：",
    ]
    for hist in histories:
        final_loss = hist.losses[-1]
        final_acc = hist.accuracies[-1]
        summary_lines.append(
            f"  - {hist.name}: loss={final_loss:.4f}, accuracy={final_acc*100:.2f}%, wall_time={hist.wall_time:.3f}s"
        )
    summary_lines.extend(
        [
            "",
            f"损失曲线: {loss_path.name}",
            "决策边界: " + ", ".join(path.name for path in boundary_paths),
        ]
    )
    (output_dir / "summary.txt").write_text("\n".join(summary_lines), encoding="utf-8")

    print("训练完成。输出文件：")
    print(f"  - {loss_path}")
    for path in boundary_paths:
        print(f"  - {path}")
    print(f"  - {output_dir / 'summary.txt'}")


if __name__ == "__main__":
    main()


