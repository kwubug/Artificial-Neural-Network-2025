# Discrete Hopfield Network with asynchronous update, attractors, and energy
# Author: ChatGPT
# Requirements: numpy, matplotlib, pandas (optional, only for table summary)
# Usage:
#   python hopfield_async_demo.py
# This script demonstrates:
#   (1) Training a Hopfield network on binary {-1, +1} patterns (Hebbian learning)
#   (2) Asynchronous (random) updates from an initial/noisy state
#   (3) Energy computation during dynamics
#   (4) Finding attractors from multiple random initializations

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import List, Tuple, Optional
import random

try:
    import pandas as pd
except Exception:
    pd = None  # pandas is optional for CLI use

rng = np.random.default_rng(42)
random.seed(42)

@dataclass
class HopfieldResult:
    final_state: np.ndarray
    energies: List[float]
    states: List[np.ndarray]
    converged: bool
    steps: int
    matched_pattern_index: Optional[int]
    hamming_to_patterns: Optional[List[int]]

class HopfieldNetwork:
    def __init__(self, n_units: int):
        self.n = n_units
        self.W = np.zeros((n_units, n_units), dtype=float)
    
    @staticmethod
    def _to_pm1(x: np.ndarray) -> np.ndarray:
        # Convert {0,1} to {-1,+1} if needed
        vals = set(np.unique(x).tolist())
        if vals.issubset({0,1}):
            return np.where(x>0, 1, -1).astype(int)
        return x.astype(int)
    
    def store_patterns(self, patterns: np.ndarray) -> None:
        """
        Hebbian learning for patterns in {-1,+1}^{n}.
        patterns: shape (P, n)
        """
        P, n = patterns.shape
        if n != self.n:
            raise ValueError("Pattern length must equal number of units")
        X = np.array([self._to_pm1(p) for p in patterns], dtype=int)
        W = np.zeros((n, n), dtype=float)
        for p in X:
            W += np.outer(p, p)
        np.fill_diagonal(W, 0.0)  # no self-connection
        self.W = W / n  # normalization
    
    def energy(self, s: np.ndarray) -> float:
        s = s.astype(float)
        # E(s) = -1/2 * s^T W s
        return -0.5 * float(s.T @ self.W @ s)
    
    def sign(self, x: np.ndarray) -> np.ndarray:
        out = np.sign(x)
        out[out == 0] = 1
        return out.astype(int)
    
    def update_async(self, s: np.ndarray, order: Optional[List[int]] = None) -> Tuple[np.ndarray, int]:
        """
        Perform one full asynchronous sweep (update each unit once).
        Returns updated state and number of flips.
        """
        s = s.copy().astype(int)
        indices = list(range(self.n)) if order is None else list(order)
        if order is None:
            random.shuffle(indices)
        flips = 0
        for i in indices:
            h_i = float(self.W[i] @ s)  # local field
            new_val = 1 if h_i >= 0 else -1
            if new_val != s[i]:
                s[i] = new_val
                flips += 1
        return s, flips
    
    def run_async_until_converge(
        self,
        s0: np.ndarray,
        max_sweeps: int = 200,
        record_states: bool = True
    ) -> HopfieldResult:
        s = self._to_pm1(np.array(s0, dtype=int))
        energies = [self.energy(s)]
        states = [s.copy()] if record_states else []
        converged = False
        steps = 0
        
        for _ in range(max_sweeps):
            s, flips = self.update_async(s)
            steps += 1
            energies.append(self.energy(s))
            if record_states:
                states.append(s.copy())
            if flips == 0:
                converged = True
                break
        
        return HopfieldResult(
            final_state=s.copy(),
            energies=energies,
            states=states,
            converged=converged,
            steps=steps,
            matched_pattern_index=None,
            hamming_to_patterns=None
        )
    
    @staticmethod
    def hamming_distance(a: np.ndarray, b: np.ndarray) -> int:
        return int(np.sum(a != b))
    
    def identify_attractor(
        self,
        state: np.ndarray,
        patterns: np.ndarray
    ) -> Tuple[Optional[int], List[int]]:
        """
        Return index of the closest stored pattern (or its inverse) by Hamming distance.
        """
        s = self._to_pm1(state)
        X = np.array([self._to_pm1(p) for p in patterns], dtype=int)
        dists = []
        for p in X:
            dists.append(min(self.hamming_distance(s, p), self.hamming_distance(s, -p)))
        best_idx = int(np.argmin(dists)) if len(dists) > 0 else None
        return best_idx, dists


# ---- Demo patterns (8x8) ----
def pattern_plus(size=8):
    p = -np.ones((size, size), dtype=int)
    mid = size//2
    p[mid, :] = 1
    p[:, mid] = 1
    return p.reshape(-1)

def pattern_cross(size=8):
    p = -np.ones((size, size), dtype=int)
    for i in range(size):
        p[i, i] = 1
        p[i, size-1-i] = 1
    return p.reshape(-1)

def pattern_vertical(size=8):
    p = -np.ones((size, size), dtype=int)
    col = size//3
    p[:, col] = 1
    return p.reshape(-1)

def show_pattern(vec, title="Pattern", size=8):
    plt.figure()
    plt.imshow(vec.reshape(size, size), interpolation='nearest')
    plt.title(title)
    plt.axis('off')
    plt.show()


def basin_experiment(net: HopfieldNetwork, patterns: np.ndarray, trials: int = 30, max_sweeps: int = 100):
    rows = []
    for t in range(trials):
        s_rand = rng.choice([-1, 1], size=net.n)
        res_t = net.run_async_until_converge(s_rand, max_sweeps=max_sweeps)
        best_idx_t, dists_t = net.identify_attractor(res_t.final_state, patterns)
        rows.append({
            "trial": t,
            "converged": res_t.converged,
            "sweeps": res_t.steps,
            "final_energy": res_t.energies[-1],
            "matched_pattern_index": best_idx_t,
            "min_hamming": min(dists_t) if dists_t else None
        })
    return rows


def main():
    size = 8
    N = size * size
    patterns = np.vstack([pattern_plus(size), pattern_cross(size), pattern_vertical(size)])
    
    net = HopfieldNetwork(n_units=N)
    net.store_patterns(patterns)
    
    # Noisy init from pattern 0
    true_idx = 0
    noise_level = 0.25
    s0 = patterns[true_idx].copy()
    num_flip = int(noise_level * N)
    flip_idx = rng.choice(N, size=num_flip, replace=False)
    s0[flip_idx] *= -1
    
    # Run asynchronous dynamics
    res = net.run_async_until_converge(s0, max_sweeps=200, record_states=True)
    best_idx, dists = net.identify_attractor(res.final_state, patterns)
    
    # Visualize
    show_pattern(s0, title="Initial (noisy) state", size=size)
    show_pattern(res.final_state, title="Final state (converged)", size=size)
    
    # Energy curve
    plt.figure()
    plt.plot(res.energies, marker='o')
    plt.xlabel("Sweep")
    plt.ylabel("Energy")
    plt.title("Energy vs. Sweeps (Asynchronous update)")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.show()
    
    # Print summary
    print("Converged:", res.converged, "in", res.steps, "sweeps")
    print("Final energy:", res.energies[-1])
    print("Matched pattern index (closest):", best_idx)
    print("Hamming distances to stored patterns:", dists)
    
    # Basin experiment (optional, summary only if pandas missing)
    rows = basin_experiment(net, patterns, trials=40)
    if pd is not None:
        df = pd.DataFrame(rows)
        print(df.head())
    else:
        print("Basin overview (first 5):", rows[:5])

if __name__ == "__main__":
    main()
