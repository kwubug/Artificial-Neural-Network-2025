from PyQt5.QtCore import pyqtSignal, QThread, pyqtSlot, QVariant
import numpy as np
import plotly.graph_objects as go

class TSPHopfieldBridge(QThread):
    # 定义信号
    routeFound = pyqtSignal(list)
    distanceFound = pyqtSignal(float)
    plotUpdated = pyqtSignal(dict)
    trainingComplete = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data =None
        self.Dis = None
        self.route = None
        self.distance = None
        self.N = 0
        self.epochs = 100
        self.U0 = 0.0009
        self.step = 0.0001
        self.A = 0
        self.B = 0
        self.C = 0
        self.D = 0
        self.energy_history = []

    @pyqtSlot(QVariant)
    def setData(self, data):
        self.data = np.array(data)
        self.N = len(self.data)
        self.Dis = self.calculate_distance_matrix(self.data)
        self.A = self.N ** 2
        self.B = self.A
        self.C = self.N / 4
        self.D = self.N / 2

    def calculate_distance_matrix(self, Data):
        N = len(Data)
        Dis = np.zeros([N, N])
        for i in range(N):
            for j in range(N):
                Dis[i, j] = np.sqrt((Data[i, 0] - Data[j, 0]) ** 2 + (Data[i, 1] - Data[j, 1]) ** 2)
        return Dis

    def run_hopfield_network(self):
        U = 0.002 * (2 * np.random.rand(self.N, self.N) - 1)
        V = 1 / self.N * (2 * np.random.rand(self.N, self.N) - 1)
        best_distance = float('inf')
        best_route = None
        self.energy_history = []

        for epoch in range(self.epochs):
            for _ in range(500):
                deltaU = self.calculate_delta_U(U, V)
                U += self.step * deltaU
                V = 0.5 * (1 + np.tanh(U / self.U0))
                energy = self.calculate_energy(V)
                self.energy_history.append(energy)

            route, distance = self.extract_route(V)
            if route and distance < best_distance:
                best_distance = distance
                best_route = route

        return best_route, best_distance

    def calculate_delta_U(self, U, V):
        deltaU = np.zeros_like(U)
        for x in range(self.N):
            for i in range(self.N):
                t1 = np.sum(V[x, :]) - V[x, i]
                t2 = np.sum(V[:, i]) - V[x, i]
                deltaU[x, i] = -self.A * t1 - self.B * t2 - self.C * (np.sum(V) - 2 * self.N)
        return deltaU

    def calculate_energy(self, V):
        energy = 0.5 * (np.sum((np.sum(V, axis=0) - 1) ** 2) +
                        np.sum((np.sum(V, axis=1) - 1) ** 2))
        return energy

    def extract_route(self, V):
        route = np.argmax(V, axis=0).tolist()
        if len(set(route)) == self.N:
            distance = sum(self.Dis[route[i], route[i + 1]] for i in range(self.N - 1))
            distance += self.Dis[route[-1], route[0]]
            return route, distance
        return None, float('inf')

    @pyqtSlot()
    def solve(self):
        print(111)
        self.setData([[1, 2], [2, 1], [1, 3], [3, 4], [4, 1]])
        if self.data is None:
            return
        self.route, self.distance = self.run_hopfield_network()
        if self.route:
            self.plot_results()
            self.routeFound.emit(self.route)
            self.distanceFound.emit(self.distance)
        self.trainingComplete.emit()

    def plot_results(self):
        # 绘制路径图
        fig_route = go.Figure()
        points = self.data[self.route + [self.route[0]]]
        fig_route.add_trace(go.Scatter(x=points[:, 0], y=points[:, 1], mode='lines+markers'))
        fig_route.update_layout(title='TSP Route', xaxis_title='X', yaxis_title='Y')

        # 绘制能量变化图
        fig_energy = go.Figure()
        fig_energy.add_trace(go.Scatter(y=self.energy_history, mode='lines'))
        fig_energy.update_layout(title='Energy over Iterations', xaxis_title='Iteration', yaxis_title='Energy')

        self.plotUpdated.emit({"route": fig_route, "energy": fig_energy})

        fig_route.show()
        fig_energy.show()

