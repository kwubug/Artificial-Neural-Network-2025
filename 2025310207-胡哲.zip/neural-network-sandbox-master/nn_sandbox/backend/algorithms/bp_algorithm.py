import numpy as np
from . import PredictiveAlgorithm


class BPAlgorithm(PredictiveAlgorithm):
    """三层前馈神经网络的BP学习算法实现"""
    
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.5, search_iteration_constant=10000,
                 test_ratio=0.3, input_nodes=2, hidden_nodes=5, output_nodes=1,
                 activation_type='unipolar', weight_init_range=(-1, 1)):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        # 网络结构参数
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.activation_type = activation_type  # 'unipolar' 或 'bipolar'
        self.weight_init_range = weight_init_range
        
        # 网络权重和偏置
        self.weights_input_hidden = None
        self.weights_hidden_output = None
        self.bias_hidden = None
        self.bias_output = None
        
        # 前向传播的中间结果
        self.hidden_inputs = None
        self.hidden_outputs = None
        self.output_inputs = None
        self.output_outputs = None
        
        # 当前误差
        self.current_error = 0.0
        
        # 动量项
        self.momentum = 0.5
        self.prev_weight_update_hidden = None
        self.prev_weight_update_output = None
        self.prev_bias_update_hidden = None
        self.prev_bias_update_output = None
        
        # 初始化网络
        self._initialize_network()

    @property
    def current_learning_rate(self):
        return self._initial_learning_rate / (1 + self.current_iterations
                                              / self._search_iteration_constant)

    def _initialize_neurons(self):
        """初始化神经元网络 - 适配基类接口"""
        # BP算法使用权重矩阵，这里创建一个虚拟的神经元列表来适配基类
        self._neurons = []
        # 实际的网络初始化在__init__中已经完成
        pass

    def _iterate(self):
        """单次迭代"""
        inputs = np.array(self.current_data[:-1]).reshape(1, -1)
        targets = np.array([self._normalize(self.current_data[-1])]).reshape(1, -1)
        
        error = self._back_propagate(inputs, targets)
        # 不返回任何值，因为基类不期望返回值
        return

    def _initialize_network(self):
        """初始化网络权重和偏置"""
        # 使用 He 初始化
        self.weights_input_hidden = np.random.randn(self.input_nodes, self.hidden_nodes) * np.sqrt(
            2. / self.input_nodes)
        self.weights_input_hidden = np.clip(self.weights_input_hidden, -1.0, 1.0)

        self.weights_hidden_output = np.random.randn(self.hidden_nodes, self.output_nodes) * np.sqrt(
            2. / self.hidden_nodes)
        self.weights_hidden_output = np.clip(self.weights_hidden_output, -1.0, 1.0)

        # 偏置初始化为小随机值
        self.bias_hidden = np.random.uniform(-0.1, 0.1, (1, self.hidden_nodes))
        self.bias_output = np.random.uniform(-0.1, 0.1, (1, self.output_nodes))


    def _sigmoid(self, x):
        """Sigmoid激活函数"""
        # 单极性Sigmoid: f(x) = 1 / (1 + exp(-x))
        if self.activation_type == 'unipolar':
            # 限制输入值范围
            x = np.clip(x, -500, 500)
            return 1 / (1 + np.exp(-x))
        else:  # 双极性Sigmoid: f(x) = 2 / (1 + exp(-x)) - 1
            # 限制输入值范围
            x = np.clip(x, -500, 500)
            return 2 / (1 + np.exp(-x)) - 1

    def _sigmoid_derivative(self, x):
        """Sigmoid函数的导数"""
        if self.activation_type == 'unipolar':
            # 单极性Sigmoid导数: f'(x) = f(x) * (1 - f(x))
            return x * (1 - x)
        else:  # bipolar
            # 双极性Sigmoid导数: f'(x) = 0.5 * (1 - f(x)^2)
            return 0.5 * (1 - x**2)
    
    def _feed_forward(self, inputs):
        """前向传播"""
        # 输入层到隐藏层
        self.hidden_inputs = np.dot(inputs, self.weights_input_hidden) + self.bias_hidden
        self.hidden_outputs = self._sigmoid(self.hidden_inputs)
        
        # 隐藏层到输出层
        self.output_inputs = np.dot(self.hidden_outputs, self.weights_hidden_output) + self.bias_output
        self.output_outputs = self._sigmoid(self.output_inputs)
        
        return self.output_outputs
    
    def _back_propagate(self, inputs, targets):
        """反向传播"""
        # 前向传播
        outputs = self._feed_forward(inputs)
        
        # 计算输出层误差
        output_errors = targets - outputs
        output_deltas = output_errors * self._sigmoid_derivative(outputs)
        
        # 计算隐藏层误差
        hidden_errors = np.dot(output_deltas, self.weights_hidden_output.T)
        hidden_deltas = hidden_errors * self._sigmoid_derivative(self.hidden_outputs)
        
        # 计算当前权重更新
        weight_update_output = self.current_learning_rate * np.dot(self.hidden_outputs.T, output_deltas)
        bias_update_output = self.current_learning_rate * np.sum(output_deltas, axis=0)
        weight_update_hidden = self.current_learning_rate * np.dot(inputs.T, hidden_deltas)
        bias_update_hidden = self.current_learning_rate * np.sum(hidden_deltas, axis=0)

        # 打印梯度和权重更新
        print(f"Weight updates: {weight_update_output}")

        # 检查梯度是否太小，如果太小则放大
        max_gradient = max(np.max(np.abs(weight_update_output)), 
                          np.max(np.abs(weight_update_hidden)))
        if max_gradient < 1e-6:
            # 如果梯度太小，放大梯度
            scale_factor = 1e-4 / max_gradient if max_gradient > 0 else 1000
            weight_update_output *= scale_factor
            bias_update_output *= scale_factor
            weight_update_hidden *= scale_factor
            bias_update_hidden *= scale_factor

        max_grad = 1.0
        if np.max(np.abs(weight_update_output)) > max_grad:
            weight_update_output = np.sign(weight_update_output) * max_grad

        # 更新权重和偏置
        self.weights_hidden_output -= weight_update_output
        self.bias_output -= bias_update_output
        self.weights_input_hidden -= weight_update_hidden
        self.bias_hidden -= bias_update_hidden
        
        return np.mean(np.abs(output_errors))
    
    def _initialize_neurons(self):
        """初始化神经元网络 - 适配基类接口"""
        # BP算法使用权重矩阵，这里创建一个虚拟的神经元列表来适配基类
        self._neurons = []
        # 实际的网络初始化在__init__中已经完成
        pass

    def _iterate(self):
        """单次迭代"""
        inputs = np.array(self.current_data[:-1]).reshape(1, -1)
        targets = np.array([self._normalize(self.current_data[-1])]).reshape(1, -1)
        
        self.current_error = self._back_propagate(inputs, targets)
    
    def _normalize(self, value):
        """标准化期望输出"""
        if len(self.group_types) == 1:
            # 如果只有一个类别，直接返回0或1
            return 0.0 if self.activation_type == 'unipolar' else -1.0
        
        if self.activation_type == 'unipolar':
            # 单极性: 输出范围 [0, 1]
            min_val = np.amin(self.group_types)
            max_val = np.amax(self.group_types)
            if max_val == min_val:
                return 0.5
            return (value - min_val) / (max_val - min_val)
        else:  # bipolar
            # 双极性: 输出范围 [-1, 1]
            min_val = np.amin(self.group_types)
            max_val = np.amax(self.group_types)
            if max_val == min_val:
                return 0.5 if self.activation_type == 'unipolar' else 0.0


    def _denormalize(self, value):
        """反标准化输出"""
        if self.activation_type == 'unipolar':
            return value * (np.amax(self.group_types) - np.amin(self.group_types)) + np.amin(self.group_types)
        else:  # bipolar
            return (value + 1) * (np.amax(self.group_types) - np.amin(self.group_types)) / 2 + np.amin(self.group_types)
    
    def _correct_rate(self, dataset):
        
        correct_count = 0
        for data in dataset:
            inputs = np.array(data[:-1]).reshape(1, -1)
            target = data[-1]
            
            # 前向传播
            outputs = self._feed_forward(inputs)
            predicted = self._denormalize(outputs[0, 0])
            
            # 对于分类问题，使用最近邻分类
            # 找到最接近的类别
            min_distance = float('inf')
            predicted_class = None
            for class_val in self.group_types:
                distance = abs(predicted - class_val)
                if distance < min_distance:
                    min_distance = distance
                    predicted_class = class_val
            
            # 判断预测是否正确
            if predicted_class == target:
                correct_count += 1
        
        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def predict(self, inputs):
        """预测函数"""
        if self.weights_input_hidden is None:
            return None

        inputs = np.array(inputs).reshape(1, -1)
        outputs = self._feed_forward(inputs)
        return self._denormalize(outputs[0, 0])

    def get_network_info(self):
        """获取网络信息"""
        return {
            'input_nodes': self.input_nodes,
            'hidden_nodes': self.hidden_nodes,
            'output_nodes': self.output_nodes,
            'activation_type': self.activation_type,
            'weight_init_range': self.weight_init_range,
            'weights_input_hidden': self.weights_input_hidden.tolist() if self.weights_input_hidden is not None else None,
            'weights_hidden_output': self.weights_hidden_output.tolist() if self.weights_hidden_output is not None else None,
            'bias_hidden': self.bias_hidden.tolist() if self.bias_hidden is not None else None,
            'bias_output': self.bias_output.tolist() if self.bias_output is not None else None
        }
