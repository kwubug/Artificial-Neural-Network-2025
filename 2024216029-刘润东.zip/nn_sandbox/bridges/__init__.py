import PyQt5.QtCore

from .bridge import Bridge, BridgeProperty
from .perceptron_bridge import PerceptronBridge
from .mlp_bridge import MlpBridge
from .rbfn_bridge import RbfnBridge
from .som_bridge import SomBridge
from .bm_bridge import BmBridge
from .hopfield_bridge import HopfieldBridge
from .tsp_bridge import TspBridge
from .BPnetwork_bridge import BPnetworkBridge
from .steepest_descent_bridge import SteepestDescentBridge
from .newton_bridge import NewtonBridge
from .conjugate_gradient_bridge import ConjugateGradientBridge
from .ols_bridge import OLSBridge
