import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget,
    QPushButton, QLineEdit, QLabel, QComboBox, QHBoxLayout,
    QSpinBox, QDoubleSpinBox
)
from PyQt5.QtCore import Qt, QTimer
from mpl_toolkits.mplot3d import Axes3D


### ---------- 损失函数与梯度计算 ----------
def loss_function(x, y):
    """二维测试损失函数（简单二次函数，最小值在(0,0)）"""
    return 0.5 * x**2 + 2 * y**2

def gradient(theta):
    """计算损失函数的精确梯度"""
    x, y = theta
    return np.array([x, 4 * y])


### ---------- 梯度下降算法基类与子类 ----------
class GradientDescent:
    """梯度下降算法基类"""
    def __init__(self, lr=0.1, max_iter=100, batch_size=None):
        self.lr = lr          # 学习率
        self.max_iter = max_iter  # 最大迭代次数
        self.batch_size = batch_size  # 小批量大小（MBGD）
        self.theta = None     # 当前参数（x, y）
        self.history = []     # 记录每次迭代的参数轨迹

    def initialize(self, initial_theta):
        """初始化参数"""
        self.theta = np.array(initial_theta, dtype=float)
        self.history = [self.theta.copy()]

    def compute_gradient(self, theta):
        """计算梯度"""
        raise NotImplementedError

    def update(self):
        """执行一次梯度更新，返回当前参数"""
        grad = self.compute_gradient(self.theta)
        self.theta -= self.lr * grad
        self.history.append(self.theta.copy())
        return self.theta


class BGD(GradientDescent):
    """批量梯度下降法（BGD）"""
    def compute_gradient(self, theta):
        return gradient(theta)


class SGD(GradientDescent):
    """随机梯度下降法（SGD）"""
    def __init__(self, lr=0.1, max_iter=100, noise_std=0.1):
        super().__init__(lr, max_iter)
        self.noise_std = noise_std

    def compute_gradient(self, theta):
        true_grad = gradient(theta)
        noise = np.random.normal(0, self.noise_std, size=2)
        return true_grad + noise


class MBGD(GradientDescent):
    """小批量梯度下降法（MBGD）"""
    def __init__(self, lr=0.1, max_iter=100, batch_size=10, noise_std=0.05):
        super().__init__(lr, max_iter)
        self.batch_size = batch_size
        self.noise_std = noise_std

    def compute_gradient(self, theta):
        true_grad = gradient(theta)
        # 模拟小批量：随机生成batch_size个带噪声的梯度并取平均
        batch_grads = []
        for _ in range(self.batch_size):
            noise = np.random.normal(0, self.noise_std, size=2)
            batch_grads.append(true_grad + noise)
        return np.mean(batch_grads, axis=0)


### ---------- PyQt5 可视化 ----------
class GradientDescentVisualizer(QMainWindow):
    """梯度下降可视化主界面"""
    def __init__(self):
        super().__init__()
        self.setWindowTitle("梯度下降法可视化")
        self.setGeometry(100, 100, 1000, 800)

        # ---------- 3D绘图区域 ----------
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111, projection='3d')

        # 初始化3D曲面（损失函数）
        self.init_3d_plot()

        # ---------- 控制面板 ----------
        control_layout = QVBoxLayout()

        # 算法选择
        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["批量梯度下降(BGD)", "随机梯度下降(SGD)", "小批量梯度下降(MBGD)"])
        self.algorithm_combo.currentIndexChanged.connect(self.update_algorithm)
        control_layout.addWidget(QLabel("选择算法："))
        control_layout.addWidget(self.algorithm_combo)

        # 学习率
        self.lr_label = QLabel("学习率(lr)：")
        self.lr_input = QDoubleSpinBox()
        self.lr_input.setRange(0.001, 1.0)
        self.lr_input.setValue(0.1)
        self.lr_input.setSingleStep(0.01)
        control_layout.addWidget(self.lr_label)
        control_layout.addWidget(self.lr_input)

        # 迭代次数
        self.iter_label = QLabel("迭代次数：")
        self.iter_input = QSpinBox()
        self.iter_input.setRange(10, 500)
        self.iter_input.setValue(100)
        control_layout.addWidget(self.iter_label)
        control_layout.addWidget(self.iter_input)

        # 批量大小（SGD/MBGD使用）
        self.batch_label = QLabel("批量大小(batch_size)：")
        self.batch_input = QSpinBox()
        self.batch_input.setRange(1, 50)
        self.batch_input.setValue(10)
        self.batch_input.setVisible(False)  # 初始隐藏（BGD不使用）
        control_layout.addWidget(self.batch_label)
        control_layout.addWidget(self.batch_input)

        # 噪声标准差（SGD/MBGD使用）
        self.noise_label = QLabel("噪声标准差(noise_std)：")
        self.noise_input = QDoubleSpinBox()
        self.noise_input.setRange(0.0, 1.0)
        self.noise_input.setValue(0.1)
        self.noise_input.setVisible(False)  # 初始隐藏（BGD不使用）
        control_layout.addWidget(self.noise_label)
        control_layout.addWidget(self.noise_input)

        # 启动按钮
        self.start_button = QPushButton("开始迭代")
        self.start_button.clicked.connect(self.start_iteration)
        control_layout.addWidget(self.start_button)

        # ---------- 主布局 ----------
        main_layout = QHBoxLayout()
        main_layout.addWidget(self.canvas, stretch=3)  # 3D绘图占3份宽度
        main_layout.addLayout(control_layout, stretch=1)  # 控制面板占1份宽度
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # ---------- 梯度下降对象与初始参数 ----------
        self.gd = None  # 当前梯度下降算法实例
        self.current_algorithm = "BGD"  # 初始算法
        self.update_algorithm()  # 初始化算法控件显示
        self.initial_theta = [4, 4]  # 初始参数点 (x, y)

    def init_3d_plot(self):
        """初始化3D曲面和坐标轴"""
        # 生成网格数据
        x = np.linspace(-5, 5, 100)
        y = np.linspace(-5, 5, 100)
        X, Y = np.meshgrid(x, y)
        Z = loss_function(X, Y)

        # 绘制损失函数曲面
        self.ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8)
        self.ax.set_xlabel('x')
        self.ax.set_ylabel('y')
        self.ax.set_zlabel('Loss')
        self.ax.set_title('梯度下降法可视化')

        # 初始化路径线（红色实线）
        self.path_line, = self.ax.plot([], [], [], 'r-', linewidth=2)
        # 初始化当前点（红色散点）
        self.current_point = self.ax.scatter([], [], [], c='r', s=50)
        # 标记最优解（绿色星标）
        self.ax.scatter(0, 0, loss_function(0, 0), c='g', s=100, marker='*', label='最优解')
        self.ax.legend()

    def update_algorithm(self):
        """根据选择的算法，显示/隐藏批量大小和噪声输入"""
        algorithm = self.algorithm_combo.currentText()
        if algorithm == "批量梯度下降(BGD)":
            self.batch_input.setVisible(False)
            self.noise_input.setVisible(False)
            self.current_algorithm = "BGD"
        elif algorithm == "随机梯度下降(SGD)":
            self.batch_input.setVisible(True)
            self.batch_input.setValue(1)  # SGD默认batch_size=1
            self.noise_input.setVisible(True)
            self.current_algorithm = "SGD"
        elif algorithm == "小批量梯度下降(MBGD)":
            self.batch_input.setVisible(True)
            self.noise_input.setVisible(True)
            self.current_algorithm = "MBGD"

    def start_iteration(self):
        """启动"""
        lr = self.lr_input.value()
        max_iter = self.iter_input.value()
        if self.current_algorithm == "BGD":
            self.gd = BGD(lr=lr, max_iter=max_iter)
        elif self.current_algorithm == "SGD":
            batch_size = self.batch_input.value()
            noise_std = self.noise_input.value()
            self.gd = SGD(lr=lr, max_iter=max_iter, noise_std=noise_std)
        elif self.current_algorithm == "MBGD":
            batch_size = self.batch_input.value()
            noise_std = self.noise_input.value()
            self.gd = MBGD(lr=lr, max_iter=max_iter, batch_size=batch_size, noise_std=noise_std)

        # 初始化参数和绘图
        self.gd.initialize(self.initial_theta)
        self.path_line.set_data([], [])
        self.path_line.set_3d_properties([])
        self.current_point.remove()
        self.current_point = self.ax.scatter([], [], [], c='r', s=50)

        # （每50毫秒更新一次）
        self.iter_count = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_iteration)
        self.timer.start(50)

    def update_iteration(self):
        """单步更新迭代，刷新3D绘图"""
        if self.iter_count < self.gd.max_iter:
            # 执行一次梯度更新
            current_theta = self.gd.update()
            # 更新路径线（已迭代的轨迹）
            history = np.array(self.gd.history)
            self.path_line.set_data(history[:, 0], history[:, 1])
            self.path_line.set_3d_properties(loss_function(history[:, 0], history[:, 1]))
            # 更新当前点（最新参数的位置）
            self.current_point._offsets3d = (
                [current_theta[0]],
                [current_theta[1]],
                [loss_function(current_theta[0], current_theta[1])]
            )
            self.canvas.draw()
            self.iter_count += 1
        else:
            self.timer.stop()

    def closeEvent(self, event):
        """窗口关闭时停止定时器"""
        if hasattr(self, 'timer'):
            self.timer.stop()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GradientDescentVisualizer()
    window.show()
    sys.exit(app.exec_())