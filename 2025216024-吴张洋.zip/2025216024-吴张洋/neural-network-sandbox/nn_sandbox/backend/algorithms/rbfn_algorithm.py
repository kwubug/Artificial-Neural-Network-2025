import copy
import numpy as np

from . import PredictiveAlgorithm
from .k_means import KMeans
from ..neurons import RbfNeuron


class RbfnAlgorithm(PredictiveAlgorithm):
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 acceptable_range=0.5, initial_learning_rate=0.8,
                 search_iteration_constant=10000, cluster_count=3,
                 test_ratio=0.3):
        # 对于曲线拟合任务，使用更大的search_iteration_constant来减缓学习率衰减
        is_curve_fitting = len(dataset) > 0 and len(dataset[0]) == 2  # 1D输入 + 1D输出
        if is_curve_fitting:
            # 对于曲线拟合，使用更慢的学习率衰减（增加search_iteration_constant）
            # 这样学习率在训练过程中衰减更慢，保持更强的学习能力
            search_iteration_constant = search_iteration_constant * 5  # 增加到5倍
        
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        # 对于曲线拟合任务，自动调整acceptable_range
        # 如果数据集是1D输入（曲线拟合），使用更小的acceptable_range
        if is_curve_fitting:
            # 计算目标值的范围
            target_values = [data[-1] for data in dataset]
            target_range = max(target_values) - min(target_values)
            # 如果acceptable_range太大（超过目标范围的20%），自动调整为更小的值
            if acceptable_range > target_range * 0.2:
                self.acceptable_range = target_range * 0.1  # 使用目标范围的10%
            else:
                self.acceptable_range = acceptable_range
        else:
            self.acceptable_range = acceptable_range
        self.cluster_count = cluster_count
        self._is_curve_fitting = is_curve_fitting
        # 用于跟踪正确率停滞情况
        self._stagnation_counter = 0
        self._last_best_rate = 0.0
        self._stagnation_threshold = 10  # 如果10个epoch没有改进，认为停滞
        # 用于跟踪曲线退化情况
        self._curve_variance_history = []  # 记录拟合曲线的方差历史
        self._degradation_counter = 0

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        self._adjust_neurons(result)
    
    def _check_stagnation(self):
        """检查正确率是否停滞，如果停滞则调整学习率"""
        if not self._is_curve_fitting:
            return
        
        # 检查是否达到新的最佳正确率
        if self.best_correct_rate > self._last_best_rate:
            self._last_best_rate = self.best_correct_rate
            self._stagnation_counter = 0
            self._degradation_counter = 0
        else:
            self._stagnation_counter += 1
        
        # 检测曲线是否退化（变平）
        # 计算当前拟合曲线的方差（衡量曲线的弯曲程度）
        try:
            import numpy as np
            x_points = np.arange(-1.0, 1.01, 0.1)  # 采样点
            y_values = []
            for x in x_points:
                x_input = np.array([x])
                result = self._feed_forward(x_input)
                y_values.append(float(result))
            
            # 计算y值的方差，方差小说明曲线变平
            curve_variance = np.var(y_values)
            self._curve_variance_history.append(curve_variance)
            
            # 只保留最近20个epoch的记录
            if len(self._curve_variance_history) > 20:
                self._curve_variance_history.pop(0)
            
            # 如果最近5个epoch的方差持续下降，说明曲线在变平
            if len(self._curve_variance_history) >= 5:
                recent_variances = self._curve_variance_history[-5:]
                if all(recent_variances[i] < recent_variances[i-1] for i in range(1, len(recent_variances))):
                    self._degradation_counter += 1
                    # 如果连续3次检测到退化，恢复到最佳神经元
                    if self._degradation_counter >= 3 and hasattr(self, '_best_neurons') and self._best_neurons:
                        # 恢复到最佳状态
                        self._neurons = copy.deepcopy(self._best_neurons)
                        self._degradation_counter = 0
                        self._curve_variance_history = []  # 重置历史
                else:
                    self._degradation_counter = 0
        except Exception:
            pass
    
    @property
    def current_learning_rate(self):
        """重写学习率属性，对于曲线拟合任务，使用更稳定的学习率策略"""
        base_lr = super().current_learning_rate
        
        # 移除停滞时的学习率增加，因为这可能导致参数发散
        # 改为使用更平滑的学习率衰减
        if self._is_curve_fitting:
            # 确保学习率不会衰减太快
            # 使用更平滑的衰减曲线
            progress = self.current_iterations / (self._total_epoches * len(self.training_dataset))
            # 在训练后期，减缓学习率衰减
            if progress > 0.5:
                # 后期保持更高的学习率
                min_lr = self._initial_learning_rate * 0.3
                if base_lr < min_lr:
                    return min_lr
        
        return base_lr

    def _initialize_neurons(self):
        clusters = KMeans(self.cluster_count).fit(self.training_dataset)
        self._neurons = []
        for cluster in clusters:
            # 确保standard_deviation不会太小
            std = max(cluster.avg_distance, 0.2)  # 最小标准差为0.2
            self._neurons.append(RbfNeuron(cluster.center, std))
        self._neurons.insert(0, RbfNeuron(is_threshold=True))

    def _feed_forward(self, data):
        # 确保data是numpy数组
        if not isinstance(data, np.ndarray):
            data = np.array(data)
        for neuron in self._neurons:
            neuron.data = data
        return sum(neuron.result for neuron in self._neurons)

    def _adjust_neurons(self, output):
        expect = self.current_data[-1]
        error = expect - output
        for neuron in self._neurons:
            new_synaptic_weight_diff = self._get_synaptic_weight_diff(
                output, expect, neuron
            )
            if not neuron.is_threshold and neuron.standard_deviation != 0:
                # 确保data和mean都是numpy数组
                data = np.array(neuron.data) if not isinstance(neuron.data, np.ndarray) else neuron.data
                mean = np.array(neuron.mean) if not isinstance(neuron.mean, np.ndarray) else neuron.mean
                
                data_mean_diff = data - mean
                # 计算激活值
                activation = neuron.activation_function(
                    data, mean, neuron.standard_deviation
                )
                
                # 如果激活值太小，跳过mean和std的更新，只更新权重
                # 这样可以避免在激活值很小时进行不稳定的更新
                if activation < 0.001:
                    neuron.synaptic_weight += new_synaptic_weight_diff
                    continue
                
                # 计算距离的平方（用于梯度计算）
                if data_mean_diff.ndim == 0:
                    dist_sq = float(data_mean_diff) ** 2
                    data_mean_diff_vec = data_mean_diff
                else:
                    dist_sq = float(data_mean_diff.dot(data_mean_diff))
                    data_mean_diff_vec = data_mean_diff
                
                # 改进mean的更新：使用梯度下降
                # 梯度 = error * synaptic_weight * activation * (data - mean) / (sigma^2)
                # 根据误差大小动态调整更新策略
                if self._is_curve_fitting:
                    # 根据误差大小动态调整：误差大时更新大，误差小时更新小
                    abs_error = abs(error)
                    # 归一化误差（假设最大误差约为2.0）
                    normalized_error = min(abs_error / 2.0, 1.0)
                    # 误差大时使用更大的更新步长，误差小时使用更小的步长
                    # 范围：0.6 - 1.2倍学习率
                    mean_learning_factor = self.current_learning_rate * (0.6 + 0.6 * normalized_error)
                    # 更新幅度限制也根据误差调整
                    mean_update_limit = 0.03 + 0.04 * normalized_error  # 范围：0.03 - 0.07
                else:
                    mean_learning_factor = self.current_learning_rate * 1.0
                    mean_update_limit = 0.05
                
                # 计算梯度
                sigma_sq = max(neuron.standard_deviation**2, 0.01)
                mean_gradient = error * neuron.synaptic_weight * activation * data_mean_diff_vec / sigma_sq
                
                # 梯度裁剪：限制梯度的大小，避免梯度爆炸
                gradient_norm = np.linalg.norm(mean_gradient) if isinstance(mean_gradient, np.ndarray) else abs(mean_gradient)
                max_gradient_norm = 1.0  # 最大梯度范数
                if gradient_norm > max_gradient_norm:
                    if isinstance(mean_gradient, np.ndarray):
                        mean_gradient = mean_gradient / gradient_norm * max_gradient_norm
                    else:
                        mean_gradient = np.sign(mean_gradient) * max_gradient_norm
                
                # 限制更新幅度，避免单次更新过大
                mean_update = mean_learning_factor * mean_gradient
                # 根据任务类型使用不同的更新限制
                if isinstance(mean_update, np.ndarray):
                    mean_update = np.clip(mean_update, -mean_update_limit, mean_update_limit)
                else:
                    mean_update = np.clip(float(mean_update), -mean_update_limit, mean_update_limit)
                
                new_mean = mean + mean_update
                
                # 改进standard_deviation的更新
                # 梯度 = error * synaptic_weight * activation * dist_sq / (sigma^3)
                if self._is_curve_fitting:
                    # 根据误差大小动态调整
                    abs_error = abs(error)
                    normalized_error = min(abs_error / 2.0, 1.0)
                    # 范围：0.2 - 0.4倍学习率
                    std_learning_factor = self.current_learning_rate * (0.2 + 0.2 * normalized_error)
                    # 更新幅度限制也根据误差调整
                    std_update_limit = 0.01 + 0.02 * normalized_error  # 范围：0.01 - 0.03
                else:
                    std_learning_factor = self.current_learning_rate * 0.3
                    std_update_limit = 0.02
                
                sigma_cubed = max(neuron.standard_deviation**3, 0.001)
                std_gradient = error * neuron.synaptic_weight * activation * dist_sq / sigma_cubed
                
                # 梯度裁剪：限制梯度的大小
                max_std_gradient = 0.5  # 最大梯度值
                std_gradient = np.clip(float(std_gradient), -max_std_gradient, max_std_gradient)
                
                # 限制更新幅度
                std_update = std_learning_factor * std_gradient
                std_update = np.clip(float(std_update), -std_update_limit, std_update_limit)
                
                new_standard_deviation = neuron.standard_deviation + std_update
                
                # 确保standard_deviation不会太小或太大
                if self._is_curve_fitting:
                    new_standard_deviation = max(0.2, min(new_standard_deviation, 1.5))  # 更保守的范围
                else:
                    new_standard_deviation = max(0.2, min(new_standard_deviation, 1.5))
                
                neuron.mean = new_mean
                neuron.standard_deviation = new_standard_deviation
            neuron.synaptic_weight += new_synaptic_weight_diff

    def _get_synaptic_weight_diff(self, output, expect, neuron):
        if neuron.is_threshold:
            return self.current_learning_rate * (expect - output)
        return self.current_learning_rate * (expect - output) * neuron.activation_function(
            neuron.data, neuron.mean, neuron.standard_deviation
        )

    def _save_best_neurons(self):
        """重写基类方法，添加停滞检测"""
        super()._save_best_neurons()
        # 检查停滞情况（每个epoch检查一次）
        if self.current_iterations % len(self.training_dataset) == 0:
            self._check_stagnation()
    
    def _correct_rate(self, dataset):
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            # 对于曲线拟合，使用相对误差而不是绝对误差
            target = data[-1]
            if abs(target) > 0.01:  # 如果目标值不为0，使用相对误差
                relative_error = abs(result - target) / abs(target)
                if relative_error < 0.2:  # 相对误差小于20%认为正确
                    correct_count += 1
            else:  # 如果目标值接近0，使用绝对误差
                if abs(result - target) < self.acceptable_range:
                    correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)
    
    def _calculate_mse(self, dataset):
        """计算均方误差（MSE），用于曲线拟合任务"""
        total_error = 0.0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            error = (data[-1] - result) ** 2
            total_error += error
        return total_error / len(dataset) if len(dataset) > 0 else float('inf')