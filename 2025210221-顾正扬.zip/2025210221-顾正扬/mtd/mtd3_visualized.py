import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# 定义函数 F(x)
def F1(x1, x2):
    return x1 ** 2 + x1 * x2 + x2 ** 2


# 创建 x1 和 x2 的网格
x1 = np.linspace(-2, 2, 400)
x2 = np.linspace(-2, 2, 400)
X1, X2 = np.meshgrid(x1, x2)

Z = F1(X1, X2)

# 绘制等高线图
plt.figure(figsize=(8, 6))
contour = plt.contour(X1, X2, Z, levels=120, cmap='viridis')
plt.clabel(contour, inline=True, fontsize=8)
plt.title('Contour plot of F(x) = (x2 - x1) ** 4 + 8 * x1 * x2 - x1 + x2 + 3')
plt.xlabel('x1')
plt.ylabel('x2')
plt.colorbar(contour)
plt.grid(True)

'''Mtd1 第五种 沿直线最小化：'''
# f1 = pd.read_excel('m1_F2.xlsx')
# plt.plot(f1['x1'], f1['x2'], label='M1', marker='.', linestyle='-', color='black')
'''Mtd3 共轭梯度法'''
f3 = pd.read_excel('m3.xlsx')
plt.plot(f3['x1'], f3['x2'], label='M3', marker='.', linestyle='-', color='black')

# 添加图例
plt.legend()
plt.show()
