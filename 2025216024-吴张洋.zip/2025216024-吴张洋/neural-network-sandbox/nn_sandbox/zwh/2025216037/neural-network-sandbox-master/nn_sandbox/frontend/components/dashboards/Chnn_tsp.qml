import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'CHNN_TSP'

    property bool bridgeReady: typeof chnnTspBridge !== 'undefined' && chnnTspBridge !== null

    RowLayout {
        anchors.fill: parent
        spacing: 15
        
        // 左侧控制面板
        ColumnLayout {
            Layout.preferredWidth: 420
            Layout.minimumWidth: 380
            Layout.fillHeight: true
            spacing: 12
            
            GroupBox {
                Layout.fillWidth: true
                
                label: Label {
                    text: 'TSP 问题设置'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 12
                    
                    Label { 
                        text: '城市数量'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 8
                        from: 4
                        to: 15
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_n_cities(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                    
                    Button {
                        text: '生成随机城市'
                        font.pixelSize: 16
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        onClicked: { 
                            if (bridgeReady) chnnTspBridge.generate_random_cities()
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 45
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                
                label: Label {
                    text: '能量函数参数'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 12
                    
                    Label { 
                        text: 'A (行约束)'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_A(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                    
                    Label { 
                        text: 'B (列约束)'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_B(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                    
                    Label { 
                        text: 'C (数量约束)'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 200
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_C(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                    
                    Label { 
                        text: 'D (距离权重)'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_D(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                
                label: Label {
                    text: '运行参数'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 12
                    
                    Label { 
                        text: '最大迭代次数'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 5000
                        from: 1000
                        to: 20000
                        stepSize: 1000
                        onValueChanged: { if (bridgeReady) chnnTspBridge.max_iterations = value }
                        Layout.fillWidth: true
                        font.pixelSize: 15
                    }
                    
                    Label { 
                        text: 'UI刷新间隔'
                        font.pixelSize: 16
                    }
                    DoubleSpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 0.05 * 100
                        from: 0
                        to: 100
                        onValueChanged: { if (bridgeReady) chnnTspBridge.ui_refresh_interval = value / 100 }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '开始求解'
                        font.pixelSize: 18
                        font.bold: true
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        onClicked: { 
                            console.log("开始求解TSP")
                            if (bridgeReady) {
                                // 清空曲线和路径
                                distanceSeries.clear()
                                cityCanvas.requestPaint()
                                chnnTspBridge.start_solving()
                            }
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 50
                    }
                    
                    Button {
                        text: '停止'
                        font.pixelSize: 16
                        enabled: bridgeReady ? !chnnTspBridge.has_finished : false
                        onClicked: { if (bridgeReady) chnnTspBridge.stop_algorithm() }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 45
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                label: Label {
                    text: '求解信息'
                    font.pixelSize: 20
                    font.bold: true
                }
                
                ColumnLayout {
                    anchors.fill: parent
                    spacing: 15
                    
                    GridLayout {
                        Layout.fillWidth: true
                        columns: 2
                        rowSpacing: 12
                        columnSpacing: 15
                        
                        Label { 
                            text: '当前迭代'
                            font.pixelSize: 20
                        }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_iterations : '0'
                            font.bold: true
                            font.pixelSize: 20
                            Layout.fillWidth: true
                        }
                        
                        Label { 
                            text: '当前能量'
                            font.pixelSize: 20
                        }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_energy.toFixed(2) : '0.00'
                            font.bold: true
                            font.pixelSize: 20
                            Layout.fillWidth: true
                        }
                        
                        Label { 
                            text: '当前路径长度'
                            font.pixelSize: 20
                        }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_distance.toFixed(4) : '0.0000'
                            font.bold: true
                            font.pixelSize: 20
                            color: bridgeReady && chnnTspBridge.is_valid_solution ? 'green' : 'orange'
                            Layout.fillWidth: true
                        }
                        
                        Label { 
                            text: '是否有效解'
                            font.pixelSize: 20
                        }
                        Label { 
                            text: bridgeReady ? (chnnTspBridge.is_valid_solution ? '是' : '否') : '否'
                            color: bridgeReady && chnnTspBridge.is_valid_solution ? 'green' : 'red'
                            font.bold: true
                            font.pixelSize: 20
                            Layout.fillWidth: true
                        }
                    }
                    
                    Rectangle {
                        Layout.fillWidth: true
                        height: 3
                        color: "#CCCCCC"
                    }
                    
                    // 最优路径长度 - 突出显示
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 8
                        
                        Label { 
                            text: '最优路径长度'
                            font.pixelSize: 20
                            font.bold: true
                            Layout.alignment: Qt.AlignHCenter
                        }
                        
                        Label { 
                            text: {
                                if (!bridgeReady) return '∞'
                                if (chnnTspBridge.best_distance === Infinity) return '∞'
                                return chnnTspBridge.best_distance.toFixed(4)
                            }
                            font.bold: true
                            font.pixelSize: 32
                            color: 'green'
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                    
                    Item { Layout.fillHeight: true }
                }
            }
        }
        
        // 右侧显示区域
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 15
            
            // 城市和路径可视化
            GroupBox {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 450
                
                label: Label {
                    text: '城市分布与最优路径'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                Rectangle {
                    anchors.fill: parent
                    color: "white"
                    border.color: "#CCCCCC"
                    border.width: 2
                    
                    Canvas {
                        id: cityCanvas
                        anchors.fill: parent
                        anchors.margins: 20
                        
                        onPaint: {
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            
                            if (!bridgeReady || !chnnTspBridge.city_positions || 
                                chnnTspBridge.city_positions.length === 0) {
                                return
                            }
                            
                            var cities = chnnTspBridge.city_positions
                            
                            var scale = Math.min(width, height) * 0.85
                            var offsetX = (width - scale) / 2
                            var offsetY = (height - scale) / 2
                            
                            // 优先显示当前路径（实时），用青色表示正在计算
                            var showCurrentTour = chnnTspBridge.current_tour && 
                                                 chnnTspBridge.current_tour.length === cities.length &&
                                                 !chnnTspBridge.has_finished
                            
                            // 如果有当前路径且未完成，显示当前路径；否则显示最优路径
                            var tour = showCurrentTour ? chnnTspBridge.current_tour : 
                                      (chnnTspBridge.best_tour && chnnTspBridge.best_tour.length === cities.length ? 
                                       chnnTspBridge.best_tour : null)
                            
                            // 绘制路径（实时或最优）
                            if (tour && tour.length === cities.length) {
                                // 当前路径用青色，最优路径用蓝色
                                var useCurrentPath = showCurrentTour
                                ctx.strokeStyle = useCurrentPath ? "#00BCD4" : "#2196F3"
                                ctx.lineWidth = useCurrentPath ? 3 : 4
                                ctx.lineCap = "round"
                                ctx.lineJoin = "round"
                                ctx.beginPath()
                                
                                for (var i = 0; i < tour.length; i++) {
                                    var cityIdx = tour[i]
                                    if (cityIdx >= 0 && cityIdx < cities.length) {
                                        var x = cities[cityIdx][0] * scale + offsetX
                                        var y = cities[cityIdx][1] * scale + offsetY
                                        
                                        if (i === 0) {
                                            ctx.moveTo(x, y)
                                        } else {
                                            ctx.lineTo(x, y)
                                        }
                                    }
                                }
                                
                                // 连接回起点
                                if (tour.length > 0 && tour[0] >= 0 && tour[0] < cities.length) {
                                    var x0 = cities[tour[0]][0] * scale + offsetX
                                    var y0 = cities[tour[0]][1] * scale + offsetY
                                    ctx.lineTo(x0, y0)
                                }
                                
                                ctx.stroke()
                            }
                            
                            // 绘制城市
                            for (var i = 0; i < cities.length; i++) {
                                var x = cities[i][0] * scale + offsetX
                                var y = cities[i][1] * scale + offsetY
                                
                                // 城市圆点
                                ctx.fillStyle = "#F44336"
                                ctx.beginPath()
                                ctx.arc(x, y, 15, 0, 2 * Math.PI)
                                ctx.fill()
                                
                                // 城市编号
                                ctx.fillStyle = "white"
                                ctx.font = "bold 18px Arial"
                                ctx.textAlign = "center"
                                ctx.textBaseline = "middle"
                                ctx.fillText(i.toString(), x, y)
                                
                                // 外圈
                                ctx.strokeStyle = "black"
                                ctx.lineWidth = 3
                                ctx.beginPath()
                                ctx.arc(x, y, 15, 0, 2 * Math.PI)
                                ctx.stroke()
                            }
                        }
                    }
                }
            }
            
            // 路径长度曲线和神经元矩阵
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 320
                Layout.minimumHeight: 280
                spacing: 15
                
                // 路径长度变化曲线（放大）
                GroupBox {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    
                    label: Label {
                        text: '路径长度变化曲线'
                        font.pixelSize: 18
                        font.bold: true
                    }
                    
                    ChartView {
                        id: distanceChart
                        anchors.fill: parent
                        antialiasing: true
                        legend.visible: false
                        
                        ValueAxis {
                            id: distanceXAxis
                            titleText: "迭代次数"
                            titleFont.pixelSize: 15
                            labelsFont.pixelSize: 13
                            min: 0
                            max: 5000
                        }
                        
                        ValueAxis {
                            id: distanceYAxis
                            titleText: "路径长度"
                            titleFont.pixelSize: 15
                            labelsFont.pixelSize: 13
                            min: 0
                            max: 5
                        }
                        
                        LineSeries {
                            id: distanceSeries
                            axisX: distanceXAxis
                            axisY: distanceYAxis
                            useOpenGL: true
                            color: "#4CAF50"
                            width: 3
                        }
                    }
                }
                
                // 神经元状态矩阵
                GroupBox {
                    Layout.preferredWidth: 350
                    Layout.minimumWidth: 300
                    Layout.fillHeight: true
                    
                    label: Label {
                        text: '神经元状态矩阵 (N×N)'
                        font.pixelSize: 16
                        font.bold: true
                    }
                    
                    ScrollView {
                        anchors.fill: parent
                        clip: true
                        
                        Grid {
                            id: neuronGrid
                            anchors.centerIn: parent
                            columns: bridgeReady ? chnnTspBridge.n_cities : 8
                            spacing: 3
                            
                            Repeater {
                                model: bridgeReady && chnnTspBridge.neuron_matrix ? 
                                       chnnTspBridge.neuron_matrix.length * chnnTspBridge.neuron_matrix.length : 0
                                
                                Rectangle {
                                    width: 38
                                    height: 38
                                    
                                    color: {
                                        if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                            return "lightgray"
                                        
                                        var row = Math.floor(index / chnnTspBridge.n_cities)
                                        var col = index % chnnTspBridge.n_cities
                                        var value = chnnTspBridge.neuron_matrix[row][col]
                                        
                                        var intensity = Math.floor((1 - value) * 255)
                                        return Qt.rgba(intensity/255, intensity/255, 1, 1)
                                    }
                                    
                                    border.color: "#666666"
                                    border.width: 1
                                    
                                    Label {
                                        anchors.centerIn: parent
                                        text: {
                                            if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                                return ""
                                            
                                            var row = Math.floor(index / chnnTspBridge.n_cities)
                                            var col = index % chnnTspBridge.n_cities
                                            return chnnTspBridge.neuron_matrix[row][col].toFixed(2)
                                        }
                                        font.pixelSize: 10
                                        font.bold: true
                                        color: {
                                            if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                                return "black"
                                            var row = Math.floor(index / chnnTspBridge.n_cities)
                                            var col = index % chnnTspBridge.n_cities
                                            var value = chnnTspBridge.neuron_matrix[row][col]
                                            return value > 0.5 ? "white" : "black"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Connections {
        target: bridgeReady ? chnnTspBridge : null
        enabled: bridgeReady
        
        function onCity_positionsChanged() {
            console.log("城市位置更新")
            cityCanvas.requestPaint()
        }
        
        function onBest_tourChanged() {
            console.log("最优路径更新:", chnnTspBridge.best_tour)
            cityCanvas.requestPaint()
        }
        
        function onCurrent_tourChanged() {
            // 当前路径更新（实时）
            cityCanvas.requestPaint()
        }
        
        function onCurrent_distanceChanged() {
            // 当前距离更新时，也重绘画布（路径可能已变化）
            cityCanvas.requestPaint()
        }
        
        function onDistance_historyChanged() {
            if (!bridgeReady || !chnnTspBridge.distance_history)
                return
            
            var history = chnnTspBridge.distance_history
            
            if (history.length === 0) {
                distanceSeries.clear()
                return
            }
            
            // 实时更新：只添加新的数据点，而不是完全重绘
            var currentCount = distanceSeries.count
            var newPointsCount = history.length - currentCount
            
            if (newPointsCount > 0) {
                // 添加新点
                var validCount = 0
                var minD = 999999
                var maxD = 0
                
                for (var i = currentCount; i < history.length; i++) {
                    var val = history[i]
                    
                    // 检查有效性
                    if (val !== undefined && val !== null && 
                        val !== Infinity && val !== -Infinity && 
                        !isNaN(val) && val > 0 && val < 1000) {
                        
                        distanceSeries.append(i, val)
                        validCount++
                        if (val < minD) minD = val
                        if (val > maxD) maxD = val
                    }
                }
                
                // 动态调整Y轴范围
                if (validCount > 0) {
                    // 获取当前所有点的范围
                    var allMin = minD
                    var allMax = maxD
                    for (var j = 0; j < currentCount; j++) {
                        if (distanceSeries.at(j)) {
                            var yVal = distanceSeries.at(j).y
                            if (yVal < allMin) allMin = yVal
                            if (yVal > allMax) allMax = yVal
                        }
                    }
                    
                    // 更新Y轴范围（添加一些边距）
                    var margin = (allMax - allMin) * 0.1
                    distanceYAxis.min = Math.max(0, allMin - margin)
                    distanceYAxis.max = allMax + margin
                }
            } else if (newPointsCount < 0) {
                // 如果历史长度减少（重新开始），清空并重绘
                distanceSeries.clear()
                var validCount = 0
                var minD = 999999
                var maxD = 0
                
                for (var i = 0; i < history.length; i++) {
                    var val = history[i]
                    
                    if (val !== undefined && val !== null && 
                        val !== Infinity && val !== -Infinity && 
                        !isNaN(val) && val > 0 && val < 1000) {
                        
                        distanceSeries.append(i, val)
                        validCount++
                        if (val < minD) minD = val
                        if (val > maxD) maxD = val
                    }
                }
                
                if (validCount > 0) {
                    var margin = (maxD - minD) * 0.1
                    distanceYAxis.min = Math.max(0, minD - margin)
                    distanceYAxis.max = maxD + margin
                }
            }
            
            // 更新X轴范围
            distanceXAxis.max = Math.max(5000, history.length + 500)
        }
    }
    
    Component.onCompleted: {
        console.log("CHNN TSP 页面加载完成")
        console.log("Bridge 就绪:", bridgeReady)
    }
}