import collections
import math

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
# ========== 修改：导入双极性Sigmoid函数 ==========
from ..utils import sigmoid, bipolar_sigmoid
# ===============================================


class MlpAlgorithm(PredictiveAlgorithm):
    """ Backpropagation prototype with batch training support. """

    # ========== 修改：只添加必要的参数 ==========
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None,
                 sigmoid_type='unipolar'):  # 只添加Sigmoid类型选择
        # ========================================
        
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight
        
        # ========== 新增：Sigmoid类型选择 ==========
        self.sigmoid_type = sigmoid_type
        # =======================================

        # the default network shape is (2 * 5)
        self.network_shape = network_shape if network_shape else (5, 5)

        # for momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)
        
        # ========== 新增：批训练相关变量 ==========
        self.total_error = 0  # 总误差E
        self._current_sample = None  # 当前样本
        # ========================================

    # ========== 修改：实现批训练BP算法 ==========
    def run(self):
        """实现图3-18的批训练BP算法流程"""
        self._initialize_neurons()
        
        # 步骤1：初始化网络权值，迭代次数计数器q=1
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            
            # 批训练流程
            self._batch_training_epoch(epoch)
            
            self._save_best_neurons()
            if self._most_correct_rate and self.best_correct_rate >= self._most_correct_rate:
                break
        
        self._load_best_neurons()

    def _batch_training_epoch(self, epoch):
        """批训练：按照图3-18流程实现"""
        # 步骤4：计算总误差E，初始化为0
        self.total_error = 0
        total_deltas = collections.defaultdict(lambda: 0)
        
        # 样本索引计数器p=1
        np.random.shuffle(self.training_dataset)
        
        # 步骤2-5：遍历所有训练样本
        for p, sample in enumerate(self.training_dataset, 1):
            self._current_sample = sample
            
            # 步骤2：输入第p对训练样本
            # 步骤3：计算各层输出
            result = self._feed_forward(sample[:-1])
            
            # 步骤6：计算各层误差信号
            deltas = self._pass_backward(self._normalize(sample[-1]), result)
            
            # 累积梯度（为步骤7的权值调整做准备）
            for neuron in deltas:
                total_deltas[neuron] += deltas[neuron]
            
            # 步骤4：累积总误差E
            expect = self._normalize(sample[-1])
            self.total_error += 0.5 * (expect - result) ** 2
            
            # 更新迭代计数器（用于UI显示）
            self.current_iterations = epoch * len(self.training_dataset) + p
        
        # 步骤7：调整权值（批量更新，使用平均梯度）
        for neuron in total_deltas:
            total_deltas[neuron] /= len(self.training_dataset)
        self._adjust_synaptic_weights(total_deltas)
        
        # 步骤8：迭代次数计数器q增1（在主循环中处理）
    # ==========================================

    # ========== 修改：重写_iterate方法 ==========
    def _iterate(self):
        """重写原有的_iterate方法，使用_current_sample"""
        if self._current_sample is not None:
            result = self._feed_forward(self._current_sample[:-1])
            deltas = self._pass_backward(self._normalize(self._current_sample[-1]), result)
            self._adjust_synaptic_weights(deltas)
        else:
            # 回退到原有逻辑
            result = self._feed_forward(self.current_data[:-1])
            deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
            self._adjust_synaptic_weights(deltas)
    # ========================================

    # ========== 修改：根据Sigmoid类型初始化神经元 ==========
    def _initialize_neurons(self):
        """ Build the neuron network with selected activation function. """
        if self.sigmoid_type == 'bipolar':
            activation_func = bipolar_sigmoid
        else:
            activation_func = sigmoid
            
        self._neurons = tuple((Perceptron(activation_func),) * size
                              for size in list(self.network_shape) + [1])
    # ================================================

    def _feed_forward(self, data):
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    # ========== 修改：支持双极性Sigmoid的反向传播 ==========
    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron. """
        deltas = {}

        # 输出层误差计算
        output_error = expect - result
        if self.sigmoid_type == 'bipolar':
            # 双极性Sigmoid (tanh) 的导数：1 - tanh²(x)
            deltas[self._neurons[-1][0]] = output_error * (1 - result ** 2)
        else:
            # 单极性Sigmoid的导数：sigmoid(x) * (1 - sigmoid(x))
            deltas[self._neurons[-1][0]] = output_error * result * (1 - result)

        # 隐藏层误差反向传播
        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                error_sum = sum(deltas[n] * n.synaptic_weight[neuron_idx]
                               for n in self._neurons[layer_idx + 1])
                
                if self.sigmoid_type == 'bipolar':
                    deltas[neuron] = error_sum * (1 - neuron.result ** 2)
                else:
                    deltas[neuron] = error_sum * neuron.result * (1 - neuron.result)
        
        return deltas
    # ================================================

    def _adjust_synaptic_weights(self, deltas):
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    # ========== 修改：支持双极性输出的正确率计算 ==========
    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            
            if self.sigmoid_type == 'bipolar':
                predicted = 1 if result > 0 else -1
                actual = 1 if expect > 0 else -1
            else:
                predicted = 1 if result > 0.5 else 0
                actual = 1 if expect > 0.5 else 0
            
            if predicted == actual:
                correct_count += 1
        
        return correct_count / len(dataset) if len(dataset) > 0 else 0
    # ================================================

    # ========== 修改：支持双极性的输出归一化 ==========
    def _normalize(self, value):
        """ Normalize expected output based on sigmoid type. """
        if self.sigmoid_type == 'bipolar':
            unique_values = np.unique(self.group_types)
            if len(unique_values) == 2:
                return 1 if value == unique_values[1] else -1
            else:
                return (2 * (value - np.amin(self.group_types)) / 
                       (np.amax(self.group_types) - np.amin(self.group_types)) - 1)
        else:
            return ((value - np.amin(self.group_types)) / 
                   (np.amax(self.group_types) - np.amin(self.group_types)))
    # ================================================


def get_layer_results(layer, data):
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)
