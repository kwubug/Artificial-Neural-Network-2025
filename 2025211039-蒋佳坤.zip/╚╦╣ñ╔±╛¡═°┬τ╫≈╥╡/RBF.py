import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import os


def set_chinese_font():
    font_paths = [
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "/usr/share/fonts/truetype/arphic/ukai.ttc"
    ]
    for path in font_paths:
        if os.path.exists(path):
            plt.rcParams['font.sans-serif'] = [fm.FontProperties(fname=path).get_name()]
            plt.rcParams['axes.unicode_minus'] = False
            return
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans']  # fallback
    plt.rcParams['axes.unicode_minus'] = False

set_chinese_font()


def rbf(x, centers, s):
    """计算高斯RBF输出向量"""
    # x: (1,) 或 (n,1), centers: (m,1)
    return np.exp(-((x - centers.T)**2) / (2 * s**2))


p = np.arange(-1, 1.1, 0.1).reshape(-1, 1)
t = np.array([
    -0.9602, -0.5770, -0.0729, 0.3771, 0.6405,
     0.6600, 0.4609, 0.1336, -0.2013, -0.4344,
    -0.5000, -0.3939, -0.1647, 0.0988, 0.3072,
     0.3960, 0.3449, 0.1816, 0.0312, -0.2189, -0.3201
]).reshape(-1, 1)


num_centers = 8
centers = np.linspace(-1, 1, num_centers).reshape(-1, 1)
s = 0.3


G = rbf(p, centers, s)  # shape: (21, 8)


w = np.linalg.pinv(G) @ t


p_test = np.linspace(-1, 1, 200).reshape(-1, 1)
G_test = rbf(p_test, centers, s)
y_pred = G_test @ w


mse = np.mean((t - G @ w)**2)


plt.figure(figsize=(8,5))
plt.plot(p, t, 'ro', label='目标输出')
plt.plot(p_test, y_pred, 'b-', linewidth=2, label='RBF网络拟合输出')
plt.title('RBF 神经网络曲线拟合', fontsize=16, weight='bold')
plt.xlabel('输入 p', fontsize=13)
plt.ylabel('输出 y', fontsize=13)
plt.legend(fontsize=12)
plt.grid(True, linestyle='--', alpha=0.5)
plt.text(-0.9, 0.7, f'均方误差 MSE = {mse:.6f}', fontsize=12, color='darkgreen')
plt.tight_layout()
plt.show()

print("===== RBF 拟合结果 =====")
print(f"RBF 节点数: {num_centers}")
print(f"高斯宽度 σ: {s}")
print(f"均方误差 MSE = {mse:.6f}")
