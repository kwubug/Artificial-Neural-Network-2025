# -*- coding: utf-8 -*-
"""
Discrete Hopfield Network (asynchronous update) with plotting helpers.

新增：
- plot_pattern()           ：画单个图案
- plot_patterns_row()      ：并排画多个图案（比如 A/B/C）
- plot_recall_triptych()   ：并排画 Clean / Noisy / Recalled

运行：
    python test7_HOP.py
"""

from dataclasses import dataclass
from typing import Iterable, List, Optional, Tuple
import numpy as np
import matplotlib.pyplot as plt


# ========== helpers ==========
def bipolarize(x: np.ndarray) -> np.ndarray:
    """Convert any real / {0,1} array to bipolar {-1, +1} (tie: >=0 -> +1)."""
    y = np.where(x >= 0, 1, -1)
    y[y == 0] = 1
    return y.astype(int)


@dataclass
class RecallResult:
    final_state: np.ndarray
    energies: List[float]
    states: List[np.ndarray]
    updates: int
    converged: bool


class HopfieldNetwork:
    """
    Discrete Hopfield network with asynchronous updates.
    Energy: E(s) = -0.5 * s^T W s + theta^T s
    """
    def __init__(self, n: int, dtype=float):
        self.n = int(n)
        self.W = np.zeros((self.n, self.n), dtype=dtype)
        self.theta = np.zeros(self.n, dtype=dtype)

    def train_hebb(
        self,
        patterns: np.ndarray,
        remove_self_connections: bool = True,
        normalize: bool = True,
    ):
        """Hebbian learning for bipolar patterns (P, n)."""
        P, n = patterns.shape
        assert n == self.n, "Pattern length must equal network size n"
        X = bipolarize(patterns)
        self.W = (X.T @ X).astype(float)
        if remove_self_connections:
            np.fill_diagonal(self.W, 0.0)
        if normalize and P > 0:
            self.W /= P

    def energy(self, state: np.ndarray) -> float:
        s = bipolarize(state).astype(float).reshape(-1)
        return float(-0.5 * s @ (self.W @ s) + self.theta @ s)

    def is_fixed_point(self, state: np.ndarray) -> bool:
        s = bipolarize(state).astype(int)
        h = self.W @ s - self.theta
        new_s = np.where(h > 0, 1, np.where(h < 0, -1, s))
        return bool(np.array_equal(new_s, s))

    def recall_async(
        self,
        initial_state: np.ndarray,
        max_updates: int = 10000,
        update_order: Optional[Iterable[int]] = None,
        record_states: bool = True,
        stop_on_cycle: bool = True,
    ) -> RecallResult:
        """
        异步回忆（逐点更新），含修正后的 2-cycle 检测：
        仅当 “当前状态 == 前前一次” 且 “当前状态 != 前一次” 时判为 2-循环。
        """
        s = bipolarize(initial_state).astype(int).reshape(-1)
        energies: List[float] = [self.energy(s)]
        states: List[np.ndarray] = [s.copy()] if record_states else []
        n = self.n

        # 索引流
        if update_order is not None:
            order = list(update_order)
            assert len(order) > 0, "update_order must be non-empty"

            def idx_gen():
                i = 0
                while True:
                    yield order[i % len(order)]
                    i += 1

            idx_stream = idx_gen()
        else:
            rng = np.random.default_rng()

            def idx_gen():
                i = 0
                while i < max_updates:
                    yield int(rng.integers(0, n))
                    i += 1

            idx_stream = idx_gen()

        prev1: Optional[np.ndarray] = None  # 上一次
        prev2: Optional[np.ndarray] = None  # 上上次
        updates = 0
        converged = False

        for k in idx_stream:
            # 单点更新（tie：保持）
            h_k = self.W[k, :] @ s - self.theta[k]
            s_k_new = 1 if h_k > 0 else (-1 if h_k < 0 else s[k])
            if s_k_new != s[k]:
                s[k] = s_k_new

            updates += 1
            e = self.energy(s)
            energies.append(e)
            if record_states:
                states.append(s.copy())

            # 固定点
            if self.is_fixed_point(s):
                converged = True
                break

            # 2-循环检测（A -> B -> A -> ...）
            if stop_on_cycle and (prev2 is not None) and (prev1 is not None):
                if np.array_equal(s, prev2) and not np.array_equal(s, prev1):
                    break

            # 更新历史
            prev2 = prev1.copy() if prev1 is not None else None
            prev1 = s.copy()

            if updates >= max_updates:
                break

        return RecallResult(
            final_state=s.copy(),
            energies=energies,
            states=states,
            updates=updates,
            converged=converged,
        )


# ========== utilities ==========
def pattern_from_ascii_grid(grid: List[str]) -> np.ndarray:
    """
    Convert list[str] (e.g., '1'/'0' or '#'/space) into flat bipolar vector.
    '1' '#' '+' 'X' -> +1 ; '0' ' ' -> -1
    """
    arr = []
    for row in grid:
        for ch in row:
            if ch in ('1', '#', '+', 'X'):
                arr.append(1)
            elif ch in ('0', ' '):
                arr.append(-1)
            else:
                arr.append(-1)
    return np.array(arr, dtype=int)


def add_noise(state: np.ndarray, flip_prob: float, rng: Optional[np.random.Generator] = None) -> np.ndarray:
    """Flip each bit with probability flip_prob (bipolar)."""
    if rng is None:
        rng = np.random.default_rng()
    s = bipolarize(state).copy()
    flips = rng.random(s.shape) < flip_prob
    s[flips] *= -1
    return s


def pretty_print_pattern(state: np.ndarray, width: int) -> str:
    """ASCII visualize +1 -> '█', -1 -> '·'."""
    s = bipolarize(state).astype(int).reshape(-1)
    height = len(s) // width
    lines = []
    for i in range(height):
        row = s[i * width:(i + 1) * width]
        lines.append(''.join('█' if v > 0 else '·' for v in row))
    return '\n'.join(lines)


# ========== plotting helpers ==========
def _to_image(state: np.ndarray, width: int) -> np.ndarray:
    """
    将平铺的 {-1,+1} 状态转为 0/1 的 2D 图像，+1->1，-1->0。
    """
    s = bipolarize(state).reshape(-1)
    h = len(s) // width
    img = (s.reshape(h, width) + 1) / 2.0  # {-1,+1} -> {0,1}
    return img


def plot_pattern(state: np.ndarray, width: int, title: str = ""):
    """画单个图案。"""
    img = _to_image(state, width)
    plt.imshow(img, cmap="gray", interpolation="nearest")
    plt.xticks([]); plt.yticks([])
    if title:
        plt.title(title)


def plot_patterns_row(patterns: List[np.ndarray], width: int, titles: Optional[List[str]] = None, suptitle: Optional[str] = None):
    """把多张图案并排绘制在一行。"""
    m = len(patterns)
    plt.figure(figsize=(2.6 * m, 2.6))
    for i, p in enumerate(patterns, start=1):
        plt.subplot(1, m, i)
        title = titles[i-1] if (titles and i-1 < len(titles)) else f"P{i}"
        plot_pattern(p, width, title)
    if suptitle:
        plt.suptitle(suptitle)
    plt.tight_layout(rect=[0, 0, 1, 0.95] if suptitle else None)


def plot_recall_triptych(clean: np.ndarray, noisy: np.ndarray, recalled: np.ndarray, width: int, suptitle: Optional[str] = None):
    """并排画 Clean / Noisy / Recalled。"""
    plt.figure(figsize=(8, 2.8))
    plt.subplot(1, 3, 1); plot_pattern(clean, width, "Clean")
    plt.subplot(1, 3, 2); plot_pattern(noisy, width, "Noisy")
    plt.subplot(1, 3, 3); plot_pattern(recalled, width, "Recalled")
    if suptitle:
        plt.suptitle(suptitle)
    plt.tight_layout(rect=[0, 0, 1, 0.93] if suptitle else None)


# ========== demo ==========
def demo() -> Tuple[HopfieldNetwork, np.ndarray, RecallResult]:
    # 8x8 的三个图案
    A = [
        "01111110",
        "01000010",
        "01000010",
        "01111110",
        "01000010",
        "01000010",
        "01000010",
        "01000010",
    ]
    B = [
        "01111110",
        "01000010",
        "01000010",
        "01111110",
        "01000010",
        "01000010",
        "01000010",
        "01111110",
    ]
    C = [
        "01111110",
        "01000000",
        "01000000",
        "01000000",
        "01000000",
        "01000000",
        "01000000",
        "01111110",
    ]
    patterns = np.stack([pattern_from_ascii_grid(x) for x in (A, B, C)], axis=0)
    n = patterns.shape[1]

    net = HopfieldNetwork(n)
    net.train_hebb(patterns, remove_self_connections=True, normalize=True)

    # 选 C 作为目标，加噪
    target_idx = 2
    clean = patterns[target_idx]
    rng = np.random.default_rng(2025)          # 固定种子便于复现（可改/可删）
    noisy = add_noise(clean, flip_prob=0.25, rng=rng)

    # 异步回忆
    result = net.recall_async(noisy, max_updates=5000, record_states=True, stop_on_cycle=True)

    # 文字输出
    print("Network size:", n)
    print("Stored patterns:", patterns.shape[0])
    print("Converged:", result.converged, "in updates:", result.updates)
    print("Initial energy:", result.energies[0], "Final energy:", result.energies[-1])

    print("\nClean target (C):")
    print(pretty_print_pattern(clean, width=8))
    print("\nNoisy input:")
    print(pretty_print_pattern(noisy, width=8))
    print("\nRecalled state:")
    print(pretty_print_pattern(result.final_state, width=8))

    # ---- 图1：能量曲线 ----
    plt.figure()
    plt.plot(result.energies)
    plt.title("Hopfield Energy During Asynchronous Recall")
    plt.xlabel("Update step")
    plt.ylabel("Energy")
    plt.tight_layout()

    # ---- 图2：A/B/C 三个存储图案 ----
    plot_patterns_row([patterns[0], patterns[1], patterns[2]], width=8, titles=["A", "B", "C"], suptitle="Stored Patterns")

    # ---- 图3：Clean / Noisy / Recalled 并排 ----
    plot_recall_triptych(clean, noisy, result.final_state, width=8, suptitle="Recall (Clean / Noisy / Recalled)")

    # 展示全部图
    plt.show()

    return net, patterns, result


if __name__ == "__main__":
    demo()
