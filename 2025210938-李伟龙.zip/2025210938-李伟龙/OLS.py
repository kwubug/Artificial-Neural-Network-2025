import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib

# 强制matplotlib使用TkAgg后端（通常能更好地支持系统字体）
matplotlib.use('TkAgg')

# 简化字体配置，使用系统更可能存在的字体
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei", "sans-serif"]  # 仅保留Windows常见中文字体
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

# 1. 生成模拟数据
np.random.seed(42)
n = 50
x = np.linspace(0, 10, n)
true_slope = 2.5
true_intercept = 3.8
noise = np.random.normal(0, 1.5, n)
y = true_slope * x + true_intercept + noise

# 2. OLS解析解
X = np.vstack([x, np.ones(n)]).T
slope_ols, intercept_ols = np.linalg.lstsq(X, y, rcond=None)[0]


# 3. 改进的梯度下降（使用自适应学习率）
def gradient_descent(x, y, initial_lr=0.001, epochs=1000):
    m = len(y)
    slope = 0.0
    intercept = 0.0
    parameters = [(slope, intercept)]
    lr = initial_lr  # 初始学习率

    for i in range(epochs):
        y_pred = slope * x + intercept

        # 计算梯度
        slope_grad = (-2 / m) * np.sum(x * (y - y_pred))
        intercept_grad = (-2 / m) * np.sum(y - y_pred)

        # 每200轮衰减学习率（防止震荡）
        if i % 200 == 0 and i > 0:
            lr *= 0.5

        # 更新参数
        slope -= lr * slope_grad
        intercept -= lr * intercept_grad

        parameters.append((slope, intercept))

    return parameters


# 运行梯度下降
parameters = gradient_descent(x, y, initial_lr=0.002, epochs=1000)

# 4. 可视化
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle('OLS学习算法可视化', fontsize=16)

# 数据与拟合线
ax1.scatter(x, y, color='blue', label='样本数据')
line, = ax1.plot(x, np.zeros_like(x), color='red', label='拟合线')
true_line, = ax1.plot(x, true_slope * x + true_intercept, 'g--', label='真实模型')
ax1.set_xlabel('x')
ax1.set_ylabel('y')
ax1.set_title('拟合过程')
ax1.legend()
ax1.grid(True)

# 参数收敛曲线
slope_values = [p[0] for p in parameters]
intercept_values = [p[1] for p in parameters]
slope_line, = ax2.plot([], [], 'r-', label='斜率')
intercept_line, = ax2.plot([], [], 'b-', label='截距')
ax2.axhline(y=true_slope, color='r', linestyle='--', alpha=0.5, label='真实斜率')
ax2.axhline(y=true_intercept, color='b', linestyle='--', alpha=0.5, label='真实截距')
ax2.set_xlabel('迭代次数')
ax2.set_ylabel('参数值')
ax2.set_title('参数收敛')
ax2.legend()
ax2.grid(True)
ax2.set_xlim(0, len(parameters) - 1)
ax2.set_ylim(0, 6)  # 固定y范围，更清晰展示收敛


# 动画更新函数
def update(frame):
    slope, intercept = parameters[frame]
    line.set_ydata(slope * x + intercept)
    slope_line.set_data(range(frame + 1), slope_values[:frame + 1])
    intercept_line.set_data(range(frame + 1), intercept_values[:frame + 1])
    ax1.set_title(f'拟合过程 (迭代: {frame})\n斜率: {slope:.4f}, 截距: {intercept:.4f}')
    return line, slope_line, intercept_line


# 创建动画（每10帧更新一次，提高速度）
ani = FuncAnimation(fig, update, frames=range(0, len(parameters), 10),
                    interval=80, blit=True)

# 输出结果对比
print(f"OLS解析解 - 斜率: {slope_ols:.4f}, 截距: {intercept_ols:.4f}")
print(f"梯度下降结果 - 斜率: {parameters[-1][0]:.4f}, 截距: {parameters[-1][1]:.4f}")
print(f"真实参数     - 斜率: {true_slope:.4f}, 截距: {true_intercept:.4f}")

plt.tight_layout()
plt.show()