import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# 定义一个3神经元的Boltzmann机器
class BoltzmannMachine:
    def __init__(self, N):
        self.N = N  # 神经元数量
        self.state = np.random.choice([1, -1], size=N)  # 随机初始化状态
        self.weights = np.random.randn(N, N)  # 随机初始化权重
        np.fill_diagonal(self.weights, 0)  # 权重矩阵对角线为0，即神经元不与自己连接
        self.bias = np.zeros(N)  # 偏置初始化为0
    
    def energy(self):
        """
        计算当前状态的能量
        """
        interaction_term = -np.sum(np.dot(self.state, self.weights) * self.state)
        bias_term = -np.sum(self.bias * self.state)
        return interaction_term + bias_term
    
    def sigmoid(self, x):
        """
        Sigmoid 激活函数
        """
        return 1 / (1 + np.exp(-x))
    
    def update(self):
        """
        异步更新神经网络（每次随机选择一个神经元更新）
        """
        i = np.random.randint(self.N)  # 随机选择一个神经元
        net_input = np.dot(self.weights[i], self.state) + self.bias[i]  # 计算净输入
        p = self.sigmoid(net_input)  # 计算激活概率
        self.state[i] = 1 if np.random.rand() < p else -1  # 随机决定是否更新状态
    
    def run(self, max_iter=1000, threshold=0.01):
        """
        运行网络直到收敛（达到热平衡）
        :param max_iter: 最大迭代次数
        :param threshold: 状态变化阈值
        """
        energy_history = []
        for _ in range(max_iter):
            old_state = self.state.copy()
            self.update()  # 异步更新
            energy_history.append(self.energy())
            
            # 检查网络是否达到热平衡（状态不再变化）
            if np.all(self.state == old_state):
                break
            
        return energy_history

# 初始化Boltzmann机器并运行
N = 3  # 网络中神经元的数量
bm = BoltzmannMachine(N)

# 运行Boltzmann机器，直到达到热平衡
energy_history = bm.run(max_iter=1000)

# 可视化：展示能量变化
plt.figure(figsize=(8, 6))
plt.plot(energy_history, label="Energy")
plt.xlabel("Iterations", fontsize=14)
plt.ylabel("Energy", fontsize=14)
plt.title("Energy vs Iterations in Boltzmann Machine", fontsize=16)
plt.grid(True)
plt.legend()
plt.show()

# 输出最终的热平衡状态
print(f"Final state (attractor): {bm.state}")
