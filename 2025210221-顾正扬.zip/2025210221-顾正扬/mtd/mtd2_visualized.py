import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# 定义函数 F(x)
def F1(x1, x2):
    return (x2 - x1) ** 4 + 8 * x1 * x2 - x1 + x2 + 3


# 创建 x1 和 x2 的网格
x1 = np.linspace(-2, 2, 400)
x2 = np.linspace(-2, 2, 400)
X1, X2 = np.meshgrid(x1, x2)

Z = F1(X1, X2)

# 绘制等高线图
plt.figure(figsize=(8, 6))
contour = plt.contour(X1, X2, Z, levels=250, cmap='viridis')
plt.clabel(contour, inline=True, fontsize=8)
plt.title('Contour plot of F(x) = (x2 - x1) ** 4 + 8 * x1 * x2 - x1 + x2 + 3')
plt.xlabel('x1')
plt.ylabel('x2')
plt.colorbar(contour)
plt.grid(True)

'''m2_NEWTON，学习3次'''
f1 = pd.read_excel('m2_F2_[0.75, 0.75].xlsx')
plt.plot(f1['x1'], f1['x2'], label='[0.75, 0.75]', marker='.', linestyle='-', color='red')
f2 = pd.read_excel('m2_F2_[1.5, 0].xlsx')
plt.plot(f2['x1'], f2['x2'], label='[1.5, 0]', marker='.', linestyle='-', color='green')
f3 = pd.read_excel('m2_F2_[1.15, 0.75].xlsx')
plt.plot(f3['x1'], f3['x2'], label='[1.15, 0.75]', marker='.', linestyle='-', color='blue')
f4 = pd.read_excel('m2_F2_[-1.5, 0].xlsx')
plt.plot(f4['x1'], f4['x2'], label='[-1.5, 0]', marker='.', linestyle='-', color='purple')

# 添加图例
plt.legend()
plt.show()
