#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试matplotlib中文字体显示
"""

import matplotlib.pyplot as plt
import matplotlib
import numpy as np

# 设置中文字体
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False

# 创建测试图形
fig, ax = plt.subplots(figsize=(8, 6))

# 测试数据
x = np.linspace(-2, 2, 100)
y = x**2

# 绘制图形
ax.plot(x, y, 'b-', linewidth=2, label='测试函数')
ax.set_xlabel('X轴', fontsize=12)
ax.set_ylabel('Y轴', fontsize=12)
ax.set_title('中文字体测试', fontsize=14)
ax.legend()
ax.grid(True, alpha=0.3)

# 保存图片
plt.tight_layout()
plt.savefig('font_test.png', dpi=150, bbox_inches='tight')
plt.show()

print("字体测试完成，请检查font_test.png文件")
