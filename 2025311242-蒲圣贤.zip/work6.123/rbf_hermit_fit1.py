#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RBF approximation for the Hermit-like target with two training strategies:
(1) Clustering + pseudoinverse
(2) Gradient descent on centers, spreads and weights

The script generates data, trains both models, prints metrics,
and draws three figures: (a) clustering fit, (b) GD fit, (c) GD loss.
"""

import numpy as np
import matplotlib.pyplot as plt


def F(x: np.ndarray) -> np.ndarray:
    """Ground-truth function from the assignment."""
    return 1.1 * (1 - x + 2 * x**2) * np.exp(-(x**2) / 2)


def kmeans_1d(data: np.ndarray, centers: np.ndarray, iters: int = 50) -> np.ndarray:
    """Simple 1D k-means used to pick RBF centers."""
    centers = centers.copy()
    for _ in range(iters):
        dists = np.abs(data[:, None] - centers[None, :])
        labels = np.argmin(dists, axis=1)
        for j in range(len(centers)):
            pts = data[labels == j]
            if len(pts) > 0:
                centers[j] = pts.mean()
    return centers


def rbf_matrix(xv: np.ndarray, C: np.ndarray, S: np.ndarray) -> np.ndarray:
    """Construct Gaussian RBF design matrix Φ for inputs xv and centers C with spreads S."""
    diff = xv[:, None] - C[None, :]
    return np.exp(-(diff**2) / (2 * (S[None, :] ** 2)))


def main(seed: int = 42):
    rng = np.random.default_rng(seed)

    # -----------------------------
    # 0) Data
    # -----------------------------
    P = 100
    x = rng.uniform(-4, 4, size=P)
    x = np.sort(x)
    noise = rng.normal(0.0, 0.1, size=P)
    y = F(x) + noise

    x_grid = np.linspace(-4, 4, 400)
    y_true_grid = F(x_grid)

    # -----------------------------
    # 1) Clustering + pseudoinverse
    # -----------------------------
    M = 10
    lam = 1.0  # overlap coefficient

    # initialization: first M samples
    centers_init = x[:M].copy()
    centers_km = kmeans_1d(x, centers_init, iters=50)

    # spreads: nearest-center distance / sqrt(2), scaled by lambda
    pairwise = np.abs(centers_km[:, None] - centers_km[None, :]) + np.eye(M) * 1e9
    nearest = pairwise.min(axis=1)
    sigma_km = lam * nearest / np.sqrt(2)
    sigma_km = np.maximum(sigma_km, 0.1)  # safety floor

    Phi = rbf_matrix(x, centers_km, sigma_km)
    Phi_aug = np.hstack([Phi, np.ones((P, 1))])  # add bias
    w_pinv = np.linalg.pinv(Phi_aug) @ y
    w_km, b_km = w_pinv[:-1], w_pinv[-1]

    # predictions
    Phi_g = rbf_matrix(x_grid, centers_km, sigma_km)
    y_km_grid = Phi_g @ w_km + b_km
    mse_km = np.mean((Phi @ w_km + b_km - y) ** 2)

    # -----------------------------
    # 2) Gradient Descent RBF
    # -----------------------------
    eta = 1e-3
    M_gd = 10
    w = rng.uniform(-0.1, 0.1, size=M_gd)
    b = rng.uniform(-0.1, 0.1)
    c = rng.uniform(-4.0, 4.0, size=M_gd)
    s = rng.uniform(0.1, 0.3, size=M_gd)
    max_iters = 5000
    target_sse = 0.9  # stop when SSE goes below this value

    losses = []
    for _ in range(max_iters):
        Phi_gd = rbf_matrix(x, c, s)  # (P,M)
        y_hat = Phi_gd @ w + b
        err = y_hat - y
        sse = 0.5 * np.sum(err**2)
        losses.append(sse)
        if sse < target_sse:
            break

        # gradients
        grad_w = Phi_gd.T @ err
        grad_b = np.sum(err)
        diff = x[:, None] - c[None, :]
        grad_c = np.sum(err[:, None] * (w[None, :] * Phi_gd) * (diff / (s[None, :] ** 2)), axis=0)
        grad_s = np.sum(err[:, None] * (w[None, :] * Phi_gd) * ((diff**2) / (s[None, :] ** 3)), axis=0)

        # parameter updates
        w -= eta * grad_w
        b -= eta * grad_b
        c -= eta * grad_c
        s -= eta * grad_s
        s = np.clip(s, 1e-3, 5.0)  # keep spreads positive

    # final predictions on grid
    Phi_gd_grid = rbf_matrix(x_grid, c, s)
    y_gd_grid = Phi_gd_grid @ w + b
    mse_gd = np.mean((rbf_matrix(x, c, s) @ w + b - y) ** 2)

    # -----------------------------
    # Print metrics
    # -----------------------------
    print("Clustering + pseudoinverse:")
    print(f"  MSE = {mse_km:.4f}")
    print("  centers (first 5):", centers_km[:5])
    print("  spreads (first 5):", sigma_km[:5])
    print("\nGradient Descent RBF:")
    print(f"  iterations = {len(losses)}  final SSE = {losses[-1]:.4f}  MSE = {mse_gd:.4f}")

    # -----------------------------
    # Visualization
    # -----------------------------
    # (a) Clustering fit
    plt.figure(figsize=(8, 5))
    plt.scatter(x, y, label="Train samples")
    plt.plot(x_grid, y_true_grid, label="True F(x)")
    plt.plot(x_grid, y_km_grid, label="RBF (cluster+pinv)")
    plt.title(f"RBF via Clustering + Pseudoinverse (M={len(centers_km)}), MSE={mse_km:.4f}")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.grid(True)
    plt.show()

    # (b) Gradient descent fit
    plt.figure(figsize=(8, 5))
    plt.scatter(x, y, label="Train samples")
    plt.plot(x_grid, y_true_grid, label="True F(x)")
    plt.plot(x_grid, y_gd_grid, label="RBF (GD)")
    plt.title(f"RBF via Gradient Descent (M={M_gd}), MSE={mse_gd:.4f}, iters={len(losses)}")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.grid(True)
    plt.show()

    # (c) GD training loss curve
    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(1, len(losses) + 1), losses)
    plt.title("Gradient Descent Training Loss (SSE)")
    plt.xlabel("Iteration")
    plt.ylabel("SSE")
    plt.grid(True)
    plt.show()


if __name__ == "__main__":
    main()
