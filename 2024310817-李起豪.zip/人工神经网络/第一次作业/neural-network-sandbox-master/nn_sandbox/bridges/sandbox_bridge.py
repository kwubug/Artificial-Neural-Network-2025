from typing import Optional

import PyQt5.QtCore

from . import Bridge
from sandboxes.bm_sandbox_gui import BMGuiWindow
from sandboxes.hopfield_sandbox_gui import HopfieldSandboxWindow
from sandboxes.tsp_sandbox_gui import TSPSandboxWindow


class SandboxBridge(Bridge):
    """为QML提供打开各沙箱可视化窗口的接口。"""

    def __init__(self) -> None:
        super().__init__()
        self._bm_window: Optional[BMGuiWindow] = None
        self._hopfield_window: Optional[HopfieldSandboxWindow] = None
        self._tsp_window: Optional[TSPSandboxWindow] = None

    @staticmethod
    def _show_window(window) -> None:
        window.show()
        window.raise_()
        window.activateWindow()

    @PyQt5.QtCore.pyqtSlot()
    def open_bm(self) -> None:
        if self._bm_window is None:
            self._bm_window = BMGuiWindow()
        self._show_window(self._bm_window)

    @PyQt5.QtCore.pyqtSlot()
    def open_hopfield(self) -> None:
        if self._hopfield_window is None:
            self._hopfield_window = HopfieldSandboxWindow()
        self._show_window(self._hopfield_window)

    @PyQt5.QtCore.pyqtSlot()
    def open_tsp(self) -> None:
        if self._tsp_window is None:
            self._tsp_window = TSPSandboxWindow()
        self._show_window(self._tsp_window)


