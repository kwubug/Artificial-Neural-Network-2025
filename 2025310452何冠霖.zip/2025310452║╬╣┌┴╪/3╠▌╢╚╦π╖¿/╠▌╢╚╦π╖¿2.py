import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm

# 使用内存效率更高的Agg后端（非交互模式）
plt.switch_backend('Agg')


def func(x):
    """目标函数 F(x) = x₁² + 25x₂²"""
    return x[0] ** 2 + 25 * x[1] ** 2


def grad(x):
    """梯度 ∇F = [2x₁, 50x₂]"""
    return np.array([2 * x[0], 50 * x[1]], dtype=np.float32)  # 使用32位浮点数


def hessian(x):
    """海森矩阵 H = [[2, 0], [0, 50]]"""
    return np.array([[2.0, 0.0], [0.0, 50.0]], dtype=np.float32)  # 使用32位浮点数


def steepest_descent(x0, max_iter=5):
    x = x0.copy().astype(np.float32)  # 使用32位浮点数
    history = [x.copy()]
    for _ in range(max_iter):
        g = grad(x)
        H = hessian(x)
        alpha = np.dot(g, g) / np.dot(g, H @ g)
        x = x - alpha * g
        history.append(x.copy())
    return np.array(history)


def newton_method(x0, max_iter=5):
    x = x0.copy().astype(np.float32)
    history = [x.copy()]
    H = hessian(x0)
    H_inv = np.linalg.inv(H)
    for _ in range(max_iter):
        g = grad(x)
        x = x - H_inv @ g
        history.append(x.copy())
    return np.array(history)


def conjugate_gradient(x0, max_iter=5):
    x = x0.copy().astype(np.float32)
    history = [x.copy()]
    A = hessian(x0)
    g = grad(x)
    d = -g

    for _ in range(max_iter):
        alpha = np.dot(g, g) / np.dot(d, A @ d)
        x = x + alpha * d
        history.append(x.copy())
        g_new = grad(x)
        beta = np.dot(g_new, g_new) / np.dot(g, g)
        d = -g_new + beta * d
        g = g_new.copy()
    return np.array(history)


# 主程序
def main():
    # 初始点（使用32位浮点数）
    x0 = np.array([0.5, 0.5], dtype=np.float32)

    # 运行三种算法并立即释放临时变量
    sd_history = steepest_descent(x0)
    nm_history = newton_method(x0)
    cg_history = conjugate_gradient(x0)

    # 生成最小化的等高线网格
    x1 = np.linspace(-0.6, 0.6, 20, dtype=np.float32)  # 进一步减少到20×20网格
    x2 = np.linspace(-0.6, 0.6, 20, dtype=np.float32)
    X1, X2 = np.meshgrid(x1, x2)
    Z = func([X1, X2])

    # 创建画布（使用最小必要参数）
    plt.figure(figsize=(10, 8), dpi=90)  # 降低分辨率

    # 子图1：最速下降法
    plt.subplot(2, 2, 1)
    plt.contour(X1, X2, Z, levels=5, cmap=cm.viridis)  # 仅5层等高线
    plt.plot(sd_history[:, 0], sd_history[:, 1], 'r-', linewidth=1)
    for i, (x, y) in enumerate(sd_history):
        plt.plot(x, y, 'ro', markersize=5)
        plt.text(x + 0.02, y + 0.02, f'x{i}', fontsize=8)
    plt.plot(0, 0, 'go', label='Optimal', markersize=6)
    plt.title('Steepest Descent')
    plt.xlabel('$x_1$')
    plt.ylabel('$x_2$')
    plt.legend(fontsize=8)

    # 子图2：牛顿法
    plt.subplot(2, 2, 2)
    plt.contour(X1, X2, Z, levels=5, cmap=cm.viridis)
    plt.plot(nm_history[:, 0], nm_history[:, 1], 'b-', linewidth=1)
    for i, (x, y) in enumerate(nm_history):
        plt.plot(x, y, 'bo', markersize=5)
        plt.text(x + 0.02, y + 0.02, f'x{i}', fontsize=8)
    plt.plot(0, 0, 'go', label='Optimal', markersize=6)
    plt.title('Newton Method')
    plt.xlabel('$x_1$')
    plt.ylabel('$x_2$')
    plt.legend(fontsize=8)

    # 子图3：共轭梯度法
    plt.subplot(2, 2, 3)
    plt.contour(X1, X2, Z, levels=5, cmap=cm.viridis)
    plt.plot(cg_history[:, 0], cg_history[:, 1], 'g-', linewidth=1)
    for i, (x, y) in enumerate(cg_history):
        plt.plot(x, y, 'go', markersize=5)
        plt.text(x + 0.02, y + 0.02, f'x{i}', fontsize=8)
    plt.plot(0, 0, 'ro', label='Optimal', markersize=6)
    plt.title('Conjugate Gradient')
    plt.xlabel('$x_1$')
    plt.ylabel('$x_2$')
    plt.legend(fontsize=8)

    # 子图4：三种方法对比
    plt.subplot(2, 2, 4)
    plt.contour(X1, X2, Z, levels=5, cmap=cm.viridis)
    # 最速下降法
    plt.plot(sd_history[:, 0], sd_history[:, 1], 'r-', linewidth=1, label='Steepest')
    plt.scatter(sd_history[:, 0], sd_history[:, 1], c='r', s=20, alpha=0.8)
    # 牛顿法
    plt.plot(nm_history[:, 0], nm_history[:, 1], 'b-', linewidth=1, label='Newton')
    plt.scatter(nm_history[:, 0], nm_history[:, 1], c='b', s=20, alpha=0.8)
    # 共轭梯度法
    plt.plot(cg_history[:, 0], cg_history[:, 1], 'g-', linewidth=1, label='Conjugate')
    plt.scatter(cg_history[:, 0], cg_history[:, 1], c='g', s=20, alpha=0.8)

    plt.plot(x0[0], x0[1], 'ko', label='Initial', markersize=6)
    plt.plot(0, 0, 'mo', label='Optimal', markersize=6)
    plt.title('Comparison')
    plt.xlabel('$x_1$')
    plt.ylabel('$x_2$')
    plt.legend(fontsize=7)

    plt.tight_layout()
    plt.savefig('optimization_comparison.png', bbox_inches='tight')  # 保存为图片而非交互显示
    plt.close('all')


if __name__ == "__main__":
    main()

    import gc

    gc.collect()
