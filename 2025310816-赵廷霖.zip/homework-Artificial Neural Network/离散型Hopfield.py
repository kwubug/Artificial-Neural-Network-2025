import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
class DiscreteHopfieldNetwork:
    def __init__(self, n_neurons):
        """
        初始化离散型Hopfield网络

        参数:
        n_neurons: 神经元数量
        """
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.energy_history = []

    def train(self, patterns):
        """
        训练网络，存储模式

        参数:
        patterns: 要存储的模式列表，每个模式是长度为n_neurons的向量，元素为±1
        """
        for pattern in patterns:
            # 确保模式是numpy数组且元素为±1
            pattern = np.array(pattern).flatten()
            pattern = np.where(pattern > 0, 1, -1)

            # Hebbian学习规则
            self.weights += np.outer(pattern, pattern)

        # 对角线元素设为0（无自连接）
        np.fill_diagonal(self.weights, 0)

        # 归一化权重
        self.weights = self.weights / len(patterns)

    def energy(self, state):
        """
        计算网络能量

        参数:
        state: 网络状态向量

        返回:
        能量值
        """
        return -0.5 * np.dot(state, np.dot(self.weights, state))

    def asynchronous_update(self, state, max_iterations=100):
        """
        异步更新网络状态

        参数:
        state: 初始状态
        max_iterations: 最大迭代次数

        返回:
        final_state: 最终状态
        energy_history: 能量历史
        """
        current_state = state.copy()
        energy_history = []

        for iteration in range(max_iterations):
            # 记录当前能量
            current_energy = self.energy(current_state)
            energy_history.append(current_energy)

            # 随机选择神经元更新
            neuron_order = np.random.permutation(self.n_neurons)

            for neuron in neuron_order:
                # 计算神经元的净输入
                net_input = np.dot(self.weights[neuron], current_state)

                # 更新神经元状态
                if net_input > 0:
                    current_state[neuron] = 1
                elif net_input < 0:
                    current_state[neuron] = -1
                # net_input == 0 时状态不变

            # 检查是否收敛（状态不再变化）
            new_energy = self.energy(current_state)
            if iteration > 0 and abs(new_energy - current_energy) < 1e-10:
                print(f"在 {iteration + 1} 次迭代后收敛")
                break

        return current_state, energy_history

    def find_attractors(self, test_patterns, max_iterations=100):
        """
        寻找吸引子

        参数:
        test_patterns: 测试模式列表
        max_iterations: 最大迭代次数

        返回:
        attractors: 吸引子字典 {吸引子状态: 收敛到该吸引子的模式数量}
        """
        attractors = {}

        for i, pattern in enumerate(test_patterns):
            initial_state = np.array(pattern).flatten()
            initial_state = np.where(initial_state > 0, 1, -1)

            final_state, energy_history = self.asynchronous_update(
                initial_state, max_iterations
            )

            # 将最终状态转换为可哈希的元组
            final_state_tuple = tuple(final_state)

            if final_state_tuple in attractors:
                attractors[final_state_tuple]["count"] += 1
                attractors[final_state_tuple]["initial_patterns"].append(i)
            else:
                attractors[final_state_tuple] = {
                    "state": final_state,
                    "count": 1,
                    "energy": self.energy(final_state),
                    "initial_patterns": [i]
                }

        return attractors

    def visualize_patterns(self, patterns, title="Patterns"):
        """
        可视化模式（适用于二维模式）
        """
        n_patterns = len(patterns)
        fig, axes = plt.subplots(1, n_patterns, figsize=(3 * n_patterns, 3))

        if n_patterns == 1:
            axes = [axes]

        for i, (ax, pattern) in enumerate(zip(axes, patterns)):
            pattern_array = np.array(pattern).reshape(int(np.sqrt(self.n_neurons)), -1)
            ax.imshow(pattern_array, cmap='binary', vmin=-1, vmax=1)
            ax.set_title(f'Pattern {i + 1}')
            ax.axis('off')

        plt.suptitle(title)
        plt.tight_layout()
        plt.show()


# 示例使用
def example_usage():
    # 定义一些模式（这里使用简单的4x4模式）
    patterns = [
        # 模式1: 十字形
        [-1, 1, 1, -1,
         1, 1, 1, 1,
         1, 1, 1, 1,
         -1, 1, 1, -1],

        # 模式2: X形
        [1, -1, -1, 1,
         -1, 1, 1, -1,
         -1, 1, 1, -1,
         1, -1, -1, 1],

        # 模式3: 方形
        [1, 1, 1, 1,
         1, -1, -1, 1,
         1, -1, -1, 1,
         1, 1, 1, 1]
    ]

    # 创建网络
    n_neurons = 16
    network = DiscreteHopfieldNetwork(n_neurons)

    # 训练网络
    network.train(patterns)

    print("训练完成！")
    print("权重矩阵形状:", network.weights.shape)

    # 可视化训练模式
    network.visualize_patterns(patterns, "训练模式")

    # 创建一些测试模式（包含噪声的模式）
    test_patterns = []

    # 添加原始模式
    test_patterns.extend(patterns)

    # 添加有噪声的模式
    for pattern in patterns:
        noisy_pattern = pattern.copy()
        # 随机翻转一些比特
        flip_indices = np.random.choice(n_neurons, size=4, replace=False)
        for idx in flip_indices:
            noisy_pattern[idx] *= -1
        test_patterns.append(noisy_pattern)

    # 寻找吸引子
    attractors = network.find_attractors(test_patterns)

    print(f"\n找到 {len(attractors)} 个吸引子:")
    print("=" * 50)

    for i, (state_key, attractor_info) in enumerate(attractors.items()):
        print(f"吸引子 {i + 1}:")
        print(f"  状态: {attractor_info['state']}")
        print(f"  能量: {attractor_info['energy']:.4f}")
        print(f"  收敛到此吸引子的模式数量: {attractor_info['count']}")
        print(f"  初始模式索引: {attractor_info['initial_patterns']}")
        print("-" * 30)

    # 可视化吸引子
    attractor_states = [info["state"] for info in attractors.values()]
    network.visualize_patterns(attractor_states, "吸引子状态")

    # 测试能量收敛
    print("\n测试能量收敛:")
    test_pattern = test_patterns[3]  # 选择一个有噪声的模式
    initial_state = np.array(test_pattern)
    initial_state = np.where(initial_state > 0, 1, -1)

    final_state, energy_history = network.asynchronous_update(initial_state)

    plt.figure(figsize=(10, 4))

    plt.subplot(1, 2, 1)
    plt.plot(energy_history)
    plt.xlabel('迭代次数')
    plt.ylabel('能量')
    plt.title('能量收敛过程')
    plt.grid(True)

    plt.subplot(1, 2, 2)
    initial_display = np.array(initial_state).reshape(4, 4)
    final_display = np.array(final_state).reshape(4, 4)

    plt.imshow(initial_display, cmap='binary', vmin=-1, vmax=1)
    plt.title('初始状态')
    plt.axis('off')

    plt.tight_layout()
    plt.show()

    print(f"初始能量: {network.energy(initial_state):.4f}")
    print(f"最终能量: {network.energy(final_state):.4f}")


# 运行示例
if __name__ == "__main__":
    example_usage()