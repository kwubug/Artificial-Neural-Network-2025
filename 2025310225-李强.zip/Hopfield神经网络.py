import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                             QWidget, QPushButton, QLabel, QGridLayout, QSpinBox,
                             QGroupBox)
from PyQt5.QtCore import QTimer


class HopfieldNetwork:
    def __init__(self, n):
        self.n = n  # number of neurons (e.g., 10x10=100)
        self.weights = np.zeros((n, n))

    def train(self, patterns):
        """Hebbian learning for storing patterns."""
        n = self.n
        self.weights = np.zeros((n, n))
        for p in patterns:
            p = np.array(p).reshape(n, 1)
            self.weights += np.dot(p, p.T)
        np.fill_diagonal(self.weights, 0)  # no self-connections
        self.weights /= n  # optional scaling
        # Make weights symmetric (though Hebbian should already give symmetric)
        self.weights = (self.weights + self.weights.T) / 2

    def energy(self, state):
        s = np.array(state).reshape(-1, 1)
        return -0.5 * np.dot(s.T, np.dot(self.weights, s))[0, 0]

    def async_update(self, state, max_iter=100):
        """Perform async updates. Return sequence of states and energies."""
        s = np.array(state, dtype=int).copy()
        n = self.n
        states = [s.copy()]
        energies = [self.energy(s)]
        for _ in range(max_iter):
            i = np.random.randint(0, n)  # random neuron
            h = np.dot(self.weights[i, :], s)
            s_new = 1 if h >= 0 else -1
            if s_new != s[i]:
                s[i] = s_new
            states.append(s.copy())
            energies.append(self.energy(s))
            # Optional: stop if no change or converged
        return np.array(states), np.array(energies)


class HopfieldGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("离散 Hopfield 神经网络可视化")
        self.setGeometry(100, 100, 1400, 800)

        # Hopfield Network Parameters
        self.n = 100  # 10x10 grid
        self.hopfield = HopfieldNetwork(self.n)
        self.pattern_size = 10
        self.train_patterns = []

        # Main layout
        main_widget = QWidget()
        main_layout = QHBoxLayout(main_widget)

        # Left: Controls + Visualization
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)

        # Control Panel
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)

        self.train_btn = QPushButton("训练网络（内置图案）")
        self.train_btn.clicked.connect(self.train_builtin_patterns)

        self.test_label = QLabel("输入测试图案（带噪声）:")
        self.noise_slider = QSpinBox()
        self.noise_slider.setRange(0, 100)
        self.noise_slider.setValue(30)
        self.noise_slider.setPrefix("噪声比例(%): ")

        self.recall_btn = QPushButton("开始回忆（异步更新）")
        self.recall_btn.clicked.connect(self.start_recall)

        self.stop_btn = QPushButton("停止")
        self.stop_btn.clicked.connect(self.stop_recall)
        self.stop_btn.setEnabled(False)

        control_layout.addWidget(self.train_btn)
        control_layout.addWidget(self.test_label)
        control_layout.addWidget(self.noise_slider)
        control_layout.addWidget(self.recall_btn)
        control_layout.addWidget(self.stop_btn)

        # State Visualization
        self.state_canvas = self.create_image_canvas(title="当前状态 (1=白, -1=黑)")
        # Energy Curve
        self.energy_canvas = self.create_plot_canvas(title="能量变化", ylabel="能量")

        left_layout.addWidget(control_group)
        left_layout.addWidget(self.state_canvas)
        left_layout.addWidget(self.energy_canvas)

        # Right: Patterns Preview
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_group = QGroupBox("训练图案预览 (1=白, -1=黑)")
        right_group_layout = QVBoxLayout(right_group)

        self.pattern_canvas = self.create_image_canvas_grid(title="训练图案 (点击训练按钮加载)", cols=5)
        right_group_layout.addWidget(self.pattern_canvas)
        right_layout.addWidget(right_group)

        # Assemble main layout
        main_layout.addWidget(left_panel, 2)
        main_layout.addWidget(right_panel, 1)

        self.setCentralWidget(main_widget)

        # Internal
        self.current_state = None
        self.states = []
        self.energies = []
        self.timer = QTimer()
        self.timer.timeout.connect(self.step_recall)
        self.is_recalling = False

    def create_image_canvas(self, title="State"):
        fig = Figure(figsize=(4, 4))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)
        ax.set_title(title)
        ax.axis('off')
        canvas.draw()
        self.state_ax = ax
        self.state_fig = fig
        return canvas

    def create_image_canvas_grid(self, title="Patterns", cols=5):
        fig = Figure(figsize=(10, 2))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)
        ax.set_title(title)
        ax.axis('off')
        canvas.draw()
        self.pattern_ax = ax
        self.pattern_fig = fig
        return canvas

    def create_plot_canvas(self, title="Energy", ylabel="E"):
        fig = Figure(figsize=(6, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)
        ax.set_title(title)
        ax.set_xlabel("迭代次数")
        ax.set_ylabel(ylabel)
        ax.grid(True)
        canvas.draw()
        self.energy_ax = ax
        self.energy_fig = fig
        return canvas

    def pattern_to_state(self, pattern):
        """Convert 2D pattern (10x10) to 1D state vector (-1/+1)."""
        arr = np.array(pattern)
        arr = (arr > 0.5).astype(int)  # assume 0=black, 1=white
        arr = 2 * arr - 1  # 1=white, -1=black
        return arr.reshape(-1)

    def state_to_pattern(self, state):
        """Convert 1D state (-1/+1) to 2D array (10x10) for display."""
        arr = state.reshape(self.pattern_size, self.pattern_size)
        arr = (arr + 1) // 2  # -1=>0 (black), 1=>1 (white)
        return arr

    def generate_builtin_patterns(self):
        """Generate simple 10x10 patterns: cross, square, diagonal, etc."""
        patterns = []

        # Pattern 1: Cross
        p1 = np.zeros((self.pattern_size, self.pattern_size))
        p1[4:6, :] = 1  # horizontal
        p1[:, 4:6] = 1  # vertical
        patterns.append(p1)

        # Pattern 2: Square
        p2 = np.zeros((self.pattern_size, self.pattern_size))
        p2[3:7, 3:7] = 1
        patterns.append(p2)

        # Pattern 3: Diagonal
        p3 = np.zeros((self.pattern_size, self.pattern_size))
        np.fill_diagonal(p3, 1)
        patterns.append(p3)

        # Pattern 4: Reverse diagonal
        p4 = np.zeros((self.pattern_size, self.pattern_size))
        np.fill_diagonal(np.fliplr(p4), 1)
        patterns.append(p4)

        # Pattern 5: Checkerboard small
        p5 = np.zeros((self.pattern_size, self.pattern_size))
        p5[2:4, 2:4] = 1
        patterns.append(p5)

        return patterns

    def train_builtin_patterns(self):
        self.train_patterns = self.generate_builtin_patterns()
        states = [self.pattern_to_state(p) for p in self.train_patterns]
        self.hopfield.train(states)
        self.display_patterns(self.train_patterns)
        print(f"训练了 {len(states)} 个模式.")

    def display_patterns(self, patterns):
        self.pattern_ax.clear()
        n = len(patterns)
        cols = min(5, n)
        rows = (n + cols - 1) // cols
        self.pattern_ax.set_xticks([])
        self.pattern_ax.set_yticks([])
        for i, p in enumerate(patterns):
            ax = self.pattern_fig.add_axes([i % cols * 0.18, rows - 1 - i // cols * 0.18, 0.17, 0.17])
            ax.imshow(p, cmap='gray', vmin=0, vmax=1)
            ax.axis('off')
        self.pattern_canvas.draw()

    def add_noise(self, state, noise_level):
        noisy = state.copy()
        flip_count = int(noise_level / 100 * self.n)
        idx = np.random.choice(self.n, flip_count, replace=False)
        noisy[idx] *= -1
        return noisy

    def start_recall(self):
        if not self.train_patterns:
            print("请先训练网络！")
            return

        # Start with a stored pattern + noise
        base_idx = 0  # you can let user choose
        base_state = self.pattern_to_state(self.train_patterns[base_idx])
        noise_level = self.noise_slider.value()
        noisy_state = self.add_noise(base_state, noise_level)

        self.current_state = noisy_state
        self.states = [noisy_state.copy()]
        self.energies = [self.hopfield.energy(noisy_state)]

        self.is_recalling = True
        self.recall_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.timer.start(200)  # 200ms per update

        self.update_display()

    def stop_recall(self):
        self.is_recalling = False
        self.timer.stop()
        self.recall_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def step_recall(self):
        if not self.is_recalling or len(self.states) == 0:
            return
        last_state = self.states[-1]
        # Async update: pick random index and update
        i = np.random.randint(0, self.n)
        h = np.dot(self.hopfield.weights[i, :], last_state)
        new_val = 1 if h >= 0 else -1
        new_state = last_state.copy()
        new_state[i] = new_val
        self.states.append(new_state)
        self.energies.append(self.hopfield.energy(new_state))

        self.update_display()

        # Stop if no change or max steps
        if len(self.states) > 1000:
            self.stop_recall()

    def update_display(self):
        if len(self.states) == 0:
            return
        latest = self.states[-1]
        pat = self.state_to_pattern(latest)
        self.state_ax.clear()
        self.state_ax.imshow(pat, cmap='gray', vmin=0, vmax=1)
        self.state_ax.axis('off')
        self.state_canvas.draw()

        # Plot energy
        self.energy_ax.clear()
        iters = range(len(self.energies))
        self.energy_ax.plot(iters, self.energies, 'b-')
        self.energy_ax.set_xlabel("迭代次数")
        self.energy_ax.set_ylabel("能量")
        self.energy_ax.grid(True)
        self.energy_canvas.draw()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    gui = HopfieldGUI()
    gui.show()
    sys.exit(app.exec_())