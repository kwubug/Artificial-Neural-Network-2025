import PyQt5.QtCore

from nn_sandbox.backend.algorithms.hopfield_tsp_algorithm import HopfieldTSPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldTSPBridge(Bridge):
    # 输入参数
    cities = BridgeProperty([])  # 城市坐标 [[x1,y1], [x2,y2], ...]
    param_A = BridgeProperty(800)
    param_B = BridgeProperty(800)
    param_C = BridgeProperty(300)
    param_D = BridgeProperty(700)
    max_iterations = BridgeProperty(5000)
    ui_refresh_interval = BridgeProperty(0.02)
    dt = BridgeProperty(0.01)
    u0 = BridgeProperty(0.1)
    tau = BridgeProperty(1.0)
    
    # 运行状态
    has_finished = BridgeProperty(True)
    current_iteration = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    energy_history = BridgeProperty([])
    
    # TSP结果
    current_tour = BridgeProperty([])
    current_distance = BridgeProperty(0.0)
    best_tour = BridgeProperty([])
    best_distance = BridgeProperty(0.0)
    neuron_states = BridgeProperty([])  # N×N矩阵
    distance_matrix = BridgeProperty([])
    
    def __init__(self):
        super().__init__()
        self._algo = None
    
    @PyQt5.QtCore.pyqtSlot()
    def start_tsp(self):
        if not self.cities or len(self.cities) < 3:
            return
        
        self._algo = ObservableHopfieldTSPAlgorithm(
            self,
            cities=self.cities,
            A=self.param_A,
            B=self.param_B,
            C=self.param_C,
            D=self.param_D,
            max_iterations=self.max_iterations,
            ui_refresh_interval=self.ui_refresh_interval,
            dt=self.dt,
            u0=self.u0,
            tau=self.tau
        )
        self._algo.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp(self):
        if self._algo:
            self._algo.stop()
    
    @PyQt5.QtCore.pyqtSlot()
    def generate_random_cities(self):
        """生成随机城市"""
        import random
        n = 10  # 默认10个城市
        cities = []
        for _ in range(n):
            x = random.uniform(0, 100)
            y = random.uniform(0, 100)
            cities.append([x, y])
        self.cities = cities


class ObservableHopfieldTSPAlgorithm(Observable, HopfieldTSPAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        object.__setattr__(self, '_obs_ready', False)
        HopfieldTSPAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, '_obs_ready', True)
        
        # 初始化静态信息
        self.notify('distance_matrix', self.distance_matrix.tolist())
        self.notify('current_energy', self.current_energy)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_obs_ready', False):
            return
        
        if name in ('current_iteration', 'current_energy'):
            self.notify(name, value)
        elif name in ('current_tour', 'best_tour'):
            # 处理tour，None转为空列表
            if value is None:
                self.notify(name, [])
            elif isinstance(value, list):
                self.notify(name, value)
            else:
                try:
                    self.notify(name, value.tolist() if hasattr(value, 'tolist') else [])
                except:
                    self.notify(name, [])
        elif name in ('current_distance', 'best_distance'):
            # 处理距离值
            self.notify(name, value if value is not None else float('inf'))
        elif name == 'has_finished':
            self.notify(name, value)
    
    def run(self):
        self.notify('has_finished', False)
        self.notify('energy_history', [])
        self.notify('best_distance', float('inf'))
        self.notify('best_tour', [])  # 初始化为空列表
        self.notify('current_tour', [])  # 初始化为空列表
        
        super().run()
        
        # 完成后推送最终信息
        self.notify('current_iteration', self.current_iteration)
        self.notify('current_energy', self.current_energy)
        self.notify('energy_history', self.energy_history)
        
        # 安全地推送tour信息
        current_tour = self.current_tour if isinstance(self.current_tour, list) else []
        best_tour = self.best_tour if isinstance(self.best_tour, list) else []
        self.notify('current_tour', current_tour)
        self.notify('current_distance', self.current_distance)
        self.notify('best_tour', best_tour)
        self.notify('best_distance', self.best_distance)
        
        # 推送神经元状态
        if self.neuron_states is not None:
            self.notify('neuron_states', self.neuron_states.tolist())
        
        self.notify('has_finished', True)
