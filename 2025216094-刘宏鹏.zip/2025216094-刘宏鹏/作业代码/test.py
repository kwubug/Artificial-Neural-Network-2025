import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

class RBFNetwork:
    def __init__(self, centers, spread):
        self.centers = centers
        self.spread = spread
        self.weights = np.random.rand(centers.shape[0])  # 随机初始化权重

    def _rbf(self, x, center):
        return np.exp(-np.linalg.norm(x - center) ** 2 / (2 * self.spread ** 2))

    def predict(self, x):
        rbf_values = np.array([self._rbf(x, center) for center in self.centers])
        return np.dot(self.weights, rbf_values)

    def fit(self, X, y):
        # 计算输出
        rbf_values = np.array([[self._rbf(x, center) for center in self.centers] for x in X])
        # 最小二乘法求解权重
        self.weights = np.linalg.lstsq(rbf_values, y, rcond=None)[0]

# 数据准备
p = np.arange(-1, 1.1, 0.1)  # 输入向量 [-1, 1]
t = np.array([-0.9602, -0.5770, 0.0729, 0.3771, 0.6405, 0.6600,
              0.4609, 0.1336, -0.2013, -0.4344, 0.5000, -0.3939,
              -0.1647, 0.0988, 0.3072, 0.3960, 0.3449, 0.1816,
              0.0312, -0.2189, -0.3201])  # 目标输出

# 定义 RBF 网络
centers = np.array([p[i] for i in range(len(p))])  # 使用输入作为中心
spread = 0.5  # 设定扩展常数
rbf_network = RBFNetwork(centers, spread)

# 训练网络
rbf_network.fit(p, t)

# 预测输出
predictions = np.array([rbf_network.predict(x) for x in p])

# 绘制结果
plt.figure(figsize=(10, 6))
plt.plot(p, t, label='Target', marker='o')
plt.plot(p, predictions, label='BP Network Output', linestyle='--', marker='x')
plt.xlabel('Input p')
plt.ylabel('Output t')
plt.title('BP')
plt.legend()
plt.grid(True)
plt.show()
