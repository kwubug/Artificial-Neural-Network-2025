import time
import math
import numpy as np

from . import TraningAlgorithm

class BMAlgorithm(TraningAlgorithm):
    """
    三神经元 Boltzmann Machine 演化算法
    """
    def __init__(self, total_epoches=200, temperature=1.0):
        super().__init__(dataset=None, total_epoches=total_epoches)
        self.temperature = temperature
        self.num_neurons = 3
        self.state = np.random.choice([0, 1], size=self.num_neurons)
        self.weights = np.array([
            [0.0, -1.0, 0.5],
            [-1.0, 0.0, -0.5],
            [0.5, -0.5, 0.0]
        ])
        self.bias = np.zeros(self.num_neurons)
        self.energy_history = []

    def _update_neuron(self, i):
        net_input = np.dot(self.weights[i], self.state) + self.bias[i]
        p = 1 / (1 + math.exp(-net_input / self.temperature))
        self.state[i] = 1 if np.random.rand() < p else 0

    def _energy(self, state):
        s = np.array(state)
        return -0.5 * np.dot(s, np.dot(self.weights, s)) - np.dot(self.bias, s)

    def _iterate(self):
        i = np.random.randint(0, self.num_neurons)
        self._update_neuron(i)
        energy = self._energy(self.state)
        self.energy_history.append(energy)
        return self.state.copy(), energy

    def run(self):
        """
        迭代运行 BM 算法，每次迭代更新一个神经元
        """
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            state, energy = self._iterate()
            # emit_signal 由 Bridge 重写
            self.emit_signal({
                'epoch': epoch,
                'state': state.tolist(),
                'energy': float(energy)
            })
            time.sleep(0.05)

    def emit_signal(self, data: dict):
        """由 ObservableBMAlgorithm 重写"""
        pass
