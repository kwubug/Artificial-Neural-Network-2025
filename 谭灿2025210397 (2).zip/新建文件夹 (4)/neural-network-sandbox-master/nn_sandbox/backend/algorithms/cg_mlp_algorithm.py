import collections
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bipolar_sigmoid, sigmoid_derivative, bipolar_sigmoid_derivative


class ConjugateGradientMlpAlgorithm(PredictiveAlgorithm):
    """使用共轭梯度法的多层感知机算法"""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 test_ratio=0.3, network_shape=None,
                 activation_function='sigmoid', cg_restart_frequency=10):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        self.activation_function = activation_function
        self.cg_restart_frequency = cg_restart_frequency  # 每多少次迭代重启共轭梯度
        self.iteration_count = 0

        # 默认网络形状为 (2 * 5)
        self.network_shape = network_shape if network_shape else (5, 5)

        # 共轭梯度法相关变量
        self._gradients = collections.defaultdict(lambda: np.zeros(1))
        self._previous_gradients = collections.defaultdict(lambda: np.zeros(1))
        self._directions = collections.defaultdict(lambda: np.zeros(1))  # 共轭方向
        self._beta = collections.defaultdict(lambda: 0.0)  # Fletcher-Reeves参数

    def _iterate(self):
        """执行一次训练迭代"""
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
        
        # 计算梯度
        self._compute_gradients(deltas)
        
        # 使用共轭梯度法调整权重
        self._adjust_weights_with_conjugate_gradient()
        
        self.iteration_count += 1

    def _initialize_neurons(self):
        """初始化神经元网络"""
        if self.activation_function == 'bipolar_sigmoid':
            activation_func = bipolar_sigmoid
        else:
            activation_func = sigmoid
            
        # 正确初始化神经元网络
        self._neurons = []
        
        # 获取输入数据维度（Perceptron会自动插入偏置项，所以权重维度需要+1）
        input_size = len(self.current_data[:-1]) if hasattr(self, 'current_data') else 1
        input_size_with_bias = input_size + 1
        
        # 创建输入层
        input_layer = []
        for i in range(self.network_shape[0]):
            neuron = Perceptron(activation_func)
            # 权重维度为输入数据维度+1（考虑偏置项）
            neuron.synaptic_weight = np.random.randn(input_size_with_bias) * 0.5
            input_layer.append(neuron)
        self._neurons.append(tuple(input_layer))
        
        # 创建隐藏层（权重维度为前一层神经元数量+1，考虑偏置）
        for i in range(1, len(self.network_shape)):
            hidden_layer = []
            for j in range(self.network_shape[i]):
                neuron = Perceptron(activation_func)
                # 权重维度为前一层神经元数量+1（偏置）
                neuron.synaptic_weight = np.random.randn(self.network_shape[i-1] + 1) * 0.5
                hidden_layer.append(neuron)
            self._neurons.append(tuple(hidden_layer))
        
        # 创建输出层
        output_layer = []
        neuron = Perceptron(activation_func)
        # 权重维度为最后一层隐藏层神经元数量+1（偏置）
        neuron.synaptic_weight = np.random.randn(self.network_shape[-1] + 1) * 0.5
        output_layer.append(neuron)
        self._neurons.append(tuple(output_layer))
        
        self._neurons = tuple(self._neurons)

    def _feed_forward(self, data):
        """前向传播"""
        if not hasattr(self, '_neurons') or not self._neurons:
            self._initialize_neurons()
            
        # 确保神经元有数据输入
        for neuron in self._neurons[0]:
            neuron.data = data
            
        results = []
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
            else:
                results = get_layer_results(layer, results)
        
        # 返回整个网络的输出（对于单输出网络，返回第一个神经元的输出）
        if isinstance(results, (list, np.ndarray)) and len(results) >= 1:
            return float(results[0])
        else:
            return 0.0  # 默认值

    def _pass_backward(self, expect, result):
        """反向传播计算误差"""
        deltas = {}

        # 输出层误差计算
        if self.activation_function == 'bipolar_sigmoid':
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * bipolar_sigmoid_derivative(result))
        else:
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * sigmoid_derivative(result))

        # 隐藏层误差反向传播
        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                # 计算下一层所有神经元对该神经元的误差贡献
                error_sum = 0.0
                for next_neuron in self._neurons[layer_idx + 1]:
                    # 使用正确的权重索引（考虑偏置项）
                    if hasattr(next_neuron, 'synaptic_weight') and len(next_neuron.synaptic_weight) > neuron_idx:
                        error_sum += deltas[next_neuron] * next_neuron.synaptic_weight[neuron_idx]
                
                if self.activation_function == 'bipolar_sigmoid':
                    deltas[neuron] = error_sum * bipolar_sigmoid_derivative(neuron.result)
                else:
                    deltas[neuron] = error_sum * sigmoid_derivative(neuron.result)
        return deltas

    def _compute_gradients(self, deltas):
        """计算梯度"""
        for neuron in deltas:
            # 确保deltas[neuron]是标量
            delta_value = deltas[neuron]
            if not np.isscalar(delta_value):
                delta_value = float(delta_value)
            
            # 正确的梯度计算：对于每个权重，梯度 = 误差 * 对应的输入
            # 对于偏置项，输入为1；对于其他权重，输入为前一层对应神经元的输出
            if hasattr(neuron, 'data') and neuron.data is not None:
                # 构建输入向量（包括偏置项1），确保维度与权重匹配
                if isinstance(neuron.data, (list, np.ndarray)):
                    inputs = np.concatenate([[1.0], neuron.data])  # 偏置 + 输入
                else:
                    inputs = np.array([1.0, neuron.data])  # 偏置 + 输入
                
                # 确保输入向量维度与权重维度匹配
                if len(inputs) != len(neuron.synaptic_weight):
                    # 如果维度不匹配，调整输入向量维度
                    if len(inputs) > len(neuron.synaptic_weight):
                        inputs = inputs[:len(neuron.synaptic_weight)]
                    else:
                        # 填充零到匹配维度
                        inputs = np.pad(inputs, (0, len(neuron.synaptic_weight) - len(inputs)), 
                                      mode='constant', constant_values=0)
                
                # 梯度 = 误差 * 输入 * 学习率（增加梯度规模）
                current_gradient = self.current_learning_rate * delta_value * inputs
                
                # 调试信息：检查梯度大小
                if self.iteration_count % 100 == 0:
                    print(f"Iteration {self.iteration_count}: delta_value={delta_value:.6f}, gradient_norm={np.linalg.norm(current_gradient):.6f}")
                
                # 保存前一次梯度
                self._previous_gradients[neuron] = self._gradients[neuron].copy()
                
                # 更新当前梯度
                self._gradients[neuron] = current_gradient
            else:
                # 如果没有数据，使用零梯度
                self._previous_gradients[neuron] = self._gradients[neuron].copy()
                self._gradients[neuron] = np.zeros_like(neuron.synaptic_weight)

    def _adjust_weights_with_conjugate_gradient(self):
        """使用共轭梯度法调整权重"""
        for neuron in self._gradients:
            if len(neuron.synaptic_weight) > 0:
                current_gradient = self._gradients[neuron]
                
                # 调试信息：检查梯度大小
                if self.iteration_count % 100 == 0:
                    print(f"Iteration {self.iteration_count}: gradient_norm={np.linalg.norm(current_gradient):.6f}")
                
                # 简化实现：先使用基本的梯度下降确保算法能工作
                if np.linalg.norm(current_gradient) > 1e-8:
                    # 保存原始权重用于调试
                    original_weights = neuron.synaptic_weight.copy()
                    
                    # 应用权重更新：使用负梯度方向
                    neuron.synaptic_weight -= current_gradient
                    
                    # 调试信息：检查权重是否更新
                    if self.iteration_count % 100 == 0:
                        weight_change = np.linalg.norm(neuron.synaptic_weight - original_weights)
                        print(f"Iteration {self.iteration_count}: weight_change={weight_change:.6f}")

    def _line_search(self, neuron, direction):
        """改进的线搜索，返回最优步长"""
        # 使用Armijo条件进行线搜索
        alpha = self.current_learning_rate
        c = 0.5  # Armijo条件参数
        tau = 0.5  # 步长缩减因子
        
        # 保存当前权重和梯度
        original_weights = neuron.synaptic_weight.copy()
        current_gradient = self._gradients[neuron]
        
        # 计算当前损失函数的梯度方向导数
        grad_dot_dir = np.dot(current_gradient, direction)
        
        # 如果方向不是下降方向，使用梯度下降
        if grad_dot_dir >= 0:
            return self.current_learning_rate
        
        # Armijo线搜索
        for _ in range(10):  # 最多尝试10次
            # 临时更新权重
            neuron.synaptic_weight = original_weights + alpha * direction
            
            # 计算新权重下的前向传播结果
            try:
                result = self._feed_forward(self.current_data[:-1])
                expect = self._normalize(self.current_data[-1])
                new_deltas = self._pass_backward(expect, result)
                
                # 计算新梯度
                self._compute_gradients(new_deltas)
                new_gradient = self._gradients[neuron]
                
                # 检查Armijo条件
                if (np.linalg.norm(new_gradient) <= 
                    np.linalg.norm(current_gradient) + c * alpha * grad_dot_dir):
                    # 恢复原始权重，返回步长
                    neuron.synaptic_weight = original_weights
                    return alpha
                
            except (ValueError, RuntimeError):
                pass
            
            # 缩减步长
            alpha *= tau
        
        # 如果线搜索失败，使用固定学习率
        neuron.synaptic_weight = original_weights
        return self.current_learning_rate

    def _correct_rate(self, dataset):
        """计算正确率"""
        if not self._neurons or len(dataset) == 0:
            return 0.0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0.0
        return float(correct_count) / len(dataset)

    def _normalize(self, value):
        """归一化期望输出"""
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))


def get_layer_results(layer, data):
    """获取一层神经元的输出结果"""
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)