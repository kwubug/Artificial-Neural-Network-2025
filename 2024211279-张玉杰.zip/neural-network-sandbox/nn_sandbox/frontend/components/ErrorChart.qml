import QtQuick 2.12
import QtQuick.Controls 2.5
import QtCharts 2.3

ChartView {
    id: chart
    property var errorSeries: LineSeries {
        name: 'Training Error'
        axisX: xAxis
        axisY: yAxis
        useOpenGL: true
    }

    antialiasing: true
    
    ValueAxis{
        id: xAxis
        titleText: 'Iterations'
        min: 1.0
        max: 2.0
    }
    ValueAxis{
        id: yAxis
        titleText: 'Error'
        min: 0.0
        max: 1.0
    }

    function updateAxes(point) {
        xAxis.max = Math.max(xAxis.max, point.x)
        xAxis.min = Math.min(xAxis.min, point.x)
        yAxis.max = Math.max(yAxis.max, point.y * 1.1)
    }

    function reset() {
        removeAllSeries()
        errorSeries = createSeries(
            ChartView.SeriesTypeLine, 'Training Error', xAxis, yAxis
        )
        errorSeries.pointAdded.connect((index) => {
            updateAxes(errorSeries.at(index))
        })
        xAxis.max = 1
        xAxis.min = 0
        yAxis.max = 1
        yAxis.min = 0
    }

    Component.onCompleted: reset()
}

