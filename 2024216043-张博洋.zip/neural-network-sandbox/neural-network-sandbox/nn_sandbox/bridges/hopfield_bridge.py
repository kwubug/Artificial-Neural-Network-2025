import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.hopfield_algorithm import HopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    """
    Bridge for 2D Hopfield Network visualization.
    Supports pattern drawing, corruption, and real-time recovery.
    """
    # Parameters
    n_dim = BridgeProperty(8)  # Grid dimension (N x N)
    patterns = BridgeProperty([])  # list[list[int]] - stored patterns (1D flattened)
    selected_pattern_idx = BridgeProperty(0)
    noise_level = BridgeProperty(0.25)  # 0.0 to 1.0
    max_iter = BridgeProperty(2000)
    ui_refresh_interval = BridgeProperty(0.01)

    # Live states
    original_pattern = BridgeProperty([])  # The selected pattern before corruption
    corrupted_state = BridgeProperty([])   # The corrupted initial state
    current_state = BridgeProperty([])     # Current network state
    attractor_state = BridgeProperty([])   # Final attractor state
    
    current_iter = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    attractor_energy = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    @PyQt5.QtCore.pyqtSlot()
    def store_patterns(self):
        """Store patterns and compute weights (doesn't start simulation)."""
        # This is called when user clicks "Store Patterns" button
        # The patterns are already set via QML binding
        pass

    @PyQt5.QtCore.pyqtSlot()
    def start(self):
        """Start the Hopfield network simulation."""
        if not self.patterns or len(self.patterns) == 0:
            return
        if self.selected_pattern_idx < 0 or self.selected_pattern_idx >= len(self.patterns):
            return
        
        self.has_finished = False
        self._algo = ObservableHopfieldAlgorithm(
            self,
            n_dim=self.n_dim,
            patterns=self.patterns,
            selected_pattern_idx=self.selected_pattern_idx,
            noise_level=self.noise_level,
            max_iter=self.max_iter,
            ui_refresh_interval=self.ui_refresh_interval
        )
        self._algo.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop(self):
        """Stop the simulation."""
        if hasattr(self, '_algo') and self._algo:
            self._algo.stop()


class ObservableHopfieldAlgorithm(Observable, HopfieldAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        HopfieldAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ('original_pattern', 'corrupted_state', 'current_state',
                    'attractor_state') and isinstance(value, (list, tuple, np.ndarray)):
            # Convert to list for QML
            if isinstance(value, np.ndarray):
                self.notify(name, value.tolist())
            else:
                self.notify(name, list(value))
        elif name in ('current_iter', 'current_energy', 'attractor_energy', 'has_finished'):
            self.notify(name, value)


