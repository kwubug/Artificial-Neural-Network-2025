"""测试应用是否能正常启动和运行"""
import sys
sys.path.insert(0, '/home/irelia/app/GradientDescentViz')

from bp_optimizers import BPNeuralNetwork, generate_classification_data
import numpy as np

print("="*60)
print("测试 BP 神经网络可视化应用")
print("="*60)

# 测试1: 数据生成
print("\n[测试1] 数据生成...")
try:
    X, y = generate_classification_data(n_samples=100)
    print(f"✅ 数据生成成功: X shape={X.shape}, y shape={y.shape}")
except Exception as e:
    print(f"❌ 数据生成失败: {e}")
    sys.exit(1)

# 测试2: 网络初始化
print("\n[测试2] 网络初始化...")
try:
    network = BPNeuralNetwork(
        input_size=2,
        hidden_size=4,
        output_size=1,
        optimizer='gradient_descent',
        learning_rate=0.1
    )
    print(f"✅ 网络初始化成功")
    print(f"   W1 shape: {network.W1.shape}")
    print(f"   W2 shape: {network.W2.shape}")
except Exception as e:
    print(f"❌ 网络初始化失败: {e}")
    sys.exit(1)

# 测试3: 训练步骤
print("\n[测试3] 训练步骤...")
try:
    loss = network.train_step(X, y)
    print(f"✅ 训练步骤成功")
    print(f"   初始损失: {loss:.6f}")
except Exception as e:
    print(f"❌ 训练步骤失败: {e}")
    sys.exit(1)

# 测试4: 多轮训练
print("\n[测试4] 多轮训练...")
try:
    for epoch in range(10):
        loss = network.train_step(X, y)
    predictions = network.predict(X)
    accuracy = np.mean((predictions > 0.5) == y)
    print(f"✅ 多轮训练成功")
    print(f"   10轮后损失: {loss:.6f}")
    print(f"   准确率: {accuracy*100:.2f}%")
except Exception as e:
    print(f"❌ 多轮训练失败: {e}")
    sys.exit(1)

# 测试5: 三种优化器
print("\n[测试5] 三种优化器...")
optimizers = ['gradient_descent', 'newton', 'conjugate_gradient']
for opt in optimizers:
    try:
        net = BPNeuralNetwork(2, 4, 1, optimizer=opt, learning_rate=0.1)
        loss = net.train_step(X, y)
        print(f"✅ {opt:20s} - 损失: {loss:.6f}")
    except Exception as e:
        print(f"❌ {opt:20s} - 失败: {e}")

# 测试6: 导入Dash组件
print("\n[测试6] Dash组件导入...")
try:
    from main import app
    print(f"✅ Dash应用导入成功")
    print(f"   应用标题: {app.title}")
except Exception as e:
    print(f"❌ Dash应用导入失败: {e}")
    sys.exit(1)

print("\n" + "="*60)
print("✅ 所有测试通过！应用可以正常运行。")
print("="*60)
print("\n运行以下命令启动应用:")
print("  cd /home/irelia/app/GradientDescentViz")
print("  python3 main.py")
print("\n然后在浏览器访问: http://localhost:8060")

