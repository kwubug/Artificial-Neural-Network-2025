import time
import numpy as np
import PyQt5.QtCore
import threading

from nn_sandbox.backend.algorithms import BoltzmannMachineAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BoltzmannMachineBridge(Bridge):
    # 网络参数
    n_neurons = BridgeProperty(3)
    temperature = BridgeProperty(1.0)
    max_iterations = BridgeProperty(1000)
    ui_refresh_interval = BridgeProperty(0.05)
    
    # 权重和偏置
    weights = BridgeProperty([[0.0, 1.5, -1.0], [1.5, 0.0, 0.5], [-1.0, 0.5, 0.0]])
    bias = BridgeProperty([0.5, -0.3, 0.2])
    
    # 当前状态
    current_state = BridgeProperty([0, 0, 0])
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    is_equilibrium = BridgeProperty(False)
    
    # 历史记录
    state_history = BridgeProperty([])
    energy_history = BridgeProperty([])
    
    # 统计信息
    state_counts = BridgeProperty({})
    equilibrium_distribution = BridgeProperty({})
    theoretical_distribution = BridgeProperty({})
    all_possible_states = BridgeProperty([])
    
    # 状态
    has_finished = BridgeProperty(True)
    
    def __init__(self):
        super().__init__()
        self.bm_algorithm = None
        self._init_default_weights()
    
    def _init_default_weights(self):
        """初始化默认权重"""
        self.weights = [[0.0, 1.5, -1.0], [1.5, 0.0, 0.5], [-1.0, 0.5, 0.0]]
        self.bias = [0.5, -0.3, 0.2]
        self.current_state = [0, 0, 0]
        
    @PyQt5.QtCore.pyqtSlot(float)
    def set_temperature(self, temp):
        """设置温度"""
        self.temperature = temp
    
    @PyQt5.QtCore.pyqtSlot(int)
    def set_max_iterations(self, iterations):
        """设置最大迭代次数"""
        self.max_iterations = iterations
    
    @PyQt5.QtCore.pyqtSlot(list, list)
    def set_weights_and_bias(self, weights, bias):
        """设置权重和偏置"""
        self.weights = weights
        self.bias = bias
    
    @PyQt5.QtCore.pyqtSlot()
    def start_simulation(self):
        """开始模拟"""
        print("开始BM模拟")
        self.bm_algorithm = ObservableBoltzmannMachineAlgorithm(
            self,
            self.ui_refresh_interval,
            temperature=self.temperature,
            max_iterations=self.max_iterations
        )
        self.bm_algorithm.set_weights(self.weights, self.bias)
        self.bm_algorithm.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def calculate_theoretical_distribution(self):
        """计算理论分布"""
        temp_algo = BoltzmannMachineAlgorithm(
            temperature=self.temperature,
            max_iterations=10
        )
        temp_algo.set_weights(self.weights, self.bias)
        temp_algo._initialize_neurons()
        
        # 计算理论分布
        theoretical = temp_algo.get_theoretical_distribution()
        self.theoretical_distribution = {str(k): v for k, v in theoretical.items()}
        
        # 获取所有可能状态
        self.all_possible_states = temp_algo.get_all_possible_states()
        
        print(f"理论分布计算完成: {self.theoretical_distribution}")
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()


class ObservableBoltzmannMachineAlgorithm(Observable, BoltzmannMachineAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        object.__setattr__(self, '_init_done', False)
        Observable.__init__(self, observer)
        BoltzmannMachineAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, 'ui_refresh_interval', ui_refresh_interval)
        object.__setattr__(self, '_init_done', True)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_init_done', False) or not hasattr(self, '_observer'):
            return
        
        if name == 'current_state':
            self.notify('current_state', value.tolist() if isinstance(value, np.ndarray) else list(value))
            self.notify('current_energy', self.calculate_energy(value))
        elif name == 'current_iterations':
            self.notify(name, value)
        elif name == 'is_equilibrium':
            self.notify(name, value)
    
    def run(self):
        self.notify('has_finished', False)
        self.notify('state_history', [])
        self.notify('energy_history', [])
        
        super().run()
        
        # 通知最终结果
        self.notify('state_history', [s.tolist() for s in self.state_history])
        self.notify('energy_history', self.energy_history)
        self.notify('current_state', self.current_state.tolist())
        self.notify('current_energy', self.calculate_energy(self.current_state))
        self.notify('is_equilibrium', self.is_equilibrium)
        
        # 转换字典的键为字符串（QML兼容）
        state_counts_str = {str(k): v for k, v in self.state_counts.items()}
        equilibrium_dist_str = {str(k): v for k, v in self.equilibrium_distribution.items()}
        
        self.notify('state_counts', state_counts_str)
        self.notify('equilibrium_distribution', equilibrium_dist_str)
        
        self.notify('has_finished', True)
    
    def _iterate(self):
        super()._iterate()
        
        # 通知更新
        self.notify('current_state', self.current_state.tolist())
        self.notify('current_iterations', self.current_iterations)
        self.notify('current_energy', self.calculate_energy(self.current_state))
        self.notify('is_equilibrium', self.is_equilibrium)
        
        # UI刷新间隔
        if self.ui_refresh_interval > 0:
            elapsed = 0
            while elapsed < self.ui_refresh_interval and not self._should_stop:
                time.sleep(0.01)
                elapsed += 0.01