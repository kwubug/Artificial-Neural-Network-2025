import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

def F(x):
    return 1.1 * (1 - x + 2 * x ** 2) * torch.exp(-x ** 2 / 2)

torch.manual_seed(42)
P = 100
x_i = torch.FloatTensor(P).uniform_(-4, 4)
e_i = torch.normal(0, 0.1, size=(P,))
y_i = F(x_i) + e_i
X_train = x_i.unsqueeze(1)
y_train = y_i.unsqueeze(1)


class RBFNet(nn.Module):
    def __init__(self, M=10):
        super(RBFNet, self).__init__()
        self.M = M
        self.centers = nn.Parameter(torch.randn(M, 1))
        self.sigmas = nn.Parameter(torch.ones(M, 1))
        self.weights = nn.Parameter(torch.randn(M, 1))
        self.bias = nn.Parameter(torch.randn(1))

    def gaussian_rbf(self, x):
        x_expanded = x.unsqueeze(1)
        centers_expanded = self.centers.unsqueeze(0)
        distances = torch.sum((x_expanded - centers_expanded) ** 2, dim=2)
        phi = torch.exp(-distances / (2 * self.sigmas.squeeze() ** 2))
        return phi

    def forward(self, x):
        phi = self.gaussian_rbf(x)  # (batch_size, M)
        output = torch.matmul(phi, self.weights) + self.bias
        return output

def kmeans_manual(X, k, max_iters=100):

    indices = torch.randperm(X.shape[0])[:k]
    centers = X[indices].clone()

    for _ in range(max_iters):

        distances = torch.cdist(X, centers)

        labels = torch.argmin(distances, dim=1)

        new_centers = torch.zeros_like(centers)
        for i in range(k):
            cluster_points = X[labels == i]
            if len(cluster_points) > 0:
                new_centers[i] = cluster_points.mean(dim=0)

        if torch.allclose(centers, new_centers):
            break
        centers = new_centers

    return centers, labels

def part1_cluster_pseudoinverse():
    centers_cluster, labels = kmeans_manual(X_train, k=10)

    sigmas_cluster = []
    for i in range(10):
        cluster_points = X_train[labels == i]
        if len(cluster_points) > 1:
            distances = torch.norm(cluster_points - centers_cluster[i], dim=1)
            sigma = torch.sqrt(torch.mean(distances ** 2))
            sigmas_cluster.append(sigma.item())
        else:
            sigmas_cluster.append(1.0)  # 默认值

    sigmas_cluster = torch.FloatTensor(sigmas_cluster).unsqueeze(1)

    model1 = RBFNet(M=10)
    model1.centers.data = centers_cluster
    model1.sigmas.data = sigmas_cluster * 1.0  # λ=1

    with torch.no_grad():

        phi_matrix = model1.gaussian_rbf(X_train)  # (100, 10)

        phi_matrix_with_bias = torch.cat([phi_matrix, torch.ones(phi_matrix.size(0), 1)], dim=1)

        pseudoinverse = torch.pinverse(phi_matrix_with_bias)
        weights_with_bias = torch.matmul(pseudoinverse, y_train)

        model1.weights.data = weights_with_bias[:-1]
        model1.bias.data = weights_with_bias[-1:]

    model1.eval()
    with torch.no_grad():
        y_pred1 = model1(X_train)
        mse1 = torch.mean((y_pred1 - y_train) ** 2)

    return model1

def part2_gradient_descent():
    model2 = RBFNet(M=10)

    torch.manual_seed(42)
    model2.centers.data = torch.FloatTensor(10, 1).uniform_(-4.0, 4.0)
    model2.sigmas.data = torch.FloatTensor(10, 1).uniform_(0.1, 0.3)
    model2.weights.data = torch.FloatTensor(10, 1).uniform_(-0.1, 0.1)
    model2.bias.data = torch.FloatTensor(1).uniform_(-0.1, 0.1)

    criterion = nn.MSELoss()
    optimizer = optim.SGD(model2.parameters(), lr=0.001)

    # 训练循环
    losses = []
    target_error = 0.9
    max_epochs = 5000

    for epoch in range(max_epochs):
        model2.train()
        optimizer.zero_grad()

        y_pred = model2(X_train)
        loss = criterion(y_pred, y_train)

        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if loss.item() <= target_error:
            print(f"在 epoch {epoch} 达到目标误差 {target_error}")
            break

        if (epoch + 1) % 1000 == 0:
            print(f"Epoch {epoch + 1}, Loss: {loss.item():.6f}")

    return model2, losses



def plot_results(model1, model2, losses):

    x_test = torch.linspace(-4, 4, 200).unsqueeze(1)
    y_true = F(x_test)

    with torch.no_grad():
        y_pred1 = model1(x_test)
        y_pred2 = model2(x_test)

    plt.figure(figsize=(15, 10))


    plt.subplot(2, 2, 1)
    plt.plot(x_test.numpy(), y_true.numpy(), 'b-', label='True Function', linewidth=2)
    plt.plot(x_test.numpy(), y_pred1.numpy(), 'r--', label='Cluster + Pseudoinverse', linewidth=2)
    plt.scatter(X_train.numpy(), y_train.numpy(), alpha=0.3, label='Training Data')
    plt.xlabel('x')
    plt.ylabel('F(x)')
    plt.title('Hermit Polynomial Approximation - Cluster + Pseudoinverse')
    plt.legend()
    plt.grid(True)

    plt.subplot(2, 2, 2)
    plt.plot(x_test.numpy(), y_true.numpy(), 'b-', label='True Function', linewidth=2)
    plt.plot(x_test.numpy(), y_pred2.numpy(), 'g--', label='Gradient Descent', linewidth=2)
    plt.scatter(X_train.numpy(), y_train.numpy(), alpha=0.3, label='Training Data')
    plt.xlabel('x')
    plt.ylabel('F(x)')
    plt.title('Hermit Polynomial Approximation - Gradient Descent')
    plt.legend()
    plt.grid(True)


    plt.subplot(2, 2, 3)
    plt.plot(losses)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss (Gradient Descent)')
    plt.yscale('log')
    plt.grid(True)

    plt.subplot(2, 2, 4)
    with torch.no_grad():
        train_pred1 = model1(X_train)
        train_pred2 = model2(X_train)
        error1 = (train_pred1 - y_train).abs().numpy()
        error2 = (train_pred2 - y_train).abs().numpy()

    plt.boxplot([error1.squeeze(), error2.squeeze()],tick_labels=['Cluster+PI', 'GD'])
    plt.ylabel('Absolute Error')
    plt.title('Error Distribution Comparison')
    plt.grid(True)

    plt.tight_layout()
    plt.show()


model1 = part1_cluster_pseudoinverse()
model2, losses = part2_gradient_descent()

plot_results(model1, model2, losses)

with torch.no_grad():
    y_pred1_final = model1(X_train)
    y_pred2_final = model2(X_train)

    mse1 = torch.mean((y_pred1_final - y_train) ** 2)
    mse2 = torch.mean((y_pred2_final - y_train) ** 2)

    print(f"聚类+伪逆法 - 训练MSE: {mse1.item():.6f}")
    print(f"梯度下降法 - 训练MSE: {mse2.item():.6f}")

    x_test = torch.linspace(-4, 4, 100).unsqueeze(1)
    y_test_true = F(x_test)

    y_test_pred1 = model1(x_test)
    y_test_pred2 = model2(x_test)

    test_mse1 = torch.mean((y_test_pred1 - y_test_true) ** 2)
    test_mse2 = torch.mean((y_test_pred2 - y_test_true) ** 2)

    print(f"聚类+伪逆法 - 测试MSE: {test_mse1.item():.6f}")
    print(f"梯度下降法 - 测试MSE: {test_mse2.item():.6f}")

print("\n=== 最终参数值 ===")
print("聚类+伪逆法参数范围:")
print(f"数据中心: [{model1.centers.data.min().item():.3f}, {model1.centers.data.max().item():.3f}]")
print(f"扩展常数: [{model1.sigmas.data.min().item():.3f}, {model1.sigmas.data.max().item():.3f}]")
print(f"输出权值: [{model1.weights.data.min().item():.3f}, {model1.weights.data.max().item():.3f}]")
print(f"阈值: {model1.bias.data.item():.6f}")

print("\n梯度下降法参数范围:")
print(f"数据中心: [{model2.centers.data.min().item():.3f}, {model2.centers.data.max().item():.3f}]")
print(f"扩展常数: [{model2.sigmas.data.min().item():.3f}, {model2.sigmas.data.max().item():.3f}]")
print(f"输出权值: [{model2.weights.data.min().item():.3f}, {model2.weights.data.max().item():.3f}]")
print(f"阈值: {model2.bias.data.item():.6f}")

with torch.no_grad():
    for i in range(5):
        true_val = y_train[i].item()
        pred1 = model1(X_train[i].unsqueeze(0)).item()
        pred2 = model2(X_train[i].unsqueeze(0)).item()
        print(f"样本{i + 1}: 真实值={true_val:.4f}, 聚类法预测={pred1:.4f}, 梯度法预测={pred2:.4f}")