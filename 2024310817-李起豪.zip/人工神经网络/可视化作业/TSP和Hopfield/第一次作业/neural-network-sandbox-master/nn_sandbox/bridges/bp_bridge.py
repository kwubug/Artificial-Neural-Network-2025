import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BPBridge(Bridge):
    """BP算法的UI桥接类"""
    
    # UI刷新间隔
    ui_refresh_interval = BridgeProperty(0.0)
    
    # 数据集相关
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    
    # 训练参数
    total_epoches = BridgeProperty(1000)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.1)
    search_iteration_constant = BridgeProperty(10000)
    test_ratio = BridgeProperty(0.3)
    
    # 网络结构参数
    input_nodes = BridgeProperty(2)
    hidden_nodes = BridgeProperty(5)
    output_nodes = BridgeProperty(1)
    
    # 激活函数类型
    sigmoid_type = BridgeProperty('unipolar')  # 'unipolar' 或 'bipolar'
    
    # 收敛阈值
    convergence_threshold = BridgeProperty(0.01)
    
    # 训练状态
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    
    # 训练信息
    current_epoch = BridgeProperty(0)
    converged = BridgeProperty(False)
    final_error = BridgeProperty(0.0)
    training_errors = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        """启动BP算法训练"""
        self.bp_algorithm = ObservableBPAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
            input_nodes=self.input_nodes,
            hidden_nodes=self.hidden_nodes,
            output_nodes=self.output_nodes,
            sigmoid_type=self.sigmoid_type,
            convergence_threshold=self.convergence_threshold
        )
        self.bp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        """停止BP算法训练"""
        if self.bp_algorithm:
            self.bp_algorithm.stop()

    @PyQt5.QtCore.pyqtSlot()
    def reset_algorithm(self):
        """重置算法状态"""
        self.current_iterations = 0
        self.current_learning_rate = 0.0
        self.best_correct_rate = 0.0
        self.current_correct_rate = 0.0
        self.test_correct_rate = 0.0
        self.current_epoch = 0
        self.converged = False
        self.final_error = 0.0
        self.training_errors = []
        self.has_finished = True

    @property
    def _most_correct_rate(self):
        """获取目标正确率"""
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableBPAlgorithm(Observable, BPAlgorithm):
    """可观察的BP算法类，用于与UI交互"""
    
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BPAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        
        # 通知UI更新
        if name == 'current_epoch':
            self.notify('current_epoch', value)
        elif name == 'converged':
            self.notify('converged', value)
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())
        elif name == 'training_errors':
            self.notify('training_errors', value.copy() if value else [])

    def run(self):
        """运行训练算法"""
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        self.notify('converged', False)
        
        try:
            super().run()
            
            # 训练完成后的处理
            training_info = self.get_training_info()
            self.notify('current_epoch', training_info['current_epoch'])
            self.notify('converged', training_info['converged'])
            self.notify('final_error', training_info['final_error'])
            self.notify('training_errors', training_info['training_errors'])
            
            # 计算最终测试正确率
            final_test_rate = self.test()
            self.notify('test_correct_rate', final_test_rate)
            
        except Exception as e:
            print(f"训练过程中出现错误: {e}")
        finally:
            self.notify('has_finished', True)

    def _save_best_neurons(self):
        """保存最佳神经元状态并通知UI"""
        super()._save_best_neurons()
        
        # 通知UI更新训练信息
        if hasattr(self, 'training_errors') and self.training_errors:
            self.notify('final_error', self.training_errors[-1])
            self.notify('training_errors', self.training_errors.copy())

    @property
    def current_learning_rate(self):
        """获取当前学习率并通知UI"""
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret

    def _iterate(self):
        """单次迭代，添加UI刷新延迟"""
        super()._iterate()
        # 防止UI阻塞
        if self.ui_refresh_interval > 0:
            time.sleep(self.ui_refresh_interval)
