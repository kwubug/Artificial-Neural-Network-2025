import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl


plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'WenQuanYi Zen Hei', 'Heiti TC']
plt.rcParams['axes.unicode_minus'] = False
mpl.rcParams['figure.dpi'] = 100


np.random.seed(42)
x = np.linspace(0, 10, 100).reshape(-1, 1)
true_w = 2.0
true_b = 3.0
y = true_w * x + true_b + np.random.normal(0, 1, size=x.shape)



class ManualOLS:
    def __init__(self):
        self.w = None  # 斜率（标量）
        self.b = None  # 截距（标量）

    def fit(self, x, y):
        """按OLS公式计算最优参数w和b"""
        n = len(x)
        sum_x = np.sum(x)
        sum_y = np.sum(y)
        sum_xy = np.sum(x * y)
        sum_x2 = np.sum(x ** 2)


        self.w = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
        self.b = (sum_y - self.w * sum_x) / n

    def predict(self, x):
        """预测函数：y_hat = w*x + b"""
        return self.w * x + self.b



def calculate_r2(y_true, y_pred):
    """
    R² = 1 - (残差平方和 / 总平方和)
    越接近1说明拟合效果越好
    """
    residual_sum_squares = np.sum((y_true - y_pred) ** 2)  # 残差平方和
    total_sum_squares = np.sum((y_true - np.mean(y_true)) ** 2)  # 总平方和
    return 1 - (residual_sum_squares / total_sum_squares)


manual_ols = ManualOLS()
manual_ols.fit(x, y)
y_hat_manual = manual_ols.predict(x)
r2 = calculate_r2(y, y_hat_manual)


plt.figure(figsize=(12, 7))


plt.scatter(x, y, alpha=0.7, label='原始数据（含噪声）', color='#87CEEB', s=60, edgecolors='#1E90FF')


plt.plot(x, true_w * x + true_b, label=f'真实模型: y = {true_w}x + {true_b}',
         color='#DC143C', linewidth=2.5, linestyle='--')


plt.plot(x, y_hat_manual, label=f'手动OLS拟合: y = {manual_ols.w:.4f}x + {manual_ols.b:.4f}',
         color='#FF8C00', linewidth=2.5)


plt.xlabel('特征 x', fontsize=14, fontproperties='SimHei')
plt.ylabel('标签 y', fontsize=14, fontproperties='SimHei')
plt.title('OLS 线性回归基础可视化（无sklearn依赖）', fontsize=16, fontweight='bold', fontproperties='SimHei')
plt.legend(fontsize=11, loc='upper left', prop={'family': 'SimHei'})
plt.grid(alpha=0.3, linestyle='-', linewidth=0.5)


print("=" * 50)
print("OLS 模型结果")
print("=" * 50)
print(f"真实参数 - 斜率w: {true_w:.4f}, 截距b: {true_b:.4f}")
print(f"手动OLS - 斜率w: {manual_ols.w:.4f}, 截距b: {manual_ols.b:.4f}")
print(f"\n拟合效果（R²分数，越接近1越好）: {r2:.4f}")
print("=" * 50)

plt.tight_layout()
plt.show()