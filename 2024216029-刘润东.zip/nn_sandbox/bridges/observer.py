import abc


class Observer(abc.ABC):
    def update(self, name, value):
        # 使用setattr设置属性，这会触发BridgeProperty的信号
        try:
            setattr(self, name, value)
        except Exception as e:
            print(f"Error updating {name} to {value}: {e}")
            import traceback
            traceback.print_exc()


class Observable(abc.ABC):
    def __init__(self, observer):
        self._observer = observer

    @abc.abstractmethod
    def __setattr__(self, name, value):
        """
        Call `notify(name, value)` if the attributes are required by the
        observer.
        """
        super().__setattr__(name, value)

    def notify(self, name, value):
        self._observer.update(name, value)
