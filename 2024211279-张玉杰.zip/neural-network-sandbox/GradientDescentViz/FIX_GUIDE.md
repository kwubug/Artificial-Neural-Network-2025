# 问题修复指南

## 🔧 修复的问题

### 问题1: Callback组件不存在错误
**错误信息**: `A nonexistent object was used in an State of a Dash callback`

**原因**: 动态布局导致初始时某些组件不存在

**解决方案**:
1. ✅ 在主布局中添加 `entry_layout()` 作为 `dynamic` div 的初始内容
2. ✅ 添加 `suppress_callback_exceptions=True` 配置
3. ✅ 在可视化函数中添加空值检查

### 问题2: Store组件重复定义
**原因**: `store` 同时在主布局和 `viz_layout()` 中定义

**解决方案**:
✅ 将 `store` 移至主布局，从 `viz_layout()` 中删除

### 问题3: 虚拟环境问题
**原因**: 需要在 tvm conda 环境中运行

**解决方案**:
✅ 更新 `run.sh` 脚本自动激活 tvm 环境

---

## 🚀 启动应用

### 方法1: 使用启动脚本（推荐）
```bash
cd /home/irelia/app/GradientDescentViz
./run.sh
```

### 方法2: 手动激活环境
```bash
cd /home/irelia/app/GradientDescentViz
conda activate tvm
python main.py
```

### 方法3: 直接使用 conda run
```bash
cd /home/irelia/app/GradientDescentViz
conda run -n tvm python main.py
```

---

## ✅ 访问应用

启动成功后，在浏览器中访问：

**http://localhost:8060**

（端口已从 8050 改为 8060，避免冲突）

---

## 🔍 验证修复

运行测试脚本验证所有功能：

```bash
cd /home/irelia/app/GradientDescentViz
conda activate tvm
python test_app.py
```

预期输出：
```
============================================================
测试 BP 神经网络可视化应用
============================================================

[测试1] 数据生成...
✅ 数据生成成功: X shape=(100, 2), y shape=(100, 1)

[测试2] 网络初始化...
✅ 网络初始化成功

[测试3] 训练步骤...
✅ 训练步骤成功

[测试4] 多轮训练...
✅ 多轮训练成功

[测试5] 三种优化器...
✅ gradient_descent     - 损失: 0.XXXXXX
✅ newton               - 损失: 0.XXXXXX
✅ conjugate_gradient   - 损失: 0.XXXXXX

[测试6] Dash组件导入...
✅ Dash应用导入成功

============================================================
✅ 所有测试通过！应用可以正常运行。
============================================================
```

---

## 🐛 常见问题排查

### Q1: 提示 "ID not found in layout"
**解决**: 确保使用了修复后的版本，`entry_layout()` 已添加到主布局中

### Q2: 提示 "No module named 'dash'"
**解决**: 
```bash
conda activate tvm
pip install dash dash-bootstrap-components plotly
```

### Q3: 端口被占用
**解决**: 修改 `main.py` 最后一行的端口号：
```python
port = int(os.environ.get("PORT", 8070))  # 改为其他端口
```

### Q4: 训练按钮无响应
**解决**: 
1. 检查浏览器控制台是否有错误
2. 确保已点击"开始训练"进入可视化界面
3. 刷新页面重试

---

## 📝 修改的文件

### main.py
- ✅ 添加 `suppress_callback_exceptions=True`
- ✅ 在主布局中添加 `store` 组件
- ✅ 初始化 `dynamic` div 为 `entry_layout()`
- ✅ 改进空值检查逻辑

### layout.py
- ✅ 从 `viz_layout()` 中删除重复的 `store` 定义

### run.sh
- ✅ 添加 conda 环境激活

---

## 🎯 使用流程

### 1. 配置阶段
- 选择优化算法（梯度下降/牛顿法/共轭梯度法）
- 设置学习率（0.01 - 1.0）
- 选择隐藏层大小（2-10个神经元）
- 选择数据集（线性可分/XOR）
- 点击"开始训练"

### 2. 训练阶段
- 选择每次训练轮数（1/5/10/20/50/100）
- 点击"训练"按钮开始训练
- 观察实时更新的图表：
  - 训练数据分布
  - 决策边界动画
  - 损失和准确率曲线
  - 权重空间轨迹
- 重复点击"训练"继续训练
- 点击"重置"重新初始化网络

---

## 💡 技术细节

### Callback 结构
```
submit-button (点击)
    ↓
entry_layout → viz_layout (切换界面)
    ↓
capture_data (初始化网络)
    ↓
sim-button/reset-button (训练/重置)
    ↓
run_training (执行训练)
    ↓
update_visualizations (更新图表)
```

### 数据流
```
params (配置参数)
    ↓
network_state (网络权重)
    ↓
store (训练历史)
    ↓
figures (可视化图表)
```

---

## 🎉 测试建议

### 实验1: 快速验证（2分钟）
```
配置: 梯度下降, 学习率=0.1, 隐藏层=4, 数据=线性可分
操作: 训练10次，重复3次
观察: 损失下降，准确率提升，决策边界变化
```

### 实验2: 算法对比（5分钟）
```
依次使用三种优化算法
每种训练50次
对比: 收敛速度、权重轨迹、最终准确率
```

### 实验3: XOR挑战（10分钟）
```
数据: XOR
隐藏层: 从2到8逐步增加
观察: 最少需要多少神经元能学会XOR？
```

---

## 📞 如果还有问题

1. **检查终端输出**: 查看详细错误信息
2. **查看浏览器控制台**: 按F12查看JavaScript错误
3. **重新安装依赖**:
   ```bash
   conda activate tvm
   pip install --upgrade dash dash-bootstrap-components plotly numpy Flask
   ```
4. **清除缓存**: 删除 `__pycache__` 目录并重启

---

**修复完成！现在可以正常使用了。** 🎉

运行 `./run.sh` 开始探索吧！

