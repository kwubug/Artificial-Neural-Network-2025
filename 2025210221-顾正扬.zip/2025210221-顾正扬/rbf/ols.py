import numpy as np
import matplotlib.pyplot as plt

# 设置matplotlib支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


# 数据预处理和加载
def load_data():
    x = np.linspace(-1, 1, 21)
    y = np.array(
        [-0.9602, -0.5770, 0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336, -0.2013, -0.4344, 0.5000, -0.3939, -0.1674,
         0.0988, 0.3072, 0.3960, 0.3449, 0.11816, 0.0312, -0.2198, -0.3201])
    return x, y


# 数据标准化
def normalize_data(x, y):
    # 对x进行标准化
    x_mean = np.mean(x)
    x_std = np.std(x)
    x_norm = (x - x_mean) / x_std if x_std > 0 else x

    # 对y进行标准化
    y_mean = np.mean(y)
    y_std = np.std(y)
    y_norm = (y - y_mean) / y_std if y_std > 0 else y

    return x_norm, y_norm, x_mean, x_std, y_mean, y_std


# 数据反标准化
def denormalize_y(y_norm, y_mean, y_std):
    return y_norm * y_std + y_mean


# 创建多项式特征
def create_polynomial_features(x, degree):
    # 创建多项式特征矩阵
    X = np.ones((len(x), 1))
    for i in range(1, degree + 1):
        X = np.column_stack((X, x ** i))
    return X


# OLS模型类
class OLSModel:
    def __init__(self, degree):
        self.degree = degree
        self.weights = None
        self.x_mean = None
        self.x_std = None
        self.y_mean = None
        self.y_std = None

    # 训练模型
    def train(self, x, y):
        # 保存标准化参数
        self.x_mean = np.mean(x)
        self.x_std = np.std(x)
        self.y_mean = np.mean(y)
        self.y_std = np.std(y)

        # 标准化数据
        x_norm = (x - self.x_mean) / self.x_std if self.x_std > 0 else x
        y_norm = (y - self.y_mean) / self.y_std if self.y_std > 0 else y

        # 创建多项式特征
        X = create_polynomial_features(x_norm, self.degree)

        # 使用最小二乘法求解权重
        # weights = (X^T X)^(-1) X^T y
        self.weights = np.linalg.pinv(X.T @ X) @ X.T @ y_norm

    # 预测
    def predict(self, x):
        # 标准化输入
        x_norm = (x - self.x_mean) / self.x_std if self.x_std > 0 else x

        # 创建多项式特征
        X = create_polynomial_features(x_norm, self.degree)

        # 预测
        y_pred_norm = X @ self.weights

        # 反标准化
        y_pred = denormalize_y(y_pred_norm, self.y_mean, self.y_std)
        return y_pred

    # 评估模型性能
    def evaluate(self, x, y):
        predictions = self.predict(x)
        mse = np.mean(np.square(predictions - y))
        rmse = np.sqrt(mse)

        # 计算R²
        ss_res = np.sum(np.square(y - predictions))
        ss_tot = np.sum(np.square(y - np.mean(y)))
        r2 = 1 - (ss_res / ss_tot)

        return mse, rmse, r2


# 可视化拟合结果
def visualize_fit(x, y, ols_model):
    plt.figure(figsize=(12, 8))

    # 绘制原始数据点
    plt.scatter(x, y, color='blue', label='原始数据点')

    # 生成密集的x值用于绘制平滑曲线
    x_dense = np.linspace(min(x), max(x), 200)

    # 预测并绘制拟合曲线
    y_dense_pred = ols_model.predict(x_dense)
    plt.plot(x_dense, y_dense_pred, color='red', linewidth=2, label=f'OLS拟合曲线 (次数={ols_model.degree})')

    # 添加标题和标签
    plt.title(f'OLS多项式拟合 (多项式次数: {ols_model.degree})')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best')

    # 显示图表
    plt.tight_layout()
    plt.show()


# 可视化不同多项式次数的性能对比
def visualize_degree_comparison(x, y, degree_range=(1, 10)):
    degrees = range(degree_range[0], degree_range[1] + 1)
    mse_list = []
    rmse_list = []
    r2_list = []
    models = {}

    print("\n不同多项式次数的性能对比:")
    print("多项式次数 | 均方误差(MSE)  | 均方根误差(RMSE) | R^2分数")
    print("----------|---------------|-----------------|-------")

    # 测试不同次数的多项式
    for degree in degrees:
        ols_model = OLSModel(degree)
        ols_model.train(x, y)
        mse, rmse, r2 = ols_model.evaluate(x, y)

        mse_list.append(mse)
        rmse_list.append(rmse)
        r2_list.append(r2)
        models[degree] = ols_model

        print(f"{degree:10d} | {mse:13.6f} | {rmse:15.6f} | {r2:7.4f}")

    # 找出最优多项式次数
    best_degree_r2 = degrees[np.argmax(r2_list)]
    best_degree_mse = degrees[np.argmin(mse_list)]

    print(f"\n基于R^2分数的最优多项式次数: {best_degree_r2}")
    print(f"基于MSE的最优多项式次数: {best_degree_mse}")

    # 可视化不同多项式次数的性能对比
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # MSE和RMSE对比
    ax1.plot(degrees, mse_list, marker='o', linestyle='-', color='blue', label='MSE')
    ax1.plot(degrees, rmse_list, marker='s', linestyle='-', color='green', label='RMSE')
    ax1.set_title('不同多项式次数的MSE和RMSE对比')
    ax1.set_xlabel('多项式次数')
    ax1.set_ylabel('误差值')
    ax1.grid(True, linestyle='--', alpha=0.7)
    ax1.legend(loc='best')

    # R²分数对比
    ax2.plot(degrees, r2_list, marker='^', linestyle='-', color='red', label='R^2')
    ax2.set_title('不同多项式次数的R^2分数对比')
    ax2.set_xlabel('多项式次数')
    ax2.set_ylabel('R^2分数')
    ax2.set_ylim(max(0, min(r2_list) - 0.1), 1.0)
    ax2.grid(True, linestyle='--', alpha=0.7)
    ax2.legend(loc='best')

    plt.tight_layout()
    plt.show()

    # 可视化最优模型的拟合效果
    best_model = models[best_degree_r2]
    print(f"\n最优模型 (次数={best_degree_r2}) 的拟合结果:")
    visualize_fit(x, y, best_model)

    # 返回所有模型和性能指标
    return models, mse_list, rmse_list, r2_list


# 可视化残差分析
def visualize_residuals(x, y, ols_model):
    # 计算预测值
    y_pred = ols_model.predict(x)

    # 计算残差
    residuals = y - y_pred

    # 创建残差图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # 残差与预测值的关系图
    ax1.scatter(y_pred, residuals, color='purple')
    ax1.axhline(y=0, color='black', linestyle='-', alpha=0.3)
    ax1.set_title('残差与预测值关系图')
    ax1.set_xlabel('预测值')
    ax1.set_ylabel('残差')
    ax1.grid(True, linestyle='--', alpha=0.7)

    # 残差直方图
    ax2.hist(residuals, bins=10, alpha=0.7, color='orange', edgecolor='black')
    ax2.set_title('残差分布图')
    ax2.set_xlabel('残差值')
    ax2.set_ylabel('频数')
    ax2.grid(True, linestyle='--', alpha=0.7)

    plt.tight_layout()
    plt.show()


# 可视化权重分析
def visualize_weights(ols_model):
    plt.figure(figsize=(10, 6))

    # 绘制权重分布
    weights = ols_model.weights
    degrees = np.arange(len(weights))

    plt.bar(degrees, weights, color='skyblue')
    plt.title(f'OLS模型权重分布 (多项式次数: {ols_model.degree})')
    plt.xlabel('权重索引 (0为偏置项)')
    plt.ylabel('权重值')
    plt.grid(True, linestyle='--', alpha=0.7, axis='y')

    # 添加数值标签
    for i, v in enumerate(weights):
        plt.text(i, v, f'{v:.4f}', ha='center', va='bottom')

    plt.tight_layout()
    plt.show()


# 主函数
def main():
    print("OLS多项式回归模型")
    print("===============")

    # 加载数据
    x, y = load_data()

    # 询问用户是否进行多项式次数优化
    optimize = input("是否进行多项式次数优化? (y/n, 默认n): ").strip().lower()

    if optimize == 'y':
        # 进行多项式次数优化
        models, mse_list, rmse_list, r2_list = visualize_degree_comparison(x, y)

        # 选择最佳模型
        best_degree = np.arange(len(r2_list)) + 1
        best_degree = best_degree[np.argmax(r2_list)]
        best_model = models[best_degree]

        # 可视化残差分析
        print("\n残差分析:")
        visualize_residuals(x, y, best_model)

        # 可视化权重分布
        print("\n权重分布:")
        visualize_weights(best_model)
    else:
        # 使用默认次数
        degree = int(input("请输入多项式次数 (默认5): ").strip() or "5")

        # 创建并训练模型
        ols_model = OLSModel(degree)
        ols_model.train(x, y)

        # 评估模型
        mse, rmse, r2 = ols_model.evaluate(x, y)
        print(f"\n模型性能:")
        print(f"均方误差(MSE): {mse:.6f}")
        print(f"均方根误差(RMSE): {rmse:.6f}")
        print(f"R^2分数: {r2:.6f}")

        # 可视化拟合结果
        print("\n拟合结果:")
        visualize_fit(x, y, ols_model)

        # 可视化残差分析
        print("\n残差分析:")
        visualize_residuals(x, y, ols_model)

        # 可视化权重分布
        print("\n权重分布:")
        visualize_weights(ols_model)

    print("\n程序执行完毕！")


if __name__ == "__main__":
    main()
