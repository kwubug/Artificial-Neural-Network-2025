# neural_sandbox.py - 完整神经网络沙箱
# 支持Python 3.7+ (完全兼容3.12.7)

import numpy as np
import matplotlib
matplotlib.use('TkAgg')  # 解决图形后端问题
import matplotlib.pyplot as plt
from itertools import product
import random
import time

# ==================== 1. HOPFIELD NETWORK ====================
class HopfieldNetwork:
    """离散型Hopfield神经网络"""
    def __init__(self, n_neurons, zero_diagonal=True):
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.zero_diagonal = zero_diagonal
    
    def train_hebbian(self, patterns):
        """Hebbian学习规则"""
        patterns = np.array(patterns)
        self.weights = patterns.T @ patterns / len(patterns)
        if self.zero_diagonal:
            np.fill_diagonal(self.weights, 0)
    
    def energy(self, state):
        """计算网络能量"""
        return -0.5 * state @ self.weights @ state.T
    
    def update_async(self, state, max_iters=1000):
        """异步更新"""
        state = np.array(state).copy()
        energy_hist = [self.energy(state)]
        
        for step in range(max_iters):
            old_state = state.copy()
            for i in np.random.permutation(self.n_neurons):
                net_input = np.dot(self.weights[i, :], state)
                state[i] = 1 if net_input >= 0 else -1
            energy_hist.append(self.energy(state))
            if np.array_equal(state, old_state):
                return state, step + 1, energy_hist
        return state, max_iters, energy_hist
    
    def find_attractors(self):
        """寻找所有吸引子"""
        attractors = []
        energies = []
        for bits in product([-1, 1], repeat=self.n_neurons):
            state = np.array(bits)
            final_state, _, _ = self.update_async(state, max_iters=1)
            if np.array_equal(state, final_state):
                attractors.append(state)
                energies.append(self.energy(state))
        return np.array(attractors), np.array(energies)
    
    def add_noise(self, pattern, noise_ratio):
        """添加噪声"""
        pattern = np.array(pattern).copy()
        n_noise = int(len(pattern) * noise_ratio)
        noise_idx = np.random.choice(len(pattern), n_noise, replace=False)
        pattern[noise_idx] *= -1
        return pattern


# ==================== 2. TSP SOLVER ====================
class TSPSolver:
    """Hopfield-Tank模型解决TSP"""
    def __init__(self, n_cities, A=500, B=500, C=200, D=100, step_size=0.01):
        self.n_cities = n_cities
        self.state = np.random.uniform(0.2, 0.8, (n_cities, n_cities))
        self.A, self.B, self.C, self.D = A, B, C, D
        self.step_size = step_size
        self.distances = None
        self.coords = None
    
    def generate_cities(self, seed=42):
        """生成随机城市坐标"""
        np.random.seed(seed)
        self.coords = np.random.rand(self.n_cities, 2) * 100
        self._calc_distances()
        return self.coords
    
    def _calc_distances(self):
        """计算距离矩阵"""
        self.distances = np.zeros((self.n_cities, self.n_cities))
        for i in range(self.n_cities):
            for j in range(self.n_cities):
                if i != j:
                    self.distances[i, j] = np.linalg.norm(self.coords[i] - self.coords[j])
    
    def energy(self):
        """计算TSP能量函数"""
        row_sum = np.sum(self.state, axis=1)
        col_sum = np.sum(self.state, axis=0)
        total_sum = np.sum(self.state)
        
        E1 = self.A * np.sum((row_sum - 1) ** 2)
        E2 = self.B * np.sum((col_sum - 1) ** 2)
        E3 = self.C * (total_sum - self.n_cities) ** 2
        
        E4 = 0
        for i in range(self.n_cities):
            for j in range(self.n_cities):
                for k in range(self.n_cities):
                    k_next = (k + 1) % self.n_cities
                    E4 += self.D * self.distances[i, j] * self.state[i, k] * self.state[j, k_next]
        
        return E1 + E2 + E3 + E4
    
    def update_async(self, max_iters=1500, early_stop=50):
        """异步更新"""
        energy_hist = []
        best_energy, no_improve = float('inf'), 0
        
        for step in range(max_iters):
            for i, j in np.random.permutation(list(np.ndindex(self.n_cities, self.n_cities))):
                net = -(self.A * (np.sum(self.state[i, :]) - 1) +
                        self.B * (np.sum(self.state[:, j]) - 1) +
                        self.C * (np.sum(self.state) - self.n_cities) +
                        self.D * sum(self.distances[i, k] * 
                                   (self.state[k, (j+1)%self.n_cities] + self.state[k, (j-1)%self.n_cities])
                                   for k in range(self.n_cities)))
                
                self.state[i, j] += self.step_size * net
                self.state[i, j] = np.clip(self.state[i, j], 0.01, 0.99)
            
            current_energy = self.energy()
            energy_hist.append(current_energy)
            
            if current_energy < best_energy - 10:
                best_energy, no_improve = current_energy, 0
            else:
                no_improve += 1
            
            if no_improve > early_stop:
                print(f"Early stop at step {step+1}")
                break
        
        return step + 1, energy_hist
    
    def decode_solution(self, threshold=0.5):
        """解码解"""
        binary_state = (self.state > threshold).astype(int)
        path = np.argmax(self.state, axis=1)
        valid = np.all(binary_state.sum(axis=1) == 1) and np.all(binary_state.sum(axis=0) == 1)
        return path.tolist(), valid
    
    def path_length(self, path):
        """计算路径长度"""
        return sum(self.distances[path[i], path[(i+1)%len(path)]] for i in range(len(path)))
    
    def plot_solution(self, path, valid, save_path=None):
        """可视化TSP解"""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        
        coords = self.coords
        for i in range(len(path)):
            curr, next_city = path[i], path[(i+1)%len(path)]
            ax1.plot([coords[curr, 0], coords[next_city, 0]],
                    [coords[curr, 1], coords[next_city, 1]],
                    'b-', linewidth=2, alpha=0.6)
            ax1.arrow(coords[curr, 0], coords[curr, 1],
                     (coords[next_city, 0]-coords[curr, 0])*0.6,
                     (coords[next_city, 1]-coords[curr, 1])*0.6,
                     head_width=3, head_length=4, fc='red', ec='red')
        
        ax1.scatter(coords[:, 0], coords[:, 1], c='green', s=100, zorder=5)
        for i in range(self.n_cities):
            ax1.text(coords[i, 0]+2, coords[i, 1]+2, f'C{i}', fontweight='bold')
        
        length = self.path_length(path)
        ax1.set_title(f'TSP Path (Length: {length:.2f}, Valid: {valid})')
        ax1.set_xlabel('X')
        ax1.set_ylabel('Y')
        ax1.grid(True, alpha=0.3)
        
        im = ax2.imshow(self.state, cmap='viridis', vmin=0, vmax=1)
        ax2.set_title('Neuron State Matrix')
        ax2.set_xlabel('Visit Order')
        ax2.set_ylabel('City')
        plt.colorbar(im, ax=ax2)
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()


# ==================== 3. BOLTZMANN MACHINE ====================
class BoltzmannMachine3N:
    """3神经元玻尔兹曼机"""
    def __init__(self, weights, biases, temperature=1.0):
        self.n_neurons = 3
        self.weights = np.array(weights)
        self.biases = np.array(biases)
        self.T = temperature
        
        assert self.weights.shape == (3, 3)
        assert np.allclose(self.weights, self.weights.T)
        assert np.all(np.diag(self.weights) == 0)
        
        self.state = np.random.choice([-1, 1], size=3)
        self.all_states = np.array(list(product([-1, 1], repeat=3)))
        self.history = {'states': [], 'energies': []}
    
    def energy(self, state):
        """计算状态能量"""
        return -0.5 * state @ self.weights @ state - np.dot(self.biases, state)
    
    def boltzmann_prob(self, state):
        """玻尔兹曼概率"""
        return np.exp(-self.energy(state) / self.T)
    
    def equilibrium_dist(self):
        """平衡分布"""
        probs = np.array([self.boltzmann_prob(s) for s in self.all_states])
        return probs / np.sum(probs)
    
    def update(self):
        """单步随机更新"""
        i = np.random.randint(0, self.n_neurons)
        net_input = np.dot(self.weights[i, :], self.state) + self.biases[i]
        prob_on = 1 / (1 + np.exp(-net_input / self.T))
        self.state[i] = 1 if np.random.rand() < prob_on else -1
        return self.state.copy()
    
    def run(self, steps=5000, burn_in=1000):
        """运行模拟"""
        print(f"\nBM Run: {steps} steps (burn-in: {burn_in})")
        print(f"Initial: state={self.state}, E={self.energy(self.state):.3f}")
        
        self.history = {'states': [], 'energies': []}
        
        for step in range(steps):
            state = self.update()
            if step >= burn_in:
                self.history['states'].append(state.copy())
                self.history['energies'].append(self.energy(state))
            
            if step % 2000 == 0:
                print(f"Step {step}: state={state}, E={self.energy(state):.3f}")
        
        print(f"Final: state={self.state}, E={self.energy(self.state):.3f}")
        return self.history
    
    def plot_network(self, save_path=None):
        """可视化网络结构"""
        fig, ax = plt.subplots(figsize=(8, 6))
        positions = {0: [0, 1], 1: [-0.866, -0.5], 2: [0.866, -0.5]}
        
        for i in range(3):
            pos = positions[i]
            color = 'red' if self.state[i] == 1 else 'blue'
            size = 3000 if self.state[i] == 1 else 2000
            ax.scatter(pos[0], pos[1], s=size, c=color, alpha=0.7, edgecolors='black')
            ax.text(pos[0], pos[1], f'N{i}\n({self.state[i]:+d})', 
                   ha='center', va='center', fontweight='bold')
            ax.text(pos[0], pos[1]+0.3, f'b={self.biases[i]:.2f}', ha='center')
        
        for i in range(3):
            for j in range(i+1, 3):
                pi, pj = positions[i], positions[j]
                w = self.weights[i, j]
                ax.plot([pi[0], pj[0]], [pi[1], pj[1]], 
                       linewidth=abs(w)*3, color='green' if w>0 else 'purple', alpha=0.7)
                mid = (np.array(pi) + pj) / 2
                ax.text(mid[0], mid[1], f'{w:.2f}', 
                       bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.5, 1.5)
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_title(f'BM Network (T={self.T})\nE={self.energy(self.state):.3f}', fontweight='bold')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def plot_state_space(self, save_path=None):
        """可视化状态空间和平衡分布"""
        fig = plt.figure(figsize=(14, 6))
        ax1 = fig.add_subplot(1, 2, 1, projection='3d')
        ax2 = fig.add_subplot(1, 2, 2)
        
        theory_dist = self.equilibrium_dist()
        
        # Empirical
        if len(self.history['states']) > 0:
            state_idx = [self._state_to_index(s) for s in self.history['states']]
            counts = np.bincount(state_idx, minlength=8)
            empirical_dist = counts / len(state_idx)
        else:
            empirical_dist = np.zeros(8)
        
        # 3D cube
        cube_coords = np.array([
            [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
            [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]
        ])
        
        for i, (state, coord) in enumerate(zip(self.all_states, cube_coords)):
            color = plt.cm.viridis(theory_dist[i])
            ax1.scatter(coord[0], coord[1], coord[2], 
                       s=theory_dist[i]*5000+100, c=[color], alpha=0.7, edgecolors='black')
            ax1.text(coord[0]*1.1, coord[1]*1.1, coord[2]*1.1, 
                    f'({state[0]:+d},{state[1]:+d},{state[2]:+d})', fontsize=8)
        
        # Probability distribution
        states = [f'({s[0]:+d},{s[1]:+d},{s[2]:+d})' for s in self.all_states]
        x = np.arange(8)
        width = 0.35
        ax2.bar(x - width/2, theory_dist, width, label='Theory', alpha=0.8, color='skyblue')
        ax2.bar(x + width/2, empirical_dist, width, label='Empirical', alpha=0.8, color='coral')
        ax2.set_xlabel('States')
        ax2.set_ylabel('Probability')
        ax2.set_title('Equilibrium Distribution')
        ax2.set_xticks(x)
        ax2.set_xticklabels(states, rotation=45)
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def _state_to_index(self, state):
        return int((state[0] + 1) / 2 * 4 + (state[1] + 1) / 2 * 2 + (state[2] + 1) / 2)


# ==================== 4. SANDBOX UI ====================
class NNSandbox:
    """神经网络沙箱主界面"""
    def __init__(self):
        self.networks = {
            '1': 'Hopfield Network',
            '2': 'TSP Solver',
            '3': 'Boltzmann Machine'
        }
    
    def print_banner(self):
        print("\n" + "=" * 70)
        print(" " * 15 + "NEURAL NETWORK SANDBOX")
        print(" Integrated Platform for Hopfield, TSP, and Boltzmann Machine")
        print("=" * 70)
    
    def main_menu(self):
        """主菜单循环"""
        while True:
            self.print_banner()
            print("\n[Main Menu]")
            for key, name in self.networks.items():
                print(f"  {key}. {name}")
            print("  0. Exit")
            
            choice = input("\nSelect Network (0-3): ").strip()
            
            if choice == '0':
                print("\nGoodbye!")
                break
            elif choice == '1':
                self.hopfield_demo()
            elif choice == '2':
                self.tsp_demo()
            elif choice == '3':
                self.boltzmann_demo()
            else:
                print("Invalid choice! Press Enter to continue...")
                input()
    
    def hopfield_demo(self):
        """Hopfield网络演示"""
        print("\n" + "="*60)
        print("HOPFIELD NETWORK - Pattern Recovery Demo")
        print("="*60)
        
        n_neurons = 8
        patterns = [
            np.array([1, 1, 1, 1, -1, -1, -1, -1]),
            np.array([-1, -1, -1, -1, 1, 1, 1, 1]),
            np.array([1, -1, 1, -1, 1, -1, 1, -1])
        ]
        
        hopfield = HopfieldNetwork(n_neurons)
        hopfield.train_hebbian(patterns)
        
        print(f"\nTrained {len(patterns)} patterns on {n_neurons} neurons")
        # Python 3.12完美支持的f-string
        pattern_energies = [hopfield.energy(p) for p in patterns]
        print(f"Pattern energies: {[f'{e:.2f}' for e in pattern_energies]}")
        
        original = patterns[0]
        noisy = hopfield.add_noise(original.copy(), 0.3)
        
        print(f"\nRecovery Test:")
        print(f"Original: {original}")
        print(f"Noisy:    {noisy}")
        
        recovered, steps, energy_hist = hopfield.update_async(noisy, max_iters=100)
        
        print(f"\nRecovered: {recovered}")
        print(f"Steps: {steps}")
        print(f"Match Original: {np.array_equal(recovered, original)}")
        print(f"Final Energy: {energy_hist[-1]:.2f}")
        
        # 可视化
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        ax1.plot(energy_hist, 'b-o', markersize=4)
        ax1.set_title('Energy Convergence')
        ax1.set_xlabel('Iterations')
        ax1.set_ylabel('Energy')
        ax1.grid(True, alpha=0.3)
        
        attractors, energies = hopfield.find_attractors()
        ax2.bar(range(len(energies)), energies, color='skyblue', edgecolor='black')
        ax2.set_title(f'Found {len(attractors)} Attractors')
        ax2.set_xlabel('Attractor Index')
        ax2.set_ylabel('Energy')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig("hopfield_results.png", dpi=150)
        plt.show()
        
        print("\n✅ Hopfield demo complete! Plot saved as 'hopfield_results.png'")
        input("Press Enter to continue...")
    
    def tsp_demo(self):
        """TSP求解器演示"""
        print("\n" + "="*60)
        print("TSP SOLVER - Hopfield-Tank Model")
        print("="*60)
        
        n_cities = int(input("Enter number of cities (4-12): ").strip())
        
        tsp = TSPSolver(n_cities, A=500, B=500, C=200, D=100)
        tsp.generate_cities()
        
        print(f"\nRunning TSP for {n_cities} cities...")
        print(f"Initial energy: {tsp.energy():.2f}")
        
        steps, energy_hist = tsp.update_async(max_iters=1500)
        
        path, valid = tsp.decode_solution()
        length = tsp.path_length(path)
        
        print(f"\nFinal path: {path}")
        print(f"Valid: {valid}")
        print(f"Path length: {length:.2f}")
        print(f"Iterations: {steps}")
        
        tsp.plot_solution(path, valid, save_path="tsp_solution.png")
        
        plt.figure(figsize=(10, 5))
        plt.plot(energy_hist, 'b-', linewidth=2)
        plt.title('TSP Energy Convergence')
        plt.xlabel('Iterations')
        plt.ylabel('Energy')
        plt.grid(True, alpha=0.3)
        plt.savefig("tsp_convergence.png", dpi=150)
        plt.show()
        
        print("\n✅ TSP demo complete! Plots saved as 'tsp_solution.png' and 'tsp_convergence.png'")
        input("Press Enter to continue...")
    
    def boltzmann_demo(self):
        """玻尔兹曼机演示"""
        print("\n" + "="*60)
        print("BOLTZMANN MACHINE - 3 Neurons")
        print("="*60)
        
        weights = np.array([[0.0, 0.5, -0.3], [0.5, 0.0, 0.4], [-0.3, 0.4, 0.0]])
        biases = np.array([0.1, -0.2, 0.3])
        T = 1.0
        
        print(f"\nNetwork Parameters:")
        print(f"Weights:\n{weights}")
        print(f"Biases: {biases}")
        print(f"Temperature: {T}")
        
        bm = BoltzmannMachine3N(weights, biases, T)
        
        print("\n[1] Network Structure")
        bm.plot_network(save_path="bm_network.png")
        
        steps = int(input("\nEnter simulation steps (1000-10000): ").strip())
        bm.run(steps=steps, burn_in=1000)
        
        print("\n[2] Equilibrium Distribution")
        bm.plot_state_space(save_path="bm_equilibrium.png")
        
        theory = bm.equilibrium_dist()
        most_probable = bm.all_states[np.argmax(theory)]
        print(f"\nMost probable state: {most_probable}")
        print(f"Max probability: {np.max(theory):.4f}")
        
        print("\n✅ Boltzmann demo complete! Plots saved as 'bm_network.png' and 'bm_equilibrium.png'")
        input("Press Enter to continue...")


# ==================== 5. MAIN ENTRY ====================
def main():
    """主函数"""
    print("\n" + "="*70)
    print("NEURAL NETWORK SANDBOX - Starting...")
    print(f"Python Version: 3.12.7 (f-string support: OK)")
    print("="*70)
    
    # 设置随机种子保证可重复性
    np.random.seed(42)
    random.seed(42)
    
    # 创建并启动沙箱
    sandbox = NNSandbox()
    
    try:
        sandbox.main_menu()
    except KeyboardInterrupt:
        print("\n\n✅ Sandbox terminated by user.")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*70)
    print("SANDBOX SHUTDOWN COMPLETE")
    print("Generated files: hopfield_results.png, tsp_solution.png, tsp_convergence.png, bm_network.png, bm_equilibrium.png")
    print("="*70)


if __name__ == "__main__":
    main()