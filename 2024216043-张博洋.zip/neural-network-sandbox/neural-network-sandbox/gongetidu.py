import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# ---------- 目标函数 ----------
def f(x, y):
    """二次函数 f(x,y) = x^2 + 2y^2"""
    return x**2 + 2*y**2

def grad_f(x, y):
    """梯度"""
    return np.array([2*x, 4*y])

# ---------- 共轭梯度法 ----------
class ConjugateGradientMethod:
    def __init__(self, start_point, tol=1e-6, max_iter=20):
        self.x = np.array(start_point, dtype=float)
        self.tol = tol
        self.max_iter = max_iter
        self.path = [self.x.copy()]

    def run(self):
        g = grad_f(*self.x)
        d = -g
        for k in range(self.max_iter):
            if np.linalg.norm(g) < self.tol:
                break

            # 计算步长 alpha = (g^T g) / (d^T A d), 对应二次函数 f(x) = 0.5 x^T A x
            A = np.array([[2, 0], [0, 4]])  # Hessian
            alpha = np.dot(g, g) / np.dot(d, A @ d)
            self.x = self.x + alpha * d
            self.path.append(self.x.copy())

            g_new = grad_f(*self.x)
            beta = np.dot(g_new, g_new) / np.dot(g, g)
            d = -g_new + beta * d
            g = g_new
        return np.array(self.path)

# ---------- 可视化 ----------
start = [-3, 4]
cg = ConjugateGradientMethod(start_point=start)
path = cg.run()

# 绘制等高线
x = np.linspace(-4, 4, 100)
y = np.linspace(-4, 4, 100)
X, Y = np.meshgrid(x, y)
Z = f(X, Y)

fig, ax = plt.subplots(figsize=(6, 6))
ax.contour(X, Y, Z, levels=30, cmap='viridis')
point_plot, = ax.plot([], [], 'ro-', lw=2)

def init():
    point_plot.set_data([], [])
    return point_plot,

def update(frame):
    point_plot.set_data(path[:frame+1, 0], path[:frame+1, 1])
    return point_plot,

ani = FuncAnimation(fig, update, frames=len(path), init_func=init, blit=True, interval=500)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Conjugate Gradient Method Visualization')
plt.show()
