import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]
class DiscreteHopfieldNetwork:
    """离散型Hopfield神经网络实现"""
    
    def __init__(self, n_neurons):
        """初始化Hopfield网络"""
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))  # 权重矩阵
        self.patterns = None  # 存储的模式
    
    def train(self, patterns):
        """使用Hebbian学习规则训练网络"""
        n_patterns = patterns.shape[0]
        
        # 检查模式是否符合要求（元素应为-1或1）
        if np.any(np.abs(patterns) != 1):
            raise ValueError("模式中的元素必须为1或-1")
        
        # 确保模式维度匹配
        if patterns.shape[1] != self.n_neurons:
            raise ValueError(f"模式的维度必须为 {self.n_neurons}")
        
        self.patterns = patterns.copy()
        
        # 计算权重矩阵（无自连接）
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                if i != j:
                    self.weights[i, j] = (1 / self.n_neurons) * np.sum(
                        patterns[:, i] * patterns[:, j]
                    )
    
    def async_update(self, state, max_iter=1000, return_history=False):
        """异步更新网络状态"""
        state = state.copy()
        energy_history = [self.calculate_energy(state)]
        state_history = [state.copy()] if return_history else None
        
        for _ in range(max_iter):
            # 随机选择一个神经元进行更新
            neuron_idx = np.random.randint(self.n_neurons)
            
            # 计算激活值
            activation = np.dot(self.weights[neuron_idx], state)
            
            # 更新神经元状态
            old_state = state[neuron_idx]
            state[neuron_idx] = 1 if activation >= 0 else -1
            
            # 记录能量变化
            new_energy = self.calculate_energy(state)
            energy_history.append(new_energy)
            
            # 记录状态历史（如果需要）
            if return_history:
                state_history.append(state.copy())
            
            # 如果状态不再变化且能量稳定，提前停止
            if (old_state == state[neuron_idx] and 
                len(energy_history) > 1 and 
                energy_history[-1] == energy_history[-2]):
                break
        
        results = [state, energy_history]
        if return_history:
            results.append(state_history)
            
        return tuple(results)
    
    def calculate_energy(self, state):
        """计算当前状态的能量"""
        return -0.5 * np.dot(np.dot(state.T, self.weights), state)
    
    def is_attractor(self, state, tolerance=1e-6):
        """判断一个状态是否是吸引子"""
        test_state = state.copy()
        # 对所有神经元进行一次更新
        for i in range(self.n_neurons):
            activation = np.dot(self.weights[i], test_state)
            test_state[i] = 1 if activation >= 0 else -1
        
        # 如果更新后状态不变，则是吸引子
        return np.allclose(state, test_state, atol=tolerance)
    
    def find_attractors(self, max_candidates=1000):
        """寻找网络的所有吸引子"""
        attractors = []
        
        # 首先检查存储的模式是否为吸引子
        if self.patterns is not None:
            for pattern in self.patterns:
                if self.is_attractor(pattern) and not any(np.array_equal(pattern, a) for a in attractors):
                    attractors.append(pattern)
        
        # 随机生成状态并使其收敛以寻找新的吸引子
        for _ in range(max_candidates):
            state = np.random.choice([-1, 1], size=self.n_neurons)
            final_state, _ = self.async_update(state)
            
            if self.is_attractor(final_state) and not any(np.array_equal(final_state, a) for a in attractors):
                attractors.append(final_state)
        
        return attractors

def create_image_patterns(image_size=(5,5), n_patterns=3):
    """创建图像模式（用于可视化）"""
    patterns = []
    n_neurons = image_size[0] * image_size[1]
    
    # 创建几个简单的图像模式
    for i in range(n_patterns):
        pattern = np.random.choice([-1, 1], size=n_neurons)
        patterns.append(pattern)
    
    return np.array(patterns), image_size

def add_noise(pattern, noise_level=0.3):
    """为模式添加噪声"""
    noisy_pattern = pattern.copy()
    n_noise = int(noise_level * len(pattern))
    noise_indices = np.random.choice(len(pattern), size=n_noise, replace=False)
    noisy_pattern[noise_indices] *= -1  # 翻转噪声位置的比特
    return noisy_pattern

def visualize_patterns(patterns, image_size, titles=None):
    """可视化模式（将1D向量转换为2D图像）"""
    n_patterns = len(patterns)
    plt.figure(figsize=(3 * n_patterns, 3))
    
    for i, pattern in enumerate(patterns):
        plt.subplot(1, n_patterns, i+1)
        plt.imshow(pattern.reshape(image_size), cmap='gray', vmin=-1, vmax=1)
        if titles and i < len(titles):
            plt.title(titles[i])
        plt.axis('off')
    
    plt.tight_layout()
    plt.show()

def sandbox_demo():
    """Hopfield神经网络沙箱演示"""
    # 设置随机种子，保证结果可复现
    np.random.seed(42)
    
    # 创建网络和模式
    image_size = (5, 5)  # 5x5的图像，共25个神经元
    n_neurons = image_size[0] * image_size[1]
    n_patterns = 3       # 存储3个模式
    
    # 创建并训练网络
    hopfield = DiscreteHopfieldNetwork(n_neurons)
    patterns, _ = create_image_patterns(image_size, n_patterns)
    hopfield.train(patterns)
    
    print(f"已创建包含 {n_neurons} 个神经元的Hopfield网络")
    print(f"已训练 {n_patterns} 个模式作为记忆")
    
    # 显示原始模式
    print("\n原始模式:")
    visualize_patterns(patterns, image_size, [f"模式 {i+1}" for i in range(n_patterns)])
    
    # 检查原始模式是否为吸引子
    print("\n吸引子检查:")
    for i, pattern in enumerate(patterns):
        is_attr = hopfield.is_attractor(pattern)
        print(f"模式 {i+1} 是吸引子: {is_attr}")
    
    # 测试带噪声的模式恢复
    noise_level = 0.3
    test_idx = 0  # 选择第一个模式进行测试
    noisy_pattern = add_noise(patterns[test_idx], noise_level)
    
    print(f"\n测试带 {noise_level*100}% 噪声的模式恢复...")
    final_state, energy_history, state_history = hopfield.async_update(
        noisy_pattern, max_iter=500, return_history=True
    )
    
    # 显示恢复过程
    print("\n恢复过程:")
    # 动态生成选择步骤，确保不超出索引范围
    max_step = len(state_history) - 1
    selected_steps = [0, 1, 5, 10]
    # 过滤掉超出范围的步骤，并确保包含最后一步
    selected_steps = [s for s in selected_steps if s <= max_step]
    if not selected_steps or selected_steps[-1] != max_step:
        selected_steps.append(max_step)
    # 去重并保持顺序
    selected_steps = list(dict.fromkeys(selected_steps))
    
    selected_states = [state_history[i] for i in selected_steps]
    titles = [f"步骤 {i}" for i in selected_steps]
    visualize_patterns(selected_states, image_size, titles)
    
    # 显示能量变化
    plt.figure(figsize=(10, 4))
    plt.plot(energy_history)
    plt.title("网络能量变化 (异步更新过程)")
    plt.xlabel("迭代次数")
    plt.ylabel("能量")
    plt.grid(True)
    plt.show()
    
    # 寻找所有吸引子
    print("\n寻找网络中的所有吸引子...")
    attractors = hopfield.find_attractors(max_candidates=500)
    print(f"找到 {len(attractors)} 个吸引子")
    
    # 显示吸引子
    print("\n发现的吸引子:")
    visualize_patterns(attractors, image_size, [f"吸引子 {i+1}" for i in range(len(attractors))])
    
    # 显示吸引子能量
    print("\n吸引子能量:")
    for i, attractor in enumerate(attractors):
        energy = hopfield.calculate_energy(attractor)
        print(f"吸引子 {i+1} 能量: {energy:.4f}")

if __name__ == "__main__":
    sandbox_demo()