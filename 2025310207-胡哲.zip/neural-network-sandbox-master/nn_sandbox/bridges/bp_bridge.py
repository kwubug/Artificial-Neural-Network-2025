import time
import PyQt5.QtCore
from nn_sandbox.backend.algorithms import BPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BPBridge(Bridge):
    """BP算法的QML桥接类"""
    
    # 基本属性
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    
    # 训练参数
    total_epoches = BridgeProperty(50)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.5)
    search_iteration_constant = BridgeProperty(10000)
    test_ratio = BridgeProperty(0.3)
    
    # 网络结构参数
    input_nodes = BridgeProperty(2)
    hidden_nodes = BridgeProperty(5)
    output_nodes = BridgeProperty(1)
    
    # 激活函数类型
    activation_type = BridgeProperty('unipolar')  # 'unipolar' 或 'bipolar'
    
    # 权重初始化范围
    weight_init_min = BridgeProperty(-1.0)
    weight_init_max = BridgeProperty(1.0)
    
    # 训练状态
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_error = BridgeProperty(0.0)
    
    # 网络信息
    network_info = BridgeProperty({})
    
    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        """启动BP算法"""
        self.bp_algorithm = ObservableBPAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
            input_nodes=self.input_nodes,
            hidden_nodes=self.hidden_nodes,
            output_nodes=self.output_nodes,
            activation_type=self.activation_type,
            weight_init_range=(self.weight_init_min, self.weight_init_max)
        )
        self.bp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        """停止BP算法"""
        if self.bp_algorithm:
            self.bp_algorithm.stop()

    @PyQt5.QtCore.pyqtSlot()
    def reset_network(self):
        """重置网络"""
        if self.bp_algorithm:
            self.bp_algorithm._initialize_network()
            self.notify('network_info', self.bp_algorithm.get_network_info())

    @PyQt5.QtCore.pyqtSlot(result=float)
    def predict(self, inputs):
        """预测函数"""
        if self.bp_algorithm:
            return self.bp_algorithm.predict(inputs)
        return 0.0

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableBPAlgorithm(Observable, BPAlgorithm):
    """可观察的BP算法类"""
    
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self.has_initialized = False
        Observable.__init__(self, observer)
        BPAlgorithm.__init__(self, **kwargs)
        self.has_initialized = True
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations' and self.has_initialized:
            self.notify(name, value)
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate', 'current_error') and self.has_initialized:
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None and self.has_initialized:
            self.notify(name, value.tolist())

    def run(self):
        """运行算法"""
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        self.notify('network_info', self.get_network_info())
        
        # 确保数据集正确传递
        if hasattr(self, 'training_dataset') and self.training_dataset is not None:
            self.notify('training_dataset', self.training_dataset.tolist())
        if hasattr(self, 'testing_dataset') and self.testing_dataset is not None:
            self.notify('testing_dataset', self.testing_dataset.tolist())
            
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        """单次迭代"""
        super()._iterate()
        print(
            f"Iteration {self.current_iterations}: Loss = {self.current_error}, Learning Rate = {self.current_learning_rate}")
        # 通知当前误差值到UI
        self.notify('current_error', self.current_error)
        # 防止GUI阻塞
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        """当前学习率"""
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
