import numpy as np
import matplotlib.pyplot as plt

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False


# 目标函数：f(x,y) = x² + 2y²（椭圆等高线，更易观察轨迹差异）
def objective_function(x, y):
    return x ** 2 + 2 * y ** 2


# 最速下降法
def steepest_descent(initial_x, initial_y, lr, iterations):
    x, y = initial_x, initial_y
    path = [(x, y)]
    for _ in range(iterations):
        grad_x = 2 * x  # 对x的偏导
        grad_y = 4 * y  # 对y的偏导（因系数为2y²）
        x -= lr * grad_x
        y -= lr * grad_y
        path.append((x, y))
    return path


# 牛顿法
def newton_method(initial_x, initial_y, iterations):
    x, y = initial_x, initial_y
    path = [(x, y)]
    for _ in range(iterations):
        grad_x = 2 * x
        grad_y = 4 * y
        # 海森矩阵为[[2,0],[0,4]]，逆矩阵为[[0.5,0],[0,0.25]]
        x -= 0.5 * grad_x  # 牛顿步长 = 海森逆 × 梯度
        y -= 0.25 * grad_y
        path.append((x, y))
    return path


# 共轭梯度法
def conjugate_gradient(initial_x, initial_y, iterations):
    x, y = initial_x, initial_y
    path = [(x, y)]
    # 初始梯度
    grad_x, grad_y = 2 * x, 4 * y
    # 初始方向（负梯度）
    d_x, d_y = -grad_x, -grad_y

    for _ in range(iterations):
        # 计算最优步长（针对二次函数的解析解）
        numerator = grad_x ** 2 + grad_y ** 2
        denominator = 2 * d_x ** 2 + 8 * d_y ** 2  # 海森矩阵与方向向量的乘积
        alpha = numerator / denominator

        # 更新参数
        x += alpha * d_x
        y += alpha * d_y
        path.append((x, y))

        # 新梯度
        new_grad_x, new_grad_y = 2 * x, 4 * y

        # 计算共轭系数（Fletcher-Reeves公式）
        beta = (new_grad_x ** 2 + new_grad_y ** 2) / (grad_x ** 2 + grad_y ** 2)

        # 更新方向
        d_x = -new_grad_x + beta * d_x
        d_y = -new_grad_y + beta * d_y

        # 更新梯度
        grad_x, grad_y = new_grad_x, new_grad_y

    return path


# 绘制轨迹
def plot_trajectories():
    # 初始点设为(2, 1.5)（较小坐标）
    initial_x, initial_y = 2.0, 1.5
    iterations = 8  # 迭代次数适中，避免轨迹重叠

    # 各算法参数
    sd_path = steepest_descent(initial_x, initial_y, lr=0.3, iterations=iterations)
    nm_path = newton_method(initial_x, initial_y, iterations=iterations)
    cg_path = conjugate_gradient(initial_x, initial_y, iterations=iterations)

    # 生成等高线网格（范围聚焦在-0.5到2.5，突出轨迹）
    x = np.linspace(-0.5, 2.5, 200)
    y = np.linspace(-0.5, 2.0, 200)
    X, Y = np.meshgrid(x, y)
    Z = objective_function(X, Y)

    plt.figure(figsize=(10, 8))
    # 绘制稀疏等高线，避免干扰轨迹
    contour = plt.contour(X, Y, Z, 10, cmap='coolwarm', alpha=0.7)
    plt.clabel(contour, inline=True, fontsize=8, colors='gray')

    # 绘制轨迹（重点突出小圆点和连线）
    # 最速下降法：红色圆点+虚线
    sd_x, sd_y = zip(*sd_path)
    plt.plot(sd_x, sd_y, 'r--', linewidth=1.5)
    plt.scatter(sd_x, sd_y, c='r', s=40, label='最速下降法')

    # 牛顿法：绿色圆点+点线
    nm_x, nm_y = zip(*nm_path)
    plt.plot(nm_x, nm_y, 'g:', linewidth=1.5)
    plt.scatter(nm_x, nm_y, c='g', s=40, label='牛顿法')

    # 共轭梯度法：蓝色圆点+实线
    cg_x, cg_y = zip(*cg_path)
    plt.plot(cg_x, cg_y, 'b-', linewidth=1.5)
    plt.scatter(cg_x, cg_y, s=40, label='共轭梯度法')

    # 标记初始点和终点
    plt.scatter(initial_x, initial_y, c='black', s=60, marker='*', label='初始点')
    plt.scatter(0, 0, c='gold', s=60, marker='*', label='最优解(0,0)')

    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('不同梯度下降算法的优化轨迹对比')
    plt.grid(alpha=0.3)
    plt.legend()
    plt.axis('equal')  # 等比例坐标，避免轨迹变形
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    plot_trajectories()