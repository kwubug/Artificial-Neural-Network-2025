import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
import os
from PIL import Image
import glob


class SOM:
    def __init__(self, grid_size, input_dim):
        self.grid_size = grid_size
        self.input_dim = input_dim
        # 初始化权重矩阵 (5x5x4)
        self.weights = np.random.rand(grid_size[0], grid_size[1], input_dim) * 0.5 + 0.25

    def find_bmu(self, x):
        """找到最佳匹配单元(BMU)"""
        min_dist = float('inf')
        bmu_idx = (0, 0)

        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                dist = np.linalg.norm(x - self.weights[i, j])
                if dist < min_dist:
                    min_dist = dist
                    bmu_idx = (i, j)
        return bmu_idx

    def get_neighborhood(self, center, radius):
        """获取邻域内的神经元索引"""
        neighbors = []
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                # 计算网格距离
                dist = np.sqrt((i - center[0]) ** 2 + (j - center[1]) ** 2)
                if dist <= radius:
                    neighbors.append((i, j))
        return neighbors

    def train(self, data, total_steps=10000, initial_lr=0.5, initial_radius=2):
        """训练SOM网络"""
        n_samples = len(data)
        weight_history = {}

        for step in range(total_steps):
            # 计算当前学习率和邻域半径
            if step < 1000:
                lr = initial_lr - (initial_lr - 0.04) * (step / 1000)
                radius = initial_radius - initial_radius * (step / 1000)
            else:
                lr = 0.04 - 0.04 * ((step - 1000) / (total_steps - 1000))
                radius = 0

            # 随机选择一个样本
            sample_idx = np.random.randint(n_samples)
            x = data[sample_idx]

            # 找到BMU
            bmu = self.find_bmu(x)

            # 获取邻域
            neighbors = self.get_neighborhood(bmu, radius)

            # 更新权重
            for i, j in neighbors:
                # 计算邻域函数 (高斯函数)
                dist_to_bmu = np.sqrt((i - bmu[0]) ** 2 + (j - bmu[1]) ** 2)
                if radius > 0:
                    influence = np.exp(-dist_to_bmu ** 2 / (2 * (radius ** 2)))
                else:
                    influence = 1 if (i, j) == bmu else 0

                # 更新权重
                self.weights[i, j] += lr * influence * (x - self.weights[i, j])

            # 每200步记录权重并生成权值图
            if step % 200 == 0:
                weight_history[step] = self.weights.copy()
                # 生成当前步的权值图
                # self.plot_weight_step(step, self.weights)

        return weight_history

    def plot_weight_step(self, step, weights):
        """绘制单步权值图，显示更多小数位数"""
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False

        fig, ax = plt.subplots(figsize=(10, 8))

        # 计算每个神经元的权重范数作为颜色
        norm_weights = np.linalg.norm(weights, axis=2)

        im = ax.imshow(norm_weights, cmap='viridis', aspect='equal')
        ax.set_title(f'SOM Training Step: {step}', fontsize=16, fontweight='bold')
        ax.set_xticks(np.arange(5))
        ax.set_yticks(np.arange(5))

        # 添加数值标注 - 显示更多小数位数
        for i in range(5):
            for j in range(5):
                # 显示4位小数，提高精度
                ax.text(j, i, f'{norm_weights[i, j]:.4f}',
                        ha='center', va='center', fontsize=9,
                        color='white' if norm_weights[i, j] > 0.5 else 'black')

        # 添加颜色条
        cbar = plt.colorbar(im, ax=ax, label='Weight Norm')
        cbar.ax.tick_params(labelsize=10)

        # 保存图像
        plt.savefig(f'weight_step_{step:05d}.png', dpi=120, bbox_inches='tight')
        plt.close()

    def map_data(self, data):
        """将数据映射到输出平面"""
        mappings = {}
        for idx, x in enumerate(data):
            bmu = self.find_bmu(x)
            mappings[idx] = bmu
        return mappings


def create_training_gif():
    """创建训练过程的GIF动图，每秒10帧"""
    # 获取所有权值图文件
    imgs = glob.glob("weight_step_*.png")

    # 按步数排序
    imgs.sort()

    print(f"找到 {len(imgs)} 张训练过程图片")

    # 创建GIF
    frames = []
    for img_path in imgs:
        frame = Image.open(img_path)
        frames.append(frame)

    # 计算每帧持续时间（每秒10帧 = 每帧100毫秒）
    duration_per_frame = 100  # 毫秒

    # 保存到桌面
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop", "som_training.gif")
    frames[0].save(
        desktop_path,
        format='GIF',
        append_images=frames[1:],
        save_all=True,
        duration=duration_per_frame,
        loop=0  # 无限循环
    )

    # 计算GIF总时长
    total_duration = len(frames) * duration_per_frame / 1000  # 转换为秒

    print(f"训练过程动图已保存到: {desktop_path}")
    print(f"动图包含 {len(frames)} 帧，总时长: {total_duration:.1f} 秒")

    # 清理临时文件
    for img in imgs:
        os.remove(img)

    return desktop_path


def plot_mapping(mappings, grid_size, title):
    """绘制映射结果 - 使用不同符号而不是颜色"""
    # 设置字体以避免警告
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']  # 用来正常显示中文标签
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

    fig, ax = plt.subplots(figsize=(10, 8))

    # 创建网格
    ax.set_xlim(-0.5, grid_size[0] - 0.5)
    ax.set_ylim(-0.5, grid_size[1] - 0.5)
    ax.set_xticks(np.arange(grid_size[0]))
    ax.set_yticks(np.arange(grid_size[1]))
    ax.grid(True, linestyle='-', linewidth=1, alpha=0.7)

    # 使用不同符号而不是颜色
    markers = ['o', 's', '^', 'D', 'v']  # 圆形, 方形, 三角形, 菱形, 倒三角形
    # 使用普通数字而不是上标，避免字体问题
    labels = ['X1', 'X2', 'X3', 'X4', 'X5']

    # 绘制映射点 - 全部使用黑色，但不同符号
    for idx, (i, j) in mappings.items():
        ax.scatter(j, grid_size[0] - 1 - i, s=200, c='black',
                   marker=markers[idx], label=labels[idx],
                   alpha=0.8, edgecolors='black', linewidth=1.5)

    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xlabel('Column Index', fontsize=12)
    ax.set_ylabel('Row Index', fontsize=12)
    ax.legend(loc='upper right', bbox_to_anchor=(1.15, 1))

    # 添加坐标标注
    for i in range(grid_size[0]):
        for j in range(grid_size[1]):
            ax.text(j, grid_size[0] - 1 - i, f'({i},{j})',
                    ha='center', va='center', fontsize=8, alpha=0.7)

    plt.tight_layout()
    plt.show()


def plot_weight_evolution(weight_history, selected_steps):
    """绘制权重演化过程，显示更多小数位数"""
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans']  # 使用兼容字体
    plt.rcParams['axes.unicode_minus'] = False

    fig, axes = plt.subplots(2, 3, figsize=(16, 12))
    axes = axes.flatten()

    for idx, step in enumerate(selected_steps):
        if step in weight_history:
            weights = weight_history[step]
            ax = axes[idx]

            # 计算每个神经元的权重范数作为颜色
            norm_weights = np.linalg.norm(weights, axis=2)

            im = ax.imshow(norm_weights, cmap='viridis', aspect='equal')
            ax.set_title(f'Training Step: {step}', fontsize=14, fontweight='bold')
            ax.set_xticks(np.arange(5))
            ax.set_yticks(np.arange(5))

            # 添加数值标注 - 显示更多小数位数
            for i in range(5):
                for j in range(5):
                    ax.text(j, i, f'{norm_weights[i, j]:.4f}',
                            ha='center', va='center', fontsize=9,
                            color='white' if norm_weights[i, j] > 0.5 else 'black')

    plt.tight_layout()
    plt.show()


# 主程序
def main():
    # 定义输入模式
    X1 = np.array([1, 0, 0, 0])
    X2 = np.array([1, 1, 0, 0])
    X3 = np.array([1, 1, 1, 0])
    X4 = np.array([0, 1, 0, 0])
    X5 = np.array([1, 1, 1, 1])

    data = np.array([X1, X2, X3, X4, X5])

    print("Input Patterns:")
    for i, x in enumerate(data, 1):
        print(f"X{i} = {x}")

    # 创建并训练SOM
    som = SOM(grid_size=(5, 5), input_dim=4)

    print("\nStarting SOM training...")
    print("Generating weight visualization every 200 steps...")
    weight_history = som.train(data, total_steps=10000)

    print("Training completed!")

    # 创建训练过程动图
    print("Creating training animation...")
    # gif_path = create_training_gif()

    # 获取最终映射
    final_mappings = som.map_data(data)

    print("\nFinal mapping results:")
    for idx, (i, j) in final_mappings.items():
        print(f"X{idx + 1} -> Neuron position: ({i}, {j})")

    # 绘制最终映射图 - 使用不同符号
    plot_mapping(final_mappings, (5, 5), "SOM Result")

    # 绘制权重演化过程
    selected_steps = [0, 200, 400, 600, 800, 1000]
    plot_weight_evolution(weight_history, selected_steps)

    # 打印一些训练统计信息，显示更多小数位数
    print(f"\nTraining Statistics:")
    print(f"- Total training steps: 10000")
    print(f"- Initial learning rate: 0.5")
    print(f"- Final learning rate: 0.0")
    print(f"- Initial neighborhood radius: 2.0")
    print(f"- Final neighborhood radius: 0.0")
    # print(f"- Training animation saved to: {gif_path}")

    # 显示最终权重的一些统计信息，显示更多小数位数
    final_weights_norm = np.linalg.norm(som.weights, axis=2)
    print(f"\nFinal weight norm statistics:")
    print(f"- Min: {final_weights_norm.min():.6f}")
    print(f"- Max: {final_weights_norm.max():.6f}")
    print(f"- Mean: {final_weights_norm.mean():.6f}")
    print(f"- Std: {final_weights_norm.std():.6f}")

    # 打印最终权重矩阵的详细值
    print(f"\nDetailed final weight norms:")
    for i in range(5):
        for j in range(5):
            print(f"Neuron ({i},{j}): {final_weights_norm[i, j]:.6f}")


if __name__ == "__main__":
    main()