import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import itertools

# 设置全局字体为黑体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


class DiscreteHopfieldNetwork:
    def __init__(self, n_neurons):
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.energy_history = []
        self.state_history = []

    def train(self, patterns):
        """
        使用Hebb规则训练网络

        参数:
        patterns: 存储模式的列表，每个模式是长度为n_neurons的向量，元素值为-1或1
        """
        self.patterns = patterns
        n_patterns = len(patterns)

        # 使用Hebb规则计算权重
        for i in range(self.n_neurons):
            for j in range(i + 1, self.n_neurons):
                weight = 0
                for pattern in patterns:
                    weight += pattern[i] * pattern[j]
                self.weights[i, j] = weight / n_patterns
                self.weights[j, i] = weight / n_patterns  # 对称权重

        print("训练完成。存储的模式:")
        for i, pattern in enumerate(patterns):
            print(f"模式 {i}: {pattern}")

    def energy(self, state):
        """
        计算网络在给定状态下的能量

        参数:
        state: 当前状态向量

        返回:
        能量值
        """
        energy = 0
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                if i != j:
                    energy -= self.weights[i, j] * state[i] * state[j]
        return energy / 2  # 除以2避免重复计算

    def asynchronous_update(self, state, max_iterations=100):
        """
        异步更新网络状态

        参数:
        state: 初始状态
        max_iterations: 最大迭代次数

        返回:
        最终状态, 能量历史, 状态历史
        """
        current_state = state.copy()
        energy_history = [self.energy(current_state)]
        state_history = [current_state.copy()]

        for iteration in range(max_iterations):
            # 随机选择神经元进行更新
            neuron_order = np.random.permutation(self.n_neurons)

            for neuron_idx in neuron_order:
                # 计算神经元的输入
                input_sum = 0
                for j in range(self.n_neurons):
                    if j != neuron_idx:
                        input_sum += self.weights[neuron_idx, j] * current_state[j]

                # 更新神经元状态
                if input_sum >= 0:
                    current_state[neuron_idx] = 1
                else:
                    current_state[neuron_idx] = -1

            # 记录能量和状态
            current_energy = self.energy(current_state)
            energy_history.append(current_energy)
            state_history.append(current_state.copy())

            # 检查是否达到稳定状态
            if len(state_history) > 1 and np.array_equal(state_history[-1], state_history[-2]):
                print(f"经过 {iteration + 1} 次迭代后收敛")
                break

        return current_state, energy_history, state_history

    def find_attractors(self, num_trials=100, max_iterations=50):
        """
        通过多次随机初始化寻找吸引子

        参数:
        num_trials: 随机初始化的次数
        max_iterations: 每次运行的最大迭代次数

        返回:
        吸引子字典: {吸引子状态: 出现次数}
        """
        attractors = defaultdict(int)

        for trial in range(num_trials):
            # 随机初始化状态
            initial_state = np.random.choice([-1, 1], size=self.n_neurons)

            # 运行网络直到收敛
            final_state, _, _ = self.asynchronous_update(initial_state, max_iterations)

            # 将状态转换为元组以便作为字典键
            state_tuple = tuple(final_state)
            attractors[state_tuple] += 1

        print(f"\n在 {num_trials} 次试验中找到 {len(attractors)} 个吸引子:")
        for i, (attractor, count) in enumerate(attractors.items()):
            energy = self.energy(np.array(attractor))
            print(f"吸引子 {i}: {attractor}, 能量: {energy:.4f}, 频率: {count}/{num_trials}")

        return attractors

    def visualize_energy_landscape(self, attractors=None, num_samples=1000):
        """
        可视化能量景观

        参数:
        attractors: 吸引子字典
        num_samples: 采样的初始状态数量
        """
        if attractors is None:
            attractors = self.find_attractors(num_trials=num_samples)

        # 计算所有吸引子的能量
        attractor_energies = {}
        for attractor in attractors:
            energy = self.energy(np.array(attractor))
            attractor_energies[attractor] = energy

        # 创建新图形 - 能量景观
        plt.figure(figsize=(10, 6))
        energies = list(attractor_energies.values())
        frequencies = list(attractors.values())

        plt.bar(range(len(energies)), energies, alpha=0.7, color='skyblue')
        plt.xlabel('吸引子索引', fontsize=12, fontweight='bold')
        plt.ylabel('能量', fontsize=12, fontweight='bold')
        plt.title('Hopfield网络能量景观', fontsize=14, fontweight='bold')

        # 在柱状图上添加频率信息
        for i, (energy, freq) in enumerate(zip(energies, frequencies)):
            plt.text(i, energy + 0.01, f'频率: {freq}', ha='center', va='bottom', fontweight='bold')

        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

        return attractor_energies

    def visualize_convergence_process(self, initial_state, max_iterations=20):
        """
        可视化一个特定初始状态的收敛过程

        参数:
        initial_state: 初始状态
        max_iterations: 最大迭代次数
        """
        final_state, energy_history, state_history = self.asynchronous_update(
            initial_state, max_iterations)

        # 创建图形1 - 能量收敛
        plt.figure(figsize=(8, 5))
        plt.plot(energy_history, 'b-o', linewidth=2, markersize=4)
        plt.xlabel('迭代次数', fontsize=12, fontweight='bold')
        plt.ylabel('能量', fontsize=12, fontweight='bold')
        plt.title('能量收敛过程', fontsize=14, fontweight='bold')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()

        # 创建图形2 - 状态演化热图
        plt.figure(figsize=(10, 6))
        state_matrix = np.array(state_history)
        im = plt.imshow(state_matrix.T, cmap='coolwarm', aspect='auto',
                        interpolation='nearest')
        plt.xlabel('迭代次数', fontsize=12, fontweight='bold')
        plt.ylabel('神经元', fontsize=12, fontweight='bold')
        plt.title('状态演化过程', fontsize=14, fontweight='bold')
        plt.yticks(range(self.n_neurons))
        plt.colorbar(im, label='状态 (-1/1)')
        plt.tight_layout()
        plt.show()

        print(f"初始状态: {initial_state}")
        print(f"最终状态: {final_state}")
        print(f"初始能量: {energy_history[0]:.4f}")
        print(f"最终能量: {energy_history[-1]:.4f}")

        return final_state, energy_history

    def visualize_weight_matrix(self):
        """可视化权重矩阵"""
        plt.figure(figsize=(8, 6))
        plt.imshow(self.weights, cmap='RdYlBu', interpolation='nearest')
        plt.colorbar(label='权重值')
        plt.title('权重矩阵', fontsize=14, fontweight='bold')
        plt.xlabel('神经元索引', fontsize=12, fontweight='bold')
        plt.ylabel('神经元索引', fontsize=12, fontweight='bold')
        plt.tight_layout()
        plt.show()

    def visualize_state_distribution(self, attractors):
        """可视化状态分布"""
        plt.figure(figsize=(10, 6))
        states_labels = [f"{state}" for state in attractors.keys()]
        counts = list(attractors.values())

        colors = plt.cm.viridis(np.linspace(0, 1, len(counts)))
        bars = plt.bar(range(len(counts)), counts, color=colors, alpha=0.7)
        plt.xlabel('状态配置', fontsize=12, fontweight='bold')
        plt.ylabel('频率', fontsize=12, fontweight='bold')
        plt.title('状态分布统计', fontsize=14, fontweight='bold')
        plt.xticks(range(len(states_labels)), states_labels, rotation=45)

        # 添加数值标签
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width() / 2., height,
                     f'{height}', ha='center', va='bottom', fontweight='bold')

        plt.tight_layout()
        plt.show()


def demonstrate_hopfield_network():
    """
    演示Hopfield网络的功能
    """
    print("=" * 60)
    print("离散型Hopfield网络演示")
    print("=" * 60)

    # 创建网络
    n_neurons = 5
    hopnet = DiscreteHopfieldNetwork(n_neurons)

    # 定义要存储的模式
    patterns = [
        np.array([1, 1, 1, -1, -1]),  # 模式1
        np.array([-1, -1, -1, 1, 1]),  # 模式2
        np.array([1, -1, 1, -1, 1])  # 模式3
    ]

    # 训练网络
    hopnet.train(patterns)

    # 显示权重矩阵
    print("\n权重矩阵:")
    print(hopnet.weights)

    # 可视化权重矩阵
    print("\n" + "=" * 40)
    print("权重矩阵可视化")
    print("=" * 40)
    hopnet.visualize_weight_matrix()

    # 测试模式回忆
    print("\n" + "=" * 40)
    print("模式回忆测试")
    print("=" * 40)

    # 对每个存储的模式，添加噪声并测试回忆
    for i, pattern in enumerate(patterns):
        # 添加噪声（翻转一个随机位）
        noisy_pattern = pattern.copy()
        flip_idx = np.random.randint(0, n_neurons)
        noisy_pattern[flip_idx] *= -1

        print(f"\n测试模式 {i}:")
        print(f"原始模式: {pattern}")
        print(f"含噪声模式: {noisy_pattern}")

        recalled, energy_hist, state_hist = hopnet.asynchronous_update(noisy_pattern)
        print(f"回忆模式: {recalled}")
        print(f"与原始模式匹配: {np.array_equal(recalled, pattern)}")

    # 寻找吸引子
    print("\n" + "=" * 40)
    print("吸引子搜索")
    print("=" * 40)

    attractors = hopnet.find_attractors(num_trials=200)

    # 可视化状态分布
    print("\n" + "=" * 40)
    print("状态分布可视化")
    print("=" * 40)
    hopnet.visualize_state_distribution(attractors)

    # 可视化能量景观
    print("\n" + "=" * 40)
    print("能量景观可视化")
    print("=" * 40)
    hopnet.visualize_energy_landscape(attractors)

    # 可视化收敛过程示例
    print("\n" + "=" * 40)
    print("收敛过程可视化")
    print("=" * 40)

    # 随机选择一个初始状态
    random_initial = np.random.choice([-1, 1], size=n_neurons)
    hopnet.visualize_convergence_process(random_initial)

    # 计算所有可能状态的能量（对于小网络可行）
    if n_neurons <= 8:
        print("\n" + "=" * 40)
        print("完整状态空间分析")
        print("=" * 40)

        all_states = list(itertools.product([-1, 1], repeat=n_neurons))
        state_energy_map = {}

        for state in all_states:
            state_array = np.array(state)
            energy = hopnet.energy(state_array)
            state_energy_map[state] = energy

        # 找出最低能量的状态
        min_energy = min(state_energy_map.values())
        min_energy_states = [state for state, energy in state_energy_map.items() if energy == min_energy]

        print(f"最低能量: {min_energy:.4f}")
        print(f"具有最低能量的状态:")
        for state in min_energy_states:
            print(f"  {state}")


if __name__ == "__main__":
    # 设置随机种子以便重现结果
    np.random.seed(42)

    demonstrate_hopfield_network()