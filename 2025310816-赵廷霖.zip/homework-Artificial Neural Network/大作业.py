import torch
import cv2
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from ultralytics import YOLO
import yaml
from PIL import Image, ImageDraw, ImageFont
import random
import os
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd


class YOLODetector:
    def __init__(self, model_path=None):
        """
        初始化YOLO检测器
        Args:
            model_path: 预训练模型路径，如果为None则创建新模型
        """
        if model_path:
            self.model = YOLO(model_path)
        else:
            # 创建新的YOLOv8模型
            self.model = YOLO('yolov8n.yaml')  # 使用nano版本作为基础

        # 类别颜色映射
        self.class_colors = {
            'instrument': (0, 255, 0),  # 绿色 - 仪表
            'flame': (255, 0, 0),  # 红色 - 火焰
            'sinkhole': (0, 0, 255)  # 蓝色 - 地陷
        }

    def create_dataset_config(self, data_dir):
        """
        创建数据集配置文件
        """
        dataset_config = {
            'path': str(data_dir),
            'train': 'images/train',
            'val': 'images/val',
            'test': 'images/test',
            'nc': 3,  # 类别数量
            'names': {0: 'instrument', 1: 'flame', 2: 'sinkhole'}
        }

        config_path = data_dir / 'dataset.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(dataset_config, f)

        return config_path

    def train_model(self, data_config, epochs=100, imgsz=640, batch=16):
        """
        训练YOLO模型
        """
        print("开始训练YOLO模型...")

        # 训练参数
        train_args = {
            'data': str(data_config),
            'epochs': epochs,
            'imgsz': imgsz,
            'batch': batch,
            'patience': 10,  # 早停耐心值
            'save': True,
            'exist_ok': True,
            'pretrained': True,
            'optimizer': 'AdamW',  # 使用AdamW优化器
            'lr0': 0.01,  # 初始学习率
            'lrf': 0.01,  # 最终学习率系数
            'momentum': 0.9,  # 动量
            'weight_decay': 0.0005,  # 权重衰减
            'warmup_epochs': 3.0,  # 热身epochs
            'warmup_momentum': 0.8,  # 热身动量
            'box': 7.5,  # 边界框损失权重
            'cls': 0.5,  # 分类损失权重
            'dfl': 1.5,  # 分布焦点损失权重
            'close_mosaic': 10,  # 最后10个epoch关闭mosaic增强
        }

        # 开始训练
        results = self.model.train(**train_args)

        print("训练完成!")
        return results

    def visualize_detection(self, image_path, save_path=None, conf_threshold=0.25):
        """
        对单张图像进行检测并可视化结果
        """
        # 读取图像
        image = cv2.imread(str(image_path))
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # 进行预测
        results = self.model(image_rgb, conf=conf_threshold)

        # 创建可视化图像
        vis_image = image_rgb.copy()

        if len(results) > 0:
            result = results[0]
            boxes = result.boxes

            for box in boxes:
                # 获取边界框坐标
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                conf = box.conf[0].cpu().numpy()
                cls = int(box.cls[0].cpu().numpy())

                # 获取类别名称和颜色
                class_name = self.model.names[cls]
                color = self.class_colors.get(class_name, (255, 255, 255))

                # 绘制边界框
                cv2.rectangle(vis_image, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)

                # 绘制标签
                label = f"{class_name} {conf:.2f}"
                label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2)[0]
                cv2.rectangle(vis_image, (int(x1), int(y1 - label_size[1] - 10)),
                              (int(x1 + label_size[0]), int(y1)), color, -1)
                cv2.putText(vis_image, label, (int(x1), int(y1 - 5)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

        # 显示或保存结果
        plt.figure(figsize=(12, 8))
        plt.imshow(vis_image)
        plt.axis('off')
        plt.title(f'Detection Results: {image_path.name}')

        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=300)
            print(f"结果已保存至: {save_path}")

        plt.show()
        return vis_image

    def plot_training_metrics(self, results_dir='runs/detect/train'):
        """
        绘制训练过程中的指标曲线
        """
        results_dir = Path(results_dir)
        metrics_file = results_dir / 'results.csv'

        if not metrics_file.exists():
            print("未找到训练结果文件")
            return

        # 读取训练指标
        metrics_df = pd.read_csv(metrics_file)

        # 创建子图
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))

        # 绘制损失曲线
        axes[0, 0].plot(metrics_df['epoch'], metrics_df['train/box_loss'], label='Box Loss')
        axes[0, 0].plot(metrics_df['epoch'], metrics_df['train/cls_loss'], label='Cls Loss')
        axes[0, 0].plot(metrics_df['epoch'], metrics_df['train/dfl_loss'], label='DFL Loss')
        axes[0, 0].set_title('Training Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True)

        # 绘制验证损失
        axes[0, 1].plot(metrics_df['epoch'], metrics_df['val/box_loss'], label='Val Box Loss')
        axes[0, 1].plot(metrics_df['epoch'], metrics_df['val/cls_loss'], label='Val Cls Loss')
        axes[0, 1].set_title('Validation Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)

        # 绘制mAP曲线
        axes[0, 2].plot(metrics_df['epoch'], metrics_df['metrics/mAP50(B)'], label='mAP@0.5')
        axes[0, 2].plot(metrics_df['epoch'], metrics_df['metrics/mAP50-95(B)'], label='mAP@0.5:0.95')
        axes[0, 2].set_title('mAP Metrics')
        axes[0, 2].set_xlabel('Epoch')
        axes[0, 2].set_ylabel('mAP')
        axes[0, 2].legend()
        axes[0, 2].grid(True)

        # 绘制精确率-召回率曲线
        axes[1, 0].plot(metrics_df['epoch'], metrics_df['metrics/precision(B)'], label='Precision')
        axes[1, 0].plot(metrics_df['epoch'], metrics_df['metrics/recall(B)'], label='Recall')
        axes[1, 0].set_title('Precision & Recall')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Score')
        axes[1, 0].legend()
        axes[1, 0].grid(True)

        # 绘制学习率曲线
        axes[1, 1].plot(metrics_df['epoch'], metrics_df['lr/pg0'], label='Learning Rate')
        axes[1, 1].set_title('Learning Rate Schedule')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Learning Rate')
        axes[1, 1].legend()
        axes[1, 1].grid(True)

        # 绘制类别分布
        if 'train/instances' in metrics_df.columns:
            axes[1, 2].plot(metrics_df['epoch'], metrics_df['train/instances'], label='Training Instances')
            axes[1, 2].set_title('Training Instances per Epoch')
            axes[1, 2].set_xlabel('Epoch')
            axes[1, 2].set_ylabel('Instances')
            axes[1, 2].grid(True)

        plt.tight_layout()
        plt.savefig('training_metrics.png', dpi=300, bbox_inches='tight')
        plt.show()

    def evaluate_model(self, data_config):
        """
        评估模型性能
        """
        print("开始模型评估...")

        # 在验证集上评估
        metrics = self.model.val(data=str(data_config), save_json=True)

        # 打印关键指标
        print(f"\n=== 模型评估结果 ===")
        print(f"mAP@0.5: {metrics.box.map50:.4f}")
        print(f"mAP@0.5:0.95: {metrics.box.map:.4f}")
        print(f"精确率: {metrics.box.precision:.4f}")
        print(f"召回率: {metrics.box.recall:.4f}")

        return metrics

    def batch_detection_visualization(self, image_dir, output_dir, num_images=9):
        """
        批量图像检测可视化
        """
        image_dir = Path(image_dir)
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)

        # 获取图像文件
        image_files = list(image_dir.glob('*.jpg')) + list(image_dir.glob('*.png'))
        selected_images = random.sample(image_files, min(num_images, len(image_files)))

        # 创建子图
        fig, axes = plt.subplots(3, 3, figsize=(15, 12))
        axes = axes.ravel()

        for idx, image_path in enumerate(selected_images):
            if idx >= 9:
                break

            # 进行检测
            results = self.model(image_path)
            result_image = results[0].plot()  # 使用YOLO内置绘图功能

            # 显示结果
            axes[idx].imshow(result_image)
            axes[idx].set_title(f'{image_path.name}')
            axes[idx].axis('off')

        # 隐藏多余的子图
        for idx in range(len(selected_images), 9):
            axes[idx].axis('off')

        plt.tight_layout()
        plt.savefig(output_dir / 'batch_detection_results.png', dpi=300, bbox_inches='tight')
        plt.show()


def create_sample_data_structure():
    """
    创建示例数据目录结构（用于演示）
    """
    base_dir = Path('safety_detection_dataset')

    # 创建目录结构
    dirs = [
        'images/train',
        'images/val',
        'images/test',
        'labels/train',
        'labels/val',
        'labels/test'
    ]

    for dir_path in dirs:
        (base_dir / dir_path).mkdir(parents=True, exist_ok=True)

    print(f"数据集目录结构已创建在: {base_dir}")
    return base_dir


def main():
    """
    主函数 - 演示完整流程
    """
    # 初始化检测器
    detector = YOLODetector()

    # 创建数据目录（实际使用时替换为真实数据路径）
    data_dir = create_sample_data_structure()

    # 创建数据集配置文件
    config_path = detector.create_dataset_config(data_dir)

    print("=== YOLOv8 安全检测系统 ===")
    print("1. 训练模型")
    print("2. 评估模型")
    print("3. 单图检测可视化")
    print("4. 批量检测可视化")
    print("5. 训练指标可视化")

    # 这里以加载预训练模型进行演示
    # 实际使用时，可以先执行训练：
    # detector.train_model(config_path, epochs=100)

    # 加载训练好的模型进行演示
    try:
        # 尝试加载最新训练的模型
        trained_model = YOLO('runs/detect/train/weights/best.pt')
        detector.model = trained_model
        print("成功加载训练好的模型")
    except:
        print("使用预训练YOLOv8模型进行演示")
        detector.model = YOLO('yolov8n.pt')

    # 演示单图检测（使用示例图像）
    sample_image = Path('sample_image.jpg')  # 替换为实际图像路径
    if sample_image.exists():
        print(f"\n对示例图像进行检测: {sample_image}")
        detector.visualize_detection(sample_image, save_path='detection_result.png')
    else:
        print("请提供示例图像进行检测演示")

    # 绘制训练指标（如果有训练结果）
    detector.plot_training_metrics()

    # 批量检测演示
    image_dir = Path('test_images')  # 替换为测试图像目录
    if image_dir.exists():
        detector.batch_detection_visualization(image_dir, 'batch_results')


if __name__ == "__main__":
    main()