import numpy as np
import random
import time
from .base_algorithm import TraningAlgorithm


class DiscreteHopfieldAlgorithm(TraningAlgorithm):
    """
    离散型 Hopfield 神经网络 (DHNN)
    """
    def __init__(self, M=4, noise_level=0.2, max_iter=2000, update_freq=5,
                 ui_refresh_interval=0.01, initial_pattern_index=0):
        super().__init__(dataset=[], total_epoches=1)
        
        self.M = int(M)  # 图像边长
        self.N = self.M * self.M  # 神经元总数
        self.noise_level = float(noise_level)
        self.max_iter = int(max_iter)
        self.update_freq = int(update_freq)
        self.ui_refresh_interval = float(ui_refresh_interval)
        self.initial_pattern_index = int(initial_pattern_index)
        
        # 网络状态
        self.W = np.zeros((self.N, self.N))
        self.S = np.random.choice([-1, 1], size=self.N)
        self.energy_history = []
        self.current_iteration = 0
        self.current_energy = 0.0
        self.has_finished = True
        
        # 存储模式
        self.stored_patterns = self._get_stored_patterns()
        self.initial_pattern = None
        self.initial_state = None
        
    def _get_stored_patterns(self):
        """获取预定义的存储模式"""
        P1 = np.array([[1, 1, 1, 1], 
                       [-1, 1, 1, -1], 
                       [-1, 1, 1, -1], 
                       [1, 1, 1, 1]]).flatten()
        
        P2 = np.array([[1, -1, -1, 1], 
                       [1, 1, -1, 1], 
                       [1, -1, 1, 1], 
                       [1, -1, -1, 1]]).flatten()
        
        P3 = np.array([[1, -1, 1, -1], 
                       [-1, 1, -1, 1], 
                       [1, -1, 1, -1], 
                       [-1, 1, -1, 1]]).flatten()
        
        return [P1, P2, P3]
    
    def _create_noisy_input(self, pattern, noise_level):
        """创建带噪声的输入模式"""
        noisy_pattern = np.copy(pattern)
        num_flips = int(self.N * noise_level)
        if num_flips > 0:
            flip_indices = np.random.choice(self.N, size=num_flips, replace=False)
            noisy_pattern[flip_indices] *= -1
        return noisy_pattern
    
    def hebbian_learning(self, patterns):
        """使用 Hebbian 规则存储模式 (训练)"""
        M = len(patterns)
        if M == 0:
            return
        P = np.array(patterns)
        self.W = (1 / self.N) * (P.T @ P)
        np.fill_diagonal(self.W, 0)
    
    def calculate_energy(self, S=None):
        """计算网络的能量函数 E"""
        if S is None:
            S = self.S
        energy = -0.5 * S @ self.W @ S
        return energy
    
    def asynchronous_update_step(self):
        """执行一步异步更新"""
        i = random.randint(0, self.N - 1)
        h_i = self.W[i, :] @ self.S
        S_new_i = np.sign(h_i)
        if S_new_i == 0:
            S_new_i = self.S[i]
        
        changed = (self.S[i] != S_new_i)
        self.S[i] = S_new_i
        
        self.current_energy = self.calculate_energy()
        self.energy_history.append(float(self.current_energy))
        self.current_iteration += 1
        
        return changed
    
    def run(self):
        self.has_finished = False
        
        # 初始化
        self.initial_pattern = self.stored_patterns[self.initial_pattern_index]
        self.initial_state = self._create_noisy_input(self.initial_pattern, self.noise_level)
        
        # 训练网络（存储模式）
        self.hebbian_learning(self.stored_patterns)
        
        # 设置初始状态
        self.S = self.initial_state.copy()
        self.current_energy = self.calculate_energy()
        self.energy_history = [float(self.current_energy)]
        self.current_iteration = 0
        
        # 初始通知
        if hasattr(self, 'notify'):
            self.notify('current_iteration', 0)
            self.notify('current_energy', self.current_energy)
            self.notify('current_state', self.S.tolist())
            self.notify('initial_pattern', self.initial_pattern.tolist())
            self.notify('initial_state', self.initial_state.tolist())
            self.notify('stored_patterns', [p.tolist() for p in self.stored_patterns])
        
        # 主循环
        is_stable = False
        for k in range(1, self.max_iter + 1):
            if self._should_stop:
                break
            
            changed = self.asynchronous_update_step()
            
            # 简单收敛判断
            if not changed and k >= self.N:
                if len(self.energy_history) >= self.N:
                    recent_energies = self.energy_history[-self.N:]
                    if all(abs(e - self.current_energy) < 1e-6 for e in recent_energies):
                        is_stable = True
                        break
            
            # 定期通知更新
            if k % self.update_freq == 0 or k == self.max_iter:
                if hasattr(self, 'notify'):
                    self.notify('current_iteration', self.current_iteration)
                    self.notify('current_energy', self.current_energy)
                    self.notify('current_state', self.S.tolist())
                    self.notify('energy_history', self.energy_history[-100:])  # 只发送最近100个点
                
                if self.ui_refresh_interval > 0:
                    time.sleep(self.ui_refresh_interval)
        
        # 最终通知
        if hasattr(self, 'notify'):
            self.notify('current_iteration', self.current_iteration)
            self.notify('current_energy', self.current_energy)
            self.notify('current_state', self.S.tolist())
            self.notify('energy_history', self.energy_history)
            self.notify('is_stable', is_stable)
            self.notify('has_finished', True)
        
        self.has_finished = True

