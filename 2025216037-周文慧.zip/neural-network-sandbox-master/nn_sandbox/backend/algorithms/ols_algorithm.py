import numpy as np
from sklearn.metrics import r2_score

from . import PredictiveAlgorithm


class OlsAlgorithm(PredictiveAlgorithm):
    """普通最小二乘法（OLS）线性回归算法"""
    
    def __init__(self, dataset, total_epoches, most_correct_rate, 
                 initial_learning_rate, search_iteration_constant, test_ratio):
        super().__init__(
            dataset=dataset,
            total_epoches=total_epoches,
            most_correct_rate=most_correct_rate,
            initial_learning_rate=initial_learning_rate,
            search_iteration_constant=search_iteration_constant,
            test_ratio=test_ratio
        )
        
        # 模型参数：y = a*x + b
        self.a = 0.0
        self.b = 0.0
        
    def _initialize_neurons(self):
        """初始化模型参数（实现抽象方法）"""
        # 使用小随机值初始化参数
        self.a = np.random.randn() * 0.01
        self.b = np.random.randn() * 0.01
        # OLS 不需要传统意义上的神经元，但为了兼容基类，创建一个空列表
        self._neurons = []
        
    def _iterate(self):
        """单次迭代：梯度下降更新参数"""
        if len(self.training_dataset) == 0:
            return
            
        # 使用基类提供的 current_data 属性获取当前样本
        sample = self.current_data
        x, y_true = sample[0], sample[1]
        
        # 预测值
        y_pred = self.a * x + self.b
        
        # 计算误差
        error = y_pred - y_true
        
        # 梯度下降更新参数（使用基类的 current_learning_rate 属性）
        learning_rate = self.current_learning_rate
        self.a -= learning_rate * error * x
        self.b -= learning_rate * error
        
    def _correct_rate(self, dataset):
        """计算R²分数"""
        if dataset is None or len(dataset) == 0:
            return 0.0
            
        X = dataset[:, 0]
        y_true = dataset[:, 1]
        y_pred = self.a * X + self.b
        
        try:
            return r2_score(y_true, y_pred)
        except:
            return 0.0
    
    def _save_best_neurons(self):
        """保存最佳参数（重写基类方法）"""
        self.current_correct_rate = self._correct_rate(self.training_dataset)
        if self.current_correct_rate > self.best_correct_rate:
            self.best_correct_rate = self.current_correct_rate
            # 保存最佳参数
            self._best_neurons = [self.a, self.b]
    
    def _load_best_neurons(self):
        """加载最佳参数（重写基类方法）"""
        if self._best_neurons:
            self.a, self.b = self._best_neurons