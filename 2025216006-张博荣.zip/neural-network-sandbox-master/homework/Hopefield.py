import numpy as np
import copy
import time
import matplotlib.pyplot as plt
from typing import Tuple, Dict, List

plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号

class HopfieldSandbox:
    """沙箱环境封装的离散型Hopfield神经网络"""
    def __init__(self, num_neurons: int, max_iter: int = 100, timeout: float = 10.0):
        """
        初始化沙箱环境
        :param num_neurons: 神经元数量
        :param max_iter: 最大迭代次数（资源限制）
        :param timeout: 超时时间（秒，资源限制）
        """
        # 沙箱内部私有状态（外部不可直接访问）
        self._num_neurons = num_neurons
        self._weights = np.zeros((num_neurons, num_neurons), dtype=np.float64)
        self._max_iter = max_iter
        self._timeout = timeout
        self._energy_history = []
        
        # 沙箱元数据（记录操作状态）
        self._is_trained = False
        self._last_operation_time = 0.0

    def _validate_bipolar(self, data: np.ndarray) -> None:
        """沙箱内部验证：确保数据是bipolar类型（1/-1）"""
        if not np.all(np.isin(data, [-1, 1])):
            raise ValueError("沙箱错误：输入数据必须是bipolar类型（仅包含1和-1）")

    def train(self, external_patterns: np.ndarray) -> None:
        """
        在沙箱内训练网络（隔离训练数据）
        :param external_patterns: 外部输入的训练模式（每行一个模式）
        """
        # 1. 数据隔离：深拷贝外部数据，避免修改原始数据
        patterns = copy.deepcopy(external_patterns)
        
        # 2. 安全验证：检查输入合法性
        if patterns.ndim != 2:
            raise ValueError("沙箱错误：训练模式必须是二维数组")
        if patterns.shape[1] != self._num_neurons:
            raise ValueError(f"沙箱错误：模式维度不匹配（需{self._num_neurons}，实际{patterns.shape[1]}）")
        self._validate_bipolar(patterns)
        
        # 3. 沙箱内执行训练（Hebbian学习规则）
        num_patterns = patterns.shape[0]
        self._weights = (1 / self._num_neurons) * np.dot(patterns.T, patterns)
        np.fill_diagonal(self._weights, 0)  # 消除自连接权重
        
        # 更新沙箱状态
        self._is_trained = True
        self._last_operation_time = time.time()

    def async_update(self, external_state: np.ndarray) -> Tuple[np.ndarray, int]:
        """
        在沙箱内执行异步更新（隔离状态数据，限制资源）
        :param external_state: 外部输入的初始状态
        :return: 稳定状态和迭代次数
        """
        # 1. 前置检查
        if not self._is_trained:
            raise RuntimeError("沙箱错误：网络未训练，请先调用train方法")
        
        # 2. 数据隔离：复制外部状态，沙箱内仅操作副本
        current_state = copy.deepcopy(external_state)
        
        # 3. 输入验证
        if len(current_state) != self._num_neurons:
            raise ValueError(f"沙箱错误：状态长度不匹配（需{self._num_neurons}，实际{len(current_state)}）")
        self._validate_bipolar(current_state)
        
        # 4. 资源控制：初始化计时和能量记录
        start_time = time.time()
        self._energy_history = [self._calculate_energy(current_state)]
        
        # 5. 沙箱内异步更新过程
        for iter_count in range(self._max_iter):
            # 超时检查
            if time.time() - start_time > self._timeout:
                raise TimeoutError(f"沙箱错误：更新超时（超过{self._timeout}秒）")
            
            # 随机选择一个神经元（异步更新核心）
            neuron_idx = np.random.randint(0, self._num_neurons)
            
            # 计算输入总和
            input_sum = np.dot(self._weights[neuron_idx], current_state)
            
            # 更新神经元状态
            new_state = current_state.copy()
            new_state[neuron_idx] = 1 if input_sum >= 0 else -1
            
            # 记录能量变化
            self._energy_history.append(self._calculate_energy(new_state))
            
            # 检查是否稳定
            if np.array_equal(new_state, current_state):
                self._last_operation_time = time.time()
                return new_state, iter_count + 1  # 返回稳定状态和迭代次数
            
            current_state = new_state
        
        # 达到最大迭代次数
        self._last_operation_time = time.time()
        return current_state, self._max_iter

    def _calculate_energy(self, state: np.ndarray) -> float:
        """沙箱内部能量计算（不暴露实现细节）"""
        return -0.5 * np.dot(np.dot(state.T, self._weights), state)

    def get_energy_history(self) -> List[float]:
        """安全获取能量历史（返回副本，防止外部篡改）"""
        return copy.deepcopy(self._energy_history)

    def find_attractors(self, external_patterns: np.ndarray, noise_level: float = 0.2, 
                       num_tests: int = 10) -> Tuple[Dict[Tuple[int, ...], int], float]:
        """
        在沙箱内检测吸引子（隔离噪声测试过程）
        :param external_patterns: 原始训练模式
        :param noise_level: 噪声比例
        :param num_tests: 每个模式的测试次数
        :return: 吸引子统计和恢复成功率
        """
        if not self._is_trained:
            raise RuntimeError("沙箱错误：网络未训练，请先调用train方法")
        
        # 数据隔离：复制原始模式
        patterns = copy.deepcopy(external_patterns)
        self._validate_bipolar(patterns)
        
        attractors: Dict[Tuple[int, ...], int] = {}
        success_count = 0
        total_tests = 0
        
        for pattern in patterns:
            pattern_tuple = tuple(pattern)
            if pattern_tuple not in attractors:
                attractors[pattern_tuple] = 0
            
            for _ in range(num_tests):
                total_tests += 1
                # 沙箱内生成带噪声的状态（不影响原始模式）
                noisy_state = pattern.copy()
                noise_mask = np.random.choice(
                    [True, False], 
                    size=self._num_neurons,
                    p=[noise_level, 1 - noise_level]
                )
                noisy_state[noise_mask] *= -1  # 翻转噪声位置
                
                # 沙箱内更新到稳定状态
                stable_state, _ = self.async_update(noisy_state)
                stable_tuple = tuple(stable_state)
                
                # 统计吸引子
                if stable_tuple in attractors:
                    attractors[stable_tuple] += 1
                else:
                    attractors[stable_tuple] = 1
                
                # 检查是否恢复到原始模式
                if np.array_equal(stable_state, pattern):
                    success_count += 1
        
        success_rate = success_count / total_tests if total_tests > 0 else 0.0
        return attractors, success_rate


# 演示沙箱环境下的Hopfield网络功能
if __name__ == "__main__":
    # 设置随机种子，保证可复现性
    np.random.seed(42)
    
    # 1. 定义参数和模式（沙箱外部数据）
    num_neurons = 25  # 5x5像素网格
    max_iter = 200    # 沙箱内最大迭代次数
    timeout = 5.0     # 沙箱超时时间（秒）
    
    # 定义3个bipolar模式（1/-1）
    # 模式1：十字形
    pattern1 = np.array([
        1, 1, 1, 1, 1,
        1, -1, -1, -1, 1,
        1, -1, 1, -1, 1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, 1
    ])
    
    # 模式2：中心空心方块
    pattern2 = np.array([
        1, 1, 1, 1, 1,
        1, -1, -1, -1, 1,
        1, -1, -1, -1, 1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, 1
    ])
    
    # 模式3：水平线
    pattern3 = np.array([
        -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1,
        1, 1, 1, 1, 1,
        -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1
    ])
    
    training_patterns = np.vstack([pattern1, pattern2, pattern3])
    
    # 2. 创建沙箱环境（建立隔离边界）
    sandbox = HopfieldSandbox(num_neurons, max_iter=max_iter, timeout=timeout)
    
    # 3. 在沙箱内训练网络
    try:
        sandbox.train(training_patterns)
        print("网络训练完成（在沙箱内执行）")
    except Exception as e:
        print(f"训练失败：{e}")
        exit(1)
    
    # 4. 测试带噪声的模式恢复（沙箱内操作）
    test_pattern = pattern1.copy()
    noise_level = 0.3  # 30%噪声
    noise_mask = np.random.choice([True, False], size=num_neurons, p=[noise_level, 1-noise_level])
    test_pattern[noise_mask] *= -1  # 生成带噪声的测试模式
    
    try:
        stable_state, iterations = sandbox.async_update(test_pattern)
        energy_history = sandbox.get_energy_history()
        print(f"\n异步更新完成：迭代{iterations}次达到稳定")
        print(f"能量变化：初始{energy_history[0]:.4f} → 稳定{energy_history[-1]:.4f}")
        print(f"是否成功恢复原始模式：{np.array_equal(stable_state, pattern1)}")
    except Exception as e:
        print(f"更新失败：{e}")
        exit(1)
    
    # 5. 检测吸引子（沙箱内执行）
    try:
        attractors, success_rate = sandbox.find_attractors(
            training_patterns, 
            noise_level=0.2, 
            num_tests=20
        )
        print(f"\n吸引子检测完成：整体恢复成功率{success_rate:.2%}")
    except Exception as e:
        print(f"吸引子检测失败：{e}")
        exit(1)
    
    # 6. 可视化结果
    plt.figure(figsize=(12, 8))
    
    # 子图1：能量变化曲线
    plt.subplot(2, 2, 1)
    plt.plot(energy_history, color='blue')
    plt.title("沙箱内能量变化曲线")
    plt.xlabel("迭代次数")
    plt.ylabel("能量值")
    plt.grid(alpha=0.3)
    
    # 子图2：原始模式
    plt.subplot(2, 2, 2)
    plt.imshow(pattern1.reshape(5, 5), cmap='gray', vmin=-1, vmax=1)
    plt.title("原始模式")
    plt.axis('off')
    
    # 子图3：带噪声模式
    plt.subplot(2, 2, 3)
    plt.imshow(test_pattern.reshape(5, 5), cmap='gray', vmin=-1, vmax=1)
    plt.title(f"带{int(noise_level*100)}%噪声的模式")
    plt.axis('off')
    
    # 子图4：恢复后的模式
    plt.subplot(2, 2, 4)
    plt.imshow(stable_state.reshape(5, 5), cmap='gray', vmin=-1, vmax=1)
    plt.title("沙箱恢复后的稳定模式")
    plt.axis('off')
    
    plt.tight_layout()
    plt.show()
    
    # 7. 打印吸引子统计
    print("\n吸引子统计结果：")
    for idx, (attractor, count) in enumerate(attractors.items()):
        # 判断是否为原始模式
        is_original = any(np.array_equal(np.array(attractor), p) for p in training_patterns)
        print(f"吸引子{idx+1}：{'[原始模式]' if is_original else '[伪吸引子]'}，出现次数：{count}")