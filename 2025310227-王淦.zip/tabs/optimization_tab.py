import numpy as np
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QDoubleSpinBox,
                               QTextEdit, QFormLayout, QLineEdit, QComboBox)
from PySide6.QtCore import Qt, QThread, Signal
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class OptimizationTab(QWidget):
    def __init__(self):
        super().__init__()
        self.optimization_thread = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 函数设置
        func_group = QGroupBox("目标函数设置")
        func_layout = QVBoxLayout()

        func_label = QLabel("目标函数 (使用x1和x2作为变量):")
        self.func_input = QLineEdit()
        self.func_input.setText("x1**2 + 2*x2**2 + 3")

        func_layout.addWidget(func_label)
        func_layout.addWidget(self.func_input)
        func_group.setLayout(func_layout)

        # 参数设置
        param_group = QGroupBox("优化参数")
        param_layout = QFormLayout()

        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["最速下降法", "牛顿法", "共轭梯度法"])

        self.x1_init = QDoubleSpinBox()
        self.x1_init.setRange(-100, 100)
        self.x1_init.setValue(2.0)
        self.x1_init.setDecimals(4)

        self.x2_init = QDoubleSpinBox()
        self.x2_init.setRange(-100, 100)
        self.x2_init.setValue(2.0)
        self.x2_init.setDecimals(4)

        self.max_iter = QSpinBox()
        self.max_iter.setRange(10, 10000)
        self.max_iter.setValue(100)

        self.tolerance = QDoubleSpinBox()
        self.tolerance.setRange(1e-10, 1e-3)
        self.tolerance.setValue(1e-6)
        self.tolerance.setDecimals(10)

        param_layout.addRow("优化算法:", self.algorithm_combo)
        param_layout.addRow("初始点 x1:", self.x1_init)
        param_layout.addRow("初始点 x2:", self.x2_init)
        param_layout.addRow("最大迭代次数:", self.max_iter)
        param_layout.addRow("收敛容差:", self.tolerance)

        param_group.setLayout(param_layout)

        # 按钮区域
        button_layout = QHBoxLayout()
        self.start_button = QPushButton("开始优化")
        self.stop_button = QPushButton("停止优化")
        self.clear_button = QPushButton("清空结果")

        self.start_button.clicked.connect(self.start_optimization)
        self.stop_button.clicked.connect(self.stop_optimization)
        self.clear_button.clicked.connect(self.clear_results)

        button_layout.addWidget(self.start_button)
        button_layout.addWidget(self.stop_button)
        button_layout.addWidget(self.clear_button)

        # 结果显示
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(12, 8)))

        # 布局
        layout.addWidget(func_group)
        layout.addWidget(param_group)
        layout.addLayout(button_layout)
        layout.addWidget(self.result_text)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def start_optimization(self):
        if self.optimization_thread and self.optimization_thread.isRunning():
            self.result_text.append("已有优化进程在运行!")
            return

        try:
            func_expr = self.func_input.text()
            x0 = [self.x1_init.value(), self.x2_init.value()]
            algorithm = self.algorithm_combo.currentText()
            max_iter = self.max_iter.value()
            tol = self.tolerance.value()

            # 验证函数
            try:
                OptimizationAlgorithms.function(x0, func_expr)
            except Exception as e:
                self.result_text.append(f"函数表达式无效: {e}")
                return

            self.optimization_thread = OptimizationThread(
                algorithm, x0, func_expr, max_iter, tol)
            self.optimization_thread.finish_signal.connect(self.optimization_finished)

            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)

            self.result_text.append(f"开始{algorithm}优化...")
            self.result_text.append(f"目标函数: {func_expr}")
            self.result_text.append(f"初始点: ({x0[0]}, {x0[1]})")

            self.optimization_thread.start()

        except Exception as e:
            self.result_text.append(f"启动优化失败: {e}")

    def stop_optimization(self):
        if self.optimization_thread and self.optimization_thread.isRunning():
            self.result_text.append("正在停止优化...")
            self.optimization_thread.stop()
            self.optimization_thread.wait()
            self.start_button.setEnabled(True)
            self.stop_button.setEnabled(False)

    def optimization_finished(self, result):
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)

        if 'error' in result:
            self.result_text.append(f"优化出错: {result['error']}")
            return

        self.result_text.append("\n优化完成!")
        self.result_text.append(f"最优解: x1 = {result['x_opt'][0]:.6f}, x2 = {result['x_opt'][1]:.6f}")
        self.result_text.append(f"最优值: f(x) = {result['f_opt']:.6f}")
        self.result_text.append(f"迭代次数: {result['iterations']}")

        self.plot_results(result, self.func_input.text())
        self.optimization_thread = None

    def plot_results(self, result, func_expr):
        """绘制优化结果"""
        self.canvas.figure.clear()

        # 创建2x2的子图布局
        ax1 = self.canvas.figure.add_subplot(221, projection='3d')  # 3D曲面
        ax2 = self.canvas.figure.add_subplot(222)  # 等高线
        ax3 = self.canvas.figure.add_subplot(223)  # 误差下降
        ax4 = self.canvas.figure.add_subplot(224)  # 优化路径

        # 生成网格数据
        x1_min, x1_max = -5, 5
        x2_min, x2_max = -5, 5
        x1_range = np.linspace(x1_min, x1_max, 50)
        x2_range = np.linspace(x2_min, x2_max, 50)
        X1, X2 = np.meshgrid(x1_range, x2_range)

        # 计算函数值
        Z = np.zeros_like(X1)
        for i in range(X1.shape[0]):
            for j in range(X1.shape[1]):
                try:
                    Z[i, j] = OptimizationAlgorithms.function([X1[i, j], X2[i, j]], func_expr)
                except:
                    Z[i, j] = np.nan

        # 1. 3D曲面图
        surf = ax1.plot_surface(X1, X2, Z, cmap=cm.coolwarm, alpha=0.7,
                                linewidth=0, antialiased=True)
        ax1.set_title('目标函数曲面')
        ax1.set_xlabel('x1')
        ax1.set_ylabel('x2')
        ax1.set_zlabel('f(x)')

        # 绘制优化路径
        path = result['path']
        if len(path) > 0:
            path_z = [OptimizationAlgorithms.function([p[0], p[1]], func_expr) for p in path]
            ax1.plot(path[:, 0], path[:, 1], path_z, 'ro-', markersize=3, linewidth=2, label='优化路径')
            ax1.legend()

        # 2. 等高线图
        contour = ax2.contourf(X1, X2, Z, 20, cmap=cm.coolwarm, alpha=0.7)
        ax2.contour(X1, X2, Z, 10, colors='black', linewidths=0.5)
        if len(path) > 0:
            ax2.plot(path[:, 0], path[:, 1], 'ro-', markersize=3, linewidth=2, label='优化路径')
            ax2.plot(path[-1, 0], path[-1, 1], 'go', markersize=8, label='最优解')
            ax2.legend()
        ax2.set_title('目标函数等高线')
        ax2.set_xlabel('x1')
        ax2.set_ylabel('x2')

        # 3. 误差下降曲线
        ax3.plot(result['f_values'], 'b-', linewidth=2)
        ax3.set_title('目标函数值下降曲线')
        ax3.set_xlabel('迭代次数')
        ax3.set_ylabel('f(x)')
        ax3.grid(True, alpha=0.3)

        # 4. 优化路径详情
        if len(path) > 0:
            iterations = range(len(path))
            ax4.plot(iterations, path[:, 0], 'r-', label='x1', linewidth=2)
            ax4.plot(iterations, path[:, 1], 'b-', label='x2', linewidth=2)
            ax4.set_title('优化变量变化过程')
            ax4.set_xlabel('迭代次数')
            ax4.set_ylabel('变量值')
            ax4.legend()
            ax4.grid(True, alpha=0.3)

        self.canvas.figure.tight_layout()
        self.canvas.draw()

    def clear_results(self):
        self.result_text.clear()
        self.canvas.figure.clear()
        self.canvas.draw()


class OptimizationAlgorithms:
    @staticmethod
    def function(x, func_expr):
        x1, x2 = x
        try:
            return eval(func_expr)
        except Exception as e:
            raise ValueError(f"函数计算错误: {e}")

    @staticmethod
    def gradient(x, func_expr, epsilon=1e-6):
        x1, x2 = x
        f_x1_plus = OptimizationAlgorithms.function([x1 + epsilon, x2], func_expr)
        f_x1_minus = OptimizationAlgorithms.function([x1 - epsilon, x2], func_expr)
        df_dx1 = (f_x1_plus - f_x1_minus) / (2 * epsilon)

        f_x2_plus = OptimizationAlgorithms.function([x1, x2 + epsilon], func_expr)
        f_x2_minus = OptimizationAlgorithms.function([x1, x2 - epsilon], func_expr)
        df_dx2 = (f_x2_plus - f_x2_minus) / (2 * epsilon)

        return np.array([df_dx1, df_dx2])

    @staticmethod
    def hessian(x, func_expr, epsilon=1e-6):
        x1, x2 = x
        grad = OptimizationAlgorithms.gradient(x, func_expr, epsilon)

        h1 = OptimizationAlgorithms.gradient([x1 + epsilon, x2], func_expr, epsilon)
        h2 = OptimizationAlgorithms.gradient([x1 - epsilon, x2], func_expr, epsilon)
        d2f_dx12 = (h1[0] - h2[0]) / (2 * epsilon)

        h3 = OptimizationAlgorithms.gradient([x1, x2 + epsilon], func_expr, epsilon)
        h4 = OptimizationAlgorithms.gradient([x1, x2 - epsilon], func_expr, epsilon)
        d2f_dx22 = (h3[1] - h4[1]) / (2 * epsilon)

        d2f_dx1dx2 = (h1[1] - h2[1]) / (2 * epsilon)

        return np.array([[d2f_dx12, d2f_dx1dx2], [d2f_dx1dx2, d2f_dx22]])

    @staticmethod
    def line_search(x, d, func_expr, alpha_init=1.0, c1=1e-4, rho=0.5):
        alpha = alpha_init
        f_x = OptimizationAlgorithms.function(x, func_expr)
        grad_x = OptimizationAlgorithms.gradient(x, func_expr)
        grad_dot_d = np.dot(grad_x, d)

        while True:
            x_new = x + alpha * d
            f_x_new = OptimizationAlgorithms.function(x_new, func_expr)
            if f_x_new <= f_x + c1 * alpha * grad_dot_d:
                return alpha
            alpha *= rho
            if alpha < 1e-10:
                return alpha

    @staticmethod
    def steepest_descent(x0, func_expr, max_iter=100, tol=1e-6):
        x = np.array(x0, dtype=np.float64)
        path = [x.copy()]
        f_values = [OptimizationAlgorithms.function(x, func_expr)]

        for i in range(max_iter):
            grad = OptimizationAlgorithms.gradient(x, func_expr)
            if np.linalg.norm(grad) < tol:
                break

            d = -grad
            alpha = OptimizationAlgorithms.line_search(x, d, func_expr)
            x += alpha * d

            path.append(x.copy())
            f_values.append(OptimizationAlgorithms.function(x, func_expr))

        return {
            'x_opt': x,
            'f_opt': OptimizationAlgorithms.function(x, func_expr),
            'iterations': len(path) - 1,
            'path': np.array(path),
            'f_values': np.array(f_values)
        }

    @staticmethod
    def newton_method(x0, func_expr, max_iter=100, tol=1e-6):
        x = np.array(x0, dtype=np.float64)
        path = [x.copy()]
        f_values = [OptimizationAlgorithms.function(x, func_expr)]

        for i in range(max_iter):
            grad = OptimizationAlgorithms.gradient(x, func_expr)
            if np.linalg.norm(grad) < tol:
                break

            hess = OptimizationAlgorithms.hessian(x, func_expr)
            try:
                np.linalg.cholesky(hess)
            except np.linalg.LinAlgError:
                hess += np.eye(hess.shape[0]) * 1e-6

            d = -np.linalg.solve(hess, grad)
            alpha = OptimizationAlgorithms.line_search(x, d, func_expr, alpha_init=1.0)
            x += alpha * d

            path.append(x.copy())
            f_values.append(OptimizationAlgorithms.function(x, func_expr))

        return {
            'x_opt': x,
            'f_opt': OptimizationAlgorithms.function(x, func_expr),
            'iterations': len(path) - 1,
            'path': np.array(path),
            'f_values': np.array(f_values)
        }

    @staticmethod
    def conjugate_gradient(x0, func_expr, max_iter=100, tol=1e-6):
        x = np.array(x0, dtype=np.float64)
        path = [x.copy()]
        f_values = [OptimizationAlgorithms.function(x, func_expr)]

        grad = OptimizationAlgorithms.gradient(x, func_expr)
        d = -grad

        for i in range(max_iter):
            if np.linalg.norm(grad) < tol:
                break

            alpha = OptimizationAlgorithms.line_search(x, d, func_expr)
            x += alpha * d
            grad_new = OptimizationAlgorithms.gradient(x, func_expr)

            beta = np.dot(grad_new, grad_new) / np.dot(grad, grad)
            d = -grad_new + beta * d

            grad = grad_new.copy()
            path.append(x.copy())
            f_values.append(OptimizationAlgorithms.function(x, func_expr))

        return {
            'x_opt': x,
            'f_opt': OptimizationAlgorithms.function(x, func_expr),
            'iterations': len(path) - 1,
            'path': np.array(path),
            'f_values': np.array(f_values)
        }


class OptimizationThread(QThread):
    update_signal = Signal(dict)
    finish_signal = Signal(dict)

    def __init__(self, algorithm, x0, func_expr, max_iter, tol):
        super().__init__()
        self.algorithm = algorithm
        self.x0 = x0
        self.func_expr = func_expr
        self.max_iter = max_iter
        self.tol = tol
        self.running = True

    def run(self):
        try:
            if self.algorithm == "最速下降法":
                result = OptimizationAlgorithms.steepest_descent(
                    self.x0, self.func_expr, self.max_iter, self.tol)
            elif self.algorithm == "牛顿法":
                result = OptimizationAlgorithms.newton_method(
                    self.x0, self.func_expr, self.max_iter, self.tol)
            elif self.algorithm == "共轭梯度法":
                result = OptimizationAlgorithms.conjugate_gradient(
                    self.x0, self.func_expr, self.max_iter, self.tol)
            else:
                result = {'error': '未知算法'}

            self.finish_signal.emit(result)
        except Exception as e:
            self.finish_signal.emit({'error': str(e)})

    def stop(self):
        self.running = False