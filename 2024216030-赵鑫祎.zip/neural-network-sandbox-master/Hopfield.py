import sys
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QComboBox, QGridLayout, QFrame
)
from PyQt5.QtCore import Qt


class HopfieldNetwork:
    """离散型Hopfield神经网络（DHN）的核心逻辑"""
    def __init__(self, n_neurons):
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))

    def train(self, patterns):
        """Hebb规则训练"""
        P, N = patterns.shape
        if N != self.n_neurons:
            raise ValueError(f"Pattern size {N} does not match network size {self.n_neurons}")
        
        self.weights = (1.0 / N) * (patterns.T @ patterns)
        np.fill_diagonal(self.weights, 0) 

    def calculate_energy(self, state):
        """计算能量"""
        energy = -0.5 * (state.T @ self.weights @ state)
        return energy

    def update_async(self, probe_pattern, max_iters=1000):
        """异步更新"""
        current_state = probe_pattern.copy()
        
        for _ in range(max_iters):
            stable = True
            indices = np.random.permutation(self.n_neurons)
            
            for i in indices:
                h_i = self.weights[i, :] @ current_state
                new_state_i = 1 if h_i >= 0 else -1
                
                if new_state_i != current_state[i]:
                    current_state[i] = new_state_i
                    stable = False
            
            if stable:
                break
        
        final_energy = self.calculate_energy(current_state)
        return current_state, final_energy

class PatternWidget(QWidget):
    """使用QGridLayout和QLabel显示一个5x5模式的控件"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.grid_shape = (5, 5)
        self.labels = []
        
        layout = QGridLayout()
        layout.setSpacing(1)
        layout.setContentsMargins(0, 0, 0, 0)
        
        for r in range(self.grid_shape[0]):
            row_labels = []
            for c in range(self.grid_shape[1]):
                label = QLabel()
                label.setFixedSize(20, 20)
                label.setStyleSheet("background-color: white; border: 1px solid lightgray;")
                layout.addWidget(label, r, c)
                row_labels.append(label)
            self.labels.append(row_labels)
            
        self.setLayout(layout)
        self.setFixedSize(105, 105)

    def set_pattern(self, pattern_1d):
        """根据1D模式数据更新网格颜色"""
        if pattern_1d is None:
             pattern_1d = -1 * np.ones(25) # 默认为全白
             
        pattern_2d = pattern_1d.reshape(self.grid_shape)
        
        for r in range(self.grid_shape[0]):
            for c in range(self.grid_shape[1]):
                color = "black" if pattern_2d[r, c] == 1 else "white"
                self.labels[r][c].setStyleSheet(f"background-color: {color};")

class HopfieldVisualizerSimple(QMainWindow):
    """PyQt5主窗口"""
    
    def __init__(self):
        super().__init__()
        self.n_neurons = 25
        self.grid_shape = (5, 5)
        self.hopfield_net = HopfieldNetwork(self.n_neurons)
        self.current_probe_1d = None
        
        self.define_patterns()
        self.init_ui()
        self.train_network()

    def define_patterns(self):
        """定义要存储的模式 (T, C, H)"""
        pattern_T = np.array([
            [ 1,  1,  1,  1,  1], [-1, -1,  1, -1, -1], [-1, -1,  1, -1, -1],
            [-1, -1,  1, -1, -1], [-1, -1,  1, -1, -1]
        ])
        pattern_C = np.array([
            [ 1,  1,  1,  1, -1], [ 1, -1, -1, -1, -1], [ 1, -1, -1, -1, -1],
            [ 1, -1, -1, -1, -1], [ 1,  1,  1,  1, -1]
        ])
        pattern_H = np.array([
            [ 1, -1, -1, -1,  1], [ 1, -1, -1, -1,  1], [ 1,  1,  1,  1,  1],
            [ 1, -1, -1, -1,  1], [ 1, -1, -1, -1,  1]
        ])
        
        self.patterns_2d = {
            "T": pattern_T, "C": pattern_C, "H": pattern_H
        }
        self.patterns_1d = np.array([
            p.flatten() for p in self.patterns_2d.values()
        ])

    def train_network(self):
        """训练网络"""
        self.hopfield_net.train(self.patterns_1d)

    def init_ui(self):
        """初始化GUI (移除第二个按钮)"""
        self.setWindowTitle("Hopfield Network (Auto-Run)")
        self.setGeometry(200, 200, 450, 400)
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # --- 1. 存储模式区 ---
        stored_layout = QHBoxLayout()
        stored_layout.addWidget(QLabel("<b>Stored (T, C, H):</b>"))
        self.widget_T = PatternWidget()
        self.widget_C = PatternWidget()
        self.widget_H = PatternWidget()
        self.widget_T.set_pattern(self.patterns_2d["T"].flatten())
        self.widget_C.set_pattern(self.patterns_2d["C"].flatten())
        self.widget_H.set_pattern(self.patterns_2d["H"].flatten())
        stored_layout.addWidget(self.widget_T)
        stored_layout.addWidget(self.widget_C)
        stored_layout.addWidget(self.widget_H)
        stored_layout.addStretch()
        main_layout.addLayout(stored_layout)
        
        main_layout.addWidget(self.create_separator())

        # --- 2. 控制区 ---
        control_layout = QVBoxLayout()
        control_layout.addWidget(QLabel("<b>Click button to generate probe and run:</b>"))
        
        # 噪声控制
        noise_layout = QHBoxLayout()
        self.combo_pattern = QComboBox()
        self.combo_pattern.addItems(self.patterns_2d.keys())
        noise_layout.addWidget(self.combo_pattern)
        
        self.noise_label = QLabel("Noise: 10%")
        noise_layout.addWidget(self.noise_label)
        
        self.slider_noise = QSlider(Qt.Horizontal)
        self.slider_noise.setRange(0, 100)
        self.slider_noise.setValue(10)
        self.slider_noise.valueChanged.connect(lambda v: self.noise_label.setText(f"Noise: {v}%"))
        noise_layout.addWidget(self.slider_noise)
        control_layout.addLayout(noise_layout)

        # 唯一的按钮
        self.btn_gen_and_run = QPushButton("Generate and Run")
        self.btn_gen_and_run.clicked.connect(self.generate_and_run)
        control_layout.addWidget(self.btn_gen_and_run)
        
        main_layout.addLayout(control_layout)
        main_layout.addWidget(self.create_separator())

        # --- 3. 探针 和 吸引子 ---
        test_layout = QHBoxLayout()
        
        # 探针 (左)
        probe_vbox = QVBoxLayout()
        probe_vbox.addWidget(QLabel("<b>Probe (Input)</b>"))
        self.widget_probe = PatternWidget()
        self.widget_probe.set_pattern(None) # 默认空白
        probe_vbox.addWidget(self.widget_probe, 0, Qt.AlignCenter)
        probe_vbox.addStretch()
        
        # 吸引子 (右)
        attractor_vbox = QVBoxLayout()
        attractor_vbox.addWidget(QLabel("<b>Attractor (Output)</b>"))
        self.widget_attractor = PatternWidget()
        self.widget_attractor.set_pattern(None) # 默认空白
        attractor_vbox.addWidget(self.widget_attractor, 0, Qt.AlignCenter)
        
        self.label_energy = QLabel("<b>Final Energy:</b> N/A")
        self.label_energy.setAlignment(Qt.AlignCenter)
        attractor_vbox.addWidget(self.label_energy)
        attractor_vbox.addStretch()

        test_layout.addLayout(probe_vbox)
        test_layout.addLayout(attractor_vbox)
        main_layout.addLayout(test_layout)
        main_layout.addStretch()

    def create_separator(self):
        """创建一个水平分割线"""
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        return line

    def generate_and_run(self):
        """
        合并了生成和运行两个步骤
        """
        # --- 1. 生成探针 (原 generate_probe) ---
        pattern_key = self.combo_pattern.currentText()
        base_pattern_1d = self.patterns_2d[pattern_key].flatten()
        noise_level = self.slider_noise.value()
        
        n_flip = int((noise_level / 100.0) * self.n_neurons)
        indices_to_flip = np.random.choice(self.n_neurons, n_flip, replace=False)
        
        noisy_pattern_1d = base_pattern_1d.copy()
        noisy_pattern_1d[indices_to_flip] *= -1 # 翻转
        
        self.current_probe_1d = noisy_pattern_1d
        
        # 绘制探针
        self.widget_probe.set_pattern(noisy_pattern_1d)
        
        # 清理旧结果
        self.widget_attractor.set_pattern(None)
        self.label_energy.setText("<b>Final Energy:</b> N/A")

        self.btn_gen_and_run.setEnabled(False)
        
 
        QApplication.processEvents() 

        if self.current_probe_1d is None:
            self.btn_gen_and_run.setEnabled(True)
            return

        # 核心：运行异步更新
        attractor, final_energy = self.hopfield_net.update_async(
            self.current_probe_1d
        )
        
        # 1. 可视化吸引子
        self.widget_attractor.set_pattern(attractor)
        
        # 2. 可视化吸引子能量（最终值）
        self.label_energy.setText(f"<b>Final Energy:</b> {final_energy:.4f}")

        # 重新启用按钮
        self.btn_gen_and_run.setEnabled(True)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_win = HopfieldVisualizerSimple()
    main_win.show()
    sys.exit(app.exec_())