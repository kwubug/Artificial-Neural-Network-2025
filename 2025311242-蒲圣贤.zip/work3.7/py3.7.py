# python是面向对象的解释型高级编程语言
print("Hello world")
# 运行py文件推荐使用方式：右键点击代码空白处，选择run

print(123)