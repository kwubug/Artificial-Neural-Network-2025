#!/usr/bin/env python3
"""
牛顿法MLP算法测试脚本
"""

import numpy as np
from nn_sandbox.backend.algorithms.newton_mlp_algorithm import NewtonMlpAlgorithm

def test_newton_mlp():
    """测试牛顿法MLP算法"""
    print("=== 牛顿法MLP算法测试 ===")
    
    # 创建简单的测试数据集（XOR问题）
    dataset = np.array([
        [0, 0, 0],
        [0, 1, 1],
        [1, 0, 1],
        [1, 1, 0]
    ])
    
    print(f"数据集: {dataset}")
    
    # 创建牛顿法MLP算法实例
    algorithm = NewtonMlpAlgorithm(
        dataset=dataset,
        total_epoches=100,
        most_correct_rate=0.95,
        initial_learning_rate=0.8,
        search_iteration_constant=1000,
        test_ratio=0.3,
        network_shape=(4,),
        activation_function='sigmoid',
        newton_update_frequency=5
    )
    
    print("算法参数:")
    print(f"  网络形状: {algorithm.network_shape}")
    print(f"  激活函数: {algorithm.activation_function}")
    print(f"  牛顿更新频率: {algorithm.newton_update_frequency}")
    print(f"  训练轮次: {algorithm._total_epoches}")
    
    # 初始化神经元
    algorithm._initialize_neurons()
    print(f"神经元网络已初始化，层数: {len(algorithm._neurons)}")
    
    # 测试前向传播
    test_data = [0, 1]
    result = algorithm._feed_forward(test_data)
    print(f"前向传播测试 - 输入: {test_data}, 输出: {result:.4f}")
    
    # 测试反向传播
    expect = 1.0
    deltas = algorithm._pass_backward(expect, result)
    print(f"反向传播测试 - 期望: {expect}, 实际: {result:.4f}")
    print(f"计算得到的误差项数量: {len(deltas)}")
    
    # 测试牛顿法更新
    print("\n测试牛顿法权重更新...")
    try:
        algorithm._compute_gradients(deltas)
        print("梯度计算成功")
        
        # 测试牛顿法更新
        algorithm._adjust_weights_with_newton()
        print("牛顿法权重更新成功")
        
        # 测试梯度下降更新
        algorithm._adjust_weights_with_gradient(deltas)
        print("梯度下降权重更新成功")
        
    except Exception as e:
        print(f"权重更新测试失败: {e}")
    
    # 测试正确率计算
    correct_rate = algorithm._correct_rate(dataset)
    print(f"初始正确率: {correct_rate:.4f}")
    
    print("\n=== 测试完成 ===")

if __name__ == "__main__":
    test_newton_mlp()