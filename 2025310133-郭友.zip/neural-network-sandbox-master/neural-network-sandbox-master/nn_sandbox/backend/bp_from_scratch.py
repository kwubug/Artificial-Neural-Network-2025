import numpy as np

def one_hot(y, num_classes=None):
    y = np.array(y).astype(int)
    num_classes = num_classes or np.max(y) + 1
    return np.eye(num_classes)[y]

def accuracy(y_true, y_pred):
    y_true = np.argmax(y_true, axis=1)
    y_pred = np.argmax(y_pred, axis=1)
    return np.mean(y_true == y_pred)

class MLP:
    def __init__(self, input_size, hidden_layers, output_size, lr=0.01):
        self.lr = lr
        self.weights = []
        layer_sizes = [input_size] + hidden_layers + [output_size]
        for i in range(len(layer_sizes) - 1):
            self.weights.append(np.random.randn(layer_sizes[i], layer_sizes[i+1]) * 0.1)

    def forward(self, X):
        a = X
        for W in self.weights[:-1]:
            a = np.tanh(a @ W)
        return self.softmax(a @ self.weights[-1])

    def softmax(self, x):
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)

    def train(self, X, y, epochs=100):
        # dummy implementation
        for _ in range(epochs):
            pass
