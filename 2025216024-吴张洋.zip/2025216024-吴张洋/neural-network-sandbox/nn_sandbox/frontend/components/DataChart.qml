import QtQuick.Controls 2.5
import QtCharts 2.3

ChartView {
    property var scatterSeriesMap: ({})
    property var classificationAreas: ({})
    property alias xAxis: xAxis
    property alias yAxis: yAxis
    property alias chartToolTip: chartToolTip
    property var networkWeights: null
    property int inputNodes: 2
    property int hiddenNodes: 5
    property int outputNodes: 1
    property string activationType: 'unipolar'
    property var dataset: []
    

    antialiasing: true
    legend.visible: false
    ValueAxis{
        id: xAxis
        min: -1.0
        max: 1.0
    }
    ValueAxis{
        id: yAxis
        min: -1.0
        max: 1.0
    }
    ToolTip {
        id: chartToolTip
    }

    function updateDataset(dataset) {
        this.dataset = dataset
        clear()
        addScatterSeries(dataset)
        updateAxesRange(dataset)
        updateClassificationAreas()
    }

    function updateNetworkWeights() {
        if (dataset && dataset.length > 0) {
            updateClassificationAreas()
        }
    }

    function updateTrainingDataset(dataset) {
        addScatterSeries(dataset)
    }

    function updateTestingDataset(dataset) {
        dataset.sort((a, b) => {return a[2] - b[2]})
        for (let data of dataset) {
            if (!(`${data[2]}test` in scatterSeriesMap)) {
                scatterSeriesMap[`${data[2]}test`] = createHoverableScatterSeries(`${data[2]}test`)
                if (data[2] in scatterSeriesMap)
                    scatterSeriesMap[`${data[2]}test`].color = Qt.lighter(scatterSeriesMap[data[2]].color)
            }
            scatterSeriesMap[`${data[2]}test`].append(...data)
        }
    }

    function addScatterSeries(dataset) {
        dataset.sort((a, b) => {return a[2] - b[2]})
        for (let data of dataset) {
            if (!(data[2] in scatterSeriesMap))
                scatterSeriesMap[data[2]] = createHoverableScatterSeries(data[2])
            scatterSeriesMap[data[2]].append(...data)
        }
    }

    function createHoverableScatterSeries(name) {
        const newSeries = createSeries(
            ChartView.SeriesTypeScatter, name, xAxis, yAxis
        )
        newSeries.hovered.connect((point, state) => {
            const position = mapToPosition(point)
            chartToolTip.x = position.x - chartToolTip.width
            chartToolTip.y = position.y - chartToolTip.height
            chartToolTip.text = `(${point.x}, ${point.y})`
            chartToolTip.visible = state
        })
        return newSeries
    }

    function updateAxesRange(dataset) {
        let xMax = -Infinity, yMax = -Infinity, xMin = Infinity, yMin = Infinity
        for (let row of dataset) {
            xMax = Math.max(xMax, row[0])
            xMin = Math.min(xMin, row[0])
            yMax = Math.max(yMax, row[1])
            yMin = Math.min(yMin, row[1])
        }
        xAxis.max = xMax + 0.1 * (xMax - xMin)
        xAxis.min = xMin - 0.1 * (xMax - xMin)
        yAxis.max = yMax + 0.1 * (yMax - yMin)
        yAxis.min = yMin - 0.1 * (yMax - yMin)
    }

    function updateClassificationAreas() {
        if (!networkWeights || !networkWeights.input_hidden_weights) {
            return
        }
        
        // 清除之前的分类区域
        for (let key in classificationAreas) {
            const areaData = classificationAreas[key]
            if (areaData && areaData.fillSeries) {
                try {
                    removeSeries(areaData.fillSeries)
                } catch (e) {
                    // 忽略移除错误
                }
            }
            if (areaData && areaData.borderSeries) {
                try {
                    removeSeries(areaData.borderSeries)
                } catch (e) {
                    // 忽略移除错误
                }
            }
        }
        classificationAreas = {}
        
        // 生成分类区域
        generateClassificationAreas()
    }

    function generateClassificationAreas() {
        if (!networkWeights || !networkWeights.input_hidden_weights) {
            return
        }
        
        const resolution = 40  // 进一步提高分辨率以获得更密集的填充
        const xStep = (xAxis.max - xAxis.min) / resolution
        const yStep = (yAxis.max - yAxis.min) / resolution
        
        // 获取数据点的颜色作为基础颜色
        const baseColors = getDataPointColors()
        
        // 为每个类别创建半透明填充区域
        for (let classId = 1; classId <= outputNodes; classId++) {
            try {
                // 使用ScatterSeries创建半透明填充区域
                const fillSeries = createSeries(
                    ChartView.SeriesTypeScatter, `类别${classId}填充`, xAxis, yAxis
                )
                
                // 使用与数据点相似的颜色，但更透明
                const baseColor = baseColors[classId - 1] || baseColors[0]
                if (baseColor) {
                    fillSeries.color = Qt.rgba(baseColor.r, baseColor.g, baseColor.b, 0.5)
                } else {
                    // 默认颜色
                    fillSeries.color = Qt.rgba(0.5, 0.5, 0.5, 0.5)
                }
                fillSeries.markerSize = 10
                fillSeries.borderWidth = 0
                
                // 创建边界线系列
                const borderSeries = createSeries(
                    ChartView.SeriesTypeLine, `类别${classId}边界`, xAxis, yAxis
                )
                
                if (baseColor) {
                    borderSeries.color = Qt.rgba(baseColor.r, baseColor.g, baseColor.b, 0.8)
                } else {
                    borderSeries.color = Qt.rgba(0.5, 0.5, 0.5, 0.8)
                }
                borderSeries.width = 2
                borderSeries.style = Qt.SolidLine
                
                classificationAreas[`area_${classId}`] = {
                    fillSeries: fillSeries,
                    borderSeries: borderSeries
                }
            } catch (e) {
                // 忽略创建错误
            }
        }
        
        // 生成分类网格并创建多边形
        const classificationGrid = []
        for (let i = 0; i <= resolution; i++) {
            classificationGrid[i] = []
            for (let j = 0; j <= resolution; j++) {
                const x = xAxis.min + i * xStep
                const y = yAxis.min + j * yStep
                const prediction = predictClassification([x, y])
                classificationGrid[i][j] = prediction
            }
        }
        
        // 为每个类别生成多边形区域
        for (let classId = 1; classId <= outputNodes; classId++) {
            generatePolygonForClass(classificationGrid, classId, xStep, yStep)
        }
    }

    function getDataPointColors() {
        // 获取数据点的颜色
        const colors = []
        for (let key in scatterSeriesMap) {
            if (scatterSeriesMap[key] && scatterSeriesMap[key].color) {
                colors.push(scatterSeriesMap[key].color)
            }
        }
        return colors
    }

    function generatePolygonForClass(grid, classId, xStep, yStep) {
        const areaData = classificationAreas[`area_${classId}`]
        if (!areaData) {
            return
        }
        
        const { fillSeries, borderSeries } = areaData
        
        // 收集属于该类别的所有点
        const allPoints = []
        const resolution = grid.length - 1
        
        for (let i = 0; i <= resolution; i++) {
            for (let j = 0; j <= resolution; j++) {
                if (grid[i][j] === classId) {
                    const x = xAxis.min + i * xStep
                    const y = yAxis.min + j * yStep
                    allPoints.push({x: x, y: y})
                }
            }
        }
        
        if (allPoints.length === 0) {
            return
        }
        
        // 为填充区域添加所有点
        for (let point of allPoints) {
            try {
                fillSeries.append(point.x, point.y)
            } catch (e) {
                // 忽略添加错误
            }
        }
        
        // 生成边界线
        const boundaryPoints = findBoundaryPoints(grid, classId, xStep, yStep)
        if (boundaryPoints.length >= 3) {
            const simplifiedPoints = simplifyBoundary(boundaryPoints)
            
            // 为边界线添加点
            for (let point of simplifiedPoints) {
                try {
                    borderSeries.append(point.x, point.y)
                } catch (e) {
                    // 忽略添加错误
                }
            }
            
            // 闭合边界线
            if (simplifiedPoints.length > 0) {
                try {
                    borderSeries.append(simplifiedPoints[0].x, simplifiedPoints[0].y)
                } catch (e) {
                    // 忽略闭合错误
                }
            }
        }
    }
    
    function findBoundaryPoints(grid, classId, xStep, yStep) {
        const resolution = grid.length - 1
        const boundaryPoints = []
        const visited = new Set()
        
        // 找到边界点
        for (let i = 0; i <= resolution; i++) {
            for (let j = 0; j <= resolution; j++) {
                if (grid[i][j] === classId) {
                    const x = xAxis.min + i * xStep
                    const y = yAxis.min + j * yStep
                    
                    // 检查是否是边界点
                    let isBoundary = false
                    if (i === 0 || j === 0 || i === resolution || j === resolution) {
                        isBoundary = true
                    } else {
                        // 检查邻居
                        const neighbors = [
                            grid[i-1][j], grid[i+1][j], grid[i][j-1], grid[i][j+1]
                        ]
                        for (let neighbor of neighbors) {
                            if (neighbor !== classId) {
                                isBoundary = true
                                break
                            }
                        }
                    }
                    
                    if (isBoundary) {
                        boundaryPoints.push({x: x, y: y})
                    }
                }
            }
        }
        
        return boundaryPoints
    }
    
    function simplifyBoundary(points) {
        if (points.length <= 3) {
            return points
        }
        
        // 使用Douglas-Peucker算法的简化版本
        const simplified = []
        const tolerance = 0.1
        
        // 按角度排序点
        const center = {x: 0, y: 0}
        for (let point of points) {
            center.x += point.x
            center.y += point.y
        }
        center.x /= points.length
        center.y /= points.length
        
        points.sort((a, b) => {
            const angleA = Math.atan2(a.y - center.y, a.x - center.x)
            const angleB = Math.atan2(b.y - center.y, b.x - center.x)
            return angleA - angleB
        })
        
        // 简化：每隔几个点取一个
        const step = Math.max(1, Math.floor(points.length / 20))
        for (let i = 0; i < points.length; i += step) {
            simplified.push(points[i])
        }
        
        // 确保包含最后一个点
        if (simplified[simplified.length - 1] !== points[points.length - 1]) {
            simplified.push(points[points.length - 1])
        }
        
        return simplified
    }

    function predictClassification(input) {
        if (!networkWeights || !networkWeights.input_hidden_weights) {
            return 1
        }
        
        // 前向传播
        const weights_input_hidden = networkWeights.input_hidden_weights
        const weights_hidden_output = networkWeights.hidden_output_weights
        const bias_hidden = networkWeights.hidden_bias
        const bias_output = networkWeights.output_bias
        
        // 隐藏层计算
        let hidden_inputs = []
        for (let i = 0; i < hiddenNodes; i++) {
            let sum = bias_hidden[i]
            for (let j = 0; j < inputNodes; j++) {
                sum += input[j] * weights_input_hidden[j][i]
            }
            hidden_inputs.push(sum)
        }
        
        let hidden_outputs = hidden_inputs.map(x => activationFunction(x))
        
        // 输出层计算
        let output_inputs = []
        for (let i = 0; i < outputNodes; i++) {
            let sum = bias_output[i]
            for (let j = 0; j < hiddenNodes; j++) {
                sum += hidden_outputs[j] * weights_hidden_output[j][i]
            }
            output_inputs.push(sum)
        }
        
        let final_outputs = output_inputs.map(x => activationFunction(x))
        
        // 预测分类
        let prediction
        if (outputNodes === 1) {
            // 二分类
            if (activationType === 'unipolar') {
                prediction = final_outputs[0] > 0.5 ? 1 : 0
            } else {
                prediction = final_outputs[0] > 0 ? 1 : -1
            }
        } else {
            // 多分类
            let maxIndex = 0
            for (let i = 1; i < final_outputs.length; i++) {
                if (final_outputs[i] > final_outputs[maxIndex]) {
                    maxIndex = i
                }
            }
            prediction = maxIndex + 1
        }
        
        return prediction
    }

    function activationFunction(x) {
        if (activationType === 'unipolar') {
            return 1 / (1 + Math.exp(-x))
        } else {
            return 2 / (1 + Math.exp(-x)) - 1
        }
    }

    function clear() {
        // 清除分类区域
        for (let key in classificationAreas) {
            const areaData = classificationAreas[key]
            if (areaData && areaData.fillSeries) {
                try {
                    removeSeries(areaData.fillSeries)
                } catch (e) {
                    // 忽略移除错误
                }
            }
            if (areaData && areaData.borderSeries) {
                try {
                    removeSeries(areaData.borderSeries)
                } catch (e) {
                    // 忽略移除错误
                }
            }
        }
        
        removeAllSeries()
        scatterSeriesMap = {}
        classificationAreas = {}
    }
}