"""
离散型Hopfield神经网络核心实现
包含异步更新、吸引子检测和能量计算功能
"""
import numpy as np
from typing import List, Tuple, Optional
import copy


class HopfieldNetwork:
    """离散型Hopfield神经网络"""
    
    def __init__(self, n_neurons: int):
        """
        初始化Hopfield网络
        
        Args:
            n_neurons: 神经元数量
        """
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.state = np.ones(n_neurons)  # 初始状态为全1
        
    def train(self, patterns: List[np.ndarray]):
        """
        使用Hebb学习规则训练网络
        
        Args:
            patterns: 训练模式列表，每个模式是长度为n_neurons的数组，值为-1或1
        """
        # 初始化权重矩阵
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        
        # Hebb学习规则：W = (1/N) * sum(x_i * x_j^T) - I
        for pattern in patterns:
            pattern = pattern.reshape(-1, 1)
            self.weights += np.outer(pattern, pattern)
        
        # 归一化并移除对角线（自连接）
        self.weights /= len(patterns)
        np.fill_diagonal(self.weights, 0)
        
    def energy(self, state: Optional[np.ndarray] = None) -> float:
        """
        计算网络能量函数 E = -0.5 * sum_i sum_j W_ij * S_i * S_j
        
        Args:
            state: 网络状态，如果为None则使用当前状态
            
        Returns:
            能量值
        """
        if state is None:
            state = self.state
        
        energy = -0.5 * np.sum(self.weights * np.outer(state, state))
        return float(energy)
    
    def update_neuron(self, index: int) -> bool:
        """
        异步更新单个神经元
        
        Args:
            index: 要更新的神经元索引
            
        Returns:
            是否发生了状态变化
        """
        # 计算输入：h_i = sum_j W_ij * S_j
        input_sum = np.dot(self.weights[index, :], self.state)
        
        # 更新规则：S_i = sign(h_i)
        new_state = 1 if input_sum >= 0 else -1
        
        # 检查状态是否改变
        changed = (self.state[index] != new_state)
        self.state[index] = new_state
        
        return changed
    
    def async_update(self, max_iterations: int = 1000, 
                     random_order: bool = True) -> Tuple[np.ndarray, List[float], int]:
        """
        异步更新网络直到收敛
        
        Args:
            max_iterations: 最大迭代次数
            random_order: 是否随机顺序更新神经元
            
        Returns:
            (最终状态, 能量历史, 迭代次数)
        """
        energy_history = [self.energy()]
        iteration = 0
        
        # 创建更新顺序
        indices = list(range(self.n_neurons))
        
        for iteration in range(max_iterations):
            if random_order:
                np.random.shuffle(indices)
            
            changed = False
            for idx in indices:
                if self.update_neuron(idx):
                    changed = True
                    energy_history.append(self.energy())
            
            # 如果没有状态改变，说明已收敛
            if not changed:
                break
        
        return self.state.copy(), energy_history, iteration + 1
    
    def find_attractor(self, initial_state: np.ndarray, 
                      max_iterations: int = 1000) -> Tuple[np.ndarray, List[float], int]:
        """
        从初始状态找到吸引子
        
        Args:
            initial_state: 初始状态
            max_iterations: 最大迭代次数
            
        Returns:
            (吸引子状态, 能量历史, 迭代次数)
        """
        self.state = initial_state.copy()
        return self.async_update(max_iterations)
    
    def is_attractor(self, state: np.ndarray) -> bool:
        """
        检查给定状态是否是吸引子（固定点）
        
        Args:
            state: 要检查的状态
            
        Returns:
            如果是吸引子返回True
        """
        # 临时保存当前状态
        original_state = self.state.copy()
        self.state = state.copy()
        
        # 尝试更新所有神经元
        changed = False
        for i in range(self.n_neurons):
            if self.update_neuron(i):
                changed = True
                break
        
        # 恢复原始状态
        self.state = original_state
        
        # 如果没有改变，说明是吸引子
        return not changed
    
    def get_all_attractors(self, max_patterns: int = 1000) -> List[Tuple[np.ndarray, float]]:
        """
        通过随机采样找到所有吸引子
        
        Args:
            max_patterns: 最大采样次数
            
        Returns:
            吸引子列表，每个元素为(状态, 能量)
        """
        attractors = []
        seen_states = set()
        
        for _ in range(max_patterns):
            # 生成随机初始状态
            initial_state = np.random.choice([-1, 1], size=self.n_neurons)
            initial_state_str = tuple(initial_state)
            
            # 如果已经探索过，跳过
            if initial_state_str in seen_states:
                continue
            
            # 找到吸引子
            attractor_state, _, _ = self.find_attractor(initial_state)
            attractor_str = tuple(attractor_state)
            
            # 检查是否是新的吸引子
            if attractor_str not in seen_states:
                energy = self.energy(attractor_state)
                attractors.append((attractor_state.copy(), energy))
                seen_states.add(attractor_str)
        
        # 按能量排序
        attractors.sort(key=lambda x: x[1])
        return attractors

