import os
from anthropic import Anthropic

# 若未用 setx，也可在代码中直接写
os.environ["ANTHROPIC_AUTH_TOKEN"] = "你的ZhipuKey"
os.environ["ANTHROPIC_BASE_URL"] = "https://open.bigmodel.cn/api/anthropic"

client = Anthropic()
resp = client.messages.create(
    model="claude-3-5-sonnet-latest",
    max_tokens=100,
    messages=[{"role":"user","content":"用一句话告诉我你是否连通了"}]
)
print(resp.content[0].text)
