import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield-TSP'

    ColumnLayout {
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label { text: 'Cities (n)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 8
                    from: 5; to: 30
                    onValueChanged: hopfieldTspBridge.n = value
                    Component.onCompleted: hopfieldTspBridge.n = value
                    Layout.fillWidth: true
                }
                Label { text: 'Seed'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 42
                    from: 0; to: 9999
                    onValueChanged: hopfieldTspBridge.seed = value
                    Component.onCompleted: hopfieldTspBridge.seed = value
                    Layout.fillWidth: true
                }
                Label { text: 'A (row penalty)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 50 * 1
                    onValueChanged: hopfieldTspBridge.A = value
                    Component.onCompleted: hopfieldTspBridge.A = value
                    Layout.fillWidth: true
                }
                Label { text: 'B (col penalty)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 50 * 1
                    onValueChanged: hopfieldTspBridge.B = value
                    Component.onCompleted: hopfieldTspBridge.B = value
                    Layout.fillWidth: true
                }
                Label { text: 'C (distance weight)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 0.1 * 100
                    onValueChanged: hopfieldTspBridge.C = value / 100
                    Component.onCompleted: hopfieldTspBridge.C = value / 100
                    Layout.fillWidth: true
                }
                Label { text: 'lambda'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 1.0 * 100
                    onValueChanged: hopfieldTspBridge.lam = value / 100
                    Component.onCompleted: hopfieldTspBridge.lam = value / 100
                    Layout.fillWidth: true
                }
                Label { text: 'dt'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 0.001 * 100000
                    onValueChanged: hopfieldTspBridge.dt = value / 100000
                    Component.onCompleted: hopfieldTspBridge.dt = value / 100000
                    Layout.fillWidth: true
                }
                Label { text: 'Max Iter'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 5000
                    from: 100; to: 50000
                    onValueChanged: hopfieldTspBridge.max_iter = value
                    Component.onCompleted: hopfieldTspBridge.max_iter = value
                    Layout.fillWidth: true
                }
                Label { text: 'Update Freq'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 50
                    from: 10; to: 1000
                    onValueChanged: hopfieldTspBridge.update_freq = value
                    Component.onCompleted: hopfieldTspBridge.update_freq = value
                    Layout.fillWidth: true
                }
                Label { text: 'UI Refresh (s)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTspBridge.has_finished
                    editable: true
                    value: 15
                    onValueChanged: hopfieldTspBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: hopfieldTspBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Controls'
            Layout.fillWidth: true
            ExecutionControls {
                startButton.enabled: hopfieldTspBridge.has_finished
                startButton.onClicked: () => {
                    energySeries.clear()
                    hopfieldTspBridge.start()
                }
                stopButton.enabled: !hopfieldTspBridge.has_finished
                stopButton.onClicked: hopfieldTspBridge.stop()
                progressBar.from: 0
                progressBar.to: hopfieldTspBridge.max_iter
                progressBar.value: hopfieldTspBridge.current_iter
                Layout.fillWidth: true
            }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        // Left: Path chart takes ~70% width
        GroupBox {
            title: 'Cities and Path'
            Layout.fillHeight: true
            Layout.preferredWidth: parent.width * 0.6
            Layout.preferredHeight: 400
            Layout.maximumHeight: 600
            ChartView {
                anchors.fill: parent
                antialiasing: true
                legend.visible: true
                legend.alignment: Qt.AlignTop
                ValueAxis { id: axisX; min: 0; max: 100; titleText: 'X' }
                ValueAxis { id: axisY; min: 0; max: 100; titleText: 'Y' }
                ScatterSeries {
                    id: citiesSeries
                    name: 'Cities'
                    axisX: axisX
                    axisY: axisY
                }
                LineSeries {
                    id: pathSeries
                    name: 'Path'
                    axisX: axisX
                    axisY: axisY
                    color: 'red'
                }
                Component.onCompleted: {
                    citiesSeries.clear()
                    if (hopfieldTspBridge.cities && hopfieldTspBridge.cities.length) {
                        for (let i = 0; i < hopfieldTspBridge.cities.length; i++) {
                            const pt = hopfieldTspBridge.cities[i]
                            citiesSeries.append(pt[0], pt[1])
                        }
                    }
                }
            }
        }
        // Right: Heatmap (capped height, scrollable) + Energy + Info
        ColumnLayout {
            Layout.fillHeight: true
            Layout.preferredWidth: parent.width * 0.3
            GroupBox {
                title: 'V Heatmap (n x n)'
                Layout.fillWidth: true
                Layout.preferredHeight: 240
                Flickable {
                    anchors.fill: parent
                    contentWidth: heatGrid.implicitWidth
                    contentHeight: heatGrid.implicitHeight
                    clip: true
                    Grid {
                        id: heatGrid
                        columns: hopfieldTspBridge.n
                        rows: hopfieldTspBridge.n
                        spacing: 0
                        Repeater {
                            model: hopfieldTspBridge.n * hopfieldTspBridge.n
                            delegate: Rectangle {
                                width: 24
                                height: 24
                                border.color: '#888'
                                border.width: 1
                                color: {
                                    if (!hopfieldTspBridge.V || hopfieldTspBridge.V.length === 0) return 'white'
                                    const r = Math.floor(index / hopfieldTspBridge.n)
                                    const c = index % hopfieldTspBridge.n
                                    const v = hopfieldTspBridge.V[r][c]
                                    const gray = Math.floor(255 * (1 - v))
                                    return Qt.rgba(gray/255, gray/255, gray/255, 1)
                                }
                            }
                        }
                    }
                }
            }
            GroupBox {
                title: 'Info'
                Layout.fillWidth: true
                GridLayout {
                    columns: 2
                    Label { text: '迭代次数' }
                    Label {
                        text: hopfieldTspBridge.current_iter
                        onTextChanged: {
                            energySeries.append(hopfieldTspBridge.current_iter, hopfieldTspBridge.current_energy)
                            eAxisX.max = Math.max(eAxisX.max, hopfieldTspBridge.current_iter + 10)
                            eAxisY.max = Math.max(eAxisY.max, hopfieldTspBridge.current_energy + 10)
                            citiesSeries.clear()
                            if (hopfieldTspBridge.cities && hopfieldTspBridge.cities.length) {
                                for (let i = 0; i < hopfieldTspBridge.cities.length; i++) {
                                    const pt = hopfieldTspBridge.cities[i]
                                    citiesSeries.append(pt[0], pt[1])
                                }
                            }
                            pathSeries.clear()
                            if (hopfieldTspBridge.x_path && hopfieldTspBridge.x_path.length) {
                                for (let i = 0; i < hopfieldTspBridge.x_path.length; i++) {
                                    pathSeries.append(hopfieldTspBridge.x_path[i], hopfieldTspBridge.y_path[i])
                                }
                            }
                        }
                    }
                    Label { text: '能量值' }
                    Label { text: hopfieldTspBridge.current_energy.toFixed(3) }
                    Label { text: '距离' }
                    Label { text: hopfieldTspBridge.total_distance.toFixed(2) }
                }
            }
            GroupBox {
                title: 'Energy'
                Layout.fillWidth: true
                Layout.preferredHeight: 260
                ChartView {
                    anchors.fill: parent
                    antialiasing: true
                    legend.visible: true
                    legend.alignment: Qt.AlignTop
                    ValueAxis { id: eAxisX; min: 0; max: 100; titleText: 'Iter' }
                    ValueAxis { id: eAxisY; min: 0; max: 1000; titleText: 'Energy' }
                    LineSeries {
                        id: energySeries
                        name: 'Energy'
                        axisX: eAxisX
                        axisY: eAxisY
                    }
                }
            }

        }
    }
}


