import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import warnings

warnings.filterwarnings('ignore')

# 设置matplotlib后端
import matplotlib

matplotlib.use('TkAgg')


class SimplifiedSOM:
    def __init__(self, input_dim, map_size, learning_rate=0.5, sigma=None):
        self.input_dim = input_dim
        self.map_size = map_size
        self.learning_rate = learning_rate
        self.sigma = sigma if sigma is not None else max(map_size) / 2

        # 初始化权重矩阵
        self.weights = np.random.rand(map_size[0], map_size[1], input_dim)

        # 创建神经元位置矩阵
        self.positions = np.array([[i, j] for i in range(map_size[0])
                                   for j in range(map_size[1])]).reshape(map_size[0], map_size[1], 2)

        # 记录训练历史
        self.history = []

        # 记录激活频率
        self.activation_count = np.zeros(map_size)

    def _gaussian_neighborhood(self, bmu_pos, current_sigma):
        """高斯邻域函数"""
        distances = np.linalg.norm(self.positions - bmu_pos, axis=2)
        return np.exp(-distances ** 2 / (2 * current_sigma ** 2))

    def _find_bmu(self, x):
        """找到最佳匹配单元(BMU)"""
        distances = np.linalg.norm(self.weights - x, axis=2)
        bmu_index = np.unravel_index(np.argmin(distances), distances.shape)
        return bmu_index

    def train(self, data, epochs, batch_size=1, save_history=True):
        """训练SOM网络"""
        n_samples = data.shape[0]

        for epoch in range(epochs):
            # 动态调整学习率和邻域半径
            current_lr = self.learning_rate * np.exp(-epoch / (epochs / 2))
            current_sigma = self.sigma * np.exp(-epoch / (epochs / 2))

            # 随机选择样本
            indices = np.random.choice(n_samples, batch_size, replace=False)
            batch_data = data[indices]

            bmu_pos = None
            for x in batch_data:
                # 找到BMU
                bmu_pos = self._find_bmu(x)

                # 更新激活计数
                self.activation_count[bmu_pos] += 1

                # 计算邻域函数
                neighborhood = self._gaussian_neighborhood(bmu_pos, current_sigma)

                # 更新权重
                influence = neighborhood[:, :, np.newaxis]
                delta = current_lr * influence * (x - self.weights)
                self.weights += delta

            # 保存当前状态用于可视化
            if save_history and epoch % max(1, epochs // 80) == 0:
                self.history.append({
                    'epoch': epoch,
                    'weights': self.weights.copy(),
                    'bmu_pos': bmu_pos if bmu_pos is not None else (0, 0),
                    'current_lr': current_lr,
                    'current_sigma': current_sigma,
                    'activation_count': self.activation_count.copy()
                })

            if epoch % max(1, epochs // 10) == 0:
                print(f"Epoch {epoch}/{epochs}, LR: {current_lr:.3f}, Sigma: {current_sigma:.3f}")

    def predict(self, x):
        """预测输入样本的BMU"""
        return self._find_bmu(x)

    def get_umatrix(self):
        """计算U-Matrix（统一距离矩阵）"""
        umatrix = np.zeros(self.map_size)
        for i in range(self.map_size[0]):
            for j in range(self.map_size[1]):
                neighbors = []
                if i > 0:
                    neighbors.append(self.weights[i - 1, j])
                if i < self.map_size[0] - 1:
                    neighbors.append(self.weights[i + 1, j])
                if j > 0:
                    neighbors.append(self.weights[i, j - 1])
                if j < self.map_size[1] - 1:
                    neighbors.append(self.weights[i, j + 1])

                if neighbors:
                    distances = [np.linalg.norm(self.weights[i, j] - neighbor)
                                 for neighbor in neighbors]
                    umatrix[i, j] = np.mean(distances)
        return umatrix


def create_optimized_visualization(som, data):
    """创建优化的可视化，减少子图数量以提高性能"""
    print("创建优化可视化...")

    # 创建2x2的子图布局，减少复杂度
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # 设置颜色
    colors = plt.cm.rainbow(np.linspace(0, 1, len(data)))

    # 初始化图形元素
    # 图1: 权重和数据分布
    ax1 = axes[0, 0]
    data_scatter = ax1.scatter(data[:, 0], data[:, 1], c=colors, alpha=0.6, s=30, label='Input Data')
    weights_scatter = ax1.scatter([], [], c='red', s=80, marker='s', edgecolors='black', label='Neurons')
    bmu_scatter = ax1.scatter([], [], c='yellow', s=150, marker='*', edgecolors='red', linewidth=2, label='BMU')

    ax1.set_xlabel('Feature 1')
    ax1.set_ylabel('Feature 2')
    ax1.grid(True, alpha=0.3)
    ax1.legend()

    # 图2: U-Matrix
    ax2 = axes[0, 1]
    umatrix_img = ax2.imshow(np.zeros(som.map_size), cmap='hot', interpolation='nearest')
    bmu_point_ax2 = ax2.scatter([], [], c='cyan', s=100, marker='*', edgecolors='white', linewidth=2)
    ax2.set_title('U-Matrix')
    ax2.set_xlabel('X Coordinate')
    ax2.set_ylabel('Y Coordinate')
    plt.colorbar(umatrix_img, ax=ax2, label='Average Distance')

    # 图3: 激活频率
    ax3 = axes[1, 0]
    activation_img = ax3.imshow(np.zeros(som.map_size), cmap='Blues', interpolation='nearest')
    bmu_point_ax3 = ax3.scatter([], [], c='red', s=100, marker='*', edgecolors='white', linewidth=2)
    ax3.set_title('Activation Frequency')
    ax3.set_xlabel('X Coordinate')
    ax3.set_ylabel('Y Coordinate')
    plt.colorbar(activation_img, ax=ax3, label='Activation Count')

    # 图4: 学习参数和权重变化
    ax4 = axes[1, 1]
    lr_line, = ax4.plot([], [], 'b-', label='Learning Rate', linewidth=2)
    sigma_line, = ax4.plot([], [], 'r-', label='Neighborhood Radius', linewidth=2)
    ax4.set_xlabel('Epoch')
    ax4.set_ylabel('Value')
    ax4.set_title('Learning Parameters')
    ax4.legend()
    ax4.grid(True, alpha=0.3)

    # 进度文本
    progress_text = fig.text(0.5, 0.01, '', ha='center',
                             bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    # 存储网格线以便更新时清除
    grid_lines = []

    def update(frame):
        """更新所有子图"""
        if frame >= len(som.history):
            return

        # 清除之前的网格线
        for line in grid_lines:
            line.remove()
        grid_lines.clear()

        state = som.history[frame]
        weights = state['weights']
        epoch = state['epoch']
        bmu_pos = state['bmu_pos']
        activation_count = state['activation_count']

        # 图1: 权重和数据分布
        # 更新权重点
        weights_flat = weights.reshape(-1, 2)
        weights_scatter.set_offsets(weights_flat)

        # 更新BMU点
        bmu_scatter.set_offsets([weights[bmu_pos[0], bmu_pos[1]]])

        # 绘制新的网格线
        for i in range(som.map_size[0]):
            for j in range(som.map_size[1]):
                if i < som.map_size[0] - 1:
                    line, = ax1.plot([weights[i, j, 0], weights[i + 1, j, 0]],
                                     [weights[i, j, 1], weights[i + 1, j, 1]], 'k-', alpha=0.5)
                    grid_lines.append(line)
                if j < som.map_size[1] - 1:
                    line, = ax1.plot([weights[i, j, 0], weights[i, j + 1, 0]],
                                     [weights[i, j, 1], weights[i, j + 1, 1]], 'k-', alpha=0.5)
                    grid_lines.append(line)

        ax1.set_title(f'Weight Distribution (Epoch: {epoch})')

        # 图2: U-Matrix
        umatrix = som.get_umatrix()
        umatrix_img.set_array(umatrix)
        umatrix_img.set_clim(vmin=umatrix.min(), vmax=umatrix.max())
        bmu_point_ax2.set_offsets([[bmu_pos[1], bmu_pos[0]]])
        ax2.set_title(f'U-Matrix (Epoch: {epoch})')

        # 图3: 激活频率
        activation_img.set_array(activation_count)
        activation_img.set_clim(vmin=0, vmax=activation_count.max())
        bmu_point_ax3.set_offsets([[bmu_pos[1], bmu_pos[0]]])
        ax3.set_title(f'Activation Frequency (Epoch: {epoch})')

        # 图4: 学习参数
        epochs_so_far = [s['epoch'] for s in som.history[:frame + 1]]
        lrs = [s['current_lr'] for s in som.history[:frame + 1]]
        sigmas = [s['current_sigma'] for s in som.history[:frame + 1]]

        lr_line.set_data(epochs_so_far, lrs)
        sigma_line.set_data(epochs_so_far, sigmas)
        ax4.set_xlim(0, max(epochs_so_far) if epochs_so_far else 1)
        ax4.set_ylim(0, max(max(lrs) if lrs else 1, max(sigmas) if sigmas else 1) * 1.1)
        ax4.set_title(f'Learning Parameters (Epoch: {epoch})')

        # 更新进度文本
        progress_text.set_text(
            f'Epoch: {epoch} | Learning Rate: {state["current_lr"]:.3f} | Neighborhood Radius: {state["current_sigma"]:.3f}')

        # 更新总标题
        fig.suptitle(f'SOM Training Process - Epoch: {epoch}', fontsize=14)

        return weights_scatter, bmu_scatter, umatrix_img, bmu_point_ax2, activation_img, bmu_point_ax3, lr_line, sigma_line, progress_text

    # 创建动画，增加间隔时间减少卡顿
    anim = FuncAnimation(fig, update, frames=len(som.history),
                         interval=400, repeat=True, blit=False)

    plt.tight_layout()
    plt.subplots_adjust(bottom=0.08)  # 为底部文本留出空间
    plt.show()

    return anim


def create_final_summary(som, data):
    """创建最终训练结果总结"""
    print("创建最终总结...")

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))

    # 获取最终状态
    final_state = som.history[-1]
    weights = final_state['weights']
    activation_count = final_state['activation_count']

    # 图1: 最终权重分布
    ax1 = axes[0, 0]
    ax1.scatter(data[:, 0], data[:, 1], c='blue', alpha=0.3, s=30, label='Input Data')

    for i in range(som.map_size[0]):
        for j in range(som.map_size[1]):
            # 根据激活频率设置颜色深浅
            activation_norm = activation_count[i, j] / (activation_count.max() + 1e-8)
            color = plt.cm.Reds(activation_norm)

            ax1.scatter(weights[i, j, 0], weights[i, j, 1],
                        c=[color], s=100, marker='s', edgecolors='black')

            if i < som.map_size[0] - 1:
                ax1.plot([weights[i, j, 0], weights[i + 1, j, 0]],
                         [weights[i, j, 1], weights[i + 1, j, 1]], 'k-', alpha=0.5)
            if j < som.map_size[1] - 1:
                ax1.plot([weights[i, j, 0], weights[i, j + 1, 0]],
                         [weights[i, j, 1], weights[i, j + 1, 1]], 'k-', alpha=0.5)

    ax1.set_title('Final Weight Distribution')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_xlabel('Feature 1')
    ax1.set_ylabel('Feature 2')

    # 图2: U-Matrix
    ax2 = axes[0, 1]
    umatrix = som.get_umatrix()
    im2 = ax2.imshow(umatrix, cmap='hot', interpolation='nearest')
    ax2.set_title('Final U-Matrix')
    ax2.set_xlabel('X Coordinate')
    ax2.set_ylabel('Y Coordinate')
    plt.colorbar(im2, ax=ax2, label='Average Distance')

    # 图3: 激活频率
    ax3 = axes[1, 0]
    im3 = ax3.imshow(activation_count, cmap='Blues', interpolation='nearest')
    ax3.set_title('Final Activation Frequency')
    ax3.set_xlabel('X Coordinate')
    ax3.set_ylabel('Y Coordinate')
    plt.colorbar(im3, ax=ax3, label='Activation Count')

    # 图4: 学习参数历史
    ax4 = axes[1, 1]
    epochs = [s['epoch'] for s in som.history]
    lrs = [s['current_lr'] for s in som.history]
    sigmas = [s['current_sigma'] for s in som.history]

    ax4.plot(epochs, lrs, 'b-', label='Learning Rate', linewidth=2)
    ax4.plot(epochs, sigmas, 'r-', label='Neighborhood Radius', linewidth=2)
    ax4.set_xlabel('Epoch')
    ax4.set_ylabel('Value')
    ax4.set_title('Learning Parameters History')
    ax4.legend()
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('som_final_summary.png', dpi=150, bbox_inches='tight')
    print("最终总结已保存为 'som_final_summary.png'")
    plt.show()


def create_simple_animation(som, data, filename='som_simple_training.gif'):
    """创建简单的训练动画并保存为GIF"""
    print("创建简单动画...")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    # 设置颜色
    colors = plt.cm.rainbow(np.linspace(0, 1, len(data)))

    def update(frame):
        for ax in [ax1, ax2]:
            ax.clear()

        if frame >= len(som.history):
            return

        state = som.history[frame]
        weights = state['weights']
        epoch = state['epoch']
        bmu_pos = state['bmu_pos']

        # 图1: 权重和数据分布
        ax1.scatter(data[:, 0], data[:, 1], c=colors, alpha=0.6, s=30, label='Input Data')

        # 绘制权重网格
        for i in range(som.map_size[0]):
            for j in range(som.map_size[1]):
                ax1.scatter(weights[i, j, 0], weights[i, j, 1],
                            c='red', s=80, marker='s', edgecolors='black')

                # 连接相邻神经元
                if i < som.map_size[0] - 1:
                    ax1.plot([weights[i, j, 0], weights[i + 1, j, 0]],
                             [weights[i, j, 1], weights[i + 1, j, 1]], 'k-', alpha=0.5)
                if j < som.map_size[1] - 1:
                    ax1.plot([weights[i, j, 0], weights[i, j + 1, 0]],
                             [weights[i, j, 1], weights[i, j + 1, 1]], 'k-', alpha=0.5)

        # 高亮显示BMU
        ax1.scatter(weights[bmu_pos[0], bmu_pos[1], 0],
                    weights[bmu_pos[0], bmu_pos[1], 1],
                    c='yellow', s=150, marker='*', edgecolors='red', linewidth=2,
                    label='BMU')

        ax1.legend()
        ax1.grid(True, alpha=0.3)
        ax1.set_xlabel('Feature 1')
        ax1.set_ylabel('Feature 2')
        ax1.set_title(f'Weight Distribution (Epoch: {epoch})')

        # 图2: U-Matrix
        umatrix = som.get_umatrix()
        im = ax2.imshow(umatrix, cmap='hot', interpolation='nearest')
        ax2.scatter(bmu_pos[1], bmu_pos[0], c='cyan', s=100, marker='*',
                    edgecolors='white', linewidth=2)
        ax2.set_title(f'U-Matrix (Epoch: {epoch})')
        ax2.set_xlabel('X Coordinate')
        ax2.set_ylabel('Y Coordinate')

        plt.suptitle(
            f'SOM Training - Epoch: {epoch}, LR: {state["current_lr"]:.3f}, Sigma: {state["current_sigma"]:.3f}')
        plt.tight_layout()

    # 创建动画
    anim = FuncAnimation(fig, update, frames=len(som.history),
                         interval=300, repeat=True, blit=False)

    # 保存动画
    try:
        anim.save(filename, writer='pillow', fps=3, dpi=100)
        print(f"简单动画已保存为: {filename}")
    except Exception as e:
        print(f"保存动画时出错: {e}")

    plt.close()


# 主程序
if __name__ == "__main__":
    # 设置随机种子以便复现结果
    np.random.seed(42)

    print("生成示例数据...")
    # 生成简单的示例数据
    n_samples = 300

    # 创建2个聚类
    cluster1 = np.random.randn(n_samples // 2, 2) * 0.5 + [1, 1]
    cluster2 = np.random.randn(n_samples // 2, 2) * 0.5 + [-1, -1]
    data = np.vstack([cluster1, cluster2])

    print(f"数据形状: {data.shape}")

    # 创建SOM网络（使用较小的网络以便快速训练和显示）
    print("创建SOM网络...")
    som = SimplifiedSOM(input_dim=2, map_size=(8, 8), learning_rate=0.3, sigma=3)

    # 训练SOM网络（使用较少的轮次以便快速测试）
    print("开始训练SOM...")
    som.train(data, epochs=300, batch_size=5)

    print("训练完成!")
    print(f"训练历史记录数: {len(som.history)}")

    # 创建优化后的可视化
    print("\n创建优化可视化...")
    anim = create_optimized_visualization(som, data)

    # 创建最终总结
    create_final_summary(som, data)

    # 创建简单动画并保存为GIF
    create_simple_animation(som, data)

    # 测试预测
    test_samples = np.array([[1.0, 1.0], [-1.0, -1.0], [0, 0]])
    print("\n测试预测:")
    for i, sample in enumerate(test_samples):
        bmu = som.predict(sample)
        activation_count = som.activation_count[bmu]
        print(f"样本 {i + 1}: {sample} -> BMU位置: {bmu}, 激活次数: {activation_count}")