import numpy as np
from enum import Enum


class OptimizationAlgorithm(Enum):
    STEEPEST_DESCENT = "steepest_descent"
    NEWTON_METHOD = "newton_method"
    CONJUGATE_GRADIENT = "conjugate_gradient"


class OptimizationVisualizer:
    def __init__(self, algorithm_type=OptimizationAlgorithm.STEEPEST_DESCENT):
        self.algorithm_type = algorithm_type
        self.loss_history = []
        self.gradient_norms = []
        self.parameter_history = []
        self.convergence_info = []

    def simulate_optimization(self, iterations=100):
        """模拟优化过程"""
        # 重置历史数据
        self.loss_history = []
        self.gradient_norms = []
        self.parameter_history = []
        self.convergence_info = []

        # 定义测试函数: f(x) = x1^2 + x2^2 + 2*x1*x2
        # 最优解在 (0, 0)
        A = np.array([[2, 1], [1, 2]])
        b = np.array([0, 0])
        x = np.array([3.0, 4.0])  # 初始点

        if self.algorithm_type == OptimizationAlgorithm.STEEPEST_DESCENT:
            self._steepest_descent(A, b, x, iterations)
        elif self.algorithm_type == OptimizationAlgorithm.NEWTON_METHOD:
            self._newton_method(A, b, x, iterations)
        elif self.algorithm_type == OptimizationAlgorithm.CONJUGATE_GRADIENT:
            self._conjugate_gradient(A, b, x, iterations)

    def _steepest_descent(self, A, b, x, iterations):
        """最速下降法"""
        learning_rate = 0.1

        for i in range(iterations):
            # 计算梯度: ∇f(x) = A @ x
            gradient = A @ x
            loss = 0.5 * x.T @ A @ x

            self.loss_history.append(loss)
            self.gradient_norms.append(np.linalg.norm(gradient))
            self.parameter_history.append(x.copy())

            # 更新参数
            x = x - learning_rate * gradient

            # 自适应学习率
            if i % 20 == 0:
                learning_rate *= 0.9

    def _newton_method(self, A, b, x, iterations):
        """牛顿法"""
        hessian = A  # 对于二次函数，Hessian矩阵就是A
        hessian_inv = np.linalg.inv(hessian)

        for i in range(iterations):
            gradient = A @ x
            loss = 0.5 * x.T @ A @ x

            self.loss_history.append(loss)
            self.gradient_norms.append(np.linalg.norm(gradient))
            self.parameter_history.append(x.copy())

            # 牛顿更新: x = x - H⁻¹ ∇f(x)
            x = x - hessian_inv @ gradient

    def _conjugate_gradient(self, A, b, x, iterations):
        """共轭梯度法"""
        r = -A @ x  # 初始残差
        p = r.copy()  # 初始搜索方向

        for i in range(min(iterations, len(x))):
            gradient = A @ x
            loss = 0.5 * x.T @ A @ x

            self.loss_history.append(loss)
            self.gradient_norms.append(np.linalg.norm(gradient))
            self.parameter_history.append(x.copy())

            # 计算步长
            Ap = A @ p
            alpha = (r.T @ r) / (p.T @ Ap)

            # 更新参数和残差
            x = x + alpha * p
            r_new = r - alpha * Ap

            # 计算共轭系数
            beta = (r_new.T @ r_new) / (r.T @ r)

            # 更新搜索方向
            p = r_new + beta * p
            r = r_new

    def get_visualization_data(self):
        return {
            'loss_history': self.loss_history,
            'gradient_norms': self.gradient_norms,
            'convergence_info': self.convergence_info
        }

    def get_contour_data(self):
        """生成等高线数据"""
        x = np.linspace(-5, 5, 100)
        y = np.linspace(-5, 5, 100)
        X, Y = np.meshgrid(x, y)

        # 定义函数: f(x,y) = x² + y² + 2xy
        Z = X ** 2 + Y ** 2 + 2 * X * Y

        return {
            'X': X.tolist(),
            'Y': Y.tolist(),
            'Z': Z.tolist(),
            'optimum': [0, 0]
        }