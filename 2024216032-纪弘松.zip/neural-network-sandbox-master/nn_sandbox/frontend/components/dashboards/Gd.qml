import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import '..'
Page {
    name: '3DGradientDescent'

    // 绑定到 Python 后端中的属性
    property int iteration: GD.iteration


    ColumnLayout {
        spacing: 10

        // 控制面板
        GroupBox {
            title: "Control Panel"
            Layout.fillWidth: true
            RowLayout {
                Button {
    text: "Start"
    onClicked: {
        GD.startTraining();  // 调用后端 startTraining() 方法
    }
}
Button {
    text: "Stop"
    onClicked: {
        GD.stopTraining();  // 调用后端 stopTraining() 方法
    }
}

            }
        }

        // 学习率与批大小
        GroupBox {
            title: "Settings"
            Layout.fillWidth: true
            GridLayout {
                columns: 2

                Label { text: "Learning Rate:" }
                TextField {
                    id: learningRateField
                    width: 100
                    placeholderText: visualizer.learningRate.toString()
                    onEditingFinished: {
                        var rate = parseFloat(learningRateField.text);
                        if (!isNaN(rate)) {
                            visualizer.learningRate = rate;
                        }
                    }
                }

                Label { text: "Batch Size:" }
                TextField {
                    id: batchSizeField
                    width: 100
                    placeholderText: visualizer.batchSize.toString()
                    onEditingFinished: {
                        var size = parseInt(batchSizeField.text);
                        if (!isNaN(size)) {
                            visualizer.batchSize = size;
                        }
                    }
                }
            }
        }

        // 显示迭代次数
        GroupBox {
            title: "Iteration"
            Layout.fillWidth: true
            Label {
                id: iterationLabel
                text: "Iteration: " + iteration
                Layout.alignment: Qt.AlignHCenter
            }
        }

        // 3D 可视化
        GroupBox {
            title: "3D Visualization"
            Layout.fillWidth: true
            RowLayout {
                Item {
                    id: visualizerCanvas
                    width: parent.width
                    height: 400

                    // 使用 PyQt 中的 FigureCanvas 进行 3D 绘图
                    MouseArea {
                        anchors.fill: parent
                        onClicked: {
                            console.log("3D Canvas Clicked");
                        }
                    }
                }
            }
        }
    }
}
