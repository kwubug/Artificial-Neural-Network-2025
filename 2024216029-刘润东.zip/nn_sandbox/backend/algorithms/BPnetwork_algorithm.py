import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, tanh


class BPnetworkAlgorithm(PredictiveAlgorithm):
    """ Backpropagation prototype. """

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, input_size=None, hidden_size=None,
                 output_size=1, function=0, activation_function=None):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.activation_function = sigmoid if function == 0 else tanh
        self._momentum_weight = momentum_weight
        network_shape = (hidden_size, output_size)
        # Define two layers: one hidden layer and one output layer
        self.network_shape = network_shape if network_shape else (5, 1)  # Hidden layer size = 5, Output layer size = 1

        # Momentum term for weight adjustments
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
        self._adjust_synaptic_weights(deltas)

    def _initialize_neurons(self):
        """ Build a two-layer neuron network with a single neuron as the output layer. """
        self._neurons = tuple((Perceptron(sigmoid),) * size
                              for size in list(self.network_shape))

    def _feed_forward(self, data):
        """ Perform a forward pass through the two layers. """
        # Pass input data through the hidden layer
        hidden_layer_result = get_layer_results(self._neurons[0], data)

        # Pass hidden layer output through the output layer
        output_layer_result = get_layer_results(self._neurons[1], hidden_layer_result)
        
        return output_layer_result[0]

    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron during backpropagation. """
        deltas = {}

        # Delta for the output layer neuron
        deltas[self._neurons[-1][0]] = ((expect - result) * result * (1 - result))

        # Delta for the hidden layer neurons
        for neuron_idx, neuron in enumerate(self._neurons[0]):
            deltas[neuron] = (sum(deltas[n] * n.synaptic_weight[neuron_idx]
                                  for n in self._neurons[1]) * neuron.result * (1 - neuron.result))
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        """ Adjust the synaptic weights for both layers based on the deltas. """
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    def _correct_rate(self, dataset):
        """ Calculate the correct rate for the dataset. """
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """ Normalize the expected output. """
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))


def get_layer_results(layer, data):
    """ Helper function to get the result of each layer during feed-forward. """
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)

