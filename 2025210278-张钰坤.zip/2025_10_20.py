import numpy as np
import matplotlib.pyplot as plt

A = np.array([[2.0, 1.0],
              [1.0, 3.0]])  
b = np.array([0.0, 0.0])
c = 0.0

x0 = np.array([0.8, -0.25])  
max_iters_sd = 30
max_iters_cg = 10
max_iters_newton = 10

use_exact_line_search_sd = True   
newton_use_backtracking = True    

tol = 1e-8



def f(x):
    return 0.5 * x.T @ A @ x + b.T @ x + c

def grad(x):
    return A @ x + b

def hess(x):
    return A  



def backtracking_line_search(x, p, grad_x, alpha0=1.0, rho=0.5, c1=1e-4):
    alpha = alpha0
    fx = f(x)
    while f(x + alpha * p) > fx + c1 * alpha * grad_x.T @ p:
        alpha *= rho
        if alpha < 1e-12:
            break
    return alpha

def exact_line_search_quadratic(x, p):
    # alpha = -(g^T p) / (p^T A p) for quadratic
    g = grad(x)
    denom = p.T @ A @ p
    if denom <= 1e-20:
        return 0.0
    return - (g.T @ p) / denom



def steepest_descent(x0, max_iters=20, tol=1e-8, use_exact=True):
    x = x0.copy()
    path = [x.copy()]
    for _ in range(max_iters):
        g = grad(x)
        if np.linalg.norm(g) < tol:
            break
        p = -g
        if use_exact:
            alpha = exact_line_search_quadratic(x, p)
        else:
            alpha = backtracking_line_search(x, p, g)
        x = x + alpha * p
        path.append(x.copy())
    return np.array(path)

def conjugate_gradient_fr(x0, max_iters=20, tol=1e-8):
    x = x0.copy()
    g = grad(x)
    p = -g
    path = [x.copy()]
    for _ in range(max_iters):
        if np.linalg.norm(g) < tol:
            break
        alpha = exact_line_search_quadratic(x, p)
        x = x + alpha * p
        path.append(x.copy())
        g_new = grad(x)
        if np.linalg.norm(g_new) < tol:
            break
        beta = (g_new.T @ g_new) / (g.T @ g)
        p = -g_new + beta * p
        g = g_new
    return np.array(path)

def newton_method(x0, max_iters=20, tol=1e-8, use_backtracking=True):
    x = x0.copy()
    path = [x.copy()]
    for _ in range(max_iters):
        g = grad(x)
        H = hess(x)
        if np.linalg.norm(g) < tol:
            break
        p = -np.linalg.solve(H, g)  # Newton direction
        if use_backtracking:
            alpha = backtracking_line_search(x, p, g, alpha0=1.0)
        else:
            alpha = 1.0
        x = x + alpha * p
        path.append(x.copy())
    return np.array(path)



def plot_contours(xlim=(-1.5, 1.5), ylim=(-1.5, 1.5), levels=25):
    xs = np.linspace(*xlim, 300)
    ys = np.linspace(*ylim, 300)
    X, Y = np.meshgrid(xs, ys)
    Z = 0.5*(A[0,0]*X**2 + 2*A[0,1]*X*Y + A[1,1]*Y**2) + b[0]*X + b[1]*Y + c
    plt.contour(X, Y, Z, levels=levels)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.title("Optimization Trajectory")

def plot_path(path, label):
    plt.plot(path[:,0], path[:,1], marker='o', label=label)
    plt.scatter(path[0,0], path[0,1], marker='x')  # start
    plt.scatter(path[-1,0], path[-1,1], marker='*')  # end
    plt.legend()

def print_summary(name, path):
    print(f"\n{name}")
    print("iter\t x1\t\t x2\t\t f(x)\t\t ||grad||")
    for i, x in enumerate(path):
        fx = f(x)
        gn = np.linalg.norm(grad(x))
        print(f"{i}\t {x[0]:+.6f}\t {x[1]:+.6f}\t {fx:+.6e}\t {gn:.3e}")



if __name__ == "__main__":
    # Run
    path_sd = steepest_descent(x0, max_iters=max_iters_sd, tol=tol,
                               use_exact=use_exact_line_search_sd)
    path_cg = conjugate_gradient_fr(x0, max_iters=max_iters_cg, tol=tol)
    path_newton = newton_method(x0, max_iters=max_iters_newton, tol=tol,
                                use_backtracking=newton_use_backtracking)

    # Figures 
    for label, path in [("Steepest Descent", path_sd),
                        ("Conjugate Gradient (FR)", path_cg),
                        ("Newton's Method", path_newton)]:
        plt.figure(figsize=(5,5))
        plot_contours(xlim=(-1.5, 1.5), ylim=(-1.5, 1.5), levels=25)
        plot_path(path, label)
        plt.show()

    # Summaries
    print_summary("Steepest Descent", path_sd)
    print_summary("Conjugate Gradient (FR)", path_cg)
    print_summary("Newton's Method", path_newton)
