import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# ========== 参数设置 ==========
np.random.seed(42)
num_neurons = 3
temperature = 1.0
steps = 100

# ========== 初始化 ==========
# 对称权重矩阵，去掉自连接
W = np.random.uniform(-1, 1, (num_neurons, num_neurons))
W = (W + W.T) / 2
np.fill_diagonal(W, 0)

# 神经元状态初始化 {-1, 1}
states = np.random.choice([-1, 1], size=num_neurons)

# 保存状态演化
state_history = [states.copy()]

# ========== BM 更新函数 ==========
def update(states, W, T):
    for i in range(num_neurons):
        # 计算神经元 i 的总输入
        h = np.dot(W[i], states)
        # 通过概率决定是否翻转
        p = 1 / (1 + np.exp(-2 * h / T))
        states[i] = 1 if np.random.rand() < p else -1
    return states

# ========== 运行 BM ==========
for _ in range(steps):
    states = update(states, W, temperature)
    state_history.append(states.copy())

state_history = np.array(state_history)

# ========== 动态可视化 ==========
fig, ax = plt.subplots()
ax.set_xlim(0, steps)
ax.set_ylim(-1.5, 1.5)
ax.set_xlabel("Step")
ax.set_ylabel("Neuron State")
ax.set_title("Boltzmann Machine Dynamics (3 Neurons)")

lines = [ax.plot([], [], label=f'Neuron {i+1}')[0] for i in range(num_neurons)]
ax.legend()

def init():
    for line in lines:
        line.set_data([], [])
    return lines

def update_plot(frame):
    x = np.arange(frame)
    for i, line in enumerate(lines):
        line.set_data(x, state_history[:frame, i])
    return lines

ani = FuncAnimation(fig, update_plot, frames=steps, init_func=init,
                    blit=True, interval=100, repeat=False)

plt.show()

# 输出最后的热平衡状态
print("最终热平衡状态：", state_history[-1])
