import sys
import numpy as np
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox, QGridLayout,
                             QTextEdit, QProgressBar)
from PyQt5.QtCore import QTimer, Qt, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QColor, QPainter, QPen, QPalette
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis


class NeuronWidget(QWidget):
    def __init__(self, index, state=1):
        super().__init__()
        self.index = index
        self.state = state
        self.setFixedSize(150, 150)
        self.animation = QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(300)
        self.animation.setEasingCurve(QEasingCurve.OutBack)

    def setState(self, state):
        old_state = self.state
        self.state = state

        # 添加动画效果
        if old_state != state:
            self.animation.setStartValue(self.geometry())
            self.animation.setEndValue(self.geometry().adjusted(-5, -5, 5, 5))
            self.animation.start()

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制神经元圆圈
        if self.state == 1:
            color = QColor(76, 175, 80)  # 绿色 - 激活
            border_color = QColor(129, 199, 132)
        else:
            color = QColor(244, 67, 54)  # 红色 - 抑制
            border_color = QColor(239, 154, 154)

        painter.setBrush(color)
        painter.setPen(QPen(border_color, 4))
        painter.drawEllipse(15, 15, 120, 120)

        # 绘制文字
        painter.setPen(QPen(Qt.white))
        font = QFont("Arial", 14, QFont.Bold)
        painter.setFont(font)
        painter.drawText(self.rect(), Qt.AlignCenter,
                         f"神经元 {self.index + 1}\n{'+1' if self.state == 1 else '-1'}\n{'激活' if self.state == 1 else '抑制'}")

        # 绘制脉冲效果
        if hasattr(self.parent(), 'is_running') and self.parent().is_running:
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(border_color, 2))
            for i in range(3):
                radius = 130 + i * 10
                alpha = 100 - i * 30
                painter.setPen(QPen(QColor(border_color.red(), border_color.green(), border_color.blue(), alpha), 2))
                painter.drawEllipse(25 - i * 5, 25 - i * 5, 100 + i * 10, 100 + i * 10)


class BoltzmannMachinePure(QMainWindow):
    def __init__(self):
        super().__init__()
        # 初始化神经元状态
        self.neurons = [random.choice([1, -1]) for _ in range(3)]
        # 权重矩阵
        self.weights = np.array([
            [0, 0.5, -0.3],
            [0.5, 0, 0.2],
            [-0.3, 0.2, 0]
        ])
        self.temperature = 5.0
        self.min_temperature = 0.01
        self.cooling_rate = 0.95
        self.iteration = 0
        self.is_running = False
        self.energy_history = []
        self.equilibrium_reached = False

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_state)
        self.timer.setInterval(500)

        self.init_ui()
        self.update_display()

    def init_ui(self):
        self.setWindowTitle("玻尔兹曼机可视化 - 三个神经元 (热平衡状态检测)")
        self.setGeometry(100, 100, 1200, 900)

        # 设置深色主题
        self.setStyleSheet("""
            QMainWindow { background-color: #2b2b2b; }
            QLabel { color: white; }
            QGroupBox { 
                color: white; 
                font-weight: bold; 
                border: 2px solid #555; 
                border-radius: 8px; 
                margin-top: 1ex;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                color: #4CAF50;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 5px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #45a049; }
            QPushButton:disabled { background-color: #666; }
            QPushButton#stop { background-color: #f44336; }
            QPushButton#stop:hover { background-color: #da190b; }
            QPushButton#reset { background-color: #2196F3; }
            QPushButton#reset:hover { background-color: #0b7dda; }
            QTextEdit {
                background-color: #1e1e1e;
                color: #00ff00;
                border: 1px solid #555;
                border-radius: 5px;
                font-family: 'Courier New';
            }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)

        # 标题
        title = QLabel("🧠 玻尔兹曼机 (Boltzmann Machine) - 三个神经元可视化")
        title.setFont(QFont("Arial", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #4CAF50; padding: 10px;")
        layout.addWidget(title)

        # 神经元显示区域
        neuron_group = QGroupBox("神经元状态可视化")
        neuron_layout = QHBoxLayout(neuron_group)
        neuron_layout.setSpacing(40)
        neuron_layout.setAlignment(Qt.AlignCenter)

        self.neuron_widgets = []
        for i in range(3):
            neuron_widget = NeuronWidget(i, self.neurons[i])
            self.neuron_widgets.append(neuron_widget)
            neuron_layout.addWidget(neuron_widget)

        layout.addWidget(neuron_group)

        # 系统状态区域
        status_layout = QHBoxLayout()

        # 左侧：权重矩阵和基本信息
        left_group = QGroupBox("网络配置和状态")
        left_layout = QVBoxLayout(left_group)

        # 权重矩阵显示
        weights_text = QLabel("权重矩阵:")
        weights_text.setFont(QFont("Arial", 12, QFont.Bold))
        left_layout.addWidget(weights_text)

        weights_grid = QGridLayout()
        weights_grid.addWidget(QLabel(""), 0, 0)
        weights_grid.addWidget(QLabel("神经元1"), 0, 1)
        weights_grid.addWidget(QLabel("神经元2"), 0, 2)
        weights_grid.addWidget(QLabel("神经元3"), 0, 3)

        for i in range(3):
            weights_grid.addWidget(QLabel(f"神经元{i + 1}"), i + 1, 0)
            for j in range(3):
                weight = self.weights[i, j]
                color = "#81C784" if weight > 0 else "#ef5350" if weight < 0 else "white"
                weight_label = QLabel(f"{weight:.2f}")
                weight_label.setStyleSheet(f"color: {color}; font-weight: bold;")
                weights_grid.addWidget(weight_label, i + 1, j + 1)

        left_layout.addLayout(weights_grid)

        # 状态信息
        info_grid = QGridLayout()
        self.temp_label = QLabel("温度: 5.0000")
        self.energy_label = QLabel("能量: 0.0000")
        self.iter_label = QLabel("迭代: 0")
        self.status_label = QLabel("状态: 已停止")
        self.equilibrium_label = QLabel("热平衡: 未达到")

        info_grid.addWidget(self.temp_label, 0, 0)
        info_grid.addWidget(self.energy_label, 0, 1)
        info_grid.addWidget(self.iter_label, 1, 0)
        info_grid.addWidget(self.status_label, 1, 1)
        info_grid.addWidget(self.equilibrium_label, 2, 0, 1, 2)

        left_layout.addLayout(info_grid)
        status_layout.addWidget(left_group)

        # 右侧：能量历史和控制面板
        right_group = QGroupBox("训练过程")
        right_layout = QVBoxLayout(right_group)

        # 控制按钮
        button_layout = QHBoxLayout()

        self.start_btn = QPushButton("🚀 开始模拟")
        self.stop_btn = QPushButton("⏹️ 停止模拟")
        self.reset_btn = QPushButton("🔄 重置系统")

        self.start_btn.clicked.connect(self.start_simulation)
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.reset_btn.clicked.connect(self.reset_simulation)

        self.stop_btn.setObjectName("stop")
        self.reset_btn.setObjectName("reset")
        self.stop_btn.setEnabled(False)

        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.stop_btn)
        button_layout.addWidget(self.reset_btn)

        right_layout.addLayout(button_layout)

        # 能量历史显示
        energy_label = QLabel("能量变化历史:")
        energy_label.setFont(QFont("Arial", 12, QFont.Bold))
        right_layout.addWidget(energy_label)

        self.energy_text = QTextEdit()
        self.energy_text.setMaximumHeight(120)
        self.energy_text.setReadOnly(True)
        right_layout.addWidget(self.energy_text)

        # 控制台输出
        console_label = QLabel("运行日志:")
        console_label.setFont(QFont("Arial", 12, QFont.Bold))
        right_layout.addWidget(console_label)

        self.console = QTextEdit()
        self.console.setMaximumHeight(100)
        self.console.setReadOnly(True)
        right_layout.addWidget(self.console)

        status_layout.addWidget(right_group)
        layout.addLayout(status_layout)

        # 热平衡进度指示
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        self.log("玻尔兹曼机初始化完成")
        self.log(f"初始神经元状态: {self.neurons}")
        self.log("权重矩阵设置完成")

    def calculate_energy(self):
        energy = 0
        for i in range(3):
            for j in range(i + 1, 3):
                energy -= self.weights[i, j] * self.neurons[i] * self.neurons[j]
        return energy

    def update_state(self):
        if not self.is_running or self.equilibrium_reached:
            return

        # 随机选择一个神经元
        idx = random.randint(0, 2)

        # 计算输入总和
        input_sum = sum(self.weights[idx, j] * self.neurons[j] for j in range(3) if j != idx)

        # 计算翻转概率（玻尔兹曼分布）
        delta_energy = 2 * input_sum * self.neurons[idx]
        prob = 1 / (1 + np.exp(-delta_energy / max(self.temperature, 0.001)))

        # 根据概率决定是否翻转
        if random.random() < prob:
            self.neurons[idx] *= -1  # 翻转状态
            self.neuron_widgets[idx].setState(self.neurons[idx])
            self.log(f"迭代 {self.iteration}: 神经元{idx + 1} 状态翻转")

        # 更新系统状态
        energy = self.calculate_energy()
        self.energy_history.append(energy)

        # 降温（模拟退火）
        if self.temperature > self.min_temperature:
            self.temperature *= self.cooling_rate

        self.iteration += 1
        self.update_display()

        # 检查热平衡
        self.check_equilibrium()

    def check_equilibrium(self):
        if len(self.energy_history) < 20:
            return

        recent_energies = self.energy_history[-20:]
        energy_std = np.std(recent_energies)

        # 热平衡条件：能量波动很小且温度足够低
        if energy_std < 0.01 and self.temperature < 0.1:
            self.equilibrium_reached = True
            self.stop_simulation()
            self.equilibrium_label.setText("热平衡: ✅ 已达成")
            self.equilibrium_label.setStyleSheet("color: #4CAF50; font-weight: bold;")

            self.log("🎯 系统已达到热平衡状态！")
            self.log(f"   最终能量: {self.calculate_energy():.4f}")
            self.log(f"   最终温度: {self.temperature:.4f}")
            self.log(f"   神经元状态: {self.neurons}")
            self.log(f"   能量标准差: {energy_std:.6f}")

    def update_display(self):
        current_energy = self.calculate_energy()

        # 更新标签
        self.temp_label.setText(f"温度: {self.temperature:.4f}")
        self.energy_label.setText(f"能量: {current_energy:.4f}")
        self.iter_label.setText(f"迭代: {self.iteration}")

        # 更新能量历史显示
        recent_count = min(10, len(self.energy_history))
        recent_energies = self.energy_history[-recent_count:]
        energy_text = " → ".join(f"{e:.4f}" for e in recent_energies)
        self.energy_text.setPlainText(energy_text)

        # 更新进度条
        if not self.equilibrium_reached:
            progress = min(100, (self.iteration % 100))
            self.progress_bar.setValue(progress)

    def start_simulation(self):
        self.is_running = True
        self.equilibrium_reached = False
        self.status_label.setText("状态: 🟢 运行中")
        self.equilibrium_label.setText("热平衡: 🔄 趋向中...")
        self.equilibrium_label.setStyleSheet("color: #FFC107;")

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.progress_bar.setVisible(True)

        self.timer.start()
        self.log("🚀 开始玻尔兹曼机模拟...")
        self.log(f"初始温度: {self.temperature:.4f}")

    def stop_simulation(self):
        self.is_running = False
        self.status_label.setText("状态: 🔴 已停止")

        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.progress_bar.setVisible(False)

        self.timer.stop()
        self.log("⏹️ 模拟已停止")

    def reset_simulation(self):
        self.stop_simulation()

        # 重置状态
        self.neurons = [random.choice([1, -1]) for _ in range(3)]
        self.temperature = 5.0
        self.iteration = 0
        self.energy_history = []
        self.equilibrium_reached = False

        # 更新显示
        for i, widget in enumerate(self.neuron_widgets):
            widget.setState(self.neurons[i])

        self.equilibrium_label.setText("热平衡: ⏳ 未达到")
        self.equilibrium_label.setStyleSheet("color: white;")

        self.update_display()
        self.log("🔄 系统已重置")
        self.log(f"新神经元状态: {self.neurons}")

    def log(self, message):
        """添加日志信息"""
        timestamp = QTimer().remainingTime()  # 简单的时间戳
        self.console.append(f"[{self.iteration:04d}] {message}")
        # 自动滚动到底部
        scrollbar = self.console.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 设置应用程序字体
    font = QFont("Arial", 10)
    app.setFont(font)

    window = BoltzmannMachinePure()
    window.show()

    print("✅ 玻尔兹曼机程序启动成功！")
    print("   三个神经元玻尔兹曼机")
    print("   包含热平衡状态检测")
    print("   使用模拟退火算法")

    sys.exit(app.exec_())