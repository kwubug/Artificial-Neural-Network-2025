import numpy as np
import matplotlib.pyplot as plt

# 1. 生成一些示例数据
np.random.seed(0)
# 生成自变量 X
X = np.random.rand(100, 1) * 10  # 100个随机点，X在0到10之间

# 生成因变量 Y (y = 2X + 1 + 噪声)
y_true = 2 * X + 1
y_noise = y_true + np.random.randn(*y_true.shape) * 2  # 加上噪声

# 2. OLS 最小二乘法实现
# X需要加一列1作为常数项
X_ = np.hstack([np.ones((X.shape[0], 1)), X])

# 使用最小二乘法求解参数：theta = (X^T * X)^-1 * X^T * y
theta = np.linalg.inv(X_.T @ X_) @ X_.T @ y_noise

# 3. 计算拟合结果
y_pred = X_ @ theta  # 预测值

# 4. 可视化
plt.figure(figsize=(8, 6))

# 原始数据
plt.scatter(X, y_noise, color='blue', label='Data with Noise', alpha=0.6)

# 拟合直线
# 修改这里，theta[1][0] 和 theta[0][0] 用于正确的格式化
plt.plot(X, y_pred, color='red', label=f'OLS Fit: y = {theta[1][0]:.2f}x + {theta[0][0]:.2f}', linewidth=2)

# 设置标题和标签
plt.title('OLS Linear Regression')
plt.xlabel('X')
plt.ylabel('y')
plt.legend(loc='best')

# 显示图形
plt.show()
 