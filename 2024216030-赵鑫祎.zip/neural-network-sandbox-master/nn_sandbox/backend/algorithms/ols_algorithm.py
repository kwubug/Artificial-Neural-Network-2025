import time
import numpy as np

from .base_algorithm import TraningAlgorithm


class OlsAlgorithm(TraningAlgorithm):
    """
    简单的一元线性回归 (y = w*x + b) 的批量梯度下降实现。

    - dataset: 形如 [[x1, y1], [x2, y2], ...] 的二维数组
    - total_epoches: 训练总迭代步数
    - initial_learning_rate: 初始学习率
    """

    def __init__(self, dataset, total_epoches=1000, initial_learning_rate=0.01):
        super().__init__(dataset, total_epoches)
        self._initial_learning_rate = initial_learning_rate
        # 参数
        self.w = 0.0
        self.b = 0.0
        # 训练状态
        self.current_iterations = 0
        self.loss = 0.0

    def set_params(self, w: float, b: float):
        self.w = float(w)
        self.b = float(b)

    def set_dataset(self, dataset):
        self._dataset = np.array(dataset)

    def run(self):
        # 批量梯度下降
        for self.current_iterations in range(self._total_epoches):
            if self._should_stop:
                break
            self._iterate()

    def _iterate(self):
        # 如果没有数据则不更新
        if self._dataset is None or len(self._dataset) == 0:
            # 不更新 loss，但保持数值
            time.sleep(0.01)  # 避免 CPU 忙等
            return

        X = self._dataset[:, 0]
        y = self._dataset[:, 1]
        n = len(X)
        # 预测
        y_pred = self.w * X + self.b
        # MSE 损失
        self.loss = float(np.mean((y - y_pred) ** 2))

        # 梯度 (对 w, b)
        # dL/dw = (-2/n) * sum(x * (y - y_pred))
        # dL/db = (-2/n) * sum(y - y_pred)
        dw = (-2.0 / n) * float(np.sum(X * (y - y_pred)))
        db = (-2.0 / n) * float(np.sum(y - y_pred))

        # 更新参数
        self.w = float(self.w - self._initial_learning_rate * dw)
        self.b = float(self.b - self._initial_learning_rate * db)