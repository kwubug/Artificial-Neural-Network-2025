import numpy as np
import matplotlib.pyplot as plt

class RBFNetwork:
    def __init__(self, centers, sigma):
        self.centers = centers
        self.sigma = sigma
        self.weights = None
        
    def gaussian(self, x, c):
        return np.exp(-np.linalg.norm(x-c)**2 / (2 * self.sigma**2))
    
    def fit(self, X, y):
        phi = np.zeros((X.shape[0], self.centers.shape[0]))
        for i in range(X.shape[0]):
            for j in range(self.centers.shape[0]):
                phi[i, j] = self.gaussian(X[i], self.centers)
        
        self.weights = np.dot(np.linalg.pinv(phi), y)
        
    def predict(self, X):
        phi = np.zeros((X.shape[0], self.centers.shape[0]))
        for i in range(X.shape[0]):
            for j in range(self.centers.shape[0]):
                phi[i, j] = self.gaussian(X[i], self.centers)
        return np.dot(phi, self.weights)

# 输入数据
p = np.arange(-1, 1.1, 0.1)
t = np.array([-0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336, -0.2013, -0.4344,
              -0.5000, -0.3939, -0.1647, 0.0988, 0.3072, 0.3960, 0.3449, 0.01816, -0.0312, -0.2189, -0.3201])

# 准备训练数据
X = p.reshape(-1, 1)
y = t.reshape(-1, 1)

# 设置中心和扩展常数
centers = X
sigma = 0.5

# 创建并训练RBF网络
rbf_net = RBFNetwork(centers, sigma)
rbf_net.fit(X, y)

# 预测
y_pred = rbf_net.predict(X)

# 绘制结果
plt.figure(figsize=(10, 6))
plt.plot(p, t, 'o', label='initial data')
plt.plot(p, y_pred, 'r-', linewidth=2, label='RBF Network Output')
plt.grid(True)
plt.xlabel('x')
plt.ylabel('y')
plt.title('RBF')
plt.legend()
plt.show()