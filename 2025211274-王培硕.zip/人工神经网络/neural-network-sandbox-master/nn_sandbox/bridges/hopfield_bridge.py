import time

import PyQt5.QtCore

from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    initial_learning_rate = BridgeProperty(0.8)
    test_ratio = BridgeProperty(0.3)
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.hopfield_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_hopfield_algorithm(self):
        # 这里应该初始化实际的Hopfield算法
        # 暂时创建一个模拟的算法对象
        self.hopfield_algorithm = ObservableHopfieldAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict.get(self.current_dataset_name, []),
            total_epoches=self.total_epoches,
            initial_learning_rate=self.initial_learning_rate,
            test_ratio=self.test_ratio
        )
        self.hopfield_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_hopfield_algorithm(self):
        if self.hopfield_algorithm:
            self.hopfield_algorithm.stop()


class ObservableHopfieldAlgorithm(Observable):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        super().__setattr__('_observer', observer)
        super().__setattr__('ui_refresh_interval', ui_refresh_interval)
        super().__setattr__('dataset', kwargs.get('dataset', []))
        super().__setattr__('total_epoches', kwargs.get('total_epoches', 10))
        super().__setattr__('initial_learning_rate', kwargs.get('initial_learning_rate', 0.8))
        super().__setattr__('test_ratio', kwargs.get('test_ratio', 0.3))
        super().__setattr__('current_iterations', 0)
        super().__setattr__('current_learning_rate', kwargs.get('initial_learning_rate', 0.8))
        super().__setattr__('best_correct_rate', 0.0)
        super().__setattr__('current_correct_rate', 0.0)
        super().__setattr__('test_correct_rate', 0.0)
        super().__setattr__('training_dataset', [])
        super().__setattr__('testing_dataset', [])
        super().__setattr__('_stop', False)
        
    def __setattr__(self, name, value):
        # 私有属性直接设置
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            # 公共属性设置并通知观察者
            super().__setattr__(name, value)
            # 需要通知的属性列表
            notify_attrs = ['current_iterations', 'current_learning_rate', 
                          'best_correct_rate', 'current_correct_rate', 
                          'test_correct_rate']
            if name in notify_attrs:
                self.notify(name, value)

    def start(self):
        import threading
        self._thread = threading.Thread(target=self.run)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop = True

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        
        # 模拟数据集分割
        if self.dataset:
            split_idx = int(len(self.dataset) * (1 - self.test_ratio))
            self.training_dataset = self.dataset[:split_idx]
            self.testing_dataset = self.dataset[split_idx:]
            self.notify('training_dataset', [])
            self.notify('testing_dataset', [])
        
        # 模拟训练过程
        total_iterations = self.total_epoches * max(1, len(self.training_dataset))
        for i in range(total_iterations):
            if self._stop:
                break
                
            self.current_iterations = i
            self.notify('current_iterations', i)
            
            # 模拟学习率衰减
            self.current_learning_rate = self.initial_learning_rate * (1 - i / total_iterations)
            self.notify('current_learning_rate', self.current_learning_rate)
            
            # 模拟正确率
            self.current_correct_rate = 0.5 + 0.4 * (i / total_iterations)
            if self.current_correct_rate > self.best_correct_rate:
                self.best_correct_rate = self.current_correct_rate
                self.notify('best_correct_rate', self.best_correct_rate)
            
            self.notify('current_correct_rate', self.current_correct_rate)
            self.test_correct_rate = self.current_correct_rate * 0.9
            self.notify('test_correct_rate', self.test_correct_rate)
            
            # 模拟延迟
            time.sleep(self.ui_refresh_interval)
        
        self.notify('has_finished', True)