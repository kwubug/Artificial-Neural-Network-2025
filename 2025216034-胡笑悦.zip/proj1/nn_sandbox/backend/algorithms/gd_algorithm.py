import numpy as np
from .base_algorithm import TraningAlgorithm


class GdAlgorithm(TraningAlgorithm):
    """
    Gradient descent trajectory generator on 2D functions z = f(x, y).
    Supports 'sgd' (steepest descent), 'newton', and 'cg' (conjugate gradient).
    """
    def __init__(self,
                 dataset=None,
                 total_epoches=200,
                 method: str = 'sgd',
                 learning_rate: float = 0.05,
                 start_point=( -1.8, 2.0 ),
                 function: str = 'rosenbrock',
                 cg_restart_interval: int = 50,
                 newton_damping: float = 1e-3):
        if dataset is None:
            dataset = []
        super().__init__(dataset, total_epoches)
        self.method = method.lower()
        self.learning_rate = float(learning_rate)
        self.start_point = np.array(start_point, dtype=float)
        self.function = function.lower()
        self.cg_restart_interval = cg_restart_interval
        self.newton_damping = float(newton_damping)

        self.current_iterations = 0
        self._point = self.start_point.copy()
        self._path = [self._point.copy()]
        self._grad_prev = None
        self._dir_prev = None

        self.value = float('inf')
        self.grad_norm = float('inf')

    # ---- Function definitions ----
    def _f(self, p: np.ndarray) -> float:
        x, y = p
        if self.function == 'rosenbrock':
            a, b = 1.0, 100.0
            return (a - x) ** 2 + b * (y - x ** 2) ** 2
        elif self.function == 'quadratic':
            # simple convex bowl: 0.5 * (x^2 + 2 y^2)
            return 0.5 * (x * x + 2.0 * y * y)
        else:
            # default to rosenbrock
            a, b = 1.0, 100.0
            return (a - x) ** 2 + b * (y - x ** 2) ** 2

    def _grad(self, p: np.ndarray) -> np.ndarray:
        x, y = p
        if self.function == 'rosenbrock':
            a, b = 1.0, 100.0
            df_dx = -2.0 * (a - x) - 4.0 * b * x * (y - x ** 2)
            df_dy = 2.0 * b * (y - x ** 2)
            return np.array([df_dx, df_dy], dtype=float)
        elif self.function == 'quadratic':
            return np.array([x, 2.0 * y], dtype=float)
        else:
            a, b = 1.0, 100.0
            df_dx = -2.0 * (a - x) - 4.0 * b * x * (y - x ** 2)
            df_dy = 2.0 * b * (y - x ** 2)
            return np.array([df_dx, df_dy], dtype=float)

    def _hess(self, p: np.ndarray) -> np.ndarray:
        x, y = p
        if self.function == 'rosenbrock':
            a, b = 1.0, 100.0
            dxx = 2.0 - 4.0 * b * (y - 3.0 * x ** 2)
            dxy = -4.0 * b * x
            dyx = dxy
            dyy = 2.0 * b
            return np.array([[dxx, dxy], [dyx, dyy]], dtype=float)
        elif self.function == 'quadratic':
            return np.array([[1.0, 0.0], [0.0, 2.0]], dtype=float)
        else:
            a, b = 1.0, 100.0
            dxx = 2.0 - 4.0 * b * (y - 3.0 * x ** 2)
            dxy = -4.0 * b * x
            dyx = dxy
            dyy = 2.0 * b
            return np.array([[dxx, dxy], [dyx, dyy]], dtype=float)

    def run(self):
        self._should_stop = False
        self._point = self.start_point.copy()
        self._path = [self._point.copy()]
        self._grad_prev = None
        self._dir_prev = None
        for self.current_iterations in range(self._total_epoches):
            if self._should_stop:
                break
            self._iterate()

    def _iterate(self):
        g = self._grad(self._point)
        H = None
        if self.method == 'newton':
            H = self._hess(self._point)
        self.value = float(self._f(self._point))
        self.grad_norm = float(np.linalg.norm(g))

        # Direction
        if self.method == 'sgd':
            direction = -g
        elif self.method == 'newton':
            # damped Newton: (H + lambda I)^{-1} g
            I = np.eye(2)
            H_damped = H + self.newton_damping * I
            try:
                newton_step = -np.linalg.solve(H_damped, g)
            except np.linalg.LinAlgError:
                newton_step = -g
            direction = newton_step
        elif self.method == 'cg':
            # Fletcher-Reeves
            if self._grad_prev is None or (self.cg_restart_interval and (self.current_iterations % self.cg_restart_interval == 0)):
                beta = 0.0
                d_prev = np.zeros_like(g)
            else:
                num = float(np.dot(g, g))
                den = float(np.dot(self._grad_prev, self._grad_prev)) + 1e-12
                beta = max(0.0, num / den)
                d_prev = self._dir_prev if self._dir_prev is not None else np.zeros_like(g)
            direction = -g + beta * d_prev
            if not np.all(np.isfinite(direction)) or np.linalg.norm(direction) < 1e-12:
                direction = -g.copy()
            # cache
            self._grad_prev = g.copy()
            self._dir_prev = direction.copy()
        else:
            direction = -g

        # Step
        step = self.learning_rate * direction
        # Clamp extreme steps
        step_norm = np.linalg.norm(step)
        if step_norm > 2.0:
            step = step * (2.0 / (step_norm + 1e-12))
        self._point = self._point + step
        self._path.append(self._point.copy())

    # Expose current point and path to observers
    @property
    def point(self):
        return self._point

    @property
    def path(self):
        return np.array(self._path, dtype=float)

