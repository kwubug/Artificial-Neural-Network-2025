import numpy as np
import threading
import time


# ---------- 目标函数 ----------
def quadratic_fn(x, y):
    return x**2 + 2*y**2

def elliptical_fn(x, y):
    return 5*x**2 + y**2

# 对应梯度
def grad_quadratic(x, y):
    return np.array([2*x, 4*y])

def grad_elliptical(x, y):
    return np.array([10*x, 2*y])

# 对应 Hessian (牛顿法用)
HESSIANS = {
    'quadratic': np.array([[2, 0],[0,4]]),
    'elliptical': np.array([[10,0],[0,2]])
}

# ---------- 梯度下降算法 ----------
class GradientDescentAlgorithm(threading.Thread):
    def __init__(self, observer, start_point=[-3,4], func_type='quadratic', method='steepest',
                 max_iter=20, tol=1e-6, ui_refresh_interval=0.5):
        super().__init__()
        self.daemon = True
        self.observer = observer
        self.start_point = np.array(start_point, dtype=float)
        self.method = method
        self.max_iter = max_iter
        self.tol = tol
        self.ui_refresh_interval = ui_refresh_interval
        self._should_stop = False

        if func_type == 'quadratic':
            self.f = quadratic_fn
            self.grad = grad_quadratic
            self.H = HESSIANS['quadratic']
        elif func_type == 'elliptical':
            self.f = elliptical_fn
            self.grad = grad_elliptical
            self.H = HESSIANS['elliptical']
        else:
            raise ValueError('Unknown function type')

        self.path = []

    def stop(self):
        self._should_stop = True

    def run(self):
        x = self.start_point.copy()
        g = self.grad(*x)
        self.path = [x.copy()]
        if self.method == 'steepest':
            for k in range(self.max_iter):
                if self._should_stop or np.linalg.norm(g) < self.tol:
                    break
                # 最速下降
                alpha = np.dot(g,g)/np.dot(g,np.array([[2,0],[0,4]])@g)
                x = x - alpha * g
                g = self.grad(*x)
                self.path.append(x.copy())
                self.observer.notify('current_point', x.tolist())
                time.sleep(self.ui_refresh_interval)
        elif self.method == 'newton':
            for k in range(self.max_iter):
                if self._should_stop or np.linalg.norm(g) < self.tol:
                    break
                # 牛顿法
                H_inv = np.linalg.inv(self.H)
                x = x - H_inv @ g
                g = self.grad(*x)
                self.path.append(x.copy())
                self.observer.notify('current_point', x.tolist())
                time.sleep(self.ui_refresh_interval)
        elif self.method == 'conjugate':
            d = -g
            for k in range(self.max_iter):
                if self._should_stop or np.linalg.norm(g) < self.tol:
                    break
                alpha = np.dot(g,g)/np.dot(d,self.H @ d)
                x = x + alpha * d
                g_new = self.grad(*x)
                beta = np.dot(g_new,g_new)/np.dot(g,g)
                d = -g_new + beta*d
                g = g_new
                self.path.append(x.copy())
                self.observer.notify('current_point', x.tolist())
                time.sleep(self.ui_refresh_interval)
        self.observer.notify('finished', True)
