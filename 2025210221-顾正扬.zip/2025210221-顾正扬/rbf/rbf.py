import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# 设置matplotlib支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


# 数据预处理和加载
def load_data():
    x = np.linspace(-1, 1, 21)
    y = np.array(
        [-0.9602, -0.5770, 0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336, -0.2013, -0.4344, 0.5000, -0.3939, -0.1674,
         0.0988, 0.3072, 0.3960, 0.3449, 0.11816, 0.0312, -0.2198, -0.3201])
    return x, y


# 数据标准化
def normalize_data(x, y):
    # 对x进行标准化
    x_mean = np.mean(x)
    x_std = np.std(x)
    x_norm = (x - x_mean) / x_std if x_std > 0 else x

    # 对y进行标准化
    y_mean = np.mean(y)
    y_std = np.std(y)
    y_norm = (y - y_mean) / y_std if y_std > 0 else y

    return x_norm, y_norm, x_mean, x_std, y_mean, y_std


# 数据反标准化
def denormalize_y(y_norm, y_mean, y_std):
    return y_norm * y_std + y_mean


# 可视化拟合结果
def visualize_fit(x, y, y_pred, rbf_net, x_mean, x_std):
    plt.figure(figsize=(12, 8))

    # 绘制原始数据点
    plt.scatter(x, y, color='blue', label='原始数据点')

    # 生成密集的x值用于绘制平滑曲线
    x_dense = np.linspace(min(x), max(x), 200)

    # 对密集x值进行标准化并预测
    x_dense_norm = (x_dense - x_mean) / x_std
    y_dense_pred_norm = rbf_net.predict(x_dense_norm)
    y_dense_pred = denormalize_y(y_dense_pred_norm, np.mean(y), np.std(y))

    # 绘制拟合曲线
    plt.plot(x_dense, y_dense_pred, color='red', linewidth=2, label='RBF网络拟合曲线')

    # 绘制径向基函数中心位置
    centers_original = rbf_net.centers * x_std + x_mean  # 将标准化的中心转换回原始尺度
    plt.scatter(centers_original, np.zeros_like(centers_original),
                color='green', s=100, marker='^', label='RBF中心')

    # 添加标题和标签
    plt.title(f'RBF神经网络曲线拟合 (中心数量: {rbf_net.num_centers})')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='best')

    # 显示图表
    plt.tight_layout()
    plt.show()


# 参数优化：测试不同数量的中心
def optimize_parameters(x, y, center_range=(2, 20)):
    # 数据标准化
    x_norm, y_norm, x_mean, x_std, y_mean, y_std = normalize_data(x, y)

    center_list = range(center_range[0], center_range[1] + 1)
    mse_list = []
    models = {}

    print("\n参数优化：测试不同数量的径向基函数中心")
    print("中心数量 | 均方误差(MSE)")
    print("--------|-------------")

    # 测试不同数量的中心
    for num_centers in center_list:
        rbf_net = RBFNetwork(num_centers)
        rbf_net.train(x_norm, y_norm)
        mse = rbf_net.evaluate(x_norm, y_norm)
        mse_list.append(mse)
        models[num_centers] = rbf_net

        print(f"{num_centers:8d} | {mse:10.6f}")

    # 找出最优中心数量
    best_idx = np.argmin(mse_list)
    best_num_centers = list(center_list)[best_idx]
    best_mse = mse_list[best_idx]
    best_model = models[best_num_centers]

    print(f"\n最优中心数量: {best_num_centers}")
    print(f"对应的最小MSE: {best_mse:.6f}")

    # 可视化不同中心数量的性能对比
    plt.figure(figsize=(10, 6))
    plt.plot(center_list, mse_list, marker='o', linestyle='-', color='blue')
    plt.scatter([best_num_centers], [best_mse], color='red', s=100, zorder=5)
    plt.annotate(f'最优: {best_num_centers}',
                 xy=(best_num_centers, best_mse),
                 xytext=(best_num_centers + 1, best_mse + 0.01),
                 arrowprops=dict(facecolor='black', shrink=0.05, width=1.5))
    plt.title('不同中心数量对模型性能的影响')
    plt.xlabel('中心数量')
    plt.ylabel('均方误差(MSE)')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

    # 可视化最优模型的拟合效果
    y_pred_norm = best_model.predict(x_norm)
    y_pred = denormalize_y(y_pred_norm, y_mean, y_std)
    print("\n最优模型的拟合结果:")
    visualize_fit(x, y, y_pred, best_model, x_mean, x_std)

    return best_model, best_num_centers, best_mse


# RBF神经网络类
class RBFNetwork:
    def __init__(self, num_centers):
        self.num_centers = num_centers
        self.centers = None
        self.widths = None
        self.weights = None

    # 径向基函数（高斯函数）
    def _gaussian(self, x, c, w):
        return np.exp(-0.5 * np.square((x - c) / w))

    # 计算RBF层的输出
    def _compute_rbf_outputs(self, x):
        rbf_outputs = np.zeros((len(x), self.num_centers))
        for i in range(self.num_centers):
            rbf_outputs[:, i] = self._gaussian(x, self.centers[i], self.widths[i])
        return rbf_outputs

    # 使用K-means选择中心
    def _select_centers(self, x):
        x_reshaped = x.reshape(-1, 1)
        kmeans = KMeans(n_clusters=self.num_centers, random_state=42)
        kmeans.fit(x_reshaped)
        self.centers = kmeans.cluster_centers_.flatten()

    # 计算宽度参数
    def _compute_widths(self):
        # 计算中心之间的平均距离作为宽度的参考
        sorted_centers = np.sort(self.centers)
        dists = np.diff(sorted_centers)
        avg_dist = np.mean(dists)
        self.widths = np.ones(self.num_centers) * avg_dist * np.sqrt(2)

    # 训练模型
    def train(self, x, y):
        # 选择中心
        self._select_centers(x)
        # 计算宽度
        self._compute_widths()
        # 计算RBF层输出
        rbf_outputs = self._compute_rbf_outputs(x)
        # 添加偏置项
        rbf_outputs_with_bias = np.column_stack((rbf_outputs, np.ones(len(x))))
        # 使用最小二乘法求解权重
        # weights = (X^T X)^(-1) X^T y
        self.weights = np.linalg.pinv(rbf_outputs_with_bias) @ y

    # 预测
    def predict(self, x):
        rbf_outputs = self._compute_rbf_outputs(x)
        rbf_outputs_with_bias = np.column_stack((rbf_outputs, np.ones(len(x))))
        return rbf_outputs_with_bias @ self.weights

    # 评估模型性能
    def evaluate(self, x, y):
        predictions = self.predict(x)
        mse = np.mean(np.square(predictions - y))
        return mse


# 主函数：训练和评估RBF神经网络
def main():
    # 加载数据
    x, y = load_data()

    print("RBF神经网络曲线拟合")
    print("===================")

    # 询问用户是否进行参数优化
    optimize = input("是否进行参数优化? (y/n, 默认n): ").strip().lower()

    if optimize == 'y':
        # 进行参数优化
        best_model, best_num_centers, best_mse = optimize_parameters(x, y)
        print(f"\n优化完成！最佳中心数量: {best_num_centers}, 最小MSE: {best_mse:.6f}")
    else:
        # 使用默认参数进行训练
        # 数据标准化
        x_norm, y_norm, x_mean, x_std, y_mean, y_std = normalize_data(x, y)

        # 设置RBF神经网络参数
        num_centers = 10  # 径向基函数的数量

        # 创建并训练模型
        rbf_net = RBFNetwork(num_centers)
        rbf_net.train(x_norm, y_norm)

        # 在训练数据上评估模型
        mse = rbf_net.evaluate(x_norm, y_norm)
        print(f"模型在训练数据上的均方误差(MSE): {mse:.6f}")

        # 使用模型进行预测
        y_pred_norm = rbf_net.predict(x_norm)
        y_pred = denormalize_y(y_pred_norm, y_mean, y_std)

        print("\n预测结果与实际值对比:")
        for i in range(len(x)):
            print(f"x={x[i]:.2f}, 实际y={y[i]:.4f}, 预测y={y_pred[i]:.4f}")

        # 可视化拟合结果
        visualize_fit(x, y, y_pred, rbf_net, x_mean, x_std)

    print("\n程序执行完毕！")


if __name__ == "__main__":
    main()
