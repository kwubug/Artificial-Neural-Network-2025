import numpy as np

from . import TraningAlgorithm


class CHNNTSPAlgorithm(TraningAlgorithm):
    """连续 Hopfield 神经网络求解 TSP 问题"""
    
    def __init__(self, n_cities=5, A=500, B=500, C=200, D=500, 
                 dt=0.0001, max_iterations=5000, total_epoches=1):
        """
        Args:
            n_cities: 城市数量
            A, B, C, D: 能量函数的权重参数
            dt: 时间步长
            max_iterations: 最大迭代次数
        """
        super().__init__(dataset=[], total_epoches=total_epoches)
        
        self.n_cities = n_cities
        self.n_neurons = n_cities * n_cities  # 神经元数量 = N×N
        
        # 能量函数参数
        self.A = A
        self.B = B
        self.C = C
        self.D = D
        self.dt = dt
        self.max_iterations = max_iterations
        
        # 城市坐标（随机生成）
        self.city_positions = None
        self.distance_matrix = None
        
        # 神经元状态（N×N 矩阵）
        self.V = None  # 输入电压
        self.U = None  # 输出（激活值）
        
        # 历史记录
        self.energy_history = []
        self.distance_history = []
        self.best_tour = None
        self.best_distance = float('inf')
        
        # 状态
        self.current_iterations = 0
        self.current_energy = 0.0
        self.current_distance = 0.0
        self.is_valid_solution = False
        self.current_tour = None  # 当前路径（实时）
        
    def _initialize_neurons(self):
        """初始化神经元和城市"""
        self._neurons = []
        
        # 只有在城市位置未设置或为空时才生成随机城市坐标
        if self.city_positions is None or (isinstance(self.city_positions, np.ndarray) and len(self.city_positions) == 0):
            # 生成随机城市坐标
            np.random.seed(42)  # 固定种子以便复现
            self.city_positions = np.random.rand(self.n_cities, 2)
            # 计算距离矩阵
            self.distance_matrix = self._calculate_distance_matrix()
        else:
            # 城市位置已设置，检查城市数量是否匹配
            if len(self.city_positions) != self.n_cities:
                raise ValueError(f"城市数量不匹配：设置的城市数量为 {len(self.city_positions)}，但算法期望 {self.n_cities} 个城市")
            # 确保city_positions是numpy数组
            if not isinstance(self.city_positions, np.ndarray):
                self.city_positions = np.array(self.city_positions)
            # 城市位置已设置，距离矩阵应该在set_cities()中已经计算过了
            if self.distance_matrix is None:
                self.distance_matrix = self._calculate_distance_matrix()
        
        # 初始化神经元状态（随机初始化 + 小扰动）
        np.random.seed()  # 使用当前时间作为种子
        self.V = np.random.rand(self.n_cities, self.n_cities) * 0.1 + 0.5
        self.U = self._activation(self.V)
        
        # 初始化历史
        self.energy_history = []
        self.distance_history = []
        self.best_distance = float('inf')
        self.current_iterations = 0
        
    def _calculate_distance_matrix(self):
        """计算城市间距离矩阵"""
        n = self.n_cities
        distances = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                if i != j:
                    diff = self.city_positions[i] - self.city_positions[j]
                    distances[i][j] = np.sqrt(np.sum(diff**2))
        
        return distances
    
    def _activation(self, x):
        """激活函数（Sigmoid）"""
        return 0.5 * (1 + np.tanh(x))
    
    def _calculate_energy(self):
        """计算 Hopfield 能量函数"""
        U = self.U
        d = self.distance_matrix
        n = self.n_cities
        
        # 项1: 每行只有一个1
        term_A = 0
        for x in range(n):
            sum_row = np.sum(U[x, :])
            term_A += (sum_row - 1) ** 2
        
        # 项2: 每列只有一个1
        term_B = 0
        for i in range(n):
            sum_col = np.sum(U[:, i])
            term_B += (sum_col - 1) ** 2
        
        # 项3: 总共n个1
        term_C = (np.sum(U) - n) ** 2
        
        # 项4: 最小化路径长度
        term_D = 0
        for x in range(n):
            for y in range(n):
                for i in range(n):
                    j = (i + 1) % n  # 循环
                    term_D += d[x][y] * U[x][i] * U[y][j]
        
        energy = self.A * term_A + self.B * term_B + self.C * term_C + self.D * term_D
        return energy
    
    def _calculate_du_dt(self):
        """计算神经元状态变化率 dU/dt"""
        U = self.U
        d = self.distance_matrix
        n = self.n_cities
        
        dU_dt = np.zeros((n, n))
        
        for x in range(n):
            for i in range(n):
                # 计算输入
                input_xi = 0
                
                # 来自约束项 A（行约束）
                input_xi -= self.A * (np.sum(U[x, :]) - 1)
                
                # 来自约束项 B（列约束）
                input_xi -= self.B * (np.sum(U[:, i]) - 1)
                
                # 来自约束项 C（总数约束）
                input_xi -= self.C * (np.sum(U) - n)
                
                # 来自距离项 D
                for y in range(n):
                    if y != x:
                        j_prev = (i - 1) % n
                        j_next = (i + 1) % n
                        input_xi -= self.D * d[x][y] * (U[y][j_prev] + U[y][j_next])
                
                dU_dt[x][i] = input_xi
        
        return dU_dt
    
    def _iterate(self):
        """单次迭代"""
        # 计算状态变化率
        dV_dt = self._calculate_du_dt()
        
        # 更新电压
        self.V = self.V + self.dt * dV_dt
        
        # 更新输出
        self.U = self._activation(self.V)
        
        # 计算能量
        self.current_energy = self._calculate_energy()
        self.energy_history.append(self.current_energy)
        
        # 提取当前路径并计算距离
        tour, distance, is_valid = self._extract_tour()
        self.current_tour = tour  # 保存当前路径
        self.current_distance = distance
        self.is_valid_solution = is_valid
        
        # 记录距离历史
        if is_valid and distance != float('inf') and not np.isnan(distance) and distance < 1000:
            self.distance_history.append(float(distance))
        else:
            if self.best_distance != float('inf') and self.best_distance < 1000:
                self.distance_history.append(float(self.best_distance))
            elif len(self.distance_history) > 0:
                self.distance_history.append(self.distance_history[-1])
            else:
                self.distance_history.append(10.0)
        
        # 更新最优解
        if is_valid and distance < self.best_distance and distance < 100:
            self.best_distance = distance
            self.best_tour = tour.copy()
        
        self.current_iterations += 1
    
    def _extract_tour(self):
        """从神经元状态提取TSP路径"""
        n = self.n_cities
        U = self.U
        tour = [-1] * n
        remaining_cities = set(range(n))
        
        # 第一次分配：逐列选择激活度最高且未被占用的城市
        for position in range(n):
            column_order = np.argsort(U[:, position])[::-1]
            for city in column_order:
                if int(city) in remaining_cities:
                    tour[position] = int(city)
                    remaining_cities.remove(int(city))
                    break
        
        # 若仍有未分配的位置，使用剩余城市的激活度继续分配
        if remaining_cities:
            for position in range(n):
                if tour[position] != -1:
                    continue
                if not remaining_cities:
                    break
                best_city = max(remaining_cities, key=lambda c: U[c, position])
                tour[position] = int(best_city)
                remaining_cities.remove(best_city)
        
        # 如果仍存在未分配（理论上不应该发生），将剩余城市依次填充
        if remaining_cities:
            for position in range(n):
                if tour[position] == -1:
                    city = remaining_cities.pop()
                    tour[position] = int(city)
                    if not remaining_cities:
                        break
        
        is_valid = len(set(tour)) == n
        
        # 规范化路径：将路径旋转，使其从城市0开始（如果包含城市0）
        if is_valid:
            tour = self._normalize_tour(tour)
        
        # 计算路径长度（TSP路径必须是一个环）
        if is_valid:
            distance = 0.0
            for i in range(n):
                j = (i + 1) % n  # 最后一个城市连接到第一个城市，形成环
                distance += self.distance_matrix[tour[i]][tour[j]]
        else:
            distance = float('inf')
        
        return tour, distance, is_valid
    
    def _normalize_tour(self, tour):
        """规范化路径：旋转路径使其从城市0开始"""
        if not tour or 0 not in tour:
            return tour
        
        start_idx = tour.index(0)
        normalized = tour[start_idx:] + tour[:start_idx]
        return normalized
    
    def run(self):
        """运行算法"""
        self._initialize_neurons()
        
        while self.current_iterations < self.max_iterations and not self._should_stop:
            self._iterate()
        
        # 确保有最优解
        if self.best_tour is None:
            tour, distance, is_valid = self._extract_tour()
            if is_valid:
                self.best_tour = tour
                self.best_distance = distance
    
    def set_cities(self, positions):
        """手动设置城市位置"""
        positions_array = np.array(positions)
        if positions_array.shape[1] != 2:
            raise ValueError(f"城市位置必须是二维坐标，每行包含x和y坐标")
        
        self.city_positions = positions_array
        self.n_cities = len(positions)
        self.n_neurons = self.n_cities * self.n_cities
        # 重新计算距离矩阵
        self.distance_matrix = self._calculate_distance_matrix()
    
    def get_current_tour_matrix(self):
        """获取当前的神经元状态矩阵（用于可视化）"""
        return self.U.tolist()


