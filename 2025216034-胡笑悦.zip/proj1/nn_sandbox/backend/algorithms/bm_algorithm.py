import numpy as np
import math

from . import TraningAlgorithm


class BmAlgorithm(TraningAlgorithm):
    """
    Boltzmann Machine with 3 neurons.
    Implements a 3-neuron Boltzmann Machine with energy-based learning.
    """
    def __init__(self, dataset, total_epoches=100, initial_temperature=10.0,
                 cooling_rate=0.95, equilibrium_iterations=100,
                 convergence_threshold=0.01):
        super().__init__(dataset, total_epoches)
        self._initial_temperature = initial_temperature
        self._cooling_rate = cooling_rate
        self._equilibrium_iterations = equilibrium_iterations
        self._convergence_threshold = convergence_threshold
        
        self.num_neurons = 3
        self.current_iterations = 0
        self._states = None  # Neuron states: [0, 1] or [-1, 1]
        self._weights = None  # Weight matrix (3x3, symmetric)
        self._biases = None  # Bias vector (3x1)
        self._temperature = initial_temperature
        self._energy = 0.0
        self._is_equilibrium = False
        self._energy_history = []
        self._state_history = []
        self._temperature_history = []
        self._equilibrium_check_counter = 0
        self._last_energy_change = float('inf')

    def run(self):
        """Run the Boltzmann Machine algorithm."""
        self._initialize_network()
        for self.current_iterations in range(self._total_epoches):
            if self._should_stop:
                break
            # Update temperature before iteration (simulated annealing)
            self._temperature = max(0.1, self._initial_temperature * 
                                  (self._cooling_rate ** self.current_iterations))
            self._iterate()

    def _initialize_network(self):
        """Initialize the network: weights, biases, and initial states."""
        # Initialize weights (3x3 symmetric matrix, diagonal = 0)
        # Small random values
        self._weights = np.random.uniform(-0.5, 0.5, (self.num_neurons, self.num_neurons))
        # Make symmetric and set diagonal to 0
        self._weights = (self._weights + self._weights.T) / 2
        np.fill_diagonal(self._weights, 0)
        
        # Initialize biases (small random values)
        self._biases = np.random.uniform(-0.5, 0.5, self.num_neurons)
        
        # Initialize states randomly (0 or 1)
        self._states = np.random.randint(0, 2, self.num_neurons).astype(float)
        
        # Calculate initial energy
        self._energy = self._calculate_energy()
        self._energy_history = [self._energy]
        self._state_history = [self._states.copy().tolist()]
        self._temperature_history = [self._temperature]
        self._is_equilibrium = False
        self._equilibrium_check_counter = 0
        self._last_energy_change = float('inf')

    def _calculate_energy(self):
        """
        Calculate the energy of the current state.
        E = -0.5 * sum_i sum_j (w_ij * s_i * s_j) - sum_i (b_i * s_i)
        Since weights are symmetric and diagonal is 0, we can compute this efficiently.
        """
        # Interaction terms: -0.5 * sum_i sum_j (w_ij * s_i * s_j)
        # Using matrix multiplication for efficiency
        interaction_energy = -0.5 * np.dot(self._states, np.dot(self._weights, self._states))
        # Bias terms: -sum_i (b_i * s_i)
        bias_energy = -np.dot(self._biases, self._states)
        return interaction_energy + bias_energy

    def _calculate_local_field(self, neuron_idx):
        """
        Calculate the local field (input) for a neuron.
        h_i = sum_j (w_ij * s_j) + b_i
        Note: w_ii = 0, so we don't need to exclude self-connection explicitly.
        """
        # Since diagonal is 0, we can compute this directly
        local_field = np.dot(self._weights[neuron_idx, :], self._states) + self._biases[neuron_idx]
        return local_field

    def _calculate_flip_probability(self, neuron_idx):
        """
        Calculate the probability of flipping a neuron's state.
        P(flip) = 1 / (1 + exp(DeltaE / T))
        where DeltaE = 2 * s_i * h_i (energy change if flipped)
        """
        if self._temperature <= 0:
            return 0.0
        
        local_field = self._calculate_local_field(neuron_idx)
        current_state = self._states[neuron_idx]
        # Energy change if we flip the state (0->1 or 1->0)
        # For binary states: new_state = 1 - current_state
        # DeltaE = -2 * current_state * local_field + local_field
        # Simplified: DeltaE = (1 - 2*current_state) * local_field
        delta_energy = (1 - 2 * current_state) * local_field
        
        # Probability of flipping
        if delta_energy <= 0:
            return 1.0
        else:
            return 1.0 / (1.0 + math.exp(delta_energy / self._temperature))

    def _update_neuron_state(self, neuron_idx):
        """Update a single neuron's state based on probability."""
        flip_prob = self._calculate_flip_probability(neuron_idx)
        if np.random.random() < flip_prob:
            # Flip the state
            self._states[neuron_idx] = 1.0 - self._states[neuron_idx]

    def _iterate(self):
        """Perform one iteration: update all neurons and check equilibrium."""
        # Update each neuron once (random order)
        neuron_order = np.random.permutation(self.num_neurons)
        for neuron_idx in neuron_order:
            self._update_neuron_state(neuron_idx)
        
        # Calculate new energy
        new_energy = self._calculate_energy()
        energy_change = abs(new_energy - self._energy)
        
        # Update energy and history
        self._energy = new_energy
        self._energy_history.append(self._energy)
        self._state_history.append(self._states.copy().tolist())
        self._temperature_history.append(self._temperature)
        
        # Check for equilibrium
        self._check_equilibrium(energy_change)

    def _check_equilibrium(self, energy_change):
        """
        Check if the network has reached thermal equilibrium.
        Equilibrium is reached when energy changes are small and stable.
        """
        self._equilibrium_check_counter += 1
        
        # Check if energy change is below threshold
        if energy_change < self._convergence_threshold:
            # Standard condition: sustained small changes
            if self._equilibrium_check_counter >= self._equilibrium_iterations:
                self._is_equilibrium = True
            # Temperature-aware early condition to reach equilibrium earlier
            elif self._temperature <= 0.2 and self._equilibrium_check_counter >= max(10, self._equilibrium_iterations // 5):
                self._is_equilibrium = True
        else:
            # Reset counter if energy change is significant
            self._equilibrium_check_counter = 0
            # Do not forcibly unset equilibrium once reached during this run
        
        self._last_energy_change = energy_change

    @property
    def current_data(self):
        """Return current data point (not used in BM, but required by base class)."""
        if len(self._dataset) > 0:
            return self._dataset[self.current_iterations % len(self._dataset)]
        return None

    @property
    def states(self):
        """Get current neuron states."""
        return self._states.copy()

    @property
    def weights(self):
        """Get weight matrix."""
        return self._weights.copy()

    @property
    def biases(self):
        """Get bias vector."""
        return self._biases.copy()

    @property
    def energy(self):
        """Get current energy."""
        return self._energy

    @property
    def temperature(self):
        """Get current temperature."""
        return self._temperature

    @property
    def is_equilibrium(self):
        """Check if network is in thermal equilibrium."""
        return self._is_equilibrium

    @property
    def energy_history(self):
        """Get energy history."""
        return self._energy_history.copy()

    @property
    def state_history(self):
        """Get state history."""
        return self._state_history.copy()

    @property
    def temperature_history(self):
        """Get temperature history."""
        return self._temperature_history.copy()

