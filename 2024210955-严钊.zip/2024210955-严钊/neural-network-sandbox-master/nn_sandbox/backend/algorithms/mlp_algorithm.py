# import collections
#
# import numpy as np
#
# from . import PredictiveAlgorithm
# from ..neurons import Perceptron
# from ..utils import sigmoid
#
#
# class MlpAlgorithm(PredictiveAlgorithm):
#     """ Backpropagation prototype. """
#
#     def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
#                  initial_learning_rate=0.8, search_iteration_constant=10000,
#                  momentum_weight=0.5, test_ratio=0.3, network_shape=None):
#         super().__init__(dataset, total_epoches, most_correct_rate,
#                          initial_learning_rate, search_iteration_constant,
#                          test_ratio)
#         self._momentum_weight = momentum_weight
#
#         # the default network shape is (2 * 5)
#         self.network_shape = network_shape if network_shape else (5, 5)
#
#         # for momentum
#         self._synaptic_weight_diff = collections.defaultdict(lambda: 0)
#
#     def _iterate(self):
#         result = self._feed_forward(self.current_data[:-1])
#         deltas = self._pass_backward(self._normalize(self.current_data[-1]),
#                                      result)
#         self._adjust_synaptic_weights(deltas)
#
#     def _initialize_neurons(self):
#         """ Build the neuron network with single neuron as output layer. """
#         self._neurons = tuple((Perceptron(sigmoid),) * size
#                               for size in list(self.network_shape) + [1])
#
#     def _feed_forward(self, data):
#         results = [None]
#         for idx, layer in enumerate(self._neurons):
#             if idx == 0:
#                 results = get_layer_results(layer, data)
#                 continue
#             results = get_layer_results(layer, results)
#         return results[0]
#
#     def _pass_backward(self, expect, result):
#         """ Calculate the delta for each neuron. """
#         deltas = {}
#
#         deltas[self._neurons[-1][0]] = ((expect - result)
#                                         * result * (1 - result))
#
#         for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
#             for neuron_idx, neuron in enumerate(layer):
#                 deltas[neuron] = (
#                     # sum of (delta) * (synaptic weight) for each neuron in next layer
#                     sum(deltas[n] * n.synaptic_weight[neuron_idx]
#                         for n in self._neurons[layer_idx + 1])
#                     * neuron.result
#                     * (1 - neuron.result)
#                 )
#         return deltas
#
#     def _adjust_synaptic_weights(self, deltas):
#         for neuron in deltas:
#             self._synaptic_weight_diff[neuron] = (
#                 self._synaptic_weight_diff[neuron] * self._momentum_weight
#                 + self.current_learning_rate * deltas[neuron] * neuron.data
#             )
#             neuron.synaptic_weight += self._synaptic_weight_diff[neuron]
#
#     def _correct_rate(self, dataset):
#         if not self._neurons:
#             return 0
#         correct_count = 0
#         for data in dataset:
#             self._feed_forward(data[:-1])
#             expect = self._normalize(data[-1])
#             interval = 1 / (2 * len(self.group_types))
#             if expect - interval < self._neurons[-1][0].result < expect + interval:
#                 correct_count += 1
#         if correct_count == 0:
#             return 0
#         return correct_count / len(dataset)
#
#     def _normalize(self, value):
#         """ Normalize expected output. """
#         return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))
#
#
# def get_layer_results(layer, data):
#     for neuron in layer:
#         neuron.data = data
#     return np.fromiter((neuron.result for neuron in layer), dtype=float)


# import collections
# # import numpy as np
# #
# # from . import PredictiveAlgorithm
# # from ..neurons import Perceptron
# # from ..utils import sigmoid
# #
# #
# # class MlpAlgorithm(PredictiveAlgorithm):
# #     """ Improved Backpropagation with customizable layers and weight initialization. """
# #
# #     def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
# #                  initial_learning_rate=0.8, search_iteration_constant=10000,
# #                  momentum_weight=0.5, test_ratio=0.3, network_shape=None,
# #                  learning_rates=None, weight_init_range=(-1, 1)):
# #         super().__init__(dataset, total_epoches, most_correct_rate,
# #                          initial_learning_rate, search_iteration_constant,
# #                          test_ratio)
# #         self._momentum_weight = momentum_weight
# #
# #         # the default network shape is (2 * 5)
# #         self.network_shape = network_shape if network_shape else [5, 5]
# #
# #         # per-layer learning rates
# #         self.learning_rates = learning_rates if learning_rates else [initial_learning_rate] * (
# #                     len(self.network_shape) + 1)
# #
# #         # weight initialization range
# #         self.weight_init_range = weight_init_range
# #
# #         # for momentum
# #         self._synaptic_weight_diff = collections.defaultdict(lambda: 0)
# #
# #     def _iterate(self):
# #         result = self._feed_forward(self.current_data[:-1])
# #         deltas = self._pass_backward(self._normalize(self.current_data[-1]),
# #                                      result)
# #         self._adjust_synaptic_weights(deltas)
# #
# #     def _initialize_neurons(self):
# #         """Build the neuron network with random-initialized weights."""
# #         self._neurons = []
# #         input_size = len(self.current_data[:-1])  # 输入层节点数 (根据样本输入维度)
# #
# #         layer_input_size = input_size
# #         for layer_size in list(self.network_shape) + [1]:  # 最后一层是输出层
# #             layer = []
# #             for _ in range(layer_size):
# #                 neuron = Perceptron(sigmoid)
# #                 # 初始化权值 [-1,1]
# #                 neuron.synaptic_weight = np.random.uniform(-1, 1, layer_input_size)
# #                 layer.append(neuron)
# #             self._neurons.append(tuple(layer))
# #             layer_input_size = layer_size
# #
# #         # Hidden layers
# #         for layer_idx in range(1, len(self.network_shape)):
# #             layer = []
# #             prev_layer_size = self.network_shape[layer_idx - 1]
# #             for i in range(self.network_shape[layer_idx]):
# #                 neuron = Perceptron(sigmoid)
# #                 # Initialize weights with random values in specified range
# #                 neuron.synaptic_weight = np.random.uniform(
# #                     self.weight_init_range[0],
# #                     self.weight_init_range[1],
# #                     prev_layer_size + 1  # +1 for bias
# #                 )
# #                 layer.append(neuron)
# #             self._neurons.append(tuple(layer))
# #
# #         # Output layer
# #         output_layer = []
# #         last_hidden_size = self.network_shape[-1]
# #         neuron = Perceptron(sigmoid)
# #         # Initialize weights with random values in specified range
# #         neuron.synaptic_weight = np.random.uniform(
# #             self.weight_init_range[0],
# #             self.weight_init_range[1],
# #             last_hidden_size + 1  # +1 for bias
# #         )
# #         output_layer.append(neuron)
# #         self._neurons.append(tuple(output_layer))
# #
# #     def _feed_forward(self, data):
# #         results = [None]
# #         for idx, layer in enumerate(self._neurons):
# #             if idx == 0:
# #                 results = get_layer_results(layer, data)
# #                 continue
# #             results = get_layer_results(layer, results)
# #         return results[0]
# #
# #     def _pass_backward(self, expect, result):
# #         """ Calculate the delta for each neuron. """
# #         deltas = {}
# #
# #         # Output layer delta
# #         deltas[self._neurons[-1][0]] = ((expect - result)
# #                                         * result * (1 - result))
# #
# #         # Hidden layers delta
# #         for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
# #             for neuron_idx, neuron in enumerate(layer):
# #                 deltas[neuron] = (
# #                     # sum of (delta) * (synaptic weight) for each neuron in next layer
# #                         sum(deltas[n] * n.synaptic_weight[neuron_idx]
# #                             for n in self._neurons[layer_idx + 1])
# #                         * neuron.result
# #                         * (1 - neuron.result)
# #                 )
# #         return deltas
# #
# #     def _adjust_synaptic_weights(self, deltas):
# #         """ Adjust weights using per-layer learning rates. """
# #         for layer_idx, layer in enumerate(self._neurons):
# #             layer_learning_rate = self.learning_rates[layer_idx] if layer_idx < len(
# #                 self.learning_rates) else self.initial_learning_rate
# #
# #             for neuron in layer:
# #                 if neuron in deltas:
# #                     self._synaptic_weight_diff[neuron] = (
# #                             self._synaptic_weight_diff[neuron] * self._momentum_weight
# #                             + layer_learning_rate * deltas[neuron] * neuron.data
# #                     )
# #                     neuron.synaptic_weight += self._synaptic_weight_diff[neuron]
# #
# #     def _correct_rate(self, dataset):
# #         if not self._neurons:
# #             return 0
# #         correct_count = 0
# #         for data in dataset:
# #             self._feed_forward(data[:-1])
# #             expect = self._normalize(data[-1])
# #             interval = 1 / (2 * len(self.group_types))
# #             if expect - interval < self._neurons[-1][0].result < expect + interval:
# #                 correct_count += 1
# #         if correct_count == 0:
# #             return 0
# #         return correct_count / len(dataset)
# #
# #     def _normalize(self, value):
# #         """ Normalize expected output. """
# #         return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))
# #
# #
# # def get_layer_results(layer, data):
# #     for neuron in layer:
# #         neuron.data = data
# #     return np.fromiter((neuron.result for neuron in layer), dtype=float)

import collections
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid
from ..utils import sigmoid, sigmoid_derivative


class MlpAlgorithm(PredictiveAlgorithm):
    """Backpropagation prototype with configurable layer sizes, learning rate, and random weight initialization."""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight

        # Allow list or tuple for network shape
        if isinstance(network_shape, list):
            self.network_shape = tuple(network_shape)
        else:
            self.network_shape = network_shape if network_shape else (5, 5)

        # For momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    # -------------------- 核心迭代部分 --------------------
    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]), result)
        self._adjust_synaptic_weights(deltas)

    # -------------------- 初始化网络结构 --------------------
    def _initialize_neurons(self):
        """Build the neuron network and randomly initialize weights within [-1, 1]."""
        self._neurons = []

        # 输入层节点数由样本维度决定
        input_size = len(self.current_data[:-1])
        layer_input_size = input_size

        # 逐层构建网络结构（隐藏层 + 输出层）
        for layer_size in list(self.network_shape) + [1]:
            layer = []
            for _ in range(layer_size):
                neuron = Perceptron(sigmoid)
                # 初始化权值 [-1, 1]
                neuron.synaptic_weight = np.random.uniform(-1, 1, layer_input_size)
                layer.append(neuron)
            self._neurons.append(tuple(layer))
            layer_input_size = layer_size

    # -------------------- 前向传播 --------------------
    def _feed_forward(self, data):
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    # -------------------- 反向传播 --------------------
    def _pass_backward(self, expect, result):
        """Calculate the delta for each neuron."""
        deltas = {}

        # 输出层 delta
        deltas[self._neurons[-1][0]] = ((expect - result)
                                        * sigmoid_derivative(result))

        # 隐藏层 delta
        # 隐藏层 delta
        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                deltas[neuron] = (
                        sum(deltas[n] * n.synaptic_weight[neuron_idx]
                            for n in self._neurons[layer_idx + 1])
                        * sigmoid_derivative(neuron.result)
                )

        return deltas

    # -------------------- 更新权值 --------------------
    def _adjust_synaptic_weights(self, deltas):
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    # -------------------- 正确率计算 --------------------
    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    # -------------------- 归一化函数 --------------------
    def _normalize(self, value):
        min_v = np.amin(self.group_types)
        max_v = np.amax(self.group_types)
        return -1 + 2 * (value - min_v) / (max_v - min_v)


def get_layer_results(layer, data):
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)
