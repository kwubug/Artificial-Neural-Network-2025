#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Hopfield 算法模块的功能测试脚本
用于验证后端和桥接层的正确性
"""

import numpy as np
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from nn_sandbox.backend.algorithms import HopfieldAlgorithm


def test_basic_storage():
    """测试：基本存储功能"""
    print("\n" + "="*60)
    print("测试 1: 基本存储功能")
    print("="*60)
    
    hopfield = HopfieldAlgorithm(num_neurons=20)
    
    # 生成随机模式
    pattern1 = np.random.choice([-1.0, 1.0], size=20)
    pattern2 = np.random.choice([-1.0, 1.0], size=20)
    
    # 存储模式
    hopfield.store_pattern(pattern1)
    hopfield.store_pattern(pattern2)
    
    print(f"✓ 存储了 {len(hopfield._patterns)} 个模式")
    print(f"✓ 权重矩阵形状: {hopfield._weights.shape}")
    print(f"✓ 权重矩阵对角线和: {np.diag(hopfield._weights).sum():.2f} (应为 0)")
    
    assert np.diag(hopfield._weights).sum() == 0, "对角线应该为 0"
    assert len(hopfield._patterns) == 2, "应该存储 2 个模式"
    print("✓ 基本存储测试通过!\n")


def test_energy_calculation():
    """测试：能量计算"""
    print("="*60)
    print("测试 2: 能量计算")
    print("="*60)
    
    hopfield = HopfieldAlgorithm(num_neurons=10)
    pattern = np.ones(10)
    hopfield.store_pattern(pattern)
    hopfield.set_initial_state(pattern)
    
    energy1 = hopfield._energy
    print(f"✓ 初始能量: {energy1:.4f}")
    
    # 翻转一个神经元
    hopfield._current_state[0] *= -1
    energy2 = hopfield._calculate_energy()
    print(f"✓ 翻转后能量: {energy2:.4f}")
    
    assert energy1 <= energy2 or abs(energy1 - energy2) < 0.01, "能量应该单调下降或相等"
    print("✓ 能量计算测试通过!\n")


def test_convergence():
    """测试：收敛检测"""
    print("="*60)
    print("测试 3: 收敛检测")
    print("="*60)
    
    hopfield = HopfieldAlgorithm(num_neurons=30)
    
    # 存储一个模式
    pattern = np.random.choice([-1.0, 1.0], size=30)
    hopfield.store_pattern(pattern)
    
    # 设置为相同的初始状态（应该立即收敛）
    hopfield.set_initial_state(pattern)
    print(f"初始状态设置，收敛状态: {hopfield._converged}")
    
    # 执行一步
    hopfield.step()
    print(f"执行一步后，收敛状态: {hopfield._converged}")
    assert hopfield._converged, "相同状态应该立即收敛"
    print("✓ 收敛检测测试通过!\n")


def test_retrieval():
    """测试：完整检索过程"""
    print("="*60)
    print("测试 4: 完整检索过程")
    print("="*60)
    
    hopfield = HopfieldAlgorithm(num_neurons=50)
    
    # 存储一个模式
    original_pattern = np.random.choice([-1.0, 1.0], size=50)
    hopfield.store_pattern(original_pattern)
    
    # 创建带噪声的模式
    noisy_pattern = original_pattern.copy()
    flip_count = 5
    flip_indices = np.random.choice(50, flip_count, replace=False)
    noisy_pattern[flip_indices] *= -1
    
    print(f"原始模式已存储")
    print(f"噪声比例: {flip_count}/50 = {flip_count/50*100:.1f}%")
    
    # 设置初始状态
    hopfield.set_initial_state(noisy_pattern)
    initial_similarity = hopfield._similarity
    print(f"初始相似度: {initial_similarity:.4f}")
    
    # 执行检索
    hopfield.retrieve(max_iterations=500, update_rule='async')
    
    final_similarity = hopfield._similarity
    print(f"最终相似度: {final_similarity:.4f}")
    print(f"迭代次数: {hopfield._iteration}")
    print(f"收敛: {hopfield._converged}")
    
    assert final_similarity >= initial_similarity, "相似度应该增加"
    print("✓ 检索过程测试通过!\n")


def test_capacity():
    """测试：网络容量计算"""
    print("="*60)
    print("测试 5: 网络容量计算")
    print("="*60)
    
    for num_neurons in [10, 50, 100, 200]:
        hopfield = HopfieldAlgorithm(num_neurons=num_neurons)
        capacity = hopfield.calculate_capacity()
        print(f"✓ {num_neurons} 个神经元 → 容量: {capacity}")
    
    print("✓ 容量计算测试通过!\n")


def test_noise_robustness():
    """测试：噪声鲁棒性"""
    print("="*60)
    print("测试 6: 噪声鲁棒性")
    print("="*60)
    
    hopfield = HopfieldAlgorithm(num_neurons=100)
    
    # 存储多个模式
    patterns = []
    for _ in range(3):
        p = np.random.choice([-1.0, 1.0], size=100)
        patterns.append(p)
        hopfield.store_pattern(p)
    
    print(f"存储了 {len(patterns)} 个模式")
    
    # 测试不同噪声等级
    noise_levels = [0.1, 0.2, 0.3]
    success_count = 0
    
    for noise_level in noise_levels:
        # 使用第一个模式
        pattern_idx = 0
        noisy_pattern = patterns[pattern_idx].copy()
        
        # 添加噪声
        num_flips = int(100 * noise_level)
        flip_indices = np.random.choice(100, num_flips, replace=False)
        noisy_pattern[flip_indices] *= -1
        
        # 检索
        hopfield.set_initial_state(noisy_pattern)
        hopfield.retrieve(max_iterations=500, update_rule='async')
        
        success = hopfield._converged and hopfield._similarity > 0.9
        success_count += success
        
        status = "✓ 成功" if success else "✗ 失败"
        print(f"  噪声 {noise_level*100:.0f}%: {status} (相似度: {hopfield._similarity:.3f})")
    
    print(f"成功率: {success_count}/{len(noise_levels)}")
    print("✓ 噪声鲁棒性测试完成!\n")


def main():
    """运行所有测试"""
    print("\n" + "█"*60)
    print("█" + " "*58 + "█")
    print("█" + " "*15 + "Hopfield 算法模块测试套件" + " "*17 + "█")
    print("█" + " "*58 + "█")
    print("█"*60)
    
    try:
        test_basic_storage()
        test_energy_calculation()
        test_convergence()
        test_retrieval()
        test_capacity()
        test_noise_robustness()
        
        print("█"*60)
        print("█" + " "*58 + "█")
        print("█" + " "*20 + "✓ 所有测试通过！" + " "*21 + "█")
        print("█" + " "*58 + "█")
        print("█"*60 + "\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n✗ 测试失败: {e}\n")
        return 1
    except Exception as e:
        print(f"\n✗ 发生错误: {e}\n")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
