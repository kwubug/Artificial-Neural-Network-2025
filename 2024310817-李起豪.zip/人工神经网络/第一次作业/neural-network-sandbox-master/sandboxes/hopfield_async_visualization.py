"""
利用沙箱可视化离散型Hopfield神经网络的异步更新、吸引子与能量变化。

脚本功能：
1. 构造包含若干记忆图案的Hopfield网络；
2. 对多个随机扰动初态进行异步更新，记录能量曲线和收敛吸引子；
3. 绘制状态演化热图、能量走势以及吸引子分布条形图；
4. 保存图像和文字摘要，方便作业汇报。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np


np.random.seed(24)
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial"]
plt.rcParams["axes.unicode_minus"] = False


@dataclass(frozen=True)
class HopfieldConfig:
    pattern_shape: Tuple[int, int] = (3, 3)
    noise_ratio: float = 0.2
    runs: int = 6
    max_iterations: int = 40


def build_patterns() -> np.ndarray:
    """定义需要记忆的二值图案（使用±1表示）。"""
    pattern_a = np.array([[1, -1, -1], [1, 1, -1], [1, -1, -1]])
    pattern_b = np.array([[-1, 1, -1], [1, -1, 1], [-1, 1, -1]])
    pattern_c = np.array([[1, 1, 1], [1, -1, 1], [1, 1, 1]])
    patterns = np.stack([pattern_a, pattern_b, pattern_c], axis=0)
    return patterns.reshape(patterns.shape[0], -1)


def hebbian_weights(patterns: np.ndarray) -> np.ndarray:
    n = patterns.shape[1]
    w = np.zeros((n, n), dtype=np.float64)
    for pattern in patterns:
        w += np.outer(pattern, pattern)
    w /= patterns.shape[0]
    np.fill_diagonal(w, 0.0)
    return w


def energy(state: np.ndarray, weights: np.ndarray) -> float:
    return -0.5 * state @ weights @ state


def add_noise(pattern: np.ndarray, noise_ratio: float) -> np.ndarray:
    noisy = pattern.copy()
    n_flip = max(1, int(noise_ratio * noisy.size))
    flip_indices = np.random.choice(noisy.size, size=n_flip, replace=False)
    noisy[flip_indices] *= -1
    return noisy


def asynchronous_update(
    state: np.ndarray,
    weights: np.ndarray,
    max_iterations: int,
) -> Tuple[np.ndarray, List[np.ndarray], List[float]]:
    current = state.copy()
    states = [current.copy()]
    energies = [energy(current, weights)]
    n = current.size
    for _ in range(max_iterations):
        idx = np.random.randint(0, n)
        current[idx] = 1 if (weights[idx] @ current) >= 0 else -1
        states.append(current.copy())
        energies.append(energy(current, weights))
        if np.all(states[-1] == states[-2]):
            break
    return current, states, energies


def to_grid(state: np.ndarray, shape: Tuple[int, int]) -> np.ndarray:
    return state.reshape(shape)


def plot_results(
    all_states: List[List[np.ndarray]],
    all_energies: List[List[float]],
    final_counts: Dict[str, int],
    config: HopfieldConfig,
    output_path: Path,
) -> None:
    """绘制状态热图、能量曲线与吸引子统计。"""
    rows = len(all_states)
    fig = plt.figure(figsize=(12, 3 + 1.4 * rows))
    gs = fig.add_gridspec(
        nrows=rows,
        ncols=2,
        width_ratios=[1.4, 1.0],
        hspace=0.4,
        wspace=0.3,
    )

    for idx, (state_seq, energy_seq) in enumerate(zip(all_states, all_energies)):
        ax_state = fig.add_subplot(gs[idx, 0])
        states_matrix = np.stack([to_grid(s, config.pattern_shape) for s in state_seq])
        im = ax_state.imshow(
            states_matrix.reshape(len(state_seq), -1),
            aspect="auto",
            cmap="coolwarm",
            vmin=-1,
            vmax=1,
        )
        ax_state.set_title(f"第 {idx + 1} 次运行的状态演化")
        ax_state.set_xlabel("神经元索引")
        ax_state.set_ylabel("异步迭代步")
        ax_state.set_yticks(range(len(state_seq)))

        ax_energy = fig.add_subplot(gs[idx, 1])
        ax_energy.plot(range(len(energy_seq)), energy_seq, color="tab:blue", linewidth=1.2)
        ax_energy.set_title("能量变化")
        ax_energy.set_xlabel("迭代步")
        ax_energy.set_ylabel("能量")
        ax_energy.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)

    ax_color = fig.add_axes([0.15, 0.08, 0.3, 0.02])
    fig.colorbar(im, cax=ax_color, orientation="horizontal", label="神经元状态 (±1)")

    fig2, ax_bar = plt.subplots(figsize=(6, 4))
    attractor_labels = list(final_counts.keys())
    attractor_values = [final_counts[label] for label in attractor_labels]
    ax_bar.bar(np.arange(len(attractor_labels)), attractor_values, color="tab:green")
    ax_bar.set_xticks(np.arange(len(attractor_labels)))
    ax_bar.set_xticklabels(attractor_labels)
    ax_bar.set_xlabel("吸引子（按图案编号）")
    ax_bar.set_ylabel("收敛次数")
    ax_bar.set_title("吸引子统计")
    ax_bar.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.5)

    handles, labels = [], []
    for ax in (*fig.axes, ax_bar):
        h, l = ax.get_legend_handles_labels()
        handles.extend(h)
        labels.extend(l)
    if handles:
        fig.legend(
            handles,
            labels,
            loc="center right",
            bbox_to_anchor=(1.03, 0.5),
            frameon=False,
        )

    fig.tight_layout(rect=(0, 0.08, 0.92, 1))
    fig2.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path.with_name("hopfield_async_dynamics.png"), dpi=300, bbox_inches="tight")
    fig2.savefig(output_path.with_name("hopfield_attractor_hist.png"), dpi=300, bbox_inches="tight")
    plt.close(fig)
    plt.close(fig2)


def export_summary(
    summary_path: Path,
    final_counts: Dict[str, int],
    all_energies: List[List[float]],
) -> None:
    lines = [
        "Hopfield异步更新结果摘要",
        f"运行次数: {sum(final_counts.values())}",
        "吸引子统计:",
    ]
    for name, count in final_counts.items():
        lines.append(f"  {name}: {count} 次")
    min_energy = min(min(energies) for energies in all_energies)
    max_energy = max(max(energies) for energies in all_energies)
    lines.append(f"能量范围: [{min_energy:.3f}, {max_energy:.3f}]")
    summary_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    config = HopfieldConfig()
    patterns = build_patterns()
    weights = hebbian_weights(patterns)

    all_states: List[List[np.ndarray]] = []
    all_energies: List[List[float]] = []
    final_counts: Dict[str, int] = {f"图案{idx + 1}": 0 for idx in range(patterns.shape[0])}

    for run_idx in range(config.runs):
        pattern_idx = run_idx % patterns.shape[0]
        initial = add_noise(patterns[pattern_idx], config.noise_ratio)
        final_state, states, energies = asynchronous_update(
            state=initial,
            weights=weights,
            max_iterations=config.max_iterations,
        )
        all_states.append(states)
        all_energies.append(energies)

        similarities = patterns @ final_state
        winner = int(np.argmax(similarities))
        final_counts[f"图案{winner + 1}"] += 1

    output_dir = Path(__file__).parent
    plot_results(
        all_states=all_states,
        all_energies=all_energies,
        final_counts=final_counts,
        config=config,
        output_path=output_dir / "hopfield_async_dynamics.png",
    )
    export_summary(
        summary_path=output_dir / "hopfield_summary.txt",
        final_counts=final_counts,
        all_energies=all_energies,
    )


if __name__ == "__main__":
    main()


