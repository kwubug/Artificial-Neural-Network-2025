# Hopfield 神经网络模块使用文档

## 概述

本文档说明如何在 Neural Network Sandbox 中使用新添加的 Hopfield 神经网络模块。

## 项目结构

```
nn_sandbox/
├── backend/
│   └── algorithms/
│       └── hopfield_algorithm.py       # Hopfield 算法实现
├── bridges/
│   └── hopfield_bridge.py              # Hopfield 前后端桥接
└── frontend/
    └── components/
        └── dashboards/
            └── Hopfield.qml            # Hopfield UI 界面
```

## 后端实现 - HopfieldAlgorithm

### 主要功能

**HopfieldAlgorithm** 类提供以下功能：

- **store_pattern()** - 使用 Hebb 规则存储模式
- **set_initial_state()** - 设置初始状态（通常是带噪声的模式）
- **step()** - 执行单步更新（同步或异步）
- **retrieve()** - 完整检索过程
- **add_noise()** - 向当前状态添加噪声
- **calculate_capacity()** - 计算网络理论容量

### 关键属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `_weights` | numpy.ndarray | 权重矩阵（N×N） |
| `_patterns` | list | 存储的所有模式 |
| `_current_state` | numpy.ndarray | 当前网络状态 |
| `_energy` | float | 网络能量 |
| `_iteration` | int | 当前迭代次数 |
| `_converged` | bool | 是否收敛 |
| `_similarity` | float | 与存储模式的相似度 |

### 使用示例

```python
from nn_sandbox.backend.algorithms import HopfieldAlgorithm
import numpy as np

# 创建 100 个神经元的 Hopfield 网络
hopfield = HopfieldAlgorithm(num_neurons=100)

# 生成并存储随机模式
pattern1 = np.random.choice([-1.0, 1.0], size=100)
pattern2 = np.random.choice([-1.0, 1.0], size=100)
hopfield.store_pattern(pattern1)
hopfield.store_pattern(pattern2)

# 创建带噪声的模式
noisy_pattern = pattern1.copy()
noisy_pattern[:10] *= -1  # 翻转 10 个神经元

# 设置初始状态并检索
hopfield.set_initial_state(noisy_pattern)
hopfield.retrieve(max_iterations=1000, update_rule='async')

print(f"Energy: {hopfield._energy}")
print(f"Converged: {hopfield._converged}")
print(f"Similarity: {hopfield._similarity}")
```

## 桥接层 - HopfieldBridge

### PyQt Slots（可从 QML 调用）

| 方法 | 参数 | 说明 |
|------|------|------|
| `store_pattern(list)` | pattern | 存储一个模式 |
| `generate_random_pattern()` | - | 生成随机模式 |
| `clear_patterns()` | - | 清空所有模式 |
| `set_initial_state(list)` | state | 设置初始状态 |
| `create_noisy_pattern(int, float)` | pattern_idx, noise_rate | 创建带噪声的模式 |
| `step(str)` | update_rule | 单步更新 |
| `retrieve(int, str)` | max_iterations, update_rule | 完整检索 |
| `add_noise(float)` | noise_rate | 添加噪声 |

### Bridge 属性（绑定到 QML）

| 属性 | 类型 | 说明 |
|------|------|------|
| `energy` | float | 网络能量值 |
| `iteration` | int | 当前迭代次数 |
| `converged` | bool | 是否收敛 |
| `similarity` | float | 与存储模式的相似度 |
| `current_state` | list | 当前状态向量 |
| `patterns` | list | 所有存储的模式 |
| `pattern_count` | int | 存储的模式数 |
| `num_neurons` | int | 神经元数量 |

## 前端 - Hopfield.qml

### UI 组件

#### 1. 模式管理区
- 显示已存储模式数
- 显示网络容量
- 存储随机模式按钮
- 清空所有模式按钮

#### 2. 检索配置区
- 选择要检索的模式
- 调整噪声等级（0% - 100%）
- 选择更新规则（Async / Sync）
- 设置最大迭代次数

#### 3. 控制按钮
- **Create Noisy Pattern** - 创建带噪声的模式
- **Single Step** - 执行单步更新
- **Retrieve** - 执行完整检索过程

#### 4. 实时状态显示
- Energy 值
- 迭代次数
- 收敛状态
- 与存储模式的相似度
- 运行状态

#### 5. 状态可视化
- 网络状态矩阵（蓝色表示 +1，橙色表示 -1）

## 工作流示例

### 基础工作流

```
1. 存储模式
   └─ 点击 "Store Random Pattern" 多次
   └─ 或手动创建模式并存储

2. 创建测试样本
   └─ 从 "Select Pattern" 选择一个模式
   └─ 调整 "Noise Level" 到 10-30%
   └─ 点击 "Create Noisy Pattern"
   └─ 在可视化中看到带噪声的状态

3. 检索
   └─ 选择更新规则（通常使用 Async）
   └─ 设置最大迭代次数
   └─ 点击 "Retrieve"
   └─ 观察 Energy 下降和 Similarity 上升
   └─ 等待 Converged 变为 Yes

4. 结果分析
   └─ 查看 Energy、Iteration、Similarity 值
   └─ 检查网络是否成功恢复原始模式
```

### 高级用法

**逐步检索**：
1. 存储 1-2 个模式
2. 创建带噪声的模式
3. 使用 "Single Step" 逐步查看网络演化
4. 观察每步的 Energy 和 Similarity 变化

**网络容量测试**：
1. 记下 "Network Capacity" 值
2. 存储等于或接近容量的模式数
3. 创建带适度噪声的模式并尝试检索
4. 观察错误率变化

## 参数说明

### 神经元数量
- **默认值**：100
- **说明**：影响网络容量和计算复杂度
- **建议范围**：50-500

### 噪声等级
- **范围**：0% - 100%
- **含义**：翻转的神经元比例
- **建议值**：10% - 30%（适度噪声）

### 最大迭代次数
- **默认值**：1000
- **含义**：防止无限循环的上限
- **建议值**：500-2000

### 更新规则
- **Async** - 异步更新，神经元依次更新（推荐）
- **Sync** - 同步更新，所有神经元同时更新

## 前后端交互机制

```
QML 前端
    ↓ [存储模式]
HopfieldBridge.store_pattern()
    ↓ [转发请求]
HopfieldAlgorithm.store_pattern()
    ↓ [Hebb 学习规则更新权重]
权重矩阵 (W)
    
QML 前端
    ↓ [设置初始状态]
HopfieldBridge.set_initial_state()
    ↓
HopfieldAlgorithm.set_initial_state()
    ↓ [初始化状态和历史]
当前状态

QML 前端
    ↓ [执行检索]
HopfieldBridge.retrieve()
    ↓
HopfieldAlgorithm.retrieve()
    ↓ [循环调用 step()]
    ├─ 计算神经元输入
    ├─ 更新神经元状态
    ├─ 计算能量 E
    ├─ 检查收敛
    └─ 触发观察者更新
    
Bridge 属性更新
    ↓
QML 自动刷新 UI
```

## 常见问题

### Q1: 如何看到网络学习效果？
**A**：使用 "Single Step" 逐步检索，观察：
- Energy 值逐步下降
- Similarity 值逐步上升
- 可视化中的状态逐步恢复到存储模式

### Q2: 为什么检索失败（不收敛）？
**A**：可能原因：
1. 存储了太多模式（超过网络容量）
2. 噪声等级过高
3. 最大迭代次数不足
   
**解决方法**：
- 减少存储的模式数
- 降低噪声等级
- 增加最大迭代次数
- 使用 Async 更新规则

### Q3: Sync 和 Async 更新的区别？
**A**：
- **Async**（异步）：更接近生物神经网络，收敛通常更慢但更稳定
- **Sync**（同步）：更新速度快，但可能陷入周期吸引子

推荐使用 **Async**。

### Q4: 网络容量是如何计算的？
**A**：理论容量 ≈ N / (2 × ln(N))，其中 N 是神经元数量
- 100 个神经元 ≈ 6-7 个模式
- 200 个神经元 ≈ 13-15 个模式

实际容量会因为模式相似性而略有不同。

## 性能优化建议

1. **减少神经元数量**（如无特殊需求）
2. **使用 Async 更新**（比 Sync 收敛快）
3. **合理设置最大迭代次数**
4. **避免存储相似的模式**

## 扩展建议

未来可能的改进：
- [ ] 支持 Continuous Hopfield（连续版本）
- [ ] 支持自适应的噪声添加
- [ ] 能量曲线的实时绘制
- [ ] 模式的自定义输入（非随机）
- [ ] 批量存储和检索多个模式
- [ ] 导出/导入模式和权重矩阵

## 参考资源

- Hopfield 网络论文：Hopfield, J. J. (1982). "Neural networks and physical systems with emergent collective computational abilities"
- 相关课程：Neural Networks, Chapter 7 - Associative Memory

---

**作者**：Neural Network Sandbox Project  
**最后更新**：2025 年 11 月
