from PyQt5.QtCore import pyqtSignal, QThread, pyqtProperty, pyqtSlot, QVariant
import numpy as np


class LVQBridge(QThread):
    # 定义信号
    classifyResult = pyqtSignal(int)  # 分类结果信号，发送分类的类别索引
    weightsUpdated = pyqtSignal()  # 权重更新信号
    trainingComplete = pyqtSignal()  # 训练完成信号

    inputSizeChanged = pyqtSignal()
    numClassesChanged = pyqtSignal()
    classificationChanged = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.input_size = 3  # 输入样本大小
        self.num_classes = 3  # 分类数
        self.learning_rate = 0.1
        self.epochs = 100
        self.weights = np.zeros((self.num_classes, self.input_size))
        self._classification = 0
        self.inputs = None
        self.labels = None
        self.initialize_weights()

    # 属性：输入大小
    @pyqtProperty(int, notify=inputSizeChanged)
    def inputSize(self):
        return self.input_size

    # 属性：分类数
    @pyqtProperty(int, notify=numClassesChanged)
    def numClasses(self):
        return self.num_classes

    # 获取权重列表并转换为 QVariantList 格式
    @pyqtProperty(QVariant, notify=weightsUpdated)
    def weightsList(self):
        return [QVariant([float(w) for w in weight_row]) for weight_row in self.weights.tolist()]

    # 分类结果
    @pyqtProperty(int, notify=classificationChanged)
    def classification(self):
        return self._classification

    @classification.setter
    def classification(self, value):
        if self._classification != value:
            self._classification = value
            self.classificationChanged.emit()

    def initialize_weights(self):
        """初始化权重"""
        class1 = np.array([[-1, 1, -1], [1, -1, -1]])
        class2 = np.array([[-1, -1, 1], [1, -1, 1], [1, 1, -1]])
        class3 = np.array([[-1, -1, -1], [-1, 1, 1]])
        self.weights[0] = np.mean(class1, axis=0)
        self.weights[1] = np.mean(class2, axis=0)
        self.weights[2] = np.mean(class3, axis=0)
        self.weightsUpdated.emit()

    @pyqtSlot(list)
    def classifySample(self, sample):
        """对输入样本进行分类"""
        sample = np.array(sample)
        distances = np.linalg.norm(self.weights - sample, axis=1)
        self.classification = int(np.argmin(distances))

    @pyqtSlot()
    def startTraining(self):
        """开始训练"""
        self.setTrainingData()
        if self.inputs is None or self.labels is None:
            print("训练数据未初始化")
            return

        # 调用训练函数
        self.train(self.inputs, self.labels, learning_rate=self.learning_rate, epochs=self.epochs)
        self.trainingComplete.emit()
        self.weightsUpdated.emit()
        print("训练完成")

    def train(self, inputs, labels, learning_rate=0.1, epochs=10):
        """训练函数"""
        for epoch in range(epochs):
            for input_vector, label in zip(inputs, labels):
                distances = np.linalg.norm(self.weights - input_vector, axis=1)
                winner_index = np.argmin(distances)

                # 更新权重
                if winner_index == label:
                    self.weights[winner_index] += learning_rate * (input_vector - self.weights[winner_index])
                else:
                    self.weights[winner_index] -= learning_rate * (input_vector - self.weights[winner_index])

                # 权重归一化
                norm = np.linalg.norm(self.weights[winner_index])
                if norm != 0:  # 避免除以0
                    self.weights[winner_index] /= norm

    @pyqtSlot(list, list)
    def setTrainingData(self):
        """设置训练数据"""
        class1 = np.array([[-1, 1, -1], [1, -1, -1]])
        class2 = np.array([[-1, -1, 1], [1, -1, 1], [1, 1, -1]])
        class3 = np.array([[-1, -1, -1], [-1, 1, 1]])

        self.inputs = np.vstack((class1, class2, class3))
        self.labels = np.array([0] * len(class1) + [1] * len(class2) + [2] * len(class3))
        # self.inputs = np.array(inputs)
        # self.labels = np.array(labels)

    def run(self):
        self.startTraining()