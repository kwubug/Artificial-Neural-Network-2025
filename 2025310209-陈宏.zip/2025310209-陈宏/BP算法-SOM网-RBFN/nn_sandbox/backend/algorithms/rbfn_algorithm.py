from . import PredictiveAlgorithm
from .k_means import KMeans
from ..neurons import RbfNeuron
import numpy as np


class RbfnAlgorithm(PredictiveAlgorithm):
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 acceptable_range=0.5, initial_learning_rate=0.8,
                 search_iteration_constant=10000, cluster_count=3,
                 test_ratio=0.3,
                 # 新增简单参数
                 adjust_centers=True,
                 adjust_widths=True,
                 width_scale=1.0,
                 use_momentum=False):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.acceptable_range = acceptable_range
        self.cluster_count = cluster_count
        self.adjust_centers = adjust_centers
        self.adjust_widths = adjust_widths
        self.width_scale = width_scale
        self.use_momentum = use_momentum
        self.previous_weight_diffs = []  # 用于动量

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        self._adjust_neurons(result)

    def _initialize_neurons(self):
        # 修改1：调整宽度计算
        clusters = KMeans(self.cluster_count).fit(self.training_dataset)
        self._neurons = []
        for cluster in clusters:
            # 使用可调节的宽度缩放
            width = cluster.avg_distance * self.width_scale
            self._neurons.append(RbfNeuron(cluster.center, width))
        self._neurons.insert(0, RbfNeuron(is_threshold=True))

        if self.use_momentum:
            self.previous_weight_diffs = [0] * len(self._neurons)

    def _feed_forward(self, data):
        for neuron in self._neurons:
            neuron.data = data
        return sum(neuron.result for neuron in self._neurons)

    def _adjust_neurons(self, output):
        expect = self.current_data[-1]
        for i, neuron in enumerate(self._neurons):
            new_synaptic_weight_diff = self._get_synaptic_weight_diff(
                output, expect, neuron
            )

            # 修改2：添加动量项
            if self.use_momentum:
                momentum = 0.9  # 动量系数
                new_synaptic_weight_diff += momentum * self.previous_weight_diffs[i]
                self.previous_weight_diffs[i] = new_synaptic_weight_diff

            # 修改3：条件性调整中心和宽度
            if not neuron.is_threshold and neuron.standard_deviation != 0:
                data_mean_diff = neuron.data - neuron.mean

                if self.adjust_centers:
                    new_mean = (neuron.mean
                                + new_synaptic_weight_diff
                                * neuron.synaptic_weight
                                * data_mean_diff
                                / neuron.standard_deviation ** 2)
                    neuron.mean = new_mean

                if self.adjust_widths:
                    new_standard_deviation = (neuron.standard_deviation
                                              + new_synaptic_weight_diff
                                              * neuron.synaptic_weight
                                              * data_mean_diff.dot(data_mean_diff)
                                              / neuron.standard_deviation ** 3)
                    # 防止宽度过小
                    neuron.standard_deviation = max(new_standard_deviation, 0.001)

            neuron.synaptic_weight += new_synaptic_weight_diff

    def _get_synaptic_weight_diff(self, output, expect, neuron):
        if neuron.is_threshold:
            return self.current_learning_rate * (expect - output)

        # 修改4：添加简单的激活函数缩放
        activation = neuron.activation_function(
            neuron.data, neuron.mean, neuron.standard_deviation
        )
        return self.current_learning_rate * (expect - output) * activation

    def _correct_rate(self, dataset):
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            # 修改5：可调节的容错范围
            if abs(data[-1] - result) <= self.acceptable_range:
                correct_count += 1
        return correct_count / len(dataset) if len(dataset) > 0 else 0


# 简单的变体类
class SimpleRbfnAlgorithm(RbfnAlgorithm):
    """只调整权重的简化版本"""

    def __init__(self, dataset, cluster_count=3, **kwargs):
        super().__init__(dataset, cluster_count=cluster_count,
                         adjust_centers=False, adjust_widths=False, **kwargs)


class AdaptiveRbfnAlgorithm(RbfnAlgorithm):
    """自适应调整参数的版本"""

    def __init__(self, dataset, **kwargs):
        super().__init__(dataset, **kwargs)

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        error = abs(self.current_data[-1] - result)

        # 根据误差大小动态调整学习率
        if error > 1.0:
            self.current_learning_rate = min(1.0, self._initial_learning_rate * 2)
        else:
            self.current_learning_rate = max(0.01, self._initial_learning_rate * 0.5)

        self._adjust_neurons(result)