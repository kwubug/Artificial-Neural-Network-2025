import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'OLS'
    RowLayout {
        ColumnLayout {
            Layout.preferredWidth: 300
            GroupBox {
                title: '数据集'
                Layout.fillWidth: true
                ComboBox {
                    id: datasetCombobox
                    anchors.fill: parent
                    model: Object.keys(olsBridge.dataset_dict)
                    enabled: olsBridge && olsBridge.has_finished
                    onActivated: () => {
                        olsBridge.current_dataset_name = currentText
                        const dataset = olsBridge.dataset_dict[datasetCombobox.currentText]
                        if (dataset && dataset.length > 0) {
                            // 将数据转换为散点图格式 [x, y, class]
                            const scatterData = dataset.map(point => [point[0], point[1], 0])
                            dataChart.updateDataset(scatterData)
                        }
                    }
                    Component.onCompleted: () => {
                        olsBridge.current_dataset_name = currentText
                        const dataset = olsBridge.dataset_dict[datasetCombobox.currentText]
                        if (dataset && dataset.length > 0) {
                            // 将数据转换为散点图格式 [x, y, class]
                            const scatterData = dataset.map(point => [point[0], point[1], 0])
                            dataChart.updateDataset(scatterData)
                        }
                    }
                }
            }
            GroupBox {
                title: '设置'
                Layout.fillWidth: true
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    Label {
                        text: '测试-训练比例'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: olsBridge && olsBridge.has_finished
                        editable: true
                        value: 0.3 * 100
                        from: 30
                        to: 90
                        onValueChanged: olsBridge.test_ratio = value / 100
                        Component.onCompleted: olsBridge.test_ratio = value / 100
                        Layout.fillWidth: true
                    }
                    Label {
                        text: '界面刷新间隔'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: olsBridge && olsBridge.has_finished
                        editable: true
                        value: 0.1 * 100
                        from: 0 * 100
                        to: 5 * 100
                        onValueChanged: olsBridge.ui_refresh_interval = value / 100
                        Component.onCompleted: olsBridge.ui_refresh_interval = value / 100
                        Layout.fillWidth: true
                    }
                }
            }
            GroupBox {
                title: '信息'
                Layout.fillWidth: true
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    Label {
                        text: '斜率 (a)'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.slope.toFixed(4) : "0.0000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label {
                        text: '截距 (b)'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.intercept.toFixed(4) : "0.0000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label {
                        text: 'R² 决定系数'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.r_squared.toFixed(4) : "0.0000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label {
                        text: '均方误差 (MSE)'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.mse.toFixed(6) : "0.000000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label {
                        text: '训练集正确率'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.current_correct_rate.toFixed(4) : "0.0000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label {
                        text: '测试集正确率'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: olsBridge ? olsBridge.test_correct_rate.toFixed(4) : "0.0000"
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                }
            }
            ExecutionControls {
                startButton.enabled: olsBridge && olsBridge.has_finished
                startButton.onClicked: () => {
                    dataChart.clear()
                    // 在算法开始前先显示数据点
                    const dataset = olsBridge.dataset_dict[datasetCombobox.currentText]
                    if (dataset && dataset.length > 0) {
                        // 将数据转换为散点图格式 [x, y, class]
                        const scatterData = dataset.map(point => [point[0], point[1], 0])
                        dataChart.updateDataset(scatterData)
                    }
                    olsBridge.start_ols_algorithm()
                }
                stopButton.enabled: olsBridge && !olsBridge.has_finished
                stopButton.onClicked: olsBridge.stop_ols_algorithm()
                progressBar.value: olsBridge && olsBridge.training_dataset ? (olsBridge.current_iterations + 1) / (olsBridge.training_dataset.length) : 0
                Layout.fillWidth: true
            }
        }
        ColumnLayout {
            Layout.fillWidth: true
            DataChart {
                id: dataChart
                property var fittedLineSeries: null

                width: 700
                Layout.fillWidth: true
                Layout.fillHeight: true

                function updateFittedLine() {
                    // 创建或更新拟合直线
                    if (!fittedLineSeries) {
                        fittedLineSeries = createSeries(
                            ChartView.SeriesTypeLine, 'OLS拟合直线',
                            xAxis, yAxis
                        )
                        fittedLineSeries.color = '#FF6B6B'
                        fittedLineSeries.width = 3
                        fittedLineSeries.useOpenGL = true
                    }
                    
                    // 更新拟合直线数据
                    if (olsBridge && olsBridge.fitted_line && olsBridge.fitted_line.length > 0) {
                        console.log("Updating fitted line with", olsBridge.fitted_line.length, "points")
                        fittedLineSeries.clear()
                        
                        // 先收集所有点，用于调整坐标轴范围
                        let xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity
                        const validPoints = []
                        
                        for (let i = 0; i < olsBridge.fitted_line.length; i++) {
                            const point = olsBridge.fitted_line[i]
                            if (point && (Array.isArray(point) ? point.length >= 2 : true)) {
                                const x = Array.isArray(point) ? point[0] : point.x
                                const y = Array.isArray(point) ? point[1] : point.y
                                if (typeof x === 'number' && typeof y === 'number' && !isNaN(x) && !isNaN(y)) {
                                    validPoints.push({x: x, y: y})
                                    xMin = Math.min(xMin, x)
                                    xMax = Math.max(xMax, x)
                                    yMin = Math.min(yMin, y)
                                    yMax = Math.max(yMax, y)
                                }
                            }
                        }
                        
                        // 调整坐标轴范围以包含拟合直线
                        if (validPoints.length > 0) {
                            const xRange = xMax - xMin
                            const yRange = yMax - yMin
                            const xPadding = Math.max(xRange * 0.1, 0.1)
                            const yPadding = Math.max(yRange * 0.1, 0.1)
                            
                            // 如果坐标轴范围太小，扩展它
                            if (xAxis.max - xAxis.min < xRange + xPadding * 2) {
                                xAxis.min = xMin - xPadding
                                xAxis.max = xMax + xPadding
                            }
                            if (yAxis.max - yAxis.min < yRange + yPadding * 2) {
                                yAxis.min = yMin - yPadding
                                yAxis.max = yMax + yPadding
                            }
                            
                            // 添加所有点
                            for (let point of validPoints) {
                                fittedLineSeries.append(point.x, point.y)
                            }
                            
                            console.log("Fitted line series count:", fittedLineSeries.count)
                            console.log("X range:", xAxis.min, "to", xAxis.max)
                            console.log("Y range:", yAxis.min, "to", yAxis.max)
                            console.log("First point:", validPoints[0].x, validPoints[0].y)
                            console.log("Last point:", validPoints[validPoints.length - 1].x, validPoints[validPoints.length - 1].y)
                        } else {
                            console.log("No valid points found")
                        }
                    } else {
                        console.log("No fitted line data available")
                    }
                }

                // XXX: sadly, QML does not have `super` access to the base class. Thus,
                // we cannot call super method in overridden methods.
                // Further details: https://bugreports.qt.io/browse/QTBUG-25942
                function clear() {
                    removeAllSeries()
                    scatterSeriesMap = {}
                    if (fittedLineSeries) {
                        removeSeries(fittedLineSeries)
                        fittedLineSeries = null
                    }
                }
            }
        }
    }

    Connections {
        target: olsBridge
        function onFitted_lineChanged() {
            console.log("Fitted line changed, length:", olsBridge.fitted_line ? olsBridge.fitted_line.length : 0)
            dataChart.updateFittedLine()
        }
        function onSlopeChanged() {
            // 当斜率改变时，也更新拟合直线
            dataChart.updateFittedLine()
        }
        function onInterceptChanged() {
            // 当截距改变时，也更新拟合直线
            dataChart.updateFittedLine()
        }
        function onHas_finishedChanged() {
            if (olsBridge.has_finished) {
                // 算法完成后，确保拟合直线显示
                console.log("Algorithm finished, updating fitted line")
                dataChart.updateFittedLine()
            }
        }
        function onTraining_datasetChanged() {
            if (olsBridge.training_dataset && olsBridge.training_dataset.length > 0) {
                const scatterData = olsBridge.training_dataset.map(point => [point[0], point[1], 0])
                dataChart.updateTrainingDataset(scatterData)
            }
        }
        function onTesting_datasetChanged() {
            if (olsBridge.testing_dataset && olsBridge.testing_dataset.length > 0) {
                const scatterData = olsBridge.testing_dataset.map(point => [point[0], point[1], 1])
                dataChart.updateTestingDataset(scatterData)
            }
        }
    }
}

