import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import random
import math
from itertools import combinations

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]



class TSPProblem:
    def __init__(self, num_cities=10, cities=None, seed=None):
        """初始化TSP问题

        Args:
            num_cities: 城市数量
            cities: 可选，城市坐标列表，如果提供则忽略num_cities
            seed: 随机种子，用于重现结果
        """
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        if cities is not None:
            self.cities = np.array(cities)
            self.num_cities = len(cities)
        else:
            self.num_cities = num_cities
            # 随机生成城市坐标，范围在(0, 100)之间
            self.cities = np.random.rand(num_cities, 2) * 100

        # 计算距离矩阵
        self.distance_matrix = self._calculate_distance_matrix()

        # 存储结果
        self.best_path = None
        self.best_distance = float('inf')

    def _calculate_distance_matrix(self):
        """计算城市之间的距离矩阵"""
        num = self.num_cities
        dist_matrix = np.zeros((num, num))

        for i in range(num):
            for j in range(num):
                if i != j:
                    dist_matrix[i][j] = np.linalg.norm(self.cities[i] - self.cities[j])

        return dist_matrix

    def calculate_path_distance(self, path):
        """计算给定路径的总距离"""
        distance = 0
        num = len(path)

        for i in range(num):
            city1 = path[i]
            city2 = path[(i + 1) % num]
            distance += self.distance_matrix[city1][city2]

        return distance

    def greedy_algorithm(self, start_city=0):
        """使用贪心算法求解TSP问题"""
        visited = [False] * self.num_cities
        path = [start_city]
        visited[start_city] = True

        current_city = start_city

        # 访问所有城市
        for _ in range(self.num_cities - 1):
            min_distance = float('inf')
            next_city = -1

            # 找到最近的未访问城市
            for city in range(self.num_cities):
                if not visited[city] and self.distance_matrix[current_city][city] < min_distance:
                    min_distance = self.distance_matrix[current_city][city]
                    next_city = city

            path.append(next_city)
            visited[next_city] = True
            current_city = next_city

        # 计算总距离
        total_distance = self.calculate_path_distance(path)

        # 更新最优解
        self.best_path = path
        self.best_distance = total_distance

        return path, total_distance

    def genetic_algorithm(self, pop_size=100, generations=500, mutation_rate=0.01):
        """使用遗传算法求解TSP问题"""
        # 初始化种群
        population = self._initialize_population(pop_size)
        best_distance = float('inf')
        best_path = None

        # 存储每代的最优解用于可视化
        history = []

        for gen in range(generations):
            # 计算适应度
            fitness = self._calculate_fitness(population)

            # 找到当代最优解
            current_best_idx = np.argmax(fitness)
            current_best_path = population[current_best_idx]
            current_best_dist = 1 / fitness[current_best_idx]

            # 更新全局最优解
            if current_best_dist < best_distance:
                best_distance = current_best_dist
                best_path = current_best_path.copy()

            # 记录历史用于可视化
            if gen % 10 == 0:  # 每10代记录一次
                history.append((current_best_path, current_best_dist))

            # 选择
            parents = self._select_parents(population, fitness, pop_size)

            # 交叉
            offspring = []
            for i in range(0, pop_size, 2):
                parent1 = parents[i]
                parent2 = parents[i + 1] if i + 1 < pop_size else parents[0]
                child1, child2 = self._crossover(parent1, parent2)
                offspring.append(child1)
                offspring.append(child2)

            # 变异
            for i in range(pop_size):
                if random.random() < mutation_rate:
                    offspring[i] = self._mutate(offspring[i])

            # 更新种群
            population = offspring[:pop_size]

        # 更新最优解
        self.best_path = best_path
        self.best_distance = best_distance

        return best_path, best_distance, history

    def _initialize_population(self, pop_size):
        """初始化种群"""
        population = []
        for _ in range(pop_size):
            # 随机生成路径
            path = list(range(self.num_cities))
            random.shuffle(path)
            population.append(path)
        return population

    def _calculate_fitness(self, population):
        """计算种群中每个个体的适应度"""
        fitness = []
        for path in population:
            distance = self.calculate_path_distance(path)
            fitness.append(1 / distance)  # 距离越短，适应度越高
        return np.array(fitness)

    def _select_parents(self, population, fitness, num_parents):
        """选择父代个体"""
        # 基于适应度的轮盘赌选择
        probabilities = fitness / np.sum(fitness)
        parents = np.random.choice(len(population), size=num_parents, p=probabilities)
        return [population[i] for i in parents]

    def _crossover(self, parent1, parent2):
        """有序交叉(OX)操作"""
        size = len(parent1)
        a, b = random.sample(range(size), 2)
        if a > b:
            a, b = b, a

        # 初始化子代
        child1 = [-1] * size
        child2 = [-1] * size

        # 复制父代的中间部分
        child1[a:b + 1] = parent1[a:b + 1]
        child2[a:b + 1] = parent2[a:b + 1]

        # 填充剩余部分
        self._fill_child(child1, parent2, a, b)
        self._fill_child(child2, parent1, a, b)

        return child1, child2

    def _fill_child(self, child, parent, a, b):
        """填充交叉后的子代"""
        size = len(child)
        current_pos = (b + 1) % size
        parent_pos = (b + 1) % size

        while -1 in child:
            if parent[parent_pos] not in child:
                child[current_pos] = parent[parent_pos]
                current_pos = (current_pos + 1) % size
            parent_pos = (parent_pos + 1) % size

    def _mutate(self, path):
        """交换变异操作"""
        # 随机选择两个位置进行交换
        i, j = random.sample(range(len(path)), 2)
        path[i], path[j] = path[j], path[i]
        return path

    def visualize(self, path=None, title="TSP问题可视化"):
        """可视化TSP路径"""
        if path is None:
            path = self.best_path

        if path is None:
            print("请先求解TSP问题")
            return

        # 创建图形
        fig, ax = plt.subplots(figsize=(10, 8))

        # 绘制城市
        ax.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, marker='o', label='城市')

        # 绘制路径
        for i in range(len(path)):
            city1 = path[i]
            city2 = path[(i + 1) % len(path)]
            ax.plot(
                [self.cities[city1, 0], self.cities[city2, 0]],
                [self.cities[city1, 1], self.cities[city2, 1]],
                'b-'
            )

        # 添加城市编号
        for i, (x, y) in enumerate(self.cities):
            ax.text(x + 1, y + 1, str(i), fontsize=12)

        ax.set_title(f"{title}\n总距离: {self.calculate_path_distance(path):.2f}")
        ax.set_xlabel("X坐标")
        ax.set_ylabel("Y坐标")
        ax.legend()
        plt.grid(True)
        plt.show()

    def animate_evolution(self, history, title="TSP遗传算法进化过程"):
        """动画展示遗传算法的进化过程"""
        if not history:
            print("没有进化历史数据")
            return

        # 创建图形
        fig, ax = plt.subplots(figsize=(10, 8))

        # 绘制城市
        cities_scatter = ax.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, marker='o', label='城市')

        # 添加城市编号
        for i, (x, y) in enumerate(self.cities):
            ax.text(x + 1, y + 1, str(i), fontsize=12)

        # 初始化路径线
        line, = ax.plot([], [], 'b-')
        title_text = ax.set_title("")

        ax.set_xlabel("X坐标")
        ax.set_ylabel("Y坐标")
        ax.legend()
        ax.grid(True)

        # 设置坐标轴范围
        ax.set_xlim(self.cities[:, 0].min() - 5, self.cities[:, 0].max() + 5)
        ax.set_ylim(self.cities[:, 1].min() - 5, self.cities[:, 1].max() + 5)

        def init():
            line.set_data([], [])
            title_text.set_text("")
            return line, title_text

        def update(frame):
            path, distance = history[frame]
            # 更新路径数据
            x = [self.cities[city, 0] for city in path + [path[0]]]
            y = [self.cities[city, 1] for city in path + [path[0]]]
            line.set_data(x, y)
            title_text.set_text(f"{title} (第{frame * 10}代)\n总距离: {distance:.2f}")
            return line, title_text

        # 创建动画
        ani = animation.FuncAnimation(
            fig, update, frames=len(history),
            init_func=init, interval=500, blit=True
        )

        plt.show()
        return ani


# 主函数
def main():
    print("旅行商问题(TSP)求解器")
    print("=" * 30)

    # 获取用户输入
    try:
        num_cities = int(input("请输入城市数量: "))
        if num_cities < 3:
            print("城市数量必须至少为3，已自动设置为10")
            num_cities = 10
    except ValueError:
        print("输入无效，已自动设置城市数量为10")
        num_cities = 10

    # 创建TSP问题实例
    tsp = TSPProblem(num_cities=num_cities, seed=42)

    # 选择算法
    print("\n请选择求解算法:")
    print("1. 贪心算法")
    print("2. 遗传算法")

    try:
        choice = int(input("请输入选择 (1/2): "))
    except ValueError:
        print("输入无效，默认选择贪心算法")
        choice = 1

    if choice == 1:
        # 使用贪心算法
        print("\n正在使用贪心算法求解...")
        path, distance = tsp.greedy_algorithm()
        print(f"贪心算法求解完成，最优路径总距离: {distance:.2f}")
        tsp.visualize(title="TSP贪心算法求解结果")

    else:
        # 使用遗传算法
        print("\n正在使用遗传算法求解...")
        try:
            pop_size = int(input("请输入种群大小 (默认100): ") or "100")
            generations = int(input("请输入进化代数 (默认500): ") or "500")
            mutation_rate = float(input("请输入变异率 (默认0.01): ") or "0.01")
        except ValueError:
            print("输入无效，使用默认参数")
            pop_size = 100
            generations = 500
            mutation_rate = 0.01

        path, distance, history = tsp.genetic_algorithm(
            pop_size=pop_size,
            generations=generations,
            mutation_rate=mutation_rate
        )

        print(f"遗传算法求解完成，最优路径总距离: {distance:.2f}")
        tsp.visualize(title="TSP遗传算法求解结果")

        # 展示进化过程动画
        show_animation = input("是否展示进化过程动画? (y/n): ").lower() == 'y'
        if show_animation:
            tsp.animate_evolution(history)


if __name__ == "__main__":
    main()