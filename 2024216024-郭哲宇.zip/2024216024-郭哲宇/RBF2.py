import numpy as np
import matplotlib.pyplot as plt

# 定义目标函数 g(p)
def g(p):
    return 1 + np.sin(p * np.pi / 8) - 2

# 生成随机训练数据
def generate_data(num_points):
    return np.random.uniform(-2, 2, num_points)

# RBF 网络类
class RBFNetwork:
    def __init__(self, num_centers):
        self.num_centers = num_centers
        self.centers = np.random.uniform(-2, 2, num_centers)
        self.weights = np.random.rand(num_centers)
        self.bias = np.random.rand()
        
    def gaussian(self, x, center, width=1.0):
        return np.exp(-((x - center) ** 2) / (2 * width ** 2))
    
    def predict(self, x):
        # 计算 RBF 的输出
        rbf_output = np.array([self.gaussian(x, center) for center in self.centers])
        return np.dot(self.weights, rbf_output) + self.bias

    def train(self, x_train, y_train, learning_rate=0.01, epochs=1000):
        for epoch in range(epochs):
            for i in range(len(x_train)):
                # 前向传播
                x = x_train[i]
                y = y_train[i]
                prediction = self.predict(x)
                
                # 计算误差
                error = y - prediction
                
                # 更新权值和偏置
                rbf_output = np.array([self.gaussian(x, center) for center in self.centers])
                self.weights += learning_rate * error * rbf_output
                self.bias += learning_rate * error

# 主程序
if __name__ == "__main__":
    # 从区间 -2 ≤ p < 2 中随机选择 10 个数据点
    p_train = generate_data(10)
    y_train = g(p_train)
    
    # 创建 RBF 网络并训练
    num_centers_list = [2, 4, 8]
    learning_rate = 0.01
    epochs = 1000
    
    plt.figure(figsize=(12, 8))
    
    for num_centers in num_centers_list:
        rbf_network = RBFNetwork(num_centers)
        rbf_network.train(p_train, y_train, learning_rate, epochs)

        # 在 -2 < p < 2 上绘制网络响应
        p_test = np.linspace(-2, 2, 100)
        y_test = g(p_test)
        y_pred = [rbf_network.predict(x) for x in p_test]

        # 计算误差平方和
        mse = np.mean((g(p_train) - rbf_network.predict(p_train)) ** 2)
        print(f"Number of centers: {num_centers}, MSE: {mse:.4f}")

        # 绘制结果
        plt.plot(p_test, y_pred, label=f'RBF Output (centers={num_centers})')
        plt.scatter(p_train, y_train, color='red', label='Training Points')

    plt.title("RBF Network Function Approximation")
    plt.xlabel("p")
    plt.ylabel("g(p)")
    plt.legend()
    plt.grid()
    plt.show()
