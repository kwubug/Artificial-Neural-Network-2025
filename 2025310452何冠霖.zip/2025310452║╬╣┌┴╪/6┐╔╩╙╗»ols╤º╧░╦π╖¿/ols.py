import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]


# --------------------------
# 1. 生成模拟数据（带噪声的线性关系）
# --------------------------
np.random.seed(42)  # 固定随机种子，保证结果可复现
n = 50  # 样本量
x = np.linspace(0, 10, n)  # 输入x：0到10的均匀分布

# 真实模型：y = 2x + 3 + 噪声（模拟真实世界的观测误差）
true_w = 2.0  # 真实斜率
true_b = 3.0  # 真实截距
noise = np.random.normal(0, 1.5, n)  # 高斯噪声（均值0，标准差1.5）
y = true_w * x + true_b + noise  # 带噪声的观测值


# --------------------------
# 2. OLS求解最优参数（解析解）
# --------------------------
# 对于线性模型 y = w*x + b，OLS通过最小化平方误差和求解w和b
# 解析解公式：w = (nΣxy - ΣxΣy)/(nΣx² - (Σx)²)，b = (Σy - wΣx)/n

sum_x = np.sum(x)
sum_y = np.sum(y)
sum_xy = np.sum(x * y)
sum_x2 = np.sum(x **2)

# 计算最优参数
w_ols = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x** 2)
b_ols = (sum_y - w_ols * sum_x) / n

print(f"OLS估计参数：w = {w_ols:.4f}, b = {b_ols:.4f}")
print(f"真实参数：w = {true_w}, b = {true_b}")


# --------------------------
# 3. 可视化1：数据与拟合直线
# --------------------------
plt.figure(figsize=(10, 6))
# 原始数据点
plt.scatter(x, y, c='blue', alpha=0.6, label='带噪声的观测数据')
# 真实直线（无噪声）
plt.plot(x, true_w * x + true_b, 'g--', linewidth=2, label=f'真实直线：y = {true_w}x + {true_b}')
# OLS拟合直线
plt.plot(x, w_ols * x + b_ols, 'r-', linewidth=2, label=f'OLS拟合直线：y = {w_ols:.2f}x + {b_ols:.2f}')

plt.xlabel('x (输入)')
plt.ylabel('y (输出)')
plt.title('OLS线性回归：数据与拟合结果')
plt.legend()
plt.grid(alpha=0.3)
plt.show()


# --------------------------
# 4. 可视化2：残差（误差项）
# --------------------------
# 残差 = 观测值 - 预测值（衡量拟合偏差）
y_pred = w_ols * x + b_ols  # OLS预测值
residuals = y - y_pred  # 残差

plt.figure(figsize=(10, 6))
# 原始数据与拟合线
plt.scatter(x, y, c='blue', alpha=0.6, label='观测数据')
plt.plot(x, y_pred, 'r-', linewidth=2, label='OLS拟合直线')
# 残差线段（每个点到拟合线的垂直距离）
for xi, yi, yp in zip(x, y, y_pred):
    plt.plot([xi, xi], [yi, yp], 'k--', linewidth=1)  # 黑色虚线表示残差

plt.xlabel('x (输入)')
plt.ylabel('y (输出)')
plt.title('OLS残差可视化（黑色虚线为误差）')
plt.legend()
plt.grid(alpha=0.3)
plt.show()


# --------------------------
# 5. 可视化3：损失函数曲面与最小值点
# --------------------------
# 损失函数：L(w, b) = 1/n * Σ(y - (w*x + b))²（平均平方误差）
def loss_function(w, b):
    y_pred = w * x + b
    return np.mean((y - y_pred) **2)

# 生成w和b的网格（用于绘制损失曲面）
w_range = np.linspace(0, 4, 100)  # w的搜索范围（围绕真实值2）
b_range = np.linspace(1, 5, 100)  # b的搜索范围（围绕真实值3）
W, B = np.meshgrid(w_range, b_range)  # 网格矩阵

# 计算每个(w, b)对应的损失值
L = np.zeros_like(W)
for i in range(W.shape[0]):
    for j in range(W.shape[1]):
        L[i, j] = loss_function(W[i, j], B[i, j])

# 绘制3D损失曲面
fig = plt.figure(figsize=(12, 8))
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_surface(W, B, L, cmap='viridis', alpha=0.8)
# 标记OLS估计的参数对应的最小值点
ax.scatter(w_ols, b_ols, loss_function(w_ols, b_ols), 
           c='red', s=200, marker='*', label='OLS最优解')
# 标记真实参数对应的损失（可能不是最小值，因为有噪声）
ax.scatter(true_w, true_b, loss_function(true_w, true_b), 
           c='green', s=200, marker='o', label='真实参数')

ax.set_xlabel('w (斜率)')
ax.set_ylabel('b (截距)')
ax.set_zlabel('损失值 L(w, b)')
ax.set_title('OLS损失函数曲面（最小值为OLS最优解）')
plt.colorbar(surf, label='损失值')
plt.legend()
plt.show()


# --------------------------
# 6. 可视化4：损失函数等高线（俯视图）
# --------------------------
plt.figure(figsize=(10, 8))
contour = plt.contourf(W, B, L, levels=30, cmap='viridis')  # 等高线填充
plt.contour(W, B, L, levels=10, colors='black', linewidths=0.5)  # 等高线轮廓
# 标记最优解和真实参数
plt.scatter(w_ols, b_ols, c='red', s=100, marker='*', label='OLS最优解')
plt.scatter(true_w, true_b, c='green', s=100, marker='o', label='真实参数')

plt.xlabel('w (斜率)')
plt.ylabel('b (截距)')
plt.title('OLS损失函数等高线（颜色越深损失越小）')
plt.colorbar(contour, label='损失值')
plt.legend()
plt.grid(alpha=0.3)
plt.show()