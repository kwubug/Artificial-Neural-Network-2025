import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.12

import '..'  // 导入上级目录组件（NetworkSetting、DataChart等）

Page {
    name: 'BP算法'

    // 小数显示精度常量
    property int toFixedValue: 6

    ColumnLayout {
        spacing: 10
        anchors.margins: 10
        Layout.fillWidth: true
        Layout.fillHeight: true

        // 1. 数据集选择区域
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(mlpBridge.dataset_dict)
                enabled: mlpBridge.has_finished
                onActivated: () => {
                    mlpBridge.current_dataset_name = currentText
                    dataChart.updateDataset(mlpBridge.dataset_dict[currentText])
                }
                Component.onCompleted: () => {
                    if (model.length > 0) {
                        currentIndex = 0  // 通过currentIndex设置默认选中项
                        mlpBridge.current_dataset_name = currentText
                        dataChart.updateDataset(mlpBridge.dataset_dict[currentText])
                    }
                }
            }
        }

        // 2. 训练参数设置区域
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                rowSpacing: 8
                columnSpacing: 8

                Label { text: 'Total Training Epoches'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: totalEpoches
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 10
                    to: 999999
                    onValueChanged: mlpBridge.total_epoches = value
                    Component.onCompleted: mlpBridge.total_epoches = value
                    Layout.fillWidth: true
                }

                CheckBox {
                    id: mostCorrectRateCheckBox
                    enabled: mlpBridge.has_finished
                    text: 'Most Correct Rate'
                    checked: true
                    onCheckedChanged: mlpBridge.most_correct_rate_checkbox = checked
                    Component.onCompleted: mlpBridge.most_correct_rate_checkbox = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: mostCorrectRateCheckBox.checked && mlpBridge.has_finished
                    editable: true
                    value: 1.00 * 100
                    onValueChanged: mlpBridge.most_correct_rate = value / 100
                    Component.onCompleted: mlpBridge.most_correct_rate = value / 100
                    Layout.fillWidth: true
                }

                Label { text: 'Initial Learning Rate'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 0.8 * 100
                    onValueChanged: mlpBridge.initial_learning_rate = value / 100
                    Component.onCompleted: mlpBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }

                Label { text: 'Search Iteration Constant'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 10000
                    to: 999999
                    onValueChanged: mlpBridge.search_iteration_constant = value
                    Component.onCompleted: mlpBridge.search_iteration_constant = value
                    Layout.fillWidth: true
                }

                Label { text: 'Momentum Weight'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 0.5 * 100
                    from: 0
                    to: 99
                    onValueChanged: mlpBridge.momentum_weight = value / 100
                    Component.onCompleted: mlpBridge.momentum_weight = value / 100
                    Layout.fillWidth: true
                }

                Label { text: 'Test-Train Ratio'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 30
                    to: 90
                    onValueChanged: mlpBridge.test_ratio = value / 100
                    Component.onCompleted: mlpBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }

                Label { text: 'UI Refresh Interval'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: mlpBridge.has_finished
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: mlpBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: mlpBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }

        // 3. 网络结构设置区域
        GroupBox {
            title: 'Network'
            Layout.fillWidth: true
            NetworkSetting {
                enabled: mlpBridge.has_finished
                onShapeChanged: mlpBridge.network_shape = shape
                Component.onCompleted: mlpBridge.network_shape = shape
            }
        }

        // 4. 3.7题 BP神经网络算法区域
        GroupBox {
            title: "3.7题 BP神经网络算法"
            Layout.fillWidth: true

            ColumnLayout {
                width: parent.width
                spacing: 15
                anchors.margins: 10

                // 网络结构配置
                GridLayout {
                    columns: 6
                    columnSpacing: 10
                    Label { text: "输入层节点:"; Layout.alignment: Qt.AlignRight }
                    SpinBox {
                        from: 1; to: 10
                        value: mlpBridge.bp_input_nodes
                        onValueChanged: mlpBridge.bp_input_nodes = value
                    }
                    Label { text: "隐层节点:"; Layout.alignment: Qt.AlignRight }
                    SpinBox {
                        from: 1; to: 20
                        value: mlpBridge.bp_hidden_nodes
                        onValueChanged: mlpBridge.bp_hidden_nodes = value
                    }
                    Label { text: "输出层节点:"; Layout.alignment: Qt.AlignRight }
                    SpinBox {
                        from: 1; to: 5
                        value: mlpBridge.bp_output_nodes
                        onValueChanged: mlpBridge.bp_output_nodes = value
                    }
                }

                // 学习率配置
                RowLayout {
                    Label { text: "学习率η:"; width: 80 }
                    Slider {
                        value: mlpBridge.bp_learning_rate
                        onValueChanged: mlpBridge.bp_learning_rate = value
                        from: 0.01; to: 1.0; stepSize: 0.01
                        Layout.fillWidth: true
                    }
                    Label {
                        text: mlpBridge.bp_learning_rate.toFixed(3)
                        width: 60
                        horizontalAlignment: Text.AlignHCenter
                    }
                }

                // 激活函数选择
                RowLayout {
                    Label { text: "激活函数:"; width: 80 }
                    ComboBox {
                        id: activationCombo
                        model: ["unipolar", "bipolar"]
                        // 仅读取currentText，不直接赋值
                        onCurrentTextChanged: mlpBridge.bp_activation_type = currentText

                        // 初始化：通过currentIndex设置默认选中项
                        Component.onCompleted: {
                            // 找到与桥接类属性匹配的索引
                            const targetType = mlpBridge.bp_activation_type;
                            const matchIndex = model.indexOf(targetType);
                            // 若找到匹配项，设置索引；否则默认选中第0项
                            currentIndex = matchIndex !== -1 ? matchIndex : 0;
                        }
                    }
                    Text { text: "(单极性/双极性)"; font.italic: true; color: "#666" }
                }

                // 权值初始化按钮
                Button {
                    text: "随机初始化权值 [-1,1]"
                    onClicked: mlpBridge.bp_initialize_weights()
                    Layout.alignment: Qt.AlignLeft
                }

                // 运行演示按钮
                Button {
                    text: "运行BP算法演示"
                    onClicked: mlpBridge.bp_run_demo()
                    Layout.alignment: Qt.AlignLeft
                }

                // 结果显示
                TextArea {
                    text: mlpBridge.bp_result
                    Layout.fillWidth: true
                    height: 150
                    font.family: "Courier New"
                    wrapMode: Text.Wrap
                    readOnly: true
                }
            }
        }

        // 5. 训练信息展示区域
        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                rowSpacing: 5
                columnSpacing: 10

                ExecutionControls {
                    startButton.enabled: mlpBridge.has_finished
                    startButton.onClicked: () => {
                        mlpBridge.start_mlp_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(mlpBridge.training_dataset)
                        dataChart.updateTestingDataset(mlpBridge.testing_dataset)
                        rateChart.reset()
                    }
                    stopButton.enabled: !mlpBridge.has_finished
                    stopButton.onClicked: mlpBridge.stop_mlp_algorithm()
                    progressBar.value: (mlpBridge.current_iterations + 1) / (totalEpoches.value * (mlpBridge.training_dataset.length || 1))
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: 'Current Training Epoch'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const iterPerEpoch = mlpBridge.training_dataset.length || 1;
                        const epoch = Math.floor(mlpBridge.current_iterations / iterPerEpoch) + 1;
                        return isNaN(epoch) ? 1 : epoch;
                    }
                }

                Label { text: 'Current Training Iteration'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: mlpBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        rateChart.bestCorrectRate.append(
                            mlpBridge.current_iterations + 1,
                            mlpBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            mlpBridge.current_iterations + 1,
                            mlpBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            mlpBridge.current_iterations + 1,
                            mlpBridge.test_correct_rate
                        )
                    }
                    Layout.fillWidth: true
                }

                Label { text: 'Current Learning Rate'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: mlpBridge.current_learning_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label { text: 'Best Training Correct Rate'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: mlpBridge.best_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label { text: 'Current Training Correct Rate'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: mlpBridge.current_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }

                Label { text: 'Current Testing Correct Rate'; Layout.alignment: Qt.AlignHCenter }
                Label {
                    text: mlpBridge.test_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }

        // 6. 图表展示区域
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10

            DataChart {
                id: dataChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
            RateChart {
                id: rateChart
                Layout.fillWidth: true
                Layout.fillHeight: true
            }
        }
    }
}