import os
import sys
from pathlib import Path

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets
import PyQt5.QtGui

from nn_sandbox.bridges import (
    BPBridge,
    MlpBridge,
    PerceptronBridge,
    RbfnBridge,
    SandboxBridge,
    SomBridge,
)
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    app = PyQt5.QtWidgets.QApplication(sys.argv)
    app.setFont(PyQt5.QtGui.QFont("Microsoft YaHei"))
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    project_root = Path(__file__).resolve().parent
    dataset_dir = project_root / 'nn_sandbox' / 'assets' / 'data'
    dataset_dict = nn_sandbox.backend.utils.read_data(str(dataset_dir))

    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'bpBridge': BPBridge(),
        'sandboxBridge': SandboxBridge(),
    }
    for name, bridge in bridges.items():
        if hasattr(bridge, 'dataset_dict'):
            bridge.dataset_dict = dataset_dict
        engine.rootContext().setContextProperty(name, bridge)

    qml_path = project_root / 'nn_sandbox' / 'frontend' / 'main.qml'
    engine.load(PyQt5.QtCore.QUrl.fromLocalFile(str(qml_path)))
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())
