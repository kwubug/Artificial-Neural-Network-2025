import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# 1. 生成数据
np.random.seed(0)

# 生成一些数据点：y = 2x + 1 + 噪声
X = np.random.rand(100, 1) * 10  # 随机生成 100 个 X 值
y = 2 * X + 1 + np.random.randn(100, 1) * 2  # y = 2x + 1，加上噪声

# 2. 使用 OLS 求解回归系数
# 在 X 加上一列偏置项（即全为 1 的列）
X_b = np.c_[np.ones((X.shape[0], 1)), X]

# 使用正规方程来计算 w: w = (X.T * X)^(-1) * X.T * y
w = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)

# 拟合后的直线
X_new = np.array([[0], [10]])  # 用于画拟合线的 X 值范围
X_new_b = np.c_[np.ones((2, 1)), X_new]  # 加入偏置项
y_predict = X_new_b.dot(w)

# 3. 绘制图形
plt.figure(figsize=(8, 6))
plt.scatter(X, y, color='blue', label="Data points", alpha=0.6)
plt.plot(X_new, y_predict, color='red', linewidth=2, label="OLS fit line")

# 标注信息
plt.title("OLS Linear Regression", fontsize=16)
plt.xlabel("X", fontsize=14)
plt.ylabel("y", fontsize=14)
plt.legend()

# 显示图像
plt.show()

# 4. 输出回归系数
print(f"回归系数 w0 (偏置项): {w[0]}")
print(f"回归系数 w1 (斜率): {w[1]}")

# 5. 可选：展示通过sklearn的线性回归对比
model = LinearRegression()
model.fit(X, y)
y_sklearn_pred = model.predict(X_new)

plt.figure(figsize=(8, 6))
plt.scatter(X, y, color='blue', label="Data points", alpha=0.6)
plt.plot(X_new, y_sklearn_pred, color='green', linestyle='--', label="Sklearn OLS fit line")

plt.title("OLS using sklearn LinearRegression", fontsize=16)
plt.xlabel("X", fontsize=14)
plt.ylabel("y", fontsize=14)
plt.legend()

plt.show()

print("Sklearn 回归系数：")
print(f"偏置项: {model.intercept_}")
print(f"斜率: {model.coef_[0]}")
