from PyQt5.QtCore import QObject, pyqtSignal
import time
from nn_sandbox.backend.algorithms.bm_algorithm import BmAlgorithm
class BMWorker(QObject):
    update_signal = pyqtSignal(int, list, float)  # epoch, state, energy
    finished_signal = pyqtSignal()

    def __init__(self, total_epoches, temperature, interval=0.05):
        super().__init__()
        self.algorithm = BMAlgorithm(total_epoches, temperature)
        self.interval = interval
        self._stop = False

    def stop(self):
        self._stop = True
        self.algorithm.stop()

    def run(self):
        for epoch in range(self.algorithm.total_epoches):
            if self._stop:
                break
            state, energy = self.algorithm.run_step()
            self.update_signal.emit(epoch, state, energy)
            time.sleep(self.interval)
        self.finished_signal.emit()
