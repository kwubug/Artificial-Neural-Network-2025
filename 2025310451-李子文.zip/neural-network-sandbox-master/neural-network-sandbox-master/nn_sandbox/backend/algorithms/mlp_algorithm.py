# -*- coding: utf-8 -*-
"""
三层 BP 神经网络（输入-隐藏-输出，单隐藏层）。
在原 MlpAlgorithm 的基础上，增加：
- activation 选择（'unipolar' 或 'bipolar'）
- reset_weights() 一键随机初始化（[-1, 1]）
- 将 network_shape 兼容为仅取第一层作为隐藏层宽度，强制三层结构
"""

from __future__ import annotations

import collections
import math
from typing import Iterable, List, Tuple, Optional

import numpy as np

from . import PredictiveAlgorithm
from ..utils import sigmoid, bipolar_sigmoid
from ..neurons import Perceptron


class MlpAlgorithm(PredictiveAlgorithm):
    """Backpropagation prototype (3-layer: input-hidden-output)."""

    def __init__(
        self,
        dataset,
        total_epoches: int = 10,
        most_correct_rate: Optional[float] = None,
        initial_learning_rate: float = 0.8,
        search_iteration_constant: int = 10000,
        momentum_weight: float = 0.5,
        test_ratio: float = 0.3,
        network_shape=None,
        activation: str = 'unipolar',  # 'unipolar' | 'bipolar'
    ):
        # 调用父类，沿用原有训练流程/拆分流程等
        super().__init__(
            dataset,
            total_epoches,
            most_correct_rate,
            initial_learning_rate,
            search_iteration_constant,
            test_ratio,
        )

        self._momentum_weight = momentum_weight
        # 兼容旧 UI：如果传来 [5,5]，仅取第一个作为单隐藏层宽度
        if network_shape is None:
            hidden = 5
        else:
            hidden = list(network_shape)[0] if isinstance(network_shape, (list, tuple)) else int(network_shape)
        self.network_shape = (hidden,)  # 强制单隐藏层（三层 BP）

        self._activation = activation  # 'unipolar' | 'bipolar'

        # for momentum（保持与原实现一致的动量结构，以便其它逻辑复用）
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

        # 初始化神经元网络
        self._initialize_neurons()

    # ========== 结构与激活 ==========

    def _initialize_neurons(self):
        """Build network with single hidden layer and one output neuron."""
        act_fn = sigmoid if self._activation == 'unipolar' else bipolar_sigmoid
        layers = list(self.network_shape) + [1]  # [hidden, 1(output)]
        # 每层若干个 Perceptron，每个使用相同激活（也可以按需固定输出层激活）
        self._neurons = tuple((Perceptron(act_fn),) * size for size in layers)

    def set_activation(self, name: str):
        """切换激活函数后需要重建神经元（保持一致）。"""
        if name not in ('unipolar', 'bipolar'):
            name = 'unipolar'
        self._activation = name
        # 保持现有权值不变，只切换激活函数：重建神经元的同时迁移权值
        old_layers = getattr(self, '_neurons', None)
        self._initialize_neurons()
        if old_layers:
            # 将旧层的权值拷贝到新层（按索引对应）
            for (new_layer, old_layer) in zip(self._neurons, old_layers):
                for (new_n, old_n) in zip(new_layer, old_layer):
                    new_n.synaptic_weight = old_n.synaptic_weight

    def reset_weights(self):
        """一键随机初始化权值（[-1, 1]），利用 Perceptron 的懒初始化特性。"""
        if not hasattr(self, "_neurons") or not self._neurons:
            return
        for layer in self._neurons:
            for neuron in layer:
                neuron.synaptic_weight = None  # 下次访问 result 时会在 [-1,1] 随机初始化

    # ========== 激活导数（用输出 y 形式，避免重复计算 z） ==========

    def _d_act_from_output(self, y: float) -> float:
        """给定激活后的输出 y，返回 f'(z)（单极性/双极性各自的导数）"""
        if self._activation == 'unipolar':
            return y * (1.0 - y)               # sigmoid'(z) = y*(1-y)
        else:
            return 0.5 * (1.0 - y * y)         # tanh(z/2)' = 0.5*(1 - y^2)

    # ========== 前向/反向/更新 ==========

    def _feed_forward(self, data: np.ndarray) -> float:
        """
        前向：逐层计算。该项目已有 get_layer_results/Perceptron.result 的机制：
        - 将当前层输入写到 neuron.data
        - 通过访问 neuron.result 触发 lazy 计算
        """
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        # 输出层只有一个神经元
        return results[0]

    def _pass_backward(self, expect: float, result: float):
        """
        计算各神经元的 delta：
        - 输出层： (target - y) * f'(z)
        - 隐层：   Σ(delta_next * w) * f'(z)
        双极性下将标签从 [0,1] 线性映射到 [-1,1] 再计算误差。
        """
        deltas = {}

        target = expect if self._activation == 'unipolar' else (2.0 * expect - 1.0)
        deltas[self._neurons[-1][0]] = (target - result) * self._d_act_from_output(result)

        # 逐层回传（不含输出层）
        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                back = sum(deltas[n] * n.synaptic_weight[neuron_idx] for n in self._neurons[layer_idx + 1])
                deltas[neuron] = back * self._d_act_from_output(neuron.result)
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        """
        按原项目风格，保留“动量 + 当前学习率”的更新形式：
        Δw(t) = α * Δw(t-1) + η * δ * x
        w ← w + Δw(t)
        """
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    # ========== 评估/标准化（维持与原实现兼容） ==========

    def _correct_rate(self, dataset) -> float:
        """与原项目保持一致：输出按单极性 [0,1] 评估准确率."""
        if not self._neurons:
            return 0.0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1.0 / (2 * len(self.group_types))
            y_out = self._neurons[-1][0].result
            y_eval = y_out if self._activation == 'unipolar' else (y_out + 1.0) / 2.0
            if expect - interval < y_eval < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0.0
        return correct_count / float(len(dataset))

    def _normalize(self, value: float) -> float:
        """将真实标签规范到 [0,1] 刻度（与原代码相同）。"""
        return (2.0 * (value - np.amin(self.group_types)) + 1.0) / (2.0 * len(self.group_types))

    def _iterate(self):
        """
        单次“训练轮”的实现：遍历训练集，按 BP 更新权值。
        基类会循环调用它（或调用 _iterate_once），所以这里就是“一个 epoch”的内容。
        """
        if not hasattr(self, 'training_dataset') or self.training_dataset is None:
            return
        for data in self.training_dataset:
            x = np.asarray(data[:-1], dtype=float)
            expect = float(self._normalize(data[-1]))
            y = self._feed_forward(x)
            deltas = self._pass_backward(expect, y)
            self._adjust_synaptic_weights(deltas)

    # 兼容某些版本基类会调用 _iterate_once(epoch)
    def _iterate_once(self, epoch: int = 0):
        self._iterate()


def get_layer_results(layer: Iterable[Perceptron], data):
    """项目原有工具：把输入塞给每个 neuron.data，然后读取 neuron.result。"""
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)
