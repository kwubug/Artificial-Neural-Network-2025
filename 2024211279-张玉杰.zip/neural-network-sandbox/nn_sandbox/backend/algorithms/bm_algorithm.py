import numpy as np
import time
from .base_algorithm import TraningAlgorithm


class BoltzmannMachineAlgorithm(TraningAlgorithm):
    """
    Simple 3-neuron Boltzmann Machine with Simulated Annealing (SA).
    Real-time notifications for step, state, energy, and temperature.
    """
    def __init__(self, W, theta, initial_state, T0=5.0, gamma=0.8, steps_per_temp=1,
                 max_iter=200, update_freq=5, ui_refresh_interval=0.01):
        super().__init__(dataset=[], total_epoches=1)
        self.W = np.array(W, dtype=float)
        self.theta = np.array(theta, dtype=float)
        self.x = np.array(initial_state, dtype=int)
        self.T = float(T0)
        self.gamma = float(gamma)
        self.steps_per_temp = int(steps_per_temp)
        self.max_iter = int(max_iter)
        self.update_freq = int(update_freq)
        self.ui_refresh_interval = float(ui_refresh_interval)

        self.k = 0
        self.energy = float(self._energy(self.x))
        self.updated_neuron = -1  # -1 means no neuron updated yet
        self.has_finished = True

    def _s_i(self, x, i):
        return float(np.dot(self.W[i, :], x) - self.theta[i])

    def _energy(self, x):
        term1 = -0.5 * float(np.dot(x.T, np.dot(self.W, x)))
        term2 = float(np.dot(x, self.theta))
        return term1 + term2

    def _sigmoid(self, s, T):
        if T <= 0:
            return 1.0 if s > 0 else 0.0
        arg = -s / max(T, 1e-6)
        arg = np.clip(arg, -100, 100)
        return 1.0 / (1.0 + np.exp(arg))

    def run(self):
        self.has_finished = False
        # notify initial state
        if hasattr(self, 'notify'):
            self.notify('has_finished', False)
            self.notify('k', 0)
            self.notify('x_state', self.x.tolist())
            self.notify('energy', self.energy)
            self.notify('temperature', float(self.T))
            self.notify('updated_neuron', -1)
        # main loop
        for k in range(1, self.max_iter + 1):
            if self._should_stop:
                break
            i = (k - 1) % len(self.x)  # round-robin
            x_old = self.x.copy()
            s_i = self._s_i(x_old, i)
            p_i = self._sigmoid(s_i, self.T)
            mu = np.random.rand()
            x_new = x_old.copy()
            x_new[i] = 1 if mu < p_i else 0
            self.x = x_new
            self.energy = float(self._energy(self.x))
            # cooling
            if k % self.steps_per_temp == 0:
                self.T = self.T * self.gamma
            self.k = k
            self.updated_neuron = i  # Record which neuron was updated
            # notify every step (real-time updates)
            if hasattr(self, 'notify'):
                self.notify('k', self.k)
                self.notify('x_state', self.x.tolist())
                self.notify('energy', self.energy)
                self.notify('temperature', float(self.T))
                self.notify('updated_neuron', i)
            if self.ui_refresh_interval > 0:
                time.sleep(self.ui_refresh_interval)
        # done
        self.has_finished = True
        if hasattr(self, 'notify'):
            self.notify('has_finished', True)


