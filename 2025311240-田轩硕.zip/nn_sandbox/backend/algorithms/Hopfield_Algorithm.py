import numpy as np
from typing import List, Dict
from . import TraningAlgorithm


class HopfieldAlgorithm(TraningAlgorithm):
    """
    Discrete Hopfield Neural Network with asynchronous updates.
    Supports pattern storage, retrieval, and attractor analysis.
    """

    def __init__(
        self,
        patterns: List[List[int]],
        initial_state: List[int],
        total_iterations: int,
        update_mode: str = 'async',  # 'async' or 'sync'
    ):
        super().__init__([initial_state], total_iterations)
        self._patterns = [np.array(p, dtype=int) for p in patterns]
        self._state = np.array(initial_state, dtype=int)
        self._total_iterations = max(1, total_iterations)
        self._update_mode = update_mode
        self._n_neurons = len(initial_state)
        
        # Initialize weight matrix using Hebbian learning
        self._weight_matrix = self._train_weights()
        
        # State tracking
        self.current_iterations = 0
        self.current_energy = self.calculate_energy()
        self.state_history = []
        self.energy_history = []
        self.attractor_state = None
        self.attractor_iteration = -1
        self.attractor_energy = None
        self.converged = False
        
        # Record initial state
        self._record_snapshot()

    def run(self):
        """Run the Hopfield network until convergence or max iterations"""
        for iteration in range(1, self._total_iterations + 1):
            if self._should_stop:
                break
            
            self.current_iterations = iteration
            old_state = self._state.copy()
            
            # Update neurons
            if self._update_mode == 'async':
                self._async_update()
            else:
                self._sync_update()
            
            self.current_energy = self.calculate_energy()
            self._record_snapshot()
            
            # Check for convergence
            if np.array_equal(self._state, old_state):
                self.converged = True
                self.attractor_state = self._state.copy().tolist()
                self.attractor_iteration = iteration
                self.attractor_energy = self.current_energy
                break
        
        # If not converged, mark last state as attractor
        if not self.converged:
            self.attractor_state = self._state.copy().tolist()
            self.attractor_iteration = self.current_iterations
            self.attractor_energy = self.current_energy

    def _train_weights(self):
        """Train weight matrix using Hebbian learning rule"""
        n = self._n_neurons
        w = np.zeros((n, n))
        
        for pattern in self._patterns:
            # Convert 0/1 to -1/+1 for training
            p = 2 * pattern - 1
            w += np.outer(p, p)
        
        # Normalize by number of patterns
        w /= len(self._patterns)
        
        # Zero diagonal (no self-connections)
        np.fill_diagonal(w, 0)
        
        return w

    def _async_update(self):
        """Asynchronously update neurons (one at a time, random order)"""
        indices = np.arange(self._n_neurons)
        np.random.shuffle(indices)
        
        for idx in indices:
            net_input = np.dot(self._weight_matrix[idx], self._state)
            self._state[idx] = 1 if net_input >= 0 else 0

    def _sync_update(self):
        """Synchronously update all neurons at once"""
        net_input = np.dot(self._weight_matrix, self._state)
        self._state = (net_input >= 0).astype(int)

    def calculate_energy(self):
        """Calculate the energy of current state using Hopfield energy function"""
        # E = -0.5 * sum(w_ij * s_i * s_j)
        # Convert 0/1 to -1/+1 for energy calculation
        s = 2 * self._state - 1
        energy = -0.5 * s @ self._weight_matrix @ s.T
        return float(energy)

    def _record_snapshot(self):
        """Record current state snapshot"""
        snapshot = {
            'iteration': self.current_iterations,
            'state': self._state.copy().tolist(),
            'energy': self.current_energy,
        }
        self.state_history.append(snapshot)
        self.energy_history.append(self.current_energy)
        return snapshot

    @property
    def neuron_state(self):
        """Get current neuron state"""
        return self._state.tolist()

    @property
    def weights(self):
        """Get weight matrix"""
        return self._weight_matrix.tolist()

    def get_pattern_similarity(self):
        """Calculate similarity between current state and stored patterns"""
        similarities = []
        for i, pattern in enumerate(self._patterns):
            # Calculate Hamming distance
            distance = np.sum(self._state != pattern)
            similarity = 1.0 - (distance / self._n_neurons)
            similarities.append({
                'pattern_index': i,
                'similarity': float(similarity),
                'hamming_distance': int(distance)
            })
        return similarities

    def detect_attractors(self):
        """Analyze state history to detect attractors"""
        attractors = []
        seen_states = {}
        
        for snapshot in self.state_history:
            state_tuple = tuple(snapshot['state'])
            if state_tuple in seen_states:
                # Found an attractor (repeating state)
                first_occurrence = seen_states[state_tuple]
                attractors.append({
                    'state': snapshot['state'],
                    'energy': snapshot['energy'],
                    'first_iteration': first_occurrence,
                    'period': snapshot['iteration'] - first_occurrence
                })
            else:
                seen_states[state_tuple] = snapshot['iteration']
        
        return attractors

    def stop(self):
        """Stop the algorithm"""
        super().stop()
