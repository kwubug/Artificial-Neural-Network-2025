import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.gridspec as gridspec
import matplotlib
matplotlib.use('Qt5Agg')  # 或 'TkAgg'
import matplotlib.pyplot as plt


# --- 1. 玻尔兹曼机 (BM) 类 ---
class BoltzmannMachine:
    def __init__(self, num_neurons):
        """
        初始化玻尔兹曼机
        :param num_neurons: 神经元的数量
        """
        self.num_neurons = num_neurons
        # 权重矩阵 W，W[i,j] 是神经元 i 和 j 之间的连接权重
        # 对角线元素为 0，因为神经元不与自身连接
        self.weights = np.random.randn(num_neurons, num_neurons) * 0.1
        self.weights -= np.diag(np.diag(self.weights))

        # 偏置向量 b
        self.biases = np.random.randn(num_neurons) * 0.1

        # 神经元状态 (0 或 1)
        self.states = np.random.randint(0, 2, num_neurons)

    def _energy(self, states=None):
        """
        计算给定状态下系统的能量 E
        :param states: 神经元状态向量，如果为 None，则使用当前状态
        :return: 能量值
        """
        if states is None:
            states = self.states

        # 确保 states 是一个列向量，便于矩阵运算
        states = states.reshape(-1, 1)

        # 能量公式: E = -0.5 * sum_i,j (W[i,j] * s[i] * s[j]) - sum_i (b[i] * s[i])
        energy = -0.5 * np.dot(np.dot(states.T, self.weights), states) - np.dot(states.T, self.biases)
        return energy.flatten()[0]  # 返回一个标量

    def update_neuron(self, neuron_idx):
        """
        使用吉布斯采样更新单个神经元的状态
        :param neuron_idx: 要更新的神经元索引
        :return: 新的状态
        """
        # 计算神经元 i 的激活能 (activation energy)
        # 激活能 = sum_j (W[i,j] * s[j]) + b[i]
        activation = np.dot(self.weights[neuron_idx, :], self.states) + self.biases[neuron_idx]

        # 计算神经元状态为 1 的概率
        # P(s_i=1 | s_{-i}) = 1 / (1 + exp(-activation))
        prob = 1 / (1 + np.exp(-activation))

        # 根据概率随机决定新状态
        new_state = 1 if np.random.random() < prob else 0
        old_state = self.states[neuron_idx]

        self.states[neuron_idx] = new_state

        # 返回状态是否发生了变化
        return old_state != new_state


# --- 2. 可视化与模拟函数 ---
def simulate_and_visualize_bm(bm, num_steps=100):
    """
    模拟 BM 运行并实时可视化
    :param bm: BoltzmannMachine 实例
    :param num_steps: 模拟的步数
    """
    # 设置图形
    fig = plt.figure(figsize=(16, 10))
    gs = gridspec.GridSpec(2, 2, height_ratios=[1, 1.2])

    # 子图1: 神经元状态 (Network Diagram)
    ax1 = plt.subplot(gs[0, :])
    ax1.set_title('Neuron States (0 = Inactive, 1 = Active)', fontsize=14)
    ax1.set_xlim(-1, bm.num_neurons)
    ax1.set_ylim(-0.5, 0.5)
    ax1.set_yticks([])
    ax1.set_xticks(range(bm.num_neurons))
    ax1.set_xticklabels([f'Neuron {i + 1}' for i in range(bm.num_neurons)])

    # 绘制神经元节点
    neuron_positions = np.arange(bm.num_neurons)
    neurons = ax1.scatter(neuron_positions, np.zeros_like(neuron_positions),
                          s=1000, c=bm.states, cmap='coolwarm', vmin=0, vmax=1, edgecolors='black')

    # 绘制连接权重
    weight_lines = []
    for i in range(bm.num_neurons):
        for j in range(i + 1, bm.num_neurons):
            line = ax1.plot([i, j], [0, 0], 'gray', lw=2, alpha=0.6)[0]
            weight_lines.append((line, i, j))

    # 子图2: 能量变化
    ax2 = plt.subplot(gs[1, 0])
    ax2.set_title('Energy of the System', fontsize=14)
    ax2.set_xlabel('Step')
    ax2.set_ylabel('Energy')
    energy_history = []
    energy_line, = ax2.plot([], [], 'b-')
    ax2.set_xlim(0, num_steps)

    # 子图3: 权重矩阵热力图
    ax3 = plt.subplot(gs[1, 1])
    ax3.set_title('Weight Matrix', fontsize=14)
    im = ax3.imshow(bm.weights, cmap='RdBu_r', interpolation='none')
    plt.colorbar(im, ax=ax3, label='Weight Value')
    ax3.set_xticks(range(bm.num_neurons))
    ax3.set_yticks(range(bm.num_neurons))
    ax3.set_xticklabels([f'{i + 1}' for i in range(bm.num_neurons)])
    ax3.set_yticklabels([f'{i + 1}' for i in range(bm.num_neurons)])

    # 添加权重数值标注
    for i in range(bm.num_neurons):
        for j in range(bm.num_neurons):
            text = ax3.text(j, i, f'{bm.weights[i, j]:.2f}',
                            ha="center", va="center", color="black" if abs(bm.weights[i, j]) < 0.5 else "white",
                            fontsize=9)

    plt.tight_layout()

    # --- 动画更新函数 ---
    def update(frame):
        # 1. 更新玻尔兹曼机状态
        # 随机选择一个神经元进行更新
        neuron_to_update = np.random.randint(0, bm.num_neurons)
        bm.update_neuron(neuron_to_update)

        # 2. 更新可视化
        # 更新神经元颜色
        neurons.set_array(bm.states)

        # 更新能量曲线
        current_energy = bm._energy()
        energy_history.append(current_energy)
        energy_line.set_data(range(len(energy_history)), energy_history)
        ax2.set_ylim(min(energy_history) - 1, max(energy_history) + 1)

        # 更新权重连线的透明度（可选，用于强调某些变化）
        # 这里我们让权重的绝对值决定线的宽度
        for line, i, j in weight_lines:
            weight = bm.weights[i, j]
            # 线的宽度与权重绝对值成正比
            line.set_linewidth(abs(weight) * 5)
            # 线的颜色反映权重符号
            line.set_color('red' if weight > 0 else 'blue')

        # 权重矩阵热力图和数值是固定的，因为我们只在模拟开始前初始化一次权重
        # 如果想模拟权重学习（如对比散度），可以在这里更新 im 和 text

        return neurons, energy_line, *[line for line, _, _ in weight_lines]

    # 创建动画
    ani = FuncAnimation(fig, update, frames=num_steps, interval=200, blit=True, repeat=False)

    plt.show()


# --- 3. 主程序 ---
if __name__ == '__main__':
    # 1. 设置随机种子以保证结果可复现
    np.random.seed(42)

    # 2. 初始化一个具有3个神经元的玻尔兹曼机
    num_neurons = 3
    bm = BoltzmannMachine(num_neurons=num_neurons)

    # (可选) 手动设置一些有趣的权重，以便观察特定行为
    # 例如，让神经元1和2相互兴奋，神经元1和3相互抑制
    print("初始权重矩阵:")
    print(bm.weights)
    print("初始偏置:")
    print(bm.biases)

    # 3. 运行模拟并可视化
    print("\n开始模拟玻尔兹曼机运行...")
    simulate_and_visualize_bm(bm, num_steps=200)