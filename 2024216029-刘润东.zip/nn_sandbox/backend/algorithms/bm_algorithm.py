import numpy as np
import threading
import time


class BmAlgorithm(threading.Thread):
    """
    Boltzmann Machine算法实现
    实现3个神经元的BM网络，演示热平衡过程
    """
    
    def __init__(self, num_neurons=3, temperature=1.0, max_iterations=1000):
        super().__init__()
        self.num_neurons = num_neurons
        self.temperature = temperature
        self.max_iterations = max_iterations
        self._should_stop = False
        
        # 初始化权重矩阵（随机生成对称矩阵）
        self.weights = np.random.randn(num_neurons, num_neurons) * 0.5
        # 确保对称性
        self.weights = (self.weights + self.weights.T) / 2
        # 对角线设为0（无自连接）
        np.fill_diagonal(self.weights, 0)
        
        # 偏置项
        self.bias = np.random.randn(num_neurons) * 0.1
        
        # 初始化神经元状态（随机0或1）
        self.states = np.random.randint(0, 2, num_neurons)
        
        # 记录历史
        self.energy_history = []
        self.state_history = []
        self.current_iteration = 0
        self.current_energy = self._calculate_energy()
        
    def run(self):
        """运行BM算法直到达到热平衡"""
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
                
            # 随机选择一个神经元更新
            neuron_idx = np.random.randint(0, self.num_neurons)
            self._update_neuron(neuron_idx)
            
            # 记录当前状态和能量
            self.current_energy = self._calculate_energy()
            self.energy_history.append(self.current_energy)
            self.state_history.append(self.states.copy())
            
            # 添加短暂延迟以便可视化
            time.sleep(0.05)
            
    def _update_neuron(self, idx):
        """
        使用Boltzmann分布更新单个神经元
        P(s_i = 1) = 1 / (1 + exp(-ΔE/T))
        """
        # 计算输入总和
        net_input = np.dot(self.weights[idx], self.states) + self.bias[idx]
        
        # 计算激活概率（sigmoid函数）
        activation_prob = 1.0 / (1.0 + np.exp(-net_input / self.temperature))
        
        # 根据概率随机决定状态
        self.states[idx] = 1 if np.random.random() < activation_prob else 0
        
    def _calculate_energy(self):
        """
        计算系统能量
        E = -0.5 * Σ(w_ij * s_i * s_j) - Σ(b_i * s_i)
        """
        weight_term = -0.5 * np.sum(
            self.weights * np.outer(self.states, self.states)
        )
        bias_term = -np.sum(self.bias * self.states)
        return weight_term + bias_term
    
    def stop(self):
        """停止算法运行"""
        self._should_stop = True
        
    def get_equilibrium_state(self):
        """
        返回热平衡状态（取最后几次迭代的平均状态）
        """
        if len(self.state_history) > 100:
            recent_states = self.state_history[-100:]
            return np.mean(recent_states, axis=0)
        return self.states
    
    def get_statistics(self):
        """返回统计信息"""
        return {
            'current_states': self.states.tolist(),
            'weights': self.weights.tolist(),
            'bias': self.bias.tolist(),
            'current_energy': float(self.current_energy),
            'avg_energy': float(np.mean(self.energy_history)) if self.energy_history else 0,
            'equilibrium_state': self.get_equilibrium_state().tolist()
        }


class ObservableBmAlgorithm(BmAlgorithm):
    """Observable版本的BM算法，用于与Bridge集成"""
    
    def __init__(self, observer, num_neurons=3, temperature=1.0, max_iterations=1000):
        BmAlgorithm.__init__(self, num_neurons, temperature, max_iterations)
        self._observer = observer
        
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            self._observer.update(name, value)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_energy', 'states']:
            if hasattr(self, '_observer'):
                self.notify(name, value)
                
    def run(self):
        """重写run方法以添加通知"""
        # 发送初始状态
        self.notify('statistics', self.get_statistics())
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
                
            # 随机选择一个神经元更新
            neuron_idx = np.random.randint(0, self.num_neurons)
            self._update_neuron(neuron_idx)
            
            # 记录当前状态和能量
            self.current_energy = self._calculate_energy()
            self.energy_history.append(self.current_energy)
            self.state_history.append(self.states.copy())
            
            # 通知统计信息
            self.notify('statistics', self.get_statistics())
            
            # 添加短暂延迟以便可视化
            time.sleep(0.03)

