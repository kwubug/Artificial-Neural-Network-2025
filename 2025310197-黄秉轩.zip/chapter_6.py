import matplotlib.pyplot as plt
import numpy as np
import os

# 创建sklearn文件夹（如果不存在）
if not os.path.exists('sklearn'):
    os.makedirs('sklearn')

# 生成示例数据
x = np.linspace(0, 10, 100)
y = np.sin(x)

# 创建图形并设置红紫色系（使用Purples或Reds等colormap）
plt.figure(figsize=(8, 6))
# 绘制曲线，颜色使用红紫色系
plt.plot(x, y, color='#8B008B')  # 深紫色
# 填充区域，使用红紫色渐变
plt.fill_between(x, y, color='#FF69B4', alpha=0.3)  # 热粉色

# 设置标题和坐标轴标签
plt.title('红紫色系示例图', fontproperties='SimHei')
plt.xlabel('X轴', fontproperties='SimHei')
plt.ylabel('Y轴', fontproperties='SimHei')

# 保存图片到sklearn文件夹
output_path = os.path.join('sklearn', 'purple_red_plot.png')
plt.savefig(output_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"图片已保存至: {output_path}")