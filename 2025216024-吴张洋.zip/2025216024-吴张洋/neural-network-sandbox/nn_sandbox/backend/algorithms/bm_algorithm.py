import time
import math
import random

import numpy as np

from . import TraningAlgorithm


class BmAlgorithm(TraningAlgorithm):
    """
    玻尔兹曼机（Boltzmann Machine）算法实现
    实现3个神经元的玻尔兹曼机，可视化运行过程并确保网络达到热平衡状态
    """
    def __init__(self, dataset=None, total_epoches=100, initial_temperature=10.0,
                 cooling_rate=0.95, min_temperature=0.1, num_neurons=3):
        # BM算法不需要数据集，但为了兼容基类，传入空列表
        if dataset is None:
            dataset = []
        super().__init__(dataset, total_epoches)
        self._initial_temperature = initial_temperature
        self._cooling_rate = cooling_rate
        self._min_temperature = min_temperature
        self._num_neurons = num_neurons
        
        # 权重矩阵（对称矩阵，无自连接）
        self._weights = np.zeros((num_neurons, num_neurons))
        # 偏置向量
        self._biases = np.zeros(num_neurons)
        # 神经元状态（0或1）
        self._neuron_states = np.random.randint(0, 2, num_neurons)
        # 能量历史
        self._energy_history = []
        # 状态历史
        self._state_history = []
        
        self.current_iterations = 0
        self.current_temperature = initial_temperature
        self.current_energy = 0.0
        self.equilibrium_reached = False
        
        # 初始化权重和偏置
        self._initialize_weights()
    
    def _initialize_weights(self):
        """初始化权重矩阵和偏置"""
        # 随机初始化权重（对称矩阵，对角线为0）
        np.random.seed(42)
        for i in range(self._num_neurons):
            for j in range(i + 1, self._num_neurons):
                weight = np.random.uniform(-0.5, 0.5)
                self._weights[i, j] = weight
                self._weights[j, i] = weight  # 对称矩阵
        
        # 随机初始化偏置
        self._biases = np.random.uniform(-0.3, 0.3, self._num_neurons)
    
    def run(self):
        """运行玻尔兹曼机训练过程"""
        self._initialize_neurons()
        for self.current_iterations in range(self._total_epoches):
            if self._should_stop:
                break
            
            # 更新温度（模拟退火）
            self.current_temperature = max(
                self._initial_temperature * (self._cooling_rate ** self.current_iterations),
                self._min_temperature
            )
            
            # 执行一次迭代
            self._iterate()
            
            # 检查是否达到热平衡（需要至少30次迭代才能检测）
            if self.current_iterations >= 30:
                self._check_equilibrium()
                # 如果已经达到平衡，可以提前结束（可选）
                # if self.equilibrium_reached:
                #     break
    
    def _initialize_neurons(self):
        """初始化神经元状态"""
        # 随机初始化神经元状态
        self._neuron_states = np.random.randint(0, 2, self._num_neurons)
        self.current_energy = self._calculate_energy()
        self._energy_history = [self.current_energy]
        self._state_history = [self._neuron_states.copy()]
        self.equilibrium_reached = False
    
    def _iterate(self):
        """执行一次迭代：使用吉布斯采样更新神经元状态"""
        # 对每个神经元进行更新
        for _ in range(self._num_neurons):
            # 随机选择一个神经元
            neuron_idx = random.randint(0, self._num_neurons - 1)
            
            # 计算该神经元的输入（来自其他神经元）
            input_sum = np.sum(self._weights[neuron_idx, :] * self._neuron_states) + self._biases[neuron_idx]
            
            # 计算激活概率（使用玻尔兹曼分布）
            # P(s_i=1) = 1 / (1 + exp(-input_sum / T))
            if self.current_temperature > 0:
                prob = 1.0 / (1.0 + math.exp(-input_sum / self.current_temperature))
            else:
                prob = 1.0 if input_sum > 0 else 0.0
            
            # 根据概率更新神经元状态
            if random.random() < prob:
                new_state = 1
            else:
                new_state = 0
            
            # 更新状态
            self._neuron_states[neuron_idx] = new_state
        
        # 计算当前能量
        self.current_energy = self._calculate_energy()
        self._energy_history.append(self.current_energy)
        self._state_history.append(self._neuron_states.copy())
    
    def _calculate_energy(self):
        """
        计算玻尔兹曼机的能量函数
        E = -0.5 * sum_i sum_j w_ij * s_i * s_j - sum_i b_i * s_i
        """
        energy = 0.0
        # 计算权重项
        for i in range(self._num_neurons):
            for j in range(self._num_neurons):
                if i != j:
                    energy -= 0.5 * self._weights[i, j] * self._neuron_states[i] * self._neuron_states[j]
        # 计算偏置项
        energy -= np.sum(self._biases * self._neuron_states)
        return energy
    
    def _check_equilibrium(self):
        """
        检查是否达到热平衡状态
        热平衡：能量变化很小，状态趋于稳定
        """
        # 需要至少30次迭代才能检测平衡（降低要求）
        if len(self._energy_history) < 30:
            return
        
        # 检查最近30次迭代的能量变化
        recent_energies = self._energy_history[-30:]
        energy_std = np.std(recent_energies)
        energy_mean = np.mean(recent_energies)
        energy_range = np.max(recent_energies) - np.min(recent_energies)
        
        # 根据温度调整检测阈值：温度越低，越容易达到平衡
        # 使用更简单的线性缩放
        if self.current_temperature > self._min_temperature:
            # 温度因子：当温度接近最小温度时，因子接近1
            temperature_factor = max(1.0, (self.current_temperature - self._min_temperature) / self._min_temperature)
        else:
            temperature_factor = 1.0
        
        # 方法1：如果温度已经很低，使用非常宽松的条件
        if self.current_temperature <= self._min_temperature * 2.0:
            # 在低温时，只要能量标准差不太大就认为平衡
            if energy_std < 3.0:  # 非常宽松的条件
                self.equilibrium_reached = True
                return
        
        # 方法2：使用相对标准差（适用于能量均值不为0的情况）
        if abs(energy_mean) > 0.01:
            relative_std = abs(energy_std / energy_mean)
            # 根据温度调整阈值：高温时阈值更大，低温时阈值更小
            # 使用更宽松的阈值：从50%开始
            threshold = 0.50 / max(1.0, temperature_factor * 0.5)
            if relative_std < threshold:
                self.equilibrium_reached = True
                return
        
        # 方法3：使用绝对标准差（适用于能量均值接近0的情况）
        # 根据温度调整阈值，使用更宽松的值
        abs_threshold = 1.0 / max(1.0, temperature_factor * 0.5)  # 从1.0开始
        if energy_std < abs_threshold:
            self.equilibrium_reached = True
            return
        
        # 方法4：使用能量范围（作为补充检测）
        # 如果能量范围很小，也认为达到平衡
        range_threshold = 2.0 / max(1.0, temperature_factor * 0.5)  # 从2.0开始
        if energy_range < range_threshold:
            self.equilibrium_reached = True
            return
        
        # 方法5：检查能量变化趋势（最后15次迭代的能量变化）
        if len(recent_energies) >= 15:
            last_15 = recent_energies[-15:]
            first_15 = recent_energies[:15]
            trend_change = abs(np.mean(last_15) - np.mean(first_15))
            if trend_change < 1.0 / max(1.0, temperature_factor * 0.5):  # 从1.0开始
                self.equilibrium_reached = True
                return
        
        # 方法6：如果迭代次数已经很多，且温度很低，强制认为达到平衡
        if self.current_iterations >= self._total_epoches * 0.7 and self.current_temperature <= self._min_temperature * 2:
            if energy_std < 3.5:  # 非常宽松的条件
                self.equilibrium_reached = True
                return
        
        # 方法7：如果迭代次数接近结束，使用最宽松的条件
        if self.current_iterations >= self._total_epoches * 0.9:
            if energy_std < 4.0:  # 极其宽松的条件
                self.equilibrium_reached = True
                return
    
    @property
    def current_data(self):
        # BM算法不依赖数据集
        return None
    
    @property
    def neuron_states(self):
        """返回当前神经元状态"""
        return self._neuron_states.copy()
    
    @property
    def weights(self):
        """返回权重矩阵"""
        return self._weights.copy()
    
    @property
    def biases(self):
        """返回偏置向量"""
        return self._biases.copy()
    
    @property
    def energy_history(self):
        """返回能量历史"""
        return self._energy_history.copy()
    
    @property
    def state_history(self):
        """返回状态历史"""
        return [state.copy() for state in self._state_history]

