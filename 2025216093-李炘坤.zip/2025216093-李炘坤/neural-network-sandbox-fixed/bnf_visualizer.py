import sys
import re
import json
from collections import defaultdict
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                             QGroupBox, QTabWidget, QSplitter, QTreeWidget, 
                             QTreeWidgetItem, QLineEdit, QMessageBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPalette, QColor, QSyntaxHighlighter, QTextCharFormat
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.patches as patches

class BNFHighlighter(QSyntaxHighlighter):
    """BNF语法高亮器"""
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # 定义高亮规则
        self.highlighting_rules = []
        
        # 非终结符（蓝色）
        non_terminal_format = QTextCharFormat()
        non_terminal_format.setForeground(QColor(86, 156, 214))
        non_terminal_format.setFontWeight(QFont.Bold)
        self.highlighting_rules.append((r'<[^>]+>', non_terminal_format))
        
        # 终结符（绿色）
        terminal_format = QTextCharFormat()
        terminal_format.setForeground(QColor(78, 201, 176))
        self.highlighting_rules.append((r'"[^"]*"', terminal_format))
        
        # 操作符（黄色）
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor(220, 220, 170))
        self.highlighting_rules.append((r'[|:=]', operator_format))
        
        # 注释（灰色）
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor(87, 166, 74))
        comment_format.setFontItalic(True)
        self.highlighting_rules.append((r'#.*$', comment_format))

    def highlightBlock(self, text):
        """高亮文本块"""
        for pattern, format in self.highlighting_rules:
            expression = re.compile(pattern)
            for match in expression.finditer(text):
                start, length = match.span()
                self.setFormat(start, length, format)

class BNFParser:
    """BNF语法解析器"""
    def __init__(self):
        self.productions = {}
        self.start_symbol = None
        self.parse_tree = None
        self.derivation_history = []
        
    def parse_grammar(self, grammar_text):
        """解析BNF语法"""
        self.productions = {}
        lines = grammar_text.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            # 解析产生式
            if ':=' in line:
                left, right = line.split(':=', 1)
                non_terminal = left.strip()
                
                if not self.start_symbol:
                    self.start_symbol = non_terminal
                    
                # 解析右侧的多个选择
                alternatives = [alt.strip() for alt in right.split('|')]
                self.productions[non_terminal] = []
                
                for alt in alternatives:
                    # 解析符号序列
                    symbols = []
                    tokens = re.findall(r'<[^>]+>|"[^"]*"|\S+', alt)
                    for token in tokens:
                        if token.startswith('<') and token.endswith('>'):
                            symbols.append(('non_terminal', token[1:-1]))
                        elif token.startswith('"') and token.endswith('"'):
                            symbols.append(('terminal', token[1:-1]))
                        else:
                            symbols.append(('terminal', token))
                    self.productions[non_terminal].append(symbols)
        
        return True
    
    def parse_string(self, input_string, start_symbol=None):
        """解析输入字符串"""
        if not start_symbol:
            start_symbol = self.start_symbol
            
        if not start_symbol or start_symbol not in self.productions:
            return False, "无效的起始符号"
            
        self.derivation_history = []
        self.parse_tree = {'symbol': start_symbol, 'children': [], 'type': 'non_terminal'}
        
        result, remaining = self._parse_recursive(input_string.strip(), start_symbol, self.parse_tree)
        
        if result and not remaining:
            return True, "解析成功"
        else:
            return False, f"解析失败，剩余: {remaining}"
    
    def _parse_recursive(self, input_string, symbol, tree_node):
        """递归解析"""
        self.derivation_history.append(f"尝试解析: {symbol} 剩余输入: '{input_string}'")
        
        # 如果是终结符
        if symbol.startswith('"') and symbol.endswith('"'):
            terminal = symbol[1:-1]
            if input_string.startswith(terminal):
                tree_node['children'].append({'symbol': terminal, 'children': [], 'type': 'terminal'})
                return True, input_string[len(terminal):].strip()
            return False, input_string
        
        # 如果是非终结符
        if symbol in self.productions:
            # 尝试每个产生式
            for production in self.productions[symbol]:
                original_children_count = len(tree_node['children'])
                remaining = input_string
                success = True
                
                for sym_type, sym_name in production:
                    child_node = {'symbol': sym_name, 'children': [], 'type': sym_type}
                    result, remaining = self._parse_recursive(remaining, 
                                                             f'<{sym_name}>' if sym_type == 'non_terminal' else f'"{sym_name}"',
                                                             child_node)
                    if not result:
                        success = False
                        # 回滚添加的子节点
                        tree_node['children'] = tree_node['children'][:original_children_count]
                        break
                    tree_node['children'].append(child_node)
                
                if success:
                    return True, remaining
            
        return False, input_string
    
    def get_derivation_tree(self):
        """获取推导树"""
        return self.parse_tree
    
    def get_derivation_history(self):
        """获取推导历史"""
        return self.derivation_history

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class BNFVisualizer(QMainWindow):
    """BNF语法可视化器"""
    
    def __init__(self):
        super().__init__()
        self.parser = BNFParser()
        self.current_grammar = ""
        self.current_input = ""
        
        self.init_ui()
        self.load_sample_grammar()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("BNF语法解析可视化器")
        self.setGeometry(100, 100, 1600, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧输入面板
        input_panel = self.create_input_panel()
        main_layout.addWidget(input_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(input_panel, 1)
        main_layout.setStretchFactor(visualization_area, 2)
        
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.Highlight, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_input_panel(self):
        """创建输入面板"""
        input_group = QGroupBox("输入面板")
        input_layout = QVBoxLayout(input_group)
        
        # 语法输入区域
        grammar_label = QLabel("BNF语法定义:")
        grammar_label.setFont(QFont("Arial", 10, QFont.Bold))
        input_layout.addWidget(grammar_label)
        
        self.grammar_edit = QTextEdit()
        self.grammar_edit.setMaximumHeight(300)
        self.grammar_edit.setFont(QFont("Consolas", 9))
        self.highlighter = BNFHighlighter(self.grammar_edit.document())
        input_layout.addWidget(self.grammar_edit)
        
        # 测试输入区域
        input_label = QLabel("测试字符串:")
        input_label.setFont(QFont("Arial", 10, QFont.Bold))
        input_layout.addWidget(input_label)
        
        self.input_edit = QTextEdit()
        self.input_edit.setMaximumHeight(100)
        self.input_edit.setFont(QFont("Consolas", 9))
        input_layout.addWidget(self.input_edit)
        
        # 控制按钮
        buttons_layout = QHBoxLayout()
        
        self.parse_btn = QPushButton("解析语法")
        self.parse_btn.clicked.connect(self.parse_grammar)
        buttons_layout.addWidget(self.parse_btn)
        
        self.test_btn = QPushButton("测试解析")
        self.test_btn.clicked.connect(self.test_parsing)
        buttons_layout.addWidget(self.test_btn)
        
        self.clear_btn = QPushButton("清空")
        self.clear_btn.clicked.connect(self.clear_all)
        buttons_layout.addWidget(self.clear_btn)
        
        input_layout.addLayout(buttons_layout)
        
        # 示例语法选择
        examples_layout = QHBoxLayout()
        examples_label = QLabel("示例语法:")
        examples_layout.addWidget(examples_label)
        
        self.examples_combo = QLineEdit()
        self.examples_combo.setPlaceholderText("选择示例或输入自定义语法")
        examples_layout.addWidget(self.examples_combo)
        
        self.load_example_btn = QPushButton("加载")
        self.load_example_btn.clicked.connect(self.load_example)
        examples_layout.addWidget(self.load_example_btn)
        
        input_layout.addLayout(examples_layout)
        
        # 解析结果
        result_label = QLabel("解析结果:")
        result_label.setFont(QFont("Arial", 10, QFont.Bold))
        input_layout.addWidget(result_label)
        
        self.result_edit = QTextEdit()
        self.result_edit.setMaximumHeight(150)
        self.result_edit.setReadOnly(True)
        input_layout.addWidget(self.result_edit)
        
        return input_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 语法树标签页
        tree_tab = QWidget()
        tree_layout = QVBoxLayout(tree_tab)
        self.tree_canvas = MplCanvas(self, width=10, height=8)
        tree_layout.addWidget(self.tree_canvas)
        visualization_widget.addTab(tree_tab, "语法树")
        
        # 产生式图表标签页
        production_tab = QWidget()
        production_layout = QVBoxLayout(production_tab)
        self.production_canvas = MplCanvas(self, width=10, height=8)
        production_layout.addWidget(self.production_canvas)
        visualization_widget.addTab(production_tab, "产生式图表")
        
        # 推导历史标签页
        history_tab = QWidget()
        history_layout = QVBoxLayout(history_tab)
        self.history_tree = QTreeWidget()
        self.history_tree.setHeaderLabels(["推导步骤"])
        history_layout.addWidget(self.history_tree)
        visualization_widget.addTab(history_tab, "推导历史")
        
        return visualization_widget
    
    def load_sample_grammar(self):
        """加载示例语法"""
        sample_grammar = """
# 简单算术表达式语法
<expression> := <term> | <expression> "+" <term> | <expression> "-" <term>
<term> := <factor> | <term> "*" <factor> | <term> "/" <factor>
<factor> := <number> | "(" <expression> ")"
<number> := <digit> | <number> <digit>
<digit> := "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9"
"""
        self.grammar_edit.setPlainText(sample_grammar.strip())
        self.examples_combo.setText("算术表达式")
        
    def parse_grammar(self):
        """解析BNF语法"""
        grammar_text = self.grammar_edit.toPlainText()
        success = self.parser.parse_grammar(grammar_text)
        
        if success:
            self.result_edit.setText("语法解析成功！")
            self.update_visualizations()
        else:
            self.result_edit.setText("语法解析失败，请检查语法格式")
    
    def test_parsing(self):
        """测试字符串解析"""
        input_string = self.input_edit.toPlainText()
        success, message = self.parser.parse_string(input_string)
        
        self.result_edit.setText(message)
        if success:
            self.update_visualizations()
    
    def clear_all(self):
        """清空所有内容"""
        self.grammar_edit.clear()
        self.input_edit.clear()
        self.result_edit.clear()
        self.history_tree.clear()
        
    def load_example(self):
        """加载示例语法"""
        example_name = self.examples_combo.text().strip()
        
        if example_name == "算术表达式":
            grammar = """
<expression> := <term> | <expression> "+" <term> | <expression> "-" <term>
<term> := <factor> | <term> "*" <factor> | <term> "/" <factor>
<factor> := <number> | "(" <expression> ")"
<number> := <digit> | <number> <digit>
<digit> := "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9"
"""
        elif example_name == "简单语句":
            grammar = """
<program> := <statement> | <program> <statement>
<statement> := <assignment> | <if_statement> | <while_statement>
<assignment> := <variable> "=" <expression>
<if_statement> := "if" <condition> "then" <statement>
<while_statement> := "while" <condition> "do" <statement>
<condition> := <expression> <comparison> <expression>
<comparison> := "<" | ">" | "==" | "!="
<expression> := <term> | <expression> "+" <term> | <expression> "-" <term>
<term> := <factor> | <term> "*" <factor> | <term> "/" <factor>
<factor> := <number> | <variable> | "(" <expression> ")"
<variable> := <letter> | <variable> <letter>
<letter> := "a" | "b" | "c" | "d" | "e" | "f" | "g" | "h" | "i" | "j"
<number> := <digit> | <number> <digit>
<digit> := "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9"
"""
        else:
            # 使用自定义语法
            grammar = example_name if example_name else ""
        
        if grammar:
            self.grammar_edit.setPlainText(grammar.strip())
    
    def update_visualizations(self):
        """更新所有可视化"""
        self.plot_parse_tree()
        self.plot_production_graph()
        self.update_derivation_history()
    
    def plot_parse_tree(self):
        """绘制解析树"""
        self.tree_canvas.fig.clear()
        ax = self.tree_canvas.fig.add_subplot(111)
        
        tree_data = self.parser.get_derivation_tree()
        if tree_data:
            self._plot_tree_recursive(ax, tree_data, 0, 0, 1)
            ax.set_title('解析树', fontsize=12, color='white')
            ax.set_facecolor('#2b2b2b')
            self.tree_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
            ax.axis('off')
        
        self.tree_canvas.draw()
    
    def _plot_tree_recursive(self, ax, node, x, y, level):
        """递归绘制树节点"""
        if not node:
            return x
            
        # 绘制当前节点
        color = 'lightblue' if node['type'] == 'non_terminal' else 'lightgreen'
        circle = patches.Circle((x, -level), 0.3, facecolor=color, edgecolor='black')
        ax.add_patch(circle)
        ax.text(x, -level, node['symbol'], ha='center', va='center', fontsize=8)
        
        # 绘制子节点
        if node['children']:
            child_x = x - (len(node['children']) - 1) * 0.8 / 2
            for child in node['children']:
                # 绘制连接线
                ax.plot([x, child_x], [-level, -level-1], 'k-', linewidth=1)
                # 递归绘制子节点
                child_x = self._plot_tree_recursive(ax, child, child_x, y, level+1)
                child_x += 0.8
        
        return x
    
    def plot_production_graph(self):
        """绘制产生式关系图"""
        self.production_canvas.fig.clear()
        ax = self.production_canvas.fig.add_subplot(111)
        
        # 创建有向图
        G = nx.DiGraph()
        
        # 添加节点和边
        for non_terminal, productions in self.parser.productions.items():
            G.add_node(non_terminal, type='non_terminal')
            for production in productions:
                for sym_type, sym_name in production:
                    if sym_type == 'non_terminal':
                        G.add_edge(non_terminal, sym_name)
        
        # 绘制图形
        if G.nodes():
            pos = nx.spring_layout(G, k=2, iterations=50)
            
            # 绘制节点
            nx.draw_networkx_nodes(G, pos, node_color='lightblue', 
                                 node_size=2000, alpha=0.7, ax=ax)
            
            # 绘制边
            nx.draw_networkx_edges(G, pos, edge_color='gray', 
                                 arrows=True, arrowsize=20, ax=ax)
            
            # 绘制标签
            nx.draw_networkx_labels(G, pos, font_size=8, font_weight='bold', ax=ax)
            
            ax.set_title('产生式关系图', fontsize=12, color='white')
            ax.set_facecolor('#2b2b2b')
            self.production_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
            ax.axis('off')
        
        self.production_canvas.draw()
    
    def update_derivation_history(self):
        """更新推导历史"""
        self.history_tree.clear()
        history = self.parser.get_derivation_history()
        
        for i, step in enumerate(history):
            item = QTreeWidgetItem([f"步骤 {i+1}: {step}"])
            self.history_tree.addTopLevelItem(item)
        
        # 展开所有项
        self.history_tree.expandAll()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = BNFVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()