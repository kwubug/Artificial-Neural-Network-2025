import numpy as np
import threading


class SOM2Neuron:
    """SOM2神经元类"""

    def __init__(self, input_dim):
        """
        初始化神经元
        Args:
            input_dim: 输入向量维度（4维）
        """
        # 随机初始化权重向量 [0, 1]
        self.synaptic_weight = np.random.rand(input_dim)


class Som2Algorithm(threading.Thread):
    """
    SOM2算法实现类
    继承自Thread以支持异步训练
    """

    def __init__(self, dataset, total_epoches, initial_learning_rate,
                 initial_standard_deviation, topology_shape):
        """
        初始化SOM2算法

        Args:
            dataset: 训练数据集字典，包含'inputs'键
            total_epoches: 总训练轮数（实际总步数 = total_epoches）
            initial_learning_rate: 初始学习率 (0.5)
            initial_standard_deviation: 初始邻域半径 (2.0)
            topology_shape: 网络拓扑形状 [5, 5]
        """
        super().__init__()

        # 处理数据集格式
        if isinstance(dataset, dict) and 'inputs' in dataset:
            self.dataset = np.array(dataset['inputs'])
        else:
            self.dataset = np.array(dataset)

        self.total_epoches = total_epoches
        self.initial_learning_rate = initial_learning_rate
        self.initial_standard_deviation = initial_standard_deviation
        self.topology_shape = topology_shape

        # 初始化神经元网格
        self._neurons = []
        self._init_neurons()

        # 训练控制变量
        self.current_iterations = 0
        self._should_stop = False

    def _init_neurons(self):
        """初始化5×5神经元网格"""
        rows, cols = self.topology_shape
        input_dim = self.dataset.shape[1] if len(self.dataset.shape) > 1 else 4

        self._neurons = []
        for i in range(rows):
            row = []
            for j in range(cols):
                neuron = SOM2Neuron(input_dim)
                row.append(neuron)
            self._neurons.append(row)

    @property
    def current_learning_rate(self):
        """
        计算当前学习率
        前1000步：从0.5线性下降到0.04
        1000步后：从0.04线性下降到0
        """
        if self.current_iterations <= 1000:
            # 前1000步线性衰减到0.04
            decay = (self.initial_learning_rate - 0.04) / 1000.0
            return self.initial_learning_rate - decay * self.current_iterations
        elif self.current_iterations < 10000:
            # 1000-10000步从0.04衰减到0
            decay = 0.04 / 9000.0
            return 0.04 - decay * (self.current_iterations - 1000)
        else:
            return 0.0

    @property
    def current_standard_deviation(self):
        """
        计算当前邻域半径
        前1000步：从2.0线性下降到0
        1000步后：保持为0
        """
        if self.current_iterations <= 1000:
            # 前1000步线性衰减到0
            decay = self.initial_standard_deviation / 1000.0
            return self.initial_standard_deviation - decay * self.current_iterations
        else:
            return 0.0

    def _find_winner_neuron(self, input_vector):
        """
        找到最佳匹配单元(BMU/优胜神经元)

        Args:
            input_vector: 输入向量

        Returns:
            winner_neuron: 优胜神经元对象
        """
        min_distance = float('inf')
        winner = None

        for row in self._neurons:
            for neuron in row:
                # 计算欧氏距离
                distance = np.linalg.norm(input_vector - neuron.synaptic_weight)
                if distance < min_distance:
                    min_distance = distance
                    winner = neuron

        return winner

    def _get_neuron_position(self, target_neuron):
        """获取神经元在网格中的位置"""
        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                if neuron == target_neuron:
                    return (i, j)
        return None

    def _calculate_influence(self, winner_pos, neuron_pos, radius):
        """
        计算邻域影响函数（高斯函数）

        Args:
            winner_pos: 优胜神经元位置 (row, col)
            neuron_pos: 当前神经元位置 (row, col)
            radius: 当前邻域半径

        Returns:
            影响系数
        """
        if radius <= 0:
            # 半径为0时只更新优胜神经元
            return 1.0 if winner_pos == neuron_pos else 0.0

        # 计算网格距离
        distance = np.sqrt((winner_pos[0] - neuron_pos[0]) ** 2 +
                           (winner_pos[1] - neuron_pos[1]) ** 2)

        # 高斯邻域函数
        return np.exp(-(distance ** 2) / (2 * radius ** 2))

    def _update_weights(self, input_vector, winner):
        """
        更新权重

        Args:
            input_vector: 输入向量
            winner: 优胜神经元
        """
        winner_pos = self._get_neuron_position(winner)
        if winner_pos is None:
            return

        learning_rate = self.current_learning_rate
        radius = self.current_standard_deviation

        # 更新所有神经元的权重
        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                # 计算邻域影响
                influence = self._calculate_influence(winner_pos, (i, j), radius)

                # 权重更新公式：w = w + η * h * (x - w)
                if influence > 0:
                    delta = learning_rate * influence * (input_vector - neuron.synaptic_weight)
                    neuron.synaptic_weight += delta

    def _iterate(self):
        """执行一次迭代"""
        # 随机选择一个输入模式
        idx = np.random.randint(0, len(self.dataset))
        input_vector = self.dataset[idx]

        # 竞争：找到优胜神经元
        winner = self._find_winner_neuron(input_vector)

        # 合作与适应：更新权重
        self._update_weights(input_vector, winner)

        # 增加迭代计数
        self.current_iterations += 1

    def run(self):
        """运行训练主循环"""
        while self.current_iterations < self.total_epoches:
            if self._should_stop:
                break
            self._iterate()

    def stop(self):
        """停止训练"""
        self._should_stop = True


# 为了兼容性，也提供SomAlgorithm别名
SomAlgorithm = Som2Algorithm

if __name__ == "__main__":
    # 测试代码
    print("测试SOM2算法")
    print("=" * 50)

    # 定义5个输入模式
    patterns = {
        'inputs': [
            [1, 0, 0, 0],  # X1
            [1, 1, 0, 0],  # X2
            [1, 1, 1, 0],  # X3
            [0, 1, 0, 0],  # X4
            [1, 1, 1, 1]  # X5
        ]
    }

    # 创建算法实例
    som = Som2Algorithm(
        dataset=patterns,
        total_epoches=10000,
        initial_learning_rate=0.5,
        initial_standard_deviation=2.0,
        topology_shape=[5, 5]
    )

    print(f"输入模式数: {len(patterns['inputs'])}")
    print(f"网络规模: 5×5")
    print(f"总步数: 10000")
    print("-" * 50)

    # 测试一些关键步骤的参数
    test_steps = [0, 500, 1000, 5000, 9999]

    for step in test_steps:
        som.current_iterations = step
        print(f"步 {step:5d}: η={som.current_learning_rate:.4f}, σ={som.current_standard_deviation:.4f}")