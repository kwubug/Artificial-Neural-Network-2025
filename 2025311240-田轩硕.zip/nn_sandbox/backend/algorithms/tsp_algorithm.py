import numpy as np
import threading
from typing import List, Tuple


class TSPAlgorithm(threading.Thread):
    """使用遗传算法求解旅行商问题"""
    
    def __init__(self, cities, population_size=100, generations=500, 
                 mutation_rate=0.01, elite_size=20):
        super().__init__()
        self.cities = np.array(cities)  # 城市坐标列表 [(x1, y1), (x2, y2), ...]
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.elite_size = elite_size
        
        self.current_generation = 0
        self.current_best_route = []
        self.current_best_distance = float('inf')
        self.best_distance_history = []
        self.avg_distance_history = []
        self._should_stop = False
        
        self.population = []
        
    def stop(self):
        self._should_stop = True
        
    def run(self):
        """运行遗传算法"""
        # 检查城市数量
        if len(self.cities) < 2:
            print("Error: Need at least 2 cities")
            return
            
        # 初始化种群
        self._initialize_population()
        
        for self.current_generation in range(self.generations):
            if self._should_stop:
                break
                
            # 评估适应度
            fitness_scores = self._evaluate_fitness()
            
            # 记录最佳路径
            best_idx = np.argmax(fitness_scores)
            best_route = self.population[best_idx]
            best_distance = self._calculate_route_distance(best_route)
            
            if best_distance < self.current_best_distance:
                self.current_best_distance = best_distance
                self.current_best_route = best_route.copy()
            
            self.best_distance_history.append(self.current_best_distance)
            self.avg_distance_history.append(
                np.mean([self._calculate_route_distance(route) for route in self.population])
            )
            
            # 选择、交叉、变异产生新种群
            self.population = self._evolve_population(fitness_scores)
    
    def _initialize_population(self):
        """初始化种群：随机生成多个路径"""
        num_cities = len(self.cities)
        self.population = []
        for _ in range(self.population_size):
            route = np.random.permutation(num_cities)
            self.population.append(route)
    
    def _calculate_distance(self, city1_idx, city2_idx):
        """计算两个城市之间的欧氏距离"""
        city1 = self.cities[city1_idx]
        city2 = self.cities[city2_idx]
        return np.sqrt(np.sum((city1 - city2) ** 2))
    
    def _calculate_route_distance(self, route):
        """计算路径总距离"""
        total_distance = 0
        for i in range(len(route)):
            total_distance += self._calculate_distance(route[i], route[(i + 1) % len(route)])
        return total_distance
    
    def _evaluate_fitness(self):
        """评估种群中每个个体的适应度（距离越短，适应度越高）"""
        fitness_scores = []
        for route in self.population:
            distance = self._calculate_route_distance(route)
            # 适应度为距离的倒数
            fitness_scores.append(1 / distance if distance > 0 else 0)
        return np.array(fitness_scores)
    
    def _selection(self, fitness_scores):
        """轮盘赌选择"""
        # 归一化适应度
        fitness_sum = np.sum(fitness_scores)
        if fitness_sum == 0:
            probabilities = np.ones(len(fitness_scores)) / len(fitness_scores)
        else:
            probabilities = fitness_scores / fitness_sum
        
        # 根据概率选择
        selected_idx = np.random.choice(len(self.population), p=probabilities)
        return self.population[selected_idx].copy()
    
    def _crossover(self, parent1, parent2):
        """顺序交叉（Order Crossover, OX）"""
        size = len(parent1)
        
        # 随机选择两个交叉点
        start, end = sorted(np.random.choice(size, 2, replace=False))
        
        # 创建子代
        child = np.full(size, -1)
        child[start:end] = parent1[start:end]
        
        # 从parent2填充剩余位置
        current_pos = end
        for gene in parent2:
            if gene not in child:
                if current_pos >= size:
                    current_pos = 0
                child[current_pos] = gene
                current_pos += 1
        
        return child
    
    def _mutate(self, route):
        """变异：交换两个城市的位置"""
        if np.random.random() < self.mutation_rate:
            idx1, idx2 = np.random.choice(len(route), 2, replace=False)
            route[idx1], route[idx2] = route[idx2], route[idx1]
        return route
    
    def _evolve_population(self, fitness_scores):
        """进化产生新种群"""
        new_population = []
        
        # 精英保留
        elite_indices = np.argsort(fitness_scores)[-self.elite_size:]
        for idx in elite_indices:
            new_population.append(self.population[idx].copy())
        
        # 生成剩余个体
        while len(new_population) < self.population_size:
            parent1 = self._selection(fitness_scores)
            parent2 = self._selection(fitness_scores)
            child = self._crossover(parent1, parent2)
            child = self._mutate(child)
            new_population.append(child)
        
        return new_population
    
    def get_best_route_coordinates(self):
        """获取最佳路径的坐标序列"""
        if len(self.current_best_route) == 0:
            return []
        route_coords = [self.cities[idx].tolist() for idx in self.current_best_route]
        # 添加回到起点的路径
        route_coords.append(self.cities[self.current_best_route[0]].tolist())
        return route_coords
