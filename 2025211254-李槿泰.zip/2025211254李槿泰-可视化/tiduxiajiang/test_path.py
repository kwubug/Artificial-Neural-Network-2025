#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试路径绘制是否正确贴合曲面
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 设置中文字体
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

def rosenbrock_function(x):
    """Rosenbrock函数"""
    return 100 * (x[1] - x[0]**2)**2 + (1 - x[0])**2

def simple_gradient_descent(x0, max_iter=10):
    """简单的梯度下降法"""
    path = [x0.copy()]
    x = x0.copy()
    
    for i in range(max_iter):
        # 计算梯度
        grad = np.array([
            -400 * x[0] * (x[1] - x[0]**2) - 2 * (1 - x[0]),
            200 * (x[1] - x[0]**2)
        ])
        
        # 更新位置
        x = x - 0.01 * grad
        path.append(x.copy())
        
        print(f"迭代 {i+1}: ({x[0]:.3f}, {x[1]:.3f}) -> f = {rosenbrock_function(x):.3f}")
    
    return path

# 创建图形
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 绘制函数表面
x_range = [-1.5, 2.5]
y_range = [-0.5, 3.5]
X = np.linspace(x_range[0], x_range[1], 50)
Y = np.linspace(y_range[0], y_range[1], 50)
X, Y = np.meshgrid(X, Y)
Z = np.zeros_like(X)

for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        Z[i, j] = rosenbrock_function(np.array([X[i, j], Y[i, j]]))

# 限制Z值范围
Z = np.clip(Z, 0, 1000)

# 绘制表面
ax.plot_surface(X, Y, Z, alpha=0.6, cmap='viridis', vmin=0, vmax=1000)

# 运行梯度下降
x0 = np.array([-1.5, 2.0])
path = simple_gradient_descent(x0, max_iter=10)

# 绘制路径
path_array = np.array(path)
x_path = path_array[:, 0]
y_path = path_array[:, 1]
z_path = [rosenbrock_function(point) for point in path]

print(f"\n路径点数量: {len(path)}")
print(f"起点: ({x_path[0]:.3f}, {y_path[0]:.3f}, {z_path[0]:.3f})")
print(f"终点: ({x_path[-1]:.3f}, {y_path[-1]:.3f}, {z_path[-1]:.3f})")

# 绘制路径
ax.plot(x_path, y_path, z_path, 'r-', linewidth=3, label='优化路径')
ax.scatter(x_path, y_path, z_path, c='red', s=50)

# 标记起点和终点
ax.scatter(x_path[0], y_path[0], z_path[0], c='green', s=100, marker='o', label='起点')
ax.scatter(x_path[-1], y_path[-1], z_path[-1], c='yellow', s=100, marker='*', label='终点')

# 设置标签
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('路径贴合曲面测试')

# 设置坐标轴范围
ax.set_xlim(x_range)
ax.set_ylim(y_range)
ax.set_zlim(0, 1000)

plt.legend()
plt.tight_layout()
plt.savefig('path_test.png', dpi=150, bbox_inches='tight')
plt.show()

print("测试完成，请检查path_test.png文件")

