import numpy as np
import random
from PyQt5.QtCore import QObject, pyqtSignal, pyqtProperty, pyqtSlot, QTimer


class HopfieldNetwork(QObject):
    """离散型Hopfield神经网络模型（25个神经元，5x5网格）"""

    # 信号定义
    neuronsChanged = pyqtSignal()
    energyChanged = pyqtSignal()
    iterationChanged = pyqtSignal()
    attractorFound = pyqtSignal(list, float)  # 吸引子状态和能量
    updateLog = pyqtSignal(str)  # 更新日志

    def __init__(self, num_neurons=25):
        super().__init__()
        self._num_neurons = num_neurons
        self._neurons = np.random.choice([-1, 1], size=num_neurons)
        self._weights = np.zeros((num_neurons, num_neurons))
        self._energy = 0
        self._iteration = 0
        self._is_running = False
        self._energy_history = []
        self._attractors = []  # 存储发现的吸引子
        self._current_attractor = None
        self._patterns = []  # 存储训练模式

        self.timer = QTimer()
        self.timer.timeout.connect(self.async_update)

        # 初始化能量
        self._energy = self.calculate_energy()
        self._energy_history.append(self._energy)

    @pyqtProperty(list, notify=neuronsChanged)
    def neurons(self):
        return self._neurons.tolist()

    @pyqtProperty(float, notify=energyChanged)
    def energy(self):
        return self._energy

    @pyqtProperty(int, notify=iterationChanged)
    def iteration(self):
        return self._iteration

    @pyqtProperty(list, notify=energyChanged)
    def energyHistory(self):
        return self._energy_history[-50:]  # 返回最近50个能量值

    @pyqtProperty(bool)
    def isRunning(self):
        return self._is_running

    @pyqtProperty(list)
    def patterns(self):
        return [pattern.tolist() for pattern in self._patterns]

    @pyqtProperty(list)
    def attractors(self):
        return [attractor.tolist() for attractor in self._attractors]

    @pyqtProperty(str)
    def currentAttractor(self):
        if self._current_attractor is not None:
            return str(self._current_attractor.tolist())
        return "无"

    def calculate_energy(self):
        """计算Hopfield网络能量"""
        energy = 0
        for i in range(self._num_neurons):
            for j in range(i + 1, self._num_neurons):
                if i != j:
                    energy -= 0.5 * self._weights[i, j] * self._neurons[i] * self._neurons[j]
        return energy

    def train_pattern(self, pattern):
        ###训练模式
        pattern_array = np.array(pattern)
        if len(pattern_array) != self._num_neurons:
            raise ValueError("模式维度不匹配")
        # 使用外积规则更新权重
        for i in range(self._num_neurons):
            for j in range(self._num_neurons):
                if i != j:
                    self._weights[i, j] += pattern_array[i] * pattern_array[j]

        self._patterns.append(pattern_array)
        self.updateLog.emit(f"训练模式完成")
    def train_patterns(self, patterns):
        self._weights = np.zeros((self._num_neurons, self._num_neurons))
        self._patterns = []

        for pattern in patterns:
            self.train_pattern(pattern)

        self.updateLog.emit(f"训练完成！共训练 {len(patterns)} 个模式")

    def async_update(self):
        """异步更新：随机选择一个神经元更新"""
        if not self._is_running:
            return
        # 随机选择一个神经元
        neuron_idx = random.randint(0, self._num_neurons - 1)
        input_sum = 0
        for j in range(self._num_neurons):
            if j != neuron_idx:
                input_sum += self._weights[neuron_idx, j] * self._neurons[j]

        # 更新神经元状态
        new_state = 1 if input_sum >= 0 else -1

        if new_state != self._neurons[neuron_idx]:
            self._neurons[neuron_idx] = new_state
            self.neuronsChanged.emit()
            self.updateLog.emit(f"迭代 {self._iteration}: 神经元 {neuron_idx} 更新")

        # 更新能量
        old_energy = self._energy
        self._energy = self.calculate_energy()
        self._energy_history.append(self._energy)

        self._iteration += 1
        self.energyChanged.emit()
        self.iterationChanged.emit()

        # 检查是否达到吸引子
        self.check_attractor(old_energy)

    def check_attractor(self, old_energy):
        """检查是否达到吸引子"""
        if len(self._energy_history) < 10:
            return

        # 检查能量稳定
        recent_energies = self._energy_history[-10:]
        energy_std = np.std(recent_energies)

        if energy_std < 0.001 and abs(old_energy - self._energy) < 0.001:
            # 检查是否为新的吸引子
            if self.is_new_attractor(self._neurons):
                self._attractors.append(self._neurons.copy())
                self._current_attractor = self._neurons.copy()
                self.attractorFound.emit(self._neurons.tolist(), self._energy)
                self.updateLog.emit(f"🎯 发现吸引子！能量: {self._energy:.4f}")

    def is_new_attractor(self, state):
        """检查是否为新的吸引子"""
        state_array = np.array(state)
        for attractor in self._attractors:
            if np.array_equal(attractor, state_array) or np.array_equal(attractor, -state_array):
                return False
        return True

    @pyqtSlot()
    def start_simulation(self):
        """开始模拟"""
        self._is_running = True
        self.timer.start(200)  # 200ms更新间隔
        self.updateLog.emit("🚀 开始Hopfield网络模拟")

    @pyqtSlot()
    def stop_simulation(self):
        """停止模拟"""
        self._is_running = False
        self.timer.stop()
        self.updateLog.emit("⏹️ 模拟停止")

    @pyqtSlot()
    def reset_network(self):
        """重置网络"""
        self.stop_simulation()
        self._neurons = np.random.choice([-1, 1], size=self._num_neurons)
        self._energy = self.calculate_energy()
        self._iteration = 0
        self._energy_history = [self._energy]
        self._current_attractor = None

        self.neuronsChanged.emit()
        self.energyChanged.emit()
        self.iterationChanged.emit()
        self.updateLog.emit("🔄 网络已重置")

    @pyqtSlot(list)
    def set_neurons(self, neurons):
        """设置神经元状态"""
        self._neurons = np.array(neurons)
        self._energy = self.calculate_energy()
        self.neuronsChanged.emit()
        self.energyChanged.emit()

    @pyqtSlot(list)
    def add_pattern(self, pattern):
        """添加训练模式"""
        self.train_pattern(pattern)

    @pyqtSlot()
    def clear_patterns(self):
        """清空训练模式"""
        self._patterns = []
        self._weights = np.zeros((self._num_neurons, self._num_neurons))
        self.updateLog.emit("🧹 已清空训练模式")