import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, TextBox, RadioButtons
import matplotlib.patches as patches
from collections import defaultdict
import time

# 设置matplotlib使用TkAgg后端
import matplotlib

matplotlib.use('TkAgg')

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class HopfieldNetwork:
    def __init__(self, num_neurons=25):
        """
        初始化Hopfield神经网络
        """
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))
        self.states = np.random.choice([-1, 1], size=num_neurons)
        self.initial_states = self.states.copy()

        # 记录历史状态和能量
        self.state_history = [self.states.copy()]
        self.energy_history = [self.calculate_energy()]

        # 异步更新参数
        self.update_order = list(range(num_neurons))
        self.current_neuron_idx = 0

        # 吸引子检测
        self.attractors = []
        self.attractor_basins = defaultdict(int)

        # 示例模式
        self.patterns = self.create_sample_patterns()

    def create_sample_patterns(self):
        """
        创建示例模式（字母和数字）
        """
        patterns = {}

        # 字母A (5x5)
        patterns['A'] = np.array([
            [-1, -1, 1, -1, -1],
            [-1, 1, -1, 1, -1],
            [1, 1, 1, 1, 1],
            [1, -1, -1, -1, 1],
            [1, -1, -1, -1, 1]
        ]).flatten()

        # 字母B (5x5)
        patterns['B'] = np.array([
            [1, 1, 1, -1, -1],
            [1, -1, -1, 1, -1],
            [1, 1, 1, -1, -1],
            [1, -1, -1, 1, -1],
            [1, 1, 1, -1, -1]
        ]).flatten()

        # 字母C (5x5)
        patterns['C'] = np.array([
            [-1, 1, 1, 1, -1],
            [1, -1, -1, -1, 1],
            [1, -1, -1, -1, -1],
            [1, -1, -1, -1, 1],
            [-1, 1, 1, 1, -1]
        ]).flatten()

        # 数字1 (5x5)
        patterns['1'] = np.array([
            [-1, -1, 1, -1, -1],
            [-1, 1, 1, -1, -1],
            [-1, -1, 1, -1, -1],
            [-1, -1, 1, -1, -1],
            [-1, -1, 1, -1, -1]
        ]).flatten()

        # 数字2 (5x5)
        patterns['2'] = np.array([
            [-1, 1, 1, 1, -1],
            [1, -1, -1, -1, 1],
            [-1, -1, -1, 1, -1],
            [-1, -1, 1, -1, -1],
            [1, 1, 1, 1, 1]
        ]).flatten()

        return patterns

    def calculate_energy(self):
        """
        计算Hopfield网络能量
        E = -0.5 * ΣΣ w_ij * s_i * s_j
        """
        energy = 0
        for i in range(self.num_neurons):
            for j in range(self.num_neurons):
                if i != j:
                    energy -= 0.5 * self.weights[i, j] * self.states[i] * self.states[j]
        return energy

    def train_pattern(self, pattern):
        """
        使用Hebb规则训练单个模式
        w_ij = Σ p_i * p_j (i ≠ j)
        """
        for i in range(self.num_neurons):
            for j in range(self.num_neurons):
                if i != j:
                    self.weights[i, j] += pattern[i] * pattern[j]

    def train_patterns(self, patterns):
        """
        训练多个模式
        """
        self.weights = np.zeros((self.num_neurons, self.num_neurons))
        for pattern in patterns:
            self.train_pattern(pattern)

    def async_update(self, neuron_idx=None):
        """
        异步更新指定神经元
        """
        if neuron_idx is None:
            neuron_idx = self.current_neuron_idx

        # 计算该神经元的输入总和
        total_input = 0
        for j in range(self.num_neurons):
            if j != neuron_idx:
                total_input += self.weights[neuron_idx, j] * self.states[j]

        # 更新神经元状态
        if total_input >= 0:
            self.states[neuron_idx] = 1
        else:
            self.states[neuron_idx] = -1

        # 更新当前神经元索引
        self.current_neuron_idx = (self.current_neuron_idx + 1) % self.num_neurons

        # 记录状态和能量
        self.state_history.append(self.states.copy())
        self.energy_history.append(self.calculate_energy())

        return self.states

    def check_convergence(self, window_size=10):
        """
        检查网络是否收敛（达到稳定状态）
        """
        if len(self.state_history) < window_size:
            return False

        # 检查最近window_size步状态是否相同
        recent_states = self.state_history[-window_size:]
        first_state = recent_states[0]
        for state in recent_states[1:]:
            if not np.array_equal(state, first_state):
                return False

        # 如果收敛，检查是否为已知吸引子
        state_key = tuple(first_state)
        if state_key not in self.attractors:
            self.attractors.append(state_key)

        self.attractor_basins[state_key] += 1

        return True

    def reset(self, pattern=None):
        """
        重置网络状态
        """
        if pattern is not None:
            self.states = pattern.copy()
        else:
            self.states = np.random.choice([-1, 1], size=self.num_neurons)

        self.initial_states = self.states.copy()
        self.state_history = [self.states.copy()]
        self.energy_history = [self.calculate_energy()]
        self.current_neuron_idx = 0

    def add_noise(self, noise_level=0.1):
        """
        向当前状态添加噪声
        """
        num_flips = int(noise_level * self.num_neurons)
        flip_indices = np.random.choice(self.num_neurons, num_flips, replace=False)

        for idx in flip_indices:
            self.states[idx] *= -1

        self.state_history.append(self.states.copy())
        self.energy_history.append(self.calculate_energy())


class HopfieldVisualizer:
    def __init__(self, hn):
        """
        初始化Hopfield网络可视化界面
        """
        self.hn = hn
        self.fig = plt.figure(figsize=(16, 10))
        self.setup_layout()
        self.setup_widgets()
        self.is_running = False
        self.step_count = 0
        self.grid_size = int(np.sqrt(hn.num_neurons))

        # 初始化可视化
        self.update_all_plots()

    def setup_layout(self):
        """
        使用绝对坐标设置布局，避免嵌套GridSpec
        """
        # 创建所有子图使用绝对坐标
        # 第一行
        self.ax_patterns = self.fig.add_axes([0.05, 0.75, 0.25, 0.2])  # 训练模式
        self.ax_current = self.fig.add_axes([0.35, 0.75, 0.25, 0.2])  # 当前状态
        self.ax_weights = self.fig.add_axes([0.65, 0.75, 0.25, 0.2])  # 权重矩阵

        # 第二行
        self.ax_energy = self.fig.add_axes([0.05, 0.45, 0.6, 0.25])  # 能量函数

        # 第三行
        self.ax_attractors = self.fig.add_axes([0.05, 0.15, 0.25, 0.25])  # 吸引子状态
        self.ax_basins = self.fig.add_axes([0.35, 0.15, 0.25, 0.25])  # 吸引盆分布
        self.ax_convergence = self.fig.add_axes([0.65, 0.15, 0.25, 0.25])  # 收敛分析

        # 控件区域
        self.ax_controls = self.fig.add_axes([0.75, 0.45, 0.2, 0.25])  # 控件区域
        self.ax_controls.axis('off')  # 隐藏控件区域的坐标轴

        self.fig.suptitle('离散型Hopfield神经网络可视化沙箱', fontsize=16, fontweight='bold')

    def setup_widgets(self):
        """
        设置交互控件 - 使用绝对坐标
        """
        # 创建按钮和控件的坐标
        ax_button_run = self.fig.add_axes([0.77, 0.65, 0.16, 0.04])
        ax_button_step = self.fig.add_axes([0.77, 0.60, 0.16, 0.04])
        ax_button_reset = self.fig.add_axes([0.77, 0.55, 0.16, 0.04])
        ax_button_train = self.fig.add_axes([0.77, 0.50, 0.16, 0.04])
        ax_button_noise = self.fig.add_axes([0.77, 0.45, 0.16, 0.04])
        ax_text_neurons = self.fig.add_axes([0.77, 0.40, 0.16, 0.04])
        ax_radio_patterns = self.fig.add_axes([0.77, 0.25, 0.16, 0.12])

        # 创建按钮
        self.button_run = Button(ax_button_run, '运行/暂停')
        self.button_step = Button(ax_button_step, '单步更新')
        self.button_reset = Button(ax_button_reset, '重置网络')
        self.button_train = Button(ax_button_train, '训练模式')
        self.button_noise = Button(ax_button_noise, '添加噪声')

        # 创建文本框
        self.text_neurons = TextBox(ax_text_neurons, '神经元数:', initial=str(self.hn.num_neurons))

        # 创建单选按钮
        self.radio_patterns = RadioButtons(ax_radio_patterns,
                                           list(self.hn.patterns.keys()) + ['随机'],
                                           active=len(self.hn.patterns.keys()))

        # 绑定事件
        self.button_run.on_clicked(self.toggle_run)
        self.button_step.on_clicked(self.step_update)
        self.button_reset.on_clicked(self.reset_network)
        self.button_train.on_clicked(self.train_patterns)
        self.button_noise.on_clicked(self.add_noise)
        self.text_neurons.on_submit(self.update_neurons)
        self.radio_patterns.on_clicked(self.select_pattern)

    def toggle_run(self, event):
        """
        切换运行/暂停状态
        """
        self.is_running = not self.is_running
        if self.is_running:
            self.run_simulation()

    def step_update(self, event):
        """
        单步更新
        """
        self.hn.async_update()
        self.step_count += 1
        self.update_all_plots()

    def reset_network(self, event):
        """
        重置网络
        """
        # 获取当前选择的模式
        selected = self.radio_patterns.value_selected
        if selected in self.hn.patterns:
            pattern = self.hn.patterns[selected]
        else:
            pattern = None

        self.hn.reset(pattern)
        self.step_count = 0
        self.update_all_plots()

    def train_patterns(self, event):
        """
        训练选定的模式
        """
        selected_patterns = []
        for pattern_name in self.hn.patterns:
            selected_patterns.append(self.hn.patterns[pattern_name])

        self.hn.train_patterns(selected_patterns)
        self.update_all_plots()
        print(f"已训练 {len(selected_patterns)} 个模式")

    def add_noise(self, event):
        """
        添加噪声
        """
        self.hn.add_noise(noise_level=0.2)
        self.update_all_plots()

    def update_neurons(self, text):
        """
        更新神经元数量
        """
        try:
            new_num = int(text)
            if new_num > 0 and np.sqrt(new_num).is_integer():
                self.hn = HopfieldNetwork(num_neurons=new_num)
                self.grid_size = int(np.sqrt(new_num))
                self.step_count = 0
                self.update_all_plots()
            else:
                print("神经元数量必须是完全平方数")
        except ValueError:
            print("请输入有效的整数")

    def select_pattern(self, label):
        """
        选择初始模式
        """
        self.reset_network(None)

    def run_simulation(self):
        """
        运行模拟
        """
        while self.is_running and self.step_count < 1000:
            self.hn.async_update()
            self.step_count += 1
            self.update_all_plots()
            plt.pause(0.05)

            # 检查收敛
            if self.hn.check_convergence():
                print(f"网络已收敛到吸引子，步数: {self.step_count}")
                self.is_running = False
                break

    def update_all_plots(self):
        """
        更新所有子图
        """
        self.plot_patterns()
        self.plot_current_state()
        self.plot_weights()
        self.plot_energy()
        self.plot_attractors()
        self.plot_basins()
        self.plot_convergence()

    def plot_patterns(self):
        """
        绘制训练模式
        """
        self.ax_patterns.clear()
        self.ax_patterns.set_title('训练模式', fontsize=12, fontweight='bold')

        patterns = list(self.hn.patterns.items())

        # 显示模式名称和数量
        pattern_names = ", ".join(self.hn.patterns.keys())
        self.ax_patterns.text(0.5, 0.7, f'模式: {pattern_names}',
                              ha='center', va='center', transform=self.ax_patterns.transAxes,
                              fontsize=10)

        # 显示当前训练状态
        if np.any(self.hn.weights):  # 如果权重矩阵非零，说明已经训练
            self.ax_patterns.text(0.5, 0.4, '网络已训练',
                                  ha='center', va='center', transform=self.ax_patterns.transAxes,
                                  fontsize=10, color='green',
                                  bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgreen"))
        else:
            self.ax_patterns.text(0.5, 0.4, '网络未训练',
                                  ha='center', va='center', transform=self.ax_patterns.transAxes,
                                  fontsize=10, color='red',
                                  bbox=dict(boxstyle="round,pad=0.3", facecolor="lightcoral"))

        self.ax_patterns.text(0.5, 0.1, '点击"训练模式"按钮开始训练',
                              ha='center', va='center', transform=self.ax_patterns.transAxes,
                              fontsize=8, style='italic')

        self.ax_patterns.axis('off')

    def plot_current_state(self):
        """
        绘制当前状态
        """
        self.ax_current.clear()

        # 绘制当前状态网格
        im = self.ax_current.imshow(self.hn.states.reshape(self.grid_size, self.grid_size),
                                    cmap='binary', vmin=-1, vmax=1)

        # 高亮显示当前更新的神经元
        row = self.hn.current_neuron_idx // self.grid_size
        col = self.hn.current_neuron_idx % self.grid_size
        rect = patches.Rectangle((col - 0.5, row - 0.5), 1, 1, linewidth=2,
                                 edgecolor='red', facecolor='none')
        self.ax_current.add_patch(rect)

        self.ax_current.set_title(f'当前状态 (步数: {self.step_count})', fontsize=12, fontweight='bold')
        self.ax_current.set_xticks([])
        self.ax_current.set_yticks([])

    def plot_weights(self):
        """
        绘制权重矩阵
        """
        self.ax_weights.clear()

        im = self.ax_weights.imshow(self.hn.weights, cmap='coolwarm',
                                    vmin=-np.max(np.abs(self.hn.weights)) if np.any(self.hn.weights) else -1,
                                    vmax=np.max(np.abs(self.hn.weights)) if np.any(self.hn.weights) else 1)

        self.ax_weights.set_title('权重矩阵', fontsize=12, fontweight='bold')
        self.ax_weights.set_xlabel('神经元索引')
        self.ax_weights.set_ylabel('神经元索引')

        # 添加颜色条
        plt.colorbar(im, ax=self.ax_weights, shrink=0.8)

    def plot_energy(self):
        """
        绘制能量变化
        """
        self.ax_energy.clear()

        if len(self.hn.energy_history) > 1:
            self.ax_energy.plot(self.hn.energy_history, color='purple', linewidth=2)
            self.ax_energy.scatter(len(self.hn.energy_history) - 1,
                                   self.hn.energy_history[-1],
                                   color='purple', s=50, zorder=5)

        self.ax_energy.set_title('能量函数变化', fontsize=12, fontweight='bold')
        self.ax_energy.set_xlabel('时间步')
        self.ax_energy.set_ylabel('能量')
        self.ax_energy.grid(True, alpha=0.3)

        # 显示当前能量值
        if self.hn.energy_history:
            current_energy = self.hn.energy_history[-1]
            self.ax_energy.text(0.02, 0.98, f'当前能量: {current_energy:.3f}',
                                transform=self.ax_energy.transAxes, fontsize=10,
                                bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

    def plot_attractors(self):
        """
        绘制吸引子状态
        """
        self.ax_attractors.clear()

        if self.hn.attractors:
            # 显示吸引子数量信息
            self.ax_attractors.text(0.5, 0.9, f'已发现 {len(self.hn.attractors)} 个吸引子',
                                    ha='center', va='center', transform=self.ax_attractors.transAxes,
                                    fontsize=12, bbox=dict(boxstyle="round,pad=0.3", facecolor="lightblue"))

            # 显示第一个吸引子的状态
            if len(self.hn.attractors) > 0:
                attractor = np.array(self.hn.attractors[0])
                ax_thumb = self.fig.add_axes([0.1, 0.25, 0.15, 0.15])
                ax_thumb.imshow(attractor.reshape(self.grid_size, self.grid_size),
                                cmap='binary', vmin=-1, vmax=1)
                ax_thumb.set_title('吸引子 1', fontsize=8)
                ax_thumb.set_xticks([])
                ax_thumb.set_yticks([])

            # 显示第二个吸引子的状态（如果有）
            if len(self.hn.attractors) > 1:
                attractor = np.array(self.hn.attractors[1])
                ax_thumb = self.fig.add_axes([0.3, 0.25, 0.15, 0.15])
                ax_thumb.imshow(attractor.reshape(self.grid_size, self.grid_size),
                                cmap='binary', vmin=-1, vmax=1)
                ax_thumb.set_title('吸引子 2', fontsize=8)
                ax_thumb.set_xticks([])
                ax_thumb.set_yticks([])
        else:
            self.ax_attractors.text(0.5, 0.5, '尚未发现吸引子',
                                    ha='center', va='center', transform=self.ax_attractors.transAxes,
                                    fontsize=12, bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow"))

        self.ax_attractors.set_title('吸引子状态', fontsize=12, fontweight='bold')
        self.ax_attractors.axis('off')

    def plot_basins(self):
        """
        绘制吸引盆分布
        """
        self.ax_basins.clear()

        if self.hn.attractor_basins:
            basins = list(self.hn.attractor_basins.items())
            basins.sort(key=lambda x: x[1], reverse=True)

            labels = [f'吸引子 {i + 1}' for i in range(len(basins))]
            sizes = [count for _, count in basins]

            self.ax_basins.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
            self.ax_basins.set_title('吸引盆分布', fontsize=12, fontweight='bold')
        else:
            self.ax_basins.text(0.5, 0.5, '无吸引盆数据',
                                ha='center', va='center', transform=self.ax_basins.transAxes,
                                fontsize=12)
            self.ax_basins.set_title('吸引盆分布', fontsize=12, fontweight='bold')

    def plot_convergence(self):
        """
        绘制收敛分析
        """
        self.ax_convergence.clear()

        if len(self.hn.state_history) > 1:
            # 计算状态变化率
            changes = []
            for i in range(1, len(self.hn.state_history)):
                change = np.sum(self.hn.state_history[i] != self.hn.state_history[i - 1])
                changes.append(change)

            self.ax_convergence.plot(range(1, len(self.hn.state_history)), changes, color='green', linewidth=2)
            self.ax_convergence.set_title('状态变化率', fontsize=12, fontweight='bold')
            self.ax_convergence.set_xlabel('时间步')
            self.ax_convergence.set_ylabel('变化神经元数')
            self.ax_convergence.grid(True, alpha=0.3)

            # 标记收敛点
            if self.hn.check_convergence(window_size=5):
                self.ax_convergence.axvline(x=len(self.hn.state_history) - 5, color='red', linestyle='--',
                                            label='收敛点')
                self.ax_convergence.legend()
        else:
            self.ax_convergence.text(0.5, 0.5, '无收敛数据',
                                     ha='center', va='center', transform=self.ax_convergence.transAxes,
                                     fontsize=12)
            self.ax_convergence.set_title('状态变化率', fontsize=12, fontweight='bold')


def main():
    """
    主函数 - 运行Hopfield神经网络可视化沙箱
    """
    print("初始化Hopfield神经网络...")
    print("神经元数量: 25 (5x5网格)")
    print("训练模式: A, B, C, 1, 2")
    print("\n功能说明:")
    print("1. 异步随机更新: 每次更新一个随机神经元")
    print("2. 吸引子可视化: 显示网络收敛到的稳定状态")
    print("3. 能量函数: 展示网络能量随时间的收敛过程")
    print("4. 交互控制: 可调整参数、选择初始状态、添加噪声")
    print("5. 示例模式: 预训练字母和数字模式")

    # 创建Hopfield网络实例
    hn = HopfieldNetwork(num_neurons=25)

    # 训练示例模式
    patterns = list(hn.patterns.values())
    hn.train_patterns(patterns)

    # 创建可视化器
    visualizer = HopfieldVisualizer(hn)

    print("\n沙箱已启动!")
    print("使用界面右侧控件进行操作:")
    print("- 运行/暂停: 开始或暂停模拟")
    print("- 单步更新: 执行一次神经元更新")
    print("- 重置网络: 重置为初始状态")
    print("- 训练模式: 使用示例模式训练网络")
    print("- 添加噪声: 向当前状态添加随机噪声")
    print("- 神经元数: 修改网络规模(需为完全平方数)")
    print("- 初始模式: 选择初始状态")

    plt.show()


if __name__ == "__main__":
    main()