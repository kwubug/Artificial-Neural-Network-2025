import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def rbf_gaussian(x, c=0, epsilon=1):
    """
    高斯RBF函数
    x: 输入值
    c: 中心点
    epsilon: 宽度参数
    """
    return np.exp(-(epsilon * (x - c)) ** 2)


def rbf_multiquadric(x, c=0, epsilon=1):
    """多二次RBF函数"""
    return np.sqrt(1 + (epsilon * (x - c)) ** 2)


def rbf_inverse_quadratic(x, c=0, epsilon=1):
    """逆二次RBF函数"""
    return 1 / (1 + (epsilon * (x - c)) ** 2)


def plot_1d_rbf_comparison():
    """绘制一维RBF函数比较"""
    x = np.linspace(-3, 3, 200)

    # 不同参数设置
    centers = [0]
    epsilons = [0.5, 1, 2]

    plt.figure(figsize=(15, 5))

    for i, epsilon in enumerate(epsilons):
        plt.subplot(1, 3, i + 1)

        for c in centers:
            y_gaussian = rbf_gaussian(x, c, epsilon)
            y_multiquadric = rbf_multiquadric(x, c, epsilon)
            y_inverse = rbf_inverse_quadratic(x, c, epsilon)

            plt.plot(x, y_gaussian, 'r-', linewidth=2, label=f'高斯 (ε={epsilon})')
            plt.plot(x, y_multiquadric, 'g--', linewidth=2, label=f'多二次 (ε={epsilon})')
            plt.plot(x, y_inverse, 'b:', linewidth=2, label=f'逆二次 (ε={epsilon})')

        plt.axvline(x=c, color='gray', linestyle='--', alpha=0.5)
        plt.title(f'RBF函数比较 (ε={epsilon})')
        plt.xlabel('x')
        plt.ylabel('φ(x)')
        plt.legend()
        plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


def plot_2d_rbf():
    """绘制二维高斯RBF函数"""
    x = np.linspace(-3, 3, 100)
    y = np.linspace(-3, 3, 100)
    X, Y = np.meshgrid(x, y)

    # 中心点
    centers = [(0, 0), (1, 1), (-1, -1)]
    epsilon = 1

    fig = plt.figure(figsize=(15, 5))

    # 绘制单个RBF
    ax1 = fig.add_subplot(131, projection='3d')
    Z = rbf_gaussian(np.sqrt(X ** 2 + Y ** 2), 0, epsilon)
    surf = ax1.plot_surface(X, Y, Z, cmap=cm.viridis, alpha=0.8)
    ax1.set_title('单个高斯RBF (2D)')
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('φ(X,Y)')

    # 绘制多个RBF叠加
    ax2 = fig.add_subplot(132, projection='3d')
    Z_combined = np.zeros_like(X)
    for cx, cy in centers:
        dist = np.sqrt((X - cx) ** 2 + (Y - cy) ** 2)
        Z_combined += rbf_gaussian(dist, 0, epsilon)

    surf2 = ax2.plot_surface(X, Y, Z_combined, cmap=cm.plasma, alpha=0.8)
    ax2.set_title('多个高斯RBF叠加')
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_zlabel('φ(X,Y)')

    # 二维等高线图
    ax3 = fig.add_subplot(133)
    contour = ax3.contourf(X, Y, Z_combined, levels=50, cmap='plasma')
    ax3.scatter([c[0] for c in centers], [c[1] for c in centers],
                c='red', s=100, marker='o', label='中心点')
    ax3.set_title('RBF等高线图')
    ax3.set_xlabel('X')
    ax3.set_ylabel('Y')
    ax3.legend()
    plt.colorbar(contour, ax=ax3)

    plt.tight_layout()
    plt.show()


def plot_rbf_with_different_centers():
    """绘制不同中心点位置的RBF"""
    x = np.linspace(-5, 5, 200)

    centers = [-2, 0, 2]
    epsilon = 1

    plt.figure(figsize=(12, 8))

    # 绘制单个RBF
    plt.subplot(2, 1, 1)
    for i, c in enumerate(centers):
        y = rbf_gaussian(x, c, epsilon)
        plt.plot(x, y, linewidth=2, label=f'中心点 c={c}')
        plt.axvline(x=c, color='red', linestyle='--', alpha=0.5)

    plt.title('不同中心点的高斯RBF函数')
    plt.xlabel('x')
    plt.ylabel('φ(x)')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # 绘制RBF叠加
    plt.subplot(2, 1, 2)
    y_combined = np.zeros_like(x)
    for c in centers:
        y_combined += rbf_gaussian(x, c, epsilon)

    plt.plot(x, y_combined, 'b-', linewidth=3, label='RBF叠加')
    for c in centers:
        plt.axvline(x=c, color='red', linestyle='--', alpha=0.5, label=f'中心点 c={c}')

    plt.title('多个RBF函数叠加')
    plt.xlabel('x')
    plt.ylabel('Σφ(x)')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


def plot_epsilon_effect():
    """展示epsilon参数对RBF形状的影响"""
    x = np.linspace(-3, 3, 200)
    center = 0

    epsilons = [0.3, 0.7, 1.0, 2.0, 3.0]
    colors = ['red', 'orange', 'green', 'blue', 'purple']

    plt.figure(figsize=(12, 8))

    for epsilon, color in zip(epsilons, colors):
        y = rbf_gaussian(x, center, epsilon)
        plt.plot(x, y, color=color, linewidth=2,
                 label=f'ε={epsilon}', alpha=0.8)

    plt.axvline(x=center, color='gray', linestyle='--', alpha=0.5)
    plt.title('epsilon参数对高斯RBF形状的影响')
    plt.xlabel('x')
    plt.ylabel('φ(x)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()


if __name__ == "__main__":
    print("RBF函数可视化演示")
    print("=" * 50)

    # 1. 比较不同RBF函数
    print("1. 绘制不同RBF函数比较...")
    plot_1d_rbf_comparison()

    # 2. 展示epsilon参数影响
    print("2. 展示epsilon参数影响...")
    plot_epsilon_effect()

    # 3. 展示不同中心点
    print("3. 展示不同中心点的RBF...")
    plot_rbf_with_different_centers()

    # 4. 二维RBF可视化
    print("4. 绘制二维RBF可视化...")
    plot_2d_rbf()

    print("可视化完成！")