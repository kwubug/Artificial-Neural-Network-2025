import PyQt5.QtCore
import numpy as np
from nn_sandbox.backend.algorithms.gradient_descent import (
    BatchGradientDescent,
    StochasticGradientDescent,
    MiniBatchGradientDescent
)

class OptimizationWorker(PyQt5.QtCore.QThread):
    """优化工作线程"""
    progress_signal = PyQt5.QtCore.pyqtSignal(int, list, float, float)
    finished_signal = PyQt5.QtCore.pyqtSignal(list)
    
    def __init__(self, algorithm_type, start_point, learning_rate, max_iterations):
        super().__init__()
        self.algorithm_type = algorithm_type
        self.start_point = start_point
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self.optimizer = None
        self.history_data = []
        
    def run(self):
        """线程执行函数"""
        # 定义一个测试函数 (例如: f(x,y) = x^2 + y^2)
        def test_function(point):
            return np.sum(np.array(point)**2)
        
        start_point = np.array(self.start_point)
        
        # 根据算法类型选择优化器
        if self.algorithm_type == "batch":
            self.optimizer = BatchGradientDescent(test_function, start_point, self.learning_rate, self.max_iterations)
        elif self.algorithm_type == "stochastic":
            self.optimizer = StochasticGradientDescent(test_function, start_point, self.learning_rate, self.max_iterations)
        elif self.algorithm_type == "mini_batch":
            self.optimizer = MiniBatchGradientDescent(test_function, start_point, self.learning_rate, self.max_iterations)
        else:
            raise ValueError("Unknown algorithm type")
        
        # 设置进度回调
        self.optimizer.set_progress_callback(self._on_progress)
        
        # 执行优化
        result = self.optimizer.optimize()
        
        # 保存历史数据
        self.history_data = self.optimizer.get_history().tolist()
        
        # 发出完成信号
        self.finished_signal.emit([self.algorithm_type, result.tolist()])
    
    def _on_progress(self, progress, current_point, func_value, grad_norm):
        """进度回调函数"""
        self.progress_signal.emit(progress, current_point, func_value, grad_norm)
        self.history_data.append(current_point)

class GradientDescentBridge(PyQt5.QtCore.QObject):
    # 定义信号，用于与前端交互
    optimization_done = PyQt5.QtCore.pyqtSignal(list)  # 优化完成信号
    optimization_progress = PyQt5.QtCore.pyqtSignal(int, list, float, float)  # 优化进度信号
    
    def __init__(self):
        super().__init__()
        self.history_data = {}  # 存储不同算法的历史数据
        self.current_worker = None  # 当前工作线程
        
    @PyQt5.QtCore.pyqtSlot(str, list, float, int)
    def run_optimization(self, algorithm_type, start_point, learning_rate, max_iterations):
        """运行优化算法"""
        print(f"Starting {algorithm_type} optimization...")
        
        # 确保工作线程已停止
        if self.current_worker and self.current_worker.isRunning():
            self.current_worker.stop()
            self.current_worker.wait()
        
        # 创建工作线程
        self.current_worker = GradientDescentWorker(
            algorithm_type, start_point, learning_rate, max_iterations
        )
        
        # 连接信号
        self.current_worker.optimization_progress.connect(self._on_optimization_progress)
        self.current_worker.optimization_finished.connect(self._on_optimization_finished)
        
        # 开始优化
        self.current_worker.start()
        
    def _on_optimization_progress(self, progress, current_point, func_value, grad_norm):
        """处理优化进度更新"""
        # 确保信号正确传递到前端
        try:
            self.optimization_progress.emit(
                float(progress), 
                [float(current_point[0]), float(current_point[1])], 
                float(func_value), 
                float(grad_norm)
            )
        except Exception as e:
            print(f"Error emitting optimization progress: {e}")
        
    def _on_optimization_finished(self, result):
        """处理优化完成"""
        algorithm_type = result[0]
        final_point = result[1]
        
        # 保存历史数据
        if self.current_worker:
            self.history_data[algorithm_type] = self.current_worker.history_data
        
        # 发出完成信号
        self.optimization_done.emit([algorithm_type, final_point])
        
        # 清理工作线程
        self.current_worker = None
        
    @PyQt5.QtCore.pyqtSlot(str, result=list)
    def get_history_data(self, algorithm_type):
        """获取指定算法的历史数据"""
        return self.history_data.get(algorithm_type, [])