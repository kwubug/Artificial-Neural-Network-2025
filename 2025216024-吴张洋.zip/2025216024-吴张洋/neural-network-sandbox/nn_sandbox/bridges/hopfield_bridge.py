import time

import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import HopfieldAlgorithm
from nn_sandbox.backend.utils import sign
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    max_iterations = BridgeProperty(1000)
    convergence_threshold = BridgeProperty(0.001)
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    has_converged = BridgeProperty(False)
    weights = BridgeProperty([])
    current_state = BridgeProperty([])
    initial_state = BridgeProperty([])
    attractor_state = BridgeProperty([])
    energy_history = BridgeProperty([])
    # 添加吸引子相关属性
    attractors = BridgeProperty([])
    attractor_energies = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.hopfield_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_hopfield_algorithm(self):
        """开始训练Hopfield网络"""
        self.hopfield_algorithm = ObservableHopfieldAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            max_iterations=self.max_iterations,
            convergence_threshold=self.convergence_threshold
        )
        self.hopfield_algorithm.start()

    @PyQt5.QtCore.pyqtSlot(list)
    def test_pattern(self, initial_state):
        """测试一个模式（在线程中运行）"""
        if self.hopfield_algorithm is None:
            # 如果还没有训练，先训练
            self.start_hopfield_algorithm()
            # 等待训练完成
            if self.hopfield_algorithm.is_alive():
                self.hopfield_algorithm.join()
        
        # 如果已经训练完成，在线程中运行测试
        if self.hopfield_algorithm and self.hopfield_algorithm._weights is not None:
            # 创建一个新的测试线程实例
            import threading
            test_thread = threading.Thread(
                target=self.hopfield_algorithm.test_pattern,
                args=(initial_state,),
                daemon=True
            )
            test_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_hopfield_algorithm(self):
        """停止算法"""
        if self.hopfield_algorithm:
            self.hopfield_algorithm.stop()


class ObservableHopfieldAlgorithm(Observable, HopfieldAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        HopfieldAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval
        self._test_mode = False
        self._test_initial_state = None

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            if hasattr(self, '_current_state') and self._current_state is not None:
                self.notify('current_state', self._current_state.tolist())
            if hasattr(self, 'current_energy') and self.current_energy is not None:
                self.notify('current_energy', self.current_energy)
            if hasattr(self, '_energy_history') and self._energy_history:
                self.notify('energy_history', self._energy_history.copy())
        elif name == 'current_energy':
            self.notify(name, value)
        elif name == 'has_converged':
            self.notify(name, value)
        elif name == 'attractor_state' and value is not None:
            self.notify(name, value.tolist())
        elif name == '_weights' and value is not None:
            self.notify('weights', value.tolist())
        elif name == '_energy_history':
            # 当能量历史更新时，也通知
            if value:
                self.notify('energy_history', value.copy())

    def run(self):
        """运行训练"""
        self.notify('has_finished', False)
        self.notify('has_converged', False)
        self.notify('current_iterations', 0)
        self.notify('current_energy', 0.0)
        self.notify('energy_history', [])
        super().run()
        
        # 训练完成后，通知权重矩阵
        if self._weights is not None:
            self.notify('weights', self._weights.tolist())
        
        self.notify('has_finished', True)
        
        # 如果设置了测试模式，自动进行测试
        if self._test_mode and self._test_initial_state is not None:
            self.test_pattern(self._test_initial_state)

    def test_pattern(self, initial_state):
        """测试模式（带通知和UI刷新）"""
        self._test_mode = True
        self._test_initial_state = initial_state
        
        # 如果已经训练完成
        if self._weights is not None:
            self.notify('has_finished', False)
            self.notify('has_converged', False)
            self.notify('initial_state', np.array(initial_state).tolist())
            
            # 调用父类的test_pattern，但需要修改以支持UI刷新
            # 先设置初始状态
            initial_state_array = np.array(initial_state)
            initial_state_array = np.where(initial_state_array >= 0, 1, -1)
            self._initial_state = initial_state_array
            self._current_state = initial_state_array.copy()
            
            self._energy_history = []
            self._state_history = [self._current_state.copy()]
            self.current_iterations = 0
            self.has_converged = False
            
            N = len(self._current_state)
            
            for iteration in range(self._max_iterations):
                self.current_iterations = iteration
                
                # 计算当前能量（使用父类方法）
                energy = super()._calculate_energy(self._current_state)
                self.current_energy = energy
                self._energy_history.append(energy)
                # 通知能量历史更新
                self.notify('energy_history', self._energy_history.copy())
                
                # 随机选择一个神经元进行异步更新
                neuron_idx = np.random.randint(0, N)
                
                # 计算该神经元的输入
                net_input = np.dot(self._weights[neuron_idx], self._current_state)
                
                # 更新神经元状态
                new_value = sign(net_input)
                old_value = self._current_state[neuron_idx]
                
                # 如果状态改变，更新
                if new_value != old_value:
                    self._current_state[neuron_idx] = new_value
                    self._state_history.append(self._current_state.copy())
                
                # UI刷新延迟
                time.sleep(self.ui_refresh_interval)
                
                # 检查是否收敛
                if len(self._energy_history) >= 2:
                    energy_change = abs(self._energy_history[-1] - self._energy_history[-2])
                    if energy_change < self._convergence_threshold:
                        if iteration > 10:
                            self.has_converged = True
                            break
                
                if len(self._state_history) >= 2:
                    if np.array_equal(self._state_history[-1], self._state_history[-2]):
                        self.has_converged = True
                        break
                
                if self._should_stop:
                    break
            
            self.attractor_state = self._current_state.copy()
            
            self.notify('attractor_state', self.attractor_state.tolist())
            self.notify('energy_history', self._energy_history.copy())
            self.notify('current_iterations', self.current_iterations)
            self.notify('has_converged', self.has_converged)
            self.notify('has_finished', True)
        else:
            # 如果还没训练，先训练
            self.run()

