import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

x = torch.unsqueeze(torch.linspace(-1, 1, 100), dim=1)
y = x.pow(2) + 0.2 * torch.rand(x.size())

class BPNet(nn.Module):
    def __init__(self):
        super(BPNet, self).__init__()
        self.hidden = nn.Linear(1, 20)  # 隐藏层
        self.output = nn.Linear(20, 1)  # 输出层
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.relu(self.hidden(x))
        x = self.output(x)
        return x


net = BPNet()
optimizer = optim.SGD(net.parameters(), lr=0.2)
loss_func = nn.MSELoss()

plt.ion()
plt.figure(figsize=(8, 5))

loss_list = []

for t in range(200):
    prediction = net(x)
    loss = loss_func(prediction, y)
    loss_list.append(loss.item())

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    if t % 5 == 0:
        plt.cla()
        plt.scatter(x.data.numpy(), y.data.numpy(), label='Data')
        plt.plot(x.data.numpy(), prediction.data.numpy(), lw=2, label='Prediction')

        plt.text(0.5, 0.05, 'Loss=%.4f' % loss.item(), fontdict={'size': 14})

        plt.title("BP Neural Network Regression (PyTorch)")
        plt.pause(0.1)

plt.ioff()
plt.show()

plt.figure(figsize=(8, 4))
plt.plot(loss_list)
plt.title("Training Loss Curve")
plt.xlabel("Step")
plt.ylabel("Loss")
plt.show()
