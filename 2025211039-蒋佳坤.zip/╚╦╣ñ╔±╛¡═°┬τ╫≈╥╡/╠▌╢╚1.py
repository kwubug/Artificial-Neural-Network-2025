import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import RadioButtons, Button
from mpl_toolkits.mplot3d import Axes3D


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def E(w):
    w1, w2 = w
    return w1**2 + 2*w2**2 + w1*w2 - 6*w1 - 8*w2 + 10

def gradE(w):
    w1, w2 = w
    return np.array([2*w1 + w2 - 6, 4*w2 + w1 - 8])

def hessE(w):
    return np.array([[2, 1], [1, 4]])


def steepest_descent(x0, lr=0.1, max_iter=50):
    x = x0.copy()
    path = [x]
    for _ in range(max_iter):
        g = gradE(x)
        x = x - lr * g
        path.append(x.copy())
        if np.linalg.norm(g) < 1e-6:
            break
    return np.array(path)

def newton_method(x0, max_iter=10):
    x = x0.copy()
    path = [x]
    for _ in range(max_iter):
        g = gradE(x)
        H = hessE(x)
        dx = np.linalg.solve(H, g)
        x = x - dx
        path.append(x.copy())
        if np.linalg.norm(g) < 1e-6:
            break
    return np.array(path)

def conjugate_gradient(x0, max_iter=50):
    x = x0.copy()
    g = gradE(x)
    d = -g
    path = [x]
    for _ in range(max_iter):
        alpha = (g @ g) / (d @ hessE(x) @ d)
        x_new = x + alpha * d
        g_new = gradE(x_new)
        beta = (g_new @ g_new) / (g @ g)
        d = -g_new + beta * d
        x, g = x_new, g_new
        path.append(x.copy())
        if np.linalg.norm(g) < 1e-6:
            break
    return np.array(path)


def plot_surface(ax):

    w1 = np.linspace(-1, 6, 10)
    w2 = np.linspace(-1, 6, 10)
    W1, W2 = np.meshgrid(w1, w2)
    Z = E([W1, W2])


    ax.plot_surface(W1, W2, Z, cmap='viridis', alpha=0.8, rstride=4, cstride=4, edgecolor='gray')
    ax.plot_wireframe(W1, W2, Z, color='black', linewidth=0.4, alpha=0.5)

    ax.set_xlabel("权值 w1", fontsize=11)
    ax.set_ylabel("权值 w2", fontsize=11)
    ax.set_zlabel("误差 E(w1, w2)", fontsize=11)


def draw_path(ax, path, method_name):
    path_z = [E(p) for p in path]
    ax.plot(path[:, 0], path[:, 1], path_z, color='red', marker='o', label=method_name)


    ax.text2D(0.05, 0.95, f"当前算法：{method_name}", transform=ax.transAxes,
              fontsize=13, color='darkred', fontweight='bold')


    A = np.array([[2,1],[1,4]])
    b = np.array([6,8])
    x_star = np.linalg.solve(A, b)
    ax.scatter([x_star[0]], [x_star[1]], [E(x_star)], color='lime', s=80, label='解析最小点')

    ax.legend(loc='upper right', fontsize=9)


fig = plt.figure(figsize=(9, 6))
ax = fig.add_subplot(111, projection='3d')
plt.subplots_adjust(left=0.25)

x0 = np.array([5.5, 5.0])
plot_surface(ax)
path = steepest_descent(x0)
draw_path(ax, path, "最速下降法")


ax_radio = plt.axes([0.05, 0.6, 0.15, 0.25])
radio = RadioButtons(ax_radio, ('最速下降法', '牛顿法', '共轭梯度法'))

ax_button = plt.axes([0.07, 0.5, 0.1, 0.05])
button = Button(ax_button, '重新运行')


def update_path(label):
    ax.cla()
    plot_surface(ax)
    if label == '最速下降法':
        p = steepest_descent(x0)
    elif label == '牛顿法':
        p = newton_method(x0)
    else:
        p = conjugate_gradient(x0)
    draw_path(ax, p, label)
    plt.draw()

def rerun(event):
    label = radio.value_selected
    update_path(label)

radio.on_clicked(update_path)
button.on_clicked(rerun)

plt.show()
