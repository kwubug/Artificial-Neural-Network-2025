import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import random
import threading
import time

class DiscreteHopfieldNetwork:
    def __init__(self, n_neurons=4):
        """
        初始化离散型Hopfield网络
        :param n_neurons: 神经元数量
        """
        self.n_neurons = n_neurons
        # 初始化权重矩阵
        self.weights = np.zeros((n_neurons, n_neurons))
        # 初始化神经元状态
        self.state = np.random.choice([-1, 1], n_neurons)
        # 存储训练模式
        self.patterns = []
        # 存储状态历史
        self.state_history = []
        self.energy_history = []
        
    def train(self, patterns):
        """
        使用Hebb规则训练网络
        :param patterns: 训练模式列表，每个模式都是一个numpy数组
        """
        self.patterns = patterns
        # 重置权重矩阵
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        
        # Hebb学习规则
        for pattern in patterns:
            # 确保模式长度正确
            if len(pattern) != self.n_neurons:
                raise ValueError("Pattern size must match network size")
            
            # 更新权重矩阵 W_ij = Σ(pattern_μ^i * pattern_μ^j)
            for i in range(self.n_neurons):
                for j in range(self.n_neurons):
                    if i != j:
                        self.weights[i, j] += pattern[i] * pattern[j]
        
        # 除以模式数量进行归一化
        if len(patterns) > 0:
            self.weights /= len(patterns)
        
    def energy(self, state=None):
        """
        计算给定状态的能量
        :param state: 网络状态，默认为当前状态
        :return: 能量值
        """
        if state is None:
            state = self.state
            
        # Hopfield网络能量函数: E = -1/2 * ΣΣ w_ij * s_i * s_j
        energy = 0
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                if i != j:
                    energy -= 0.5 * self.weights[i, j] * state[i] * state[j]
        return energy
    
    def update_neuron(self, neuron_idx):
        """
        异步更新单个神经元
        :param neuron_idx: 要更新的神经元索引
        """
        # 计算局部场 h_i = Σ w_ij * s_j
        local_field = 0
        for j in range(self.n_neurons):
            if j != neuron_idx:  # 排除自连接
                local_field += self.weights[neuron_idx, j] * self.state[j]
        
        # 根据激活函数更新状态: s_i = sign(h_i)
        self.state[neuron_idx] = 1 if local_field >= 0 else -1
    
    def asynchronous_update(self, n_steps=1):
        """
        异步更新网络
        :param n_steps: 更新步数
        """
        for _ in range(n_steps):
            # 随机选择一个神经元进行更新
            neuron_idx = random.randint(0, self.n_neurons - 1)
            self.update_neuron(neuron_idx)
            # 记录状态和能量
            self.state_history.append(self.state.copy())
            self.energy_history.append(self.energy())
    
    def synchronous_update(self, n_steps=1):
        """
        同步更新网络（所有神经元同时更新）
        :param n_steps: 更新步数
        """
        for _ in range(n_steps):
            new_state = np.copy(self.state)
            for i in range(self.n_neurons):
                # 计算局部场
                local_field = np.dot(self.weights[i, :], self.state)
                # 更新状态
                new_state[i] = 1 if local_field >= 0 else -1
            self.state = new_state
            # 记录状态和能量
            self.state_history.append(self.state.copy())
            self.energy_history.append(self.energy())
    
    def find_attractors(self):
        """
        找到网络的所有吸引子（稳定状态）
        :return: 吸引子列表
        """
        attractors = []
        visited_states = set()
        
        # 遍历所有可能的状态
        for i in range(2**self.n_neurons):
            # 将数字转换为二进制状态向量
            state = []
            for j in range(self.n_neurons):
                state.append(1 if (i >> j) & 1 else -1)
            state = np.array(state)
            
            # 将状态转换为元组以便存储在集合中
            state_tuple = tuple(state)
            
            # 如果已经访问过此状态，则跳过
            if state_tuple in visited_states:
                continue
                
            # 设置当前状态并运行直到收敛
            self.state = np.copy(state)
            prev_state = np.copy(state)
            
            # 运行直到状态不再改变或达到最大迭代次数
            for _ in range(20):  # 最多迭代20次
                self.asynchronous_update(5*self.n_neurons)  # 每次更新5*n_neurons次
                if np.array_equal(self.state, prev_state):
                    break
                prev_state = np.copy(self.state)
            
            # 检查是否找到了新的吸引子
            final_state_tuple = tuple(self.state)
            if final_state_tuple not in visited_states:
                attractors.append({
                    'state': np.copy(self.state),
                    'energy': self.energy()
                })
                visited_states.add(final_state_tuple)
            
            visited_states.add(state_tuple)
        
        return attractors
    
    def is_stable(self, state=None):
        """
        检查给定状态是否稳定（是否为吸引子）
        :param state: 要检查的状态，默认为当前状态
        :return: 是否稳定
        """
        if state is None:
            state = self.state
            
        # 复制当前状态
        test_state = np.copy(state)
        self.state = test_state
        
        # 进行一次异步更新
        self.asynchronous_update(self.n_neurons)
        
        # 检查状态是否改变
        is_stable = np.array_equal(test_state, self.state)
        
        # 恢复原始状态
        self.state = state
        
        return is_stable
    
    def convergence_analysis(self, initial_state=None, max_steps=100):
        """
        分析网络从初始状态到吸引子的收敛过程
        :param initial_state: 初始状态，默认为当前状态
        :param max_steps: 最大步数
        :return: 收敛步数、最终状态、能量变化
        """
        if initial_state is None:
            initial_state = np.random.choice([-1, 1], self.n_neurons)
            
        # 保存当前状态
        saved_state = self.state.copy()
        saved_history = self.state_history.copy()
        saved_energy = self.energy_history.copy()
        
        # 设置初始状态
        self.state = initial_state.copy()
        self.state_history = [initial_state.copy()]
        self.energy_history = [self.energy()]
        
        # 运行直到收敛或达到最大步数
        prev_state = initial_state.copy()
        for step in range(max_steps):
            self.asynchronous_update(1)
            
            # 检查是否收敛
            if np.array_equal(self.state, prev_state):
                break
                
            prev_state = self.state.copy()
        
        # 保存结果
        final_state = self.state.copy()
        convergence_steps = step + 1
        energy_changes = self.energy_history.copy()
        
        # 恢复原始状态
        self.state = saved_state
        self.state_history = saved_history
        self.energy_history = saved_energy
        
        return {
            'convergence_steps': convergence_steps,
            'final_state': final_state,
            'energy_changes': energy_changes,
            'is_attractor': self.is_stable(final_state)
        }

class HopfieldVisualizer:
    def __init__(self, root):
        """
        初始化可视化界面
        :param root: Tk根窗口
        """
        self.root = root
        self.root.title("离散型Hopfield神经网络可视化")
        self.root.geometry("1400x900")
        
        # 创建Hopfield网络实例
        self.network = DiscreteHopfieldNetwork(4)
        
        # 初始化一些预定义模式
        self.init_patterns()
        
        # 训练网络
        self.network.train(self.patterns)
        
        # 控制运行的标志
        self.running = False
        self.run_thread = None
        
        self.setup_ui()
        self.update_visualization()
        
    def init_patterns(self):
        """
        初始化训练模式
        """
        # 定义一些简单的模式（4个神经元）
        pattern1 = np.array([1, 1, -1, -1])   # 模式1: [1,1,0,0] -> [1,1,-1,-1]
        pattern2 = np.array([-1, 1, 1, -1])   # 模式2: [0,1,1,0] -> [-1,1,1,-1]
        pattern3 = np.array([1, -1, -1, 1])   # 模式3: [1,0,0,1] -> [1,-1,-1,1]
        pattern4 = np.array([-1, -1, 1, 1])   # 模式4: [0,0,1,1] -> [-1,-1,1,1]
        
        self.patterns = [pattern1, pattern2, pattern3, pattern4]
        
    def setup_ui(self):
        """
        设置用户界面
        """
        # 主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 控制面板
        control_frame = tk.LabelFrame(main_frame, text="控制面板", padx=10, pady=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 模式选择
        pattern_frame = tk.Frame(control_frame)
        pattern_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(pattern_frame, text="训练模式:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        self.pattern_vars = []
        pattern_names = ["模式1 [1,1,-1,-1]", "模式2 [-1,1,1,-1]", "模式3 [1,-1,-1,1]", "模式4 [-1,-1,1,1]"]
        
        for i, pattern_name in enumerate(pattern_names):
            var = tk.BooleanVar(value=True)
            chk = tk.Checkbutton(pattern_frame, text=pattern_name, variable=var)
            chk.pack(anchor=tk.W)
            self.pattern_vars.append(var)
        
        # 操作按钮
        button_frame = tk.Frame(control_frame)
        button_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(button_frame, text="操作:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        train_button = tk.Button(button_frame, text="重新训练", command=self.retrain_network)
        train_button.pack(pady=2)
        
        self.run_button = tk.Button(button_frame, text="开始异步更新", command=self.toggle_run)
        self.run_button.pack(pady=2)
        
        update_button = tk.Button(button_frame, text="单步异步更新", command=self.single_async_update)
        update_button.pack(pady=2)
        
        sync_update_button = tk.Button(button_frame, text="同步更新", command=self.sync_update)
        sync_update_button.pack(pady=2)
        
        reset_button = tk.Button(button_frame, text="重置状态", command=self.reset_state)
        reset_button.pack(pady=2)
        
        find_attr_button = tk.Button(button_frame, text="查找吸引子", command=self.find_attractors)
        find_attr_button.pack(pady=2)
        
        converge_button = tk.Button(button_frame, text="收敛分析", command=self.convergence_analysis)
        converge_button.pack(pady=2)
        
        # 网络参数
        param_frame = tk.Frame(control_frame)
        param_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Label(param_frame, text="网络参数:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        # 神经元状态设置
        state_frame = tk.Frame(param_frame)
        state_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(state_frame, text="当前状态:").pack(side=tk.LEFT)
        
        self.state_vars = []
        for i in range(4):
            var = tk.IntVar(value=self.network.state[i])
            scale = tk.Scale(state_frame, from_=-1, to=1, orient=tk.HORIZONTAL, 
                           variable=var, length=100)
            scale.pack(side=tk.LEFT, padx=5)
            self.state_vars.append(var)
        
        set_state_button = tk.Button(state_frame, text="设置状态", command=self.set_state)
        set_state_button.pack(side=tk.LEFT, padx=(10, 0))
        
        # 显示区域
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # 网络结构图
        network_frame = tk.LabelFrame(display_frame, text="网络结构", padx=10, pady=10)
        network_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.network_fig, self.network_ax = plt.subplots(figsize=(5, 5))
        self.network_canvas = FigureCanvasTkAgg(self.network_fig, network_frame)
        self.network_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 能量变化图
        energy_frame = tk.LabelFrame(display_frame, text="能量变化", padx=10, pady=10)
        energy_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.energy_fig, self.energy_ax = plt.subplots(figsize=(5, 3))
        self.energy_canvas = FigureCanvasTkAgg(self.energy_fig, energy_frame)
        self.energy_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 吸引子能量图
        attractor_frame = tk.LabelFrame(display_frame, text="吸引子能量", padx=10, pady=10)
        attractor_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.attractor_fig, self.attractor_ax = plt.subplots(figsize=(5, 3))
        self.attractor_canvas = FigureCanvasTkAgg(self.attractor_fig, attractor_frame)
        self.attractor_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 信息显示区域
        info_frame = tk.Frame(main_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # 吸引子信息
        attractor_info_frame = tk.LabelFrame(info_frame, text="吸引子分析", padx=10, pady=10)
        attractor_info_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.attractor_text = tk.Text(attractor_info_frame, height=8)
        self.attractor_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = tk.Scrollbar(attractor_info_frame, command=self.attractor_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.attractor_text.config(yscrollcommand=scrollbar.set)
        
        # 日志信息
        log_frame = tk.LabelFrame(info_frame, text="运行日志", padx=10, pady=10)
        log_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=8)
        self.log_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
        
    def log_message(self, message):
        """
        添加日志信息
        """
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        
    def retrain_network(self):
        """
        重新训练网络
        """
        # 获取选中的模式
        selected_patterns = []
        for i, var in enumerate(self.pattern_vars):
            if var.get():
                selected_patterns.append(self.patterns[i])
        
        if len(selected_patterns) == 0:
            self.log_message("错误: 至少选择一个训练模式")
            return
            
        # 重新训练网络
        self.network.train(selected_patterns)
        self.log_message(f"网络已使用{len(selected_patterns)}个模式重新训练")
        self.update_visualization()
        
    def toggle_run(self):
        """
        切换运行状态
        """
        if not self.running:
            self.running = True
            self.run_button.config(text="停止异步更新")
            self.run_thread = threading.Thread(target=self.run_continuous)
            self.run_thread.daemon = True
            self.run_thread.start()
        else:
            self.running = False
            self.run_button.config(text="开始异步更新")
    
    def run_continuous(self):
        """
        连续异步更新
        """
        while self.running:
            self.network.asynchronous_update(1)
            self.root.after(0, self.update_visualization)
            time.sleep(0.2)  # 控制更新速度
    
    def single_async_update(self):
        """
        单步异步更新
        """
        prev_energy = self.network.energy()
        self.network.asynchronous_update(1)
        new_energy = self.network.energy()
        
        self.update_visualization()
        self.log_message(f"异步更新完成 - 能量: {prev_energy:.4f} → {new_energy:.4f}")
        
    def sync_update(self):
        """
        同步更新
        """
        prev_energy = self.network.energy()
        self.network.synchronous_update(1)
        new_energy = self.network.energy()
        
        self.update_visualization()
        self.log_message(f"同步更新完成 - 能量: {prev_energy:.4f} → {new_energy:.4f}")
        
    def reset_state(self):
        """
        重置网络状态
        """
        self.network.state = np.random.choice([-1, 1], self.network.n_neurons)
        self.network.state_history = [self.network.state.copy()]
        self.network.energy_history = [self.network.energy()]
        
        # 更新UI控件
        for i, var in enumerate(self.state_vars):
            var.set(self.network.state[i])
            
        self.update_visualization()
        self.log_message("网络状态已重置为随机状态")
        
    def set_state(self):
        """
        设置网络状态
        """
        for i, var in enumerate(self.state_vars):
            self.network.state[i] = var.get()
            
        self.network.state_history = [self.network.state.copy()]
        self.network.energy_history = [self.network.energy()]
        self.update_visualization()
        self.log_message(f"网络状态已设置为: {self.network.state}")
        
    def find_attractors(self):
        """
        查找并显示吸引子
        """
        self.log_message("正在查找吸引子...")
        self.attractor_text.delete(1.0, tk.END)
        
        # 查找吸引子
        attractors = self.network.find_attractors()
        
        # 显示结果
        self.attractor_text.insert(tk.END, f"找到 {len(attractors)} 个吸引子:\n\n")
        
        for i, attractor in enumerate(attractors):
            self.attractor_text.insert(tk.END, f"吸引子 {i+1}:\n")
            self.attractor_text.insert(tk.END, f"  状态: {attractor['state']}\n")
            self.attractor_text.insert(tk.END, f"  能量: {attractor['energy']:.4f}\n")
            self.attractor_text.insert(tk.END, f"  是否稳定: {self.network.is_stable(attractor['state'])}\n\n")
        
        # 更新吸引子能量图
        self.update_attractor_plot(attractors)
            
        self.log_message(f"吸引子查找完成，共找到 {len(attractors)} 个吸引子")
        
    def convergence_analysis(self):
        """
        进行收敛分析
        """
        self.log_message("正在进行收敛分析...")
        
        # 使用当前状态作为初始状态
        initial_state = self.network.state.copy()
        result = self.network.convergence_analysis(initial_state)
        
        # 显示结果
        self.log_message(f"收敛分析结果:")
        self.log_message(f"  初始状态: {initial_state}")
        self.log_message(f"  最终状态: {result['final_state']}")
        self.log_message(f"  收敛步数: {result['convergence_steps']}")
        self.log_message(f"  是否为吸引子: {result['is_attractor']}")
        
        # 更新能量变化图
        self.update_energy_plot(result['energy_changes'])
        
    def update_visualization(self):
        """
        更新所有可视化内容
        """
        # 更新网络结构图
        self.update_network_plot()
        
        # 更新能量变化图
        self.update_energy_plot()
        
        # 更新状态显示
        for i, var in enumerate(self.state_vars):
            var.set(self.network.state[i])
            
    def update_network_plot(self):
        """
        更新网络结构图
        """
        self.network_ax.clear()
        
        # 设置神经元位置（正方形布局）
        positions = {
            0: (0, 1),    # 上
            1: (1, 0),    # 右
            2: (0, -1),   # 下
            3: (-1, 0)    # 左
        }
        
        # 绘制神经元
        colors = ['red' if s == 1 else 'blue' for s in self.network.state]
        labels = ['1' if s == 1 else '-1' for s in self.network.state]
        
        for i in range(4):
            x, y = positions[i]
            self.network_ax.scatter(x, y, s=800, c=colors[i], edgecolors='black', linewidth=2)
            self.network_ax.text(x, y, f'N{i+1}\n{labels[i]}', 
                               ha='center', va='center', fontsize=12, weight='bold')
        
        # 绘制连接线和权重
        for i in range(4):
            for j in range(i+1, 4):
                x1, y1 = positions[i]
                x2, y2 = positions[j]
                
                # 根据权重大小和正负设置线条样式
                weight = self.network.weights[i, j]
                linewidth = min(3, max(0.5, abs(weight)))
                color = 'green' if weight > 0 else 'red'
                
                # 绘制连接线
                self.network_ax.plot([x1, x2], [y1, y2], color=color, alpha=0.7, linewidth=linewidth)
                
                # 在连线旁边显示权重
                mid_x, mid_y = (x1+x2)/2, (y1+y2)/2
                # 根据权重大小调整显示位置
                offset_x, offset_y = 0.1*(y2-y1), 0.1*(x1-x2)
                self.network_ax.text(mid_x+offset_x, mid_y+offset_y, f'{weight:.2f}', 
                                   ha='center', va='center', fontsize=9,
                                   bbox=dict(boxstyle="round,pad=0.2", facecolor="white", alpha=0.8))
        
        self.network_ax.set_xlim(-1.5, 1.5)
        self.network_ax.set_ylim(-1.5, 1.5)
        self.network_ax.set_aspect('equal')
        self.network_ax.axis('off')
        self.network_ax.set_title('Hopfield网络结构')
        self.network_canvas.draw()
        
    def update_energy_plot(self, energy_history=None):
        """
        更新能量变化图
        """
        self.energy_ax.clear()
        
        if energy_history is None:
            energy_history = self.network.energy_history
            
        if len(energy_history) > 0:
            self.energy_ax.plot(energy_history, 'b-o', markersize=4)
            self.energy_ax.set_xlabel('更新步骤')
            self.energy_ax.set_ylabel('能量')
            self.energy_ax.set_title('网络能量变化')
            self.energy_ax.grid(True, alpha=0.3)
        
        self.energy_canvas.draw()
        
    def update_attractor_plot(self, attractors):
        """
        更新吸引子能量图
        """
        self.attractor_ax.clear()
        
        if len(attractors) > 0:
            # 提取吸引子的能量值
            energies = [a['energy'] for a in attractors]
            states = [str(a['state']) for a in attractors]
            
            # 绘制柱状图
            self.attractor_ax.bar(range(len(attractors)), energies)
            self.attractor_ax.set_xlabel('吸引子')
            self.attractor_ax.set_ylabel('能量')
            self.attractor_ax.set_title('吸引子能量分布')
            self.attractor_ax.set_xticks(range(len(attractors)))
            self.attractor_ax.set_xticklabels(states, rotation=45)
            self.attractor_ax.grid(True, alpha=0.3)
        
        self.attractor_canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = HopfieldVisualizer(root)
    root.mainloop()