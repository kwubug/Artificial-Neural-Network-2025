import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.patches as patches
from matplotlib.gridspec import GridSpec
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

# 设置matplotlib字体
import matplotlib
import matplotlib.font_manager as fm

# 尝试设置中文字体
try:
    # 查找可用的中文字体
    chinese_fonts = [f.name for f in fm.fontManager.ttflist if 'CJK' in f.name or 'Noto' in f.name or 'AR PL' in f.name]
    if chinese_fonts:
        # 优先使用Noto Sans CJK SC
        if 'Noto Sans CJK SC' in chinese_fonts:
            plt.rcParams['font.family'] = 'Noto Sans CJK SC'
        elif 'AR PL UMing TW MBE' in chinese_fonts:
            plt.rcParams['font.family'] = 'AR PL UMing TW MBE'
        else:
            plt.rcParams['font.family'] = chinese_fonts[0]
        print(f"使用中文字体: {plt.rcParams['font.family']}")
    else:
        plt.rcParams['font.family'] = 'DejaVu Sans'
        print("未找到中文字体，使用默认字体")
except:
    plt.rcParams['font.family'] = 'DejaVu Sans'
    print("字体设置失败，使用默认字体")

# 如果中文字体不可用，使用英文标签
CHINESE_FONT_AVAILABLE = True
try:
    # 测试中文字体是否可用
    fig_test = plt.figure()
    ax_test = fig_test.add_subplot(111)
    ax_test.text(0.5, 0.5, '测试', fontsize=12)
    plt.close(fig_test)
except:
    CHINESE_FONT_AVAILABLE = False
    print("警告: 中文字体不可用，将使用英文标签")

plt.rcParams['axes.unicode_minus'] = False

class GradientDescentVisualizer:
    """梯度下降可视化类"""
    
    def __init__(self):
        self.fig = None
        self.ax = None
        
    def multimodal_function(self, x, y):
        """
        多模态测试函数 - 使用更均匀的梯度变化设计
        全局最小值在 (0, 0)，函数值为 0
        局部最小值在 (3, 3)、(-3, -3)、(3, -3)、(-3, 3)
        """
        # 基础函数：简单的二次函数
        f1 = 0.05 * (x**2 + y**2)
        
        # 主要局部最小值 - 确保位置正确
        f2 = 0.6 * np.exp(-((x - 3)**2 + (y - 3)**2) / 8)  # 局部最小值在(3,3)
        f3 = 0.6 * np.exp(-((x + 3)**2 + (y + 3)**2) / 8)  # 局部最小值在(-3,-3)
        f4 = 0.6 * np.exp(-((x - 3)**2 + (y + 3)**2) / 8)  # 局部最小值在(3,-3)
        f5 = 0.6 * np.exp(-((x + 3)**2 + (y - 3)**2) / 8)  # 局部最小值在(-3,3)
        
        # 中等局部最小值 - 填充中间区域
        f6 = 0.3 * np.exp(-((x - 2)**2 + (y - 2)**2) / 6)
        f7 = 0.3 * np.exp(-((x + 2)**2 + (y + 2)**2) / 6)
        f8 = 0.3 * np.exp(-((x - 2)**2 + (y + 2)**2) / 6)
        f9 = 0.3 * np.exp(-((x + 2)**2 + (y - 2)**2) / 6)
        
        # 小局部最小值 - 进一步填充
        f10 = 0.2 * np.exp(-((x - 1)**2 + (y - 1)**2) / 4)
        f11 = 0.2 * np.exp(-((x + 1)**2 + (y + 1)**2) / 4)
        f12 = 0.2 * np.exp(-((x - 1)**2 + (y + 1)**2) / 4)
        f13 = 0.2 * np.exp(-((x + 1)**2 + (y - 1)**2) / 4)
        
        # 添加一些平滑的周期性变化以填充空白
        f14 = 0.1 * np.sin(x) * np.cos(y)
        f15 = 0.1 * np.cos(x) * np.sin(y)
        f16 = 0.05 * np.sin(2*x) * np.cos(2*y)
        f17 = 0.05 * np.cos(2*x) * np.sin(2*y)
        
        return f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + f14 + f15 + f16 + f17
    
    def multimodal_gradient(self, x, y):
        """多模态函数的梯度"""
        # 基础函数的梯度
        gx1 = 0.1 * x
        gy1 = 0.1 * y
        
        # 主要局部最小值的梯度
        gx2 = -0.15 * (x - 3) * np.exp(-((x - 3)**2 + (y - 3)**2) / 8)
        gy2 = -0.15 * (y - 3) * np.exp(-((x - 3)**2 + (y - 3)**2) / 8)
        
        gx3 = -0.15 * (x + 3) * np.exp(-((x + 3)**2 + (y + 3)**2) / 8)
        gy3 = -0.15 * (y + 3) * np.exp(-((x + 3)**2 + (y + 3)**2) / 8)
        
        gx4 = -0.15 * (x - 3) * np.exp(-((x - 3)**2 + (y + 3)**2) / 8)
        gy4 = -0.15 * (y + 3) * np.exp(-((x - 3)**2 + (y + 3)**2) / 8)
        
        gx5 = -0.15 * (x + 3) * np.exp(-((x + 3)**2 + (y - 3)**2) / 8)
        gy5 = -0.15 * (y - 3) * np.exp(-((x + 3)**2 + (y - 3)**2) / 8)
        
        # 中等局部最小值的梯度
        gx6 = -0.1 * (x - 2) * np.exp(-((x - 2)**2 + (y - 2)**2) / 6)
        gy6 = -0.1 * (y - 2) * np.exp(-((x - 2)**2 + (y - 2)**2) / 6)
        
        gx7 = -0.1 * (x + 2) * np.exp(-((x + 2)**2 + (y + 2)**2) / 6)
        gy7 = -0.1 * (y + 2) * np.exp(-((x + 2)**2 + (y + 2)**2) / 6)
        
        gx8 = -0.1 * (x - 2) * np.exp(-((x - 2)**2 + (y + 2)**2) / 6)
        gy8 = -0.1 * (y + 2) * np.exp(-((x - 2)**2 + (y + 2)**2) / 6)
        
        gx9 = -0.1 * (x + 2) * np.exp(-((x + 2)**2 + (y - 2)**2) / 6)
        gy9 = -0.1 * (y - 2) * np.exp(-((x + 2)**2 + (y - 2)**2) / 6)
        
        # 小局部最小值的梯度
        gx10 = -0.1 * (x - 1) * np.exp(-((x - 1)**2 + (y - 1)**2) / 4)
        gy10 = -0.1 * (y - 1) * np.exp(-((x - 1)**2 + (y - 1)**2) / 4)
        
        gx11 = -0.1 * (x + 1) * np.exp(-((x + 1)**2 + (y + 1)**2) / 4)
        gy11 = -0.1 * (y + 1) * np.exp(-((x + 1)**2 + (y + 1)**2) / 4)
        
        gx12 = -0.1 * (x - 1) * np.exp(-((x - 1)**2 + (y + 1)**2) / 4)
        gy12 = -0.1 * (y + 1) * np.exp(-((x - 1)**2 + (y + 1)**2) / 4)
        
        gx13 = -0.1 * (x + 1) * np.exp(-((x + 1)**2 + (y - 1)**2) / 4)
        gy13 = -0.1 * (y - 1) * np.exp(-((x + 1)**2 + (y - 1)**2) / 4)
        
        # 周期性变化的梯度
        gx14 = 0.1 * np.cos(x) * np.cos(y)
        gy14 = -0.1 * np.sin(x) * np.sin(y)
        
        gx15 = -0.1 * np.sin(x) * np.sin(y)
        gy15 = 0.1 * np.cos(x) * np.cos(y)
        
        gx16 = 0.2 * np.cos(2*x) * np.cos(2*y)
        gy16 = -0.2 * np.sin(2*x) * np.sin(2*y)
        
        gx17 = -0.2 * np.sin(2*x) * np.sin(2*y)
        gy17 = 0.2 * np.cos(2*x) * np.cos(2*y)
        
        gx = gx1 + gx2 + gx3 + gx4 + gx5 + gx6 + gx7 + gx8 + gx9 + gx10 + gx11 + gx12 + gx13 + gx14 + gx15 + gx16 + gx17
        gy = gy1 + gy2 + gy3 + gy4 + gy5 + gy6 + gy7 + gy8 + gy9 + gy10 + gy11 + gy12 + gy13 + gy14 + gy15 + gy16 + gy17
        
        return np.array([gx, gy])
    
    def multimodal_hessian(self, x, y):
        """多模态函数的Hessian矩阵"""
        # 主函数Hessian - 更平缓
        h11_1 = 1 - 8 * y + 24 * x**2
        h12_1 = -8 * x
        h21_1 = -8 * x
        h22_1 = 4
        
        # 局部最小值陷阱的Hessian（简化计算）
        exp1 = np.exp(-((x - 3)**2 + (y - 3)**2) / 4)
        exp2 = np.exp(-((x + 3)**2 + (y + 3)**2) / 4)
        
        h11_2 = -exp1 * (1 - (x - 3)**2 / 2)
        h12_2 = (x - 3) * (y - 3) * exp1 / 2
        h21_2 = h12_2
        h22_2 = -exp2 * (1 - (y - 3)**2 / 2)
        
        h11_3 = -exp2 * (1 - (x + 3)**2 / 2)
        h12_3 = (x + 3) * (y + 3) * exp2 / 2
        h21_3 = h12_3
        h22_3 = -exp2 * (1 - (y + 3)**2 / 2)
        
        # 噪声函数的Hessian（简化）
        h11_4 = -0.5 * np.sin(x) * np.cos(y) - 0.8 * np.sin(2*x + y)
        h12_4 = -0.5 * np.cos(x) * np.sin(y) - 0.2 * np.sin(2*x + y)
        h21_4 = h12_4
        h22_4 = -0.5 * np.sin(x) * np.cos(y) - 0.2 * np.sin(2*x + y)
        
        h11 = h11_1 + h11_2 + h11_3 + h11_4
        h12 = h12_1 + h12_2 + h12_3 + h12_4
        h21 = h21_1 + h21_2 + h21_3 + h21_4
        h22 = h22_1 + h22_2 + h22_3 + h22_4
        
        return np.array([[h11, h12], [h21, h22]])
    
    def steepest_descent(self, x0, y0, max_iter=500, learning_rate=0.01, aggressive=False):
        """最速下降法"""
        trajectory = [(x0, y0)]
        x, y = x0, y0
        
        for i in range(max_iter):
            grad = self.multimodal_gradient(x, y)
            
            # 根据aggressive参数调整学习策略
            if aggressive:
                # 激进模式：更大的初始学习率，更少的线搜索
                alpha = learning_rate * 2.0
                for _ in range(10):
                    new_x = x - alpha * grad[0]
                    new_y = y - alpha * grad[1]
                    if self.multimodal_function(new_x, new_y) < self.multimodal_function(x, y):
                        break
                    alpha *= 0.5  # 更激进的衰减
            else:
                # 保守模式：较小的学习率，更多的线搜索
                alpha = learning_rate * 0.5
                for _ in range(30):
                    new_x = x - alpha * grad[0]
                    new_y = y - alpha * grad[1]
                    if self.multimodal_function(new_x, new_y) < self.multimodal_function(x, y):
                        break
                    alpha *= 0.8  # 更温和的衰减
            
            x = x - alpha * grad[0]
            y = y - alpha * grad[1]
            trajectory.append((x, y))
            
            # 收敛判断 - 放宽条件
            if np.linalg.norm(grad) < 1e-4:
                break
                
        return np.array(trajectory)
    
    def newton_method(self, x0, y0, max_iter=500, damping_factor=1.0):
        """改进的牛顿法"""
        trajectory = [(x0, y0)]
        x, y = x0, y0
        
        for i in range(max_iter):
            grad = self.multimodal_gradient(x, y)
            hess = self.multimodal_hessian(x, y)
            current_value = self.multimodal_function(x, y)
            
            # 牛顿步长 - 添加阻尼
            try:
                # 添加正则化项避免奇异矩阵，使用damping_factor控制
                reg = 1e-6 * damping_factor
                hess_reg = hess + reg * np.eye(2)
                delta = np.linalg.solve(hess_reg, -grad)
                
                # 更激进的步长控制
                step_size = np.linalg.norm(delta)
                max_step = 5.0 / damping_factor  # 进一步增加最大步长
                
                # 简化的线搜索
                alpha = 1.0
                for _ in range(5):  # 减少线搜索次数
                    new_x = x + alpha * delta[0]
                    new_y = y + alpha * delta[1]
                    new_value = self.multimodal_function(new_x, new_y)
                    
                    if new_value < current_value:
                        break
                    alpha *= 0.3  # 更激进的衰减
                
                # 如果线搜索失败，使用梯度下降
                if alpha < 0.01:
                    delta = -0.2 * grad
                    alpha = 1.0
                
                x = x + alpha * delta[0]
                y = y + alpha * delta[1]
                    
            except np.linalg.LinAlgError:
                # 如果Hessian矩阵奇异，使用梯度下降
                delta = -0.1 * grad
                x = x + delta[0]
                y = y + delta[1]
            
            trajectory.append((x, y))
            
            # 更严格的收敛判断
            if np.linalg.norm(grad) < 1e-6:
                break
                
        return np.array(trajectory)
    
    def conjugate_gradient(self, x0, y0, max_iter=500, restart_frequency=10):
        """共轭梯度法"""
        trajectory = [(x0, y0)]
        x, y = x0, y0
        
        # 初始梯度
        grad = self.multimodal_gradient(x, y)
        d = -grad  # 初始搜索方向
        
        for i in range(max_iter):
            # 线搜索找到最优步长
            alpha = self.line_search(x, y, d)
            
            # 更新位置
            x = x + alpha * d[0]
            y = y + alpha * d[1]
            trajectory.append((x, y))
            
            # 计算新梯度
            new_grad = self.multimodal_gradient(x, y)
            
            # 根据restart_frequency决定是否重启
            if i % restart_frequency == 0 and i > 0:
                # 重启：重置搜索方向为负梯度方向
                d = -new_grad
            else:
                # 计算共轭系数 (Polak-Ribiere公式)
                grad_dot = np.dot(grad, grad)
                if grad_dot > 1e-12:  # 避免除零
                    beta = np.dot(new_grad, new_grad - grad) / grad_dot
                    beta = max(0, beta)  # 确保非负
                else:
                    beta = 0
                
                # 更新搜索方向
                d = -new_grad + beta * d
            
            grad = new_grad
            
            # 收敛判断 - 放宽条件
            if np.linalg.norm(grad) < 1e-4:
                break
                
        return np.array(trajectory)
    
    def line_search(self, x, y, direction, max_alpha=1.0):
        """线搜索找到最优步长"""
        alpha = max_alpha
        f0 = self.multimodal_function(x, y)
        
        for _ in range(30):  # 增加搜索次数
            new_x = x + alpha * direction[0]
            new_y = y + alpha * direction[1]
            f_new = self.multimodal_function(new_x, new_y)
            
            if f_new < f0:
                return alpha
            alpha *= 0.7  # 更温和的衰减
            
        return max(alpha, 0.001)  # 确保返回一个小的正值
    
    def create_surface_plot(self, x_range=(-5, 5), y_range=(-5, 5), resolution=150):
        """创建性能曲面图"""
        x = np.linspace(x_range[0], x_range[1], resolution)
        y = np.linspace(y_range[0], y_range[1], resolution)
        X, Y = np.meshgrid(x, y)
        Z = self.multimodal_function(X, Y)
        
        # 创建更大的图形布局
        self.fig = plt.figure(figsize=(32, 22))
        
        # 使用传统的subplot布局，但确保每个子图都有足够空间
        # 3D曲面图
        self.ax = self.fig.add_subplot(2, 3, 1, projection='3d')
        surf = self.ax.plot_surface(X, Y, Z, cmap=cm.viridis, alpha=0.8, 
                                  linewidth=0, antialiased=True)
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('f(x,y)')
        title_3d = '性能曲面' if CHINESE_FONT_AVAILABLE else 'Multimodal Function Surface'
        self.ax.set_title(title_3d, fontsize=14, fontweight='bold')
        
        # 设置3D图的坐标轴范围，确保曲面完整显示
        self.ax.set_xlim(X.min(), X.max())
        self.ax.set_ylim(Y.min(), Y.max())
        self.ax.set_zlim(Z.min(), Z.max())
        
        return X, Y, Z
    
    def plot_contour_with_trajectories(self, X, Y, Z, trajectories, labels, colors):
        """在等高线图上绘制轨迹"""
        # 主等高线图 - 显示所有轨迹对比
        ax1 = self.fig.add_subplot(2, 3, 2)
        # 创建更密集且均匀的等高线级别
        z_min, z_max = np.min(Z), np.max(Z)
        # 使用线性尺度创建更密集的等高线，确保覆盖整个范围
        levels = np.linspace(z_min, z_max, 60)
        contour = ax1.contour(X, Y, Z, levels=levels, colors='lightgray', alpha=0.7, linewidths=0.8)
        contour_filled = ax1.contourf(X, Y, Z, levels=levels, cmap=cm.viridis, alpha=0.3)
        
        # 设置坐标轴范围，确保等高线完整显示
        ax1.set_xlim(X.min(), X.max())
        ax1.set_ylim(Y.min(), Y.max())
        
        # 不标记局部最小值点
        
        # 绘制轨迹 - 增强视觉效果
        for i, (traj, label, color) in enumerate(zip(trajectories, labels, colors)):
            # 轨迹线
            ax1.plot(traj[:, 0], traj[:, 1], color=color, linewidth=3, 
                    label=label, alpha=0.9, zorder=5)
            
            # 起点 - 大方形
            ax1.plot(traj[0, 0], traj[0, 1], color=color, marker='s', 
                    markersize=12, markeredgecolor='black', markeredgewidth=2, 
                    zorder=6, label=f'{label} Start' if i == 0 else "")
            
            # 终点 - 大星形
            ax1.plot(traj[-1, 0], traj[-1, 1], color=color, marker='*', 
                    markersize=15, markeredgecolor='black', markeredgewidth=2,
                    zorder=6, label=f'{label} End' if i == 0 else "")
            
            # 添加箭头显示方向
            if len(traj) > 1:
                for j in range(0, len(traj)-1, max(1, len(traj)//10)):
                    dx = traj[j+1, 0] - traj[j, 0]
                    dy = traj[j+1, 1] - traj[j, 1]
                    ax1.arrow(traj[j, 0], traj[j, 1], dx*0.3, dy*0.3, 
                             head_width=0.05, head_length=0.05, fc=color, ec=color, alpha=0.7)
        
        ax1.set_xlabel('X', fontsize=12)
        ax1.set_ylabel('Y', fontsize=12)
        title_contour = '优化轨迹对比' if CHINESE_FONT_AVAILABLE else 'Optimization Trajectories Comparison'
        ax1.set_title(title_contour, fontsize=14, fontweight='bold')
        ax1.legend(fontsize=10, loc='upper right')
        ax1.grid(True, alpha=0.3)
        
        # 函数值收敛图
        ax2 = self.fig.add_subplot(2, 3, 3)
        for i, (traj, label, color) in enumerate(zip(trajectories, labels, colors)):
            function_values = [self.multimodal_function(x, y) for x, y in traj]
            ax2.semilogy(function_values, color=color, linewidth=3, 
                        label=label, marker='o', markersize=4, alpha=0.8)
        
        ax2.set_xlabel('迭代次数' if CHINESE_FONT_AVAILABLE else 'Iterations', fontsize=12)
        ax2.set_ylabel('函数值 (对数尺度)' if CHINESE_FONT_AVAILABLE else 'Function Value (log scale)', fontsize=12)
        title_convergence = '收敛性能对比' if CHINESE_FONT_AVAILABLE else 'Convergence Performance'
        ax2.set_title(title_convergence, fontsize=14, fontweight='bold')
        ax2.legend(fontsize=10)
        ax2.grid(True, alpha=0.3)
        
        # 添加单独的子图显示每种算法的详细轨迹
        for i, (traj, label, color) in enumerate(zip(trajectories, labels, colors)):
            ax_sub = self.fig.add_subplot(2, 3, 4 + i)
            # 为子图也创建均匀的等高线级别
            z_min, z_max = np.min(Z), np.max(Z)
            levels_sub = np.linspace(z_min, z_max, 40)
            contour_sub = ax_sub.contour(X, Y, Z, levels=levels_sub, colors='gray', alpha=0.6)
            ax_sub.clabel(contour_sub, inline=True, fontsize=6)
            
            # 设置子图坐标轴范围，确保等高线完整显示
            ax_sub.set_xlim(X.min(), X.max())
            ax_sub.set_ylim(Y.min(), Y.max())
            
            # 不标记关键点
            
            # 绘制单个轨迹
            ax_sub.plot(traj[:, 0], traj[:, 1], color=color, linewidth=3, 
                       marker='o', markersize=4, alpha=0.8)
            ax_sub.plot(traj[0, 0], traj[0, 1], color=color, marker='s', 
                       markersize=10, markeredgecolor='black', markeredgewidth=2)
            ax_sub.plot(traj[-1, 0], traj[-1, 1], color=color, marker='*', 
                       markersize=12, markeredgecolor='black', markeredgewidth=2)
            
            ax_sub.set_xlabel('X', fontsize=10)
            ax_sub.set_ylabel('Y', fontsize=10)
            ax_sub.set_title(f'{label} 轨迹' if CHINESE_FONT_AVAILABLE else f'{label} Trajectory', fontsize=12, fontweight='bold')
            ax_sub.legend(fontsize=8)
            ax_sub.grid(True, alpha=0.3)
        
    def visualize_optimization(self, start_point=(4.5, 4.5)):
        """主可视化函数"""
        print("正在生成梯度下降可视化...")
        print(f"使用多模态测试函数，包含网格状局部最小值陷阱")
        print(f"全局最小值在 (0, 0)")
        print(f"主要局部最小值在四个角落: (3,3)、(-3,-3)、(3,-3)、(-3,3)")
        print(f"还有多个中等和小幅度的局部最小值分布在整个区域")
        print()
        
        # 创建性能曲面
        X, Y, Z = self.create_surface_plot()
        
        # 运行三种优化算法，从同一个起点出发但使用不同参数
        print("运行最速下降法（激进模式）...")
        print(f"起始点: {start_point}")
        sd_trajectory = self.steepest_descent(start_point[0], start_point[1], aggressive=True, learning_rate=0.05)
        
        print("运行牛顿法（无阻尼）...")
        print(f"起始点: {start_point}")
        newton_trajectory = self.newton_method(start_point[0], start_point[1], damping_factor=0.01)
        
        print("运行共轭梯度法（标准模式）...")
        print(f"起始点: {start_point}")
        cg_trajectory = self.conjugate_gradient(start_point[0], start_point[1], restart_frequency=20)
        
        # 准备绘图数据
        if CHINESE_FONT_AVAILABLE:
            labels = ['最速下降法', '牛顿法', '共轭梯度法']
        else:
            labels = ['Steepest Descent', 'Newton Method', 'Conjugate Gradient']
        colors = ['red', 'blue', 'green']
        trajectories = [sd_trajectory, newton_trajectory, cg_trajectory]
        
        # 绘制轨迹
        self.plot_contour_with_trajectories(X, Y, Z, trajectories, labels, colors)
        
        # 打印结果统计
        print("\n=== 优化结果统计 ===")
        for i, (traj, label) in enumerate(zip(trajectories, labels)):
            final_x, final_y = traj[-1]
            final_value = self.multimodal_function(final_x, final_y)
            iterations = len(traj) - 1
            
            # 判断是否陷入局部最小值
            dist_to_global = np.sqrt(final_x**2 + final_y**2)
            dist_to_local1 = np.sqrt((final_x - 3)**2 + (final_y - 3)**2)
            dist_to_local2 = np.sqrt((final_x + 3)**2 + (final_y + 3)**2)
            dist_to_local3 = np.sqrt((final_x - 3)**2 + (final_y + 3)**2)
            dist_to_local4 = np.sqrt((final_x + 3)**2 + (final_y - 3)**2)
            
            if dist_to_global < 0.5:
                result = "找到全局最小值"
            elif dist_to_local1 < 0.5:
                result = "陷入局部最小值 (3,3)"
            elif dist_to_local2 < 0.5:
                result = "陷入局部最小值 (-3,-3)"
            elif dist_to_local3 < 0.5:
                result = "陷入局部最小值 (3,-3)"
            elif dist_to_local4 < 0.5:
                result = "陷入局部最小值 (-3,3)"
            else:
                result = "未收敛到任何最小值"
            
            print(f"{label}:")
            print(f"  起始位置: ({start_point[0]:.1f}, {start_point[1]:.1f})")
            print(f"  最终位置: ({final_x:.6f}, {final_y:.6f})")
            print(f"  最终函数值: {final_value:.6f}")
            print(f"  迭代次数: {iterations}")
            print(f"  结果: {result}")
            print()
        
        plt.tight_layout(pad=4.0)
        plt.subplots_adjust(hspace=0.5, wspace=0.5, left=0.05, right=0.95, top=0.95, bottom=0.05)
        plt.show()
        
        return trajectories, labels, colors

def main():
    """主函数"""
    print("梯度下降算法可视化程序")
    print("=" * 50)
    
    # 创建可视化器
    visualizer = GradientDescentVisualizer()
    
    # 设置统一的起始点
    start_point = (-3.5, 2.0)
    
    print("使用相同起始点，通过不同算法参数实现路径差异化:")
    print(f"起始点: {start_point} - 函数值: {visualizer.multimodal_function(start_point[0], start_point[1]):.6f}")
    print("算法参数设置:")
    print("- 最速下降法: 激进模式（大学习率，少线搜索）")
    print("- 牛顿法: 无阻尼模式（damping_factor=0.01）")
    print("- 共轭梯度法: 标准模式（每20步重启）")
    print()
    
    # 运行可视化
    trajectories, labels, colors = visualizer.visualize_optimization(start_point)
    
    print("可视化完成！")
    print("\n说明:")
    print("- 红色轨迹: 最速下降法 (Steepest Descent)")
    print("- 蓝色轨迹: 牛顿法 (Newton Method)") 
    print("- 绿色轨迹: 共轭梯度法 (Conjugate Gradient)")
    print("- 方形标记: 起始点")
    print("- 星形标记: 最终点")
    print("- 箭头: 显示优化方向")

if __name__ == "__main__":
    main()
