# 2025_10_22.py
import math
import os
from dataclasses import dataclass
from typing import Tuple, List

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 配置参数
GRID_H, GRID_W = 5, 5
INPUT_DIM = 4
TOTAL_STEPS = 10_000
SNAPSHOT_EVERY = 200
SEED = 7  # 确保结果可复现

# 五组4维输入数据
patterns = np.array(
    [
        [1, 0, 0, 0],  # X1
        [1, 1, 0, 0],  # X2
        [1, 1, 1, 0],  # X3
        [0, 1, 0, 0],  # X4
        [1, 1, 1, 1],  # X5
    ],
    dtype=np.float64,
)

# 红紫色系配色方案（统一主题）
COLORS = {
    "grid_bg": "#E6E6FA",    # 淡紫色（网格背景点）
    "bmu_point": "#C71585",  # 紫红色（BMU点）
    "text": "#800080",       # 深紫色（文字标签）
    "title": "#4B0082",      # 靛蓝色（标题）
    "grid_line": "#DDA0DD",  # 淡紫色（网格线）
    "line_plot": "#9370DB",  # 中紫色（曲线）
    "axis_label": "#800080"  # 深紫色（坐标轴标签）
}

@dataclass
class SOM:
    height: int
    width: int
    dim: int
    rng: np.random.Generator

    def __post_init__(self) -> None:
        self.weights = self.rng.random((self.height, self.width, self.dim))
        ys, xs = np.meshgrid(np.arange(self.height), np.arange(self.width), indexing="ij")
        self.coords = np.stack([ys, xs], axis=-1)  # (H, W, 2)

    @staticmethod
    def _linear(a: float, b: float, t: float, t0: float, t1: float) -> float:
        if t <= t0: return a
        if t >= t1: return b
        r = (t - t0) / float(t1 - t0)
        return (1 - r) * a + r * b

    def learning_rate(self, t: int) -> float:
        if t < 1000: return self._linear(0.5, 0.04, t, 0, 999)
        return self._linear(0.04, 0.0, t, 1000, TOTAL_STEPS - 1)

    def sigma(self, t: int) -> float:
        if t < 1000: return self._linear(2.0, 0.0, t, 0, 999)
        return 0.0

    def bmu(self, x: np.ndarray) -> Tuple[int, int]:
        d = np.linalg.norm(self.weights - x[None, None, :], axis=-1)
        idx = np.unravel_index(np.argmin(d), d.shape)
        return int(idx[0]), int(idx[1])

    def step(self, x: np.ndarray, t: int) -> None:
        lr = self.learning_rate(t)
        sig = self.sigma(t)
        by, bx = self.bmu(x)

        if sig <= 0.0 or lr <= 0.0:
            self.weights[by, bx, :] += lr * (x - self.weights[by, bx, :])
            return

        d2 = np.sum((self.coords - np.array([by, bx])) **2, axis=-1)
        h = np.exp(-d2 / (2.0 * (sig** 2)))
        self.weights += lr * h[..., None] * (x[None, None, :] - self.weights)

    def quantization_error(self, inputs: np.ndarray) -> float:
        d = []
        for x in inputs:
            y, xj = self.bmu(x)
            d.append(np.linalg.norm(self.weights[y, xj, :] - x))
        return float(np.mean(d))

def train_and_export(output_dir: str = "./2025-10-22") -> None:
    # 创建输出目录（不存在则自动创建）
    os.makedirs(output_dir, exist_ok=True)
    rng = np.random.default_rng(SEED)
    som = SOM(GRID_H, GRID_W, INPUT_DIM, rng)

    # 训练过程记录
    snapshot_steps: List[int] = [0]
    snapshots: List[np.ndarray] = [som.weights.copy()]
    qe_history: List[float] = [som.quantization_error(patterns)]

    # 训练SOM
    for t in range(TOTAL_STEPS):
        x = patterns[t % len(patterns)]
        som.step(x, t)
        qe_history.append(som.quantization_error(patterns))
        if (t + 1) % SNAPSHOT_EVERY == 0:
            snapshot_steps.append(t + 1)
            snapshots.append(som.weights.copy())

    # 保存快照数据
    np.savez(
        os.path.join(output_dir, "som_snapshots.npz"),
        weights=np.stack(snapshots, axis=0),
        steps=np.array(snapshot_steps, dtype=np.int32),
    )

    # 1. 学习率曲线（红紫色系）
    lrs = [som.learning_rate(t) for t in range(TOTAL_STEPS)]
    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(TOTAL_STEPS), lrs, color=COLORS["line_plot"], linewidth=2)
    plt.title("Learning Rate Schedule", color=COLORS["title"], fontsize=12)
    plt.xlabel("Training Step", color=COLORS["axis_label"])
    plt.ylabel("Learning Rate", color=COLORS["axis_label"])
    plt.grid(True, linestyle='--', color=COLORS["grid_line"], alpha=0.7)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "som_lr.png"), dpi=160)
    plt.close()

    # 2. 邻域半径曲线（红紫色系）
    sigs = [som.sigma(t) for t in range(TOTAL_STEPS)]
    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(TOTAL_STEPS), sigs, color=COLORS["line_plot"], linewidth=2)
    plt.title("Neighborhood Radius (sigma)", color=COLORS["title"], fontsize=12)
    plt.xlabel("Training Step", color=COLORS["axis_label"])
    plt.ylabel("Sigma (nodes)", color=COLORS["axis_label"])
    plt.grid(True, linestyle='--', color=COLORS["grid_line"], alpha=0.7)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "som_radius.png"), dpi=160)
    plt.close()

    # 3. 量化误差曲线（红紫色系）
    plt.figure(figsize=(8, 5))
    plt.plot(np.arange(len(qe_history)), qe_history, color=COLORS["line_plot"], linewidth=2)
    plt.title("Quantization Error", color=COLORS["title"], fontsize=12)
    plt.xlabel("Training Step", color=COLORS["axis_label"])
    plt.ylabel("Mean BMU Distance", color=COLORS["axis_label"])
    plt.grid(True, linestyle='--', color=COLORS["grid_line"], alpha=0.7)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "som_qe.png"), dpi=160)
    plt.close()

    # 4. 最终映射散点图（红紫色系）
    yy, xx = np.meshgrid(np.arange(GRID_H), np.arange(GRID_W), indexing="ij")
    plt.figure(figsize=(6, 6))
    # 网格背景点（淡紫色）
    plt.scatter(xx.flatten(), yy.flatten(), s=30, alpha=0.5, color=COLORS["grid_bg"])
    # 标记每个样本的BMU位置
    final_bmus = []
    for i, x in enumerate(patterns, start=1):
        by, bx = som.bmu(x)
        final_bmus.append((f"X{i}", by, bx))
        # BMU点（紫红色，带白色边框）
        plt.scatter([bx], [by], s=100, color=COLORS["bmu_point"],
                   edgecolors='white', linewidths=1.5)
        # 标签文字（深紫色）
        plt.text(bx + 0.1, by + 0.1, f"X{i}", color=COLORS["text"], fontsize=10)
    plt.gca().invert_yaxis()  # 保持坐标与网格索引一致
    plt.title("Final Mapping of 5 Inputs on 5x5 SOM Grid", color=COLORS["title"], fontsize=12)
    plt.xlabel("X (column index)", color=COLORS["axis_label"])
    plt.ylabel("Y (row index)", color=COLORS["axis_label"])
    plt.xticks(range(GRID_W))
    plt.yticks(range(GRID_H))
    plt.grid(True, linestyle="--", color=COLORS["grid_line"], alpha=0.7)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "som_final_mapping.png"), dpi=160)
    plt.close()

    # 保存BMU坐标CSV
    pd.DataFrame(final_bmus, columns=["pattern", "row", "col"]) \
      .to_csv(os.path.join(output_dir, "som_final_bmu.csv"), index=False)

if __name__ == "__main__":
    train_and_export()  # 自动输出到2025-10-22文件夹