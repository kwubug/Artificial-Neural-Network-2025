# Neural Network Sandbox

An assignment collection for course _CE5037 Neural Network_ in National Central University, Taiwan.

## Features

* Back-end completely separates from front-end by `setContextProperty()` and [`BridgeProperty`](./nn_sandbox/bridges/bridge.py)
* Animated Qt Chart in QML.
* Automatically update UI when specific variables in back-end changed.
* Modulized UI components.

> Actually, neural networks are not the point.

## Previews

![perceptron preview](https://i.imgur.com/47GYvuU.gif)

![mlp preview](https://i.imgur.com/bl2NqJr.gif)

![rbfn preview](https://i.imgur.com/PFyYhwb.gif)

![som preview](https://i.imgur.com/IhDmror.gif)

## Introduction to Architecture

I created the toy, Neural Network Sandbox, to explore if I could completely separate business logic (algorithms) from UI with Python and QML. Take [`mlp_algorithm.py`](./nn_sandbox/backend/algorithms/mlp_algorithm.py) for example, the class does not know anything about UI but the users still can interact with it via a QML app.

The QML UI needs to automatically observe some variables in the business logic. Thus, I need to inherit each algorithm with the Observable class. For example, [`ObservableMlpAlgorithm`](./nn_sandbox/bridges/mlp_bridge.py) inherits [`Observable`](./nn_sandbox/bridges/observer.py) and [`MlpAlgorithm`](./nn_sandbox/backend/algorithms/mlp_algorithm.py). Whenever a property has changed in the `MlpAlgorithm`, `ObserableMlpAlgorithm.__setattr__(self, name, value)` would be called. I can know which property has changed with the `name` parameter and notify the `Observer` with its new value.

But who is the observer? The [bridge classes](./nn_sandbox/bridges/bridge.py) are the observer in this scenario. I created the bridge classes (e.g. [`mlp_bridge.py`](./nn_sandbox/bridges/mlp_bridge.py)) containing a list of `BridgeProperty`. When a property has been updated by the observable via `setattr(self, name, value)`, the corresponding (having the same name) `BridgeProperty` will get updated. When a `BridgeProperty` has been updated, its setter method will be called and emit PyQt signal to change QML UI.

In the early version of the project, there is no `BridgeProperty` class. For instance, [the old version of `perceptron_bridge.py`](https://github.com/seanwu1105/neural-network-sandbox/blob/3bfe07ba4db2a3f78a273b94860fabc7cf0df34a/nn_sandbox/frontend/bridges/perceptron_bridge.py) having multiple pyqtProperty and its setter. To make the code cleaner, I have to create these `pyqtProperties` dynamically. `BridgeProperty` and [`BridgeMeta`](./nn_sandbox/bridges/bridge.py) classes solve the problem. You can find more details from [this Stackoverflow answer](https://stackoverflow.com/questions/48425316/how-to-create-pyqt-properties-dynamically/48432653#48432653) about creating `pyqtProperty` dynamically and [this Stackoverflow answer](https://stackoverflow.com/questions/54695976/how-can-i-update-a-qml-objects-property-from-my-python-file/54697414#54697414) about different ways to communicate between QML and Python.

Actually, after I finished the project, I feel it is a little bit over-engineered, and there are still many boilerplates scattering in the project. __My solution to separate business logic (algorithms) from UI is definitely NOT the best way__, which can be further improved. Hence, if you have a better idea about the architecture, feel free to create a pull request.

By the way, as far as I know, the architecture mentioned above cannot be applied to PySide2 currently [due to this issue](https://bugreports.qt.io/browse/PYSIDE-900). I hope the Qt company would provide a cleaner and simpler solution regarding the interaction between Python and QML in [the future (Qt 6)](https://www.qt.io/blog/2019/08/07/technical-vision-qt-6).

## Installation

Clone the project.

``` shell
git clone https://github.com/seanwu1105/neural-network-sandbox
```

Install requirements.

``` shell
pip install -r requirements.txt
```

Start the application.

``` shell
python main.py
```

---

## 📝 改进日志 (Improvement Log)

### 2025-11-02

#### 🧠 BP神经网络改进
**改进内容：**
- ✅ 完善了BP算法的文档注释和代码说明
- ✅ 添加了详细的算法原理说明（前向传播、反向传播、梯度下降）
- ✅ 增强了训练过程的性能指标记录（epoch_errors）
- ✅ 优化了激活函数的实现（支持单极性和双极性Sigmoid）
- ✅ 改进了动量法的权重更新机制

**技术细节：**
- 实现了标准的反向传播算法，包括：
  - `_feed_forward()`: 前向传播计算网络输出
  - `_backpropagation()`: 反向传播计算梯度（使用链式法则）
  - `_update_weights()`: 使用梯度下降 + 动量法更新权重
- 权重更新公式：`Δw = α * Δw_prev + η * δ * x`
  - α: 动量系数（momentum_weight）
  - η: 学习率（learning_rate）
  - δ: 梯度（delta）
  - x: 输入（input）

**相关文件：**
- `nn_sandbox/backend/algorithms/bp_algorithm.py` - BP算法核心实现
- `nn_sandbox/bridges/bp_bridge.py` - BP算法的UI桥接层

#### 🗺️ SOM网络改进
**改进内容：**
- ✅ 添加了训练历史跟踪功能
- ✅ 实现了量化误差（Quantization Error）的实时计算和记录
- ✅ 增强了算法的文档注释
- ✅ 改进了邻域函数的实现

#### 🎯 OLS-RBFN算法新增
**新增内容：**
- ✅ 实现了RBF网络的OLS（正交最小二乘）中心选择算法
- ✅ 自动确定网络规模，避免过拟合
- ✅ 使用Gram-Schmidt正交化避免数值病态
- ✅ 基于ERR（误差减少率）的前向选择策略

**技术细节：**
- 正交最小二乘（OLS）算法实现：
  - 将RBF中心选择归结为线性回归的子模型选择问题
  - 使用Gram-Schmidt正交化：`u_k = x_k - Σ α_ik * u_i`
  - 计算误差减少率（ERR）：`ERR = (u_j^T * d)² / ((u_j^T * u_j) * (d^T * d))`
  - 前向选择：每次选择ERR最大的中心加入网络
  - 自动停止：当ERR小于阈值时停止选择
- 优势：
  - 可构造出较小规模的网络
  - 避免计算过程中的数值病态问题
  - 自动权衡网络复杂度和拟合精度

**关键算法流程：**
```python
1. 从输入模式中选择候选中心集合
2. For step = 1 to max_centers:
     a. 使用Gram-Schmidt正交化未选中的列
     b. 计算每个候选中心的ERR
     c. 选择ERR最大的中心
     d. If ERR < threshold: 停止
3. 使用最小二乘法计算最优权重: w = (Φ^T Φ)^{-1} Φ^T d
```

**相关文件：**
- `nn_sandbox/backend/algorithms/ols_rbfn_algorithm.py` - OLS-RBFN算法实现
- `nn_sandbox/bridges/ols_rbfn_bridge.py` - OLS-RBFN桥接层
- `nn_sandbox/ols_test.py` - OLS算法测试脚本

**参考文献：**
- Chen, Cowan, Grant (1992) - "Orthogonal least squares learning algorithm for radial basis function networks"

**技术细节（SOM）：**
- 自组织映射（Self-Organizing Map）算法改进：
  - 添加 `quantization_errors` 列表记录每个epoch的量化误差
  - 添加 `current_quantization_error` 实时跟踪当前误差
  - 量化误差定义：输入数据到最佳匹配单元（BMU）的距离
- 训练过程监控：
  - 每个epoch结束时记录平均量化误差
  - 可用于判断网络收敛情况
  - 辅助超参数调优（学习率、标准差）

**关键算法流程：**
```python
1. 前向传播 → 计算所有神经元与输入的距离
2. 找到最佳匹配单元（BMU, Best Matching Unit）
3. 计算量化误差 = BMU.dist
4. 调整权重（高斯邻域函数）：
   Δw = η * exp(-d²/(2σ²)) * (x - w)
   - η: 学习率（随迭代递减）
   - σ: 邻域标准差（随迭代递减）
   - d: 神经元间的拓扑距离
```

**相关文件：**
- `nn_sandbox/backend/algorithms/som_algorithm.py` - SOM算法核心实现
- `nn_sandbox/backend/neurons/som_neuron.py` - SOM神经元
- `nn_sandbox/bridges/som_bridge.py` - SOM算法的UI桥接层

#### 🎨 可视化框架扩展
**成果：**
基于本项目的BP算法实现，创建了独立的Web可视化工具：
- 项目路径：`/home/irelia/app/GradientDescentViz`
- 技术栈：Dash + Plotly + NumPy
- 功能特性：
  - ✅ 支持三种优化算法（梯度下降、牛顿法、共轭梯度法）
  - ✅ 实时训练过程可视化（自动训练，每秒50次迭代）
  - ✅ 四维动态展示：
    1. 训练数据分布
    2. 决策边界动画
    3. 损失/准确率曲线
    4. 二维损失地形图（等高线 + 优化轨迹）
  - ✅ 多种数据集支持（线性可分、XOR非线性）
  - ✅ 增量训练、暂停/继续、重置功能

**技术亮点：**
- 参考了 `bp_algorithm.py` 的实现原理
- 独立的Dash Web应用，可用于教学演示
- 完整的文档系统（QUICKSTART.md, USAGE.md, CHANGES.md）

---

### 改进总结

本项目的神经网络算法实现具有以下特点：

1. **模块化设计**：业务逻辑与UI完全分离
2. **可观察模式**：通过Observer模式实现UI自动更新
3. **完整的文档**：每个算法都有详细的注释和说明
4. **训练监控**：实时跟踪训练指标（误差、准确率等）
5. **可扩展性**：易于添加新的神经网络算法

**未来可能的改进方向：**
- [ ] 为所有算法添加训练历史记录
- [ ] 实现更多优化算法（Adam、RMSprop等）
- [ ] 添加批量训练模式
- [ ] 支持更多激活函数（ReLU、Tanh等）
- [ ] 实现早停（Early Stopping）机制

---

*最后更新：2025-11-02*