from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QDoubleSpinBox, QPushButton, QTextEdit,
                               QLabel, QSpinBox, QComboBox, QFileDialog, QMessageBox, QGridLayout)
from PySide6.QtCore import Slot
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os

# 适配旧Matplotlib版本：强化负号和字体设置
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


# Sigmoid激活函数类（保留原有功能）
class SigmoidFunction:
    @staticmethod
    def unipolar(x):
        """单极性Sigmoid：f(x) = 1/(1+e^-x)，输出[0,1]"""
        return 1.0 / (1.0 + np.exp(-x))

    @staticmethod
    def unipolar_derivative(y):
        """单极性导数：f’(x) = y*(1-y)"""
        return y * (1 - y)

    @staticmethod
    def bipolar(x):
        """双极性Sigmoid（tanh）：输出[-1,1]"""
        return np.tanh(x)

    @staticmethod
    def bipolar_derivative(y):
        """双极性导数：f’(x) = 1-y²"""
        return 1 - y * y


# BP神经网络核心类（保留完整训练/预测功能）
class BPNeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size,
                 learning_rate=0.5, activation_type='unipolar', random_seed=42):
        """
        初始化三层BP网络
        input_size: 输入层节点数
        hidden_size: 隐藏层节点数
        output_size: 输出层节点数
        activation_type: 'unipolar'/'bipolar'
        """
        np.random.seed(random_seed)
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate

        # 激活函数选择
        if activation_type == 'unipolar':
            self.activation = SigmoidFunction.unipolar
            self.activation_deriv = SigmoidFunction.unipolar_derivative
        else:
            self.activation = SigmoidFunction.bipolar
            self.activation_deriv = SigmoidFunction.bipolar_derivative

        # 初始化权重（[-1,1]随机数）
        self.W1 = np.random.uniform(-1, 1, (self.input_size, self.hidden_size))  # 输入→隐藏
        self.W2 = np.random.uniform(-1, 1, (self.hidden_size, self.output_size))  # 隐藏→输出
        self.b1 = np.random.uniform(-1, 1, self.hidden_size)  # 隐藏层偏置
        self.b2 = np.random.uniform(-1, 1, self.output_size)  # 输出层偏置

        # 训练历史
        self.train_error_history = []

    def forward(self, X):
        """前向传播：X→隐藏层→输出层"""
        # 隐藏层：z1 = X@W1 + b1 → a1 = activation(z1)
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = self.activation(self.z1)

        # 输出层：z2 = a1@W2 + b2 → a2 = activation(z2)
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.a2 = self.activation(self.z2)

        return self.a2

    def backward(self, X, y, y_pred):
        """反向传播：计算梯度并更新权重"""
        # 输出层误差：delta2 = (y_pred - y) * f’(z2)
        delta2 = (y_pred - y) * self.activation_deriv(self.a2)

        # 隐藏层误差：delta1 = (delta2@W2.T) * f’(z1)
        delta1 = np.dot(delta2, self.W2.T) * self.activation_deriv(self.a1)

        # 更新权重和偏置（批量平均梯度）
        m = X.shape[0]
        self.W2 -= self.learning_rate * np.dot(self.a1.T, delta2) / m
        self.b2 -= self.learning_rate * np.sum(delta2, axis=0) / m
        self.W1 -= self.learning_rate * np.dot(X.T, delta1) / m
        self.b1 -= self.learning_rate * np.sum(delta1, axis=0) / m

    def train(self, X, y, epochs=1000, batch_size=32, verbose=False):
        """训练网络：支持小批量梯度下降"""
        self.train_error_history = []
        n_samples = X.shape[0]

        for epoch in range(epochs):
            # 随机打乱数据
            indices = np.random.permutation(n_samples)
            X_shuffled = X[indices]
            y_shuffled = y[indices]

            # 小批量训练
            for i in range(0, n_samples, batch_size):
                X_batch = X_shuffled[i:i + batch_size]
                y_batch = y_shuffled[i:i + batch_size]

                # 前向传播
                y_pred = self.forward(X_batch)

                # 反向传播更新参数
                self.backward(X_batch, y_batch, y_pred)

            # 计算epoch误差（MSE）
            y_pred_all = self.forward(X)
            mse = np.mean((y_pred_all - y) ** 2)
            self.train_error_history.append(mse)

            # 打印进度（可选）
            if verbose and (epoch + 1) % 100 == 0:
                print(f"Epoch {epoch + 1}/{epochs} - MSE: {mse:.6f}")

        return self.train_error_history

    def predict(self, X):
        """预测：前向传播输出结果"""
        return self.forward(X)


class BPNeuralNetworkWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None
        self.canvas = None
        self.init_ui()
        self.bp_net = None  # BP网络实例
        self.X_train = None  # 训练输入
        self.y_train = None  # 训练标签
        self.dataset_type = None  # 数据集类型（XOR/回归）

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 控制面板（分两部分：网络参数 + 训练参数）
        control_group = QGroupBox("参数设置（三层BP神经网络）")
        control_layout = QGridLayout()

        # 第一部分：网络结构参数（左列）
        control_layout.addWidget(QLabel("网络结构:"), 0, 0, 1, 2)

        # 输入层节点数（由数据集决定，禁用手动修改）
        self.input_size_label = QLabel("输入层节点数: 2")
        control_layout.addWidget(self.input_size_label, 1, 0)

        # 隐藏层节点数
        control_layout.addWidget(QLabel("隐藏层节点数:"), 1, 1)
        self.hidden_spin = QSpinBox()
        self.hidden_spin.setRange(2, 50)
        self.hidden_spin.setValue(4)
        control_layout.addWidget(self.hidden_spin, 1, 2)

        # 输出层节点数（由数据集决定，禁用手动修改）
        self.output_size_label = QLabel("输出层节点数: 1")
        control_layout.addWidget(self.output_size_label, 2, 0)

        # 激活函数
        control_layout.addWidget(QLabel("激活函数:"), 2, 1)
        self.activation_combo = QComboBox()
        self.activation_combo.addItems(["单极性Sigmoid [0,1]", "双极性Sigmoid [-1,1]"])
        control_layout.addWidget(self.activation_combo, 2, 2)

        # 第二部分：训练参数（左列）
        control_layout.addWidget(QLabel("训练参数:"), 3, 0, 1, 2)

        # 学习率
        control_layout.addWidget(QLabel("学习率 η:"), 4, 1)
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.01, 1.0)
        self.lr_spin.setValue(0.5)
        self.lr_spin.setSingleStep(0.01)
        control_layout.addWidget(self.lr_spin, 4, 2)

        # 训练轮数
        control_layout.addWidget(QLabel("训练轮数:"), 5, 1)
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(500, 10000)
        self.epochs_spin.setValue(2000)
        self.epochs_spin.setSingleStep(500)
        control_layout.addWidget(self.epochs_spin, 5, 2)

        # 批量大小
        control_layout.addWidget(QLabel("批量大小:"), 6, 1)
        self.batch_spin = QSpinBox()
        self.batch_spin.setRange(1, 32)
        self.batch_spin.setValue(4)
        control_layout.addWidget(self.batch_spin, 6, 2)

        # 第三部分：数据集选择（左列）
        control_layout.addWidget(QLabel("数据集选择:"), 7, 0, 1, 2)
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems(["XOR问题（分类）", "正弦曲线拟合（回归）"])
        self.dataset_combo.currentTextChanged.connect(self.on_dataset_changed)
        control_layout.addWidget(self.dataset_combo, 7, 1, 1, 2)

        # 按钮布局（2行2列）
        # 生成数据 + 训练按钮
        self.gen_data_btn = QPushButton("生成数据集")
        self.gen_data_btn.clicked.connect(self.generate_dataset)
        control_layout.addWidget(self.gen_data_btn, 8, 1)

        self.train_btn = QPushButton("训练BP网络")
        self.train_btn.clicked.connect(self.train_network)
        control_layout.addWidget(self.train_btn, 8, 2)

        # 保存图片按钮
        self.save_btn = QPushButton("保存结果图")
        self.save_btn.clicked.connect(self.save_figure)
        control_layout.addWidget(self.save_btn, 9, 1, 1, 2)

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 结果显示区域
        result_layout = QHBoxLayout()

        # 文本输出
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用BP神经网络界面！")
        self.text_output.append("支持：XOR分类、正弦曲线回归（三层网络）")
        self.text_output.append("步骤：1. 选择数据集 → 2. 生成数据集 → 3. 训练网络 → 4. 查看结果")
        result_layout.addWidget(self.text_output, 1)

        # 图形显示
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)

        main_layout.addLayout(result_layout, 1)

    def on_dataset_changed(self, dataset_name):
        """数据集选择变化时，更新输入/输出层节点数提示"""
        if "XOR" in dataset_name:
            self.dataset_type = "XOR"
            self.input_size_label.setText("输入层节点数: 2")
            self.output_size_label.setText("输出层节点数: 1")
            self.text_output.append(f"\n已选择「XOR问题」：输入2维，输出1维（二分类）")
        else:
            self.dataset_type = "REGRESSION"
            self.input_size_label.setText("输入层节点数: 1")
            self.output_size_label.setText("输出层节点数: 1")
            self.text_output.append(f"\n已选择「正弦曲线拟合」：输入1维，输出1维（回归）")

    def initialize_plot(self):
        """初始化绘图区域（主窗口调用）"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(8, 6), dpi=100)
            # 再次强化显示设置，避免被覆盖
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        # 初始绘制提示图
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "等待生成数据集...", ha='center', va='center', fontsize=14)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot()
    def generate_dataset(self):
        """生成数据集（XOR或正弦回归）"""
        if self.dataset_type is None:
            self.dataset_type = "XOR"  # 默认XOR
            self.dataset_combo.setCurrentIndex(0)

        self.text_output.append(f"\n[步骤1] 生成{self.dataset_type}数据集...")

        if self.dataset_type == "XOR":
            # XOR数据集：4个样本，输入(2维)，输出(1维)
            X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
            y = np.array([[0], [1], [1], [0]])  # 单极性标签

            self.X_train = X
            self.y_train = y
            self.text_output.append(f"生成XOR数据集：4个样本，输入(2维)，输出(1维)")
            self.text_output.append(f"输入：\n{X}\n输出：\n{y}")

            # 绘制XOR散点图
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            # 按标签分类绘制
            for i, (x, label) in enumerate(zip(X, y)):
                color = 'red' if label[0] == 1 else 'blue'
                ax.scatter(x[0], x[1], c=color, s=100, label=f'标签{label[0]}' if i < 2 else "")
            ax.set_title("XOR数据集（分类任务）")
            ax.set_xlabel("输入X1")
            ax.set_ylabel("输入X2")
            ax.legend()
            ax.grid(True, alpha=0.3)  # 手动设置透明度

        else:
            # 正弦曲线回归数据集：100个样本，输入(1维)，输出(1维)
            X = np.linspace(0, 2 * np.pi, 100).reshape(-1, 1)
            y = np.sin(X) + 0.1 * np.random.randn(100, 1)  # 带噪声的sin曲线

            # 若选择双极性激活函数，将输出映射到[-1,1]（已天然满足）
            self.X_train = X
            self.y_train = y
            self.text_output.append(f"生成正弦回归数据集：100个样本，输入(1维)，输出(1维)")
            self.text_output.append(f"输入范围：[0, 2π]，输出：sin(X)+噪声")

            # 绘制正弦散点图
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.scatter(X, y, c='green', alpha=0.6, s=30, label='带噪声的sin(X)')
            ax.plot(X, np.sin(X), 'k-', linewidth=2, label='理想sin(X)')
            ax.set_title("正弦曲线拟合数据集（回归任务）")
            ax.set_xlabel("输入X")
            ax.set_ylabel("输出Y=sin(X)")
            ax.legend()
            ax.grid(True, alpha=0.3)

        self.canvas.draw()

    @Slot()
    def train_network(self):
        """训练BP神经网络"""
        if self.X_train is None or self.y_train is None:
            self.text_output.append("\n[错误] 请先生成数据集！")
            QMessageBox.warning(self, "警告", "请先点击「生成数据集」按钮！")
            return

        self.text_output.append("\n[步骤2] 训练BP神经网络...")

        # 获取参数
        input_size = self.X_train.shape[1]
        hidden_size = self.hidden_spin.value()
        output_size = self.y_train.shape[1]
        lr = self.lr_spin.value()
        epochs = self.epochs_spin.value()
        batch_size = self.batch_spin.value()
        activation_type = 'unipolar' if "单极性" in self.activation_combo.currentText() else 'bipolar'

        # 调整标签范围（双极性时将[0,1]转为[-1,1]）
        y_train_adjusted = self.y_train.copy()
        if activation_type == 'bipolar' and self.dataset_type == "XOR":
            y_train_adjusted = 2 * y_train_adjusted - 1  # 0→-1，1→1

        self.text_output.append(f"训练参数：")
        self.text_output.append(f"网络结构：{input_size}→{hidden_size}→{output_size}")
        self.text_output.append(f"激活函数：{activation_type}，学习率：{lr}")
        self.text_output.append(f"训练轮数：{epochs}，批量大小：{batch_size}")

        # 初始化BP网络
        self.bp_net = BPNeuralNetwork(
            input_size=input_size,
            hidden_size=hidden_size,
            output_size=output_size,
            learning_rate=lr,
            activation_type=activation_type
        )

        # 训练（记录时间）
        import time
        start_time = time.time()
        train_errors = self.bp_net.train(
            self.X_train, y_train_adjusted,
            epochs=epochs,
            batch_size=batch_size,
            verbose=False
        )
        end_time = time.time()

        # 预测
        y_pred = self.bp_net.predict(self.X_train)

        # 若双极性，将预测结果转回[0,1]（方便显示）
        if activation_type == 'bipolar' and self.dataset_type == "XOR":
            y_pred = (y_pred + 1) / 2  # -1→0，1→1

        # 输出结果
        final_mse = np.mean((y_pred - self.y_train) ** 2)
        self.text_output.append(f"\n训练完成！耗时：{end_time - start_time:.2f}秒")
        self.text_output.append(f"最终MSE误差：{final_mse:.6f}")

        # 打印XOR预测细节（分类任务）
        if self.dataset_type == "XOR":
            self.text_output.append("\nXOR预测结果对比：")
            for i, (x, true, pred) in enumerate(zip(self.X_train, self.y_train, y_pred)):
                self.text_output.append(f"输入：{x} → 真实：{true[0]} → 预测：{pred[0]:.4f}")

        # 绘制结果（双图：预测结果 + 误差曲线）
        self.figure.clear()

        # 子图1：预测结果
        ax1 = self.figure.add_subplot(121)
        if self.dataset_type == "XOR":
            # XOR分类结果（绘制决策边界）
            ax1.scatter(self.X_train[:, 0], self.X_train[:, 1], c=self.y_train.flatten(),
                        cmap='coolwarm', s=100, edgecolors='black')
            # 绘制决策边界（网格采样）
            x1 = np.linspace(-0.5, 1.5, 100)
            x2 = np.linspace(-0.5, 1.5, 100)
            X1, X2 = np.meshgrid(x1, x2)
            grid_input = np.column_stack((X1.ravel(), X2.ravel()))
            grid_pred = self.bp_net.predict(grid_input)
            if activation_type == 'bipolar':
                grid_pred = (grid_pred + 1) / 2  # 转回[0,1]
            grid_pred = grid_pred.reshape(X1.shape)
            ax1.contourf(X1, X2, grid_pred, alpha=0.3, cmap='coolwarm')
            ax1.set_title("XOR分类结果（决策边界）")
            ax1.set_xlabel("X1")
            ax1.set_ylabel("X2")
        else:
            # 回归拟合结果
            ax1.scatter(self.X_train, self.y_train, c='green', alpha=0.6, s=30, label='真实数据')
            ax1.plot(self.X_train, y_pred, 'r-', linewidth=2, label='预测曲线')
            ax1.set_title("正弦曲线拟合结果（回归任务）")
            ax1.set_xlabel("X")
            ax1.set_ylabel("Y")
            ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 子图2：训练误差曲线
        ax2 = self.figure.add_subplot(122)
        ax2.plot(train_errors, 'b-', linewidth=1.5)
        ax2.set_title("训练误差变化（MSE）")
        ax2.set_xlabel("训练轮数")
        ax2.set_ylabel("MSE误差（对数坐标）")
        ax2.set_yscale('log')
        ax2.grid(True, alpha=0.3)

        # 调整布局
        self.figure.tight_layout()
        self.canvas.draw()

    @Slot()
    def save_figure(self):
        """保存结果图（适配旧Matplotlib版本）"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先训练网络，生成结果图后再保存！")
            return

        # 选择保存路径
        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存BP网络结果图",
            os.path.join(os.getcwd(), "bp_network_result.png"),
            "图片文件 (*.png *.jpg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        # 手动添加bbox_inches，避免标签截断
        try:
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}")
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}")