import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '../'

Page {
    name: "在线序列学习 (OSL)"

    ColumnLayout {
        spacing: 10
        // 删除此行: anchors.fill: parent
        Layout.fillWidth: true
        Layout.fillHeight: true

        // 控制面板
        GroupBox {
            title: "OSL 控制面板"
            Layout.fillWidth: true

            ColumnLayout {
                spacing: 10

                // 参数设置
                GroupBox {
                    title: "参数设置"
                    Layout.fillWidth: true

                    GridLayout {
                        columns: 4
                        rowSpacing: 10
                        columnSpacing: 10

                        Label { text: "学习率:" }
                        TextField {
                            text: "0.1"
                            Layout.preferredWidth: 100
                            selectByMouse: true
                        }

                        Label { text: "样本数量:" }
                        TextField {
                            text: "200"
                            Layout.preferredWidth: 100
                            selectByMouse: true
                        }

                        Label { text: "训练步数:" }
                        TextField {
                            text: "100"
                            Layout.preferredWidth: 100
                            selectByMouse: true
                        }

                        Label { text: "批次大小:" }
                        TextField {
                            text: "10"
                            Layout.preferredWidth: 100
                            selectByMouse: true
                        }
                    }
                }

                // 控制按钮
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 20

                    Button {
                        text: "开始训练"
                        onClicked: {
                            console.log("开始 OSL 训练")
                            oslBridge.start_training()
                        }
                    }

                    Button {
                        text: "暂停训练"
                        enabled: oslBridge.is_training
                        onClicked: {
                            console.log("暂停 OSL 训练")
                            oslBridge.pause_training()
                        }
                    }

                    Button {
                        text: "重置模型"
                        onClicked: {
                            console.log("重置 OSL 模型")
                            oslBridge.reset_model()
                        }
                    }
                }

                // 进度条和信息显示
                ProgressBar {
                    id: progressBar
                    Layout.fillWidth: true
                    value: oslBridge.progress / 100
                }

                GroupBox {
                    title: "训练信息"
                    Layout.fillWidth: true
                    Layout.maximumHeight: 100

                    ScrollView {
                        anchors.fill: parent

                        TextArea {
                            id: infoText
                            readOnly: true
                            text: "步数: " + oslBridge.current_step + 
                                  ", 损失: " + oslBridge.loss_value.toFixed(4) + 
                                  ", 准确率: " + oslBridge.accuracy_value.toFixed(4)
                        }
                    }
                }
            }
        }

        // 可视化区域
        GroupBox {
            title: "OSL 可视化"
            Layout.fillWidth: true
            Layout.fillHeight: true

            TabBar {
                id: tabBar
                width: parent.width

                TabButton { text: "损失函数" }
                TabButton { text: "权重矩阵" }
                TabButton { text: "预测结果" }
                TabButton { text: "决策边界" }
                TabButton { text: "数据分布" }
            }

            StackLayout {
                width: parent.width
                height: parent.height - tabBar.height
                currentIndex: tabBar.currentIndex
                anchors.top: tabBar.bottom

                // 损失函数图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "损失函数可视化区域"
                    }
                }

                // 权重矩阵图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "权重矩阵可视化区域"
                    }
                }

                // 预测结果图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "预测结果可视化区域"
                    }
                }

                // 决策边界图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "决策边界可视化区域"
                    }
                }

                // 数据分布图表
                Rectangle {
                    border.color: "lightgray"
                    Label {
                        anchors.centerIn: parent
                        text: "数据分布可视化区域"
                    }
                }
            }
        }
    }
}