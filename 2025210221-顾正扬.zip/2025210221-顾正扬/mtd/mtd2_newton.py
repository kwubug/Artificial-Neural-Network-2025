import pandas as pd
import numpy as np


def main1():
    def F(x: list):
        return x[0] ** 2 + x[1] ** 2

    def g_F(x: list):
        return [2 * x[0], 50 * x[1]]

    start_x = [0.5, 0.5]
    g = g_F(start_x)
    g2 = [[2, 0], [0, 50]]

    final_x = [start_x[0] - g[0] / g2[0][0], start_x[1] - g[1] / g2[1][1]]
    print(final_x)
    data = [{'x1': start_x[0], 'x2': start_x[1]}, {'x1': final_x[0], 'x2': final_x[1]}]
    df = pd.DataFrame(data, columns=['x1', 'x2'])
    df.to_excel(f"m2_F1.xlsx", index=False)

    return True


def main2():
    data = []

    def F(x: list):
        # 该函数有三个驻点
        # x1 = [-0.41878, 0.41878]      强局部极小点
        # x2 = [-0.134797, 0.134797]    鞍点
        # x3 = [0.55358, -0.55358]      强全局极小点
        return (x[1] - x[0]) ** 4 + 8 * x[0] * x[1] - x[0] + x[1] + 3

    def g_F(x: list):
        return [-4 * (x[1] - x[0]) ** 3 + 8 * x[1] - 1, 4 * (x[1] - x[0]) ** 3 + 8 * x[0] + 1]

    def g2_F(x: list):
        return [[12 * (x[1] - x[0]) ** 2, 8 - 12 * (x[1] - x[0]) ** 2],
                [8 - 12 * (x[1] - x[0]) ** 2, 12 * (x[1] - x[0]) ** 2]]

    def learn(x):
        g = g_F(x)
        g2 = g2_F(x)
        g2_1 = np.linalg.inv(g2)
        # print(g)
        # print(g2)
        # print(g2_1)
        delta_x1 = g2_1[0][0] * g[0] + g2_1[0][1] * g[1]
        delta_x2 = g2_1[1][0] * g[0] + g2_1[1][1] * g[1]
        x[0] = float(x[0] - delta_x1)
        x[1] = float(x[1] - delta_x2)
        print(x)
        return True

    a = 4
    idx = [[1.5, 0], [-1.5, 0], [0.75, 0.75], [1.15, 0.75]]
    lst = [[1.5, 0], [-1.5, 0], [0.75, 0.75], [1.15, 0.75]]
    x = lst[a - 1]
    data.append({'x1': x[0], 'x2': x[1]})
    print(x)
    for i in range(3):
        learn(x)
        data.append({'x1': x[0], 'x2': x[1]})

    df = pd.DataFrame(data, columns=['x1', 'x2'])
    df.to_excel(f"m2_F2_{idx[a - 1]}.xlsx", index=False)
    return True


if __name__ == '__main__':
    # main1()
    main2()
