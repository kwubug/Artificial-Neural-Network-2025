import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import random
import matplotlib

matplotlib.use('TkAgg')

# 设置中文显示，仅保留SimHei字体
plt.rcParams["font.family"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号


class TSPVisualizer:
    def __init__(self, num_cities=10, width=10, height=10, seed=None):
        """初始化TSP可视化器"""
        if seed:
            random.seed(seed)
            np.random.seed(seed)

        self.num_cities = num_cities
        self.width = width
        self.height = height
        self.cities = self.generate_cities()  # 城市坐标
        self.dist_matrix = self.calculate_distance_matrix()  # 距离矩阵
        self.path = []  # 路径
        self.total_distance = 0  # 总距离

        # 设置图形
        self.fig, self.ax = plt.subplots(figsize=(10, 8))
        self.fig.suptitle('旅行商问题(TSP)可视化')

    def generate_cities(self):
        """生成随机城市坐标"""
        return np.random.rand(self.num_cities, 2) * np.array([self.width, self.height])

    def calculate_distance_matrix(self):
        """计算城市之间的距离矩阵"""
        dist_matrix = np.zeros((self.num_cities, self.num_cities))
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                if i != j:
                    # 计算欧氏距离
                    dist_matrix[i][j] = np.linalg.norm(self.cities[i] - self.cities[j])
        return dist_matrix

    def greedy_algorithm(self, start_city=0):
        """使用贪心算法求解TSP"""
        visited = [False] * self.num_cities
        path = [start_city]
        visited[start_city] = True
        current_city = start_city

        for _ in range(self.num_cities - 1):
            min_dist = float('inf')
            next_city = -1

            # 找到最近的未访问城市
            for city in range(self.num_cities):
                if not visited[city] and self.dist_matrix[current_city][city] < min_dist:
                    min_dist = self.dist_matrix[current_city][city]
                    next_city = city

            path.append(next_city)
            visited[next_city] = True
            current_city = next_city
            self.total_distance += min_dist

        # 回到起始城市，完成回路
        self.total_distance += self.dist_matrix[current_city][start_city]
        path.append(start_city)

        self.path = path
        return path, self.total_distance

    def initialize_plot(self):
        """初始化绘图"""
        self.ax.clear()
        # 绘制城市
        self.ax.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, marker='o', label='城市')

        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            self.ax.text(x + 0.1, y + 0.1, str(i), fontsize=12)

        self.ax.set_xlim(0, self.width)
        self.ax.set_ylim(0, self.height)
        self.ax.set_xlabel('X坐标')
        self.ax.set_ylabel('Y坐标')
        self.ax.legend()
        return self.ax,

    def update_plot(self, frame):
        """更新绘图，用于动画"""
        # 绘制当前路径
        self.initialize_plot()
        if frame < len(self.path):
            current_path = self.path[:frame + 1]
            self.ax.plot(self.cities[current_path, 0], self.cities[current_path, 1], 'b-', linewidth=2, label='路径')

            # 显示当前路径长度
            if frame > 0:
                current_dist = 0
                for i in range(frame):
                    current_dist += self.dist_matrix[current_path[i]][current_path[i + 1]]
                self.ax.set_title(f'当前路径长度: {current_dist:.2f}, 总路径长度: {self.total_distance:.2f}')

        return self.ax,

    def visualize(self, algorithm='greedy', start_city=0):
        """可视化TSP求解过程"""
        # 求解TSP
        if algorithm == 'greedy':
            self.greedy_algorithm(start_city)

        # 创建动画
        animation = FuncAnimation(
            self.fig,
            self.update_plot,
            frames=len(self.path),
            init_func=self.initialize_plot,
            interval=500,  # 每帧间隔500ms
            blit=True,
            repeat=False  # 不重复播放
        )

        plt.tight_layout()
        plt.show()
        return animation


if __name__ == "__main__":
    # 创建TSP可视化器，包含10个城市
    tsp_visualizer = TSPVisualizer(num_cities=10, seed=42)

    # 使用贪心算法求解并可视化
    tsp_visualizer.visualize(algorithm='greedy', start_city=0)