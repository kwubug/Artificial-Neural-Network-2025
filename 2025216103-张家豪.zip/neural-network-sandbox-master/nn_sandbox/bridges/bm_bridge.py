import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.bm_algorithm import BMAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BmBridge(Bridge):
    # 可配置参数
    ui_refresh_interval = BridgeProperty(0.0)
    weights = BridgeProperty([[0.0, 1.0, 1.0],
                              [1.0, 0.0, 1.0],
                              [1.0, 1.0, 0.0]])
    biases = BridgeProperty([0.0, 0.0, 0.0])
    initial_state = BridgeProperty([0, 0, 0])
    initial_temperature = BridgeProperty(2.0)
    min_temperature = BridgeProperty(0.05)
    cooling_rate = BridgeProperty(0.99)
    max_iterations = BridgeProperty(5000)

    # 运行时信息
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    current_temperature = BridgeProperty(0.0)
    current_state = BridgeProperty([0, 0, 0])
    equilibrium_state = BridgeProperty([0, 0, 0])
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self._bm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm(self):
        self._bm = ObservableBMAlgorithm(
            self,
            self.ui_refresh_interval,
            weights=self.weights,
            biases=self.biases,
            initial_state=self.initial_state,
            initial_temperature=self.initial_temperature,
            min_temperature=self.min_temperature,
            cooling_rate=self.cooling_rate,
            max_iterations=self.max_iterations,
        )
        self._bm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm(self):
        if self._bm:
            self._bm.stop()


class ObservableBMAlgorithm(Observable, BMAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        # 初始化期间不发送通知，待底层完成构造（含 _lock）后再开启
        object.__setattr__(self, '_obs_ready', False)
        BMAlgorithm.__init__(self, **kwargs, ui_refresh_interval=ui_refresh_interval)
        self._ui_refresh = ui_refresh_interval
        object.__setattr__(self, '_obs_ready', True)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 初始化未完成时不进行跨线程通知，避免访问未建立的锁或属性
        if not getattr(self, '_obs_ready', False):
            return
        if name == 'current_iterations':
            self.notify('current_iterations', value)
            # 推送当前状态、能量、温度
            self.notify('current_state', self.state.tolist())
            self.notify('current_energy', self.current_energy)
            self.notify('current_temperature', float(self.temperature))
        elif name in ('has_finished', 'equilibrium_state'):
            if name == 'equilibrium_state' and value is not None:
                try:
                    self.notify('equilibrium_state', value.tolist())
                except Exception:
                    self.notify('equilibrium_state', value)
            else:
                self.notify(name, value)

    def run(self):
        self.notify('has_finished', False)
        self.notify('equilibrium_state', [0, 0, 0])
        super().run()
        self.notify('current_state', self.state.tolist())
        self.notify('current_energy', self.current_energy)
        self.notify('current_temperature', float(self.temperature))
        self.notify('equilibrium_state', self.equilibrium_state.tolist())
        self.notify('has_finished', True)


