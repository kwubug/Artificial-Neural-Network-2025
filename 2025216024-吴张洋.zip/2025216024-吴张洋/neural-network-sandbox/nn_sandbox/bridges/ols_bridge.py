import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import OlsAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(1)
    most_correct_rate_checkbox = BridgeProperty(False)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    test_ratio = BridgeProperty(0.3)
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    
    # OLS特定属性
    slope = BridgeProperty(0.0)  # 斜率
    intercept = BridgeProperty(0.0)  # 截距
    r_squared = BridgeProperty(0.0)  # R²
    mse = BridgeProperty(0.0)  # 均方误差
    fitted_line = BridgeProperty([])  # 拟合直线
    residuals = BridgeProperty([])  # 残差

    def __init__(self):
        super().__init__()
        self.ols_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_ols_algorithm(self):
        self.ols_algorithm = ObservableOlsAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio
        )
        self.ols_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols_algorithm(self):
        if self.ols_algorithm:
            self.ols_algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableOlsAlgorithm(Observable, OlsAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self.has_initialized = False
        Observable.__init__(self, observer)
        OlsAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval
        self.has_initialized = True

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 只有在初始化完成后才通知UI
        if not hasattr(self, 'has_initialized'):
            return
        
        if name == 'current_iterations':
            self.notify(name, value)
            # 更新OLS相关属性（如果已计算）
            if hasattr(self, 'slope') and hasattr(self, 'r_squared'):
                self.notify('slope', self.slope)
                self.notify('intercept', self.intercept)
                self.notify('r_squared', self.r_squared)
                self.notify('mse', self.mse)
                self.notify('fitted_line', self.fitted_line)
                self.notify('residuals', self.residuals)
            # 只有在算法初始化完成后才调用test()
            if hasattr(self, 'training_dataset') and self.training_dataset is not None:
                try:
                    self.notify('test_correct_rate', self.test())
                except (AttributeError, ValueError):
                    pass  # 如果属性还未初始化，忽略错误
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())
        elif name in ('slope', 'intercept', 'r_squared', 'mse', 'fitted_line', 'residuals'):
            self.notify(name, value)

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        # 更新最终结果
        self.notify('slope', self.slope)
        self.notify('intercept', self.intercept)
        self.notify('r_squared', self.r_squared)
        self.notify('mse', self.mse)
        self.notify('fitted_line', self.fitted_line)
        self.notify('residuals', self.residuals)
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 更新属性 - 确保在每次迭代后都通知UI
        if hasattr(self, 'slope'):
            self.notify('slope', self.slope)
        if hasattr(self, 'intercept'):
            self.notify('intercept', self.intercept)
        if hasattr(self, 'r_squared'):
            self.notify('r_squared', self.r_squared)
        if hasattr(self, 'mse'):
            self.notify('mse', self.mse)
        if hasattr(self, 'fitted_line') and self.fitted_line:
            # 确保fitted_line是列表格式
            if isinstance(self.fitted_line, list):
                self.notify('fitted_line', self.fitted_line)
            else:
                self.notify('fitted_line', list(self.fitted_line))
        if hasattr(self, 'residuals'):
            self.notify('residuals', self.residuals)
        # the following line keeps the GUI from blocking
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret

