import numpy as np
from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import unipolar_sigmoid, bipolar_sigmoid


class BpAlgorithm(PredictiveAlgorithm):
    """三层前馈神经网络的BP学习算法"""

    def __init__(self, dataset, total_epoches=100, most_correct_rate=None,
                 initial_learning_rate=0.5, search_iteration_constant=10000,
                 test_ratio=0.3, input_nodes=2, hidden_nodes=5, output_nodes=3,
                 activation_type='unipolar'):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.activation_type = activation_type  # 'unipolar' or 'bipolar'
        
        # 选择激活函数
        if activation_type == 'unipolar':
            self.activation_function = unipolar_sigmoid
            self.activation_derivative = self._unipolar_sigmoid_derivative
        else:  # bipolar
            self.activation_function = bipolar_sigmoid
            self.activation_derivative = self._bipolar_sigmoid_derivative
        
        # 网络权重和偏置
        self.weights_input_hidden = None
        self.weights_hidden_output = None
        self.bias_hidden = None
        self.bias_output = None
        
        # 用于存储前向传播的中间结果
        self.hidden_outputs = None
        self.final_outputs = None

    def _unipolar_sigmoid_derivative(self, x):
        """单极性Sigmoid函数的导数"""
        s = self.activation_function(x)
        return s * (1 - s)

    def _bipolar_sigmoid_derivative(self, x):
        """双极性Sigmoid函数的导数"""
        s = self.activation_function(x)
        return 0.5 * (1 - s * s)

    def _initialize_neurons(self):
        """初始化网络权重和偏置，使用Xavier初始化"""
        # Xavier初始化：权重范围根据输入输出节点数调整
        input_range = np.sqrt(6.0 / (self.input_nodes + self.hidden_nodes))
        hidden_range = np.sqrt(6.0 / (self.hidden_nodes + self.output_nodes))
        
        # 输入层到隐藏层权重
        self.weights_input_hidden = np.random.uniform(-input_range, input_range, (self.input_nodes, self.hidden_nodes))
        # 隐藏层到输出层权重
        self.weights_hidden_output = np.random.uniform(-hidden_range, hidden_range, (self.hidden_nodes, self.output_nodes))
        # 隐藏层偏置
        self.bias_hidden = np.random.uniform(-0.1, 0.1, self.hidden_nodes)
        # 输出层偏置
        self.bias_output = np.random.uniform(-0.1, 0.1, self.output_nodes)
        
        # 初始化中间结果
        self.hidden_outputs = None
        self.final_outputs = None
        

    def _iterate(self):
        """执行一次BP算法迭代"""
        # 获取当前训练数据
        input_data = np.array(self.current_data[:-1])
        target = self.current_data[-1]
        
        # 前向传播
        self._forward_propagation(input_data)
        
        # 反向传播
        self._backward_propagation(input_data, target)

    def _forward_propagation(self, input_data):
        """前向传播"""
        # 隐藏层计算
        hidden_inputs = np.dot(input_data, self.weights_input_hidden) + self.bias_hidden
        self.hidden_outputs = np.array([self.activation_function(x) for x in hidden_inputs])
        
        # 输出层计算
        output_inputs = np.dot(self.hidden_outputs, self.weights_hidden_output) + self.bias_output
        self.final_outputs = np.array([self.activation_function(x) for x in output_inputs])
        
        
        
        

    def _backward_propagation(self, input_data, target):
        """反向传播"""
        # 计算输出层误差
        if self.output_nodes == 1:
            # 二分类问题
            output_errors = np.array([target - self.final_outputs[0]])
        else:
            # 多分类问题，使用one-hot编码
            target_one_hot = np.zeros(self.output_nodes)
            target_one_hot[int(target) - 1] = 1  # 假设类别从1开始
            output_errors = target_one_hot - self.final_outputs
        
        # 计算输出层梯度
        output_gradients = output_errors * np.array([self.activation_derivative(x) for x in 
                                                   np.dot(self.hidden_outputs, self.weights_hidden_output) + self.bias_output])
        
        # 计算隐藏层误差
        hidden_errors = np.dot(output_gradients, self.weights_hidden_output.T)
        
        # 计算隐藏层梯度
        hidden_gradients = hidden_errors * np.array([self.activation_derivative(x) for x in 
                                                   np.dot(input_data, self.weights_input_hidden) + self.bias_hidden])
        
        # 更新权重和偏置
        self.weights_hidden_output += self._initial_learning_rate * np.outer(self.hidden_outputs, output_gradients)
        self.weights_input_hidden += self._initial_learning_rate * np.outer(input_data, hidden_gradients)
        self.bias_output += self._initial_learning_rate * output_gradients
        self.bias_hidden += self._initial_learning_rate * hidden_gradients
        
    def _correct_rate(self, dataset):
        """计算正确率"""
        correct_count = 0
        total_count = len(dataset)
        
        for i, data in enumerate(dataset):
            input_data = np.array(data[:-1])
            target = data[-1]
            
            # 前向传播（不影响训练状态）
            final_outputs = self._forward_propagation_for_evaluation(input_data)
            
            # 根据激活函数类型和输出节点数判断预测结果
            if self.output_nodes == 1:
                # 二分类问题
                if self.activation_type == 'unipolar':
                    predicted = 1 if final_outputs[0] > 0.5 else 0
                else:  # bipolar
                    predicted = 1 if final_outputs[0] > 0 else -1
            else:
                # 多分类问题，使用softmax
                predicted = np.argmax(final_outputs) + 1  # 假设类别从1开始
            
            if predicted == target:
                correct_count += 1
            
        correct_rate = correct_count / total_count
        
        return correct_rate
    
    def _save_best_neurons(self):
        """重写保存最佳神经元的方法，避免影响训练状态"""
        # 计算训练集正确率
        self.current_correct_rate = self._correct_rate(self.training_dataset)
        
        if self.current_correct_rate > self.best_correct_rate:
            self.best_correct_rate = self.current_correct_rate
            # 对于BP算法，我们保存权重而不是神经元
            self._best_weights = {
                'weights_input_hidden': self.weights_input_hidden.copy(),
                'weights_hidden_output': self.weights_hidden_output.copy(),
                'bias_hidden': self.bias_hidden.copy(),
                'bias_output': self.bias_output.copy()
            }
    
    def _load_best_neurons(self):
        """重写加载最佳神经元的方法"""
        if hasattr(self, '_best_weights'):
            self.weights_input_hidden = self._best_weights['weights_input_hidden'].copy()
            self.weights_hidden_output = self._best_weights['weights_hidden_output'].copy()
            self.bias_hidden = self._best_weights['bias_hidden'].copy()
            self.bias_output = self._best_weights['bias_output'].copy()
    
    def _forward_propagation_for_evaluation(self, input_data):
        """用于评估的前向传播，不影响训练状态"""
        # 隐藏层计算
        hidden_inputs = np.dot(input_data, self.weights_input_hidden) + self.bias_hidden
        hidden_outputs = np.array([self.activation_function(x) for x in hidden_inputs])
        
        # 输出层计算
        output_inputs = np.dot(hidden_outputs, self.weights_hidden_output) + self.bias_output
        final_outputs = np.array([self.activation_function(x) for x in output_inputs])
        
        return final_outputs

    def get_network_weights(self):
        """获取网络权重信息，用于可视化"""
        if self.weights_input_hidden is None:
            return {
                'input_hidden_weights': [],
                'hidden_output_weights': [],
                'hidden_bias': [],
                'output_bias': [],
                'hidden_outputs': [],
                'final_outputs': []
            }
        
        return {
            'input_hidden_weights': self.weights_input_hidden.tolist(),
            'hidden_output_weights': self.weights_hidden_output.tolist(),
            'hidden_bias': self.bias_hidden.tolist(),
            'output_bias': self.bias_output.tolist(),
            'hidden_outputs': self.hidden_outputs.tolist() if self.hidden_outputs is not None else [],
            'final_outputs': self.final_outputs.tolist() if self.final_outputs is not None else []
        }
