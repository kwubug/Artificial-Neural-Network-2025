import numpy as np
import matplotlib.pyplot as plt
import random
import math
from matplotlib.animation import FuncAnimation
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei']
class TSPSolver:
    def __init__(self, cities, temperature=1000, cooling_rate=0.995, iterations=1000):
        """
        初始化TSP求解器

        参数:
        cities: 城市坐标列表 [(x1, y1), (x2, y2), ...]
        temperature: 初始温度
        cooling_rate: 冷却速率
        iterations: 迭代次数
        """
        self.cities = np.array(cities)
        self.n_cities = len(cities)
        self.temperature = temperature
        self.cooling_rate = cooling_rate
        self.iterations = iterations
        self.best_solution = None
        self.best_distance = float('inf')
        self.history = []

    def calculate_distance(self, path):
        """计算路径总距离"""
        total_distance = 0
        for i in range(self.n_cities):
            city_a = path[i]
            city_b = path[(i + 1) % self.n_cities]
            total_distance += np.linalg.norm(self.cities[city_a] - self.cities[city_b])
        return total_distance

    def generate_initial_solution(self):
        """生成初始解（随机路径）"""
        return random.sample(range(self.n_cities), self.n_cities)

    def generate_neighbor(self, path):
        """生成邻居解（使用2-opt交换）"""
        new_path = path.copy()
        i, j = random.sample(range(self.n_cities), 2)
        i, j = min(i, j), max(i, j)
        new_path[i:j + 1] = reversed(new_path[i:j + 1])
        return new_path

    def solve(self):
        """使用模拟退火算法求解TSP"""
        current_solution = self.generate_initial_solution()
        current_distance = self.calculate_distance(current_solution)

        self.best_solution = current_solution.copy()
        self.best_distance = current_distance

        temp = self.temperature

        for iteration in range(self.iterations):
            # 生成邻居解
            neighbor_solution = self.generate_neighbor(current_solution)
            neighbor_distance = self.calculate_distance(neighbor_solution)

            # 计算能量差
            delta_energy = neighbor_distance - current_distance

            # 决定是否接受新解
            if delta_energy < 0 or random.random() < math.exp(-delta_energy / temp):
                current_solution = neighbor_solution
                current_distance = neighbor_distance

                # 更新最优解
                if current_distance < self.best_distance:
                    self.best_solution = current_solution.copy()
                    self.best_distance = current_distance

            # 记录历史数据用于可视化
            self.history.append({
                'iteration': iteration,
                'temperature': temp,
                'current_distance': current_distance,
                'best_distance': self.best_distance,
                'current_solution': current_solution.copy(),
                'best_solution': self.best_solution.copy()
            })

            # 降温
            temp *= self.cooling_rate

            # 打印进度
            if iteration % 100 == 0:
                print(
                    f'迭代 {iteration}: 当前距离 = {current_distance:.2f}, 最优距离 = {self.best_distance:.2f}, 温度 = {temp:.2f}')

        return self.best_solution, self.best_distance


class TSPVisualizer:
    def __init__(self, solver):
        self.solver = solver
        self.fig, self.axes = plt.subplots(2, 2, figsize=(15, 10))
        self.setup_plots()

    def setup_plots(self):
        """设置绘图区域"""
        self.axes[0, 0].set_title('当前路径')
        self.axes[0, 0].set_xlabel('X坐标')
        self.axes[0, 0].set_ylabel('Y坐标')
        self.axes[0, 0].grid(True)

        self.axes[0, 1].set_title('最优路径')
        self.axes[0, 1].set_xlabel('X坐标')
        self.axes[0, 1].set_ylabel('Y坐标')
        self.axes[0, 1].grid(True)

        self.axes[1, 0].set_title('距离收敛')
        self.axes[1, 0].set_xlabel('迭代次数')
        self.axes[1, 0].set_ylabel('距离')
        self.axes[1, 0].grid(True)

        self.axes[1, 1].set_title('温度下降')
        self.axes[1, 1].set_xlabel('迭代次数')
        self.axes[1, 1].set_ylabel('温度')
        self.axes[1, 1].grid(True)

        plt.tight_layout()

    def plot_cities(self, ax, cities):
        """绘制城市点"""
        ax.scatter(cities[:, 0], cities[:, 1], c='red', s=100, zorder=5)
        for i, (x, y) in enumerate(cities):
            ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points')

    def plot_path(self, ax, path, cities, title="", color='blue'):
        """绘制路径"""
        self.plot_cities(ax, cities)

        # 绘制路径线
        for i in range(len(path)):
            start_city = cities[path[i]]
            end_city = cities[path[(i + 1) % len(path)]]
            ax.plot([start_city[0], end_city[0]], [start_city[1], end_city[1]],
                    color=color, linewidth=2, alpha=0.7)

        ax.set_title(title)

    def animate(self, frame_interval=50):
        """创建动画"""
        history = self.solver.history

        # 清空图形
        for ax in self.axes.flat:
            ax.clear()

        self.setup_plots()

        def update(frame):
            if frame >= len(history):
                return

            data = history[frame]

            # 清空当前图形
            for ax in self.axes.flat:
                ax.clear()

            self.setup_plots()

            # 绘制当前路径
            self.plot_path(self.axes[0, 0], data['current_solution'],
                           self.solver.cities, f'当前路径 (距离: {data["current_distance"]:.2f})', 'blue')

            # 绘制最优路径
            self.plot_path(self.axes[0, 1], data['best_solution'],
                           self.solver.cities, f'最优路径 (距离: {data["best_distance"]:.2f})', 'green')

            # 绘制距离收敛
            iterations = [h['iteration'] for h in history[:frame + 1]]
            current_distances = [h['current_distance'] for h in history[:frame + 1]]
            best_distances = [h['best_distance'] for h in history[:frame + 1]]

            self.axes[1, 0].plot(iterations, current_distances, 'b-', alpha=0.5, label='当前距离')
            self.axes[1, 0].plot(iterations, best_distances, 'g-', linewidth=2, label='最优距离')
            self.axes[1, 0].legend()
            self.axes[1, 0].set_title(f'距离收敛 (迭代: {frame})')

            # 绘制温度下降
            temperatures = [h['temperature'] for h in history[:frame + 1]]
            self.axes[1, 1].plot(iterations, temperatures, 'r-')
            self.axes[1, 1].set_title('温度下降')

            return self.axes.flat

        anim = FuncAnimation(self.fig, update, frames=len(history),
                             interval=frame_interval, blit=False, repeat=False)

        return anim


def generate_random_cities(n_cities, x_range=(0, 100), y_range=(0, 100)):
    """生成随机城市坐标"""
    cities = []
    for i in range(n_cities):
        x = random.uniform(x_range[0], x_range[1])
        y = random.uniform(y_range[0], y_range[1])
        cities.append((x, y))
    return cities


def generate_circle_cities(n_cities, radius=50):
    """生成圆形分布的城市（用于测试）"""
    cities = []
    for i in range(n_cities):
        angle = 2 * math.pi * i / n_cities
        x = radius * math.cos(angle) + radius
        y = radius * math.sin(angle) + radius
        cities.append((x, y))
    return cities


def main():
    # 设置随机种子以便重现结果
    random.seed(42)
    np.random.seed(42)

    print("TSP问题求解器 - 模拟退火算法")
    print("=" * 50)

    # 选择城市生成方式
    print("选择城市分布:")
    print("1. 随机分布")
    print("2. 圆形分布")
    choice = input("请输入选择 (1 或 2): ").strip()

    n_cities = int(input("请输入城市数量 (建议 10-30): ").strip())

    if choice == "2":
        cities = generate_circle_cities(n_cities)
        print("生成圆形分布城市")
    else:
        cities = generate_random_cities(n_cities)
        print("生成随机分布城市")

    # 创建求解器
    solver = TSPSolver(
        cities=cities,
        temperature=1000,
        cooling_rate=0.995,
        iterations=2000
    )

    print(f"\n开始求解 {n_cities} 个城市的TSP问题...")
    print(f"参数: 初始温度={solver.temperature}, 冷却速率={solver.cooling_rate}, 迭代次数={solver.iterations}")

    # 求解问题
    best_solution, best_distance = solver.solve()

    print(f"\n求解完成!")
    print(f"最优路径: {best_solution}")
    print(f"最优距离: {best_distance:.2f}")

    # 创建可视化
    print("\n生成可视化...")
    visualizer = TSPVisualizer(solver)

    # 显示最终结果
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    visualizer.plot_path(plt.gca(), solver.generate_initial_solution(),
                         solver.cities, "初始随机路径", 'red')

    plt.subplot(1, 2, 2)
    visualizer.plot_path(plt.gca(), best_solution,
                         solver.cities, f"最优路径 (距离: {best_distance:.2f})", 'green')

    plt.tight_layout()
    plt.show()

    # 显示收敛过程
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    iterations = [h['iteration'] for h in solver.history]
    current_distances = [h['current_distance'] for h in solver.history]
    best_distances = [h['best_distance'] for h in solver.history]

    plt.plot(iterations, current_distances, 'b-', alpha=0.5, label='当前距离')
    plt.plot(iterations, best_distances, 'g-', linewidth=2, label='最优距离')
    plt.xlabel('迭代次数')
    plt.ylabel('距离')
    plt.title('距离收敛过程')
    plt.legend()
    plt.grid(True)

    plt.subplot(1, 2, 2)
    temperatures = [h['temperature'] for h in solver.history]
    plt.plot(iterations, temperatures, 'r-')
    plt.xlabel('迭代次数')
    plt.ylabel('温度')
    plt.title('温度下降过程')
    plt.grid(True)

    plt.tight_layout()2
    plt.show()

    # 询问是否生成动画
    generate_anim = input("\n是否生成动画？(y/n): ").strip().lower()
    if generate_anim == 'y':
        print("生成动画中...")
        anim = visualizer.animate(frame_interval=50)
        plt.show()


if __name__ == "__main__":
    main()