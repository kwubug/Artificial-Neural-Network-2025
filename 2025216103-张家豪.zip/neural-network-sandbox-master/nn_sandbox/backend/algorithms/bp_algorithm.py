import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bipolar_sigmoid


class BpAlgorithm(PredictiveAlgorithm):
    """三层反馈神经网络的BP学习算法"""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 test_ratio=0.3, hidden_neurons=5, output_neurons=1,
                 activation_type='unipolar'):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        self.hidden_neurons = hidden_neurons
        self.output_neurons = output_neurons
        self.activation_type = activation_type  # 'unipolar' or 'bipolar'
        
        # 根据激活函数类型选择对应的函数
        if activation_type == 'bipolar':
            self.activation_function = bipolar_sigmoid
        else:
            self.activation_function = sigmoid

    def _iterate(self):
        """每次迭代的训练过程"""
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]),
                                     result)
        self._adjust_synaptic_weights(deltas)

    def _initialize_neurons(self):
        """初始化神经网络：输入层 -> 隐藏层 -> 输出层"""
        # 隐藏层神经元
        self._hidden_layer = tuple(Perceptron(self.activation_function) 
                                   for _ in range(self.hidden_neurons))
        # 输出层神经元
        self._output_layer = tuple(Perceptron(self.activation_function) 
                                   for _ in range(self.output_neurons))
        
        self._neurons = (self._hidden_layer, self._output_layer)

    def _feed_forward(self, data):
        """前向传播"""
        # 隐藏层计算
        hidden_results = self._get_layer_results(self._hidden_layer, data)
        # 输出层计算
        output_results = self._get_layer_results(self._output_layer, hidden_results)
        return output_results

    def _get_layer_results(self, layer, data):
        """计算某一层的输出结果"""
        for neuron in layer:
            neuron.data = data
        return np.fromiter((neuron.result for neuron in layer), dtype=float)

    def _pass_backward(self, expect, result):
        """反向传播计算误差"""
        deltas = {}
        
        # 计算输出层的误差
        for idx, neuron in enumerate(self._output_layer):
            if self.activation_type == 'bipolar':
                # 双极性sigmoid的导数: f'(x) = 0.5 * (1 - f(x)^2)
                deltas[neuron] = (expect[idx] - result[idx]) * 0.5 * (1 - neuron.result ** 2)
            else:
                # 单极性sigmoid的导数: f'(x) = f(x) * (1 - f(x))
                deltas[neuron] = (expect[idx] - result[idx]) * neuron.result * (1 - neuron.result)
        
        # 计算隐藏层的误差
        for neuron_idx, neuron in enumerate(self._hidden_layer):
            # 计算从输出层传回的误差
            error_sum = sum(deltas[output_neuron] * output_neuron.synaptic_weight[neuron_idx + 1]
                          for output_neuron in self._output_layer)
            
            if self.activation_type == 'bipolar':
                deltas[neuron] = error_sum * 0.5 * (1 - neuron.result ** 2)
            else:
                deltas[neuron] = error_sum * neuron.result * (1 - neuron.result)
        
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        """根据误差调整权值"""
        for neuron in deltas:
            # 权值调整: w = w + η * δ * x
            neuron.synaptic_weight += self.current_learning_rate * deltas[neuron] * neuron.data

    def _correct_rate(self, dataset):
        """计算正确率"""
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            
            # 判断预测是否正确
            if self.output_neurons == 1:
                # 单输出神经元
                interval = 1 / (2 * len(self.group_types))
                if expect[0] - interval < result[0] < expect[0] + interval:
                    correct_count += 1
            else:
                # 多输出神经元，采用最大值匹配
                if np.argmax(result) == np.argmax(expect):
                    correct_count += 1
        
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """归一化期望输出"""
        if self.output_neurons == 1:
            # 单输出神经元
            if self.activation_type == 'bipolar':
                # 双极性: 归一化到 [-1, 1]
                return np.array([(2 * (value - np.amin(self.group_types)) / 
                                (np.amax(self.group_types) - np.amin(self.group_types))) - 1])
            else:
                # 单极性: 归一化到 [0, 1]
                return np.array([(2 * (value - np.amin(self.group_types)) + 1) / 
                                (2 * len(self.group_types))])
        else:
            # 多输出神经元，采用one-hot编码
            result = np.zeros(self.output_neurons)
            class_idx = int(value - np.amin(self.group_types))
            if self.activation_type == 'bipolar':
                result[:] = -1
                result[class_idx] = 1
            else:
                result[class_idx] = 1
            return result


