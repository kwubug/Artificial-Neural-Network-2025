import numpy as np
import math

class GradientDescentAlgorithm:
    """梯度下降算法基类"""
    def __init__(self, func, start_point, learning_rate=0.01, max_iterations=1000):
        self.func = func  # 目标函数
        self.gradient = self._numerical_gradient  # 梯度计算方法
        self.start_point = np.array(start_point)  # 起始点
        self.learning_rate = learning_rate  # 学习率
        self.max_iterations = max_iterations  # 最大迭代次数
        self.current_point = self.start_point.copy()  # 当前点
        self.history = [self.start_point.copy()]  # 记录点的历史
        self.progress_callback = None # 进度回调函数

    def set_progress_callback(self, callback):
        self.progress_callback = callback        
    def _numerical_gradient(self, x):
        """数值梯度计算"""
        h = 1e-8
        grad = np.zeros_like(x)
        for i in range(len(x)):
            x_plus = x.copy()
            x_minus = x.copy()
            x_plus[i] += h
            x_minus[i] -= h
            grad[i] = (self.func(x_plus) - self.func(x_minus)) / (2 * h)
        return grad
    
    def optimize(self):
        """执行优化"""
        for i in range(self.max_iterations):
            grad = self.gradient(self.current_point)
            self.current_point -= self.learning_rate * grad
            self.history.append(self.current_point.copy())

            if self.progress_callback:
                progress = int((i + 1) / self.max_iterations * 100)
                func_value = self.func(self.current_point)
                grad_norm = np.linalg.norm(grad)
                self.progress_callback(progress, self.current_point.tolist(), func_value, grad_norm)
        return self.current_point
    
    def get_history(self):
        """获取优化历史"""
        return np.array(self.history)

class BatchGradientDescent(GradientDescentAlgorithm):
    """批量梯度下降"""
    def optimize(self):
        """执行批量梯度下降优化"""
        for i in range(self.max_iterations):
            grad = self.gradient(self.current_point)
            self.current_point -= self.learning_rate * grad
            self.history.append(self.current_point.copy())

            if self.progress_callback:
                progress = int((i + 1) / self.max_iterations * 100)
                unc_value = self.func(self.current_point)
                grad_norm = np.linalg.norm(grad)
                self.progress_callback(progress, self.current_point.tolist(), unc_value, grad_norm)
        return self.current_point

class StochasticGradientDescent(GradientDescentAlgorithm):
    """随机梯度下降"""
    def __init__(self, func, start_point, learning_rate=0.01, max_iterations=1000):
        super().__init__(func, start_point, learning_rate, max_iterations)
        self.noise_factor = 0.1  # 噪声因子
        
    def optimize(self):
        """执行随机梯度下降优化"""
        for i in range(self.max_iterations):
            grad = self.gradient(self.current_point)
            # 添加随机噪声模拟随机性
            noise = np.random.normal(0, self.noise_factor, self.current_point.shape)
            self.current_point -= self.learning_rate * (grad + noise)
            self.history.append(self.current_point.copy())

            if self.progress_callback:
                progress = int((i + 1) / self.max_iterations * 100)
                func_value = self.func(self.current_point)
                grad_norm = np.linalg.norm(grad)
                self.progress_callback(progress, self.current_point.tolist(), func_value, grad_norm)
        return self.current_point

class MiniBatchGradientDescent(GradientDescentAlgorithm):
    """小批量梯度下降"""
    def __init__(self, func, start_point, learning_rate=0.01, max_iterations=1000, batch_size=10):
        super().__init__(func, start_point, learning_rate, max_iterations)
        self.batch_size = batch_size
        self.noise_factor = 0.05  # 噪声因子比SGD小
        
    def optimize(self):
        """执行小批量梯度下降优化"""
        for i in range(self.max_iterations):
            grad = self.gradient(self.current_point)
            # 添加较小的随机噪声模拟小批量随机性
            noise = np.random.normal(0, self.noise_factor, self.current_point.shape)
            self.current_point -= self.learning_rate * (grad + noise)
            self.history.append(self.current_point.copy())

            if self.progress_callback:
                progress = int((i + 1) / self.max_iterations * 100)
                func_value = self.func(self.current_point)
                grad_norm = np.linalg.norm(grad)
                self.progress_callback(progress, self.current_point.tolist(), func_value, grad_norm)
        return self.current_point