import time
import threading
import numpy as np

from . import TraningAlgorithm


class HopfieldTSPAlgorithm(TraningAlgorithm):
    """
    使用Hopfield网络求解TSP问题（旅行商问题）
    
    网络结构：
    - N个城市，N×N个神经元矩阵 V[x,i]
    - V[x,i]=1 表示城市x在路径的第i个位置访问
    
    能量函数包含4个约束项：
    - A: 每个城市只能在一个位置被访问
    - B: 每个位置只能访问一个城市
    - C: 必须访问N个城市
    - D: 路径总长度最小化
    
    E = A/2 * Σ_x Σ_i Σ_j≠i V[x,i]V[x,j]
      + B/2 * Σ_i Σ_x Σ_y≠x V[x,i]V[y,i]
      + C/2 * (Σ_x Σ_i V[x,i] - N)²
      + D/2 * Σ_x Σ_y Σ_i d[x,y]V[x,i](V[y,i+1] + V[y,i-1])
    """

    def __init__(
        self,
        cities,
        A=800,
        B=800,
        C=300,
        D=700,
        max_iterations=5000,
        ui_refresh_interval=0.02,
        dt=0.01,
        u0=0.1,
        tau=1.0
    ):
        super().__init__(dataset=[], total_epoches=1)
        
        # 城市坐标 [[x1,y1], [x2,y2], ...]
        self.cities = np.array(cities, dtype=float)
        self.n_cities = len(self.cities)
        
        # 计算城市间距离矩阵
        self.distance_matrix = self._compute_distance_matrix()
        
        # 能量函数参数
        self.A = float(A)
        self.B = float(B)
        self.C = float(C)
        self.D = float(D)
        
        # 运行参数
        self._max_iterations = int(max_iterations)
        self._ui_refresh_interval = float(ui_refresh_interval)
        self.dt = float(dt)  # 时间步长
        self.u0 = float(u0)  # 初始化参数
        self.tau = float(tau)  # 时间常数
        
        # 神经元状态：V[x,i] 表示城市x在位置i
        # 使用连续值 [0,1]，通过sigmoid激活
        self.U = None  # 输入电位
        self.V = None  # 输出状态
        self._initialize_network()
        
        # 运行状态
        self.current_iteration = 0
        self.current_energy = 0.0
        self.energy_history = []
        self.best_tour = []  # 初始化为空列表而不是None
        self.best_distance = float('inf')
        self.current_tour = []  # 初始化为空列表而不是None
        self.current_distance = float('inf')
        self.has_finished = True
        
        self._lock = threading.Lock()
        
    def _compute_distance_matrix(self):
        """计算城市间的欧氏距离矩阵"""
        n = self.n_cities
        dist = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    diff = self.cities[i] - self.cities[j]
                    dist[i, j] = np.sqrt(np.sum(diff ** 2))
        return dist
    
    def _initialize_network(self):
        """初始化神经网络状态"""
        n = self.n_cities
        # 在0.5附近随机初始化，加入足够大的扰动打破对称性
        # 使用更大的初始化范围以避免对称陷阱
        self.U = 0.5 * self.u0 * np.random.randn(n, n) + 0.1 * np.random.randn(n, n)
        self.V = self._sigmoid(self.U)
    
    def _sigmoid(self, x):
        """Sigmoid激活函数，使用clip避免溢出"""
        # 限制指数范围避免数值溢出
        return 1.0 / (1.0 + np.exp(-np.clip(x / self.u0, -50, 50)))
    
    def _compute_energy(self):
        """计算当前能量"""
        n = self.n_cities
        V = self.V
        
        # A项：每个城市只在一个位置
        term_A = 0.0
        for x in range(n):
            for i in range(n):
                for j in range(n):
                    if i != j:
                        term_A += V[x, i] * V[x, j]
        term_A *= self.A / 2.0
        
        # B项：每个位置只有一个城市
        term_B = 0.0
        for i in range(n):
            for x in range(n):
                for y in range(n):
                    if x != y:
                        term_B += V[x, i] * V[y, i]
        term_B *= self.B / 2.0
        
        # C项：访问N个城市
        sum_v = np.sum(V)
        term_C = self.C / 2.0 * (sum_v - n) ** 2
        
        # D项：路径长度
        term_D = 0.0
        for x in range(n):
            for y in range(n):
                if x != y:
                    for i in range(n):
                        j_next = (i + 1) % n
                        j_prev = (i - 1) % n
                        term_D += self.distance_matrix[x, y] * V[x, i] * (V[y, j_next] + V[y, j_prev])
        term_D *= self.D / 2.0
        
        return term_A + term_B + term_C + term_D
    
    def _update_network(self):
        """更新神经网络状态（连续Hopfield动力学）"""
        n = self.n_cities
        dU = np.zeros((n, n))
        
        for x in range(n):
            for i in range(n):
                # 计算 dU/dt = -∂E/∂V
                delta = 0.0
                
                # A项的贡献
                for j in range(n):
                    if j != i:
                        delta -= self.A * self.V[x, j]
                
                # B项的贡献
                for y in range(n):
                    if y != x:
                        delta -= self.B * self.V[y, i]
                
                # C项的贡献
                sum_v = np.sum(self.V)
                delta -= self.C * (sum_v - n)
                
                # D项的贡献
                for y in range(n):
                    if y != x:
                        i_next = (i + 1) % n
                        i_prev = (i - 1) % n
                        delta -= self.D * self.distance_matrix[x, y] * (
                            self.V[y, i_next] + self.V[y, i_prev]
                        )
                
                # 添加时间常数tau，使更新更平滑
                dU[x, i] = (delta - self.U[x, i]) / self.tau
        
        # 更新U和V
        self.U += self.dt * dU
        self.V = self._sigmoid(self.U)
    
    def _extract_tour(self):
        """从神经网络状态提取旅行路径
        
        使用改进的提取策略：
        1. 首先尝试简单的argmax提取
        2. 如果无效（有重复），使用贪心匹配确保每个城市恰好访问一次
        """
        n = self.n_cities
        tour = []
        
        # 方法1：简单argmax（快速但可能无效）
        for i in range(n):
            city = np.argmax(self.V[:, i])
            tour.append(int(city))
        
        # 检查是否有效（每个城市恰好一次）
        if len(set(tour)) == n:
            return tour
        
        # 方法2：贪心匹配（确保有效性）
        tour = []
        used_cities = set()
        
        for i in range(n):
            # 获取当前位置所有城市的激活值
            activations = self.V[:, i].copy()
            
            # 按激活值从大到小尝试
            sorted_cities = np.argsort(-activations)
            
            for city in sorted_cities:
                if city not in used_cities:
                    tour.append(int(city))
                    used_cities.add(city)
                    break
            else:
                # 如果所有城市都被用过（理论上不应该发生）
                # 选择一个未使用的城市
                for city in range(n):
                    if city not in used_cities:
                        tour.append(int(city))
                        used_cities.add(city)
                        break
        
        return tour
    
    def _compute_tour_distance(self, tour):
        """计算路径的总距离"""
        if len(tour) != self.n_cities:
            return float('inf')
        
        # 检查是否是有效路径（每个城市恰好访问一次）
        if len(set(tour)) != self.n_cities:
            return float('inf')
        
        distance = 0.0
        for i in range(len(tour)):
            city1 = tour[i]
            city2 = tour[(i + 1) % len(tour)]
            distance += self.distance_matrix[city1, city2]
        
        return distance
    
    def _is_valid_tour(self, tour):
        """检查是否是有效的TSP路径"""
        if len(tour) != self.n_cities:
            return False
        return len(set(tour)) == self.n_cities
    
    def run(self):
        with self._lock:
            self.has_finished = False
            self.energy_history = []
            self.best_distance = float('inf')
            self.best_tour = []  # 使用空列表而不是None
        
        for self.current_iteration in range(1, self._max_iterations + 1):
            if self._should_stop:
                break
            
            # 更新网络
            self._update_network()
            
            with self._lock:
                # 计算能量
                self.current_energy = self._compute_energy()
                self.energy_history.append(self.current_energy)
                
                # 提取当前路径
                self.current_tour = self._extract_tour()
                self.current_distance = self._compute_tour_distance(self.current_tour)
                
                # 更新最优解
                if self._is_valid_tour(self.current_tour) and self.current_distance < self.best_distance:
                    self.best_distance = self.current_distance
                    self.best_tour = self.current_tour.copy()
            
            # UI刷新控制
            if self._ui_refresh_interval > 0:
                remaining = self._ui_refresh_interval
                while remaining > 0 and not self._should_stop:
                    step = 0.01 if remaining > 0.01 else remaining
                    time.sleep(step)
                    remaining -= step
            else:
                if self.current_iteration % 10 == 0:
                    time.sleep(0.001)
        
        with self._lock:
            self.has_finished = True
    
    @property
    def neuron_states(self):
        """返回神经元状态矩阵（用于可视化）"""
        with self._lock:
            return self.V.copy() if self.V is not None else None
