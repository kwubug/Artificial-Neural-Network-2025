import re
import sys
import numpy as np
import matplotlib

# —— 确保中文正常显示 ——
matplotlib.use("Qt5Agg")
matplotlib.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "WenQuanYi Micro Hei", "STHeiti"]
matplotlib.rcParams["axes.unicode_minus"] = False

from dataclasses import dataclass
from typing import Callable, Tuple, List, Dict

from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import (
    QApplication, QWidget, QHBoxLayout, QVBoxLayout, QGridLayout,
    QLabel, QPushButton, QComboBox, QDoubleSpinBox, QSpinBox,
    QLineEdit, QTextEdit
)

from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib import cm


# ===================== 工具函数 =====================
def fmt_pair(xy) -> str:
    """把 numpy 数组/列表格式化成 '(x.xxxx, y.yyyy)'"""
    return f"({xy[0]:.4f}, {xy[1]:.4f})"

def parse_pair(s: str) -> np.ndarray:
    """从 '(a, b)' / '[a, b]' / 'a,b' 等文本解析为 2 元数组（内部用真值，不四舍五入）"""
    nums = re.findall(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?", s)
    if len(nums) >= 2:
        return np.array([float(nums[0]), float(nums[1])], dtype=float)
    return np.array([-1.5, 2.0], dtype=float)


# ===================== 目标函数 =====================
@dataclass
class Objective:
    name: str
    f: Callable[[np.ndarray], float]
    grad: Callable[[np.ndarray], np.ndarray]
    hess: Callable[[np.ndarray], np.ndarray]
    domain: Tuple[Tuple[float, float], Tuple[float, float]]
    x_star: np.ndarray
    f_star: float

def obj_quadratic():
    A = np.array([[3.0, 0.8],
                  [0.8, 1.5]])
    b = np.array([-1.0, 0.5])

    def f(x):
        x = np.asarray(x)
        return float(0.5 * x @ A @ x + b @ x)

    def g(x):
        return A @ x + b

    def H(_):
        return A

    x_star = -np.linalg.solve(A, b)
    # 放大绘制范围
    domain = ((-6.0, 6.0), (-6.0, 6.0))
    return Objective("二次函数", f, g, H, domain, x_star, f(x_star))

def obj_rosenbrock(a=1.0, b=100.0):
    def f(x):
        x1, x2 = x
        return float((a - x1) ** 2 + b * (x2 - x1 ** 2) ** 2)

    def g(x):
        x1, x2 = x
        return np.array([
            -2 * (a - x1) - 4 * b * x1 * (x2 - x1 ** 2),
            2 * b * (x2 - x1 ** 2)
        ])

    def H(x):
        x1, x2 = x
        return np.array([
            [2 - 4 * b * (x2 - 3 * x1 ** 2), -4 * b * x1],
            [-4 * b * x1, 2 * b]
        ])

    x_star = np.array([a, a ** 2])
    # 放大绘制范围（解决轨迹上飘）
    domain = ((-6.0, 6.0), (-6.0, 6.0))
    return Objective("Rosenbrock 函数", f, g, H, domain, x_star, 0.0)

def obj_himmelblau():
    def f(x):
        x1, x2 = x
        return float((x1 ** 2 + x2 - 11) ** 2 + (x1 + x2 ** 2 - 7) ** 2)

    def g(x):
        x1, x2 = x
        return np.array([
            4 * x1 * (x1 ** 2 + x2 - 11) + 2 * (x1 + x2 ** 2 - 7),
            2 * (x1 ** 2 + x2 - 11) + 4 * x2 * (x1 + x2 ** 2 - 7)
        ])

    def H(x):
        x1, x2 = x
        a = 12 * x1 ** 2 + 4 * x2 - 42
        b = 4 * x1 + 4 * x2
        c = 12 * x2 ** 2 + 4 * x1 - 26
        return np.array([[a, b], [b, c]])

    x_star = np.array([3.0, 2.0])  # 其中一个极小点
    # 放大绘制范围
    domain = ((-6.0, 6.0), (-6.0, 6.0))
    return Objective("Himmelblau 函数", f, g, H, domain, x_star, 0.0)

OBJECTS: Dict[str, Objective] = {
    "二次函数": obj_quadratic(),
    "Rosenbrock 函数": obj_rosenbrock(),
    "Himmelblau 函数": obj_himmelblau(),
}


# ===================== 三种算法的一步（固定 lr） =====================
def step_sd(obj: Objective, x, lr, **_):
    g = obj.grad(x)
    d = -g
    a = lr
    x_new = x + a * d
    return x_new, {"alpha": a, "gnorm": float(np.linalg.norm(g))}

def step_newton(obj: Objective, x, lr, **_):
    g = obj.grad(x)
    H = obj.hess(x)
    try:
        p = -np.linalg.solve(H, g)
    except np.linalg.LinAlgError:
        p = -g
    a = lr
    x_new = x + a * p
    return x_new, {"alpha": a, "gnorm": float(np.linalg.norm(g))}

def step_cg_pr(obj: Objective, x, lr, **kw):
    st = kw.setdefault("state", {})
    g = obj.grad(x)
    if "d" not in st:
        d = -g
    else:
        g0, d0 = st["g"], st["d"]
        beta = (g @ (g - g0)) / (g0 @ g0 + 1e-12)
        beta = max(0.0, beta)
        d = -g + beta * d0
    a = lr
    x_new = x + a * d
    st["g"] = g
    st["d"] = d
    return x_new, {"alpha": a, "gnorm": float(np.linalg.norm(g))}


# ===================== 画布区域 =====================
class PlotPane(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        # —— 两张主图等大 ——
        self.fig3d = Figure(figsize=(7.0, 5.2))
        self.ax3d = self.fig3d.add_subplot(111, projection='3d')
        self.canvas3d = FigureCanvas(self.fig3d)

        self.fig2d = Figure(figsize=(7.0, 5.2))
        self.ax2d = self.fig2d.add_subplot(111)
        self.canvas2d = FigureCanvas(self.fig2d)

        self.figErr = Figure(figsize=(7.2, 3.0))
        self.axErr = self.figErr.add_subplot(111)
        self.canvasErr = FigureCanvas(self.figErr)
        self.err_line = None

        layout = QVBoxLayout()
        upper = QHBoxLayout()
        upper.addWidget(self.canvas3d, stretch=1)
        upper.addWidget(self.canvas2d, stretch=1)
        layout.addLayout(upper)
        layout.addWidget(self.canvasErr, stretch=0)
        self.setLayout(layout)

    def draw_surfaces(self, obj: Objective):
        self.ax3d.clear(); self.ax2d.clear(); self.axErr.clear(); self.err_line = None

        (x0, x1), (y0, y1) = obj.domain
        X = np.linspace(x0, x1, 220)   # 稍密的网格
        Y = np.linspace(y0, y1, 220)
        Xg, Yg = np.meshgrid(X, Y)
        Z = np.vectorize(lambda a, b: obj.f(np.array([a, b])))(Xg, Yg)

        # 3D 曲面
        self.ax3d.plot_surface(Xg, Yg, Z, cmap=cm.viridis, alpha=0.5, linewidth=0, antialiased=True)
        self.ax3d.set_xlabel("x"); self.ax3d.set_ylabel("y"); self.ax3d.set_zlabel("f(x, y)")
        self.ax3d.view_init(elev=32, azim=140)
        try:
            self.ax3d.set_box_aspect((1, 1, 0.75))
        except Exception:
            pass
        # 固定范围，避免越界
        self.ax3d.set_xlim(x0, x1)
        self.ax3d.set_ylim(y0, y1)

        # 2D 等高线
        cs = self.ax2d.contour(Xg, Yg, Z, levels=28, cmap=cm.viridis)
        self.ax2d.clabel(cs, inline=True, fontsize=8, fmt="%.1f")
        self.ax2d.set_aspect('equal', adjustable='box')
        self.ax2d.set_xlabel("x"); self.ax2d.set_ylabel("y"); self.ax2d.set_title("等高线与迭代轨迹")
        self.ax2d.scatter(obj.x_star[0], obj.x_star[1], s=70, c="black", marker="x", label="已知极小点")
        self.ax2d.legend(loc="upper right")
        self.ax2d.set_xlim(x0, x1)
        self.ax2d.set_ylim(y0, y1)

        # 误差曲线
        self.axErr.set_xlabel("迭代次数"); self.axErr.set_ylabel("|f(x) - f*|"); self.axErr.set_title("误差曲线")

        self.canvas3d.draw(); self.canvas2d.draw(); self.canvasErr.draw()

    def plot_step(self, obj: Objective, x_prev, x_new, fval, err_hist):
        # 3D 轨迹
        self.ax3d.plot([x_prev[0], x_new[0]],
                       [x_prev[1], x_new[1]],
                       [obj.f(x_prev), fval], 'r-', lw=3)
        self.ax3d.scatter(x_new[0], x_new[1], fval, c='r', s=36)
        self.canvas3d.draw()

        # 2D 轨迹
        self.ax2d.plot([x_prev[0], x_new[0]],
                       [x_prev[1], x_new[1]], 'r.-', lw=2.5, ms=5)
        self.canvas2d.draw()

        # 误差折线
        xs = np.arange(len(err_hist))
        ys = np.array(err_hist)
        if self.err_line is None:
            (self.err_line,) = self.axErr.plot(xs, ys, '-', lw=2.2, color='r')
        else:
            self.err_line.set_data(xs, ys)
            self.axErr.relim(); self.axErr.autoscale_view()
        self.canvasErr.draw()


# ===================== 控件区域 =====================
class ControlPane(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.cmb_obj = QComboBox(); self.cmb_obj.addItems(list(OBJECTS.keys()))
        self.cmb_alg = QComboBox(); self.cmb_alg.addItems(["最速下降法", "牛顿法", "共轭梯度法"])

        self.spin_lr = QDoubleSpinBox(); self.spin_lr.setDecimals(4); self.spin_lr.setRange(1e-6, 10.0)
        self.spin_lr.setSingleStep(0.01); self.spin_lr.setValue(0.02)

        self.spin_iter = QSpinBox(); self.spin_iter.setRange(1, 5000); self.spin_iter.setValue(300)
        self.spin_tol  = QDoubleSpinBox(); self.spin_tol.setDecimals(6); self.spin_tol.setRange(1e-12, 1.0); self.spin_tol.setValue(1e-4)

        self.edit_x0 = QLineEdit("(-1.5000, 2.0000)")
        self.btn_rand = QPushButton("随机初始化")

        self.btn_start = QPushButton("开始")
        self.btn_pause = QPushButton("暂停")
        self.btn_reset = QPushButton("重置")

        self.txt_report = QTextEdit(); self.txt_report.setReadOnly(True); self.txt_report.setMinimumWidth(320)
        self.txt_report.setPlaceholderText("优化结果将在此显示")

        g = QGridLayout(); r = 0
        g.addWidget(QLabel("目标函数"), r, 0); g.addWidget(self.cmb_obj, r, 1); r += 1
        g.addWidget(QLabel("梯度下降算法"), r, 0); g.addWidget(self.cmb_alg, r, 1); r += 1
        g.addWidget(QLabel("学习率"), r, 0); g.addWidget(self.spin_lr, r, 1); r += 1
        g.addWidget(QLabel("最大迭代数"), r, 0); g.addWidget(self.spin_iter, r, 1); r += 1
        g.addWidget(QLabel("收敛阈值"), r, 0); g.addWidget(self.spin_tol, r, 1); r += 1
        g.addWidget(QLabel("初始点"), r, 0); g.addWidget(self.edit_x0, r, 1); r += 1
        g.addWidget(self.btn_rand, r, 0, 1, 2); r += 1
        g.addWidget(QLabel("优化结果"), r, 0, 1, 2); r += 1
        g.addWidget(self.txt_report, r, 0, 1, 2); r += 1

        v = QVBoxLayout(); v.addLayout(g)
        btns = QHBoxLayout(); btns.addWidget(self.btn_start); btns.addWidget(self.btn_pause); btns.addWidget(self.btn_reset)
        v.addLayout(btns)
        self.setLayout(v)


# ===================== 主窗口 =====================
class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("梯度下降算法可视化软件")
        self.resize(1450, 860)

        self.ctrl = ControlPane()
        self.plot = PlotPane()

        root = QHBoxLayout()
        root.addWidget(self.ctrl, 0)
        root.addWidget(self.plot, 1)
        self.setLayout(root)

        self.timer = QTimer(self)
        self.timer.setInterval(60)
        self.timer.timeout.connect(self.iterate_once)

        self.obj = OBJECTS[self.ctrl.cmb_obj.currentText()]
        self.reset_state()

        # 事件绑定
        self.ctrl.cmb_obj.currentTextChanged.connect(self.on_obj_changed)
        self.ctrl.btn_start.clicked.connect(self.on_start)
        self.ctrl.btn_pause.clicked.connect(self.on_pause)
        self.ctrl.btn_reset.clicked.connect(self.on_reset)
        self.ctrl.btn_rand.clicked.connect(self.on_random_init)

    # -------- 状态与解析 --------
    def on_obj_changed(self, _):
        self.obj = OBJECTS[self.ctrl.cmb_obj.currentText()]
        self.reset_state()

    def parse_x0(self) -> np.ndarray:
        x0 = parse_pair(self.ctrl.edit_x0.text())
        self.ctrl.edit_x0.setText(fmt_pair(x0))  # 仅显示四位
        return x0

    def reset_state(self):
        self.k = 0
        self.x = self.parse_x0()
        self.state_dict = {}
        self.loss: List[float] = []
        self.err:  List[float] = []
        f0 = self.obj.f(self.x)
        self.loss.append(f0); self.err.append(abs(f0 - self.obj.f_star))
        self.plot.draw_surfaces(self.obj)
        self.show_report(final=False)

    # -------- 控件回调 --------
    def on_start(self):
        if not self.timer.isActive():
            self.timer.start()

    def on_pause(self):
        if self.timer.isActive():
            self.timer.stop()

    def on_reset(self):
        self.timer.stop()
        self.reset_state()

    def on_random_init(self):
        (x0, x1), (y0, y1) = self.obj.domain
        x = np.array([np.random.uniform(x0, x1), np.random.uniform(y0, y1)], dtype=float)
        self.ctrl.edit_x0.setText(fmt_pair(x))
        self.reset_state()

    # -------- 单步迭代 --------
    def iterate_once(self):
        if self.k >= self.ctrl.spin_iter.value():
            self.finish()
            return

        lr = self.ctrl.spin_lr.value()
        tol = self.ctrl.spin_tol.value()
        algo = self.ctrl.cmb_alg.currentText()

        x_prev = self.x.copy()
        if algo == "最速下降法":
            self.x, info = step_sd(self.obj, self.x, lr)
        elif algo == "牛顿法":
            self.x, info = step_newton(self.obj, self.x, lr)
        else:
            self.x, info = step_cg_pr(self.obj, self.x, lr, state=self.state_dict)

        fval = self.obj.f(self.x)
        self.k += 1
        self.loss.append(fval)
        self.err.append(abs(fval - self.obj.f_star))

        # 绘制：使用“真值”，轨迹平滑连续
        self.plot.plot_step(self.obj, x_prev, self.x, fval, self.err)

        # 收敛判断
        gnorm = float(np.linalg.norm(self.obj.grad(self.x)))
        if gnorm < tol:
            self.finish()
        else:
            self.show_report(final=False, extra=info)

    def finish(self):
        self.timer.stop()
        self.show_report(final=True)

    # -------- 报告输出（仅显示时四舍五入） --------
    def show_report(self, final: bool, extra: dict = None):
        algo = self.ctrl.cmb_alg.currentText()
        x0 = parse_pair(self.ctrl.edit_x0.text())
        f0 = self.obj.f(x0)

        txt  = f"梯度下降算法：{algo}\n"
        txt += f"迭代次数：{self.k}\n"
        txt += f"初始点：{fmt_pair(x0)}\n"
        txt += f"初始函数值：{f0:.6f}\n"

        if final:
            txt += f"最终点：{fmt_pair(self.x)}\n"
            txt += f"最终函数值：{self.obj.f(self.x):.6f}\n"
            txt += f"梯度范数：{float(np.linalg.norm(self.obj.grad(self.x))):.6f}\n"
            if len(self.err) > 0:
                txt += f"最终误差 |f-f*|：{self.err[-1]:.6f}\n"
            txt += f"最终步长：{self.ctrl.spin_lr.value():.6f}\n"
        else:
            if extra is not None:
                txt += f"当前点：{fmt_pair(self.x)}\n"
                txt += f"当前函数值：{self.obj.f(self.x):.6f}\n"
                txt += f"当前步长：{self.ctrl.spin_lr.value():.6f}\n"
                txt += f"当前梯度范数：{extra['gnorm']:.6f}\n"

        self.ctrl.txt_report.setText(txt)
        self.setWindowTitle(f"梯度下降算法可视化软件")


# ===================== main =====================
def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
