import QtQml 2.13
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'OLS-RBFN'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(olsRbfnBridge.dataset_dict)
                enabled: olsRbfnBridge.has_finished
                onActivated: () => {
                    olsRbfnBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsRbfnBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    olsRbfnBridge.current_dataset_name = currentText
                    dataChart.updateDataset(olsRbfnBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: 'OLS Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: 'Total Training Epoches'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 3
                    from: 1
                    to: 100
                    onValueChanged: olsRbfnBridge.total_epoches = value
                    Component.onCompleted: olsRbfnBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                CheckBox {
                    id: mostCorrectRateCheckBox
                    enabled: olsRbfnBridge.has_finished
                    text: 'Most Correct Rate'
                    checked: true
                    onCheckedChanged: olsRbfnBridge.most_correct_rate_checkbox = checked
                    Component.onCompleted: olsRbfnBridge.most_correct_rate_checkbox = checked
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: mostCorrectRateCheckBox.checked && olsRbfnBridge.has_finished
                    editable: true
                    value: 1.00 * 100
                    onValueChanged: olsRbfnBridge.most_correct_rate = value / 100
                    Component.onCompleted: olsRbfnBridge.most_correct_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Acceptable Range (±)'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 0.5 * 100
                    to: 999999 * 100
                    onValueChanged: olsRbfnBridge.acceptable_range = value / 100
                    Component.onCompleted: olsRbfnBridge.acceptable_range = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Max Centers (OLS)'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.text: 'Maximum number of RBF centers to select'
                    ToolTip.visible: hovered
                    ToolTip.delay: 500
                    MouseArea {
                        id: hovered
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                SpinBox {
                    id: maxCenters
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 10
                    from: 1
                    to: 50
                    onValueChanged: olsRbfnBridge.max_centers = value
                    Component.onCompleted: olsRbfnBridge.max_centers = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'ERR Threshold (OLS)'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.text: 'Error Reduction Ratio threshold for stopping'
                    ToolTip.visible: errHovered
                    ToolTip.delay: 500
                    MouseArea {
                        id: errHovered
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                DoubleSpinBox {
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 0.01 * 100
                    decimals: 4
                    from: 0.001 * 100
                    to: 0.1 * 100
                    onValueChanged: olsRbfnBridge.err_threshold = value / 100
                    Component.onCompleted: olsRbfnBridge.err_threshold = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'RBF Sigma (σ)'
                    Layout.alignment: Qt.AlignHCenter
                    ToolTip.text: 'Standard deviation of Gaussian RBF'
                    ToolTip.visible: sigmaHovered
                    ToolTip.delay: 500
                    MouseArea {
                        id: sigmaHovered
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                DoubleSpinBox {
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 1.0 * 100
                    from: 0.1 * 100
                    to: 5.0 * 100
                    onValueChanged: olsRbfnBridge.sigma = value / 100
                    Component.onCompleted: olsRbfnBridge.sigma = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Test-Train Ratio'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 10
                    to: 90
                    onValueChanged: olsRbfnBridge.test_ratio = value / 100
                    Component.onCompleted: olsRbfnBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: olsRbfnBridge.has_finished
                    editable: true
                    value: 0.2 * 100
                    from: 0.05 * 100
                    to: 2 * 100
                    onValueChanged: olsRbfnBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: olsRbfnBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'OLS Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: olsRbfnBridge.has_finished
                    startButton.onClicked: () => {
                        olsRbfnBridge.start_ols_rbfn_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(olsRbfnBridge.training_dataset)
                        dataChart.updateTestingDataset(olsRbfnBridge.testing_dataset)
                        rateChart.reset()
                        errChart.reset()
                    }
                    stopButton.enabled: !olsRbfnBridge.has_finished
                    stopButton.onClicked: olsRbfnBridge.stop_ols_rbfn_algorithm()
                    progressBar.value: (olsRbfnBridge.current_iterations + 1) / (totalEpoches.value * olsRbfnBridge.training_dataset.length)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Epoch'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const epoch = Math.floor(olsRbfnBridge.current_iterations / olsRbfnBridge.training_dataset.length) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: 'Selected Centers (OLS)'
                    Layout.alignment: Qt.AlignHCenter
                    font.bold: true
                }
                Label {
                    text: olsRbfnBridge.selected_centers_count
                    horizontalAlignment: Text.AlignHCenter
                    font.bold: true
                    font.pointSize: 14
                    color: '#4CAF50'
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Iteration'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsRbfnBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        // 实时更新中心显示（关键！）
                        dataChart.updateNeurons()
                        neuronChart.updateAxisY()
                        
                        // 更新准确率曲线
                        rateChart.bestCorrectRate.append(
                            olsRbfnBridge.current_iterations + 1,
                            olsRbfnBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            olsRbfnBridge.current_iterations + 1,
                            olsRbfnBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            olsRbfnBridge.current_iterations + 1,
                            olsRbfnBridge.test_correct_rate
                        )
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Best Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsRbfnBridge.best_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsRbfnBridge.current_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Testing Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: olsRbfnBridge.test_correct_rate.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            property var neuronScatters: []

            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true

            function updateNeurons() {
                // 移除旧的中心标记
                neuronScatters.forEach(neuron => {removeSeries(neuron)})
                neuronScatters = []

                // 为每个选择的中心创建散点系列
                for (let {mean: m, standardDeviation: sd, synapticWeight: sw} of olsRbfnBridge.current_neurons) {
                    if (m && m.length >= 2) {
                        neuronScatters.push(createHoverableNeuronSeries(m, sw, sd))
                    }
                }
            }

            function createHoverableNeuronSeries(mean, weight, sigma) {
                const newSeries = createSeries(
                    ChartView.SeriesTypeScatter, 'OLS Center',
                    xAxis, yAxis
                )
                
                // 设置中心标记样式 - 黑色中心，黄色边框（醒目）
                newSeries.color = 'black'
                newSeries.borderColor = 'yellow'
                newSeries.borderWidth = 3
                newSeries.markerSize = 15  // 较大的标记，易于识别
                
                // 悬浮提示
                newSeries.hovered.connect((point, state) => {
                    const position = mapToPosition(point)
                    chartToolTip.x = position.x - chartToolTip.width
                    chartToolTip.y = position.y - chartToolTip.height
                    chartToolTip.text = `OLS Center\nMean: (${point.x.toFixed(3)}, ${point.y.toFixed(3)})\nWeight: ${weight.toFixed(4)}\nSigma: ${sigma.toFixed(3)}`
                    chartToolTip.visible = state
                })
                
                newSeries.append(...mean)
                newSeries.useOpenGL = true
                return newSeries
            }

            function clear() {
                removeAllSeries()
                scatterSeriesMap = {}
                neuronScatters = []
            }
        }
        RowLayout {
            // ERR历史图表（OLS特有）
            ChartView {
                id: errChart
                title: 'Error Reduction Ratio (ERR) History'
                antialiasing: true
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                ValueAxis {
                    id: errAxisX
                    titleText: 'Selection Step'
                    min: 0
                    max: 20
                }
                ValueAxis {
                    id: errAxisY
                    titleText: 'ERR Value'
                    min: 0
                    max: 1
                }
                
                LineSeries {
                    id: errSeries
                    name: 'ERR'
                    axisX: errAxisX
                    axisY: errAxisY
                    color: '#FF5722'
                    width: 3
                }
                
                ScatterSeries {
                    id: errScatter
                    name: 'ERR Points'
                    axisX: errAxisX
                    axisY: errAxisY
                    color: '#FF5722'
                    markerSize: 12
                }
                
                function reset() {
                    errSeries.clear()
                    errScatter.clear()
                }
                
                function updateERR() {
                    console.log("📊 [QML] updateERR 被调用")
                    errSeries.clear()
                    errScatter.clear()
                    
                    const errHistory = olsRbfnBridge.err_history
                    console.log("📊 [QML] err_history:", JSON.stringify(errHistory))
                    console.log("📊 [QML] err_history.length:", errHistory.length)
                    
                    if (errHistory.length === 0) {
                        console.log("⚠️ [QML] ERR历史为空，退出")
                        return
                    }
                    
                    // 更新坐标轴
                    errAxisX.max = Math.max(20, errHistory.length + 2)
                    const maxErr = Math.max(...errHistory)
                    errAxisY.max = Math.min(1, maxErr * 1.1)
                    console.log("📊 [QML] 坐标轴范围: X[0-" + errAxisX.max + "], Y[0-" + errAxisY.max + "]")
                    
                    // 添加数据点
                    for (let i = 0; i < errHistory.length; i++) {
                        errSeries.append(i + 1, errHistory[i])
                        errScatter.append(i + 1, errHistory[i])
                        console.log(`📊 [QML] 添加点 (${i + 1}, ${errHistory[i]})`)
                    }
                    console.log("✅ [QML] ERR图表更新完成")
                }
            }
            
            // 神经元信息图表
            ChartView {
                id: neuronChart
                title: 'RBF Neuron Weights'
                antialiasing: true
                Layout.fillWidth: true
                Layout.fillHeight: true
                margins.bottom: 10
                margins.left: 10
                ToolTip {
                    id: neuronChartToolTip
                    x: (parent.width - width) / 2
                    y: (parent.height - height) / 2
                }
                BarSeries {
                    id: neuronChartSeries
                    useOpenGL: true
                    axisX: BarCategoryAxis {
                        titleText: 'Centers'
                        labelsAngle: 0
                        categories: Array.from(Array(olsRbfnBridge.selected_centers_count).keys()).map(i => `C${i+1}`)
                    }
                    axisY: ValueAxis {
                        id: neuronChartAxisY
                        titleText: 'Value'
                        max: 1
                        min: -1
                    }
                    BarSet {
                        id: synapticWeightBarSet
                        label: 'Synaptic Weight'
                        values: olsRbfnBridge.current_neurons.map(neuron => neuron.synaptic_weight)
                        color: '#2196F3'
                    }
                    BarSet {
                        id: standardDeviationBarSet
                        label: 'Sigma (σ)'
                        values: olsRbfnBridge.current_neurons.map(neuron => neuron.standard_deviation)
                        color: '#FF9800'
                    }
                    onHovered: (status, index, barset) => {
                        neuronChartToolTip.text = `${barset.label}: ${barset.at(index).toFixed(4)}`
                        neuronChartToolTip.visible = status
                    }
                }
                function updateAxisY() {
                    const max = Math.max(1, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    const min = Math.min(-1, ...standardDeviationBarSet.values, ...synapticWeightBarSet.values)
                    neuronChartAxisY.max = isFinite(max) ? max : 1
                    neuronChartAxisY.min = isFinite(min) ? min : -1
                }
            }
        }
        // 准确率图表
        RateChart {
            id: rateChart
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
    }
    Connections {
        target: olsRbfnBridge
        // 训练完成时更新
        onHas_finishedChanged: {
            console.log("🔔 [QML Connections] has_finished 变化:", olsRbfnBridge.has_finished)
            dataChart.updateNeurons()
            errChart.updateERR()
        }
        // ERR历史更新时更新图表
        onErr_historyChanged: {
            console.log("🔔 [QML Connections] err_history 变化，长度:", olsRbfnBridge.err_history.length)
            errChart.updateERR()
        }
        // 中心选择历史更新时更新ERR图表
        onCenter_selection_historyChanged: {
            console.log("🔔 [QML Connections] center_selection_history 变化")
            errChart.updateERR()
        }
    }
}

