import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import OlsAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsBridge(Bridge):
    """OLS算法的桥接类，连接前端QML和后端算法"""
    
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    acceptable_range = BridgeProperty(0.5)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    max_centers = BridgeProperty(5)
    err_threshold = BridgeProperty(0.001)
    initial_sigma = BridgeProperty(1.0)
    test_ratio = BridgeProperty(0.3)
    # 新增的优化参数
    adaptive_sigma = BridgeProperty(True)
    regularization_lambda = BridgeProperty(0.0001)
    backward_elimination = BridgeProperty(True)
    min_err_contribution = BridgeProperty(0.0001)
    # 状态属性
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_neurons = BridgeProperty([])
    center_count = BridgeProperty(0)
    err_ratios = BridgeProperty([])
    # 新增：详细计算过程
    calculation_steps = BridgeProperty([])
    err_calculation_details = BridgeProperty([])
    gram_schmidt_steps = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.ols_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_ols_algorithm(self):
        """启动OLS算法"""
        self.ols_algorithm = ObservableOlsAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            acceptable_range=self.acceptable_range,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            max_centers=self.max_centers,
            err_threshold=self.err_threshold,
            initial_sigma=self.initial_sigma,
            test_ratio=self.test_ratio,
            adaptive_sigma=self.adaptive_sigma,
            regularization_lambda=self.regularization_lambda,
            backward_elimination=self.backward_elimination,
            min_err_contribution=self.min_err_contribution
        )
        self.ols_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols_algorithm(self):
        """停止OLS算法"""
        if self.ols_algorithm:
            self.ols_algorithm.stop()

    @property
    def _most_correct_rate(self):
        """获取目标正确率（如果启用）"""
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableOlsAlgorithm(Observable, OlsAlgorithm):
    """可观察的OLS算法，用于自动更新UI"""
    
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self.has_initialized = False
        Observable.__init__(self, observer)
        OlsAlgorithm.__init__(self, **kwargs)
        self.has_initialized = True
        self.ui_refresh_interval = ui_refresh_interval
        

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        
        if name == 'current_iterations' and self.has_initialized:
            self.notify(name, value)
            
            # 降低更新频率，避免GUI阻塞
            # 每10次迭代更新一次神经元状态，或每100次迭代更新一次测试正确率
            if value % 10 == 0:
                # 通知当前神经元状态
                self.notify('current_neurons', [{
                    'mean': neuron.mean.tolist(),
                    'standard_deviation': float(neuron.standard_deviation),
                    'synaptic_weight': float(neuron.synaptic_weight)
                } for neuron in self._neurons if not neuron.is_threshold])
            
            # 每100次迭代才计算测试正确率（避免频繁计算）
            if value % 100 == 0:
                self.notify('test_correct_rate', self.test())
            
        if name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
            
        if name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())
            
        if name == 'center_count' and self.has_initialized:
            self.notify(name, value)
            
        if name == 'err_ratios' and self.has_initialized:
            # 确保err_ratios是列表格式并通知
            err_list = value if isinstance(value, list) else list(value) if value is not None else []
            self.notify('err_ratios', err_list)
        
        # 新增：通知详细计算过程
        if name in ('calculation_steps', 'err_calculation_details', 'gram_schmidt_steps') and self.has_initialized:
            steps_list = value if isinstance(value, list) else list(value) if value is not None else []
            self.notify(name, steps_list)

    def run(self):
        """运行算法"""
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        # 清空之前的ERR值
        self.notify('err_ratios', [])
        self.notify('center_count', 0)
        # 清空详细计算步骤
        self.notify('calculation_steps', [])
        self.notify('err_calculation_details', [])
        self.notify('gram_schmidt_steps', [])
        
        # 执行算法（在_initialize_neurons中会设置err_ratios和center_count）
        # 由于__setattr__会监听这些属性的变化，它们会在设置时自动通知前端
        super().run()
        
        # 在初始化完成后立即通知ERR值和中心数量
        # 因为err_ratios是通过append添加的，不会触发__setattr__，需要手动通知
        if hasattr(self, 'err_ratios') and self.err_ratios:
            # 确保是Python列表格式
            err_list = [float(err) for err in self.err_ratios] if isinstance(self.err_ratios, (list, tuple)) else []
            self.notify('err_ratios', err_list)
        
        if hasattr(self, 'center_count'):
            self.notify('center_count', self.center_count)
        
        # 确保在训练完成后再次通知（以防万一）
        if hasattr(self, 'center_count') and hasattr(self, 'err_ratios'):
            self.notify('center_count', self.center_count)
            err_list = [float(err) for err in self.err_ratios] if isinstance(self.err_ratios, (list, tuple)) else []
            self.notify('err_ratios', err_list)
        
        # 通知详细计算步骤
        if hasattr(self, 'calculation_steps'):
            self.notify('calculation_steps', self.calculation_steps)
        if hasattr(self, 'err_calculation_details'):
            self.notify('err_calculation_details', self.err_calculation_details)
        if hasattr(self, 'gram_schmidt_steps'):
            self.notify('gram_schmidt_steps', self.gram_schmidt_steps)
        
        # 通知最终神经元状态（确保更新）
        self.notify('current_neurons', [{
            'mean': neuron.mean.tolist(),
            'standard_deviation': float(neuron.standard_deviation),
            'synaptic_weight': float(neuron.synaptic_weight)
        } for neuron in self._neurons if not neuron.is_threshold])
        
        # 通知最终测试正确率
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)
        
        # 给GUI最后一次更新时间
        import time
        time.sleep(0.01)

    def _notify_err_ratios_update(self):
        """实时通知ERR值更新（在OLS选择每个中心时调用）"""
        if hasattr(self, 'err_ratios') and self.err_ratios:
            err_list = [float(err) for err in self.err_ratios] if isinstance(self.err_ratios, (list, tuple)) else []
            self.notify('err_ratios', err_list)
        if hasattr(self, 'center_count'):
            self.notify('center_count', self.center_count)
    
    def _initialize_neurons(self):
        """重写初始化方法，在初始化完成后立即通知ERR值"""
        # 通知开始初始化
        self.notify('has_finished', False)
        
        # 执行初始化（可能耗时较长）
        super()._initialize_neurons()
        
        # 初始化完成后立即通知ERR值和中心数量
        # 因为err_ratios是通过append添加的，不会触发__setattr__
        self._notify_err_ratios_update()
        
        # 给GUI一点时间响应
        import time
        time.sleep(0.01)
    
    def _iterate(self):
        """单次迭代"""
        super()._iterate()
        # 防止GUI阻塞
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        """获取当前学习率并通知观察者"""
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret

