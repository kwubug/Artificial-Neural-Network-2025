import sys
import numpy as np
import matplotlib
matplotlib.use('Qt5Agg')  # 兼容PyQt5的渲染后端
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import PyQt5.QtWidgets as qtw
import PyQt5.QtCore as qtc
import PyQt5.QtGui as qtg

# 中文字体配置（Windows必带，无警告）
plt.rcParams["font.family"] = ["SimHei", "SimSun", "FangSong"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams['figure.dpi'] = 100  # 统一DPI，图形清晰

class GradientDescentVisualizer(qtw.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("梯度下降算法可视化软件")
        self.setGeometry(100, 100, 1300, 800)

        # 算法核心参数（默认值）
        self.selected_algo = "最速下降法"
        self.init_point = np.array([2.0, 2.0])  # 初始点 (x0, y0)
        self.lr = 0.1  # 学习率（牛顿法无需）
        self.max_iter = 100  # 最大迭代次数
        self.tol = 1e-6  # 收敛容差（梯度模长阈值）

        # 迭代历史记录
        self.iter_history = []  # 记录每步坐标 (x, y)
        self.func_values = []  # 记录每步函数值 f(x,y)

        # 初始化图形画布（先于UI创建，避免渲染冲突）
        self.init_figure()
        # 创建UI界面
        self.init_ui()

    def init_ui(self):
        """创建完整交互UI"""
        main_widget = qtw.QWidget()
        main_layout = qtw.QHBoxLayout(main_widget)

        # 左侧控制面板（320px固定宽度）
        control_panel = qtw.QWidget()
        control_layout = qtw.QVBoxLayout(control_panel)
        control_panel.setFixedWidth(320)

        # 1. 算法选择分组
        algo_group = qtw.QGroupBox("📌 选择优化算法", styleSheet="font-size: 12px;")
        algo_layout = qtw.QVBoxLayout()
        self.algo_btns = {
            "最速下降法": qtw.QRadioButton("最速下降法（梯度下降）"),
            "牛顿法": qtw.QRadioButton("牛顿法（二阶优化，收敛快）"),
            "共轭梯度法": qtw.QRadioButton("共轭梯度法（无约束优化）")
        }
        self.algo_btns["最速下降法"].setChecked(True)
        for btn in self.algo_btns.values():
            btn.toggled.connect(self.on_algo_change)
            btn.setStyleSheet("font-size: 11px; margin: 5px 0;")
            algo_layout.addWidget(btn)
        algo_group.setLayout(algo_layout)
        control_layout.addWidget(algo_group)

        # 2. 参数配置分组
        param_group = qtw.QGroupBox("⚙️ 算法参数配置", styleSheet="font-size: 12px;")
        param_layout = qtw.QFormLayout()
        param_layout.setSpacing(15)
        param_layout.setContentsMargins(10, 10, 10, 10)

        # 初始点输入
        self.x0_input = qtw.QLineEdit(str(self.init_point[0]))
        self.y0_input = qtw.QLineEdit(str(self.init_point[1]))
        # 学习率输入
        self.lr_input = qtw.QLineEdit(str(self.lr))
        # 最大迭代次数输入
        self.iter_input = qtw.QLineEdit(str(self.max_iter))
        # 收敛容差输入
        self.tol_input = qtw.QLineEdit(str(self.tol))

        # 输入框样式与验证
        for input_box in [self.x0_input, self.y0_input, self.lr_input, self.iter_input, self.tol_input]:
            input_box.setStyleSheet("padding: 6px; font-size: 11px;")
            # 仅允许数字输入
            validator = qtg.QDoubleValidator() if input_box != self.iter_input else qtg.QIntValidator()
            input_box.setValidator(validator)

        # 添加到参数布局
        param_layout.addRow("初始点 X:", self.x0_input)
        param_layout.addRow("初始点 Y:", self.y0_input)
        param_layout.addRow("学习率（η）:", self.lr_input)
        param_layout.addRow("最大迭代次数:", self.iter_input)
        param_layout.addRow("收敛容差（ε）:", self.tol_input)
        param_group.setLayout(param_layout)
        control_layout.addWidget(param_group)

        # 3. 目标函数选择分组
        func_group = qtw.QGroupBox("📈 选择目标函数", styleSheet="font-size: 12px;")
        func_layout = qtw.QVBoxLayout()
        self.func_btns = {
            "二次函数": qtw.QRadioButton("二次函数 f(x,y) = x² + 2y²（凸函数，易优化）"),
            "Rosenbrock": qtw.QRadioButton("Rosenbrock函数 f(x,y) = (1-x)² + 100(y-x²)²（非凸）"),
            "自定义函数": qtw.QRadioButton("自定义函数 f(x,y) = x² + y² + sin(x) + cos(y)")
        }
        self.func_btns["二次函数"].setChecked(True)
        for btn in self.func_btns.values():
            btn.setStyleSheet("font-size: 11px; margin: 5px 0;")
            func_layout.addWidget(btn)
        func_group.setLayout(func_layout)
        control_layout.addWidget(func_group)

        # 4. 功能按钮组
        btn_layout = qtw.QHBoxLayout()
        self.run_btn = qtw.QPushButton("▶️ 运行算法")
        self.reset_btn = qtw.QPushButton("🔄 重置")
        self.run_btn.setStyleSheet("padding: 8px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; font-size: 11px;")
        self.reset_btn.setStyleSheet("padding: 8px; background-color: #f44336; color: white; border: none; border-radius: 4px; font-size: 11px;")
        self.run_btn.clicked.connect(self.run_algorithm)
        self.reset_btn.clicked.connect(self.reset_all)
        btn_layout.addWidget(self.run_btn)
        btn_layout.addWidget(self.reset_btn)
        control_layout.addLayout(btn_layout)

        # 5. 状态提示标签
        self.status_label = qtw.QLabel("就绪 - 配置参数后点击运行", styleSheet="font-size: 11px; margin-top: 10px; color: #666;")
        control_layout.addWidget(self.status_label)

        # 填充剩余空间
        control_layout.addStretch()

        # 右侧可视化区域（占主要空间）
        vis_panel = qtw.QWidget()
        vis_layout = qtw.QVBoxLayout(vis_panel)

        # 图形画布
        vis_layout.addWidget(self.canvas)

        # 迭代信息显示框
        self.info_text = qtw.QTextEdit()
        self.info_text.setReadOnly(True)
        self.info_text.setFixedHeight(120)
        self.info_text.setStyleSheet("font-size: 11px; padding: 10px;")
        vis_layout.addWidget(self.info_text)

        # 加入主布局
        main_layout.addWidget(control_panel)
        main_layout.addWidget(vis_panel, 1)

        self.setCentralWidget(main_widget)

    def init_figure(self):
        """初始化图形画布（3D曲面图 + 2D等高线图）"""
        self.fig = plt.figure(figsize=(9, 6), facecolor='white')
        self.canvas = FigureCanvas(self.fig)

        # 初始绘制空图（验证渲染）
        self.ax3d = self.fig.add_subplot(121, projection='3d')
        self.ax_contour = self.fig.add_subplot(122)

        # 空图网格
        x_range = np.linspace(-3, 3, 50)
        y_range = np.linspace(-3, 3, 50)
        X, Y = np.meshgrid(x_range, y_range)
        Z = np.zeros_like(X)

        # 3D空图
        self.ax3d.plot_surface(X, Y, Z, cmap='viridis', alpha=0.1)
        self.ax3d.set_xlabel('X 轴', fontsize=10)
        self.ax3d.set_ylabel('Y 轴', fontsize=10)
        self.ax3d.set_zlabel('f(X,Y) 函数值', fontsize=10)
        self.ax3d.set_title('函数3D曲面视图', fontsize=11)

        # 2D等高线空图
        contour = self.ax_contour.contourf(X, Y, Z, 20, cmap='viridis', alpha=0.1)
        self.fig.colorbar(contour, ax=self.ax_contour, shrink=0.8)
        self.ax_contour.set_xlabel('X 轴', fontsize=10)
        self.ax_contour.set_ylabel('Y 轴', fontsize=10)
        self.ax_contour.set_title('函数等高线视图', fontsize=11)

        self.canvas.draw()

    def on_algo_change(self):
        """算法切换时的处理（牛顿法隐藏学习率）"""
        for algo_name, btn in self.algo_btns.items():
            if btn.isChecked():
                self.selected_algo = algo_name
                self.lr_input.setEnabled(algo_name != "牛顿法")  # 牛顿法无需学习率
                break

    def get_target_func(self):
        """返回选中的目标函数、梯度函数、Hessian矩阵函数"""
        if self.func_btns["二次函数"].isChecked():
            # 二次函数：f(x,y) = x² + 2y²（凸函数，最优解(0,0)）
            def func(x):
                return x[0]**2 + 2 * x[1]**2

            def grad(x):
                return np.array([2*x[0], 4*x[1]])  # 梯度

            def hess(x):
                return np.array([[2, 0], [0, 4]])  # Hessian矩阵（常数）

        elif self.func_btns["Rosenbrock"].isChecked():
            # Rosenbrock函数：f(x,y) = (1-x)² + 100(y-x²)²（非凸，最优解(1,1)）
            def func(x):
                return (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2

            def grad(x):
                df_dx = -2*(1 - x[0]) - 400*x[0]*(x[1] - x[0]**2)
                df_dy = 200*(x[1] - x[0]**2)
                return np.array([df_dx, df_dy])

            def hess(x):
                d2f_dx2 = 2 - 400*(x[1] - x[0]**2) + 800*x[0]**2
                d2f_dy2 = 200
                d2f_dxdy = -400*x[0]
                return np.array([[d2f_dx2, d2f_dxdy], [d2f_dxdy, d2f_dy2]])

        else:
            # 自定义函数：f(x,y) = x² + y² + sin(x) + cos(y)（凸函数）
            def func(x):
                return x[0]**2 + x[1]**2 + np.sin(x[0]) + np.cos(x[1])

            def grad(x):
                return np.array([2*x[0] + np.cos(x[0]), 2*x[1] - np.sin(x[1])])

            def hess(x):
                return np.array([[2 - np.sin(x[0]), 0], [0, 2 - np.cos(x[1])]])

        return func, grad, hess

    # ---------------------- 三种核心优化算法实现 ----------------------
    def steepest_descent(self, func, grad, x0, lr, max_iter, tol):
        """最速下降法（梯度下降）：沿负梯度方向更新"""
        x = x0.copy()
        history = [x.copy()]
        f_vals = [func(x)]

        for i in range(max_iter):
            g = grad(x)
            if np.linalg.norm(g) < tol:  # 梯度模长小于容差，收敛
                break
            x -= lr * g  # 负梯度方向更新
            history.append(x.copy())
            f_vals.append(func(x))

        return np.array(history), np.array(f_vals)

    def newton_method(self, func, grad, hess, x0, max_iter, tol):
        """牛顿法：利用二阶信息（Hessian矩阵）加速收敛"""
        x = x0.copy()
        history = [x.copy()]
        f_vals = [func(x)]

        for i in range(max_iter):
            g = grad(x)
            if np.linalg.norm(g) < tol:  # 收敛条件
                break
            H = hess(x)  # Hessian矩阵
            # 正则化避免奇异矩阵
            try:
                H_inv = np.linalg.inv(H)
            except np.linalg.LinAlgError:
                H_inv = np.linalg.inv(H + 1e-6 * np.eye(2))
            x -= H_inv @ g  # 牛顿方向更新
            history.append(x.copy())
            f_vals.append(func(x))

        return np.array(history), np.array(f_vals)

    def conjugate_gradient(self, func, grad, x0, lr, max_iter, tol):
        """共轭梯度法：介于最速下降和牛顿法之间，无需Hessian矩阵存储"""
        x = x0.copy()
        history = [x.copy()]
        f_vals = [func(x)]

        g = grad(x)
        d = -g  # 初始方向为负梯度

        for i in range(max_iter):
            if np.linalg.norm(g) < tol:
                break
            x += lr * d  # 沿共轭方向更新
            history.append(x.copy())
            f_vals.append(func(x))

            g_new = grad(x)
            # Fletcher-Reeves公式计算β
            beta = np.dot(g_new, g_new) / (np.dot(g, g) + 1e-10)  # 加小值避免除零
            d = -g_new + beta * d  # 更新共轭方向
            g = g_new.copy()

        return np.array(history), np.array(f_vals)

    # -------------------------------------------------------------------

    def run_algorithm(self):
        """运行选中的算法并可视化结果"""
        try:
            # 读取用户输入的参数
            self.init_point = np.array([
                float(self.x0_input.text()),
                float(self.y0_input.text())
            ])
            self.lr = float(self.lr_input.text())
            self.max_iter = int(self.iter_input.text())
            self.tol = float(self.tol_input.text())

            # 获取目标函数、梯度、Hessian
            func, grad, hess = self.get_target_func()

            # 运行对应的算法
            self.status_label.setText(f"⏳ 正在运行 {self.selected_algo}...")
            qtw.QApplication.processEvents()  # 实时更新UI

            if self.selected_algo == "最速下降法":
                self.iter_history, self.func_values = self.steepest_descent(
                    func, grad, self.init_point, self.lr, self.max_iter, self.tol
                )
            elif self.selected_algo == "牛顿法":
                self.iter_history, self.func_values = self.newton_method(
                    func, grad, hess, self.init_point, self.max_iter, self.tol
                )
            else:  # 共轭梯度法
                self.iter_history, self.func_values = self.conjugate_gradient(
                    func, grad, self.init_point, self.lr, self.max_iter, self.tol
                )

            # 更新UI和可视化
            self.status_label.setText(f"✅ {self.selected_algo}完成！迭代次数：{len(self.iter_history)-1}")
            self.update_iter_info()
            self.visualize_results(func)

        except ValueError:
            self.status_label.setText("❌ 错误：参数输入非法（