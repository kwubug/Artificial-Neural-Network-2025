#!/usr/bin/env python3
"""
牛顿法MLP训练效果详细测试
"""

import numpy as np
from nn_sandbox.backend.algorithms.newton_mlp_algorithm import NewtonMlpAlgorithm

def test_newton_vs_gradient():
    """比较牛顿法和梯度下降的训练效果"""
    print("=== 牛顿法 vs 梯度下降训练效果比较 ===")
    
    # 创建简单的XOR数据集
    dataset = np.array([
        [0, 0, 0],
        [0, 1, 1], 
        [1, 0, 1],
        [1, 1, 0]
    ])
    
    # 测试牛顿法
    print("\n1. 牛顿法MLP训练:")
    newton_mlp = NewtonMlpAlgorithm(
        dataset=dataset,
        total_epoches=50,
        network_shape=(4,),
        activation_function='sigmoid',
        newton_update_frequency=5,  # 每5次迭代使用一次牛顿法
        initial_learning_rate=0.5
    )
    
    # 记录训练过程
    newton_losses = []
    for epoch in range(50):
        newton_mlp._iterate()
        if epoch % 10 == 0:
            loss = newton_mlp._correct_rate(dataset)
            newton_losses.append(loss)
            print(f"  轮次 {epoch}: 正确率 = {loss:.4f}")
    
    # 测试纯梯度下降
    print("\n2. 纯梯度下降MLP训练:")
    gradient_mlp = NewtonMlpAlgorithm(
        dataset=dataset,
        total_epoches=50,
        network_shape=(4,),
        activation_function='sigmoid',
        newton_update_frequency=1000,  # 设置很大，基本不使用牛顿法
        initial_learning_rate=0.5
    )
    
    gradient_losses = []
    for epoch in range(50):
        gradient_mlp._iterate()
        if epoch % 10 == 0:
            loss = gradient_mlp._correct_rate(dataset)
            gradient_losses.append(loss)
            print(f"  轮次 {epoch}: 正确率 = {loss:.4f}")
    
    # 比较结果
    print("\n=== 训练结果比较 ===")
    print("轮次\t牛顿法\t梯度下降")
    for i in range(len(newton_losses)):
        print(f"{i*10}\t{newton_losses[i]:.4f}\t{gradient_losses[i]:.4f}")
    
    # 最终正确率
    final_newton = newton_mlp._correct_rate(dataset)
    final_gradient = gradient_mlp._correct_rate(dataset)
    print(f"\n最终正确率:")
    print(f"牛顿法: {final_newton:.4f}")
    print(f"梯度下降: {final_gradient:.4f}")

def debug_newton_update():
    """调试牛顿法权重更新过程"""
    print("\n=== 牛顿法权重更新调试 ===")
    
    dataset = np.array([[0, 1, 1]])
    mlp = NewtonMlpAlgorithm(
        dataset=dataset,
        network_shape=(2,),
        newton_update_frequency=1  # 每次都使用牛顿法
    )
    
    # 初始化权重
    mlp._initialize_neurons()
    
    print("初始权重:")
    for i, layer in enumerate(mlp._neurons):
        for j, neuron in enumerate(layer):
            print(f"层{i}神经元{j}: {neuron.synaptic_weight}")
    
    # 执行一次牛顿法更新
    mlp.current_data = dataset[0]
    result = mlp._feed_forward(dataset[0][:-1])
    print(f"前向传播结果: {result}")
    
    deltas = mlp._pass_backward(mlp._normalize(dataset[0][-1]), result)
    mlp._compute_gradients(deltas)
    
    print("梯度计算完成")
    mlp._adjust_weights_with_newton()
    print("牛顿法权重更新完成")
    
    print("更新后权重:")
    for i, layer in enumerate(mlp._neurons):
        for j, neuron in enumerate(layer):
            print(f"层{i}神经元{j}: {neuron.synaptic_weight}")

if __name__ == "__main__":
    test_newton_vs_gradient()
    debug_newton_update()