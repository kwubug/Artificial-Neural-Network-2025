import numpy as np


class BpNeuron:
    def __init__(self, input_size):
        # 权重包括偏置项，所以是 input_size + 1
        self._weights = np.random.uniform(-1, 1, input_size + 1)
        self._last_input = None
        self._last_output = None

    @property
    def weights(self):
        return self._weights

    @weights.setter
    def weights(self, value):
        self._weights = np.array(value)

    def forward_pass(self, inputs):
        """前向传播计算"""
        # 添加偏置项
        inputs_with_bias = np.insert(inputs, 0, 1)
        self._last_input = inputs_with_bias
        net_input = np.dot(self._weights, inputs_with_bias)
        self._last_output = self._sigmoid(net_input)
        return self._last_output

    def _sigmoid(self, x):
        return 1 / (1 + np.exp(-np.clip(x, -250, 250)))

    def get_last_input(self):
        """获取最后一次的输入（用于反向传播）"""
        return self._last_input

    def get_last_output(self):
        """获取最后一次的输出"""
        return self._last_output