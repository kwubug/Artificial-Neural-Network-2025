import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# ---------- 定义目标函数 ----------
def f(x, y):
    """目标函数 f(x,y) = x^2 + 2y^2"""
    return x**2 + 2*y**2

def grad_f(x, y):
    """梯度"""
    return np.array([2*x, 4*y])

# ---------- 最速下降法 ----------
class SteepestDescent:
    def __init__(self, start_point, learning_rate=0.1, tol=1e-6, max_iter=50):
        self.point = np.array(start_point, dtype=float)
        self.learning_rate = learning_rate
        self.tol = tol
        self.max_iter = max_iter
        self.path = [self.point.copy()]

    def step(self):
        grad = grad_f(*self.point)
        if np.linalg.norm(grad) < self.tol:
            return False  # 收敛
        # 最速下降法：沿梯度方向负方向更新
        self.point -= self.learning_rate * grad
        self.path.append(self.point.copy())
        return True

    def run(self):
        for _ in range(self.max_iter):
            if not self.step():
                break
        return np.array(self.path)

# ---------- 可视化 ----------
start = [-3, 4]
sd = SteepestDescent(start_point=start, learning_rate=0.1, max_iter=30)
path = sd.run()

# 绘制等高线
x = np.linspace(-4, 4, 100)
y = np.linspace(-4, 4, 100)
X, Y = np.meshgrid(x, y)
Z = f(X, Y)

fig, ax = plt.subplots(figsize=(6, 6))
ax.contour(X, Y, Z, levels=30, cmap='viridis')
point_plot, = ax.plot([], [], 'ro-', lw=2)

def init():
    point_plot.set_data([], [])
    return point_plot,

def update(frame):
    point_plot.set_data(path[:frame+1, 0], path[:frame+1, 1])
    return point_plot,

ani = FuncAnimation(fig, update, frames=len(path), init_func=init, blit=True, interval=500)
plt.xlabel('x')
plt.ylabel('y')
plt.title('Steepest Descent Visualization')
plt.show()
