from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget
from nn_sandbox.bridges.TSPBridgeSimple import TSPBridgeSimple
import sys

class TSPMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neural Network Sandbox - TSP 可视化")

        # 主容器
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # 可视化组件
        self.tsp_widget = TSPBridgeSimple(self)
        layout.addWidget(self.tsp_widget)

        # “随机生成”按钮
        self.refresh_btn = QPushButton("🔁 随机生成城市并求解")
        self.refresh_btn.clicked.connect(self.on_refresh)
        layout.addWidget(self.refresh_btn)

        # 初次生成
        self.tsp_widget.refresh()

    def on_refresh(self):
        self.tsp_widget.refresh()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = TSPMainWindow()
    win.resize(600, 650)
    win.show()
    sys.exit(app.exec_())


