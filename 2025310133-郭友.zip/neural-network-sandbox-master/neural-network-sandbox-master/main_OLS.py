from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QComboBox
from nn_sandbox.bridges.OLSVisualizer import OLSVisualizer
import sys

class OLSMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neural Network Sandbox - OLS 可视化")

        # 主容器
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # OLS可视化组件
        self.ols_widget = OLSVisualizer(self)
        layout.addWidget(self.ols_widget)

        # 多项式阶数选择下拉框
        self.degree_combo = QComboBox()
        self.degree_combo.addItems([str(i) for i in range(1, 6)])  # 1~5阶
        layout.addWidget(self.degree_combo)

        # 按钮
        self.refresh_btn = QPushButton("🔁 随机生成数据并拟合")
        self.refresh_btn.clicked.connect(self.on_refresh)
        layout.addWidget(self.refresh_btn)

        self.ols_widget.refresh(degree=2)

    def on_refresh(self):
        degree = int(self.degree_combo.currentText())
        self.ols_widget.refresh(degree=degree)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = OLSMainWindow()
    win.resize(600, 650)
    win.show()
    sys.exit(app.exec_())
