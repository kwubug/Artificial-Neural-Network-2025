import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3
import '..'

Page {
    id: root
    name: "Hopfield"

    readonly property var patternLibrary: [
        {
            name: "X",
            data: [
                1, -1, -1, -1, 1,
                -1, 1, -1, 1, -1,
                -1, -1, 1, -1, -1,
                -1, 1, -1, 1, -1,
                1, -1, -1, -1, 1
            ]
        },
        {
            name: "O",
            data: [
                1, 1, 1, 1, 1,
                1, -1, -1, -1, 1,
                1, -1, -1, -1, 1,
                1, -1, -1, -1, 1,
                1, 1, 1, 1, 1
            ]
        },
        {
            name: "L",
            data: [
                1, -1, -1, -1, -1,
                1, -1, -1, -1, -1,
                1, -1, -1, -1, -1,
                1, -1, -1, -1, -1,
                1, 1, 1, 1, 1
            ]
        }
    ]
    GridLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        columns: 2
        columnSpacing: 16
        rowSpacing: 16

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true

            GroupBox {
                title: "Network Controls"
                Layout.fillWidth: true

                ColumnLayout {
                    spacing: 12

                    ComboBox {
                        id: patternSelector
                        Layout.fillWidth: true
                        textRole: "name"
                        model: patternLibrary
                    }

                    Button {
                        text: "Train With Samples"
                        Layout.fillWidth: true
                        onClicked: {
                            hopfieldBridge.train(patternLibrary.map(p => p.data))
                        }
                    }

                    Button {
                        text: "Run Selected Pattern"
                        Layout.fillWidth: true
                        onClicked: {
                            if (patternSelector.currentIndex >= 0) {
                                hopfieldBridge.run_async_update(patternLibrary[patternSelector.currentIndex].data, 200)
                            }
                        }
                    }

                    Button {
                        text: "Run Noisy Pattern"
                        Layout.fillWidth: true
                        onClicked: {
                            if (patternSelector.currentIndex >= 0) {
                                let base = patternLibrary[patternSelector.currentIndex].data
                                let noisy = base.map(value => Math.random() < 0.2 ? -value : value)
                                hopfieldBridge.run_async_update(noisy, 200)
                            }
                        }
                    }

                    Button {
                        text: "Clear Current State"
                        Layout.fillWidth: true
                        onClicked: hopfieldBridge.reset()
                    }
                }
            }

            GroupBox {
                title: "Status"
                Layout.fillWidth: true

                ColumnLayout {
                    Label {
                        text: hopfieldBridge.status
                        wrapMode: Text.WordWrap
                    }
                    Label {
                        text: "Energy: " + hopfieldBridge.energy.toFixed(4)
                    }
                    Label {
                        text: hopfieldBridge.isTrained ? "Stored patterns: " + hopfieldBridge.patterns.length : "Network not trained"
                    }
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 16

            GroupBox {
                title: "Current State"
                Layout.fillWidth: true
                Layout.fillHeight: true

                Grid {
                    id: stateGrid
                    property int side: hopfieldBridge.currentState.length > 0 ? Math.round(Math.sqrt(hopfieldBridge.currentState.length)) : 0
                    columns: side > 0 ? side : 1
                    spacing: 2

                    Repeater {
                        model: hopfieldBridge.currentState.length
                        Rectangle {
                            width: 24
                            height: 24
                            color: hopfieldBridge.currentState[index] === 1 ? "#202020" : "white"
                            border.color: "#808080"
                        }
                    }
                }
            }

            GroupBox {
                title: "Attractor"
                Layout.fillWidth: true
                Layout.fillHeight: true

                Grid {
                    id: attractorGrid
                    property int side: hopfieldBridge.attractor.length > 0 ? Math.round(Math.sqrt(hopfieldBridge.attractor.length)) : 0
                    columns: side > 0 ? side : 1
                    spacing: 2

                    Repeater {
                        model: hopfieldBridge.attractor.length
                        Rectangle {
                            width: 24
                            height: 24
                            color: hopfieldBridge.attractor[index] === 1 ? "#202020" : "white"
                            border.color: "#808080"
                        }
                    }
                }
            }
        }
    }
}
