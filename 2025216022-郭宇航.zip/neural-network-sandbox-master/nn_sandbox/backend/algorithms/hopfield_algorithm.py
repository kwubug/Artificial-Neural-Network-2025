import copy
import threading

import numpy as np

from . import TraningAlgorithm


class HopfieldAlgorithm(TraningAlgorithm):
    """
    Hopfield 神经网络 - 关联记忆网络
    用于存储和检索关联模式
    """

    def __init__(self, num_neurons=100, ui_refresh_interval=0.0):
        """
        初始化 Hopfield 网络
        
        Args:
            num_neurons: 神经元数量
            ui_refresh_interval: UI 刷新间隔（用于防止 UI 阻塞）
        """
        # 不调用父类 __init__，因为 Hopfield 不需要 dataset
        threading.Thread.__init__(self)
        
        self._num_neurons = num_neurons
        self._weights = np.zeros((num_neurons, num_neurons))
        self._patterns = []
        self._current_state = np.zeros(num_neurons)
        self._energy = 0.0
        self._iteration = 0
        self._converged = False
        self._state_history = []
        self._similarity = 0.0
        self._should_stop = False
        self.ui_refresh_interval = ui_refresh_interval
        
        # 用于跟踪训练进度
        self._pattern_count = 0
        self._retrieval_in_progress = False

    def store_pattern(self, pattern):
        """
        使用 Hebb 规则存储一个模式
        
        Args:
            pattern: numpy array，形状为 (num_neurons,)，值为 ±1
        """
        if len(pattern) != self._num_neurons:
            raise ValueError(
                f"Pattern size {len(pattern)} != {self._num_neurons}"
            )
        
        pattern = np.array(pattern, dtype=np.float64)
        # 确保值为 ±1
        pattern = np.sign(pattern)
        pattern[pattern == 0] = 1
        
        self._patterns.append(pattern.copy())
        
        # Hebb 学习规则: W = W + pattern * pattern^T
        # 对角线为 0（无自连接）
        self._weights += np.outer(pattern, pattern)
        np.fill_diagonal(self._weights, 0)
        
        self._pattern_count = len(self._patterns)

    def clear_patterns(self):
        """清空所有存储的模式"""
        self._patterns = []
        self._weights = np.zeros((self._num_neurons, self._num_neurons))
        self._current_state = np.zeros(self._num_neurons)
        self._state_history = []
        self._pattern_count = 0
        self._iteration = 0
        self._converged = False
        self._energy = 0.0
        self._similarity = 0.0

    def set_initial_state(self, state):
        """
        设置初始状态（通常是一个带噪声的模式）
        
        Args:
            state: numpy array，值为 ±1
        """
        state = np.array(state, dtype=np.float64)
        if len(state) != self._num_neurons:
            raise ValueError(f"State size {len(state)} != {self._num_neurons}")
        
        # 确保值为 ±1
        state = np.sign(state)
        state[state == 0] = 1
        
        self._current_state = state.copy()
        self._state_history = [state.copy()]
        self._iteration = 0
        self._converged = False
        self._energy = self._calculate_energy()

    def _calculate_energy(self):
        """计算 Hopfield 网络能量函数"""
        # E = -0.5 * s^T * W * s
        energy = -0.5 * np.dot(
            self._current_state,
            np.dot(self._weights, self._current_state)
        )
        return float(energy)

    def _calculate_similarity(self):
        """计算与存储模式的最大相似度"""
        if len(self._patterns) == 0:
            return 0.0
        
        similarities = [
            np.dot(self._current_state, p) / self._num_neurons
            for p in self._patterns
        ]
        return float(max(similarities))

    def _update_neuron_sync(self):
        """同步更新所有神经元"""
        new_state = np.zeros(self._num_neurons)
        for i in range(self._num_neurons):
            net_input = np.dot(self._weights[i], self._current_state)
            new_state[i] = 1.0 if net_input >= 0 else -1.0
        return new_state

    def _update_neuron_async(self):
        """异步更新所有神经元"""
        for i in range(self._num_neurons):
            net_input = np.dot(self._weights[i], self._current_state)
            self._current_state[i] = 1.0 if net_input >= 0 else -1.0

    def step(self, update_rule='async'):
        """
        执行一步更新
        
        Args:
            update_rule: 'sync' (同步) 或 'async' (异步)
        """
        old_state = self._current_state.copy()
        
        if update_rule == 'sync':
            self._current_state = self._update_neuron_sync()
        else:
            self._update_neuron_async()
        
        self._iteration += 1
        self._energy = self._calculate_energy()
        self._similarity = self._calculate_similarity()
        self._state_history.append(self._current_state.copy())
        
        # 检查收敛（状态不再改变）
        if np.array_equal(old_state, self._current_state):
            self._converged = True

    def retrieve(self, max_iterations=1000, update_rule='async'):
        """
        检索过程：迭代更新直到收敛
        
        Args:
            max_iterations: 最大迭代次数
            update_rule: 'sync' 或 'async'
        """
        self._retrieval_in_progress = True
        for _ in range(max_iterations):
            if self._should_stop or self._converged:
                break
            self.step(update_rule=update_rule)
        self._retrieval_in_progress = False

    def add_noise(self, noise_rate=0.1):
        """
        向当前状态添加噪声
        
        Args:
            noise_rate: 翻转的神经元比例 (0.0 ~ 1.0)
        """
        num_flips = int(self._num_neurons * noise_rate)
        if num_flips > 0:
            flip_indices = np.random.choice(
                self._num_neurons, num_flips, replace=False
            )
            self._current_state[flip_indices] *= -1
            self._energy = self._calculate_energy()
            self._similarity = self._calculate_similarity()

    def calculate_capacity(self):
        """
        计算网络理论容量
        容量约为 N / (2 * ln(N))，N 为神经元数
        """
        import math
        if self._num_neurons <= 1:
            return 0
        return int(self._num_neurons / (2 * math.log(self._num_neurons + 1)))

    def run(self):
        """Thread 的 run 方法 - 目前未使用"""
        pass

    def stop(self):
        """停止运行"""
        self._should_stop = True

    # 数据访问接口
    def get_state_vector(self):
        """获取当前状态向量"""
        return self._current_state.tolist()

    def get_weights_matrix(self):
        """获取权重矩阵"""
        return self._weights.tolist()

    def get_patterns(self):
        """获取所有存储的模式"""
        return [p.tolist() for p in self._patterns]

    def get_state_history(self):
        """获取状态演化历史"""
        return [s.tolist() for s in self._state_history]
