import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.linear_model import LinearRegression

plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False 

class OLSVisualizer:
    def __init__(self):
        self.X = None
        self.y = None
        self.theta0 = None  # 截距
        self.theta1 = None  # 斜率
        self.figures = []   # 存储所有图像对象

    def generate_data(self, n=100, seed=42):
        """生成模拟数据：y = 2x + 5 + 高斯噪声"""
        np.random.seed(seed)
        self.X = np.linspace(0, 10, n).reshape(-1, 1)  # 转换为二维数组（适合sklearn输入）
        self.y = 2 * self.X.flatten() + 5 + np.random.normal(0, 1.5, n)  # 真实模型+噪声
        return self

    def ols_solution(self):
        """手动实现OLS计算：计算最优截距和斜率"""
        if self.X is None or self.y is None:
            raise ValueError("请先调用generate_data生成数据")
        
        X_flat = self.X.flatten()  # 转换为一维数组便于计算
        x_mean = np.mean(X_flat)
        y_mean = np.mean(self.y)
        
        # 计算斜率theta1：协方差/方差
        numerator = np.sum((X_flat - x_mean) * (self.y - y_mean))
        denominator = np.sum((X_flat - x_mean) **2)
        self.theta1 = numerator / denominator
        
        # 计算截距theta0
        self.theta0 = y_mean - self.theta1 * x_mean
        return self

    def plot_data(self):
        """可视化1：原始数据分布"""
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.scatter(self.X, self.y, color='blue', alpha=0.7, label='原始数据')
        ax.set_xlabel('X值')
        ax.set_ylabel('Y值')
        ax.set_title('原始数据分布')
        ax.legend()
        ax.grid(True, linestyle='--', alpha=0.5)
        self.figures.append(fig)  # 保存图像对象
        return self

    def plot_fitting_result(self):
        """可视化2：OLS拟合结果（含残差）"""
        if self.theta0 is None or self.theta1 is None:
            raise ValueError("请先调用ols_solution计算参数")
        
        fig, ax = plt.subplots(figsize=(8, 6))
        X_flat = self.X.flatten()
        y_pred = self.theta0 + self.theta1 * X_flat  # 预测值
        
        # 绘制原始数据和拟合直线
        ax.scatter(X_flat, self.y, color='blue', alpha=0.7, label='原始数据')
        ax.plot(X_flat, y_pred, color='red', linewidth=2, label=f'拟合直线: y = {self.theta1:.4f}x + {self.theta0:.4f}')
        
        # 绘制残差（数据点到拟合直线的垂线）
        for x, y, yp in zip(X_flat, self.y, y_pred):
            ax.plot([x, x], [y, yp], color='black', linestyle='--', linewidth=1, alpha=0.5)
        
        ax.set_xlabel('X值')
        ax.set_ylabel('Y值')
        ax.set_title('OLS线性回归拟合结果（黑色虚线为残差）')
        ax.legend()
        ax.grid(True, linestyle='--', alpha=0.5)
        self.figures.append(fig)
        return self

    def plot_cost_function(self):
        """可视化3：代价函数（残差平方和）的3D曲面与等高线"""
        if self.theta0 is None or self.theta1 is None:
            raise ValueError("请先调用ols_solution计算参数")
        
        X_flat = self.X.flatten()
        
        # 生成参数网格（围绕最优解的范围）
        theta0_range = np.linspace(self.theta0 - 3, self.theta0 + 3, 100)
        theta1_range = np.linspace(self.theta1 - 1, self.theta1 + 1, 100)
        theta0_grid, theta1_grid = np.meshgrid(theta0_range, theta1_range)
        
        # 计算每个参数组合的代价（残差平方和）
        cost = np.zeros_like(theta0_grid)
        for i in range(theta0_grid.shape[0]):
            for j in range(theta0_grid.shape[1]):
                y_pred = theta0_grid[i, j] + theta1_grid[i, j] * X_flat
                cost[i, j] = np.sum((self.y - y_pred)** 2)
        
        # 创建2x1子图（3D曲面 + 等高线）
        fig = plt.figure(figsize=(14, 6))
        
        # 左侧：3D代价曲面
        ax1 = fig.add_subplot(121, projection='3d')
        surf = ax1.plot_surface(theta0_grid, theta1_grid, cost, cmap='viridis', alpha=0.8)
        ax1.scatter([self.theta0], [self.theta1], [np.min(cost)], color='red', s=100, marker='*', label='最优解')
        ax1.set_xlabel('截距 (θ₀)')
        ax1.set_ylabel('斜率 (θ₁)')
        ax1.set_zlabel('代价（残差平方和）')
        ax1.set_title('代价函数3D曲面')
        ax1.legend()
        fig.colorbar(surf, ax=ax1, shrink=0.5, aspect=5)
        
        # 右侧：等高线图
        ax2 = fig.add_subplot(122)
        contour = ax2.contourf(theta0_grid, theta1_grid, cost, levels=20, cmap='viridis', alpha=0.7)
        ax2.scatter([self.theta0], [self.theta1], color='red', s=100, marker='*', label='最优解')
        ax2.set_xlabel('截距 (θ₀)')
        ax2.set_ylabel('斜率 (θ₁)')
        ax2.set_title('代价函数等高线')
        ax2.legend()
        fig.colorbar(contour, ax=ax2, shrink=0.5, aspect=5)
        
        plt.tight_layout()
        self.figures.append(fig)
        return self

    def compare_with_sklearn(self):
        """与sklearn的LinearRegression对比（验证手动实现正确性）"""
        model = LinearRegression()
        model.fit(self.X, self.y)
        sk_theta1 = model.coef_[0]  # sklearn计算的斜率
        sk_theta0 = model.intercept_  # sklearn计算的截距
        
        print("手动实现OLS参数：")
        print(f"截距 (θ₀) = {self.theta0:.6f}")
        print(f"斜率 (θ₁) = {self.theta1:.6f}\n")
        
        print("sklearn的LinearRegression参数：")
        print(f"截距 (θ₀) = {sk_theta0:.6f}")
        print(f"斜率 (θ₁) = {sk_theta1:.6f}\n")
        
        print(f"参数差异（绝对值）：")
        print(f"截距差异 = {abs(self.theta0 - sk_theta0):.10f}")
        print(f"斜率差异 = {abs(self.theta1 - sk_theta1):.10f}")
        return self

    def show_all_figures(self):
        """显示所有保存的图像"""
        plt.show()


if __name__ == "__main__":
    # 执行流程：生成数据 → 计算OLS → 绘制可视化 → 对比验证
    ols_viz = OLSVisualizer()
    (ols_viz.generate_data(n=100)
            .ols_solution()
            .plot_data()
            .plot_fitting_result()
            .plot_cost_function()
            .compare_with_sklearn()
            .show_all_figures())