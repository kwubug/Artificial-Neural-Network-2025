# PyQt5 DLL 加载失败修复指南

## 问题描述
在 Windows 系统上运行程序时出现错误：
```
ImportError: DLL load failed while importing QtWidgets: 找不到指定的程序。
```

## 解决方案

### 方案 1：重新安装 PyQt5（推荐）

1. **使用修复脚本**（最简单）：
   ```bash
   # 双击运行或在命令行执行
   fix_pyqt5.bat
   ```

2. **手动执行**：
   ```bash
   pip uninstall PyQt5 PyQt5-Qt5 PyQt5-sip -y
   pip cache purge
   pip install PyQt5==5.15.11
   ```

### 方案 2：安装 Visual C++ 运行时库

PyQt5 需要 Visual C++ 运行时库支持。请下载并安装：

- **64位系统**：https://aka.ms/vs/17/release/vc_redist.x64.exe
- **32位系统**：https://aka.ms/vs/17/release/vc_redist.x86.exe

### 方案 3：使用 PySide2 替代（兼容方案）

PySide2 是 Qt 的官方 Python 绑定，与 PyQt5 API 兼容：

1. **安装 PySide2**：
   ```bash
   pip uninstall PyQt5 -y
   pip install PySide2
   ```

2. **自动转换脚本**：
   ```bash
   python fix_pyqt5_alternative.py
   ```
   这会创建一个使用 PySide2 的新文件 `tsp_visualizer_pyside2.py`

3. **手动修改**：
   将代码中所有的 `PyQt5` 替换为 `PySide2`：
   ```python
   # 原代码
   from PyQt5.QtWidgets import ...
   
   # 修改为
   from PySide2.QtWidgets import ...
   ```

### 方案 4：使用 conda 环境（如果使用 Anaconda）

```bash
conda install pyqt=5.15.11
```

## 验证安装

运行以下命令测试 PyQt5 是否正常工作：

```python
python -c "from PyQt5.QtWidgets import QApplication; print('PyQt5 安装成功！')"
```

如果成功，会显示 "PyQt5 安装成功！"

## 常见问题

### Q: 为什么会出现 DLL 加载失败？
A: 通常是因为：
- 缺少 Visual C++ 运行时库
- PyQt5 版本与 Python 版本不兼容
- PyQt5 安装不完整或损坏

### Q: 我应该使用哪个版本？
A: 推荐使用 `PyQt5==5.15.11`，这是一个稳定且广泛使用的版本。

### Q: PySide2 和 PyQt5 有什么区别？
A: 
- PyQt5 是第三方绑定，需要商业许可
- PySide2 是 Qt 官方绑定，使用 LGPL 许可
- API 几乎完全相同，可以无缝替换

## 联系支持

如果以上方案都无法解决问题，请检查：
1. Python 版本（推荐 3.8-3.11）
2. 系统架构（32位/64位）
3. 是否有多个 Python 环境冲突

