# main_BM.py
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QComboBox
from nn_sandbox.bridges.BoltzmannVisualizer import BoltzmannVisualizer
import sys

class BMMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neural Network Sandbox - Boltzmann Machine 可视化")

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # BM 可视化组件
        self.bm_widget = BoltzmannVisualizer(n_neurons=3, temperature=1.0)
        layout.addWidget(self.bm_widget)

        # Gibbs 迭代步数选择下拉框
        self.steps_combo = QComboBox()
        self.steps_combo.addItems([str(i) for i in [10, 50, 100, 200]])
        layout.addWidget(self.steps_combo)

        # 按钮
        self.refresh_btn = QPushButton("🔁 随机初始化并运行 BM")
        self.refresh_btn.clicked.connect(self.on_refresh)
        layout.addWidget(self.refresh_btn)

        # 初次绘制
        self.bm_widget.refresh(n_steps=100)

    def on_refresh(self):
        steps = int(self.steps_combo.currentText())
        final_state = self.bm_widget.refresh(n_steps=steps)
        print("Final thermal equilibrium state:", final_state)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = BMMainWindow()
    win.resize(500, 450)
    win.show()
    sys.exit(app.exec_())
