"""BP Neural Network Training Visualization Web App"""
import os
import numpy as np
from dash import Dash, html, dcc, callback_context
from dash.dependencies import Input, Output, State
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash_bootstrap_components.themes import BOOTSTRAP
from layout import entry_layout, viz_layout
from bp_optimizers import BPNeuralNetwork, generate_classification_data, generate_xor_data


app = Dash(external_stylesheets=[BOOTSTRAP], suppress_callback_exceptions=True)
app.title = "BP神经网络训练可视化"

app.layout = html.Div(
    children=[
        html.H1("BP神经网络训练过程可视化", style={"text-align": "center"}),
        html.Hr(),
        dcc.Store(id="params", data={}),
        dcc.Store(id="network_state", data={}),
        dcc.Store(id="store", data={
            "epochs": [],
            "losses": [],
            "weights_w1": [],
            "weights_w2": [],
            "accuracy": [],
        }),
        dcc.Store(id="training_status", data={"is_training": False}),  # 训练状态
        html.Button(
            "开始训练",
            id="submit-button",
            n_clicks=0,
            style={
                "display": "block",
                "margin": "20px auto",
                "padding": "15px 30px",
                "font-size": "18px",
                "background-color": "#2196F3",
                "color": "white",
                "border": "none",
                "border-radius": "5px",
                "cursor": "pointer",
            },
        ),
        html.Div(id="dynamic", children=entry_layout()),
    ],
    style={"padding": "20px"}
)


@app.callback(
    Output("dynamic", "children"),
    Output("submit-button", "style"),
    Input("submit-button", "n_clicks"),
)
def update_layout(n_clicks: int):
    """Changes layout after configuration"""
    if n_clicks > 0:
        return viz_layout(), {"display": "none"}
    else:
        return entry_layout(), {
            "display": "block",
            "margin": "20px auto",
            "padding": "15px 30px",
            "font-size": "18px",
            "background-color": "#2196F3",
            "color": "white",
            "border": "none",
            "border-radius": "5px",
            "cursor": "pointer",
        }


@app.callback(
    Output("params", "data"),
    Output("network_state", "data"),
    State("drop_down_optimizer", "value"),
    State("drop_down_lr", "value"),
    State("slider_hidden", "value"),
    State("drop_down_dataset", "value"),
    State("params", "data"),
    State("network_state", "data"),
    Input("submit-button", "n_clicks"),
)
def capture_data(optimizer: str, lr: float, hidden_size: int, dataset_type: str,
                params: dict, network_state: dict, n_clicks: int):
    """Initialize network and data"""
    
    # 如果还没点击或条件不满足，返回现有值（不改变）
    if not n_clicks or n_clicks == 0:
        return params or {}, network_state or {}
    
    if not (optimizer and lr and hidden_size and dataset_type):
        print("⚠️ 配置参数不完整，跳过初始化")
        return params or {}, network_state or {}
    
    print(f"\n🚀 初始化网络: {optimizer}, lr={lr}, hidden={hidden_size}, dataset={dataset_type}")
    
    # 生成数据集
    if dataset_type == "classification":
        X, y = generate_classification_data(n_samples=100)
    else:
        X, y = generate_xor_data(n_samples=200)
    
    new_params = {
        "optimizer": optimizer,
        "lr": float(lr),
        "hidden_size": int(hidden_size),
        "dataset_type": dataset_type,
        "X": X.tolist(),
        "y": y.tolist(),
        "initialized": True
    }
    
    print(f"📊 数据集生成完成: X shape={X.shape}, y shape={y.shape}")
    
    # 初始化网络
    network = BPNeuralNetwork(
        input_size=2,
        hidden_size=hidden_size,
        output_size=1,
        optimizer=optimizer,
        learning_rate=float(lr)
    )
    
    # 保存网络状态
    new_network_state = {
        "W1": network.W1.tolist(),
        "b1": network.b1.tolist(),
        "W2": network.W2.tolist(),
        "b2": network.b2.tolist(),
        "prev_gradient": None,
        "initialized": True
    }
    
    print(f"✅ 网络初始化完成! W1 shape={network.W1.shape}, W2 shape={network.W2.shape}")
    
    return new_params, new_network_state


# ============= 训练控制 Callbacks =============

@app.callback(
    Output("training_status", "data"),
    Output("training_status", "data", allow_duplicate=True),
    Input("sim-button", "n_clicks"),
    Input("reset-button", "n_clicks"),
    State("training_status", "data"),
    State("params", "data"),
    State("network_state", "data"),
    prevent_initial_call=True,
)
def toggle_training(sim_clicks, reset_clicks, training_status, params, network_state):
    """切换训练状态（开始/暂停/重置时停止）"""
    from dash.exceptions import PreventUpdate
    
    ctx = callback_context
    if not ctx.triggered:
        raise PreventUpdate
    
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    # 处理重置：停止训练
    if trigger_id == "reset-button":
        if reset_clicks is None or reset_clicks == 0:
            raise PreventUpdate
        print("🛑 重置时停止训练")
        return {"is_training": False}, {"is_training": False}
    
    # 处理训练按钮
    if trigger_id == "sim-button":
        if sim_clicks is None or sim_clicks == 0:
            raise PreventUpdate
        
        # 检查是否已初始化
        params_ready = params and params.get("initialized") == True
        network_ready = network_state and network_state.get("initialized") == True
        
        if not params_ready or not network_ready:
            print(f"❌ 网络未初始化，无法开始训练")
            raise PreventUpdate
        
        # 切换训练状态
        current_status = training_status.get("is_training", False)
        new_status = not current_status
        
        if new_status:
            print(f"▶️  开始自动训练（每秒50次迭代）...")
        else:
            print(f"⏸️  暂停训练")
        
        return {"is_training": new_status}, {"is_training": new_status}
    
    raise PreventUpdate


@app.callback(
    Output("training-interval", "disabled"),
    Output("sim-button", "children"),
    Output("sim-button", "style"),
    Input("training_status", "data"),
    prevent_initial_call=True,
)
def update_training_ui(training_status):
    """根据训练状态更新UI"""
    is_training = training_status.get("is_training", False)
    
    if is_training:
        return False, "暂停训练", {
            "display": "inline-block",
            "background-color": "#FF9800",  # 橙色
            "color": "white",
            "padding": "10px 20px",
            "border": "none",
            "border-radius": "4px",
            "cursor": "pointer",
            "font-weight": "bold",
        }
    else:
        return True, "开始训练", {
            "display": "inline-block",
            "background-color": "#4CAF50",  # 绿色
            "color": "white",
            "padding": "10px 20px",
            "border": "none",
            "border-radius": "4px",
            "cursor": "pointer",
            "font-weight": "bold",
        }


@app.callback(
    Output("store", "data"),
    Output("network_state", "data", allow_duplicate=True),
    Input("training-interval", "n_intervals"),
    Input("reset-button", "n_clicks"),
    State("store", "data"),
    State("params", "data"),
    State("network_state", "data"),
    State("training_status", "data"),
    prevent_initial_call=True,
)
def auto_training(n_intervals, reset_clicks, data, params, network_state, training_status):
    """自动训练：每次执行50次迭代"""
    from dash.exceptions import PreventUpdate
    
    ctx = callback_context
    if not ctx.triggered:
        raise PreventUpdate
    
    trigger_id = ctx.triggered[0]["prop_id"].split(".")[0]
    
    # 处理重置按钮
    if trigger_id == "reset-button":
        if reset_clicks is None or reset_clicks == 0:
            raise PreventUpdate
        
        print("\n🔄 重置网络...")
        
        # 重新初始化网络
        if params and params.get("initialized"):
            network = BPNeuralNetwork(
                input_size=2,
                hidden_size=params["hidden_size"],
                output_size=1,
                optimizer=params["optimizer"],
                learning_rate=params["lr"]
            )
            network_state = {
                "W1": network.W1.tolist(),
                "b1": network.b1.tolist(),
                "W2": network.W2.tolist(),
                "b2": network.b2.tolist(),
                "prev_gradient": None,
                "initialized": True
            }
        
        # 清空数据
        data = {
            "epochs": [],
            "losses": [],
            "weights_w1": [],
            "weights_w2": [],
            "accuracy": [],
        }
        
        print("✅ 网络已重置")
        return data, network_state
    
    # 处理自动训练
    if trigger_id == "training-interval":
        # 检查是否正在训练
        if not training_status.get("is_training", False):
            raise PreventUpdate
        
        # 检查初始化状态
        params_ready = params and params.get("initialized") == True
        network_ready = network_state and network_state.get("initialized") == True
        
        if not params_ready or not network_ready:
            raise PreventUpdate
        
        # 初始化data
        if data is None:
            data = {
                "epochs": [],
                "losses": [],
                "weights_w1": [],
                "weights_w2": [],
                "accuracy": [],
            }
        
        # 恢复网络状态
        network = BPNeuralNetwork(
            input_size=2,
            hidden_size=params["hidden_size"],
            output_size=1,
            optimizer=params["optimizer"],
            learning_rate=params["lr"]
        )
        network.W1 = np.array(network_state["W1"], dtype=np.float64)
        network.b1 = np.array(network_state["b1"], dtype=np.float64)
        network.W2 = np.array(network_state["W2"], dtype=np.float64)
        network.b2 = np.array(network_state["b2"], dtype=np.float64)
        if network_state["prev_gradient"] is not None:
            network.prev_gradient = np.array(network_state["prev_gradient"], dtype=np.float64)
        
        # 获取数据
        X = np.array(params["X"])
        y = np.array(params["y"])
        
        # 每次执行50次训练
        n_iters = 50
        for i in range(n_iters):
            loss = network.train_step(X, y)
            
            # 计算准确率
            predictions = network.predict(X)
            accuracy = np.mean((predictions > 0.5) == y)
            
            # 保存历史
            current_epoch = len(data["epochs"])
            data["epochs"].append(current_epoch)
            data["losses"].append(float(loss))
            data["weights_w1"].append(float(network.W1[0, 0]))
            data["weights_w2"].append(float(network.W2[0, 0]))
            data["accuracy"].append(float(accuracy))
        
        # 保存网络状态
        network_state["W1"] = network.W1.tolist()
        network_state["b1"] = network.b1.tolist()
        network_state["W2"] = network.W2.tolist()
        network_state["b2"] = network.b2.tolist()
        network_state["initialized"] = True
        if network.prev_gradient is not None:
            network_state["prev_gradient"] = network.prev_gradient.tolist()
        else:
            network_state["prev_gradient"] = None
        
        # 每10秒打印一次进度
        if n_intervals % 10 == 0:
            print(f"  轮次 {current_epoch}: 损失={loss:.6f}, 准确率={accuracy*100:.2f}%")
    
    return data, network_state


def compute_loss_surface(X, y, network, w1_range, w2_range, grid_size=50):
    """计算损失函数在W1[0,0]和W2[0,0]平面上的曲面"""
    w1_vals = np.linspace(w1_range[0], w1_range[1], grid_size)
    w2_vals = np.linspace(w2_range[0], w2_range[1], grid_size)
    
    W1_grid, W2_grid = np.meshgrid(w1_vals, w2_vals)
    loss_grid = np.zeros_like(W1_grid)
    
    # 保存原始权重
    orig_w1_00 = network.W1[0, 0]
    orig_w2_00 = network.W2[0, 0]
    
    # 计算每个网格点的损失
    for i in range(grid_size):
        for j in range(grid_size):
            network.W1[0, 0] = W1_grid[i, j]
            network.W2[0, 0] = W2_grid[i, j]
            
            # 前向传播计算损失
            predictions = network.predict(X)
            loss = np.mean((predictions - y) ** 2)
            loss_grid[i, j] = loss
    
    # 恢复原始权重
    network.W1[0, 0] = orig_w1_00
    network.W2[0, 0] = orig_w2_00
    
    return W1_grid, W2_grid, loss_grid


@app.callback(
    Output("training-info", "children"),
    Output("data-scatter", "figure"),
    Output("decision-boundary", "figure"),
    Output("loss-curve", "figure"),
    Output("weight-trajectory", "figure"),
    Input("store", "data"),
    State("params", "data"),
    State("network_state", "data"),
)
def update_visualizations(data: dict, params: dict, network_state: dict):
    """Update all visualizations"""
    
    # 训练信息
    if data and len(data.get("epochs", [])) > 0:
        current_epoch = data["epochs"][-1]
        current_loss = data["losses"][-1]
        current_acc = data["accuracy"][-1]
        info_text = html.Div([
            html.Span(f"轮次: {current_epoch} | ", style={"font-weight": "bold"}),
            html.Span(f"损失: {current_loss:.6f} | ", style={"color": "#f44336"}),
            html.Span(f"准确率: {current_acc*100:.2f}%", style={"color": "#4CAF50"}),
        ])
    else:
        info_text = "点击'训练'按钮开始训练..."
    
    # 数据散点图
    if not params or "X" not in params:
        # 如果还没有初始化数据，返回空图表
        empty_fig = go.Figure()
        empty_fig.update_layout(title="等待配置...")
        return info_text, empty_fig, empty_fig, empty_fig, empty_fig
    
    X = np.array(params.get("X", [[0, 0]]))
    y = np.array(params.get("y", [[0]]))
    
    data_fig = go.Figure()
    
    # 绘制两类数据点
    class_0_idx = (y.flatten() == 0)
    class_1_idx = (y.flatten() == 1)
    
    data_fig.add_trace(go.Scatter(
        x=X[class_0_idx, 0],
        y=X[class_0_idx, 1],
        mode='markers',
        name='类别 0',
        marker=dict(color='blue', size=8, symbol='circle')
    ))
    
    data_fig.add_trace(go.Scatter(
        x=X[class_1_idx, 0],
        y=X[class_1_idx, 1],
        mode='markers',
        name='类别 1',
        marker=dict(color='red', size=8, symbol='x')
    ))
    
    data_fig.update_layout(
        title="训练数据分布",
        xaxis_title="特征 1",
        yaxis_title="特征 2",
        showlegend=True,
        hovermode='closest'
    )
    
    # 决策边界图
    boundary_fig = go.Figure()
    
    if network_state.get("initialized"):
        # 创建网格
        x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
        y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                            np.linspace(y_min, y_max, 100))
        
        # 恢复网络并预测
        network = BPNeuralNetwork(
            input_size=2,
            hidden_size=params["hidden_size"],
            output_size=1,
            optimizer=params["optimizer"],
            learning_rate=params["lr"]
        )
        network.W1 = np.array(network_state["W1"])
        network.b1 = np.array(network_state["b1"])
        network.W2 = np.array(network_state["W2"])
        network.b2 = np.array(network_state["b2"])
        
        grid_points = np.c_[xx.ravel(), yy.ravel()]
        Z = network.predict(grid_points)
        Z = Z.reshape(xx.shape)
        
        # 绘制决策边界
        boundary_fig.add_trace(go.Contour(
            x=np.linspace(x_min, x_max, 100),
            y=np.linspace(y_min, y_max, 100),
            z=Z,
            colorscale='RdBu',
            showscale=True,
            contours=dict(
                start=0,
                end=1,
                size=0.1,
            ),
            opacity=0.6,
        ))
        
        # 添加数据点
        boundary_fig.add_trace(go.Scatter(
            x=X[class_0_idx, 0],
            y=X[class_0_idx, 1],
            mode='markers',
            name='类别 0',
            marker=dict(color='blue', size=8, symbol='circle', line=dict(color='white', width=1))
        ))
        
        boundary_fig.add_trace(go.Scatter(
            x=X[class_1_idx, 0],
            y=X[class_1_idx, 1],
            mode='markers',
            name='类别 1',
            marker=dict(color='red', size=8, symbol='x', line=dict(color='white', width=1))
        ))
    
    boundary_fig.update_layout(
        title="决策边界",
        xaxis_title="特征 1",
        yaxis_title="特征 2",
        showlegend=True,
        legend=dict(
            x=0.02,
            y=0.98,
            xanchor='left',
            yanchor='top',
            bgcolor='rgba(255, 255, 255, 0.8)',
            bordercolor='black',
            borderwidth=1
        )
    )
    
    # 损失曲线
    loss_fig = go.Figure()
    
    if data and len(data.get("epochs", [])) > 0:
        loss_fig.add_trace(go.Scatter(
            x=data["epochs"],
            y=data["losses"],
            mode='lines+markers',
            name='训练损失',
            line=dict(color='red', width=2),
            marker=dict(size=6)
        ))
        
        # 添加准确率（使用第二个y轴）
        loss_fig.add_trace(go.Scatter(
            x=data["epochs"],
            y=[acc * 100 for acc in data["accuracy"]],
            mode='lines+markers',
            name='准确率 (%)',
            line=dict(color='green', width=2),
            marker=dict(size=6),
            yaxis='y2'
        ))
    
    loss_fig.update_layout(
        title=f"训练曲线 - {params.get('optimizer', 'gradient_descent')}",
        xaxis_title="训练轮次",
        yaxis_title="损失值",
        yaxis2=dict(
            title="准确率 (%)",
            overlaying='y',
            side='right',
            range=[0, 100]
        ),
        showlegend=True,
        hovermode='x unified'
    )
    
    # 三维损失地形图（3D Loss Landscape）
    loss_landscape_fig = go.Figure()
    
    if data and len(data.get("epochs", [])) > 0 and network_state.get("initialized"):
        # 恢复网络状态
        network = BPNeuralNetwork(
            input_size=2,
            hidden_size=params["hidden_size"],
            output_size=1,
            optimizer=params["optimizer"],
            learning_rate=params["lr"]
        )
        network.W1 = np.array(network_state["W1"], dtype=np.float64)
        network.b1 = np.array(network_state["b1"], dtype=np.float64)
        network.W2 = np.array(network_state["W2"], dtype=np.float64)
        network.b2 = np.array(network_state["b2"], dtype=np.float64)
        
        # 获取权重轨迹的范围
        w1_vals = data["weights_w1"]
        w2_vals = data["weights_w2"]
        loss_vals = data["losses"]
        
        w1_min, w1_max = min(w1_vals), max(w1_vals)
        w2_min, w2_max = min(w2_vals), max(w2_vals)
        
        # 扩展范围以显示更广的区域
        w1_range = w1_min - abs(w1_max - w1_min) * 0.3, w1_max + abs(w1_max - w1_min) * 0.3
        w2_range = w2_min - abs(w2_max - w2_min) * 0.3, w2_max + abs(w2_max - w2_min) * 0.3
        
        # 如果范围太小，设置最小范围
        if w1_range[1] - w1_range[0] < 0.1:
            w1_center = (w1_range[0] + w1_range[1]) / 2
            w1_range = (w1_center - 0.5, w1_center + 0.5)
        if w2_range[1] - w2_range[0] < 0.1:
            w2_center = (w2_range[0] + w2_range[1]) / 2
            w2_range = (w2_center - 0.5, w2_center + 0.5)
        
        # 计算损失曲面
        W1_grid, W2_grid, loss_grid = compute_loss_surface(
            X, y, network, w1_range, w2_range, grid_size=40
        )
        
        # 使用对数刻度使等高线更清晰
        loss_grid_log = np.log10(loss_grid + 1e-10)
        
        # 绘制等高线
        loss_landscape_fig.add_trace(go.Contour(
            x=W1_grid[0, :],
            y=W2_grid[:, 0],
            z=loss_grid_log,
            colorscale='RdYlBu_r',
            contours=dict(
                coloring='heatmap',
                showlabels=True,
                labelfont=dict(size=10, color='white')
            ),
            colorbar=dict(
                title=dict(
                    text="log(Loss)",
                    side="right"
                ),
                x=1.02,
                len=0.4,
                y=0.95,
                yanchor='top'
            ),
            name='损失曲面',
            hovertemplate='W1[0,0]: %{x:.4f}<br>W2[0,0]: %{y:.4f}<br>log(Loss): %{z:.4f}<extra></extra>'
        ))
        
        # 绘制优化轨迹
        loss_landscape_fig.add_trace(go.Scatter(
            x=w1_vals,
            y=w2_vals,
            mode='lines+markers',
            name='优化轨迹',
            line=dict(color='white', width=3),
            marker=dict(
                size=6,
                color=data["epochs"],
                colorscale='Plasma',
                showscale=True,
                colorbar=dict(
                    title="轮次",
                    x=1.02,
                    len=0.4,
                    y=0.05,
                    yanchor='bottom'
                ),
                line=dict(color='black', width=1)
            ),
            text=[f"轮次 {e}<br>Loss: {l:.6f}" for e, l in zip(data["epochs"], data["losses"])],
            hovertemplate='W1[0,0]: %{x:.4f}<br>W2[0,0]: %{y:.4f}<br>%{text}<extra></extra>'
        ))
        
        # 标记起点
        loss_landscape_fig.add_trace(go.Scatter(
            x=[w1_vals[0]],
            y=[w2_vals[0]],
            mode='markers',
            name='起点',
            marker=dict(color='lime', size=20, symbol='star', line=dict(color='black', width=2))
        ))
        
        # 标记当前位置
        loss_landscape_fig.add_trace(go.Scatter(
            x=[w1_vals[-1]],
            y=[w2_vals[-1]],
            mode='markers',
            name='当前位置',
            marker=dict(color='red', size=20, symbol='diamond', line=dict(color='black', width=2))
        ))
        
        loss_landscape_fig.update_layout(
            title=f"loss地形图 - {params.get('optimizer', 'gradient_descent')}",
            xaxis_title="W1[0,0] (输入→隐藏层权重)",
            yaxis_title="W2[0,0] (隐藏层→输出权重)",
            showlegend=True,
            legend=dict(
                x=0.02,
                y=0.98,
                xanchor='left',
                yanchor='top',
                bgcolor='rgba(255, 255, 255, 0.9)',
                bordercolor='black',
                borderwidth=1
            ),
            hovermode='closest',
            height=500,
            margin=dict(r=120)  # 增加右侧边距以容纳两个colorbar
        )
    else:
        loss_landscape_fig.update_layout(title="等待训练数据...")
    
    return info_text, data_fig, boundary_fig, loss_fig, loss_landscape_fig


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8060))
    app.run(host="0.0.0.0", port=port, debug=True)
