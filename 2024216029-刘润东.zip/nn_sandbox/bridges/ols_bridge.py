from PyQt5.QtCore import pyqtSlot
from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.ols_algorithm import ObservableOLSAlgorithm
import nn_sandbox.backend.utils


class OLSBridge(Bridge):
    """
    OLS算法的Bridge类
    连接算法和QML界面
    """
    
    # 定义Bridge属性
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    coefficients = BridgeProperty([0.0])
    intercept = BridgeProperty(0.0)
    slope = BridgeProperty(0.0)
    r_squared = BridgeProperty(0.0)
    mse = BridgeProperty(0.0)
    rmse = BridgeProperty(0.0)
    data_points = BridgeProperty([])
    regression_line = BridgeProperty([])
    fitted_values = BridgeProperty([])
    residuals = BridgeProperty([])
    statistics = BridgeProperty({})
    is_running = BridgeProperty(False)
    add_intercept = BridgeProperty(True)
    
    def __init__(self):
        super().__init__()
        self.algorithm = None
        # 加载数据集
        self.dataset_dict = nn_sandbox.backend.utils.read_data()
        
    @pyqtSlot(str, bool)
    def start(self, dataset_name, add_intercept):
        """启动OLS算法"""
        try:
            print(f"Starting OLS with dataset: {dataset_name}, add_intercept: {add_intercept}")
            
            if self.algorithm and self.algorithm.is_alive():
                self.algorithm.stop()
                self.algorithm.join()
            
            if dataset_name not in self.dataset_dict:
                print(f"Dataset {dataset_name} not found")
                return
            
            dataset = self.dataset_dict[dataset_name]
            
            self.algorithm = ObservableOLSAlgorithm(
                observer=self,
                dataset=dataset,
                add_intercept=add_intercept
            )
            self.is_running = True
            self.add_intercept = add_intercept
            
            # 启动算法（在后台线程中运行）
            self.algorithm.start()
            
            # 等待算法完成
            import threading
            def wait_for_completion():
                if self.algorithm:
                    self.algorithm.join()
                    self.is_running = False
                    print("OLS algorithm completed")
            threading.Thread(target=wait_for_completion, daemon=True).start()
            
        except Exception as e:
            print(f"Error starting OLS algorithm: {e}")
            import traceback
            traceback.print_exc()
            self.is_running = False
    
    @pyqtSlot()
    def stop(self):
        """停止算法"""
        if self.algorithm:
            self.algorithm.stop()
            if self.algorithm.is_alive():
                self.algorithm.join()
        self.is_running = False

