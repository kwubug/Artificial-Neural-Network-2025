import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# 设置中文显示
# 适配 Windows 系统自带中文字体，避免字体找不到的警告
plt.rcParams["font.family"] = ["Microsoft YaHei", "SimSun", "SimHei", "FangSong"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示为方块的问题

# 生成模拟数据
np.random.seed(42)  # 固定随机种子，保证结果可复现
x = np.linspace(0, 10, 50)  # 自变量
true_slope = 2.3  # 真实斜率
true_intercept = 1.5  # 真实截距
noise = np.random.normal(0, 1.2, size=len(x))  # 高斯噪声
y = true_slope * x + true_intercept + noise  # 带噪声的因变量

# 计算OLS解析解（最小二乘估计）
n = len(x)
sum_x = np.sum(x)
sum_y = np.sum(y)
sum_xy = np.sum(x * y)
sum_x2 = np.sum(x **2)

# OLS公式计算最优参数
beta1 = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x** 2)  # 估计斜率
beta0 = (sum_y - beta1 * sum_x) / n  # 估计截距
y_pred_ols = beta0 + beta1 * x  # OLS预测值

# 创建图形
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle('OLS(普通最小二乘法)学习过程可视化', fontsize=16)

# 左侧图：数据与回归线
ax1.scatter(x, y, color='blue', alpha=0.6, label='观测数据')
ax1.plot(x, true_slope * x + true_intercept, 'r--', label=f'真实关系: y={true_slope}x+{true_intercept}')
line, = ax1.plot(x, np.zeros_like(x), 'g-', linewidth=2, label='当前回归线')
residuals = [ax1.plot([], [], 'gray', linestyle=':', alpha=0.5)[0] for _ in range(n)]  # 残差线

ax1.set_xlim(0, 10)
ax1.set_ylim(min(y) - 2, max(y) + 2)
ax1.set_xlabel('自变量 x')
ax1.set_ylabel('因变量 y')
ax1.legend()

# 右侧图：残差平方和曲线
slope_range = np.linspace(-1, 5, 200)  # 斜率参数范围
sse_values = []
for m in slope_range:
    b = beta0  # 固定截距为最优解
    y_pred = b + m * x
    sse = np.sum((y - y_pred) **2)
    sse_values.append(sse)

ax2.plot(slope_range, sse_values, 'b-', label='残差平方和曲线')
min_point, = ax2.plot([], [], 'ro', markersize=8, label='最小值点')
current_point, = ax2.plot([], [], 'go', label='当前点')

ax2.set_xlabel('斜率参数')
ax2.set_ylabel('残差平方和(SSE)')
ax2.axvline(x=beta1, color='r', linestyle='--', alpha=0.3)
ax2.legend()
ax2.grid(True, alpha=0.3)

# 动画更新函数
def update(frame):
    # 模拟斜率从初始值逐步优化到最优解
    progress = frame / 100  # 0到1的进度
    current_slope = -1 + progress * (5 - (-1))  # 从-1过渡到5
    current_intercept = beta0  # 截距固定为最优解
    
    # 更新回归线
    y_pred = current_intercept + current_slope * x
    line.set_ydata(y_pred)
    
    # 更新残差线
    for i in range(n):
        residuals[i].set_data([x[i], x[i]], [y[i], y_pred[i]])
    
    # 更新残差平方和曲线中的当前点
    current_sse = np.sum((y - y_pred)** 2)
    current_point.set_data([current_slope], [current_sse])
    min_point.set_data([beta1], [np.sum((y - y_pred_ols) **2)])
    
    # 更新标题显示当前参数和SSE
    ax1.set_title(f'回归线: y={current_intercept:.2f}+{current_slope:.2f}x\n残差平方和: {current_sse:.2f}')
    return line, min_point, current_point, *residuals

# 创建动画
ani = FuncAnimation(
    fig, 
    update, 
    frames=np.linspace(0, 100, 100), 
    interval=100, 
    blit=True
)

# 显示最终结果
plt.tight_layout()
plt.subplots_adjust(top=0.9)
plt.show()

# 如需保存动画，取消下面的注释（需要安装pillow库）
# ani.save('ols_animation.gif', writer='pillow', fps=10)