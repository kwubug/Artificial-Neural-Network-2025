import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QTextEdit, QMessageBox)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QPainter, QPen, QColor, QFont
from ols_algorithm import OLSAlgorithm


class PlotWidget(QWidget):
    """自定义绘图组件"""
    point_added = pyqtSignal(float, float)
    
    def __init__(self):
        super().__init__()
        self.setMinimumSize(600, 500)
        self.setMouseTracking(True)
        
        # 数据存储
        self.x_data = []
        self.y_data = []
        self.coefficients = None  # [截距, 斜率]
        
        # 绘图参数
        self.padding = 50
        self.point_radius = 5
        
        # 鼠标位置跟踪
        self.mouse_x = None
        self.mouse_y = None
    
    def set_data(self, x_data: list, y_data: list):
        """设置数据点"""
        self.x_data = x_data
        self.y_data = y_data
    
    def set_coefficients(self, coefficients: np.ndarray):
        """设置回归系数"""
        self.coefficients = coefficients
    
    def clear_data(self):
        """清空数据"""
        self.x_data.clear()
        self.y_data.clear()
        self.coefficients = None
        self.update()
    
    def mousePressEvent(self, event):
        """鼠标点击添加数据点"""
        if event.button() == Qt.LeftButton:
            x, y = self.screen_to_data(event.x(), event.y())
            self.x_data.append(x)
            self.y_data.append(y)
            self.point_added.emit(x, y)
            self.update()
    
    def mouseMoveEvent(self, event):
        """鼠标移动跟踪"""
        self.mouse_x = event.x()
        self.mouse_y = event.y()
        self.update()
    
    def screen_to_data(self, screen_x: int, screen_y: int) -> tuple:
        """将屏幕坐标转换为数据坐标"""
        width = self.width()
        height = self.height()
        
        # 计算数据范围
        if len(self.x_data) > 0:
            x_min = min(self.x_data) if self.x_data else 0
            x_max = max(self.x_data) if self.x_data else 10
            y_min = min(self.y_data) if self.y_data else 0
            y_max = max(self.y_data) if self.y_data else 10
        else:
            x_min, x_max = 0, 10
            y_min, y_max = 0, 10
        
        # 添加一些边距
        x_range = x_max - x_min if x_max != x_min else 10
        y_range = y_max - y_min if y_max != y_min else 10
        
        x_min -= x_range * 0.1
        x_max += x_range * 0.1
        y_min -= y_range * 0.1
        y_max += y_range * 0.1
        
        x_range = x_max - x_min
        y_range = y_max - y_min
        
        # 转换坐标
        plot_width = width - 2 * self.padding
        plot_height = height - 2 * self.padding
        
        data_x = x_min + (screen_x - self.padding) / plot_width * x_range
        data_y = y_max - (screen_y - self.padding) / plot_height * y_range
        
        return data_x, data_y
    
    def data_to_screen(self, data_x: float, data_y: float) -> tuple:
        """将数据坐标转换为屏幕坐标"""
        width = self.width()
        height = self.height()
        
        # 计算数据范围
        if len(self.x_data) > 0:
            x_min = min(self.x_data)
            x_max = max(self.x_data)
            y_min = min(self.y_data)
            y_max = max(self.y_data)
        else:
            x_min, x_max = 0, 10
            y_min, y_max = 0, 10
        
        # 添加边距
        x_range = x_max - x_min if x_max != x_min else 10
        y_range = y_max - y_min if y_max != y_min else 10
        
        x_min -= x_range * 0.1
        x_max += x_range * 0.1
        y_min -= y_range * 0.1
        y_max += y_range * 0.1
        
        x_range = x_max - x_min
        y_range = y_max - y_min
        
        # 转换坐标
        plot_width = width - 2 * self.padding
        plot_height = height - 2 * self.padding
        
        screen_x = self.padding + (data_x - x_min) / x_range * plot_width
        screen_y = self.padding + (y_max - data_y) / y_range * plot_height
        
        return int(screen_x), int(screen_y)
    
    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        width = self.width()
        height = self.height()
        
        # 绘制背景
        painter.fillRect(0, 0, width, height, QColor(255, 255, 255))
        
        if len(self.x_data) == 0:
            # 显示提示信息
            painter.setPen(QPen(QColor(100, 100, 100), 1))
            font = QFont("Arial", 14)
            painter.setFont(font)
            text = "点击图表添加数据点"
            painter.drawText(width // 2 - 100, height // 2, text)
            return
        
        # 计算数据范围
        x_min = min(self.x_data)
        x_max = max(self.x_data)
        y_min = min(self.y_data)
        y_max = max(self.y_data)
        
        x_range = x_max - x_min if x_max != x_min else 10
        y_range = y_max - y_min if y_max != y_min else 10
        
        x_min -= x_range * 0.1
        x_max += x_range * 0.1
        y_min -= y_range * 0.1
        y_max += y_range * 0.1
        
        # 绘制坐标轴
        painter.setPen(QPen(QColor(0, 0, 0), 2))
        painter.drawLine(self.padding, height - self.padding, 
                        width - self.padding, height - self.padding)  # X轴
        painter.drawLine(self.padding, height - self.padding, 
                        self.padding, self.padding)  # Y轴
        
        # 绘制网格线
        painter.setPen(QPen(QColor(200, 200, 200), 1))
        num_grid_lines = 5
        for i in range(num_grid_lines + 1):
            # 垂直网格线
            x = self.padding + (width - 2 * self.padding) * i / num_grid_lines
            painter.drawLine(int(x), self.padding, int(x), height - self.padding)
            
            # 水平网格线
            y = self.padding + (height - 2 * self.padding) * i / num_grid_lines
            painter.drawLine(self.padding, int(y), width - self.padding, int(y))
        
        # 绘制坐标标签
        painter.setPen(QPen(QColor(0, 0, 0), 1))
        font = QFont("Arial", 9)
        painter.setFont(font)
        
        for i in range(num_grid_lines + 1):
            # X轴标签
            x_val = x_min + (x_max - x_min) * i / num_grid_lines
            x_pos = self.padding + (width - 2 * self.padding) * i / num_grid_lines
            painter.drawText(int(x_pos) - 20, height - self.padding + 20, 
                           f"{x_val:.2f}")
            
            # Y轴标签
            y_val = y_min + (y_max - y_min) * (num_grid_lines - i) / num_grid_lines
            y_pos = self.padding + (height - 2 * self.padding) * i / num_grid_lines
            painter.drawText(self.padding - 45, int(y_pos) + 5, 
                           f"{y_val:.2f}")
        
        # 绘制回归线
        if self.coefficients is not None:
            painter.setPen(QPen(QColor(255, 0, 0), 3))
            x1, y1 = self.data_to_screen(x_min, 
                                        self.coefficients[0] + self.coefficients[1] * x_min)
            x2, y2 = self.data_to_screen(x_max, 
                                        self.coefficients[0] + self.coefficients[1] * x_max)
            painter.drawLine(x1, y1, x2, y2)
        
        # 绘制数据点
        painter.setPen(QPen(QColor(50, 100, 200), 2))
        painter.setBrush(QColor(50, 100, 200))
        for x, y in zip(self.x_data, self.y_data):
            screen_x, screen_y = self.data_to_screen(x, y)
            painter.drawEllipse(screen_x - self.point_radius, 
                              screen_y - self.point_radius,
                              2 * self.point_radius, 
                              2 * self.point_radius)
        
        # 显示鼠标位置对应的数据坐标
        if self.mouse_x is not None and self.mouse_y is not None:
            if (self.padding <= self.mouse_x <= width - self.padding and
                self.padding <= self.mouse_y <= height - self.padding):
                data_x, data_y = self.screen_to_data(self.mouse_x, self.mouse_y)
                painter.setPen(QPen(QColor(100, 100, 100), 1))
                font = QFont("Arial", 10)
                painter.setFont(font)
                info_text = f"({data_x:.2f}, {data_y:.2f})"
                painter.drawText(self.mouse_x + 10, self.mouse_y - 10, info_text)


class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.ols = OLSAlgorithm()
        self.init_ui()
    
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("OLS最小二乘法可视化")
        self.setGeometry(100, 100, 1000, 700)
        
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧：绘图区域
        left_layout = QVBoxLayout()
        
        self.plot_widget = PlotWidget()
        self.plot_widget.point_added.connect(self.on_point_added)
        left_layout.addWidget(self.plot_widget)
        
        # 控制按钮
        button_layout = QHBoxLayout()
        
        self.fit_button = QPushButton("拟合回归线")
        self.fit_button.clicked.connect(self.fit_regression)
        self.fit_button.setEnabled(False)
        button_layout.addWidget(self.fit_button)
        
        self.clear_button = QPushButton("清空数据")
        self.clear_button.clicked.connect(self.clear_data)
        button_layout.addWidget(self.clear_button)
        
        self.generate_button = QPushButton("生成示例数据")
        self.generate_button.clicked.connect(self.generate_sample_data)
        button_layout.addWidget(self.generate_button)
        
        left_layout.addLayout(button_layout)
        
        main_layout.addLayout(left_layout, 2)
        
        # 右侧：统计信息
        right_layout = QVBoxLayout()
        
        stats_label = QLabel("统计信息")
        stats_label.setFont(QFont("Arial", 14, QFont.Bold))
        right_layout.addWidget(stats_label)
        
        self.stats_text = QTextEdit()
        self.stats_text.setReadOnly(True)
        self.stats_text.setMinimumWidth(300)
        self.stats_text.setFont(QFont("Arial", 10))
        right_layout.addWidget(self.stats_text)
        
        # 说明文字
        info_label = QLabel("使用说明：\n\n"
                           "1. 点击左侧图表添加数据点\n"
                           "2. 至少添加2个点后点击'拟合回归线'\n"
                           "3. 红色直线为拟合结果\n"
                           "4. 右侧显示统计信息")
        info_label.setWordWrap(True)
        info_label.setFont(QFont("Arial", 9))
        right_layout.addWidget(info_label)
        
        main_layout.addLayout(right_layout, 1)
        
        # 更新统计信息显示
        self.update_stats_display()
    
    def on_point_added(self, x: float, y: float):
        """数据点添加事件"""
        self.ols.add_data_point(x, y)
        self.plot_widget.set_data(self.ols.x_data, self.ols.y_data)
        
        # 至少需要2个点才能拟合
        if len(self.ols.x_data) >= 2:
            self.fit_button.setEnabled(True)
        
        self.update_stats_display()
    
    def fit_regression(self):
        """拟合回归线"""
        if self.ols.fit():
            self.plot_widget.set_coefficients(self.ols.coefficients)
            self.plot_widget.update()
            self.update_stats_display()
        else:
            QMessageBox.warning(self, "警告", "数据点不足，至少需要2个点才能拟合！")
    
    def clear_data(self):
        """清空数据"""
        reply = QMessageBox.question(self, "确认", "确定要清空所有数据吗？",
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.ols.clear_data()
            self.plot_widget.clear_data()
            self.fit_button.setEnabled(False)
            self.update_stats_display()
    
    def generate_sample_data(self):
        """生成示例数据"""
        import random
        
        # 生成带噪声的线性数据
        x_data = np.linspace(0, 10, 20)
        y_data = 2 * x_data + 3 + np.random.normal(0, 1, 20)
        
        self.ols.clear_data()
        self.plot_widget.clear_data()
        
        for x, y in zip(x_data, y_data):
            self.ols.add_data_point(float(x), float(y))
        
        self.plot_widget.set_data(self.ols.x_data, self.ols.y_data)
        self.fit_button.setEnabled(True)
        self.update_stats_display()
        self.plot_widget.update()
    
    def update_stats_display(self):
        """更新统计信息显示"""
        stats = self.ols.get_statistics()
        
        text = f"数据点数量: {stats['n_points']}\n\n"
        
        if stats['coefficients'] is not None:
            text += f"回归方程: {stats['equation']}\n\n"
            text += f"截距 (b0): {stats['coefficients'][0]:.4f}\n"
            text += f"斜率 (b1): {stats['coefficients'][1]:.4f}\n\n"
            text += f"R² (决定系数): {stats['r_squared']:.4f}\n"
            text += f"MSE (均方误差): {stats['mse']:.4f}\n"
            text += f"MAE (平均绝对误差): {stats['mae']:.4f}\n"
        else:
            text += "尚未拟合回归线\n"
            text += "请添加至少2个数据点后点击'拟合回归线'"
        
        self.stats_text.setText(text)


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

