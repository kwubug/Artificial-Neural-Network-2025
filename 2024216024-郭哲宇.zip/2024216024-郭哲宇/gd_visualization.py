import numpy as np
import matplotlib.pyplot as plt

# -------------------------------
# 定义一个可视化用的二维损失函数
# -------------------------------
def loss(w):
    w1, w2 = w
    return (w1 - 2)**2 + (w2 + 3)**2 + 1

def grad(w):
    w1, w2 = w
    return np.array([2*(w1 - 2), 2*(w2 + 3)])

# -------------------------------
# 三种梯度下降算法
# -------------------------------

def batch_gradient_descent(lr=0.1, steps=40):
    w = np.array([6.0, 6.0])
    trajectory = [w.copy()]
    for _ in range(steps):
        g = grad(w)
        w = w - lr * g
        trajectory.append(w.copy())
    return np.array(trajectory)

def stochastic_gradient_descent(lr=0.1, steps=40):
    w = np.array([6.0, 6.0])
    trajectory = [w.copy()]
    for _ in range(steps):
        noise = np.random.randn(2) * 0.7  # 模拟随机样本带来的噪声
        g = grad(w) + noise
        w = w - lr * g
        trajectory.append(w.copy())
    return np.array(trajectory)

def mini_batch_gradient_descent(lr=0.1, steps=40, batch_size=5):
    w = np.array([6.0, 6.0])
    trajectory = [w.copy()]
    for _ in range(steps):
        noise = np.random.randn(2) * (1.0 / batch_size)  # 小批噪声
        g = grad(w) + noise
        w = w - lr * g
        trajectory.append(w.copy())
    return np.array(trajectory)

# -------------------------------
# 可视化轨迹
# -------------------------------

def plot_trajectories(trajectories, labels):
    # 绘制损失函数等高线
    w1 = np.linspace(-6, 6, 200)
    w2 = np.linspace(-6, 6, 200)
    W1, W2 = np.meshgrid(w1, w2)
    L = (W1 - 2)**2 + (W2 + 3)**2 + 1

    plt.figure(figsize=(9,7))
    plt.contour(W1, W2, L, levels=30)

    # 绘制每种优化算法的下降路径
    for traj, label in zip(trajectories, labels):
        plt.plot(traj[:,0], traj[:,1], marker='o', markersize=3, label=label)

    plt.scatter([2], [-3], s=80, label="最优解")
    plt.title("三种梯度下降算法可视化")
    plt.xlabel("w1")
    plt.ylabel("w2")
    plt.legend()
    plt.grid()

# -------------------------------
# 运行三种算法并可视化
# -------------------------------

traj_batch = batch_gradient_descent()
traj_sgd = stochastic_gradient_descent()
traj_minibatch = mini_batch_gradient_descent()

plot_trajectories(
    [traj_batch, traj_sgd, traj_minibatch],
    ["Batch GD（批量梯度下降）",
     "SGD（随机梯度下降）",
     "Mini-Batch（小批量下降）"],
)

plt.show()
