import numpy as np
import matplotlib.pyplot as plt

# ---------------------- 1. Signal Generation (matching MATLAB logic) ----------------------
# Time parameters (simulating MATLAB's t=0:0.005:50)
dt = 0.005  # Time step
t_end = 50  # End time
time = np.arange(0, t_end, dt)  # Time sequence
n = len(time)  # Signal length

# Simulate EEG signal (random noise with low-frequency components)
eeg = (np.random.rand(n) - 0.5) * 4  # Random signal with mean 0, range [-2,2]
eeg += 0.5 * np.sin(2 * np.pi * 0.5 * time)  # Add 0.5Hz low-frequency component

# Noise source (50Hz sine wave, simulating instrument noise)
noise_freq = 50  # Noise frequency
noise = np.sin(2 * np.pi * noise_freq * time)  # Pure sine wave noise

# Mixed signal (collected signal = EEG + noise)
input_signal = eeg + noise  # Corresponding to MATLAB's input=eeg+noise;

# Target signal (original EEG for error calculation during training)
target = eeg  # Corresponding to MATLAB's target=eeg;

# ---------------------- 2. ADALINE Network Configuration (with delayed inputs) ----------------------
delays = 2  # Number of delay steps (using current + previous 1 step, total 2 inputs)
input_dim = delays  # Input dimension = number of delays
learning_rate = 0.005  # Learning rate


class ADALINE:
    def __init__(self, input_dim, lr):
        self.weights = np.zeros(input_dim)  # Weight initialization
        self.bias = 0  # Bias initialization
        self.lr = lr  # Learning rate

    def forward(self, x):
        # Forward propagation: y = weights·input + bias
        return np.dot(self.weights, x) + self.bias

    def update(self, x, d, y):
        # LMS update rule: adjust weights and bias based on error
        error = d - y
        self.weights += self.lr * error * x
        self.bias += self.lr * error
        return error  # Return error (for signal recovery)


# Initialize ADALINE network
adaline = ADALINE(input_dim, learning_rate)

# ---------------------- 3. Network Training and Signal Processing ----------------------
output = np.zeros(n)  # Store network output (noise estimation)
e = np.zeros(n)  # Store error (recovered EEG signal)

for i in range(delays, n):  # Start from delays step (ensure enough historical data)
    # Construct input: current noise + delayed noise (e.g., [i-1, i] for delays=2)
    x = noise[i - delays + 1: i + 1]  # Delayed input, corresponding to MATLAB's delay network

    # Forward calculation (estimate noise)
    y = adaline.forward(x)

    # Update weights (target is to fit noise component in mixed signal)
    error = adaline.update(x, input_signal[i], y)  # Use mixed signal as target

    # Store results: network output is estimated noise, error is recovered EEG
    output[i] = y
    e[i] = error  # Equivalent to input_signal[i] - y = (eeg + noise) - estimated noise ≈ eeg

# Fill first 'delays' steps with neighboring values
output[:delays] = output[delays]
e[:delays] = e[delays]

# ---------------------- 4. Visualization (matching MATLAB's subplot layout) ----------------------
plt.figure(figsize=(12, 10))

# Subplot 1: Original EEG signal
plt.subplot(3, 1, 1)
plt.plot(time, eeg, 'r')  # Red line
plt.title('Original EEG Signal')
plt.ylabel('Amplitude')
plt.xlim([0, 20])  # Show first 20 seconds
plt.ylim([-1.8, 1.8])  # Adjust display range

# Subplot 2: Mixed signal (EEG + noise)
plt.subplot(3, 1, 2)
plt.plot(time, input_signal, 'b')  # Blue line
plt.title('Mixed Signal (EEG + Noise)')
plt.ylabel('Amplitude')
plt.xlim([0, 20])
plt.ylim([-1.8, 1.8])

# Subplot 3: Recovered EEG signal (error signal)
plt.subplot(3, 1, 3)
plt.plot(time, e, 'k')  # Black line
plt.title('EEG Signal Recovered by ADALINE')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.xlim([0, 20])
plt.ylim([-1.8, 1.8])

plt.tight_layout()
plt.show()