import QtQuick.Controls 2.5
import QtCharts 2.3

ChartView {
    property var scatterSeriesMap: ({})
    property var lineSeriesMap: ({})
    property alias xAxis: xAxis
    property alias yAxis: yAxis
    property alias chartToolTip: chartToolTip
    

    antialiasing: true
    legend.visible: false
    ValueAxis{
        id: xAxis
        min: -1.0
        max: 1.0
    }
    ValueAxis{
        id: yAxis
        min: -1.0
        max: 1.0
    }
    ToolTip {
        id: chartToolTip
    }

    function updateDataset(dataset) {
        clear()
        addScatterSeries(dataset)
        updateAxesRange(dataset)
    }

    function updateTrainingDataset(dataset) {
        addScatterSeries(dataset)
    }

    function updateTestingDataset(dataset) {
        dataset.sort((a, b) => {return a[2] - b[2]})
        for (let data of dataset) {
            if (!(`${data[2]}test` in scatterSeriesMap)) {
                scatterSeriesMap[`${data[2]}test`] = createHoverableScatterSeries(`${data[2]}test`)
                if (data[2] in scatterSeriesMap)
                    scatterSeriesMap[`${data[2]}test`].color = Qt.lighter(scatterSeriesMap[data[2]].color)
            }
            scatterSeriesMap[`${data[2]}test`].append(...data)
        }
    }

    function updateOptimizationPath(dataset) {
        // 清除之前的优化路径
        if ('optimization_path' in lineSeriesMap) {
            removeSeries(lineSeriesMap['optimization_path'])
            delete lineSeriesMap['optimization_path']
        }
        
        // 创建新的优化路径线
        if (!('optimization_path' in lineSeriesMap)) {
            lineSeriesMap['optimization_path'] = createSeries(
                ChartView.SeriesTypeLine, 'optimization_path', xAxis, yAxis
            )
            lineSeriesMap['optimization_path'].color = 'red'
            lineSeriesMap['optimization_path'].width = 2
        }
        
        // 添加路径点
        for (let i = 0; i < dataset.length; i++) {
            lineSeriesMap['optimization_path'].append(dataset[i][0], dataset[i][1])
        }
        
        // 更新坐标轴范围
        updateAxesRange(dataset)
    }

    function appendPointToOptimizationPath(point) {
        // 创建优化路径线（如果不存在）
        if (!('optimization_path' in lineSeriesMap)) {
            lineSeriesMap['optimization_path'] = createSeries(
                ChartView.SeriesTypeLine, 'optimization_path', xAxis, yAxis
            )
            lineSeriesMap['optimization_path'].color = 'red'
            lineSeriesMap['optimization_path'].width = 2
        }
        
        // 添加点到路径
        lineSeriesMap['optimization_path'].append(point[0], point[1])
        
        // 更新坐标轴范围
        // 为了提高性能，我们只在特定条件下更新坐标轴范围
        let pointCount = lineSeriesMap['optimization_path'].count
        if (pointCount % 10 === 0 || pointCount < 10) {  // 每10个点或前10个点时更新
            // 获取所有点来计算范围
            let xValues = []
            let yValues = []
            for (let i = 0; i < pointCount; i++) {
                let p = lineSeriesMap['optimization_path'].at(i)
                xValues.push(p.x)
                yValues.push(p.y)
            }
            
            let xMax = Math.max(...xValues)
            let xMin = Math.min(...xValues)
            let yMax = Math.max(...yValues)
            let yMin = Math.min(...yValues)
            
            // 添加一些边距
            let xMargin = (xMax - xMin) * 0.1
            let yMargin = (yMax - yMin) * 0.1
            
            xAxis.max = xMax + xMargin
            xAxis.min = xMin - xMargin
            yAxis.max = yMax + yMargin
            yAxis.min = yMin - yMargin
        }
    }

    function addScatterSeries(dataset) {
        dataset.sort((a, b) => {return a[2] - b[2]})
        for (let data of dataset) {
            if (!(data[2] in scatterSeriesMap))
                scatterSeriesMap[data[2]] = createHoverableScatterSeries(data[2])
            scatterSeriesMap[data[2]].append(...data)
        }
    }

    function createHoverableScatterSeries(name) {
        const newSeries = createSeries(
            ChartView.SeriesTypeScatter, name, xAxis, yAxis
        )
        newSeries.hovered.connect((point, state) => {
            const position = mapToPosition(point)
            chartToolTip.x = position.x - chartToolTip.width
            chartToolTip.y = position.y - chartToolTip.height
            chartToolTip.text = `(${point.x}, ${point.y})`
            chartToolTip.visible = state
        })
        return newSeries
    }

    function updateAxesRange(dataset) {
        let xMax = -Infinity, yMax = -Infinity, xMin = Infinity, yMin = Infinity
        for (let row of dataset) {
            xMax = Math.max(xMax, row[0])
            xMin = Math.min(xMin, row[0])
            yMax = Math.max(yMax, row[1])
            yMin = Math.min(yMin, row[1])
        }
        xAxis.max = xMax + 0.1 * (xMax - xMin)
        xAxis.min = xMin - 0.1 * (xMax - xMin)
        yAxis.max = yMax + 0.1 * (yMax - yMin)
        yAxis.min = yMin - 0.1 * (yMax - yMin)
    }

    function clear() {
        removeAllSeries()
        scatterSeriesMap = {}
        lineSeriesMap = {}
    }

    // ---- Added: simple contour drawing for f(x,y) = x^2 + y^2 ----
    function clearContours() {
        for (let key in lineSeriesMap) {
            if (key.indexOf('contour_') === 0) {
                removeSeries(lineSeriesMap[key])
                delete lineSeriesMap[key]
            }
        }
    }
    function drawQuadraticContours(levels) {
        // levels: array of positive numbers = f(x,y) values; circles of radius sqrt(level)
        if (!levels || levels.length === 0) {
            levels = [0.25, 0.5, 1, 2, 4, 8, 16]
        }
        clearContours()
        for (let i = 0; i < levels.length; i++) {
            let r = Math.sqrt(levels[i])
            let name = 'contour_' + i
            lineSeriesMap[name] = createSeries(ChartView.SeriesTypeLine, name, xAxis, yAxis)
            // lightly styled
            lineSeriesMap[name].width = 1
            lineSeriesMap[name].opacity = 0.35
            // circle polyline
            let seg = 180
            for (let t = 0; t <= seg; t++) {
                let th = 2 * Math.PI * t / seg
                lineSeriesMap[name].append(r * Math.cos(th), r * Math.sin(th))
            }
        }
    }
    // ---- end added ----

}
