import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'TSP'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: tspBridge ? Object.keys(tspBridge.dataset_dict) : []
                enabled: tspBridge && tspBridge.has_finished
                onActivated: () => {
                    if (!tspBridge)
                        return
                    tspBridge.current_dataset_name = currentText
                    updateMap()
                }
                Component.onCompleted: () => {
                    function initialize() {
                        if (!tspBridge) {
                            Qt.callLater(initialize)
                            return
                        }
                        tspBridge.current_dataset_name = currentText
                        updateMap()
                    }
                    Qt.callLater(initialize)
                }
            }
        }
        
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                
                Label {
                    text: 'Population Size'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: populationSize
                    enabled: tspBridge && tspBridge.has_finished
                    editable: true
                    value: 100
                    from: 10
                    to: 1000
                }
                
                Label {
                    text: 'Mutation Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    id: mutationRate
                    enabled: tspBridge && tspBridge.has_finished
                    editable: true
                    value: 1  // 1表示0.01
                    from: 0   // 0表示0.00
                    to: 100   // 100表示1.00
                    stepSize: 1
                }
                
                Label {
                    text: 'Crossover Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    id: crossoverRate
                    enabled: tspBridge && tspBridge.has_finished
                    editable: true
                    value: 80  // 80表示0.80
                    from: 0    // 0表示0.00
                    to: 100    // 100表示1.00
                    stepSize: 10
                }
            }
        }
        
        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ChartView {
                id: tspMap
                antialiasing: true
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                ValueAxis {
                    id: xAxis
                    min: -6
                    max: 6
                }
                
                ValueAxis {
                    id: yAxis
                    min: -6
                    max: 6
                }
                
                ScatterSeries {
                    id: citiesSeries
                    name: 'Cities'
                    markerSize: 8
                    color: 'blue'
                }
                
                LineSeries {
                    id: currentRouteSeries
                    name: 'Current Route'
                    color: 'gray'
                    width: 1
                }
                
                LineSeries {
                    id: bestRouteSeries
                    name: 'Best Route'
                    color: 'red'
                    width: 2
                }
            }
        }
        
        RowLayout {
            Layout.fillWidth: true
            
            Button {
                id: startButton
                text: 'Start'
                enabled: tspBridge && tspBridge.has_finished
                onClicked: () => {
                    if (!tspBridge)
                        return
                    // 将整数值转换为算法需要的小数值
                    tspBridge.start_tsp_algorithm(
                        datasetCombobox.currentText,
                        populationSize.value,
                        mutationRate.value / 100,  // 转换为小数
                        crossoverRate.value / 100  // 转换为小数
                    )
                }
            }
            
            Button {
                id: stopButton
                text: 'Stop'
                enabled: tspBridge && !tspBridge.has_finished
                onClicked: () => {
                    if (!tspBridge)
                        return
                    tspBridge.stop_tsp_algorithm()
                }
            }
            
            Label {
                id: statusLabel
            text: tspBridge
                ? 'Iteration: ' + tspBridge.current_iteration + ', Best Distance: ' + tspBridge.best_distance.toFixed(4)
                : 'Iteration: -, Best Distance: -'
            }
        }
    }
    
    function updateMap() {
        // 确保dataset_dict不为空且current_dataset_name已设置
        if (!tspBridge)
            return
        if (tspBridge.dataset_dict && tspBridge.dataset_dict[tspBridge.current_dataset_name]) {
            citiesSeries.clear()
            const cities = tspBridge.dataset_dict[tspBridge.current_dataset_name]
            for (let i = 0; i < cities.length; i++) {
                citiesSeries.append(cities[i][0], cities[i][1])
            }
        }
    }
    
    // 更新路线显示
    Connections {
        target: tspBridge
        onCurrent_dataset_nameChanged: updateMap()
        onCurrent_routeChanged: {
            if (!tspBridge)
                return
            currentRouteSeries.clear()
            if (tspBridge.current_route && tspBridge.current_route.length > 0 &&
                tspBridge.dataset_dict && tspBridge.dataset_dict[tspBridge.current_dataset_name]) {
                const cities = tspBridge.dataset_dict[tspBridge.current_dataset_name]
                for (let i = 0; i < tspBridge.current_route.length; i++) {
                    const idx = tspBridge.current_route[i]
                    currentRouteSeries.append(cities[idx][0], cities[idx][1])
                }
                // 连接最后一个城市和第一个城市
                if (tspBridge.current_route.length > 0) {
                    const firstIdx = tspBridge.current_route[0]
                    currentRouteSeries.append(cities[firstIdx][0], cities[firstIdx][1])
                }
            }
        }
        
        onBest_routeChanged: {
            if (!tspBridge)
                return
            bestRouteSeries.clear()
            if (tspBridge.best_route && tspBridge.best_route.length > 0 &&
                tspBridge.dataset_dict && tspBridge.dataset_dict[tspBridge.current_dataset_name]) {
                const cities = tspBridge.dataset_dict[tspBridge.current_dataset_name]
                for (let i = 0; i < tspBridge.best_route.length; i++) {
                    const idx = tspBridge.best_route[i]
                    bestRouteSeries.append(cities[idx][0], cities[idx][1])
                }
                // 连接最后一个城市和第一个城市
                if (tspBridge.best_route.length > 0) {
                    const firstIdx = tspBridge.best_route[0]
                    bestRouteSeries.append(cities[firstIdx][0], cities[firstIdx][1])
                }
            }
        }
    }
}