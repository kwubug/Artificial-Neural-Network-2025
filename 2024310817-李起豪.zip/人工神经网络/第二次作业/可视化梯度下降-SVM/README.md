# 可视化梯度下降 - 非线性 SVM（三种梯度下降算法）

本项目基于《参考书1》第 9 章 9.2 节“非线性支持向量机”的内容，借助随机傅里叶特征近似 RBF 核，将二维非线性数据映射到高维空间，随后在软间隔 SVM 的原始形式上应用三种不同的梯度下降策略，并输出训练过程的可视化结果。

## 目录结构

```
非线性 SVM 可视化
├── nonlinear_svm_visualization.py  # 主程序
├── loss_curves.png                 # 三种算法的损失对比曲线
├── decision_boundary_*.png         # 各算法的决策边界可视化
├── summary.txt                     # 关键指标与训练时间汇总
└── README.md                       # 使用说明与实现细节（当前文件）
```

## 数据与特征映射

- 使用 `make_moons` 生成 240 个样本的二维非线性数据集，类别标签取值为 {-1, +1}。
- 采用随机傅里叶特征（Random Fourier Features）近似 RBF 核，特征数 250，`gamma=1.0`。
- 软间隔 SVM 的目标函数：

  \[
  \min_{w,b}\; \frac{1}{2}\|w\|^2 + C \cdot \frac{1}{n}\sum_{i=1}^n \max(0, 1 - y_i (w^\top z_i + b))
  \]

  其中 \(z_i\) 为随机傅里叶特征映射后的样本，`C = 1.5`。

## 三种梯度下降策略

1. **Batch Gradient Descent (GD)**：每轮迭代使用全部样本计算梯度，学习率 0.08。
2. **Stochastic Gradient Descent (SGD)**：逐样本更新参数，学习率 0.01。
3. **Mini-batch Gradient Descent (MBGD)**：批量大小 32，学习率 0.05。

所有算法训练 120 轮，并在若干关键 epoch 保存模型快照以绘制决策边界。最终实际可获得的精度在 87% 左右，符合非线性数据上的软间隔 SVM 表现。

## 运行方式

1. 确保已安装 `numpy`、`matplotlib`（Anaconda/Miniconda 默认已包含）。
2. 在当前目录执行：

   ```bash
   python nonlinear_svm_visualization.py
   ```

3. 程序会在同级目录生成：
   - `loss_curves.png`：三种算法的损失对比曲线；
   - `decision_boundary_*.png`：三种算法最终的决策边界与样本分布；
   - `summary.txt`：包含超参数、收敛损失、分类精度及训练耗时。

## 可视化示例

- **损失曲线**：对比三种梯度下降策略的收敛速度与稳定性；
- **决策边界**：展示随机傅里叶特征 + SVM 在非线性样本上的判别能力；
- **summary.txt**：便于撰写实验报告或作业总结。

## 扩展建议

- 调整 `gamma`、随机特征数或 `C` 观察对收敛的影响；
- 增加动量、Adam 等优化器与三种梯度下降策略对比；
- 替换数据集（如双环、XOR）以验证模型的非线性表达能力。

如需进一步嵌入 GUI 或结合其它可视化沙箱，可在此基础上接入 PyQt5 或交互式 Dash/Streamlit 前端。


