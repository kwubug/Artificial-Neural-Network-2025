"""
梯度下降可视化软件 - 主程序
支持三种优化算法：
1. 最速下降法
2. 牛顿法  
3. 共轭梯度法
"""

import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QComboBox, QPushButton, QLabel, 
                             QLineEdit, QSpinBox, QDoubleSpinBox, QGroupBox,
                             QFormLayout, QTextEdit)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib import cm
plt.rcParams["font.sans-serif"] = ["SimHei"]  # 设置字体
plt.rcParams["axes.unicode_minus"] = False


import matplotlib as mpl
mpl.rcParams['font.family'] = ['Arial Unicode MS']  # Mac 系统通常都有这个字体
plt.rcParams['axes.unicode_minus'] = False
from optimization_algorithms import (SteepestDescent, NewtonMethod, 
                                     ConjugateGradient, TestFunctions)


class OptimizationVisualization(QMainWindow):
    """优化算法可视化主窗口"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
        
        # 当前优化路径
        self.current_path = None
        self.current_values = None
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle('梯度下降算法可视化软件')
        self.setGeometry(100, 100, 1400, 800)
        
        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        viz_layout = QVBoxLayout()
        
        # 等高线图
        self.contour_canvas = PlotCanvas(self, title='优化路径可视化')
        viz_layout.addWidget(self.contour_canvas)
        
        # 收敛曲线
        self.convergence_canvas = PlotCanvas(self, title='收敛曲线')
        viz_layout.addWidget(self.convergence_canvas)
        
        main_layout.addLayout(viz_layout, stretch=2)
        
    def create_control_panel(self):
        """创建控制面板"""
        panel = QWidget()
        layout = QVBoxLayout()
        panel.setLayout(layout)
        panel.setMaximumWidth(400)
        
        # 标题
        title = QLabel('梯度下降算法可视化')
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet('font-size: 18px; font-weight: bold; margin: 10px;')
        layout.addWidget(title)
        
        # 算法选择
        algo_group = QGroupBox('算法选择')
        algo_layout = QFormLayout()
        
        self.algo_combo = QComboBox()
        self.algo_combo.addItems(['最速下降法', '牛顿法', '共轭梯度法'])
        algo_layout.addRow('优化算法:', self.algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group)
        
        # 函数选择
        func_group = QGroupBox('测试函数')
        func_layout = QFormLayout()
        
        self.func_combo = QComboBox()
        self.func_combo.addItems([
            'Rosenbrock函数',
            '二次函数',
            'Beale函数',
            'Booth函数'
        ])
        self.func_combo.currentIndexChanged.connect(self.on_function_changed)
        func_layout.addRow('目标函数:', self.func_combo)
        
        func_group.setLayout(func_layout)
        layout.addWidget(func_group)
        
        # 初始点设置
        init_group = QGroupBox('初始点设置')
        init_layout = QFormLayout()
        
        self.x0_input = QDoubleSpinBox()
        self.x0_input.setRange(-10, 10)
        self.x0_input.setValue(-1.5)
        self.x0_input.setSingleStep(0.1)
        init_layout.addRow('x0:', self.x0_input)
        
        self.y0_input = QDoubleSpinBox()
        self.y0_input.setRange(-10, 10)
        self.y0_input.setValue(2.5)
        self.y0_input.setSingleStep(0.1)
        init_layout.addRow('y0:', self.y0_input)
        
        init_group.setLayout(init_layout)
        layout.addWidget(init_group)
        
        # 参数设置
        param_group = QGroupBox('优化参数')
        param_layout = QFormLayout()
        
        self.max_iter_input = QSpinBox()
        self.max_iter_input.setRange(10, 1000)
        self.max_iter_input.setValue(100)
        param_layout.addRow('最大迭代次数:', self.max_iter_input)
        
        self.tol_input = QDoubleSpinBox()
        self.tol_input.setRange(1e-10, 1e-2)
        self.tol_input.setValue(1e-6)
        self.tol_input.setDecimals(10)
        self.tol_input.setSingleStep(1e-7)
        param_layout.addRow('收敛容差:', self.tol_input)
        
        param_group.setLayout(param_layout)
        layout.addWidget(param_group)
        
        # 运行按钮
        self.run_button = QPushButton('运行优化')
        self.run_button.setStyleSheet('font-size: 14px; padding: 10px; background-color: #4CAF50; color: white;')
        self.run_button.clicked.connect(self.run_optimization)
        layout.addWidget(self.run_button)
        
        # 结果显示
        result_group = QGroupBox('优化结果')
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setMaximumHeight(200)
        result_layout.addWidget(self.result_text)
        
        result_group.setLayout(result_layout)
        layout.addWidget(result_group)
        
        layout.addStretch()
        
        return panel
    
    def on_function_changed(self, index):
        """当选择的函数改变时，更新推荐的初始点"""
        if index == 0:  # Rosenbrock
            self.x0_input.setValue(-1.5)
            self.y0_input.setValue(2.5)
        elif index == 1:  # Quadratic
            self.x0_input.setValue(5.0)
            self.y0_input.setValue(5.0)
        elif index == 2:  # Beale
            self.x0_input.setValue(1.0)
            self.y0_input.setValue(1.0)
        elif index == 3:  # Booth
            self.x0_input.setValue(0.0)
            self.y0_input.setValue(0.0)
    
    def get_function_info(self):
        """获取选定的函数信息"""
        func_name = self.func_combo.currentText()
        
        if func_name == 'Rosenbrock函数':
            return (TestFunctions.rosenbrock, 
                    TestFunctions.rosenbrock_grad,
                    TestFunctions.rosenbrock_hessian,
                    (-2, 2), (-1, 3))
        elif func_name == '二次函数':
            return (TestFunctions.quadratic,
                    TestFunctions.quadratic_grad,
                    TestFunctions.quadratic_hessian,
                    (-10, 10), (-10, 10))
        elif func_name == 'Beale函数':
            return (TestFunctions.beale,
                    TestFunctions.beale_grad,
                    TestFunctions.beale_hessian,
                    (-4.5, 4.5), (-4.5, 4.5))
        elif func_name == 'Booth函数':
            return (TestFunctions.booth,
                    TestFunctions.booth_grad,
                    TestFunctions.booth_hessian,
                    (-10, 10), (-10, 10))
    
    def run_optimization(self):
        """运行优化算法"""
        try:
            # 获取参数
            algo_name = self.algo_combo.currentText()
            x0 = np.array([self.x0_input.value(), self.y0_input.value()])
            max_iter = self.max_iter_input.value()
            tol = self.tol_input.value()
            
            # 获取函数信息
            func, grad, hessian, x_range, y_range = self.get_function_info()
            
            # 创建优化器
            if algo_name == '最速下降法':
                optimizer = SteepestDescent(func, grad)
            elif algo_name == '牛顿法':
                optimizer = NewtonMethod(func, grad, hessian)
            elif algo_name == '共轭梯度法':
                optimizer = ConjugateGradient(func, grad)
            
            # 运行优化
            path, values = optimizer.optimize(x0, max_iter, tol)
            
            self.current_path = path
            self.current_values = values
            
            # 显示结果
            result_text = f"算法: {algo_name}\n"
            result_text += f"迭代次数: {len(path)}\n"
            result_text += f"初始点: ({x0[0]:.4f}, {x0[1]:.4f})\n"
            result_text += f"初始函数值: {values[0]:.6f}\n"
            result_text += f"最终点: ({path[-1][0]:.4f}, {path[-1][1]:.4f})\n"
            result_text += f"最终函数值: {values[-1]:.6f}\n"
            result_text += f"梯度范数: {np.linalg.norm(grad(path[-1])):.6e}\n"
            
            self.result_text.setText(result_text)
            
            # 更新可视化
            self.update_visualization(func, path, values, x_range, y_range)
            
        except Exception as e:
            self.result_text.setText(f"错误: {str(e)}")
    
    def update_visualization(self, func, path, values, x_range, y_range):
        """更新可视化"""
        # 更新等高线图
        self.contour_canvas.plot_contour(func, path, x_range, y_range)
        
        # 更新收敛曲线
        self.convergence_canvas.plot_convergence(values)


class PlotCanvas(FigureCanvas):
    """绘图画布"""
    
    def __init__(self, parent=None, title=''):
        self.fig = Figure(figsize=(8, 6))
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)
        self.title = title
        
    def plot_contour(self, func, path, x_range, y_range):
        """绘制等高线图和优化路径"""
        self.axes.clear()
        
        # 创建网格
        x = np.linspace(x_range[0], x_range[1], 200)
        y = np.linspace(y_range[0], y_range[1], 200)
        X, Y = np.meshgrid(x, y)
        Z = np.zeros_like(X)
        
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                Z[i, j] = func(np.array([X[i, j], Y[i, j]]))
        
        # 绘制等高线
        levels = np.logspace(-1, 3, 20)
        contour = self.axes.contour(X, Y, Z, levels=levels, alpha=0.6)
        self.axes.clabel(contour, inline=True, fontsize=8)
        
        # 绘制优化路径
        path_array = np.array(path)
        self.axes.plot(path_array[:, 0], path_array[:, 1], 
                      'ro-', linewidth=2, markersize=6, label='优化路径')
        
        # 标记起点和终点
        self.axes.plot(path_array[0, 0], path_array[0, 1], 
                      'go', markersize=12, label='起点')
        self.axes.plot(path_array[-1, 0], path_array[-1, 1], 
                      'r*', markersize=15, label='终点')
        
        self.axes.set_xlabel('x', fontsize=12)
        self.axes.set_ylabel('y', fontsize=12)
        self.axes.set_title(self.title, fontsize=14)
        self.axes.legend()
        self.axes.grid(True, alpha=0.3)
        
        self.draw()
    
    def plot_convergence(self, values):
        """绘制收敛曲线"""
        self.axes.clear()
        
        iterations = range(len(values))
        self.axes.semilogy(iterations, values, 'b-o', linewidth=2, markersize=4)
        
        self.axes.set_xlabel('迭代次数', fontsize=12)
        self.axes.set_ylabel('目标函数值 (对数尺度)', fontsize=12)
        self.axes.set_title('收敛曲线', fontsize=14)
        self.axes.grid(True, alpha=0.3)
        
        self.draw()


def main():
    """主函数"""
    app = QApplication(sys.argv)
    window = OptimizationVisualization()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

