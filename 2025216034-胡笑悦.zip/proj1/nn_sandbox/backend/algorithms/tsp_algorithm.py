import numpy as np
import math
import threading
from .base_algorithm import TraningAlgorithm


class TspAlgorithm(TraningAlgorithm):
    """
    Simple TSP solver using iterative 2-opt improvements on a single tour.
    - dataset: array-like of shape (N, 2) representing city coordinates
    - total_epoches: number of outer iterations to attempt improvements
    """
    def __init__(self, dataset, total_epoches=500):
        super().__init__(dataset, total_epoches)
        self.current_iterations = 0
        self._num_cities = len(self._dataset)
        self._tour = None  # list of indices
        self._best_tour = None
        self._distance = float('inf')
        self._best_distance = float('inf')
        self._distance_history = []
        self._positions = self._dataset.astype(float) if self._num_cities > 0 else np.zeros((0, 2), dtype=float)

    def run(self):
        self._initialize()
        for iteration in range(self._total_epoches):
            if self._should_stop:
                break
            self.current_iterations = iteration
            self._iterate()

    def _initialize(self):
        if self._num_cities == 0:
            self._tour = []
            self._best_tour = []
            self._distance = 0.0
            self._best_distance = 0.0
            self._distance_history = []
            return
        self._tour = np.random.permutation(self._num_cities).tolist()
        self._distance = self._tour_length(self._tour)
        self._best_tour = list(self._tour)
        self._best_distance = self._distance
        self._distance_history = [float(self._distance)]

    def _iterate(self):
        """
        Perform one 2-opt attempt; accept improvement if found.
        """
        if self._num_cities < 4:
            # Nothing meaningful to improve
            self._distance_history.append(float(self._distance))
            return
        i, k = self._random_two_opt_indices(self._num_cities)
        new_tour = self._two_opt_swap(self._tour, i, k)
        new_distance = self._tour_length(new_tour)
        if new_distance < self._distance:
            self._tour = new_tour
            self._distance = new_distance
            if new_distance < self._best_distance:
                self._best_distance = new_distance
                self._best_tour = list(new_tour)
        self._distance_history.append(float(self._distance))

    def _tour_length(self, tour):
        if not tour:
            return 0.0
        length = 0.0
        for idx in range(len(tour)):
            a = tour[idx]
            b = tour[(idx + 1) % len(tour)]
            pa = self._positions[a]
            pb = self._positions[b]
            length += math.hypot(pa[0] - pb[0], pa[1] - pb[1])
        return length

    @staticmethod
    def _two_opt_swap(tour, i, k):
        """
        Reverse tour segment between i and k inclusive.
        """
        if i > k:
            i, k = k, i
        return tour[:i] + list(reversed(tour[i:k + 1])) + tour[k + 1:]

    @staticmethod
    def _random_two_opt_indices(n):
        i = np.random.randint(0, n - 1)
        k = np.random.randint(i + 1, n)
        return i, k

    @property
    def tour(self):
        return list(self._tour) if self._tour is not None else []

    @property
    def best_tour(self):
        return list(self._best_tour) if self._best_tour is not None else []

    @property
    def distance(self):
        return float(self._distance)

    @property
    def best_distance(self):
        return float(self._best_distance)

    @property
    def distance_history(self):
        return list(self._distance_history)

    @property
    def positions(self):
        return self._positions.copy()