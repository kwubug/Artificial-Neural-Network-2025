import os
import sys

import PyQt5
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtQml import QQmlApplicationEngine
from PyQt5.QtWidgets import QApplication

from nn_sandbox.bridges import PerceptronBridge, MlpBridge, RbfnBridge, SomBridge, TspBridge
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'
    # XXX: Why I Have To Use QApplication instead of QGuiApplication? It seams
    # QGuiApplication cannot load QML Chart libs!
    app = QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'tspBridge': TspBridge()
    }

    dataset = nn_sandbox.backend.utils.read_data()

    for name, bridge in bridges.items():
        if name != 'tspBridge':
            bridge.dataset_dict = dataset
        engine.rootContext().setContextProperty(name, bridge)

    engine.load('./nn_sandbox/frontend/main.qml')
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())