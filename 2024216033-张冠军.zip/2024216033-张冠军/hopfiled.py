import numpy as np
import matplotlib.pyplot as plt
from itertools import product

class DiscreteHopfieldNetwork:
    """
    离散型Hopfield神经网络实现
    支持异步更新和能量计算
    """
    
    def __init__(self, n_neurons, zero_diagonal=True):
        """
        初始化网络
        :param n_neurons: 神经元数量
        :param zero_diagonal: 是否将权重对角线设为0
        """
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.zero_diagonal = zero_diagonal
    
    def train_hebbian(self, patterns):
        """
        使用Hebbian规则训练网络（外积和规则）
        :param patterns: 训练模式列表，每个模式是±1向量
        """
        patterns = np.array(patterns)
        n_patterns = patterns.shape[0]
        
        # Hebbian学习规则: w_ij = (1/N) * Σ pattern_i * pattern_j
        self.weights = patterns.T @ patterns / n_patterns
        
        # 对角线元素设为0（无自反馈）
        if self.zero_diagonal:
            np.fill_diagonal(self.weights, 0)
    
    def energy(self, state):
        """
        计算网络能量函数
        E = -0.5 * Σ_i Σ_j w_ij * s_i * s_j
        :param state: 当前网络状态
        :return: 能量值
        """
        state = np.array(state)
        return -0.5 * state @ self.weights @ state.T
    
    def update_async(self, state, max_iters=1000, random_order=True):
        """
        异步更新网络状态直到收敛
        :param state: 初始状态
        :param max_iters: 最大迭代次数
        :param random_order: 是否随机选择更新顺序
        :return: (最终状态, 收敛步数, 能量历史)
        """
        state = np.array(state).copy()
        energy_history = [self.energy(state)]
        
        for step in range(max_iters):
            old_state = state.copy()
            
            # 确定更新顺序
            if random_order:
                update_order = np.random.permutation(self.n_neurons)
            else:
                update_order = np.arange(self.n_neurons)
            
            # 逐个神经元异步更新
            for i in update_order:
                # 计算神经元i的净输入
                net_input = np.dot(self.weights[i, :], state)
                
                # 使用符号函数更新状态
                state[i] = 1 if net_input >= 0 else -1
            
            # 计算当前能量
            current_energy = self.energy(state)
            energy_history.append(current_energy)
            
            # 检查是否收敛
            if np.array_equal(state, old_state):
                return state, step + 1, energy_history
        
        return state, max_iters, energy_history
    
    def find_attractors(self):
        """
        穷举所有可能状态，找到网络的吸引子（能量极小值点）
        :return: (吸引子列表, 能量值列表, 状态-能量映射字典)
        """
        attractors = []
        energies = []
        state_energy_map = {}
        
        # 遍历所有可能状态 (2^n种)
        for bits in product([-1, 1], repeat=self.n_neurons):
            state = np.array(bits)
            current_energy = self.energy(state)
            state_energy_map[bits] = current_energy
            
            # 检查是否为吸引子：异步更新后状态不变
            final_state, _, _ = self.update_async(state, max_iters=1, random_order=False)
            
            if np.array_equal(state, final_state):
                attractors.append(state)
                energies.append(current_energy)
        
        return np.array(attractors), np.array(energies), state_energy_map
    
    def add_noise(self, pattern, noise_ratio):
        """
        向模式添加随机噪声
        :param pattern: 原始模式
        :param noise_ratio: 噪声比例 (0-1)
        :return: 带噪声的模式
        """
        pattern = np.array(pattern).copy()
        n_noise = int(len(pattern) * noise_ratio)
        noise_idx = np.random.choice(len(pattern), n_noise, replace=False)
        pattern[noise_idx] *= -1  # 翻转符号
        return pattern


# ==================== 演示示例 ====================
def demonstrate_hopfield():
    """完整演示：训练、添加噪声、恢复和能量分析"""
    
    print("="*50)
    print("离散型Hopfield神经网络演示")
    print("="*50)
    
    # 1. 定义训练模式（3个模式，每个8个神经元）
    # 每个模式应该是正交的或接近正交的
    patterns = [
        np.array([1, 1, 1, 1, -1, -1, -1, -1]),  # 模式A：前4个激活
        np.array([-1, -1, -1, -1, 1, 1, 1, 1]),  # 模式B：后4个激活
        np.array([1, -1, 1, -1, 1, -1, 1, -1])   # 模式C：交替激活
    ]
    
    n_neurons = len(patterns[0])
    print(f"\n神经元数量: {n_neurons}")
    print(f"训练模式数量: {len(patterns)}")
    
    # 2. 创建并训练网络
    hopfield = DiscreteHopfieldNetwork(n_neurons)
    hopfield.train_hebbian(patterns)
    
    print(f"\n权重矩阵:\n{hopfield.weights}")
    
    # 3. 计算并显示各训练模式的能量
    print("\n训练模式的能量:")
    for i, pattern in enumerate(patterns):
        energy = hopfield.energy(pattern)
        print(f"模式{i+1}: {energy:.2f}")
    
    # 4. 寻找网络的所有吸引子
    print("\n" + "="*50)
    print("寻找网络吸引子...")
    attractors, energies, state_map = hopfield.find_attractors()
    
    print(f"\n找到 {len(attractors)} 个吸引子:")
    for i, (att, eng) in enumerate(zip(attractors, energies)):
        print(f"吸引子 {i+1}: {att}  能量: {eng:.2f}")
    
    # 5. 测试模式恢复能力
    print("\n" + "="*50)
    print("测试模式恢复能力")
    
    # 选择第一个模式并添加噪声
    original_pattern = patterns[0]
    noisy_pattern = hopfield.add_noise(original_pattern.copy(), noise_ratio=0.3)
    
    print(f"\n原始模式: {original_pattern}")
    print(f"噪声模式: {noisy_pattern}")
    print(f"噪声比例: {np.mean(noisy_pattern != original_pattern):.1%}")
    
    # 异步更新恢复
    recovered_state, steps, energy_hist = hopfield.update_async(
        noisy_pattern, 
        max_iters=100, 
        random_order=True
    )
    
    print(f"\n恢复过程:")
    print(f"  收敛步数: {steps}")
    print(f"  最终状态: {recovered_state}")
    print(f"  是否匹配训练模式: {np.array_equal(recovered_state, original_pattern)}")
    print(f"  最终能量: {energy_hist[-1]:.2f}")
    
    # 6. 可视化能量变化
    plt.figure(figsize=(10, 6))
    plt.plot(energy_hist, 'b-o', linewidth=2, markersize=4)
    plt.xlabel('迭代次数', fontsize=12)
    plt.ylabel('网络能量', fontsize=12)
    plt.title('Hopfield网络能量收敛过程', fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.axhline(y=energies.min(), color='r', linestyle='--', label='最小能量')
    plt.legend()
    plt.tight_layout()
    plt.show()
    
    # 7. 验证吸引子稳定性
    print("\n" + "="*50)
    print("验证吸引子稳定性")
    
    for i, attractor in enumerate(attractors):
        # 从吸引子出发，看是否保持稳定
        final_state, steps, _ = hopfield.update_async(attractor, max_iters=10)
        is_stable = np.array_equal(attractor, final_state)
        print(f"吸引子 {i+1} 稳定性: {'✓' if is_stable else '✗'} (能量: {energies[i]:.2f})")
    
    print("\n" + "="*50)
    print("演示完成！")
    print("="*50)


# 运行演示
if __name__ == "__main__":
    # 设置随机种子保证可重复性
    np.random.seed(42)
    demonstrate_hopfield()