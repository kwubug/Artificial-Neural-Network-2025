import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from collections import defaultdict
import time

# 设置matplotlib使用TkAgg后端
import matplotlib

matplotlib.use('TkAgg')

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class BoltzmannMachine:
    def __init__(self, num_neurons=3):
        """
        初始化玻尔兹曼机
        """
        self.num_neurons = num_neurons

        # 初始化权重矩阵（对称，无自连接）
        self.weights = np.array([
            [0, 0.8, -0.5],
            [0.8, 0, 0.6],
            [-0.5, 0.6, 0]
        ])

        # 初始化偏置
        self.biases = np.array([0.2, -0.3, 0.1])

        # 初始化神经元状态（随机）
        self.states = np.random.choice([-1, 1], size=num_neurons)

        # 温度参数（模拟退火）
        self.temperature = 2.0
        self.min_temperature = 0.1
        self.cooling_rate = 0.995

        # 记录历史状态用于可视化
        self.state_history = [self.states.copy()]
        self.energy_history = [self.calculate_energy()]
        self.temperature_history = [self.temperature]

        # 状态计数（用于热平衡检测）
        self.state_counts = defaultdict(int)

        # 热平衡检测参数
        self.equilibrium_window = 50
        self.equilibrium_threshold = 0.7
        self.energy_stability_threshold = 0.1

    def calculate_energy(self):
        """
        计算系统的能量（哈密顿量）
        """
        energy = 0
        for i in range(self.num_neurons):
            for j in range(i + 1, self.num_neurons):
                energy -= self.weights[i, j] * self.states[i] * self.states[j]
            energy -= self.biases[i] * self.states[i]
        return energy

    def update_neuron(self, neuron_idx):
        """
        更新指定神经元的状态
        """
        total_input = 0
        for j in range(self.num_neurons):
            if j != neuron_idx:
                total_input += self.weights[neuron_idx, j] * self.states[j]
        total_input += self.biases[neuron_idx]

        prob_flip = 1 / (1 + np.exp(-2 * total_input / self.temperature))

        if np.random.random() < prob_flip:
            self.states[neuron_idx] = 1
        else:
            self.states[neuron_idx] = -1

    def step(self):
        """
        执行一步更新
        """
        update_order = np.random.permutation(self.num_neurons)
        for neuron_idx in update_order:
            self.update_neuron(neuron_idx)

        self.state_history.append(self.states.copy())
        self.energy_history.append(self.calculate_energy())

        if self.temperature > self.min_temperature:
            self.temperature *= self.cooling_rate
        self.temperature_history.append(self.temperature)

        state_key = tuple(self.states)
        self.state_counts[state_key] += 1

    def check_thermal_equilibrium(self):
        """
        改进的热平衡检测
        """
        if len(self.state_history) < self.equilibrium_window:
            return False

        # 检查状态稳定性
        recent_states = self.state_history[-self.equilibrium_window:]
        state_freq = defaultdict(int)

        for state in recent_states:
            state_freq[tuple(state)] += 1

        max_freq = max(state_freq.values()) if state_freq else 0
        state_stable = (max_freq / self.equilibrium_window) >= self.equilibrium_threshold

        # 检查能量稳定性
        recent_energies = self.energy_history[-self.equilibrium_window:]
        if len(recent_energies) > 1:
            energy_std = np.std(recent_energies)
            energy_stable = energy_std < self.energy_stability_threshold
        else:
            energy_stable = False

        # 检查温度是否足够低
        temperature_low = self.temperature < 0.5

        # 打印调试信息
        if len(self.state_history) % 50 == 0:
            print(f"Step {len(self.state_history) - 1}: "
                  f"Max state freq: {max_freq / self.equilibrium_window:.3f}, "
                  f"Energy std: {energy_std if len(recent_energies) > 1 else 0:.3f}, "
                  f"Temp: {self.temperature:.3f}")

        # 热平衡条件：状态稳定 或 (能量稳定且温度足够低)
        return state_stable or (energy_stable and temperature_low)

    def get_state_probability(self):
        """
        计算当前各状态的估计概率
        """
        total_steps = len(self.state_history)
        state_probs = {}

        for state, count in self.state_counts.items():
            state_probs[state] = count / total_steps

        return state_probs


class BoltzmannVisualizer:
    def __init__(self, bm):
        self.bm = bm
        self.fig = plt.figure(figsize=(15, 10))
        self.setup_layout()
        self.is_running = True
        self.step_count = 0

    def setup_layout(self):
        gs = gridspec.GridSpec(3, 3, figure=self.fig)

        self.ax_states = self.fig.add_subplot(gs[0, 0])
        self.ax_network = self.fig.add_subplot(gs[0, 1])
        self.ax_energy = self.fig.add_subplot(gs[1, :])
        self.ax_probability = self.fig.add_subplot(gs[2, 0])
        self.ax_temperature = self.fig.add_subplot(gs[2, 1])
        self.ax_weights = self.fig.add_subplot(gs[2, 2])

        self.fig.suptitle('玻尔兹曼机可视化沙箱 - 改进的热平衡检测', fontsize=16, fontweight='bold')
        plt.tight_layout()

    def safe_set_limits(self, ax, x_min, x_max, y_min, y_max):
        """
        安全设置坐标轴范围，避免left >= right错误
        """
        try:
            # 确保x轴范围有效
            if np.isnan(x_min) or np.isnan(x_max) or x_min >= x_max:
                x_min, x_max = 0, 1

            # 确保y轴范围有效
            if np.isnan(y_min) or np.isnan(y_max) or y_min >= y_max:
                y_min, y_max = -1, 1

            ax.set_xlim(x_min, x_max)
            ax.set_ylim(y_min, y_max)
        except Exception as e:
            print(f"设置坐标轴范围时出错: {e}")
            # 使用默认范围
            ax.set_xlim(0, 1)
            ax.set_ylim(-1, 1)

    def update_all_plots(self):
        try:
            self.bm.step()
            self.step_count += 1

            self.plot_neuron_states()
            self.plot_network()
            self.plot_energy()
            self.plot_probability_distribution()
            self.plot_temperature()
            self.plot_weights()

            # 改进的热平衡检测
            if self.bm.check_thermal_equilibrium():
                equilibrium_state = self.bm.state_history[-1]
                state_probs = self.bm.get_state_probability()
                max_prob_state = max(state_probs, key=state_probs.get) if state_probs else equilibrium_state
                max_prob = state_probs[max_prob_state] if state_probs else 0

                self.ax_states.set_title(
                    f'神经元状态 - 已达到热平衡!\n'
                    f'稳定状态: {equilibrium_state}, 最大概率: {max_prob:.3f}',
                    color='red', fontweight='bold'
                )
                self.is_running = False

                # 在控制台输出详细信息
                print(f"\n=== 热平衡达成 ===")
                print(f"步数: {self.step_count}")
                print(f"最终状态: {equilibrium_state}")
                print(f"最终温度: {self.bm.temperature:.3f}")
                print(f"最终能量: {self.bm.energy_history[-1]:.3f}")
                if state_probs:
                    print(f"状态概率分布:")
                    for state, prob in sorted(state_probs.items(), key=lambda x: x[1], reverse=True):
                        print(f"  {state}: {prob:.3f}")

        except Exception as e:
            print(f"更新图形时出错: {e}")
            # 继续运行，不停止模拟

    def plot_neuron_states(self):
        try:
            self.ax_states.clear()
            states_array = np.array(self.bm.state_history)

            colors = ['red', 'blue', 'green']
            labels = ['神经元 0', '神经元 1', '神经元 2']

            for i in range(self.bm.num_neurons):
                self.ax_states.plot(states_array[:, i],
                                    color=colors[i], label=labels[i], linewidth=2)
                self.ax_states.scatter(len(states_array) - 1, states_array[-1, i],
                                       color=colors[i], s=50, zorder=5)

            status = "运行中" if self.is_running else "已稳定"
            self.ax_states.set_title(f'神经元状态 ({status}) - 步数: {self.step_count}')
            self.ax_states.set_xlabel('时间步')
            self.ax_states.set_ylabel('状态 (-1/1)')

            # 安全设置坐标轴范围
            x_min, x_max = 0, max(1, len(states_array) - 1)
            self.safe_set_limits(self.ax_states, x_min, x_max, -1.5, 1.5)

            self.ax_states.legend()
            self.ax_states.grid(True, alpha=0.3)
        except Exception as e:
            print(f"绘制神经元状态时出错: {e}")

    def plot_energy(self):
        try:
            self.ax_energy.clear()

            if len(self.bm.energy_history) > 1:
                energy_values = self.bm.energy_history
                time_steps = list(range(len(energy_values)))

                self.ax_energy.plot(time_steps, energy_values, color='purple', linewidth=2)
                self.ax_energy.scatter(time_steps[-1], energy_values[-1],
                                       color='purple', s=50, zorder=5)

                # 安全计算能量范围
                energy_min = min(energy_values) if energy_values else -1
                energy_max = max(energy_values) if energy_values else 1

                # 如果所有能量值相同，添加一些偏移
                if energy_min == energy_max:
                    energy_min -= 0.1
                    energy_max += 0.1

                # 安全设置坐标轴范围
                x_min, x_max = 0, max(1, len(energy_values) - 1)
                self.safe_set_limits(self.ax_energy, x_min, x_max, energy_min, energy_max)

                # 计算能量稳定性
                if len(energy_values) >= 10:
                    recent_energy_std = np.std(energy_values[-10:])
                    self.ax_energy.text(0.02, 0.98, f'当前能量: {energy_values[-1]:.3f}\n近期波动: {recent_energy_std:.3f}',
                                        transform=self.ax_energy.transAxes, fontsize=10,
                                        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

            self.ax_energy.set_title('系统能量变化')
            self.ax_energy.set_xlabel('时间步')
            self.ax_energy.set_ylabel('能量')
            self.ax_energy.grid(True, alpha=0.3)
        except Exception as e:
            print(f"绘制能量图时出错: {e}")

    def plot_network(self):
        try:
            self.ax_network.clear()
            angles = np.linspace(0, 2 * np.pi, self.bm.num_neurons, endpoint=False)
            radius = 1
            x = radius * np.cos(angles)
            y = radius * np.sin(angles)

            for i in range(self.bm.num_neurons):
                for j in range(i + 1, self.bm.num_neurons):
                    weight = self.bm.weights[i, j]
                    color = 'red' if weight > 0 else 'blue'
                    linewidth = abs(weight) * 3
                    self.ax_network.plot([x[i], x[j]], [y[i], y[j]],
                                         color=color, linewidth=linewidth, alpha=0.6)

                    mid_x, mid_y = (x[i] + x[j]) / 2, (y[i] + y[j]) / 2
                    self.ax_network.text(mid_x, mid_y, f'{weight:.1f}',
                                         fontsize=8, ha='center', va='center',
                                         bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

            for i, (xi, yi) in enumerate(zip(x, y)):
                color = 'lightcoral' if self.bm.states[i] == 1 else 'lightblue'
                self.ax_network.scatter(xi, yi, s=500, c=color, edgecolors='black', linewidth=2)
                self.ax_network.text(xi, yi, f'N{i}\n({self.bm.states[i]})',
                                     ha='center', va='center', fontweight='bold')

            self.ax_network.set_title('神经网络结构')
            self.ax_network.set_aspect('equal')
            self.ax_network.axis('off')

            # 安全设置坐标轴范围
            self.safe_set_limits(self.ax_network, -1.5, 1.5, -1.5, 1.5)
        except Exception as e:
            print(f"绘制网络图时出错: {e}")

    def plot_probability_distribution(self):
        try:
            self.ax_probability.clear()
            state_probs = self.bm.get_state_probability()

            if state_probs and len(state_probs) > 0:
                states = list(state_probs.keys())
                probabilities = list(state_probs.values())

                state_labels = [f'{state}' for state in states]

                bars = self.ax_probability.bar(state_labels, probabilities,
                                               color='skyblue', edgecolor='navy')

                for bar, prob in zip(bars, probabilities):
                    height = bar.get_height()
                    self.ax_probability.text(bar.get_x() + bar.get_width() / 2., height + 0.01,
                                             f'{prob:.3f}', ha='center', va='bottom', fontsize=8)

                # 安全设置y轴范围
                x_min, x_max = -0.5, len(state_labels) - 0.5
                y_min, y_max = 0, 1
                self.safe_set_limits(self.ax_probability, x_min, x_max, y_min, y_max)

                self.ax_probability.set_title('状态概率分布')
                self.ax_probability.set_ylabel('概率')
                self.ax_probability.tick_params(axis='x', rotation=45)
                self.ax_probability.grid(True, alpha=0.3)
            else:
                self.ax_probability.text(0.5, 0.5, '收集数据中...',
                                         ha='center', va='center', transform=self.ax_probability.transAxes)
                self.ax_probability.set_title('状态概率分布')
                # 安全设置默认范围
                self.safe_set_limits(self.ax_probability, -0.5, 0.5, 0, 1)
        except Exception as e:
            print(f"绘制概率分布图时出错: {e}")

    def plot_temperature(self):
        try:
            self.ax_temperature.clear()

            if len(self.bm.temperature_history) > 1:
                temp_values = self.bm.temperature_history
                time_steps = list(range(len(temp_values)))

                self.ax_temperature.plot(time_steps, temp_values, color='orange', linewidth=2)
                self.ax_temperature.scatter(time_steps[-1], temp_values[-1],
                                            color='orange', s=50, zorder=5)

                # 安全计算温度范围
                temp_min = min(temp_values) if temp_values else 0
                temp_max = max(temp_values) if temp_values else 2

                # 如果所有温度值相同，添加一些偏移
                if temp_min == temp_max:
                    temp_min -= 0.1
                    temp_max += 0.1

                # 安全设置坐标轴范围
                x_min, x_max = 0, max(1, len(temp_values) - 1)
                self.safe_set_limits(self.ax_temperature, x_min, x_max, temp_min, temp_max)

                current_temp = temp_values[-1]
                self.ax_temperature.text(0.02, 0.98, f'当前温度: {current_temp:.3f}',
                                         transform=self.ax_temperature.transAxes, fontsize=10,
                                         bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

            self.ax_temperature.set_title('温度变化 (模拟退火)')
            self.ax_temperature.set_xlabel('时间步')
            self.ax_temperature.set_ylabel('温度')
            self.ax_temperature.grid(True, alpha=0.3)
        except Exception as e:
            print(f"绘制温度图时出错: {e}")

    def plot_weights(self):
        try:
            self.ax_weights.clear()
            im = self.ax_weights.imshow(self.bm.weights, cmap='coolwarm',
                                        vmin=-1, vmax=1, aspect='equal')

            for i in range(self.bm.num_neurons):
                for j in range(self.bm.num_neurons):
                    self.ax_weights.text(j, i, f'{self.bm.weights[i, j]:.1f}',
                                         ha="center", va="center", color="black", fontweight='bold')

            self.ax_weights.set_title('权重矩阵')
            self.ax_weights.set_xticks(range(self.bm.num_neurons))
            self.ax_weights.set_yticks(range(self.bm.num_neurons))
            self.ax_weights.set_xticklabels(['N0', 'N1', 'N2'])
            self.ax_weights.set_yticklabels(['N0', 'N1', 'N2'])

            plt.colorbar(im, ax=self.ax_weights, shrink=0.8)

            # 安全设置坐标轴范围
            self.safe_set_limits(self.ax_weights, -0.5, self.bm.num_neurons - 0.5,
                                 -0.5, self.bm.num_neurons - 0.5)
        except Exception as e:
            print(f"绘制权重矩阵时出错: {e}")

    def run_simulation(self, max_steps=500, interval=0.3):
        plt.ion()
        plt.show()

        print("开始模拟...按Ctrl+C停止")
        print("热平衡检测参数:")
        print(f"  观察窗口: {self.bm.equilibrium_window} 步")
        print(f"  状态稳定性阈值: {self.bm.equilibrium_threshold}")
        print(f"  能量稳定性阈值: {self.bm.energy_stability_threshold}")

        try:
            for step in range(max_steps):
                if not self.is_running:
                    print(f"在步数 {step} 达到热平衡，模拟结束")
                    break

                self.update_all_plots()
                plt.draw()
                plt.pause(interval)

                if step % 50 == 0:
                    print(f"已运行 {step} 步，当前温度: {self.bm.temperature:.3f}")

        except KeyboardInterrupt:
            print("模拟被用户中断")
        except Exception as e:
            print(f"模拟过程中发生错误: {e}")
            print("尝试继续运行...")

        plt.ioff()

        if not self.bm.check_thermal_equilibrium():
            print(f"\n模拟结束！在 {max_steps} 步内未达到热平衡。")
            print("建议调整热平衡检测参数或增加最大步数。")

        print("关闭窗口以退出程序。")
        plt.show(block=True)


def main():
    print("初始化玻尔兹曼机...")
    print("改进的热平衡检测版本")

    bm = BoltzmannMachine(num_neurons=3)
    visualizer = BoltzmannVisualizer(bm)
    visualizer.run_simulation(max_steps=400, interval=0.2)


if __name__ == "__main__":
    main()