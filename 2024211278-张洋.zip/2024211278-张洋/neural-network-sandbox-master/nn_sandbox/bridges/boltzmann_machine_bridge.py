import PyQt5.QtCore

from nn_sandbox.backend.algorithms.boltzmann_machine_algorithm import BoltzmannMachineAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BoltzmannMachineBridge(Bridge):
    """
    玻尔兹曼机的桥接类，用于前端和后端交互
    """
    # 训练参数
    T0 = BridgeProperty(1.0)  # 初始温度
    alpha = BridgeProperty(0.995)  # 冷却速率
    max_iter = BridgeProperty(1000)  # 最大迭代次数
    update_freq = BridgeProperty(10)  # 更新频率
    ui_refresh_interval = BridgeProperty(0.05)  # UI刷新间隔
    
    # 初始状态
    init_v1 = BridgeProperty(0)
    init_v2 = BridgeProperty(0)
    init_v3 = BridgeProperty(0)
    
    # 运行时状态
    has_finished = BridgeProperty(True)
    current_iter = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    current_temperature = BridgeProperty(1.0)
    
    # 当前神经元状态
    current_state = BridgeProperty([0, 0, 0])
    
    # 历史数据（用于可视化）
    energy_history = BridgeProperty([])
    temperature_history = BridgeProperty([])
    detailed_history = BridgeProperty([])  # 详细历史记录（用于表格显示）
    
    @PyQt5.QtCore.pyqtSlot()
    def start(self):
        self.has_finished = False
        initial_state = [self.init_v1, self.init_v2, self.init_v3]
        
        self._algo = ObservableBoltzmannMachineAlgorithm(
            self,
            T0=self.T0,
            alpha=self.alpha,
            max_iter=self.max_iter,
            update_freq=self.update_freq,
            ui_refresh_interval=self.ui_refresh_interval,
            initial_state=initial_state
        )
        self._algo.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop(self):
        if hasattr(self, '_algo') and self._algo:
            self._algo.stop()


class ObservableBoltzmannMachineAlgorithm(Observable, BoltzmannMachineAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        BoltzmannMachineAlgorithm.__init__(self, **kwargs)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ('current_state', 'energy_history', 'temperature_history', 'detailed_history') and value is not None:
            self.notify(name, value.tolist() if hasattr(value, 'tolist') else list(value))
        elif name in ('current_iter', 'current_energy', 'current_temperature', 'has_finished'):
            self.notify(name, value)

