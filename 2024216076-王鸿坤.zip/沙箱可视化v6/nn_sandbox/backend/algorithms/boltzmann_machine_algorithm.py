import math
from typing import List

import numpy as np

from . import TraningAlgorithm


class BoltzmannMachineAlgorithm(TraningAlgorithm):
    """
    Simulate a fully connected Boltzmann Machine with a tiny (3 neuron) network.
    The algorithm performs asynchronous Gibbs sampling with an exponential
    cooling schedule until the system reaches thermal equilibrium or the
    maximum number of iterations is exhausted.
    """

    def __init__(
        self,
        weight_matrix: List[List[float]],
        bias_vector: List[float],
        initial_state: List[int],
        total_iterations: int,
        initial_temperature: float,
        cooling_rate: float,
        min_temperature: float,
        stability_window: int = 4,
    ):
        super().__init__([initial_state], total_iterations)
        self._weight_matrix = self._sanitize_weight_matrix(weight_matrix)
        self._bias_vector = np.array(bias_vector, dtype=float)
        self._state = np.array(initial_state, dtype=int)
        self._total_iterations = max(1, total_iterations)
        self._initial_temperature = max(initial_temperature, 1e-4)
        self._cooling_rate = np.clip(cooling_rate, 0.01, 0.9999)
        self._min_temperature = max(min_temperature, 1e-4)
        self._stability_window = max(3, stability_window)

        self.current_iterations = 0
        self.current_temperature = self._initial_temperature
        self.current_energy = self.calculate_energy()
        self.state_history = []
        self.equilibrium_state = None
        self.equilibrium_iteration = -1

        # record the initial state so the UI can visualize the starting point
        self._record_snapshot()

    def run(self):
        for iteration in range(1, self._total_iterations + 1):
            if self._should_stop:
                break

            self.current_iterations = iteration
            self._gibbs_sample_step()
            self.current_energy = self.calculate_energy()
            snapshot = self._record_snapshot()

            if self._reached_equilibrium():
                self.equilibrium_state = snapshot['state']
                self.equilibrium_iteration = snapshot['iteration']
                break

            self._cool_down()

        # If equilibrium wasn't detected explicitly, treat the final state as equilibrium.
        if self.equilibrium_state is None:
            last_state = self.state_history[-1]
            self.equilibrium_state = last_state['state']
            self.equilibrium_iteration = last_state['iteration']

    def stop(self):
        super().stop()

    @property
    def neuron_state(self):
        return self._state.tolist()

    def calculate_energy(self):
        state = self._state.astype(float)
        quadratic_term = -0.5 * state @ self._weight_matrix @ state.T
        linear_term = -self._bias_vector @ state
        return float(quadratic_term + linear_term)

    def _gibbs_sample_step(self):
        indices = np.arange(len(self._state))
        np.random.shuffle(indices)
        safe_temperature = max(self.current_temperature, 1e-4)
        for neuron_idx in indices:
            total_input = np.dot(self._weight_matrix[neuron_idx], self._state) + self._bias_vector[neuron_idx]
            total_input -= self._weight_matrix[neuron_idx, neuron_idx] * self._state[neuron_idx]
            probability = self._sigmoid(total_input / safe_temperature)
            self._state[neuron_idx] = 1 if np.random.random() < probability else 0

    def _cool_down(self):
        cooled_temp = self.current_temperature * self._cooling_rate
        self.current_temperature = max(cooled_temp, self._min_temperature)

    def _record_snapshot(self):
        snapshot = {
            'iteration': self.current_iterations,
            'state': self.neuron_state,
            'energy': self.current_energy,
            'temperature': self.current_temperature,
        }
        self.state_history.append(snapshot)
        return snapshot

    def _reached_equilibrium(self):
        if len(self.state_history) < self._stability_window:
            return False

        latest_state = self.state_history[-1]['state']
        for snapshot in self.state_history[-self._stability_window:]:
            if snapshot['state'] != latest_state:
                return False
        return True

    @staticmethod
    def _sigmoid(value):
        value = float(value)
        # Prevent overflow for very large values
        if value >= 0:
            z = math.exp(-value)
            return 1 / (1 + z)
        z = math.exp(value)
        return z / (1 + z)

    @staticmethod
    def _sanitize_weight_matrix(matrix):
        array = np.array(matrix, dtype=float)
        size = array.shape[0]
        if array.shape != (size, size):
            raise ValueError("weight_matrix must be square")
        # Enforce symmetry for the energy function.
        array = (array + array.T) / 2.0
        np.fill_diagonal(array, 0.0)
        return array
