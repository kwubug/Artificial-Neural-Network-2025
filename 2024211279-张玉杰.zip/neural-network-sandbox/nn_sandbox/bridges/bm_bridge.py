import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.bm_algorithm import BoltzmannMachineAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BmBridge(Bridge):
    """
    Bridge for Boltzmann Machine visualization (3 neurons).
    """
    # Parameters
    W = BridgeProperty([[0.0, 0.55, 0.45],
                        [0.55, 0.0, 0.2],
                        [0.45, 0.2, 0.0]])
    theta = BridgeProperty([0.65, 0.3, 0.4])
    initial_state = BridgeProperty([0, 0, 0])
    T0 = BridgeProperty(5.0)
    gamma = BridgeProperty(0.8)
    steps_per_temp = BridgeProperty(1)
    max_iter = BridgeProperty(200)
    update_freq = BridgeProperty(5)
    ui_refresh_interval = BridgeProperty(0.01)

    # Live values
    has_finished = BridgeProperty(True)
    k = BridgeProperty(0)
    energy = BridgeProperty(0.0)
    temperature = BridgeProperty(0.0)
    x_state = BridgeProperty([])
    updated_neuron = BridgeProperty(-1)  # -1 means no neuron updated yet

    @PyQt5.QtCore.pyqtSlot()
    def start(self):
        # Reset state
        self.k = 0
        self.energy = 0.0
        self.temperature = 0.0
        self.x_state = []
        self.updated_neuron = -1
        self.has_finished = False
        # Create and start algorithm
        self._algo = ObservableBmAlgorithm(
            self,
            W=self.W,
            theta=self.theta,
            initial_state=self.initial_state,
            T0=self.T0, gamma=self.gamma,
            steps_per_temp=self.steps_per_temp,
            max_iter=self.max_iter,
            update_freq=self.update_freq,
            ui_refresh_interval=self.ui_refresh_interval
        )
        self._algo.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop(self):
        if hasattr(self, '_algo') and self._algo:
            self._algo.stop()


class ObservableBmAlgorithm(Observable, BoltzmannMachineAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        BoltzmannMachineAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'x' and hasattr(self, 'notify'):
            # Convert numpy array to list for QML
            if isinstance(value, np.ndarray):
                self.notify('x_state', value.tolist())
        elif name == 'k' and hasattr(self, 'notify'):
            self.notify('k', value)
        elif name == 'energy' and hasattr(self, 'notify'):
            self.notify('energy', value)
        elif name == 'T' and hasattr(self, 'notify'):
            self.notify('temperature', float(value))
        elif name == 'updated_neuron' and hasattr(self, 'notify'):
            self.notify('updated_neuron', int(value))
        elif name == 'has_finished' and hasattr(self, 'notify'):
            self.notify('has_finished', value)


