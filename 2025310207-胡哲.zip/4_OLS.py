import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# 中文字体支持
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# ------------------------------
# 1. 生成数据（50个样本）
# ------------------------------
np.random.seed(42)
X = 2 * np.random.rand(50, 1)
y = 4 + 3 * X + np.random.randn(50, 1)  # 带噪声线性数据

# ------------------------------
# 2. OLS解析解求权重
# ------------------------------
X_b = np.c_[np.ones((50, 1)), X]  # 添加偏置项 x0=1
theta_best = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)

print(f"OLS学习得到的参数: w0={theta_best[0][0]:.2f}, w1={theta_best[1][0]:.2f}")

# ------------------------------
# 3. 可视化回归结果
# ------------------------------
X_new = np.linspace(0, 2, 100).reshape(100, 1)
X_new_b = np.c_[np.ones((100, 1)), X_new]
y_predict = X_new_b.dot(theta_best)

plt.figure(figsize=(7,5))
plt.scatter(X, y, color='blue', label='训练数据')
plt.plot(X_new, y_predict, color='red', linewidth=2, label='OLS回归线')
plt.title('OLS可视化')
plt.xlabel('特征 X')
plt.ylabel('目标 y')
plt.legend()
plt.grid(True)
plt.show()

# ------------------------------
# 4. 误差分析可视化
# ------------------------------
y_pred_train = X_b.dot(theta_best)
residuals = y - y_pred_train

plt.figure(figsize=(6,4))
plt.scatter(y_pred_train, residuals, c='purple')
plt.axhline(0, color='red', linestyle='--')
plt.title('残差分布图')
plt.xlabel('预测值')
plt.ylabel('残差')
plt.grid(True)
plt.show()