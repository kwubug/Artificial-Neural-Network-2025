import time
import numpy as np
import PyQt5.QtCore
import threading

from nn_sandbox.backend.algorithms import HopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldBridge(Bridge):
    # 网络参数
    patterns = BridgeProperty([])  # 存储的模式
    n_neurons = BridgeProperty(0)  # 神经元数量
    max_iterations = BridgeProperty(100)
    ui_refresh_interval = BridgeProperty(0.05)
    
    # 当前状态
    current_state = BridgeProperty([])
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    is_converged = BridgeProperty(False)
    
    # 权重矩阵
    weights = BridgeProperty([])
    
    # 吸引子
    attractors = BridgeProperty([])
    attractor_energies = BridgeProperty([])
    n_attractors_found = BridgeProperty(0)
    
    # 历史记录
    state_history = BridgeProperty([])
    energy_history = BridgeProperty([])
    
    # 状态
    has_finished = BridgeProperty(True)
    
    def __init__(self):
        super().__init__()
        self.hopfield_algorithm = None
        self._init_default_patterns()
    
    def _init_default_patterns(self):
        """初始化默认模式（简单的图案）"""
        # 5x5的图案
        pattern1 = [1, 1, 1, 1, 1,
                   1, -1, -1, -1, 1,
                   1, -1, -1, -1, 1,
                   1, -1, -1, -1, 1,
                   1, 1, 1, 1, 1]  # 方框
        
        pattern2 = [-1, -1, 1, -1, -1,
                   -1, 1, 1, 1, -1,
                   1, 1, 1, 1, 1,
                   -1, -1, 1, -1, -1,
                   -1, -1, 1, -1, -1]  # 十字
        
        pattern3 = [1, -1, -1, -1, 1,
                   -1, 1, -1, 1, -1,
                   -1, -1, 1, -1, -1,
                   -1, 1, -1, 1, -1,
                   1, -1, -1, -1, 1]  # X形
        
        self.patterns = [pattern1, pattern2, pattern3]
        self.n_neurons = 25
    
    @PyQt5.QtCore.pyqtSlot(list)
    def set_patterns(self, patterns):
        """设置要存储的模式"""
        self.patterns = patterns
        if len(patterns) > 0:
            self.n_neurons = len(patterns[0])
    
    @PyQt5.QtCore.pyqtSlot(list)
    def start_recognition(self, initial_state):
        """开始模式识别"""
        print(f"开始模式识别，初始状态: {initial_state}")
        self.hopfield_algorithm = ObservableHopfieldAlgorithm(
            self,
            self.ui_refresh_interval,
            patterns=self.patterns,
            max_iterations=self.max_iterations
        )
        self.hopfield_algorithm.set_initial_state(initial_state)
        self.hopfield_algorithm.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def find_attractors(self):
        """寻找吸引子"""
        print("Bridge: find_attractors 被调用")
        
        # 在新线程中执行寻找吸引子任务
        def find_in_thread():
            self.has_finished = False
            
            # 创建临时算法实例
            temp_algo = HopfieldAlgorithm(
                patterns=self.patterns,
                max_iterations=self.max_iterations
            )
            
            # 训练网络
            temp_algo._initialize_neurons()
            print(f"权重矩阵已计算，形状: {temp_algo.weights.shape}")
            
            # 寻找吸引子
            temp_algo.find_attractors(n_trials=50)
            
            print(f"找到 {len(temp_algo.attractors)} 个吸引子")
            print(f"能量值样例: {temp_algo.attractor_energies[:5]}")
            
            # 通知到界面
            self.attractors = [a.tolist() for a in temp_algo.attractors]
            self.attractor_energies = temp_algo.attractor_energies
            self.n_attractors_found = len(temp_algo.attractors)
            self.weights = temp_algo.weights.tolist()
            
            self.has_finished = True
            print("寻找吸引子完成")
        
        thread = threading.Thread(target=find_in_thread, daemon=True)
        thread.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def train_network(self):
        """训练网络（计算权重矩阵）"""
        print("训练网络被调用")
        self.has_finished = False
        
        temp_algo = HopfieldAlgorithm(
            patterns=self.patterns,
            max_iterations=self.max_iterations
        )
        temp_algo._initialize_neurons()
        
        self.weights = temp_algo.weights.tolist()
        print(f"权重矩阵已计算，形状: {temp_algo.weights.shape}")
        
        self.has_finished = True
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_algorithm(self):
        if self.hopfield_algorithm:
            self.hopfield_algorithm.stop()


class ObservableHopfieldAlgorithm(Observable, HopfieldAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        object.__setattr__(self, '_init_done', False)
        Observable.__init__(self, observer)
        HopfieldAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, 'ui_refresh_interval', ui_refresh_interval)
        object.__setattr__(self, '_init_done', True)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_init_done', False) or not hasattr(self, '_observer'):
            return
        
        if name == 'current_state':
            self.notify('current_state', value.tolist() if isinstance(value, np.ndarray) else value)
            energy = self.calculate_energy(value)
            self.notify('current_energy', energy)
        elif name == 'current_iterations':
            self.notify(name, value)
        elif name == 'is_converged':
            self.notify(name, value)
        elif name == 'weights':
            self.notify('weights', value.tolist() if isinstance(value, np.ndarray) else value)
    
    def run(self):
        self.notify('has_finished', False)
        self.notify('state_history', [])
        self.notify('energy_history', [])
        
        super().run()
        
        # 通知最终结果
        self.notify('state_history', [s.tolist() for s in self.state_history])
        self.notify('energy_history', self.energy_history)
        self.notify('current_state', self.current_state.tolist())
        self.notify('current_energy', self.calculate_energy(self.current_state))
        self.notify('is_converged', self.is_converged)
        self.notify('has_finished', True)
    
    def _iterate(self):
        super()._iterate()
        
        # 通知更新
        self.notify('current_state', self.current_state.tolist())
        self.notify('current_iterations', self.current_iterations)
        energy = self.calculate_energy(self.current_state)
        self.notify('current_energy', energy)
        self.notify('is_converged', self.is_converged)
        
        # UI刷新间隔
        if self.ui_refresh_interval > 0:
            elapsed = 0
            while elapsed < self.ui_refresh_interval and not self._should_stop:
                time.sleep(0.01)
                elapsed += 0.01


