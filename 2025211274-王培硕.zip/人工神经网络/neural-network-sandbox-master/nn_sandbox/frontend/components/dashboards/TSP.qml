import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'TSP'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(tspBridge.dataset_dict)
                enabled: tspBridge.has_finished
                onActivated: () => {
                    tspBridge.current_dataset_name = currentText
                    dataChart.updateDataset(tspBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    tspBridge.current_dataset_name = currentText
                    dataChart.updateDataset(tspBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: 'Solving Method'
                    Layout.alignment: Qt.AlignHCenter
                }
                ComboBox {
                    id: methodCombobox
                    enabled: tspBridge.has_finished
                    model: ['simulated_annealing', '2opt']
                    currentIndex: 0
                    onActivated: tspBridge.method = currentText
                    Component.onCompleted: tspBridge.method = currentText
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Max Iterations'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: maxIterations
                    enabled: tspBridge.has_finished
                    editable: true
                    value: 1000
                    to: 999999
                    onValueChanged: tspBridge.max_iterations = value
                    Component.onCompleted: tspBridge.max_iterations = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: tspBridge.has_finished
                    editable: true
                    value: 0.2 * 100
                    from: 0
                    to: 100
                    onValueChanged: tspBridge.learning_rate = value / 100
                    Component.onCompleted: tspBridge.learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Initial Temperature'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: tspBridge.has_finished
                    editable: true
                    value: 100.0 * 100
                    from: 1 * 100
                    to: 1000 * 100
                    onValueChanged: tspBridge.temperature = value / 100
                    Component.onCompleted: tspBridge.temperature = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Cooling Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: tspBridge.has_finished
                    editable: true
                    value: 0.99 * 100
                    from: 90
                    to: 99
                    onValueChanged: tspBridge.cooling_rate = value / 100
                    Component.onCompleted: tspBridge.cooling_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: tspBridge.has_finished
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: tspBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: tspBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: tspBridge.has_finished
                    startButton.onClicked: () => {
                        tspBridge.start_tsp_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(tspBridge.training_dataset)
                        dataChart.updateTestingDataset(tspBridge.testing_dataset)
                        rateChart.reset()
                    }
                    stopButton.enabled: !tspBridge.has_finished
                    stopButton.onClicked: tspBridge.stop_tsp_algorithm()
                    progressBar.value: tspBridge.current_iterations / maxIterations.value
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Iteration'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: tspBridge.current_iterations
                    horizontalAlignment: Text.AlignHCenter
                    onTextChanged: () => {
                        rateChart.trainingCorrectRate.append(
                            tspBridge.current_iterations,
                            tspBridge.current_distance
                        )
                        rateChart.bestCorrectRate.append(
                            tspBridge.current_iterations,
                            tspBridge.best_distance
                        )
                    }
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Distance'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: tspBridge.current_distance.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Best Distance'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: tspBridge.best_distance === Infinity ? 'N/A' : tspBridge.best_distance.toFixed(toFixedValue)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Progress'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: ((tspBridge.current_iterations / maxIterations.value * 100).toFixed(1) + '%')
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
        RateChart {
            id: rateChart
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
    }
}