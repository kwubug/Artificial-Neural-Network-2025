import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BmAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BmBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.01)
    total_epoches = BridgeProperty(100)
    initial_temperature = BridgeProperty(10.0)
    min_temperature = BridgeProperty(0.1)
    cooling_rate = BridgeProperty(0.95)
    equilibrium_threshold = BridgeProperty(10)
    current_iterations = BridgeProperty(0)
    current_temperature = BridgeProperty(10.0)
    current_energy = BridgeProperty(0.0)
    current_states = BridgeProperty([])
    current_weights = BridgeProperty([])
    current_biases = BridgeProperty([])
    is_equilibrium = BridgeProperty(False)
    equilibrium_iteration = BridgeProperty(-1)
    has_finished = BridgeProperty(True)
    energy_history = BridgeProperty([])
    states_history = BridgeProperty([])
    temperature_history = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.bm_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm_algorithm(self):
        try:
            # Clear history first
            self.energy_history = []
            self.states_history = []
            self.temperature_history = []
            
            self.bm_algorithm = ObservableBmAlgorithm(
                self,
                self.ui_refresh_interval,
                dataset=None,
                total_epoches=self.total_epoches,
                initial_temperature=self.initial_temperature,
                min_temperature=self.min_temperature,
                cooling_rate=self.cooling_rate,
                equilibrium_threshold=self.equilibrium_threshold
            )
            # Initialize UI with initial values
            try:
                self.current_weights = self.bm_algorithm.weights.tolist()
                self.current_biases = self.bm_algorithm.biases.tolist()
                self.current_states = self.bm_algorithm.states.tolist()
                self.current_energy = float(self.bm_algorithm.get_current_energy())
                self.current_temperature = float(self.bm_algorithm._current_temperature)
                
                # Pre-initialize history with initial state so charts can display immediately
                initial_energy = float(self.bm_algorithm.get_current_energy())
                initial_temp = float(self.bm_algorithm._current_temperature)
                initial_states = self.bm_algorithm.states.tolist()
                
                # Set history in bridge - this will trigger signals
                self.energy_history = [initial_energy]
                self.temperature_history = [initial_temp]
                self.states_history = [initial_states]
                
                # Also initialize algorithm's history to match (so run() doesn't overwrite)
                # Use object.__setattr__ to avoid triggering notifications in algorithm
                object.__setattr__(self.bm_algorithm, 'energy_history', [initial_energy])
                object.__setattr__(self.bm_algorithm, 'temperature_history', [initial_temp])
                object.__setattr__(self.bm_algorithm, 'states_history', [self.bm_algorithm.states.copy()])
                
                print(f"Initialized history: energy={self.energy_history}, temp={self.temperature_history}")
                
            except Exception as e:
                print(f"Error initializing UI values: {e}")
                import traceback
                traceback.print_exc()
                # Set default values if initialization fails
                self.current_weights = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
                self.current_biases = [0.0, 0.0, 0.0]
                self.current_states = [0, 0, 0]
                self.current_energy = 0.0
                self.current_temperature = self.initial_temperature
                self.energy_history = [0.0]
                self.temperature_history = [self.initial_temperature]
                self.states_history = [[0, 0, 0]]
            
            # Start the algorithm in a separate thread
            self.bm_algorithm.start()
        except Exception as e:
            import traceback
            print(f"Error starting BM algorithm: {e}")
            traceback.print_exc()
            # Make sure to set has_finished back to True on error
            self.has_finished = True

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()

    @PyQt5.QtCore.pyqtSlot()
    def reset_bm_algorithm(self):
        try:
            # Stop algorithm if running
            if self.bm_algorithm and not self.has_finished:
                self.bm_algorithm.stop()
                # Wait a bit for the thread to stop
                time.sleep(0.1)
            
            # Create a new algorithm instance to reset everything (including weights)
            # This ensures a fresh start with new random weights and biases
            self.bm_algorithm = ObservableBmAlgorithm(
                self,
                self.ui_refresh_interval,
                dataset=None,
                total_epoches=self.total_epoches,
                initial_temperature=self.initial_temperature,
                min_temperature=self.min_temperature,
                cooling_rate=self.cooling_rate,
                equilibrium_threshold=self.equilibrium_threshold
            )
            # Wait a bit for algorithm to be fully initialized
            time.sleep(0.01)
            
            # Reset UI properties - safely get values
            try:
                self.current_iterations = 0
                self.current_states = self.bm_algorithm.states.tolist()
                self.current_energy = float(self.bm_algorithm.get_current_energy())
                self.current_temperature = float(self.bm_algorithm._current_temperature)
                self.current_weights = self.bm_algorithm.weights.tolist()
                self.current_biases = self.bm_algorithm.biases.tolist()
            except Exception as e:
                print(f"Error resetting UI values: {e}")
                # Set default values if reset fails
                self.current_iterations = 0
                self.current_states = [0, 0, 0]
                self.current_energy = 0.0
                self.current_temperature = self.initial_temperature
                self.current_weights = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
                self.current_biases = [0.0, 0.0, 0.0]
            
            self.is_equilibrium = False
            self.equilibrium_iteration = -1
            self.energy_history = []
            self.states_history = []
            self.temperature_history = []
            self.has_finished = True
        except Exception as e:
            import traceback
            print(f"Error resetting BM algorithm: {e}")
            traceback.print_exc()
            self.has_finished = True


class ObservableBmAlgorithm(Observable, BmAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        # Use object.__setattr__ to avoid triggering our __setattr__ during init
        object.__setattr__(self, 'has_initialized', False)
        object.__setattr__(self, '_observer', observer)
        Observable.__init__(self, observer)
        BmAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, 'ui_refresh_interval', ui_refresh_interval)
        # Mark as initialized after all attributes are set
        object.__setattr__(self, 'has_initialized', True)

    def __setattr__(self, name, value):
        # Use object.__setattr__ to avoid recursion
        object.__setattr__(self, name, value)
        # Only notify after initialization is complete and for current_iterations
        try:
            if not getattr(self, 'has_initialized', False):
                return
            if name == 'current_iterations':
                try:
                    self.notify(name, value)
                    self.notify('current_states', self.states.tolist())
                    self.notify('current_energy', self.get_current_energy())
                    self.notify('current_temperature', self._current_temperature)
                    self.notify('current_weights', self.weights.tolist())
                    self.notify('current_biases', self.biases.tolist())
                    self.notify('is_equilibrium', self.is_equilibrium)
                    self.notify('equilibrium_iteration', self.equilibrium_iteration)
                    self.notify('energy_history', self.energy_history.copy())
                    self.notify('states_history', [s.tolist() for s in self.states_history])
                    self.notify('temperature_history', self.temperature_history.copy())
                except (AttributeError, RuntimeError) as e:
                    # Ignore errors - might happen if object is being destroyed
                    pass
        except AttributeError:
            # Ignore if has_initialized doesn't exist yet
            pass

    def run(self):
        try:
            self.notify('has_finished', False)
            # Initialize notifications - send initial state
            self.notify('current_states', self.states.tolist())
            self.notify('current_energy', float(self.get_current_energy()))
            self.notify('current_temperature', float(self._current_temperature))
            self.notify('current_weights', self.weights.tolist())
            self.notify('current_biases', self.biases.tolist())
            self.notify('is_equilibrium', False)
            self.notify('equilibrium_iteration', -1)
            
            # History should already be initialized in start_bm_algorithm
            # But make sure it has at least the initial state
            if len(self.energy_history) == 0:
                self.states_history.append(self.states.copy())
                self.energy_history.append(self._calculate_energy())
                self.temperature_history.append(self._current_temperature)
            
            # Send initial history data immediately - convert to list of Python floats
            # This ensures charts have data to display from the start
            energy_list = [float(e) for e in self.energy_history]
            temp_list = [float(t) for t in self.temperature_history]
            states_list = [s.tolist() if hasattr(s, 'tolist') else s for s in self.states_history]
            
            self.notify('energy_history', energy_list)
            self.notify('temperature_history', temp_list)
            self.notify('states_history', states_list)
            
            # Run the algorithm loop
            # Note: iteration starts from 0, and we want current_iterations to reflect the iteration number
            for iteration in range(self._total_epoches):
                if self._should_stop:
                    break
                
                # Update current_iterations first to indicate we're starting this iteration
                # This will trigger __setattr__ which sends notifications with current state
                self.current_iterations = iteration
                
                # Update state
                self._iterate()
                
                # Record history after iteration
                self.states_history.append(self.states.copy())
                self.energy_history.append(self._calculate_energy())
                
                # Check for equilibrium after iteration
                if self._check_equilibrium():
                    self.is_equilibrium = True
                    if self.equilibrium_iteration == -1:
                        self.equilibrium_iteration = iteration
                
                # Update temperature (simulated annealing)
                if self._current_temperature > self._min_temperature:
                    self._current_temperature *= self._cooling_rate
                else:
                    self._current_temperature = self._min_temperature
                
                # Record temperature after update
                self.temperature_history.append(self._current_temperature)
                
                # Explicitly notify history updates after recording new data
                # This ensures UI gets updated even if __setattr__ didn't trigger
                energy_list = [float(e) for e in self.energy_history]
                temp_list = [float(t) for t in self.temperature_history]
                self.notify('energy_history', energy_list)
                self.notify('temperature_history', temp_list)
                self.notify('current_states', self.states.tolist())
                self.notify('current_energy', float(self.get_current_energy()))
                self.notify('current_temperature', float(self._current_temperature))
                if self.is_equilibrium:
                    self.notify('is_equilibrium', True)
                if self.equilibrium_iteration >= 0:
                    self.notify('equilibrium_iteration', self.equilibrium_iteration)
            
            # Final update
            self.notify('has_finished', True)
            energy_list = [float(e) for e in self.energy_history]
            temp_list = [float(t) for t in self.temperature_history]
            self.notify('energy_history', energy_list)
            self.notify('temperature_history', temp_list)
            self.notify('states_history', [s.tolist() if hasattr(s, 'tolist') else s for s in self.states_history])
            self.notify('current_states', self.states.tolist())
            self.notify('current_energy', float(self.get_current_energy()))
            self.notify('current_temperature', float(self._current_temperature))
            self.notify('is_equilibrium', self.is_equilibrium)
            self.notify('equilibrium_iteration', self.equilibrium_iteration)
        except Exception as e:
            # Log error and notify that it finished (even if with error)
            import traceback
            print(f"Error in BM algorithm run: {e}")
            traceback.print_exc()
            try:
                self.notify('has_finished', True)
            except:
                pass

    def _iterate(self):
        super()._iterate()
        # Notifications are handled by __setattr__ when current_iterations is updated
        # in the parent's run() method, so we don't need to do anything here
        # The following line keeps the GUI from blocking
        time.sleep(self.ui_refresh_interval)

    def reset(self):
        super().reset()
        # Notify all properties after reset
        self.notify('current_iterations', 0)
        self.notify('current_states', self.states.tolist())
        self.notify('current_energy', self.get_current_energy())
        self.notify('current_temperature', self._current_temperature)
        self.notify('current_weights', self.weights.tolist())
        self.notify('current_biases', self.biases.tolist())
        self.notify('is_equilibrium', False)
        self.notify('equilibrium_iteration', -1)
        self.notify('energy_history', [])
        self.notify('states_history', [])
        self.notify('temperature_history', [])

