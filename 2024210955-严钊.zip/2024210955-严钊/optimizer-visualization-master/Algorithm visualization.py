import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.animation import FuncAnimation
import os

# 设置中文字体 - 解决中文显示方框问题
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']  # 支持中文的字体
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号

# 创建保存动画的目录
if not os.path.exists('optimization_animations'):
    os.makedirs('optimization_animations')


def quadratic_function(x, y):
    """二次函数示例: f(x,y) = x^2 + 10y^2"""
    return x ** 2 + 10 * y ** 2


def quadratic_gradient(x, y):
    """二次函数的梯度"""
    return np.array([2 * x, 20 * y])


def quadratic_hessian(x, y):
    """二次函数的Hessian矩阵"""
    return np.array([[2, 0], [0, 20]])


class OptimizationAnimator:
    def __init__(self, x0, y0, max_iter=20):
        self.x0, self.y0 = x0, y0
        self.max_iter = max_iter

        # 存储三种算法的完整路径历史
        self.sd_history = [(x0, y0)]
        self.newton_history = [(x0, y0)]
        self.cg_history = [(x0, y0)]

        # 当前算法状态
        self._init_algorithms()

    def _init_algorithms(self):
        """初始化算法状态"""
        # 最速下降法状态
        self.sd_x, self.sd_y = self.x0, self.y0
        self.sd_alpha = 0.1  # 学习率

        # 牛顿法状态
        self.newton_x, self.newton_y = self.x0, self.y0

        # 共轭梯度法状态
        self.cg_x, self.cg_y = self.x0, self.y0
        self.cg_r = -quadratic_gradient(self.cg_x, self.cg_y)  # 初始残差
        self.cg_p = self.cg_r.copy()  # 初始搜索方向

    def steepest_descent_step(self):
        """最速下降法单步"""
        grad = quadratic_gradient(self.sd_x, self.sd_y)
        self.sd_x = self.sd_x - self.sd_alpha * grad[0]
        self.sd_y = self.sd_y - self.sd_alpha * grad[1]
        return self.sd_x, self.sd_y

    def newtons_method_step(self):
        """牛顿法单步"""
        grad = quadratic_gradient(self.newton_x, self.newton_y)
        hess = quadratic_hessian(self.newton_x, self.newton_y)

        # 解线性系统: Hessian * delta = -Gradient
        delta = np.linalg.solve(hess, -grad)
        self.newton_x = self.newton_x + delta[0]
        self.newton_y = self.newton_y + delta[1]
        return self.newton_x, self.newton_y

    def conjugate_gradient_step(self):
        """共轭梯度法单步"""
        # 计算步长
        A = quadratic_hessian(self.cg_x, self.cg_y)
        alpha = np.dot(self.cg_r, self.cg_r) / np.dot(self.cg_p, A @ self.cg_p)

        # 更新点
        self.cg_x = self.cg_x + alpha * self.cg_p[0]
        self.cg_y = self.cg_y + alpha * self.cg_p[1]

        # 更新残差和搜索方向
        r_new = self.cg_r - alpha * (A @ self.cg_p)
        beta = np.dot(r_new, r_new) / np.dot(self.cg_r, self.cg_r)
        self.cg_p = r_new + beta * self.cg_p
        self.cg_r = r_new

        return self.cg_x, self.cg_y

    def run_all_steps(self):
        """运行所有优化步骤并记录历史"""
        for i in range(self.max_iter):
            # 执行一步优化
            sd_point = self.steepest_descent_step()
            newton_point = self.newtons_method_step()
            cg_point = self.conjugate_gradient_step()

            # 记录历史
            self.sd_history.append(sd_point)
            self.newton_history.append(newton_point)
            self.cg_history.append(cg_point)


def create_optimization_animation():
    """创建优化算法动画"""
    # 设置起点和最大迭代次数
    start_point = (1.5, 0.8)
    max_iter = 20

    # 创建优化器并运行所有步骤
    optimizer = OptimizationAnimator(*start_point, max_iter)
    optimizer.run_all_steps()

    # 创建网格数据用于可视化
    x = np.linspace(-2, 2, 150)
    y = np.linspace(-1, 1, 150)
    X, Y = np.meshgrid(x, y)
    Z = quadratic_function(X, Y)

    # 创建图形和子图
    fig = plt.figure(figsize=(16, 12))

    # 1. 2D 等高线图
    ax1 = fig.add_subplot(231)
    contours = ax1.contour(X, Y, Z, levels=20, alpha=0.6, cmap='viridis')
    ax1.clabel(contours, inline=True, fontsize=6)
    ax1.set_xlabel('x')
    ax1.set_ylabel('y')
    ax1.set_title('优化路径 - 等高线视图')
    ax1.grid(True, alpha=0.3)
    ax1.set_aspect('equal')

    # 2. 3D 曲面图
    ax2 = fig.add_subplot(232, projection='3d')
    surf = ax2.plot_surface(X, Y, Z, cmap=cm.coolwarm, alpha=0.6, antialiased=True)
    ax2.set_xlabel('x')
    ax2.set_ylabel('y')
    ax2.set_zlabel('f(x,y)')
    ax2.set_title('3D 优化路径视图')

    # 3. 函数值收敛图
    ax3 = fig.add_subplot(233)
    ax3.set_xlabel('迭代步数')
    ax3.set_ylabel('函数值 f(x,y)')
    ax3.set_title('函数值收敛过程')
    ax3.grid(True, alpha=0.3)
    # 预先设置坐标轴范围
    ax3.set_xlim(0, max_iter)
    ax3.set_ylim(0, quadratic_function(*start_point) * 1.1)

    # 4. 梯度范数收敛图
    ax4 = fig.add_subplot(234)
    ax4.set_xlabel('迭代步数')
    ax4.set_ylabel('梯度范数 ||∇f||')
    ax4.set_title('梯度范数收敛过程')
    ax4.grid(True, alpha=0.3)
    ax4.set_xlim(0, max_iter)
    initial_grad_norm = np.linalg.norm(quadratic_gradient(*start_point))
    ax4.set_ylim(0, initial_grad_norm * 1.1)

    # 5. 与最优解距离
    ax5 = fig.add_subplot(235)
    ax5.set_xlabel('迭代步数')
    ax5.set_ylabel('与最优解距离')
    ax5.set_title('与最优解的距离')
    ax5.grid(True, alpha=0.3)
    ax5.set_xlim(0, max_iter)
    initial_distance = np.linalg.norm(start_point)
    ax5.set_ylim(0, initial_distance * 1.1)

    # 6. 算法信息显示
    ax6 = fig.add_subplot(236)
    ax6.axis('off')

    # 初始化绘图元素
    # 2D 路径线
    sd_line_2d, = ax1.plot([], [], 'ro-', markersize=6, linewidth=2, label='最速下降法', alpha=0.8)
    newton_line_2d, = ax1.plot([], [], 'gs-', markersize=6, linewidth=2, label='牛顿法', alpha=0.8)
    cg_line_2d, = ax1.plot([], [], 'b^-', markersize=6, linewidth=2, label='共轭梯度法', alpha=0.8)

    # 起点和最小值点
    start_scatter = ax1.scatter(*start_point, color='black', s=100, label='起点', zorder=5)
    min_scatter = ax1.scatter(0, 0, color='red', s=100, marker='*', label='最小值', zorder=5)
    ax1.legend(fontsize=9)

    # 3D 路径线
    sd_line_3d, = ax2.plot([], [], [], 'ro-', markersize=4, linewidth=2, alpha=0.8)
    newton_line_3d, = ax2.plot([], [], [], 'gs-', markersize=4, linewidth=2, alpha=0.8)
    cg_line_3d, = ax2.plot([], [], [], 'b^-', markersize=4, linewidth=2, alpha=0.8)

    # 收敛曲线
    sd_conv, = ax3.plot([], [], 'ro-', label='最速下降法', linewidth=2, alpha=0.8, markersize=4)
    newton_conv, = ax3.plot([], [], 'gs-', label='牛顿法', linewidth=2, alpha=0.8, markersize=4)
    cg_conv, = ax3.plot([], [], 'b^-', label='共轭梯度法', linewidth=2, alpha=0.8, markersize=4)
    ax3.legend(fontsize=9)

    # 梯度范数
    sd_grad, = ax4.plot([], [], 'ro-', label='最速下降法', linewidth=2, alpha=0.8, markersize=4)
    newton_grad, = ax4.plot([], [], 'gs-', label='牛顿法', linewidth=2, alpha=0.8, markersize=4)
    cg_grad, = ax4.plot([], [], 'b^-', label='共轭梯度法', linewidth=2, alpha=0.8, markersize=4)
    ax4.legend(fontsize=9)

    # 距离
    sd_dist, = ax5.plot([], [], 'ro-', label='最速下降法', linewidth=2, alpha=0.8, markersize=4)
    newton_dist, = ax5.plot([], [], 'gs-', label='牛顿法', linewidth=2, alpha=0.8, markersize=4)
    cg_dist, = ax5.plot([], [], 'b^-', label='共轭梯度法', linewidth=2, alpha=0.8, markersize=4)
    ax5.legend(fontsize=9)

    # 信息文本
    info_text = ax6.text(0.05, 0.95, '', transform=ax6.transAxes, fontsize=11,
                         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))

    # 当前点标记
    sd_current = ax1.scatter([], [], color='red', s=80, zorder=10)
    newton_current = ax1.scatter([], [], color='green', s=80, zorder=10)
    cg_current = ax1.scatter([], [], color='blue', s=80, zorder=10)

    def init():
        """初始化动画"""
        # 清空所有线条和数据
        for line in [sd_line_2d, newton_line_2d, cg_line_2d,
                     sd_line_3d, newton_line_3d, cg_line_3d,
                     sd_conv, newton_conv, cg_conv,
                     sd_grad, newton_grad, cg_grad,
                     sd_dist, newton_dist, cg_dist]:
            line.set_data([], [])
            if hasattr(line, 'set_3d_properties'):
                line.set_3d_properties([])

        # 清空当前点
        sd_current.set_offsets([[np.nan, np.nan]])
        newton_current.set_offsets([[np.nan, np.nan]])
        cg_current.set_offsets([[np.nan, np.nan]])

        info_text.set_text('准备开始优化...')

        return (sd_line_2d, newton_line_2d, cg_line_2d,
                sd_line_3d, newton_line_3d, cg_line_3d,
                sd_conv, newton_conv, cg_conv,
                sd_grad, newton_grad, cg_grad,
                sd_dist, newton_dist, cg_dist,
                sd_current, newton_current, cg_current, info_text)

    def update(frame):
        """更新动画帧"""
        if frame > max_iter:
            return (sd_line_2d, newton_line_2d, cg_line_2d,
                    sd_line_3d, newton_line_3d, cg_line_3d,
                    sd_conv, newton_conv, cg_conv,
                    sd_grad, newton_grad, cg_grad,
                    sd_dist, newton_dist, cg_dist,
                    sd_current, newton_current, cg_current, info_text)

        # 获取当前帧的路径（从起点到当前帧）
        current_sd_path = optimizer.sd_history[:frame + 1]
        current_newton_path = optimizer.newton_history[:frame + 1]
        current_cg_path = optimizer.cg_history[:frame + 1]

        # 转换为numpy数组
        sd_array = np.array(current_sd_path)
        newton_array = np.array(current_newton_path)
        cg_array = np.array(current_cg_path)

        # 更新2D路径
        if len(sd_array) > 0:
            sd_line_2d.set_data(sd_array[:, 0], sd_array[:, 1])
        if len(newton_array) > 0:
            newton_line_2d.set_data(newton_array[:, 0], newton_array[:, 1])
        if len(cg_array) > 0:
            cg_line_2d.set_data(cg_array[:, 0], cg_array[:, 1])

        # 更新当前点位置
        if len(sd_array) > 0:
            sd_current.set_offsets([sd_array[-1]])
        if len(newton_array) > 0:
            newton_current.set_offsets([newton_array[-1]])
        if len(cg_array) > 0:
            cg_current.set_offsets([cg_array[-1]])

        # 更新3D路径
        if len(sd_array) > 0:
            sd_z = quadratic_function(sd_array[:, 0], sd_array[:, 1])
            sd_line_3d.set_data(sd_array[:, 0], sd_array[:, 1])
            sd_line_3d.set_3d_properties(sd_z)

        if len(newton_array) > 0:
            newton_z = quadratic_function(newton_array[:, 0], newton_array[:, 1])
            newton_line_3d.set_data(newton_array[:, 0], newton_array[:, 1])
            newton_line_3d.set_3d_properties(newton_z)

        if len(cg_array) > 0:
            cg_z = quadratic_function(cg_array[:, 0], cg_array[:, 1])
            cg_line_3d.set_data(cg_array[:, 0], cg_array[:, 1])
            cg_line_3d.set_3d_properties(cg_z)

        # 更新收敛曲线
        iterations = list(range(frame + 1))

        # 函数值
        if len(sd_array) > 0:
            sd_func = [quadratic_function(x, y) for x, y in current_sd_path]
            sd_conv.set_data(iterations, sd_func)

        if len(newton_array) > 0:
            newton_func = [quadratic_function(x, y) for x, y in current_newton_path]
            newton_conv.set_data(iterations, newton_func)

        if len(cg_array) > 0:
            cg_func = [quadratic_function(x, y) for x, y in current_cg_path]
            cg_conv.set_data(iterations, cg_func)

        # 梯度范数
        if len(sd_array) > 0:
            sd_grad_norm = [np.linalg.norm(quadratic_gradient(x, y)) for x, y in current_sd_path]
            sd_grad.set_data(iterations, sd_grad_norm)

        if len(newton_array) > 0:
            newton_grad_norm = [np.linalg.norm(quadratic_gradient(x, y)) for x, y in current_newton_path]
            newton_grad.set_data(iterations, newton_grad_norm)

        if len(cg_array) > 0:
            cg_grad_norm = [np.linalg.norm(quadratic_gradient(x, y)) for x, y in current_cg_path]
            cg_grad.set_data(iterations, cg_grad_norm)

        # 与最优解距离
        if len(sd_array) > 0:
            sd_distance = [np.linalg.norm([x, y]) for x, y in current_sd_path]
            sd_dist.set_data(iterations, sd_distance)

        if len(newton_array) > 0:
            newton_distance = [np.linalg.norm([x, y]) for x, y in current_newton_path]
            newton_dist.set_data(iterations, newton_distance)

        if len(cg_array) > 0:
            cg_distance = [np.linalg.norm([x, y]) for x, y in current_cg_path]
            cg_dist.set_data(iterations, cg_distance)

        # 动态调整收敛图的Y轴范围
        if frame > 0:
            # 函数值范围
            all_func_values = []
            if len(sd_array) > 0:
                all_func_values.extend(sd_func)
            if len(newton_array) > 0:
                all_func_values.extend(newton_func)
            if len(cg_array) > 0:
                all_func_values.extend(cg_func)

            if all_func_values:
                func_min, func_max = min(all_func_values), max(all_func_values)
                ax3.set_ylim(0, func_max * 1.1)

            # 梯度范数范围
            all_grad_norms = []
            if len(sd_array) > 0:
                all_grad_norms.extend(sd_grad_norm)
            if len(newton_array) > 0:
                all_grad_norms.extend(newton_grad_norm)
            if len(cg_array) > 0:
                all_grad_norms.extend(cg_grad_norm)

            if all_grad_norms:
                grad_min, grad_max = min(all_grad_norms), max(all_grad_norms)
                ax4.set_ylim(0, grad_max * 1.1)

            # 距离范围
            all_distances = []
            if len(sd_array) > 0:
                all_distances.extend(sd_distance)
            if len(newton_array) > 0:
                all_distances.extend(newton_distance)
            if len(cg_array) > 0:
                all_distances.extend(cg_distance)

            if all_distances:
                dist_min, dist_max = min(all_distances), max(all_distances)
                ax5.set_ylim(0, dist_max * 1.1)

        # 更新信息文本
        info_str = f'迭代步数: {frame}/{max_iter}\n\n'

        if len(sd_array) > 0:
            current_sd = sd_array[-1]
            sd_val = quadratic_function(*current_sd)
            info_str += f'最速下降法:\n  位置: ({current_sd[0]:.4f}, {current_sd[1]:.4f})\n  函数值: {sd_val:.6f}\n\n'

        if len(newton_array) > 0:
            current_newton = newton_array[-1]
            newton_val = quadratic_function(*current_newton)
            info_str += f'牛顿法:\n  位置: ({current_newton[0]:.4f}, {current_newton[1]:.4f})\n  函数值: {newton_val:.6f}\n\n'

        if len(cg_array) > 0:
            current_cg = cg_array[-1]
            cg_val = quadratic_function(*current_cg)
            info_str += f'共轭梯度法:\n  位置: ({current_cg[0]:.4f}, {current_cg[1]:.4f})\n  函数值: {cg_val:.6f}'

        info_text.set_text(info_str)

        # 动态调整2D图的坐标轴范围
        if frame > 0:
            all_points = np.vstack([sd_array, newton_array, cg_array])
            x_min, x_max = all_points[:, 0].min(), all_points[:, 0].max()
            y_min, y_max = all_points[:, 1].min(), all_points[:, 1].max()

            # 为2D图添加一些边距
            x_margin = (x_max - x_min) * 0.1
            y_margin = (y_max - y_min) * 0.1
            ax1.set_xlim(x_min - x_margin, x_max + x_margin)
            ax1.set_ylim(y_min - y_margin, y_max + y_margin)

        return (sd_line_2d, newton_line_2d, cg_line_2d,
                sd_line_3d, newton_line_3d, cg_line_3d,
                sd_conv, newton_conv, cg_conv,
                sd_grad, newton_grad, cg_grad,
                sd_dist, newton_dist, cg_dist,
                sd_current, newton_current, cg_current, info_text)

    # 创建动画
    print("正在创建动画...")
    anim = FuncAnimation(fig, update, frames=max_iter + 1, init_func=init,
                         blit=False, interval=600, repeat=True)

    plt.tight_layout()

    # 保存动画
    print("正在保存动画...")
    anim.save('optimization_animations/optimization_comparison.gif',
              writer='pillow', fps=2, dpi=100)
    print("动画已保存为 'optimization_animations/optimization_comparison.gif'")

    # 显示动画
    print("显示动画中...")
    plt.show()

    return anim


# 运行主程序
if __name__ == "__main__":
    print("开始优化算法演示...")
    print("比较三种优化算法:")
    print("1. 最速下降法 (红色)")
    print("2. 牛顿法 (绿色)")
    print("3. 共轭梯度法 (蓝色)")
    print()

    animation_obj = create_optimization_animation()