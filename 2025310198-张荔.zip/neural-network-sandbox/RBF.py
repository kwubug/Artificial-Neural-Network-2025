import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import norm
from sklearn.cluster import KMeans
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体为 SimHei（黑体）
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class RBFNet:
    def __init__(self, num_centers=10, sigma=1.0):
        self.num_centers = num_centers
        self.sigma = sigma
        self.centers = None
        self.weights = None
        self.bias = None

    def _gaussian_basis(self, x, c):
        """高斯径向基函数"""
        return np.exp(-norm(x - c) ** 2 / (2 * self.sigma ** 2))

    def _calculate_phi(self, X):
        """计算设计矩阵"""
        n_samples = X.shape[0]
        phi = np.zeros((n_samples, self.num_centers))

        for i in range(n_samples):
            for j in range(self.num_centers):
                phi[i, j] = self._gaussian_basis(X[i], self.centers[j])
        return phi

    def fit(self, X, y):
        """训练RBF网络"""
        X = X.reshape(-1, 1)
        y = y.reshape(-1, 1)

        # 使用K-means确定中心点
        kmeans = KMeans(n_clusters=self.num_centers, random_state=42)
        kmeans.fit(X)
        self.centers = kmeans.cluster_centers_

        # 计算设计矩阵
        phi = self._calculate_phi(X)

        # 使用最小二乘法求解权重
        self.weights = np.linalg.pinv(phi) @ y

        return self

    def predict(self, X):
        """预测"""
        X = X.reshape(-1, 1)
        phi = self._calculate_phi(X)
        return phi @ self.weights


# 修正后的目标向量
t = np.array([
    -0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336,
    -0.2013, -0.4344, -0.5000, -0.3930, -0.1647, 0.0988, 0.3072, 0.3960,
    0.3449, 0.1816, -0.0312, -0.2189, -0.3201
])

# 输入向量
p = np.arange(-1, 1.1, 0.1)

# 创建并训练RBF网络
rbf_net = RBFNet(num_centers=8, sigma=0.2)
rbf_net.fit(p, t)

# 预测
x_test = np.linspace(-1, 1, 100)
y_pred = rbf_net.predict(x_test)

# 绘制结果
plt.figure(figsize=(12, 8))

# 原始数据点
plt.scatter(p, t, color='red', s=50, label='原始数据点', zorder=5)

# RBF拟合曲线
plt.plot(x_test, y_pred, 'b-', linewidth=2, label='RBF拟合曲线')

plt.xlabel('x', fontsize=12)
plt.ylabel('f(x)', fontsize=12)
plt.title('RBF神经网络曲线拟合', fontsize=14)
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# 计算拟合误差
y_train_pred = rbf_net.predict(p)
mse = np.mean((t - y_train_pred.flatten()) ** 2)
print(f"均方误差 (MSE): {mse:.6f}")

# 显示网络参数
print(f"\nRBF网络参数:")
print(f"中心点数量: {rbf_net.num_centers}")
print(f"高斯函数宽度: {rbf_net.sigma}")
print("中心点位置:")
for i, center in enumerate(rbf_net.centers):
    print(f"  中心点 {i + 1}: {center[0]:.4f}")

# 绘制更详细的图表
plt.figure(figsize=(15, 10))

# 主拟合图
plt.subplot(2, 2, 1)
plt.scatter(p, t, color='red', s=50, label='原始数据点')
plt.plot(x_test, y_pred, 'b-', linewidth=2, label='RBF拟合')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('RBF神经网络曲线拟合')
plt.legend()
plt.grid(True, alpha=0.3)

# 误差图
plt.subplot(2, 2, 2)
error = t - y_train_pred.flatten()
plt.stem(p, error, basefmt=" ")
plt.axhline(y=0, color='r', linestyle='--', alpha=0.7)
plt.xlabel('x')
plt.ylabel('误差')
plt.title('拟合误差')
plt.grid(True, alpha=0.3)

# 径向基函数可视化 - 修复了这里的错误
plt.subplot(2, 2, 3)
for i, center in enumerate(rbf_net.centers):
    basis_func = np.exp(-(x_test - center[0]) ** 2 / (2 * rbf_net.sigma ** 2))
    plt.plot(x_test, basis_func, alpha=0.7, label=f'中心{i + 1}')
plt.xlabel('x')
plt.ylabel('基函数值')
plt.title('径向基函数')
plt.legend(fontsize=8)
plt.grid(True, alpha=0.3)

# 拟合值与真实值对比
plt.subplot(2, 2, 4)
plt.scatter(t, y_train_pred, alpha=0.7)
min_val = min(t.min(), y_train_pred.min())
max_val = max(t.max(), y_train_pred.max())
plt.plot([min_val, max_val], [min_val, max_val], 'r--', alpha=0.7)
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title('真实值 vs 预测值')
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# 尝试不同的参数组合进行比较
print("\n不同参数组合的拟合效果比较:")
centers_list = [5, 8, 12]
sigma_list = [0.1, 0.2, 0.5]

plt.figure(figsize=(15, 10))
plot_idx = 1
for num_centers in centers_list:
    for sigma in sigma_list:
        rbf_temp = RBFNet(num_centers=num_centers, sigma=sigma)
        rbf_temp.fit(p, t)
        y_temp = rbf_temp.predict(x_test)

        plt.subplot(3, 3, plot_idx)
        plt.scatter(p, t, color='red', s=30)
        plt.plot(x_test, y_temp, 'b-', linewidth=1.5)
        plt.title(f'中心数={num_centers}, σ={sigma}')
        plt.grid(True, alpha=0.3)
        plot_idx += 1

plt.tight_layout()
plt.show()


# 添加性能评估函数
def evaluate_fit(actual, predicted):
    """评估拟合性能"""
    mse = np.mean((actual - predicted) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(actual - predicted))
    r_squared = 1 - np.sum((actual - predicted) ** 2) / np.sum((actual - np.mean(actual)) ** 2)

    print(f"\n拟合性能评估:")
    print(f"均方误差 (MSE): {mse:.6f}")
    print(f"均方根误差 (RMSE): {rmse:.6f}")
    print(f"平均绝对误差 (MAE): {mae:.6f}")
    print(f"决定系数 (R²): {r_squared:.6f}")


# 评估当前模型的拟合性能
evaluate_fit(t, y_train_pred.flatten())

# 寻找最优参数
print("\n寻找最优参数组合:")
best_mse = float('inf')
best_params = {}

for num_centers in range(4, 15):
    for sigma in [0.05, 0.1, 0.15, 0.2, 0.3, 0.5]:
        try:
            rbf_temp = RBFNet(num_centers=num_centers, sigma=sigma)
            rbf_temp.fit(p, t)
            y_temp = rbf_temp.predict(p)
            mse_temp = np.mean((t - y_temp.flatten()) ** 2)

            if mse_temp < best_mse:
                best_mse = mse_temp
                best_params = {'centers': num_centers, 'sigma': sigma}
        except:
            continue

print(f"最优参数: 中心点数={best_params['centers']}, σ={best_params['sigma']}")
print(f"最优MSE: {best_mse:.6f}")

# 使用最优参数重新训练
rbf_best = RBFNet(num_centers=best_params['centers'], sigma=best_params['sigma'])
rbf_best.fit(p, t)
y_best_pred = rbf_best.predict(x_test)

# 绘制最优结果
plt.figure(figsize=(12, 8))
plt.scatter(p, t, color='red', s=50, label='原始数据点', zorder=5)
plt.plot(x_test, y_best_pred, 'b-', linewidth=2,
         label=f'最优RBF拟合 (中心数={best_params["centers"]}, σ={best_params["sigma"]})')
plt.xlabel('x', fontsize=12)
plt.ylabel('f(x)', fontsize=12)
plt.title('最优RBF神经网络曲线拟合', fontsize=14)
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()

# 评估最优模型的性能
y_best_train_pred = rbf_best.predict(p)
evaluate_fit(t, y_best_train_pred.flatten())