"""Bridge for OLS-RBFN Algorithm - 完全基于RBFN Bridge结构"""
import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import OlsRbfnAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsRbfnBridge(Bridge):
    """OLS-RBFN桥接 - 与RbfnBridge结构相同"""
    
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    acceptable_range = BridgeProperty(0.5)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    
    # OLS特有参数（替代RBFN的cluster_count）
    max_centers = BridgeProperty(10)
    err_threshold = BridgeProperty(0.01)
    sigma = BridgeProperty(1.0)
    
    test_ratio = BridgeProperty(0.3)
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_neurons = BridgeProperty([])
    
    # OLS特有信息
    selected_centers_count = BridgeProperty(0)
    err_history = BridgeProperty([])
    center_selection_history = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.ols_rbfn_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_ols_rbfn_algorithm(self):
        """启动OLS-RBFN算法 - 与start_rbfn_algorithm结构相同"""
        self.ols_rbfn_algorithm = ObservableOlsRbfnAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            acceptable_range=self.acceptable_range,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            max_centers=self.max_centers,
            err_threshold=self.err_threshold,
            sigma=self.sigma,
            test_ratio=self.test_ratio
        )
        self.ols_rbfn_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols_rbfn_algorithm(self):
        """停止OLS-RBFN算法"""
        if self.ols_rbfn_algorithm:
            self.ols_rbfn_algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableOlsRbfnAlgorithm(Observable, OlsRbfnAlgorithm):
    """可观察的OLS-RBFN算法 - 与ObservableRbfnAlgorithm结构相同"""
    
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self.has_initialized = False
        Observable.__init__(self, observer)
        OlsRbfnAlgorithm.__init__(self, **kwargs)
        self.has_initialized = True
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        
        # 与RBFN完全相同的更新逻辑
        if name == 'current_iterations' and self.has_initialized:
            self.notify(name, value)
            self.notify('current_neurons', [{
                'mean': neuron.mean.tolist(),
                'standard_deviation': float(neuron.standard_deviation),
                'synaptic_weight': float(neuron.synaptic_weight)
            } for neuron in self._neurons if not neuron.is_threshold])
            self.notify('test_correct_rate', self.test())
        
        if name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        
        if name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())
        
        # OLS特有的更新
        if name == 'selected_centers' and self.has_initialized:
            self.notify('selected_centers_count', len(value))
            print(f"🔔 [Bridge] 通知选择中心数: {len(value)}")
        
        if name == 'err_history' and self.has_initialized:
            # 确保转换为Python列表（QML兼容）
            err_list = list(value) if value else []
            self.notify(name, err_list)
            print(f"🔔 [Bridge] 通知ERR历史: {len(err_list)} 个步骤, 内容: {err_list}")
        
        if name == 'center_selection_history' and self.has_initialized:
            self.notify(name, value)
            print(f"🔔 [Bridge] 通知中心选择历史: {len(value)} 个步骤")

    def run(self):
        """运行算法 - 与RBFN完全相同"""
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        super().run()
        self.notify('current_neurons', [{
            'mean': neuron.mean.tolist(),
            'standard_deviation': float(neuron.standard_deviation),
            'synaptic_weight': float(neuron.synaptic_weight)
        } for neuron in self._neurons if not neuron.is_threshold])
        
        # 通知OLS特有信息
        print(f"🔔 [run结束] 通知OLS信息:")
        print(f"   - selected_centers_count: {len(self.selected_centers)}")
        print(f"   - err_history长度: {len(self.err_history)}")
        print(f"   - err_history类型: {type(self.err_history)}")
        print(f"   - err_history内容: {self.err_history}")
        
        # 确保转换为QML可识别的格式
        err_list = [float(x) for x in self.err_history] if self.err_history else []
        
        self.notify('selected_centers_count', len(self.selected_centers))
        self.notify('err_history', err_list)
        self.notify('center_selection_history', self.center_selection_history)
        
        print(f"✅ [run结束] 已通知err_history，长度: {len(err_list)}, 内容: {err_list}")
        
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        """迭代 - 与RBFN完全相同"""
        super()._iterate()
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        """当前学习率 - 与RBFN完全相同"""
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
