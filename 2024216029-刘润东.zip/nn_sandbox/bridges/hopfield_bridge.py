from PyQt5.QtCore import pyqtSlot
from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.hopfield_algorithm import ObservableHopfieldAlgorithm
import json


class HopfieldBridge(Bridge):
    """
    Hopfield神经网络的Bridge类
    连接Hopfield算法和QML界面
    """
    
    # 定义Bridge属性
    current_iteration = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    statistics = BridgeProperty({})
    is_running = BridgeProperty(False)
    is_stable = BridgeProperty(False)
    
    def __init__(self):
        super().__init__()
        self.algorithm = None
        
    @pyqtSlot(str, int, bool)
    def start(self, patterns_json, max_iterations, async_update):
        """
        启动Hopfield算法
        
        Args:
            patterns_json: JSON字符串形式的模式列表
            max_iterations: 最大迭代次数
            async_update: 是否使用异步更新
        """
        if self.algorithm and self.algorithm.is_alive():
            self.algorithm.stop()
            self.algorithm.join()
        
        # 解析模式
        try:
            patterns = json.loads(patterns_json)
        except:
            patterns = [[1, -1, 1], [-1, 1, -1]]  # 默认模式
            
        self.algorithm = ObservableHopfieldAlgorithm(
            observer=self,
            patterns=patterns,
            max_iterations=max_iterations,
            async_update=async_update
        )
        self.is_running = True
        
        # 立即发送初始统计信息
        self.statistics = self.algorithm.get_statistics()
        
        self.algorithm.start()
        
    @pyqtSlot(str)
    def set_initial_state(self, state_json):
        """设置初始状态"""
        if self.algorithm:
            try:
                state = json.loads(state_json)
                self.algorithm.set_initial_state(state)
                self.statistics = self.algorithm.get_statistics()
            except:
                pass
        
    @pyqtSlot()
    def stop(self):
        """停止Hopfield算法"""
        if self.algorithm:
            self.algorithm.stop()
            self.is_running = False

