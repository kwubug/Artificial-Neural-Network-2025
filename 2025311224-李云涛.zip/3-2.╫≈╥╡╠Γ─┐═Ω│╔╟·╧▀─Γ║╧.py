import numpy as np
import matplotlib.pyplot as plt

# 1. Define input and target vectors
p = np.arange(-1, 1.1, 0.1)  # Input vector: [-1.0, -0.9, ..., 1.0], 21 points total
t = np.array([-0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609,
              0.1336, -0.2013, -0.4344, -0.5000, -0.3939, -0.1647, 0.0988,
              0.3072, 0.3960, 0.3449, 0.1816, -0.0312, -0.2189, -0.3201])  # Target vector

# 2. Initialize RBF parameters
M = 5  # Number of hidden nodes
c = np.linspace(-1, 1, M)  # Hidden node centers: [-1.0, -0.5, 0.0, 0.5, 1.0]
sigma = 0.25  # Spread constant

# 3. Construct radial basis function matrix Φ
def rbf(x, c, sigma):
    return np.exp(-(x - c)**2 / (2 * sigma**2))

Phi = np.zeros((len(p), M))
for m in range(M):
    Phi[:, m] = rbf(p, c[m], sigma)

# 4. OLS solve for weights and bias (augmented matrix method)
Phi_aug = np.hstack((Phi, np.ones((len(p), 1))))  # Augmented matrix: 21×6
w_aug = np.linalg.inv(Phi_aug.T @ Phi_aug) @ Phi_aug.T @ t  # OLS solution
w = w_aug[:-1]  # Weights
b = w_aug[-1]   # Bias

# 5. Prediction and error calculation
y_pred = Phi @ w + b  # Network output
mse = np.mean((y_pred - t)**2)  # Mean squared error
print(f"Mean Squared Error (MSE): {mse:.6f}")

# 6. Visualize fitting results
plt.figure(figsize=(8, 5))
plt.scatter(p, t, c='blue', label='Target Data')
plt.plot(p, y_pred, 'r-', linewidth=2, label='RBF Fitting Curve')
plt.scatter(c, np.zeros_like(c), c='green', marker='*', s=100, label='Hidden Node Centers')
plt.xlabel('Input p')
plt.ylabel('Output y')
plt.title('RBF Neural Network Curve Fitting (OLS Method)')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()