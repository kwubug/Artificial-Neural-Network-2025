"""
PyQt5 DLL 加载失败 - 替代方案脚本
如果 PyQt5 无法正常工作，可以使用 PySide2 作为替代
"""

import sys
import subprocess

def check_and_install_pyside2():
    """检查并安装 PySide2 作为 PyQt5 的替代"""
    try:
        import PySide2
        print("✓ PySide2 已安装")
        return True
    except ImportError:
        print("PySide2 未安装，正在安装...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "PySide2"])
            print("✓ PySide2 安装成功")
            return True
        except subprocess.CalledProcessError:
            print("✗ PySide2 安装失败")
            return False

def convert_imports():
    """将 PyQt5 导入转换为 PySide2"""
    print("\n正在转换导入语句...")
    
    # 读取原文件
    with open("tsp_visualizer.py", "r", encoding="utf-8") as f:
        content = f.read()
    
    # 替换导入
    content = content.replace("from PyQt5.", "from PySide2.")
    content = content.replace("import PyQt5", "import PySide2")
    
    # 保存新文件
    with open("tsp_visualizer_pyside2.py", "w", encoding="utf-8") as f:
        f.write(content)
    
    print("✓ 已创建 tsp_visualizer_pyside2.py")
    print("  现在可以使用: python tsp_visualizer_pyside2.py")

if __name__ == "__main__":
    print("=" * 50)
    print("PyQt5 替代方案：使用 PySide2")
    print("=" * 50)
    
    if check_and_install_pyside2():
        convert_imports()
        print("\n✓ 转换完成！")
    else:
        print("\n✗ 安装失败，请手动执行：")
        print("  pip install PySide2")

