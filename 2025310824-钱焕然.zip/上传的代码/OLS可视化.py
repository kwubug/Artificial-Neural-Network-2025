import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import tkinter as tk
from tkinter import ttk, messagebox
from scipy.stats import norm

# ===================== matplotlib样式配置 =====================
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimSun', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['animation.embed_limit'] = 20.0
plt.rcParams['figure.facecolor'] = '#f8f9fa'
plt.rcParams['axes.facecolor'] = '#ffffff'
plt.rcParams['axes.edgecolor'] = '#dee2e6'
plt.rcParams['grid.color'] = '#e9ecef'
plt.rcParams['grid.linewidth'] = 0.8
plt.rcParams['grid.alpha'] = 0.5


class OLSVisualizerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("OLS线性回归可视化系统")
        self.root.geometry("1600x900")
        self.root.configure(bg='#f8f9fa')
        
        # 动画相关
        self.anim = None
        self.is_animating = False
        
        # 默认参数
        self.n_samples = 100
        self.true_slope = 2.0
        self.true_intercept = 3.0
        self.noise_level = 1.2
        self.random_seed = 42
        
        # 创建界面
        self.create_widgets()
        # 初始化绘图
        self.update_plot()
    
    def create_widgets(self):
        """创建GUI组件"""
        # ==================== 左侧控制面板 ====================
        control_frame = tk.Frame(self.root, bg='#ffffff', relief=tk.RAISED, borderwidth=2)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)
        
        # 标题
        title_label = tk.Label(control_frame, text="📊 参数控制面板", 
                              font=('Microsoft YaHei', 16, 'bold'),
                              bg='#ffffff', fg='#2c3e50')
        title_label.pack(pady=15)
        
        # 分隔线
        ttk.Separator(control_frame, orient='horizontal').pack(fill='x', padx=10, pady=10)
        
        # -------------------- 数据参数 --------------------
        data_label = tk.Label(control_frame, text="🔧 数据生成参数", 
                             font=('Microsoft YaHei', 12, 'bold'),
                             bg='#ffffff', fg='#34495e')
        data_label.pack(pady=(10, 5))
        
        # 样本数量
        self.create_slider(control_frame, "样本数量", 50, 500, self.n_samples, 
                          lambda v: setattr(self, 'n_samples', int(v)))
        
        # 真实斜率
        self.create_slider(control_frame, "真实斜率", -5, 5, self.true_slope, 
                          lambda v: setattr(self, 'true_slope', float(v)), resolution=0.1)
        
        # 真实截距
        self.create_slider(control_frame, "真实截距", -10, 10, self.true_intercept, 
                          lambda v: setattr(self, 'true_intercept', float(v)), resolution=0.1)
        
        # 噪声水平
        self.create_slider(control_frame, "噪声水平", 0, 5, self.noise_level, 
                          lambda v: setattr(self, 'noise_level', float(v)), resolution=0.1)
        
        # 随机种子
        self.create_slider(control_frame, "随机种子", 0, 100, self.random_seed, 
                          lambda v: setattr(self, 'random_seed', int(v)))
        
        ttk.Separator(control_frame, orient='horizontal').pack(fill='x', padx=10, pady=15)
        
        # -------------------- 控制按钮 --------------------
        button_label = tk.Label(control_frame, text="🎮 操作控制", 
                               font=('Microsoft YaHei', 12, 'bold'),
                               bg='#ffffff', fg='#34495e')
        button_label.pack(pady=(10, 5))
        
        # 更新按钮
        self.update_btn = tk.Button(control_frame, text="🔄 更新图表", 
                                    command=self.update_plot,
                                    font=('Microsoft YaHei', 11, 'bold'),
                                    bg='#3498db', fg='white',
                                    activebackground='#2980b9',
                                    relief=tk.RAISED, borderwidth=3,
                                    cursor='hand2', width=20, height=2)
        self.update_btn.pack(pady=8)
        
        # 动画按钮
        self.anim_btn = tk.Button(control_frame, text="▶️ 播放动画", 
                                  command=self.toggle_animation,
                                  font=('Microsoft YaHei', 11, 'bold'),
                                  bg='#27ae60', fg='white',
                                  activebackground='#229954',
                                  relief=tk.RAISED, borderwidth=3,
                                  cursor='hand2', width=20, height=2)
        self.anim_btn.pack(pady=8)
        
        # 保存动画按钮
        save_btn = tk.Button(control_frame, text="💾 保存动画", 
                            command=self.save_animation,
                            font=('Microsoft YaHei', 11, 'bold'),
                            bg='#e74c3c', fg='white',
                            activebackground='#c0392b',
                            relief=tk.RAISED, borderwidth=3,
                            cursor='hand2', width=20, height=2)
        save_btn.pack(pady=8)
        
        # 重置按钮
        reset_btn = tk.Button(control_frame, text="🔄 重置默认", 
                             command=self.reset_defaults,
                             font=('Microsoft YaHei', 11, 'bold'),
                             bg='#95a5a6', fg='white',
                             activebackground='#7f8c8d',
                             relief=tk.RAISED, borderwidth=3,
                             cursor='hand2', width=20, height=2)
        reset_btn.pack(pady=8)
        
        ttk.Separator(control_frame, orient='horizontal').pack(fill='x', padx=10, pady=15)
        
        # -------------------- 统计信息显示 --------------------
        info_label = tk.Label(control_frame, text="📈 统计信息", 
                             font=('Microsoft YaHei', 12, 'bold'),
                             bg='#ffffff', fg='#34495e')
        info_label.pack(pady=(10, 5))
        
        self.info_text = tk.Text(control_frame, height=12, width=28, 
                                font=('Consolas', 10),
                                bg='#ecf0f1', fg='#2c3e50',
                                relief=tk.SUNKEN, borderwidth=2)
        self.info_text.pack(padx=10, pady=5)
        
        # ==================== 右侧绘图区域 ====================
        plot_frame = tk.Frame(self.root, bg='#f8f9fa')
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建matplotlib图形
        self.fig, self.axes = plt.subplots(2, 2, figsize=(14, 10))
        self.fig.patch.set_facecolor('#f8f9fa')
        
        # 嵌入到tkinter
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 添加工具栏
        toolbar = NavigationToolbar2Tk(self.canvas, plot_frame)
        toolbar.update()
    
    def create_slider(self, parent, label, from_, to, default, command, resolution=1):
        """创建标签和滑块组合"""
        frame = tk.Frame(parent, bg='#ffffff')
        frame.pack(pady=8, padx=15, fill='x')
        
        # 标签
        label_widget = tk.Label(frame, text=label, font=('Microsoft YaHei', 10),
                               bg='#ffffff', fg='#2c3e50', anchor='w')
        label_widget.pack(side=tk.TOP, fill='x')
        
        # 值显示
        value_label = tk.Label(frame, text=f"{default:.2f}" if resolution < 1 else f"{int(default)}", 
                              font=('Consolas', 9, 'bold'),
                              bg='#ffffff', fg='#e74c3c')
        value_label.pack(side=tk.TOP, fill='x')
        
        # 滑块
        def on_change(v):
            val = float(v)
            value_label.config(text=f"{val:.2f}" if resolution < 1 else f"{int(val)}")
            command(val)
        
        slider = tk.Scale(frame, from_=from_, to=to, resolution=resolution,
                         orient=tk.HORIZONTAL, command=on_change,
                         bg='#ecf0f1', fg='#2c3e50',
                         highlightthickness=0, troughcolor='#bdc3c7',
                         activebackground='#3498db', length=220)
        slider.set(default)
        slider.pack(side=tk.TOP, fill='x')
    
    def generate_data(self):
        """生成回归数据"""
        np.random.seed(self.random_seed)
        x = np.linspace(0, 10, self.n_samples)
        y_true = self.true_slope * x + self.true_intercept
        noise = np.random.normal(0, self.noise_level, size=self.n_samples)
        y = y_true + noise
        return x, y, y_true
    
    def calculate_ols(self, x, y):
        """计算OLS参数"""
        X = np.column_stack((np.ones_like(x), x))
        X_T = X.T
        X_T_X = X_T @ X
        X_T_X_inv = np.linalg.inv(X_T_X)
        X_T_y = X_T @ y
        theta_ols = X_T_X_inv @ X_T_y
        ols_intercept, ols_slope = theta_ols
        y_pred = X @ theta_ols
        
        residuals = y - y_pred
        rss = np.sum(residuals ** 2)
        tss = np.sum((y - np.mean(y)) ** 2)
        r2 = 1 - (rss / tss)
        
        return ols_intercept, ols_slope, y_pred, residuals, rss, r2
    
    def update_plot(self):
        """更新所有子图"""
        # 停止动画（如果正在播放）
        if self.is_animating:
            self.toggle_animation()
        
        # 生成数据
        x, y, y_true = self.generate_data()
        ols_intercept, ols_slope, y_pred, residuals, rss, r2 = self.calculate_ols(x, y)
        
        # 保存数据供动画使用
        self.x = x
        self.y = y
        self.y_pred = y_pred
        self.ols_intercept = ols_intercept
        self.ols_slope = ols_slope
        
        # 清除所有子图
        for ax in self.axes.flat:
            ax.clear()
        
        # 更新主标题
        self.fig.suptitle(f'OLS线性回归详细可视化分析\nR² = {r2:.4f}  |  残差平方和 = {rss:.2f}', 
                         fontsize=18, fontweight='bold', color='#2c3e50', y=0.995)
        
        # -------------------- 子图1：数据拟合 --------------------
        ax1 = self.axes[0, 0]
        ax1.scatter(x, y, color='#3498db', alpha=0.7, label='观测数据（带噪声）', 
                   s=50, edgecolors='white', linewidth=1.5, zorder=3)
        ax1.plot(x, y_true, color='#27ae60', linestyle='-.', linewidth=3, 
                label=f'真实关系：y={self.true_slope:.1f}x+{self.true_intercept:.1f}', 
                alpha=0.8, zorder=2)
        ax1.plot(x, y_pred, color='#e74c3c', linewidth=3.5, 
                label=f'OLS拟合：y={ols_slope:.2f}x+{ols_intercept:.2f}', zorder=4)
        ax1.set_xlabel('特征 x', fontsize=13, fontweight='bold', color='#2c3e50')
        ax1.set_ylabel('目标 y', fontsize=13, fontweight='bold', color='#2c3e50')
        ax1.set_title('① 数据拟合核心结果', fontsize=15, pad=12, fontweight='bold', color='#2c3e50')
        ax1.legend(loc='upper left', fontsize=10, frameon=True, shadow=True, fancybox=True)
        ax1.grid(True, linestyle='--', alpha=0.6)
        ax1.set_xlim(-0.5, 10.5)
        ax1.set_ylim(y.min()-1.5, y.max()+1.5)
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)
        
        # -------------------- 子图2：残差可视化 --------------------
        ax2 = self.axes[0, 1]
        ax2.scatter(x, y, color='#3498db', alpha=0.7, s=50, edgecolors='white', 
                   linewidth=1.5, label='观测数据', zorder=3)
        ax2.plot(x, y_pred, color='#e74c3c', linewidth=3.5, label='OLS拟合直线', zorder=4)
        for xi, yi, ypi in zip(x, y, y_pred):
            ax2.plot([xi, xi], [yi, ypi], color='#9b59b6', linestyle='--', 
                    alpha=0.5, linewidth=1.2)
        ax2.set_xlabel('特征 x', fontsize=13, fontweight='bold', color='#2c3e50')
        ax2.set_ylabel('目标 y', fontsize=13, fontweight='bold', color='#2c3e50')
        ax2.set_title('② 残差可视化（垂直距离）', fontsize=15, pad=12, fontweight='bold', color='#2c3e50')
        ax2.legend(fontsize=10, frameon=True, shadow=True, fancybox=True)
        ax2.grid(True, linestyle='--', alpha=0.6)
        ax2.set_xlim(-0.5, 10.5)
        ax2.set_ylim(y.min()-1.5, y.max()+1.5)
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)
        
        # -------------------- 子图3：残差分布 --------------------
        ax3 = self.axes[1, 0]
        n, bins, patches = ax3.hist(residuals, bins=20, color='#16a085', alpha=0.75, 
                                    edgecolor='#0e6655', linewidth=1.5)
        for i, patch in enumerate(patches):
            patch.set_facecolor(plt.cm.viridis(i / len(patches)))
        mean_residual = np.mean(residuals)
        ax3.axvline(mean_residual, color='#e74c3c', linewidth=3, linestyle='--',
                   label=f'残差均值：{mean_residual:.4f}', zorder=5)
        mu, sigma = norm.fit(residuals)
        x_res = np.linspace(residuals.min(), residuals.max(), 100)
        y_res = norm.pdf(x_res, mu, sigma) * (bins[1]-bins[0]) * len(residuals)
        ax3.plot(x_res, y_res, color='#e67e22', linewidth=3, label='正态分布拟合', 
                linestyle='-', alpha=0.9, zorder=4)
        ax3.set_xlabel('残差大小', fontsize=13, fontweight='bold', color='#2c3e50')
        ax3.set_ylabel('频数', fontsize=13, fontweight='bold', color='#2c3e50')
        ax3.set_title('③ 残差分布（正态性检验）', fontsize=15, pad=12, fontweight='bold', color='#2c3e50')
        ax3.legend(fontsize=10, frameon=True, shadow=True, fancybox=True)
        ax3.grid(True, linestyle='--', alpha=0.6, axis='y')
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)
        
        # -------------------- 子图4：参数收敛（初始化） --------------------
        ax4 = self.axes[1, 1]
        ax4.scatter(x, y, color='#3498db', alpha=0.7, s=50, edgecolors='white', 
                   linewidth=1.5, label='观测数据', zorder=3)
        self.line_anim, = ax4.plot(x, y_pred, color='#f39c12', linewidth=4, 
                                   label='当前拟合直线', zorder=4)
        ax4.set_xlabel('特征 x', fontsize=13, fontweight='bold', color='#2c3e50')
        ax4.set_ylabel('目标 y', fontsize=13, fontweight='bold', color='#2c3e50')
        ax4.set_title('④ OLS参数收敛过程', fontsize=15, pad=12, fontweight='bold', color='#2c3e50')
        ax4.legend(fontsize=10, frameon=True, shadow=True, fancybox=True)
        ax4.grid(True, linestyle='--', alpha=0.6)
        ax4.set_xlim(-0.5, 10.5)
        ax4.set_ylim(y.min()-1.5, y.max()+1.5)
        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)
        
        # 调整布局
        self.fig.tight_layout(rect=[0, 0, 1, 0.97])
        self.canvas.draw()
        
        # 更新统计信息
        self.update_info(r2, rss, ols_slope, ols_intercept, residuals, mu, sigma)
    
    def update_info(self, r2, rss, slope, intercept, residuals, mu, sigma):
        """更新统计信息文本框"""
        info = f"""
╔══════════════════════════╗
║     模型评估指标         ║
╚══════════════════════════╝

📊 拟合优度
   R² = {r2:.6f}

📉 残差平方和
   RSS = {rss:.4f}

📐 OLS参数估计
   斜率 = {slope:.4f}
   截距 = {intercept:.4f}

📈 残差统计
   均值 μ = {mu:.4f}
   标准差 σ = {sigma:.4f}
   最小值 = {residuals.min():.4f}
   最大值 = {residuals.max():.4f}

🎯 真实参数
   斜率 = {self.true_slope:.2f}
   截距 = {self.true_intercept:.2f}
"""
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(1.0, info)
    
    def toggle_animation(self):
        """切换动画播放/暂停"""
        if not self.is_animating:
            # 开始动画
            self.is_animating = True
            self.anim_btn.config(text="⏸️ 暂停动画", bg='#f39c12')
            self.update_btn.config(state='disabled')
            self.start_animation()
        else:
            # 停止动画
            self.is_animating = False
            self.anim_btn.config(text="▶️ 播放动画", bg='#27ae60')
            self.update_btn.config(state='normal')
            if self.anim:
                self.anim.event_source.stop()
    
    def start_animation(self):
        """启动参数收敛动画"""
        ax4 = self.axes[1, 1]
        
        def update_anim(frame):
            if not self.is_animating:
                return self.line_anim,
            
            t = frame / 60
            current_intercept = 10 * np.exp(-t*2) + self.ols_intercept * (1 - np.exp(-t*2))
            current_slope = -1 * np.exp(-t*2) + self.ols_slope * (1 - np.exp(-t*2))
            y_anim = current_slope * self.x + current_intercept
            self.line_anim.set_ydata(y_anim)
            ax4.set_title(f'④ 参数收敛过程（进度={t*100:.0f}%）\n截距={current_intercept:.2f} | 斜率={current_slope:.2f}',
                         fontsize=14, pad=10, fontweight='bold', color='#2c3e50')
            return self.line_anim,
        
        self.anim = FuncAnimation(self.fig, update_anim, frames=60, 
                                 interval=80, blit=True, repeat=False)
        
        # 动画结束后的回调
        def on_anim_end(event):
            if self.is_animating:
                self.toggle_animation()
        
        self.anim.event_source.add_callback(on_anim_end)
        self.canvas.draw()
    
    def save_animation(self):
        """保存动画为GIF"""
        try:
            messagebox.showinfo("保存动画", "正在生成动画，请稍候...\n这可能需要10-20秒")
            
            # 创建临时动画
            def update_temp(frame):
                t = frame / 60
                current_intercept = 10 * np.exp(-t*2) + self.ols_intercept * (1 - np.exp(-t*2))
                current_slope = -1 * np.exp(-t*2) + self.ols_slope * (1 - np.exp(-t*2))
                y_anim = current_slope * self.x + current_intercept
                self.line_anim.set_ydata(y_anim)
                self.axes[1, 1].set_title(f'④ 参数收敛过程（进度={t*100:.0f}%）\n截距={current_intercept:.2f} | 斜率={current_slope:.2f}',
                                          fontsize=14, pad=10, fontweight='bold', color='#2c3e50')
                return self.line_anim,
            
            temp_anim = FuncAnimation(self.fig, update_temp, frames=60, 
                                     interval=80, blit=True, repeat=False)
            
            temp_anim.save('ols_convergence_gui.gif', writer='pillow', 
                          fps=12, dpi=150, 
                          savefig_kwargs={'bbox_inches': 'tight', 'facecolor': '#f8f9fa'})
            
            messagebox.showinfo("成功", "✅ 动画已保存为 ols_convergence_gui.gif")
        except Exception as e:
            messagebox.showerror("错误", f"保存动画失败：{e}\n\n请确保已安装pillow库")
    
    def reset_defaults(self):
        """重置为默认参数"""
        self.n_samples = 100
        self.true_slope = 2.0
        self.true_intercept = 3.0
        self.noise_level = 1.2
        self.random_seed = 42
        
        # 重新创建控制面板（更新滑块值）
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame) and widget.cget('bg') == '#ffffff':
                widget.destroy()
                break
        self.create_widgets()
        self.update_plot()


def main():
    root = tk.Tk()
    app = OLSVisualizerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
