import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield'

    property bool bridgeReady: typeof hopfieldBridge !== 'undefined' && hopfieldBridge !== null

    RowLayout {
        anchors.fill: parent
        spacing: 10
        
        // 左侧控制面板
        ColumnLayout {
            Layout.preferredWidth: 400
            Layout.fillHeight: true
            spacing: 10
            
            GroupBox {
                title: '存储的模式'
                Layout.fillWidth: true
                Layout.preferredHeight: 140
                
                Item {
                    anchors.fill: parent
                    
                    RowLayout {
                        anchors.centerIn: parent
                        spacing: 15
                        
                        Repeater {
                            model: bridgeReady && hopfieldBridge.patterns ? hopfieldBridge.patterns.length : 0
                            
                            Loader {
                                sourceComponent: patternComponent
                                onLoaded: {
                                    item.patternData = bridgeReady && hopfieldBridge.patterns ? hopfieldBridge.patterns[index] : []
                                    item.gridSize = 5
                                    item.cellSize = 18
                                    item.title = "模式 " + (index + 1)
                                }
                            }
                        }
                    }
                }
            }

            GroupBox {
                title: '控制面板'
                Layout.fillWidth: true
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    
                    Label { text: '最大迭代次数' }
                    SpinBox {
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        value: 100
                        from: 10
                        to: 1000
                        stepSize: 10
                        onValueChanged: { if (bridgeReady) hopfieldBridge.max_iterations = value }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'UI刷新间隔' }
                    DoubleSpinBox {
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        value: 0.05 * 100
                        from: 0
                        to: 100
                        onValueChanged: { if (bridgeReady) hopfieldBridge.ui_refresh_interval = value / 100 }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '训练网络'
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        onClicked: { 
                            console.log("训练网络按钮被点击")
                            if (bridgeReady) hopfieldBridge.train_network() 
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                    }
                    
                    Button {
                        text: '寻找吸引子'
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        onClicked: { 
                            console.log("寻找吸引子按钮被点击")
                            if (bridgeReady) hopfieldBridge.find_attractors() 
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                    }
                    
                    Button {
                        text: '添加噪声并识别'
                        enabled: bridgeReady ? hopfieldBridge.has_finished : false
                        onClicked: {
                            console.log("添加噪声按钮被点击")
                            addNoiseAndRecognize()
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                    }
                    
                    Button {
                        text: '停止'
                        enabled: bridgeReady ? !hopfieldBridge.has_finished : false
                        onClicked: { if (bridgeReady) hopfieldBridge.stop_algorithm() }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                    }
                }
            }

            GroupBox {
                title: '网络信息'
                Layout.fillWidth: true
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    
                    Label { text: '神经元数量' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.n_neurons : '0'
                        font.bold: true
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '当前迭代' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.current_iterations : '0'
                        font.bold: true
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '当前能量' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.current_energy.toFixed(4) : '0.0000'
                        font.bold: true
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '是否收敛' }
                    Label { 
                        text: bridgeReady ? (hopfieldBridge.is_converged ? '是' : '否') : '否'
                        color: bridgeReady && hopfieldBridge.is_converged ? 'green' : 'red'
                        font.bold: true
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '吸引子数' }
                    Label { 
                        text: bridgeReady ? hopfieldBridge.n_attractors_found : '0'
                        font.bold: true
                        Layout.fillWidth: true
                    }
                }
            }

            GroupBox {
                title: '当前状态（可点击编辑）'
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                Item {
                    anchors.fill: parent
                    
                    Loader {
                        id: currentStateLoader
                        anchors.centerIn: parent
                        sourceComponent: patternComponent
                        onLoaded: {
                            item.patternData = Qt.binding(function() {
                                return bridgeReady && hopfieldBridge.current_state ? hopfieldBridge.current_state : []
                            })
                            item.gridSize = 5
                            item.cellSize = 35
                            item.editable = Qt.binding(function() {
                                return bridgeReady && hopfieldBridge.has_finished
                            })
                            item.onPatternEdited.connect(function(newPattern) {
                                if (bridgeReady && hopfieldBridge.has_finished) {
                                    console.log("手动编辑模式，开始识别")
                                    hopfieldBridge.start_recognition(newPattern)
                                }
                            })
                        }
                    }
                }
            }
        }
        
        // 右侧吸引子列表区域
        GroupBox {
            title: '吸引子列表'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ScrollView {
                anchors.fill: parent
                clip: true
                
                Flow {
                    width: parent.parent.width - 20
                    spacing: 12
                    padding: 10
                    
                    Repeater {
                        model: bridgeReady && hopfieldBridge.attractors ? hopfieldBridge.attractors.length : 0
                        
                        Loader {
                            sourceComponent: attractorComponent
                            property int attractorIndex: index
                            
                            onLoaded: {
                                if (bridgeReady && hopfieldBridge.attractors && attractorIndex < hopfieldBridge.attractors.length) {
                                    item.patternData = hopfieldBridge.attractors[attractorIndex]
                                    item.gridSize = 5
                                    item.cellSize = 32
                                    var energy = (hopfieldBridge.attractor_energies && attractorIndex < hopfieldBridge.attractor_energies.length) ?
                                                 hopfieldBridge.attractor_energies[attractorIndex].toFixed(2) : "0.00"
                                    item.title = "吸引子 " + (attractorIndex + 1) + "\n能量: " + energy
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Component {
        id: patternComponent
        
        Item {
            id: patternItem
            property var patternData: []
            property int gridSize: 5
            property int cellSize: 30
            property string title: ""
            property bool editable: false
            
            signal onPatternEdited(var newPattern)
            
            implicitWidth: gridSize * (cellSize + 2) + 20
            implicitHeight: gridSize * (cellSize + 2) + 60
            
            ColumnLayout {
                anchors.fill: parent
                spacing: 5
                
                Label {
                    text: title
                    font.bold: true
                    horizontalAlignment: Text.AlignHCenter
                    Layout.alignment: Qt.AlignHCenter
                    visible: title !== ""
                    wrapMode: Text.WordWrap
                    Layout.preferredWidth: parent.width
                }
                
                Grid {
                    columns: gridSize
                    spacing: 2
                    Layout.alignment: Qt.AlignHCenter
                    
                    Repeater {
                        model: gridSize * gridSize
                        
                        Rectangle {
                            width: cellSize
                            height: cellSize
                            color: {
                                if (!patternData || index >= patternData.length)
                                    return "lightgray"
                                return patternData[index] === 1 ? "black" : "white"
                            }
                            border.color: "gray"
                            border.width: 1
                            
                            MouseArea {
                                anchors.fill: parent
                                enabled: editable
                                cursorShape: editable ? Qt.PointingHandCursor : Qt.ArrowCursor
                                
                                onClicked: {
                                    if (editable && patternData && index < patternData.length) {
                                        var newPattern = []
                                        for (var i = 0; i < patternData.length; i++) {
                                            newPattern[i] = patternData[i]
                                        }
                                        newPattern[index] = -newPattern[index]
                                        patternItem.onPatternEdited(newPattern)
                                    }
                                }
                            }
                        }
                    }
                }
                
                Item { Layout.fillHeight: true }
            }
        }
    }
    
    Component {
        id: attractorComponent
        
        Item {
            property var patternData: []
            property int gridSize: 5
            property int cellSize: 18
            property string title: ""
            
            implicitWidth: gridSize * (cellSize + 2) + 20
            implicitHeight: gridSize * (cellSize + 2) + 60
            
            ColumnLayout {
                anchors.fill: parent
                spacing: 5
                
                Label {
                    text: title
                    font.bold: true
                    font.pixelSize: 20
                    horizontalAlignment: Text.AlignHCenter
                    Layout.alignment: Qt.AlignHCenter
                    visible: title !== ""
                    wrapMode: Text.WordWrap
                    Layout.preferredWidth: parent.width
                }
                
                Grid {
                    columns: gridSize
                    spacing: 2
                    Layout.alignment: Qt.AlignHCenter
                    
                    Repeater {
                        model: gridSize * gridSize
                        
                        Rectangle {
                            width: cellSize
                            height: cellSize
                            color: {
                                if (!patternData || index >= patternData.length)
                                    return "lightgray"
                                return patternData[index] === 1 ? "black" : "white"
                            }
                            border.color: "gray"
                            border.width: 1
                        }
                    }
                }
                
                Item { Layout.fillHeight: true }
            }
        }
    }

    function addNoiseAndRecognize() {
        if (!bridgeReady || !hopfieldBridge.patterns || hopfieldBridge.patterns.length === 0)
            return
        
        var patternIdx = Math.floor(Math.random() * hopfieldBridge.patterns.length)
        var pattern = hopfieldBridge.patterns[patternIdx].slice()
        
        var noiseLevel = 0.2
        var nFlips = Math.floor(pattern.length * noiseLevel)
        for (var i = 0; i < nFlips; i++) {
            var idx = Math.floor(Math.random() * pattern.length)
            pattern[idx] = -pattern[idx]
        }
        
        console.log("添加噪声后的模式:", pattern)
        hopfieldBridge.start_recognition(pattern)
    }

    Connections {
        target: bridgeReady ? hopfieldBridge : null
        enabled: bridgeReady
        
        function onAttractorsChanged() {
            console.log("吸引子列表更新，找到", hopfieldBridge.n_attractors_found, "个吸引子")
        }
    }
    
    Component.onCompleted: {
        console.log("Hopfield 页面加载完成")
        console.log("Bridge 就绪:", bridgeReady)
        if (bridgeReady) {
            console.log("初始模式数:", hopfieldBridge.patterns ? hopfieldBridge.patterns.length : 0)
        }
    }
}