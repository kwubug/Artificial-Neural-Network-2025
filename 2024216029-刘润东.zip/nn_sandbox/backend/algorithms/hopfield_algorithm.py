import numpy as np
import threading
import time


class HopfieldAlgorithm(threading.Thread):
    """
    离散型Hopfield神经网络算法实现
    实现异步更新、吸引子检测和能量计算
    """
    
    def __init__(self, patterns, max_iterations=100, async_update=True):
        """
        初始化Hopfield网络
        
        Args:
            patterns: 要存储的模式列表，每个模式是一个{-1, 1}数组
            max_iterations: 最大迭代次数
            async_update: 是否使用异步更新（True）或同步更新（False）
        """
        super().__init__()
        self.patterns = np.array(patterns)
        self.num_neurons = len(patterns[0]) if len(patterns) > 0 else 0
        self.max_iterations = max_iterations
        self.async_update = async_update
        self._should_stop = False
        
        # 使用Hebb规则计算权重矩阵
        self.weights = self._calculate_weights()
        
        # 初始化状态（可以是随机的或某个模式的扰动版本）
        self.state = np.random.choice([-1, 1], self.num_neurons)
        
        # 记录历史
        self.energy_history = []
        self.state_history = []
        self.current_iteration = 0
        self.current_energy = self._calculate_energy()
        self.is_stable = False
        self.attractor = None
        
    def _calculate_weights(self):
        """使用Hebb规则计算权重矩阵"""
        weights = np.zeros((self.num_neurons, self.num_neurons))
        
        for pattern in self.patterns:
            weights += np.outer(pattern, pattern)
            
        # 归一化
        weights = weights / len(self.patterns)
        
        # 对角线设为0（无自连接）
        np.fill_diagonal(weights, 0)
        
        return weights
    
    def set_initial_state(self, state):
        """设置初始状态"""
        self.state = np.array(state)
        self.current_energy = self._calculate_energy()
        
    def run(self):
        """运行网络直到收敛到吸引子"""
        prev_state = None
        stable_count = 0
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 保存上一个状态
            prev_state = self.state.copy()
            
            # 更新神经元
            if self.async_update:
                self._async_update()
            else:
                self._sync_update()
            
            # 计算能量
            self.current_energy = self._calculate_energy()
            self.energy_history.append(self.current_energy)
            self.state_history.append(self.state.copy())
            
            # 检查是否稳定
            if np.array_equal(self.state, prev_state):
                stable_count += 1
                if stable_count >= 5:  # 连续5次状态不变则认为稳定
                    self.is_stable = True
                    self.attractor = self.state.copy()
                    break
            else:
                stable_count = 0
            
            # 添加延迟以便可视化
            time.sleep(0.1)
        
        # 如果没有完全稳定，使用最后的状态作为吸引子
        if not self.is_stable:
            self.attractor = self.state.copy()
            
    def _async_update(self):
        """异步更新：每次随机选择一个神经元更新"""
        idx = np.random.randint(0, self.num_neurons)
        net_input = np.dot(self.weights[idx], self.state)
        self.state[idx] = 1 if net_input >= 0 else -1
        
    def _sync_update(self):
        """同步更新：同时更新所有神经元"""
        net_input = np.dot(self.weights, self.state)
        self.state = np.where(net_input >= 0, 1, -1)
        
    def _calculate_energy(self):
        """
        计算Hopfield网络能量
        E = -0.5 * Σ(w_ij * s_i * s_j)
        """
        energy = -0.5 * np.sum(
            self.weights * np.outer(self.state, self.state)
        )
        return energy
    
    def stop(self):
        """停止算法运行"""
        self._should_stop = True
        
    def find_attractor_for_pattern(self, pattern):
        """给定一个模式（可能有噪声），找到其吸引子"""
        self.set_initial_state(pattern)
        self.run()
        return self.attractor
    
    def get_statistics(self):
        """返回统计信息"""
        # 找到最接近的存储模式
        closest_pattern_idx = -1
        if self.attractor is not None:
            similarities = [np.dot(self.attractor, p) for p in self.patterns]
            closest_pattern_idx = int(np.argmax(similarities))
        
        return {
            'current_state': self.state.tolist(),
            'weights': self.weights.tolist(),
            'current_energy': float(self.current_energy),
            'is_stable': self.is_stable,
            'attractor': self.attractor.tolist() if self.attractor is not None else None,
            'attractor_energy': float(self._calculate_energy_for_state(self.attractor)) if self.attractor is not None else 0,
            'patterns': self.patterns.tolist(),
            'closest_pattern_idx': closest_pattern_idx
        }
    
    def _calculate_energy_for_state(self, state):
        """计算给定状态的能量"""
        if state is None:
            return 0
        return -0.5 * np.sum(self.weights * np.outer(state, state))


class ObservableHopfieldAlgorithm(HopfieldAlgorithm):
    """Observable版本的Hopfield算法，用于与Bridge集成"""
    
    def __init__(self, observer, patterns, max_iterations=100, async_update=True):
        HopfieldAlgorithm.__init__(self, patterns, max_iterations, async_update)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            self._observer.update(name, value)
        
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_energy', 'state', 'is_stable']:
            if hasattr(self, '_observer'):
                self.notify(name, value)
                
    def run(self):
        """重写run方法以添加通知"""
        # 发送初始状态
        self.notify('statistics', self.get_statistics())
        
        prev_state = None
        stable_count = 0
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            prev_state = self.state.copy()
            
            if self.async_update:
                self._async_update()
            else:
                self._sync_update()
            
            self.current_energy = self._calculate_energy()
            self.energy_history.append(self.current_energy)
            self.state_history.append(self.state.copy())
            
            # 通知统计信息
            self.notify('statistics', self.get_statistics())
            
            if np.array_equal(self.state, prev_state):
                stable_count += 1
                if stable_count >= 5:
                    self.is_stable = True
                    self.attractor = self.state.copy()
                    self.notify('statistics', self.get_statistics())
                    break
            else:
                stable_count = 0
            
            time.sleep(0.05)
        
        if not self.is_stable:
            self.attractor = self.state.copy()
            self.notify('statistics', self.get_statistics())

