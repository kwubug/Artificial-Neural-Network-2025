import numpy as np
import matplotlib.pyplot as plt
import random
import math
import time
import tkinter as tk
from tkinter import ttk, messagebox, Scale
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import threading

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

class TSPVisualizer:
    """旅行商问题可视化工具"""
    
    def __init__(self, root):
        """初始化TSP可视化器"""
        self.root = root
        self.root.title("旅行商问题(TSP)可视化工具")
        self.root.geometry("1200x800")
        self.root.resizable(True, True)
        
        # 数据存储
        self.cities = []  # 城市坐标列表
        self.best_path = []  # 最优路径
        self.best_distance = float('inf')  # 最优路径长度
        self.algorithm_running = False  # 算法运行状态
        self.algorithm_thread = None  # 算法线程
        self.stop_event = threading.Event()  # 停止事件
        
        # 创建界面
        self._create_widgets()
        
        # 绑定鼠标事件
        self.canvas.mpl_connect('button_press_event', self._on_canvas_click)
    
    def _create_widgets(self):
        """创建界面组件"""
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建左侧控制面板
        control_frame = ttk.LabelFrame(main_frame, text="控制面板", padding="10")
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        
        # 城市管理
        city_frame = ttk.LabelFrame(control_frame, text="城市管理", padding="10")
        city_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(city_frame, text="随机生成城市", command=self._generate_random_cities).pack(fill=tk.X, pady=2)
        
        ttk.Label(city_frame, text="城市数量:").pack(anchor=tk.W, pady=2)
        self.city_count_var = tk.IntVar(value=10)
        ttk.Scale(city_frame, from_=2, to=50, orient=tk.HORIZONTAL,
                 variable=self.city_count_var, command=lambda v: None).pack(fill=tk.X, pady=2)
        ttk.Label(city_frame, textvariable=self.city_count_var).pack(anchor=tk.CENTER)
        
        ttk.Button(city_frame, text="清除所有城市", command=self._clear_cities).pack(fill=tk.X, pady=2)
        
        # 算法选择
        algo_frame = ttk.LabelFrame(control_frame, text="算法选择", padding="10")
        algo_frame.pack(fill=tk.X, pady=5)
        
        self.algorithm_var = tk.StringVar(value="ga")
        ttk.Radiobutton(algo_frame, text="遗传算法", variable=self.algorithm_var, value="ga").pack(anchor=tk.W)
        ttk.Radiobutton(algo_frame, text="模拟退火", variable=self.algorithm_var, value="sa").pack(anchor=tk.W)
        ttk.Radiobutton(algo_frame, text="动态规划", variable=self.algorithm_var, value="dp").pack(anchor=tk.W)
        
        # 算法参数
        self.param_frame = ttk.LabelFrame(control_frame, text="算法参数", padding="10")
        self.param_frame.pack(fill=tk.X, pady=5)
        self._update_param_widgets()
        
        # 运行控制
        run_frame = ttk.LabelFrame(control_frame, text="运行控制", padding="10")
        run_frame.pack(fill=tk.X, pady=5)
        
        self.run_button = ttk.Button(run_frame, text="开始求解", command=self._start_solving)
        self.run_button.pack(fill=tk.X, pady=2)
        
        self.stop_button = ttk.Button(run_frame, text="停止求解", command=self._stop_solving, state=tk.DISABLED)
        self.stop_button.pack(fill=tk.X, pady=2)
        
        # 结果显示
        result_frame = ttk.LabelFrame(control_frame, text="结果", padding="10")
        result_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.distance_var = tk.StringVar(value="总距离: --")
        ttk.Label(result_frame, textvariable=self.distance_var).pack(anchor=tk.W, pady=2)
        
        self.time_var = tk.StringVar(value="计算时间: --")
        ttk.Label(result_frame, textvariable=self.time_var).pack(anchor=tk.W, pady=2)
        
        self.iterations_var = tk.StringVar(value="迭代次数: --")
        ttk.Label(result_frame, textvariable=self.iterations_var).pack(anchor=tk.W, pady=2)
        
        # 创建右侧可视化区域
        viz_frame = ttk.LabelFrame(main_frame, text="可视化", padding="10")
        viz_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 创建Matplotlib图形
        self.fig = Figure(figsize=(8, 6), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_title("点击添加城市，右键删除城市")
        self.ax.set_xlabel("X坐标")
        self.ax.set_ylabel("Y坐标")
        self.ax.grid(True)
        self.ax.set_xlim(0, 800)
        self.ax.set_ylim(0, 600)
        
        # 创建画布
        self.canvas = FigureCanvasTkAgg(self.fig, master=viz_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 添加工具栏
        toolbar_frame = ttk.Frame(viz_frame)
        toolbar_frame.pack(fill=tk.X)
        toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame)
        toolbar.update()
    
    def _update_param_widgets(self):
        """根据选择的算法更新参数控件"""
        # 清除现有控件
        for widget in self.param_frame.winfo_children():
            widget.destroy()
        
        algorithm = self.algorithm_var.get()
        
        if algorithm == "ga":
            # 遗传算法参数
            ttk.Label(self.param_frame, text="种群大小:").pack(anchor=tk.W, pady=2)
            self.population_size_var = tk.IntVar(value=100)
            Scale(self.param_frame, from_=10, to=500, orient=tk.HORIZONTAL,
                 variable=self.population_size_var, resolution=10,
                 command=lambda v: None).pack(fill=tk.X)
            
            ttk.Label(self.param_frame, text="迭代代数:").pack(anchor=tk.W, pady=2)
            self.generations_var = tk.IntVar(value=1000)
            Scale(self.param_frame, from_=100, to=5000, orient=tk.HORIZONTAL,
                 variable=self.generations_var, resolution=100,
                 command=lambda v: None).pack(fill=tk.X)
            
            ttk.Label(self.param_frame, text="交叉概率:").pack(anchor=tk.W, pady=2)
            self.crossover_rate_var = tk.DoubleVar(value=0.8)
            Scale(self.param_frame, from_=0.1, to=1.0, orient=tk.HORIZONTAL,
                 variable=self.crossover_rate_var, resolution=0.1,
                 command=lambda v: None).pack(fill=tk.X)
            
            ttk.Label(self.param_frame, text="变异概率:").pack(anchor=tk.W, pady=2)
            self.mutation_rate_var = tk.DoubleVar(value=0.1)
            Scale(self.param_frame, from_=0.01, to=0.5, orient=tk.HORIZONTAL,
                 variable=self.mutation_rate_var, resolution=0.01,
                 command=lambda v: None).pack(fill=tk.X)
        
        elif algorithm == "sa":
            # 模拟退火参数
            ttk.Label(self.param_frame, text="初始温度:").pack(anchor=tk.W, pady=2)
            self.initial_temp_var = tk.DoubleVar(value=1000.0)
            Scale(self.param_frame, from_=100, to=5000, orient=tk.HORIZONTAL,
                 variable=self.initial_temp_var, resolution=100,
                 command=lambda v: None).pack(fill=tk.X)
            
            ttk.Label(self.param_frame, text="降温率:").pack(anchor=tk.W, pady=2)
            self.cooling_rate_var = tk.DoubleVar(value=0.995)
            Scale(self.param_frame, from_=0.9, to=0.999, orient=tk.HORIZONTAL,
                 variable=self.cooling_rate_var, resolution=0.001,
                 command=lambda v: None).pack(fill=tk.X)
            
            ttk.Label(self.param_frame, text="停止温度:").pack(anchor=tk.W, pady=2)
            self.stopping_temp_var = tk.DoubleVar(value=0.1)
            Scale(self.param_frame, from_=0.01, to=10.0, orient=tk.HORIZONTAL,
                 variable=self.stopping_temp_var, resolution=0.01,
                 command=lambda v: None).pack(fill=tk.X)
        
        elif algorithm == "dp":
            # 动态规划算法没有参数
            ttk.Label(self.param_frame, text="动态规划是精确算法，适合小规模问题 (<20个城市)").pack(anchor=tk.W, pady=2)
    
    def _on_canvas_click(self, event):
        """处理画布点击事件"""
        if event.inaxes != self.ax:
            return
        
        x, y = event.xdata, event.ydata
        
        if event.button == 1:  # 左键点击添加城市
            self.cities.append((x, y))
            self._update_plot()
        elif event.button == 3:  # 右键点击删除城市
            self._remove_city_near(x, y)
    
    def _remove_city_near(self, x, y, tolerance=20):
        """删除指定坐标附近的城市"""
        for i, (cx, cy) in enumerate(self.cities):
            if math.sqrt((cx - x) **2 + (cy - y)** 2) < tolerance:
                del self.cities[i]
                self._update_plot()
                break
    
    def _generate_random_cities(self):
        """随机生成城市"""
        count = self.city_count_var.get()
        self.cities = []
        for _ in range(count):
            x = random.uniform(50, 750)
            y = random.uniform(50, 550)
            self.cities.append((x, y))
        self._update_plot()
    
    def _clear_cities(self):
        """清除所有城市"""
        self.cities = []
        self.best_path = []
        self.best_distance = float('inf')
        self.distance_var.set("总距离: --")
        self.time_var.set("计算时间: --")
        self.iterations_var.set("迭代次数: --")
        self._update_plot()
    
    def _start_solving(self):
        """开始求解TSP问题"""
        if len(self.cities) < 2:
            messagebox.showerror("错误", "至少需要2个城市")
            return
        
        # 对于动态规划算法，限制城市数量
        if self.algorithm_var.get() == "dp" and len(self.cities) > 20:
            if not messagebox.askyesno("警告", "动态规划算法在城市数量较多时会非常慢，确定要继续吗？"):
                return
        
        # 更新按钮状态
        self.run_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        self.algorithm_running = True
        self.stop_event.clear()
        
        # 在新线程中运行算法
        self.algorithm_thread = threading.Thread(target=self._solve_tsp)
        self.algorithm_thread.daemon = True
        self.algorithm_thread.start()
    
    def _stop_solving(self):
        """停止求解过程"""
        self.stop_event.set()
    
    def _solve_tsp(self):
        """在新线程中求解TSP问题"""
        try:
            start_time = time.time()
            algorithm = self.algorithm_var.get()
            
            if algorithm == "ga":
                # 遗传算法
                result = self._genetic_algorithm(
                    population_size=self.population_size_var.get(),
                    generations=self.generations_var.get(),
                    crossover_rate=self.crossover_rate_var.get(),
                    mutation_rate=self.mutation_rate_var.get()
                )
            elif algorithm == "sa":
                # 模拟退火算法
                result = self._simulated_annealing(
                    initial_temperature=self.initial_temp_var.get(),
                    cooling_rate=self.cooling_rate_var.get(),
                    stopping_temperature=self.stopping_temp_var.get()
                )
            elif algorithm == "dp":
                # 动态规划算法
                result = self._dynamic_programming()
            
            execution_time = time.time() - start_time
            
            # 更新结果
            if result and not self.stop_event.is_set():
                self.best_path = result['path']
                self.best_distance = result['distance']
                iterations = result.get('iterations', 0)
                
                # 在主线程中更新UI
                self.root.after(0, lambda: self._update_results(execution_time, iterations))
                self.root.after(0, self._update_plot)
        
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("错误", f"算法执行出错: {str(e)}"))
        finally:
            # 恢复按钮状态
            self.root.after(0, lambda: self.run_button.config(state=tk.NORMAL))
            self.root.after(0, lambda: self.stop_button.config(state=tk.DISABLED))
            self.algorithm_running = False
    
    def _update_results(self, execution_time, iterations):
        """更新结果显示"""
        self.distance_var.set(f"总距离: {self.best_distance:.2f}")
        self.time_var.set(f"计算时间: {execution_time:.2f}秒")
        self.iterations_var.set(f"迭代次数: {iterations}")
    
    def _update_plot(self):
        """更新可视化图表"""
        self.ax.clear()
        self.ax.set_title("点击添加城市，右键删除城市")
        self.ax.set_xlabel("X坐标")
        self.ax.set_ylabel("Y坐标")
        self.ax.grid(True)
        self.ax.set_xlim(0, 800)
        self.ax.set_ylim(0, 600)
        
        # 绘制城市
        if self.cities:
            cities_array = np.array(self.cities)
            self.ax.scatter(cities_array[:, 0], cities_array[:, 1], c='red', s=50, label='城市')
            
            # 标注城市序号
            for i, (x, y) in enumerate(self.cities):
                self.ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points')
            
            # 绘制最优路径
            if self.best_path:
                path_coords = cities_array[self.best_path]
                # 添加起点到路径末尾以闭合路径
                path_coords = np.vstack([path_coords, path_coords[0]])
                self.ax.plot(path_coords[:, 0], path_coords[:, 1], 'b-', linewidth=1, label='最优路径')
        
        self.ax.legend()
        self.canvas.draw()
    
    def _calculate_distance(self, path):
        """计算路径总长度"""
        total_distance = 0
        n = len(path)
        for i in range(n):
            j = (i + 1) % n
            x1, y1 = self.cities[path[i]]
            x2, y2 = self.cities[path[j]]
            total_distance += math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
        return total_distance
    
    def _genetic_algorithm(self, population_size=100, generations=1000, 
                           crossover_rate=0.8, mutation_rate=0.1):
        """遗传算法求解TSP"""
        n_cities = len(self.cities)
        
        # 创建初始种群
        def create_individual():
            return random.sample(range(n_cities), n_cities)
        
        population = [create_individual() for _ in range(population_size)]
        
        best_individual = None
        best_distance = float('inf')
        
        for generation in range(generations):
            # 检查是否停止
            if self.stop_event.is_set():
                return None
            
            # 计算适应度（距离的倒数）
            fitness = [1 / self._calculate_distance(individual) for individual in population]
            
            # 选择（轮盘赌选择）
            total_fitness = sum(fitness)
            if total_fitness == 0:
                probabilities = [1/population_size] * population_size
            else:
                probabilities = [f/total_fitness for f in fitness]
            
            # 创建新一代
            new_population = []
            
            # 保留最佳个体
            best_idx = fitness.index(max(fitness))
            current_best_distance = self._calculate_distance(population[best_idx])
            if current_best_distance < best_distance:
                best_distance = current_best_distance
                best_individual = population[best_idx].copy()
                
                # 每10代更新一次图形
                if generation % 10 == 0:
                    self.root.after(0, self._update_plot)
            
            new_population.append(best_individual.copy())
            
            # 生成剩余个体
            for _ in range(population_size - 1):
                # 选择父母
                parents = random.choices(population, weights=probabilities, k=2)
                
                # 交叉
                if random.random() < crossover_rate:
                    # 单点交叉
                    point = random.randint(1, n_cities - 2)
                    child = parents[0][:point] + [city for city in parents[1] if city not in parents[0][:point]]
                else:
                    child = parents[0].copy()
                
                # 变异
                for i in range(n_cities):
                    if random.random() < mutation_rate:
                        j = random.randint(0, n_cities - 1)
                        child[i], child[j] = child[j], child[i]
                
                new_population.append(child)
            
            population = new_population
        
        return {'path': best_individual, 'distance': best_distance, 'iterations': generations}
    
    def _simulated_annealing(self, initial_temperature=1000.0, cooling_rate=0.995, 
                            stopping_temperature=0.1):
        """模拟退火算法求解TSP"""
        n_cities = len(self.cities)
        
        # 初始解
        current_path = list(range(n_cities))
        random.shuffle(current_path)
        current_distance = self._calculate_distance(current_path)
        
        best_path = current_path.copy()
        best_distance = current_distance
        
        temperature = initial_temperature
        iteration = 0
        
        while temperature > stopping_temperature:
            # 检查是否停止
            if self.stop_event.is_set():
                return None
            
            # 生成邻域解（交换两个城市）
            new_path = current_path.copy()
            i, j = sorted(random.sample(range(n_cities), 2))
            new_path[i], new_path[j] = new_path[j], new_path[i]
            new_distance = self._calculate_distance(new_path)
            
            # 决定是否接受新解
            if new_distance < current_distance or random.random() < math.exp((current_distance - new_distance) / temperature):
                current_path = new_path
                current_distance = new_distance
                
                # 更新全局最优
                if current_distance < best_distance:
                    best_path = current_path.copy()
                    best_distance = current_distance
            
            # 降温
            temperature *= cooling_rate
            iteration += 1
            
            # 每100次迭代更新一次图形
            if iteration % 100 == 0:
                self.root.after(0, self._update_plot)
        
        return {'path': best_path, 'distance': best_distance, 'iterations': iteration}
    
    def _dynamic_programming(self):
        """动态规划算法求解TSP"""
        n_cities = len(self.cities)
        
        # 预计算距离矩阵
        dist_matrix = [[0] * n_cities for _ in range(n_cities)]
        for i in range(n_cities):
            for j in range(n_cities):
                if i != j:
                    x1, y1 = self.cities[i]
                    x2, y2 = self.cities[j]
                    dist_matrix[i][j] = math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
        
        # 初始化DP表
        # dp[mask][i] 表示访问过mask中的城市，最后到达城市i的最短距离
        dp = [[float('inf')] * n_cities for _ in range(1 << n_cities)]
        for i in range(n_cities):
            dp[1 << i][i] = 0
        
        # 填充DP表
        for mask in range(1, 1 << n_cities):
            # 检查是否停止
            if self.stop_event.is_set():
                return None
            
            for i in range(n_cities):
                if not (mask & (1 << i)):
                    continue
                
                prev_mask = mask ^ (1 << i)
                for j in range(n_cities):
                    if not (prev_mask & (1 << j)):
                        continue
                    
                    if dp[prev_mask][j] + dist_matrix[j][i] < dp[mask][i]:
                        dp[mask][i] = dp[prev_mask][j] + dist_matrix[j][i]
            
            # 定期更新UI
            if mask % 1000 == 0:
                self.root.after(0, lambda: self.ax.set_title(f"动态规划求解中... mask: {mask}"))
                self.root.after(0, self.canvas.draw)
        
        # 找到最优解
        full_mask = (1 << n_cities) - 1
        min_distance = float('inf')
        last_city = -1
        
        for i in range(n_cities):
            if dp[full_mask][i] + dist_matrix[i][0] < min_distance:
                min_distance = dp[full_mask][i] + dist_matrix[i][0]
                last_city = i
        
        # 重构路径
        path = []
        mask = full_mask
        city = last_city
        
        while mask != 0:
            path.append(city)
            prev_mask = mask ^ (1 << city)
            
            # 找到前驱城市
            for j in range(n_cities):
                if prev_mask & (1 << j) and dp[prev_mask][j] + dist_matrix[j][city] == dp[mask][city]:
                    city = j
                    break
            
            mask = prev_mask
        
        path.append(0)
        path.reverse()
        
        return {'path': path, 'distance': min_distance, 'iterations': full_mask}

if __name__ == "__main__":
    # 创建主窗口
    root = tk.Tk()
    # 创建应用实例
    app = TSPVisualizer(root)
    # 启动主循环
    root.mainloop()