"""
gd_lab_interactive.py
一个“接近 MATLAB App”的纯 Python 可视化小工具：最速下降 / 牛顿法 / 共轭梯度（FR）
- 依赖：numpy, matplotlib（均很常见，Anaconda 默认有）
- 运行：python gd_lab_interactive.py
- 功能：
  * 选择目标函数（Quadratic / Rosenbrock）
  * 选择算法（Steepest Descent / Newton / Conjugate Gradient-FR）
  * 拖动滑块设定初始点 (x1,x2)、最大步数、Armijo 参数
  * 勾选“二次函数解析步长”
  * 点击 [Run] 绘制等高线 + 轨迹；[Clear] 清空图面
"""
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons, CheckButtons

# ——中文字体（可按需修改/删除）——
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = True
matplotlib.rcParams['mathtext.fontset'] = 'dejavusans'

# ============== 目标函数集合 ==============
def make_problem(name):
    name = name.lower()
    if name == "quadratic":
        A = np.array([[2.0, 1.0],[1.0, 2.0]])
        d = np.array([0.0, 0.0])
        def f(x):   return 0.5 * x @ A @ x + d @ x
        def g(x):   return A @ x + d
        def H(x):   return A
        box = np.array([[-3.0, 3.0], [-3.0, 3.0]])
        return f, g, H, box, True  # True 表示 Hessian 常数（近似“二次”）
    elif name == "rosenbrock":
        def f(x):   return (1 - x[0])**2 + 100.0 * (x[1] - x[0]**2)**2
        def g(x):
            return np.array([
                -2.0*(1 - x[0]) - 400.0*x[0]*(x[1] - x[0]**2),
                 200.0*(x[1] - x[0]**2)
            ])
        def H(x):
            return np.array([
                [2.0 - 400.0*(x[1] - 3.0*x[0]**2), -400.0*x[0]],
                [-400.0*x[0], 200.0]
            ])
        box = np.array([[-2.0, 2.0], [-1.0, 3.0]])
        return f, g, H, box, False
    else:
        raise ValueError("未知 problem 名称")

# ============== 线搜索 / 算法 ==============
def backtracking_armijo(f, grad, x, p, alpha0, rho, c, max_bt):
    alpha = alpha0
    fx = f(x); gx = grad(x)
    for _ in range(int(max_bt)):
        if f(x + alpha*p) <= fx + c * alpha * (gx @ p):
            return alpha
        alpha *= rho
    return max(alpha, 1e-12)

def run_sd(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, use_exact_for_quad):
    x = x0.copy(); gx = g(x)
    traj = [x.copy()]
    # 判断是否常 Hessian
    is_quad = use_exact_for_quad
    steps = 0
    for k in range(int(itmax)):
        if np.linalg.norm(gx) < tol: break
        p = -gx
        if is_quad:
            A = H(x); alpha = (gx @ gx) / (p @ A @ p)
        else:
            alpha = backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
        x = x + alpha * p
        gx = g(x)
        traj.append(x.copy()); steps += 1
    return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))

def run_newton(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt):
    x = x0.copy(); gx = g(x)
    traj = [x.copy()]; steps = 0
    for k in range(int(itmax)):
        if np.linalg.norm(gx) < tol: break
        Hx = H(x)
        # 简单阻尼以保障下降
        try:
            p = -np.linalg.solve(Hx, gx)
        except np.linalg.LinAlgError:
            Hx = Hx + 1e-6*np.eye(2)
            p = -np.linalg.solve(Hx, gx)
        if gx @ p >= 0:
            mu = 1e-6; I = np.eye(2)
            for _ in range(10):
                p = -np.linalg.solve(Hx + mu*I, gx)
                if gx @ p < 0: break
                mu *= 10
        alpha = backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
        x = x + alpha * p
        gx = g(x)
        traj.append(x.copy()); steps += 1
    return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))

def run_cg_fr(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, use_exact_for_quad):
    x = x0.copy(); gx = g(x); p = -gx
    traj = [x.copy()]; steps = 0
    is_quad = use_exact_for_quad
    for k in range(int(itmax)):
        if np.linalg.norm(gx) < tol: break
        if is_quad:
            A = H(x); alpha = (gx @ gx) / (p @ A @ p)
        else:
            alpha = backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
        x_new = x + alpha * p
        gx_new = g(x_new)
        traj.append(x_new.copy()); steps += 1
        if np.linalg.norm(gx_new) < tol:
            x, gx = x_new, gx_new; break
        beta = (gx_new @ gx_new) / (gx @ gx + 1e-16)
        p = -gx_new + beta * p
        if gx_new @ p >= 0:  # 重启
            p = -gx_new
        x, gx = x_new, gx_new
    return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))

# ============== 绘图布局（带控件） ==============
plt.close('all')
fig = plt.figure(figsize=(11.0, 7), facecolor='white')  # 进一步增大窗口宽度
ax = fig.add_axes([0.05, 0.20, 0.64, 0.75])  # 主图宽度略减以腾出右侧空间

ax.set_title("梯度法可视化（等高线 + 轨迹）")
ax.set_xlabel("x1"); ax.set_ylabel("x2")
ax.grid(True); ax.set_aspect('equal', adjustable='box')

# 右侧控制面板，x起始左移到0.71，宽度增大到0.27以显示完整数字
ax_method = fig.add_axes([0.63, 0.78, 0.27, 0.15])
rb_method = RadioButtons(ax_method, ('Steepest Descent', 'Newton', 'Conjugate Gradient-FR'), active=0)
ax_prob   = fig.add_axes([0.63, 0.63, 0.27, 0.12])
rb_prob   = RadioButtons(ax_prob, ('Quadratic', 'Rosenbrock'), active=0)

ax_chk = fig.add_axes([0.63, 0.57, 0.27, 0.05])
chk = CheckButtons(ax_chk, ['Quadratic 精确步长'], [True])

# 滑块区域，左侧滑块宽度增大
ax_x1    = fig.add_axes([0.08, 0.12, 0.45, 0.03])
ax_x2    = fig.add_axes([0.08, 0.08, 0.45, 0.03])
ax_it    = fig.add_axes([0.08, 0.04, 0.45, 0.03])

# 右侧滑块，下移到与左侧齐平（y=0.13~0.01），x左移，宽度增大
ax_a0    = fig.add_axes([0.63, 0.13, 0.27, 0.03])
ax_rho   = fig.add_axes([0.63, 0.09, 0.27, 0.03])
ax_c     = fig.add_axes([0.63, 0.05, 0.27, 0.03])
ax_bt    = fig.add_axes([0.63, 0.01, 0.27, 0.03])

s_x1  = Slider(ax_x1, 'x1 (init)', -2.5, 2.5, valinit=1.5)
s_x2  = Slider(ax_x2, 'x2 (init)', -2.5, 2.5, valinit=-0.5)
s_it  = Slider(ax_it, '最大步数',    1, 300, valinit=200, valstep=1)

s_a0  = Slider(ax_a0, 'α0',  1e-3, 2.0, valinit=1.0, valstep=1e-3)
s_rho = Slider(ax_rho, 'ρ',   0.10, 0.95, valinit=0.5)
s_c   = Slider(ax_c,   'c',   1e-6, 1e-1, valinit=1e-4)
s_bt  = Slider(ax_bt,  '回溯次数', 1, 50, valinit=30, valstep=1)

# 按钮，调整x位置和宽度
ax_run   = fig.add_axes([0.63, 0.48, 0.13, 0.05])
ax_clear = fig.add_axes([0.78, 0.48, 0.13, 0.05])
btn_run   = Button(ax_run,   'Run')
btn_clear = Button(ax_clear, 'Clear')

# 文本信息区，上移到按钮下方（0.30~0.48），高度减小到0.18避免重叠，字体减小
ax_txt = fig.add_axes([0.63, 0.25, 0.27, 0.18])  # 往下面挪一点（y从0.30到0.25）
ax_txt.axis('off')
txt_handle = ax_txt.text(0.0, 1.0, "", va='top', family='monospace', fontsize=9)  # 字体大一点（从7到9）

# 初始化等高线
def draw_contours(ax, f, box):
    x1 = np.linspace(box[0,0], box[0,1], 300)
    x2 = np.linspace(box[1,0], box[1,1], 300)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.zeros_like(X1)
    for i in range(X1.size):
        Z.flat[i] = f(np.array([X1.flat[i], X2.flat[i]]))
    cs = ax.contour(X1, X2, Z, levels=30)
    ax.clabel(cs, inline=True, fontsize=8)

def refresh_contours():
    ax.cla()
    ax.set_title("梯度法可视化（等高线 + 轨迹）")
    ax.set_xlabel("x1"); ax.set_ylabel("x2")
    ax.grid(True); ax.set_aspect('equal', adjustable='box')
    f, g, H, box, is_quad = make_problem(rb_prob.value_selected)
    draw_contours(ax, f, box)
    fig.canvas.draw_idle()

refresh_contours()

# Run 动作
def on_run(event):
    f, g, H, box, is_quad = make_problem(rb_prob.value_selected)
    x0 = np.array([s_x1.val, s_x2.val])
    itmax = int(s_it.val)
    alpha0 = float(s_a0.val)
    rho    = float(s_rho.val)
    c      = float(s_c.val)
    maxbt  = int(s_bt.val)
    tol    = 1e-6
    exact  = chk.get_status()[0] and (rb_prob.value_selected.lower() == "quadratic")

    # 计算并画轨迹
    if rb_method.value_selected == 'Steepest Descent':
        traj, steps, gnorm, fval = run_sd(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, exact)
        label = '最速下降'
        style = dict(color='C0', marker='o')
    elif rb_method.value_selected == 'Newton':
        traj, steps, gnorm, fval = run_newton(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt)
        label = '牛顿法'
        style = dict(color='C1', marker='s')
    else:
        traj, steps, gnorm, fval = run_cg_fr(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, exact)
        label = '共轭梯度 (FR)'
        style = dict(color='C2', marker='^')

    ax.plot(traj[0,:], traj[1,:], '-', **style, linewidth=1.6, markersize=4, label=label)
    ax.legend(loc='best')
    fig.canvas.draw_idle()

    # 文本信息
    msg = [
        f"Problem: {rb_prob.value_selected}",
        f"Method : {rb_method.value_selected}",
        f"x0     : [{x0[0]:.3f}, {x0[1]:.3f}]",
        f"iters  : {steps}",
        f"||grad||: {gnorm:.3e}",
        f"f(x)   : {fval:.6f}",
        "",
        f"Armijo: alpha0={alpha0}, rho={rho}, c={c}, max_bt={maxbt}",
        f"Exact step (quadratic): {exact}"
    ]
    txt_handle.set_text("\n".join(msg))

btn_run.on_clicked(on_run)

# Clear 动作
def on_clear(event):
    refresh_contours()
    txt_handle.set_text("")
btn_clear.on_clicked(on_clear)

if __name__ == "__main__":
    plt.show()