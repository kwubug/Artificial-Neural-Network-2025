import numpy as np

from . import PredictiveAlgorithm


class OlsAlgorithm(PredictiveAlgorithm):
    def __init__(self, dataset, total_epoches=1, most_correct_rate=None,
                 initial_learning_rate=0.5, search_iteration_constant=1000,
                 test_ratio=0.3, tolerance=1e-6):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        # OLS是一次计算完成的，不需要多次迭代
        self.total_epoches = 1
        self.tolerance = tolerance  # 用于计算误差时的容差
        self.weights = None  # 存储回归系数
        self.mse = 0.0  # 均方误差
        self.r2 = 0.0   # 决定系数

    def _initialize_neurons(self):
        # OLS不需要神经元，我们直接使用权重向量
        # 获取特征数量
        feature_count = len(self.training_dataset[0]) - 1
        # 初始化权重为0
        self.weights = np.zeros(feature_count + 1)  # +1 用于截距项

    def _iterate(self):
        # 提取特征和标签
        X = self.training_dataset[:, :-1]
        y = self.training_dataset[:, -1]
        
        # 添加截距项（常数项）
        X_with_intercept = np.c_[np.ones(X.shape[0]), X]
        
        # 使用最小二乘法计算权重
        # w = (X^T X)^(-1) X^T y
        X_transpose = X_with_intercept.T
        X_transpose_X = X_transpose.dot(X_with_intercept)
        
        # 计算逆矩阵
        try:
            X_transpose_X_inv = np.linalg.inv(X_transpose_X)
        except np.linalg.LinAlgError:
            # 如果矩阵不可逆，使用伪逆
            X_transpose_X_inv = np.linalg.pinv(X_transpose_X)
        
        # 计算最优权重
        self.weights = X_transpose_X_inv.dot(X_transpose).dot(y)

    def _correct_rate(self, dataset):
        if self.weights is None:
            return 0
        
        correct_count = 0
        for data in dataset:
            # 提取特征（不包含标签）
            features = data[:-1]
            # 预测值
            prediction = self._predict(features)
            # 实际值
            actual = data[-1]
            
            # 对于分类问题，判断预测值和实际值是否在容差范围内相等
            if abs(prediction - actual) < self.tolerance:
                correct_count += 1
        
        return correct_count / len(dataset)
    
    def _predict(self, features):
        # 添加截距项
        features_with_intercept = np.insert(features, 0, 1)
        # 计算预测值
        return np.dot(self.weights, features_with_intercept)
    
    @property
    def current_synaptic_weights(self):
        # 为了在前端可视化，将权重作为突触权重返回
        if self.weights is None:
            return []
        return [self.weights.tolist()]
    
    def test(self):
        # 重写测试方法以提供更详细的评估指标
        if self.weights is None:
            return 0
        
        X_test = self.testing_dataset[:, :-1]
        y_test = self.testing_dataset[:, -1]
        
        # 添加截距项
        X_test_with_intercept = np.c_[np.ones(X_test.shape[0]), X_test]
        
        # 计算预测值
        y_pred = X_test_with_intercept.dot(self.weights)
        
        # 计算均方误差(MSE)
        self.mse = np.mean((y_pred - y_test) ** 2)
        
        # 计算决定系数(R^2)
        ss_total = np.sum((y_test - np.mean(y_test)) ** 2)
        if ss_total == 0:
            self.r2 = 1.0  # 所有实际值都相同
        else:
            ss_residual = np.sum((y_test - y_pred) ** 2)
            self.r2 = 1 - (ss_residual / ss_total)
        
        # 返回正确率（尽管对于回归问题不太合适，但为了保持API一致性）
        return self._correct_rate(self.testing_dataset)