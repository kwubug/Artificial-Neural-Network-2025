import numpy as np
import matplotlib.pyplot as plt
from pylab import mpl
mpl.rcParams["font.sans-serif"] = ["SimHei"]

class BoltzmannMachine:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons
        self.weights = np.random.randn(num_neurons, num_neurons) * 0.2  # 加大权重随机范围
        np.fill_diagonal(self.weights, 0)
        self.states = np.random.randint(2, size=num_neurons)
        self.history = []

    def energy(self):
        return -0.5 * np.dot(self.states, np.dot(self.weights, self.states))

    def update(self):
        for i in range(self.num_neurons):
            activation = np.dot(self.weights[i], self.states)
            prob = 1 / (1 + np.exp(-activation))
            self.states[i] = np.random.binomial(1, prob)
        self.history.append(self.states.copy())

    def run(self, steps):
        for _ in range(steps):
            self.update()
        return self.states

    def plot_history(self):
        history_array = np.array(self.history)

        plt.figure(figsize=(9, 6))
        plt.imshow(history_array.T, cmap="viridis", aspect="auto")
        plt.colorbar(label="状态值(0 或 1)")
        plt.title("Boltzmann Machine 状态演化（热力图形式）")
        plt.xlabel("步数")
        plt.ylabel("神经元编号")
        plt.yticks(range(self.num_neurons), [f"神经元 {i+1}" for i in range(self.num_neurons)])
        plt.show()


# 创建新的 BM：5 个神经元
bm = BoltzmannMachine(num_neurons=5)

# 运行 200 步
final_states = bm.run(200)

print("⚡ 网络最终热平衡状态:", final_states)

# 新风格图像展示
bm.plot_history()
