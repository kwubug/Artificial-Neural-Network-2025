import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# -------------------------------
# 生成更复杂的随机数据
# -------------------------------
np.random.seed(42)
X = np.linspace(0, 10, 100)  # 增加数据点
true_w0 = 3.0
true_w1 = 2.0
Y = true_w0 + true_w1 * X + np.random.normal(0, 5, size=X.shape)  # 加大噪声

# -------------------------------
# 初始化参数
# -------------------------------
w0, w1 = 0.0, 0.0
learning_rate = 0.005  # 减小学习率，让变化慢一些
num_epochs = 200        # 增加迭代次数，让动画更慢

n = len(X)
errors_w0, errors_w1 = [], []

# -------------------------------
# 梯度下降迭代，记录每步参数
# -------------------------------
for epoch in range(num_epochs):
    Y_pred = w0 + w1 * X
    error = Y - Y_pred

    dw0 = -2 * np.sum(error) / n
    dw1 = -2 * np.sum(error * X) / n

    w0 -= learning_rate * dw0
    w1 -= learning_rate * dw1

    errors_w0.append(w0)
    errors_w1.append(w1)

# -------------------------------
# 动画可视化
# -------------------------------
fig, ax = plt.subplots(figsize=(8,6))
ax.scatter(X, Y, color='blue', label='Data points')
line, = ax.plot([], [], 'r-', lw=2, label='Fitted line')
ax.set_xlim(0, 10)
ax.set_ylim(min(Y)-5, max(Y)+5)
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_title('OLS Gradient Descent Animation')
ax.legend()

def init():
    line.set_data([], [])
    return line,

def update(frame):
    w0_frame = errors_w0[frame]
    w1_frame = errors_w1[frame]
    Y_pred_frame = w0_frame + w1_frame * X
    line.set_data(X, Y_pred_frame)
    ax.set_title(f'Iteration {frame+1}/{num_epochs} - w0={w0_frame:.2f}, w1={w1_frame:.2f}')
    return line,

ani = FuncAnimation(fig, update, frames=num_epochs, init_func=init, blit=True, interval=150)  # 间隔150ms，每帧慢一些

plt.show()
print(f"Final learned parameters: w0={errors_w0[-1]:.2f}, w1={errors_w1[-1]:.2f}")
