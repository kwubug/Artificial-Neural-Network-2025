# -*- coding: utf-8 -*-
"""
Boltzmann Machine (BM) 算法模块
适配 nn_sandbox.backend.algorithms 结构
作者: 你的姓名 / 课程项目
"""

import numpy as np
import time
from nn_sandbox.backend.algorithms.base_algorithm import PredictiveAlgorithm



class BmAlgorithm(PredictiveAlgorithm):
    """
    三神经元 Boltzmann Machine 算法
    继承自 PredictiveAlgorithm（与 MlpAlgorithm 一致）
    """

    def __init__(self, num_neurons=3, temperature=1.0, delay=0.05, **kwargs):
        super().__init__(**kwargs)
        self.num_neurons = num_neurons
        self.temperature = temperature
        self.delay = delay  # 每步更新之间的时间间隔（可视化友好）
        # 初始化权重矩阵（对称且无自连接）
        self.weights = np.random.uniform(-1, 1, (num_neurons, num_neurons))
        np.fill_diagonal(self.weights, 0)
        # 初始化神经元状态 {-1, +1}
        self.state = np.random.choice([-1, 1], size=num_neurons)
        self.energy_trace = []

    # ---------------- 核心算法部分 ---------------- #

    def energy(self, state):
        """计算网络当前能量"""
        return -0.5 * np.dot(state, np.dot(self.weights, state))

    def update_neuron(self, i):
        """单个神经元的随机更新 (Gibbs采样)"""
        h = np.dot(self.weights[i], self.state)
        p = 1 / (1 + np.exp(-2 * h / self.temperature))
        self.state[i] = 1 if np.random.rand() < p else -1

    def run(self, steps=200):
        """运行 BM，直到系统达到热平衡"""
        self.energy_trace = []
        for step in range(steps):
            i = np.random.randint(0, self.num_neurons)
            self.update_neuron(i)
            E = self.energy(self.state)
            self.energy_trace.append(E)

            # 若用于实时显示，可在这里触发可观察更新
            self._notify_observers({"state": self.state.tolist(), "energy": float(E)})

            time.sleep(self.delay)

            # 若能量变化极小则提前停止
            if step > 20 and np.std(self.energy_trace[-10:]) < 1e-3:
                break

        return self.state.tolist()

    def get_weights(self):
        """返回权重矩阵（可用于显示）"""
        return self.weights.tolist()

    def get_energy_trace(self):
        """返回能量变化曲线"""
        return self.energy_trace
