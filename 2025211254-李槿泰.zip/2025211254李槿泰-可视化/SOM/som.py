import sys
import math
import random
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np

# Lazy import of PyQt5/matplotlib so the module can be imported without GUI
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtCore import Qt

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


def set_global_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)


@dataclass
class TrainingSchedule:
    total_steps: int = 10_000
    lr_start: float = 0.5
    lr_mid: float = 0.04  # at step 1000
    radius_start: float = 2.0  # in nodes
    radius_zero_step: int = 1_000
    snapshot_every: int = 200

    def learning_rate(self, step: int) -> float:
        if step <= 1000:
            # Linear from 0.5 -> 0.04 in first 1000 steps
            return self.lr_start + (self.lr_mid - self.lr_start) * (step / 1000.0)
        # Linear from 0.04 -> 0 by 10,000
        return max(0.0, self.lr_mid * (1.0 - (step - 1000) / (self.total_steps - 1000)))

    def radius(self, step: int) -> float:
        # Linearly decays 2 -> 0 in first 1000 steps, then 0
        if step >= self.radius_zero_step:
            return 0.0
        return max(0.0, self.radius_start * (1.0 - step / float(self.radius_zero_step)))


class SOM:
    def __init__(self, grid_shape: Tuple[int, int], input_dim: int, schedule: TrainingSchedule):
        self.rows, self.cols = grid_shape
        self.input_dim = input_dim
        self.schedule = schedule
        # Weights in [0,1]
        self.weights = np.random.rand(self.rows, self.cols, input_dim).astype(np.float64)
        # Precompute coordinate grid for Gaussian neighborhood
        r_coords = np.arange(self.rows).reshape(-1, 1)
        c_coords = np.arange(self.cols).reshape(1, -1)
        self.r_coords = r_coords
        self.c_coords = c_coords

    def bmu_index(self, x: np.ndarray) -> Tuple[int, int]:
        # Compute squared Euclidean distance to all nodes
        diff = self.weights - x[None, None, :]
        dist2 = np.sum(diff * diff, axis=2)
        idx = np.unravel_index(np.argmin(dist2), (self.rows, self.cols))
        return int(idx[0]), int(idx[1])

    def gaussian_neighborhood(self, center: Tuple[int, int], sigma: float) -> np.ndarray:
        if sigma <= 0.0:
            h = np.zeros((self.rows, self.cols), dtype=np.float64)
            h[center[0], center[1]] = 1.0
            return h
        rr = (self.r_coords - center[0]) ** 2
        cc = (self.c_coords - center[1]) ** 2
        # Broadcast to grid
        dist2 = rr + cc
        h = np.exp(-dist2 / (2.0 * (sigma ** 2)))
        return h

    def train(self, inputs: np.ndarray, on_snapshot=None) -> List[dict]:
        schedule = self.schedule
        steps = schedule.total_steps
        snapshots: List[dict] = []
        for step in range(steps + 1):
            x = inputs[np.random.randint(0, inputs.shape[0])]
            bmu_r, bmu_c = self.bmu_index(x)
            lr = schedule.learning_rate(step)
            rad = schedule.radius(step)
            h = self.gaussian_neighborhood((bmu_r, bmu_c), rad)  # [rows, cols]
            # Update weights: w += lr * h * (x - w)
            delta = (x[None, None, :] - self.weights) * h[:, :, None]
            self.weights += lr * delta
            if step % schedule.snapshot_every == 0 or step == steps:
                snap = self._capture_snapshot(step, inputs)
                snapshots.append(snap)
                if on_snapshot is not None:
                    on_snapshot(snap)
        return snapshots

    def _capture_snapshot(self, step: int, inputs: np.ndarray) -> dict:
        positions = []
        for i in range(inputs.shape[0]):
            positions.append(self.bmu_index(inputs[i]))
        return {
            "step": step,
            "positions": positions,  # list of (r, c)
            "weights": self.weights.copy(),
        }


class MplCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(6, 6), tight_layout=True)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)

    def draw_grid(self, rows: int, cols: int) -> None:
        self.ax.clear()
        # Draw grid lines
        for r in range(rows + 1):
            self.ax.plot([-0.5, cols - 0.5], [r - 0.5, r - 0.5], color="#cccccc", linewidth=1)
        for c in range(cols + 1):
            self.ax.plot([c - 0.5, c - 0.5], [-0.5, rows - 0.5], color="#cccccc", linewidth=1)
        self.ax.set_xlim(-0.5, cols - 0.5)
        self.ax.set_ylim(rows - 0.5, -0.5)
        self.ax.set_aspect("equal")
        self.ax.set_xticks(range(cols))
        self.ax.set_yticks(range(rows))
        self.ax.set_xlabel("col")
        self.ax.set_ylabel("row")

    def plot_positions(self, positions: List[Tuple[int, int]], labels: List[str]) -> None:
        colors = ["#FF4444", "#FF8800", "#00AA00", "#0088FF", "#AA00AA"]
        markers = ['o', 's', '^', 'D', 'v']
        for i, (r, c) in enumerate(positions):
            self.ax.scatter([c], [r], s=200, color=colors[i % len(colors)], 
                          marker=markers[i % len(markers)], label=labels[i], 
                          edgecolors="black", linewidths=2, zorder=3, alpha=0.8)
            self.ax.text(c, r + 0.25, labels[i], ha="center", va="bottom", 
                        fontsize=10, fontweight='bold')
        handles, lab = self.ax.get_legend_handles_labels()
        if handles:
            self.ax.legend(loc="upper right", fontsize=9, frameon=True, 
                          fancybox=True, shadow=True)
        self.ax.set_title('SOM 输出平面映射图 (5×5)', fontsize=12, fontweight='bold', pad=10)
        self.draw()


class SOMWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SOM 5x5 自组织映射网络可视化 (PyQt5)")
        self.resize(1200, 800)

        set_global_seed(42)
        self.schedule = TrainingSchedule()

        # Inputs: 5 patterns in R^4
        self.inputs = np.array([
            [1, 0, 0, 0],
            [1, 1, 0, 0],
            [1, 1, 1, 0],
            [0, 1, 0, 0],
            [1, 1, 1, 1],
        ], dtype=np.float64)
        self.labels = ["X¹", "X²", "X³", "X⁴", "X⁵"]

        self.som = SOM((5, 5), 4, self.schedule)
        self.snapshots: List[dict] = []

        # UI
        central = QtWidgets.QWidget(self)
        self.setCentralWidget(central)

        # 创建主布局：左侧是映射图，右侧是参数曲线
        main_layout = QtWidgets.QHBoxLayout(central)
        
        # 左侧：映射图和控制面板
        left_panel = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left_panel)
        
        self.canvas = MplCanvas(self)

        self.train_button = QtWidgets.QPushButton("开始训练")
        self.train_button.setMinimumHeight(35)
        self.reset_button = QtWidgets.QPushButton("重置")
        self.reset_button.setMinimumHeight(35)
        self.play_button = QtWidgets.QPushButton("▶ 播放")
        self.play_button.setCheckable(True)
        self.play_button.setMinimumHeight(35)
        self.step_label = QtWidgets.QLabel("训练步数: -")
        self.lr_label = QtWidgets.QLabel("学习率: -")
        self.radius_label = QtWidgets.QLabel("邻域半径: -")
        self.slider = QtWidgets.QSlider(Qt.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(0)
        self.slider.setSingleStep(1)

        top_bar = QtWidgets.QHBoxLayout()
        top_bar.addWidget(self.train_button)
        top_bar.addWidget(self.reset_button)
        top_bar.addWidget(self.play_button)
        top_bar.addStretch(1)
        
        info_layout = QtWidgets.QVBoxLayout()
        info_layout.addWidget(self.step_label)
        info_layout.addWidget(self.lr_label)
        info_layout.addWidget(self.radius_label)
        top_bar.addLayout(info_layout)

        bottom_bar = QtWidgets.QHBoxLayout()
        bottom_bar.addWidget(QtWidgets.QLabel("快照:"))
        bottom_bar.addWidget(self.slider)

        left_layout.addLayout(top_bar)
        left_layout.addWidget(self.canvas, stretch=1)
        left_layout.addLayout(bottom_bar)
        
        # 右侧：参数曲线图
        right_panel = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right_panel)
        
        self.param_canvas = MplCanvas(self)
        right_layout.addWidget(QtWidgets.QLabel("训练参数曲线:"))
        right_layout.addWidget(self.param_canvas)
        
        main_layout.addWidget(left_panel, stretch=2)
        main_layout.addWidget(right_panel, stretch=1)

        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(300)
        self.timer.timeout.connect(self._advance_frame)

        self.train_button.clicked.connect(self._on_train)
        self.reset_button.clicked.connect(self._on_reset)
        self.play_button.toggled.connect(self._on_toggle_play)
        self.slider.valueChanged.connect(self._on_slider)

        # 绘制初始参数曲线
        self._draw_param_curves()
        # Initial draw
        self._render_snapshot(None)

    # ----- Training and interaction -----
    def _on_train(self) -> None:
        self.train_button.setEnabled(False)
        self.reset_button.setEnabled(False)
        self.play_button.setEnabled(False)
        QtWidgets.QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.snapshots = self.som.train(self.inputs)
        finally:
            QtWidgets.QApplication.restoreOverrideCursor()
            self.train_button.setEnabled(True)
            self.reset_button.setEnabled(True)
            self.play_button.setEnabled(True)
        self.slider.setMaximum(max(0, len(self.snapshots) - 1))
        self.slider.setValue(0)
        self._render_snapshot(self.snapshots[0] if self.snapshots else None)

    def _on_reset(self) -> None:
        self.som = SOM((5, 5), 4, self.schedule)
        self.snapshots = []
        self.slider.setMaximum(0)
        self.slider.setValue(0)
        self.play_button.setChecked(False)
        self._render_snapshot(None)

    def _on_toggle_play(self, checked: bool) -> None:
        if checked:
            self.play_button.setText("⏸ 暂停")
            self.timer.start()
        else:
            self.play_button.setText("▶ 播放")
            self.timer.stop()

    def _advance_frame(self) -> None:
        if not self.snapshots:
            return
        idx = (self.slider.value() + 1) % len(self.snapshots)
        self.slider.setValue(idx)

    def _on_slider(self, value: int) -> None:
        snap = self.snapshots[value] if self.snapshots else None
        self._render_snapshot(snap)

    # ----- Rendering -----
    def _draw_param_curves(self) -> None:
        """绘制学习率和邻域半径的变化曲线"""
        ax = self.param_canvas.ax
        ax.clear()
        
        steps = np.arange(0, self.schedule.total_steps + 1, 100)
        lrs = [self.schedule.learning_rate(s) for s in steps]
        radii = [self.schedule.radius(s) for s in steps]
        
        ax2 = ax.twinx()
        # 保存ax2引用以便后续使用
        self.param_canvas.ax2 = ax2
        
        line1 = ax.plot(steps, lrs, 'b-', linewidth=2, label='学习率 η(t)')
        line2 = ax2.plot(steps, radii, 'r-', linewidth=2, label='邻域半径')
        
        ax.set_xlabel('训练步数', fontsize=10)
        ax.set_ylabel('学习率', color='b', fontsize=10)
        ax2.set_ylabel('邻域半径', color='r', fontsize=10)
        ax.tick_params(axis='y', labelcolor='b')
        ax2.tick_params(axis='y', labelcolor='r')
        ax.grid(True, alpha=0.3)
        ax.set_title('训练参数变化曲线', fontsize=11, fontweight='bold')
        
        # 添加图例
        lines = line1 + line2
        labels = [l.get_label() for l in lines]
        ax.legend(lines, labels, loc='upper right', fontsize=9)
        
        self.param_canvas.draw()
    
    def _render_snapshot(self, snapshot: dict) -> None:
        self.canvas.draw_grid(5, 5)
        if snapshot is None:
            self.step_label.setText("训练步数: -")
            self.lr_label.setText("学习率: -")
            self.radius_label.setText("邻域半径: -")
            self.canvas.draw()
            return
        
        step = snapshot['step']
        lr = self.schedule.learning_rate(step)
        radius = self.schedule.radius(step)
        
        self.step_label.setText(f"训练步数: {step}")
        self.lr_label.setText(f"学习率: {lr:.4f}")
        self.radius_label.setText(f"邻域半径: {radius:.3f}")
        
        self.canvas.plot_positions(snapshot["positions"], self.labels)
        
        # 在参数曲线上标记当前步数
        self._highlight_current_step(step)
    
    def _highlight_current_step(self, step: int) -> None:
        """在参数曲线上高亮当前训练步数"""
        ax = self.param_canvas.ax
        # 清除之前的高亮线
        for line in list(ax.lines):
            if line.get_label() == '_current_step':
                line.remove()
        
        # 获取twinx轴
        ax2 = getattr(self.param_canvas, 'ax2', None)
        if ax2:
            # 清除之前的高亮线
            for line in list(ax2.lines):
                if line.get_label() == '_current_step':
                    line.remove()
        
        # 绘制垂直线标记当前步数
        ax.axvline(x=step, color='green', linestyle='--', linewidth=2, alpha=0.7, label='_current_step')
        if ax2:
            ax2.axvline(x=step, color='green', linestyle='--', linewidth=2, alpha=0.7, label='_current_step')
        
        self.param_canvas.draw()


def main() -> None:
    app = QtWidgets.QApplication(sys.argv)
    win = SOMWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


