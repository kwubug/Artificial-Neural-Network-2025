import os
import sys
import math

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets
from PyQt5.QtCore import pyqtSlot  # 使用pyqtSlot替代

from nn_sandbox.bridges import PerceptronBridge, MlpBridge, RbfnBridge, SomBridge
import nn_sandbox.backend.utils

# 设置环境变量（移除重复设置）
os.environ['QT_LOGGING_RULES'] = 'qt.qml.connections=false'

class ActivationFunctions(PyQt5.QtCore.QObject):
    """激活函数工具类，提供单极性和双极性sigmoid函数"""
    @pyqtSlot(float, result=float)  # 使用pyqtSlot，指定输入输出类型
    def sigmoid_unipolar(self, x):
        """单极性sigmoid函数: f(x) = 1 / (1 + e^(-x))"""
        try:
            return 1.0 / (1.0 + math.exp(-x))
        except OverflowError:
            return 0.0 if x < 0 else 1.0
    
    @pyqtSlot(float, result=float)
    def sigmoid_bipolar(self, x):
        """双极性sigmoid函数: f(x) = (1 - e^(-x)) / (1 + e^(-x))"""
        try:
            return (1.0 - math.exp(-x)) / (1.0 + math.exp(-x))
        except OverflowError:
            return -1.0 if x < 0 else 1.0
    
    @pyqtSlot(float, result=float)
    def sigmoid_unipolar_derivative(self, x):
        """单极性sigmoid函数的导数"""
        s = self.sigmoid_unipolar(x)
        return s * (1 - s)
    
    @pyqtSlot(float, result=float)
    def sigmoid_bipolar_derivative(self, x):
        """双极性sigmoid函数的导数"""
        s = self.sigmoid_bipolar(x)
        return 0.5 * (1 - s **2)

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    # 创建应用实例
    app = PyQt5.QtWidgets.QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    # 注册激活函数工具类到QML上下文
    activation_functions = ActivationFunctions()
    engine.rootContext().setContextProperty("ActivationFunctions", activation_functions)

    # 初始化神经网络桥梁
    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge()
    }
    for name in bridges:
        bridges[name].dataset_dict = nn_sandbox.backend.utils.read_data()
        # 可以将激活函数设置到桥梁中，供后端使用
        bridges[name].activation_functions = activation_functions
        engine.rootContext().setContextProperty(name, bridges[name])

    # 加载QML界面
    engine.load('./nn_sandbox/frontend/main.qml')
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())
    