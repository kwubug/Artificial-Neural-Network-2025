import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import ".."  // 确保路径正确

Page {
    name: 'LVQ'

    // 绑定到 Python 中的属性
    property var weights: LVQ.weightsList
    property int inputSize: LVQ.inputSize
    property int numClasses: LVQ.numClasses
    property int classification: LVQ.classification

    ColumnLayout {
        spacing: 10

        // 输入样本
        GroupBox {
            title: "Input Sample"
            Layout.fillWidth: true
            RowLayout {
                TextField {
                    id: inputSample
                    width: 200
                    placeholderText: "Enter sample (e.g., -1,1,-1)"
                }
                Button {
                    text: "Classify"
                    onClicked: {
                        var sample = inputSample.text.split(",").map(function(x) { return parseInt(x.trim()); });
                        if (sample.length === LVQ.inputSize) {
                            LVQ.start()
                            LVQ.classifySample(sample);
                        } else {
                            console.log("Invalid input sample size");
                        }
                    }
                }
            }
        }

        // 网络信息
        GroupBox {
            title: "Network Information"
            Layout.fillWidth: true
            GridLayout {
                columns: 2

                Label { text: "Input Size:" }
                Label { text: inputSize }

                Label { text: "Number of Classes:" }
                Label { text: numClasses }

                Label { text: "Weights:" }
                ListView {
                    id: weightsView
                    width: parent.width
                    height: 150
                    model: weights
                    delegate: Text {
                    text: modelData.join(", ")
                    }
                }


            }
        }

        // 显示分类结果
        GroupBox {
            title: "Classification Result"
            Layout.fillWidth: true
            Label {
                id: classifyResult
                text: "Result: "+ LVQ.classification
                Layout.alignment: Qt.AlignHCenter
            }

        }
    }

}
