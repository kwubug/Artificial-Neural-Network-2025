import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '../..'  // 导入父级目录
import '../'    // 导入components目录

Page {
    name: 'Gradient Descent'
    
    property var currentPath: []  // 当前优化路径
    property int currentProgress: 0  // 当前进度
    property real currentFuncValue: 0  // 当前函数值
    property real currentGradNorm: 0  // 当前梯度范数
    
    ColumnLayout {
        // 算法选择和参数设置
        GroupBox {
            title: 'Algorithm Settings'
            Layout.fillWidth: true
            
            GridLayout {
                anchors.fill: parent
                columns: 2
                
                Label {
                    text: 'Algorithm Type'
                    Layout.alignment: Qt.AlignHCenter
                }
                
                ComboBox {
                    id: algorithmTypeComboBox
                    model: ["Batch Gradient Descent", "Stochastic Gradient Descent", "Mini-batch Gradient Descent"]
                    currentIndex: 0
                    Layout.fillWidth: true
                }
                
                Label {
                    text: 'Start Point (X, Y)'
                    Layout.alignment: Qt.AlignHCenter
                }
                
                RowLayout {
                    TextField {
                        id: startXField
                        text: "5.0"
                        Layout.fillWidth: true
                        validator: DoubleValidator {}
                    }
                    TextField {
                        id: startYField
                        text: "5.0"
                        Layout.fillWidth: true
                        validator: DoubleValidator {}
                    }
                }
                
                Label {
                    text: 'Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                
                TextField {
                    id: learningRateField
                    text: "0.1"
                    Layout.fillWidth: true
                    validator: DoubleValidator { bottom: 0.001; top: 1.0; decimals: 4 }
                }
                
                Label {
                    text: 'Max Iterations'
                    Layout.alignment: Qt.AlignHCenter
                }
                
                TextField {
                    id: maxIterationsField
                    text: "100"
                    Layout.fillWidth: true
                    validator: IntValidator { bottom: 1; top: 10000 }
                }
            }
        }
        
        // 控制按钮
        GroupBox {
            title: 'Controls'
            Layout.fillWidth: true
            
            RowLayout {
                anchors.fill: parent
                
                Button {
                    id: startButton
                    text: "Start Optimization"
                    Layout.fillWidth: true
                    onClicked: {
                        // 获取参数
                        var algorithmType = ["batch", "stochastic", "mini_batch"][algorithmTypeComboBox.currentIndex]
                        var startPoint = [parseFloat(startXField.text), parseFloat(startYField.text)]
                        var learningRate = parseFloat(learningRateField.text)
                        var maxIterations = parseInt(maxIterationsField.text)
                        
                        // 清空图表和路径
                        dataChart.clear()
                        currentPath = []
                        currentProgress = 0
                        
                        
                        // draw simple contours for f(x,y)=x^2+y^2
                        dataChart.drawQuadraticContours([0.25, 0.5, 1, 2, 4, 8, 16]);

                        // set initial axis range to include start and origin
                        var maxAbs = Math.max(Math.abs(startPoint[0]), Math.abs(startPoint[1]), 4)
                        var R = maxAbs * 1.3
                        dataChart.xAxis.min = -R
                        dataChart.xAxis.max = R
                        dataChart.yAxis.min = -R
                        dataChart.yAxis.max = R
    // 开始优化
                        gradientDescentBridge.run_optimization(algorithmType, startPoint, learningRate, maxIterations)
                        
                        // 更新状态
                        statusText.text = "Optimizing..."
                    }
                }
                
                Button {
                    id: stopButton
                    text: "Stop"
                    Layout.fillWidth: true
                    enabled: statusText.text === "Optimizing..."
                    onClicked: {
                        // 停止优化
                        statusText.text = "Stopped"
                        currentProgress = 0
                    }
                }
                
                Button {
                    id: clearButton
                    text: "Clear"
                    Layout.fillWidth: true
                    onClicked: {
                        dataChart.clear()
                        currentPath = []
                        currentProgress = 0
                        
                        // draw simple contours for f(x,y)=x^2+y^2
                        dataChart.drawQuadraticContours([0.25, 0.5, 1, 2, 4, 8, 16]);

                        // set initial axis range to include start and origin
                        var maxAbs = Math.max(Math.abs(startPoint[0]), Math.abs(startPoint[1]), 4)
                        var R = maxAbs * 1.3
                        dataChart.xAxis.min = -R
                        dataChart.xAxis.max = R
                        dataChart.yAxis.min = -R
                        dataChart.yAxis.max = R
    statusText.text = "Ready"
                    }
                }
            }
        }
        
        // 进度显示
        GroupBox {
            title: 'Progress'
            Layout.fillWidth: true
            
            ColumnLayout {
                anchors.fill: parent
                
                ProgressBar {
                    id: progressBar
                    value: currentProgress / 100.0
                    Layout.fillWidth: true
                }
                
                Text {
                    text: "Progress: " + currentProgress + "%"
                    font.pixelSize: 14
                    Layout.alignment: Qt.AlignHCenter
                }
            }
        }
        
        // 状态显示
        GroupBox {
            title: 'Status'
            Layout.fillWidth: true
            
            Text {
                id: statusText
                text: "Ready"
                color: "green"
                font.pixelSize: 16
                anchors.centerIn: parent
            }
        }
        
        // 当前点信息
        GroupBox {
            title: 'Current Point'
            Layout.fillWidth: true
            visible: currentPath.length > 0
            
            Text {
                id: currentPointText
                text: currentPath.length > 0 ? 
                      "X: " + currentPath[currentPath.length - 1][0].toFixed(4) + 
                      ", Y: " + currentPath[currentPath.length - 1][1].toFixed(4) : 
                      "No data"
                font.pixelSize: 14
                anchors.centerIn: parent
            }
        }
        
        // 新增：当前函数值和梯度范数显示
        GroupBox {
            title: 'Current Metrics'
            Layout.fillWidth: true
            visible: currentPath.length > 0
            
            ColumnLayout {
                anchors.fill: parent
                
                Text {
                    text: "Function Value: " + currentFuncValue.toFixed(6)
                    font.pixelSize: 14
                    Layout.alignment: Qt.AlignHCenter
                }
                
                Text {
                    text: "Gradient Norm: " + currentGradNorm.toFixed(6)
                    font.pixelSize: 14
                    Layout.alignment: Qt.AlignHCenter
                }
            }
        }
        
        // 图表标题
        Text {
            text: "Optimization Path Visualization"
            font.pixelSize: 16
            font.bold: true
            Layout.alignment: Qt.AlignHCenter
        }
        
        // 数据图表
        DataChart {
            id: dataChart
            Layout.fillWidth: true
            Layout.minimumHeight: 300
            Layout.maximumHeight: 400
        }
    }
    
    // 监听优化进度信号
    Connections {
        target: gradientDescentBridge
        function onOptimization_progress(progress, currentPoint, func_value, grad_norm) {
            currentProgress = progress
            progressBar.value = progress / 100.0
            
            // 更新新增的指标
            currentFuncValue = func_value
            currentGradNorm = grad_norm

            currentPath.push(currentPoint)
            
            // 实时更新图表显示当前路径
            if (currentPath.length > 1) {
                // 使用更高效的appendPointToOptimizationPath方法
                dataChart.appendPointToOptimizationPath(currentPoint)
            }
            
            // 更新当前点显示
            currentPointText.text = "X: " + currentPoint[0].toFixed(4) + 
                                   ", Y: " + currentPoint[1].toFixed(4)
        }
    }
    
    // 监听优化完成信号
    Connections {
        target: gradientDescentBridge
        function onOptimization_done(result) {
            statusText.text = "Optimization Complete!"
            currentProgress = 100
            console.log("Optimization completed for algorithm: " + algorithmType)
            
            // 获取完整历史数据并显示在图表上
            var algorithmType = result[0]
            var finalPoint = result[1]
            var historyData = gradientDescentBridge.get_history_data(algorithmType)
            
            if (historyData && historyData.length > 0) {
                console.log("Displaying optimization path, points: " + historyData.length)
                dataChart.updateOptimizationPath(historyData)
            } else {
                console.log("No history data available")
            }
        }
    }
}