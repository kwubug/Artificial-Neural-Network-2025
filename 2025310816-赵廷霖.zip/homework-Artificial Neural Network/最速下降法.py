import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation

plt.rcParams['font.sans-serif'] = ['SimHei']
class GradientDescent:
    def __init__(self, learning_rate=0.01, max_iter=1000, tol=1e-6):
        """
        初始化梯度下降算法

        参数:
        learning_rate: 学习率
        max_iter: 最大迭代次数
        tol: 收敛容忍度
        """
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.tol = tol
        self.history = []  # 存储迭代历史

    def function(self, x):
        """
        目标函数: f(x) = x1^2 + 2*x2^2 + 2*x1*x2 + x1 - x2
        """
        return x[0] ** 2 + 2 * x[1] ** 2 + 2 * x[0] * x[1] + x[0] - x[1]

    def gradient(self, x):
        """
        计算梯度
        """
        grad = np.zeros_like(x)
        grad[0] = 2 * x[0] + 2 * x[1] + 1  # ∂f/∂x1
        grad[1] = 4 * x[1] + 2 * x[0] - 1  # ∂f/∂x2
        return grad

    def optimize(self, initial_point):
        """
        执行梯度下降优化

        参数:
        initial_point: 初始点

        返回:
        x_opt: 最优解
        history: 优化历史
        """
        x = initial_point.copy()
        self.history = [x.copy()]

        for i in range(self.max_iter):
            grad = self.gradient(x)

            # 检查梯度是否足够小（收敛）
            if np.linalg.norm(grad) < self.tol:
                print(f"在 {i + 1} 次迭代后收敛")
                break

            # 梯度下降更新
            x = x - self.learning_rate * grad
            self.history.append(x.copy())

            # 每100次迭代打印进度
            if (i + 1) % 100 == 0:
                print(f"迭代 {i + 1}: x = {x}, f(x) = {self.function(x):.6f}")

        else:
            print(f"达到最大迭代次数 {self.max_iter}")

        return x, self.history

def create_contour_plot(history, function):
    """
    创建等高线图显示优化路径
    """
    # 创建网格数据
    x1 = np.linspace(-3, 3, 100)
    x2 = np.linspace(-3, 3, 100)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.zeros_like(X1)

    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            Z[i, j] = function(np.array([X1[i, j], X2[i, j]]))

    # 绘制等高线图
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    contour = plt.contour(X1, X2, Z, levels=50, alpha=0.6)
    plt.clabel(contour, inline=True, fontsize=8)

    # 绘制优化路径
    history_array = np.array(history)
    plt.plot(history_array[:, 0], history_array[:, 1], 'ro-', markersize=4, linewidth=1, label='优化路径')
    plt.plot(history_array[0, 0], history_array[0, 1], 'go', markersize=8, label='起点')
    plt.plot(history_array[-1, 0], history_array[-1, 1], 'bo', markersize=8, label='终点')

    plt.xlabel('x1')
    plt.ylabel('x2')
    plt.title('梯度下降优化路径 - 等高线图')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.axis('equal')

    # 绘制函数值下降曲线
    plt.subplot(1, 2, 2)
    function_values = [function(point) for point in history]
    plt.plot(range(len(function_values)), function_values, 'b-', linewidth=2)
    plt.xlabel('迭代次数')
    plt.ylabel('函数值 f(x)')
    plt.title('函数值下降曲线')
    plt.grid(True, alpha=0.3)
    plt.yscale('log')  # 使用对数坐标更好地观察收敛

    plt.tight_layout()
    plt.show()

def create_3d_surface_plot(history, function):
    """
    创建3D表面图显示优化路径
    """
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # 创建网格数据
    x1 = np.linspace(-3, 3, 50)
    x2 = np.linspace(-3, 3, 50)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.zeros_like(X1)

    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            Z[i, j] = function(np.array([X1[i, j], X2[i, j]]))

    # 绘制3D表面
    surf = ax.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.7,
                           linewidth=0, antialiased=True)

    # 绘制优化路径
    history_array = np.array(history)
    function_values = [function(point) for point in history]

    ax.plot(history_array[:, 0], history_array[:, 1], function_values,
            'ro-', markersize=4, linewidth=2, label='优化路径')
    ax.plot([history_array[0, 0]], [history_array[0, 1]], [function_values[0]],
            'go', markersize=8, label='起点')
    ax.plot([history_array[-1, 0]], [history_array[-1, 1]], [function_values[-1]],
            'bo', markersize=8, label='终点')

    ax.set_xlabel('x1')
    ax.set_ylabel('x2')
    ax.set_zlabel('f(x)')
    ax.set_title('梯度下降优化路径 - 3D可视化')
    ax.legend()

    plt.show()

def create_animation(history, function):
    """
    创建优化过程的动画
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # 准备等高线数据
    x1 = np.linspace(-3, 3, 100)
    x2 = np.linspace(-3, 3, 100)
    X1, X2 = np.meshgrid(x1, x2)
    Z = np.zeros_like(X1)

    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            Z[i, j] = function(np.array([X1[i, j], X2[i, j]]))

    # 左图：等高线
    contour = ax1.contour(X1, X2, Z, levels=30, alpha=0.6)
    ax1.clabel(contour, inline=True, fontsize=8)
    line, = ax1.plot([], [], 'ro-', markersize=4, linewidth=1)
    start_point = ax1.plot([], [], 'go', markersize=8)[0]
    current_point = ax1.plot([], [], 'bo', markersize=8)[0]

    ax1.set_xlim(-3, 3)
    ax1.set_ylim(-3, 3)
    ax1.set_xlabel('x1')
    ax1.set_ylabel('x2')
    ax1.set_title('梯度下降优化路径')
    ax1.grid(True, alpha=0.3)

    # 右图：函数值下降曲线
    function_values = [function(point) for point in history]
    ax2.plot(range(len(function_values)), function_values, 'b-', alpha=0.3)
    current_value, = ax2.plot([], [], 'ro', markersize=6)

    ax2.set_xlim(0, len(function_values))
    ax2.set_ylim(min(function_values), max(function_values))
    ax2.set_xlabel('迭代次数')
    ax2.set_ylabel('函数值 f(x)')
    ax2.set_title('函数值下降过程')
    ax2.grid(True, alpha=0.3)
    ax2.set_yscale('log')

    def animate(frame):
        # 更新左图
        if frame > 0:
            x_data = [p[0] for p in history[:frame + 1]]
            y_data = [p[1] for p in history[:frame + 1]]
            line.set_data(x_data, y_data)

        start_point.set_data([history[0][0]], [history[0][1]])
        current_point.set_data([history[frame][0]], [history[frame][1]])

        # 更新右图
        current_value.set_data([frame], [function_values[frame]])

        return line, start_point, current_point, current_value

    anim = FuncAnimation(fig, animate, frames=len(history),
                         interval=200, blit=True, repeat=True)

    plt.tight_layout()
    plt.show()

    return anim

def main():
    """
    主函数：执行梯度下降并可视化结果
    """
    # 初始化梯度下降算法
    gd = GradientDescent(learning_rate=0.1, max_iter=500, tol=1e-6)

    # 设置初始点
    initial_point = np.array([2.0, 2.0])

    print("开始梯度下降优化...")
    print(f"初始点: {initial_point}")
    print(f"初始函数值: {gd.function(initial_point):.6f}")
    print("-" * 50)

    # 执行优化
    x_opt, history = gd.optimize(initial_point)

    print("-" * 50)
    print(f"最优解: {x_opt}")
    print(f"最优函数值: {gd.function(x_opt):.6f}")
    print(f"梯度范数: {np.linalg.norm(gd.gradient(x_opt)):.6f}")
    print(f"总迭代次数: {len(history)}")

    # 可视化结果
    print("\n生成可视化图表...")

    # 1. 等高线图和函数值下降曲线
    create_contour_plot(history, gd.function)

    # 2. 3D表面图
    create_3d_surface_plot(history, gd.function)

    # 3. 动画（可选，如果运行缓慢可以注释掉）
    print("生成动画...（这可能需要一些时间）")
    create_animation(history, gd.function)


if __name__ == "__main__":
    main()