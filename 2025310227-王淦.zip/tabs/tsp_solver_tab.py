import numpy as np
import matplotlib.pyplot as plt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                               QGroupBox, QLabel, QSpinBox, QTextEdit)
from PySide6.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class TSPSolverTab(QWidget):
    def __init__(self):
        super().__init__()
        self.cities = None
        self.solver = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # 控制面板
        control_group = QGroupBox("TSP参数设置")
        control_layout = QVBoxLayout()

        param_layout = QHBoxLayout()
        param_layout.addWidget(QLabel("城市数量:"))
        self.city_spin = QSpinBox()
        self.city_spin.setRange(5, 50)
        self.city_spin.setValue(10)
        param_layout.addWidget(self.city_spin)

        self.generate_button = QPushButton("生成随机城市")
        self.generate_button.clicked.connect(self.generate_cities)

        self.solve_button = QPushButton("求解TSP")
        self.solve_button.clicked.connect(self.solve_tsp)

        control_layout.addLayout(param_layout)
        control_layout.addWidget(self.generate_button)
        control_layout.addWidget(self.solve_button)
        control_group.setLayout(control_layout)

        # 结果显示
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)

        # 图表区域
        self.canvas = FigureCanvas(Figure(figsize=(10, 6)))

        # 布局
        layout.addWidget(control_group)
        layout.addWidget(self.result_text)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def generate_cities(self):
        n_cities = self.city_spin.value()
        np.random.seed(42)
        self.cities = np.random.rand(n_cities, 2) * 100
        self.result_text.append(f"已生成 {n_cities} 个随机城市坐标")

    def solve_tsp(self):
        if self.cities is None:
            self.result_text.append("请先生成城市坐标！")
            return

        try:
            self.solver = TSPSolver(self.cities)
            result = self.solver.solve_tsp()

            # 显示结果
            self.result_text.append("=== TSP求解结果 ===")
            self.result_text.append(f"初始路径距离: {result['initial_distance']:.2f}")
            self.result_text.append(f"优化后路径距离: {result['optimized_distance']:.2f}")
            self.result_text.append(f"优化改进: {result['initial_distance'] - result['optimized_distance']:.2f}")

            # 可视化结果
            self.visualize_tsp(result)

        except Exception as e:
            self.result_text.append(f"TSP求解错误: {e}")

    def visualize_tsp(self, result):
        self.canvas.figure.clear()

        cities_array = np.array(self.cities)

        # 创建子图
        ax1 = self.canvas.figure.add_subplot(121)
        ax2 = self.canvas.figure.add_subplot(122)

        # 绘制初始路径
        initial_path = result['initial_path'] + [result['initial_path'][0]]
        ax1.scatter(cities_array[:, 0], cities_array[:, 1], c='red', s=100, zorder=5)
        ax1.plot(cities_array[initial_path, 0], cities_array[initial_path, 1], 'b-', linewidth=2, alpha=0.7)
        for j, (x, y) in enumerate(self.cities):
            ax1.annotate(str(j), (x, y), xytext=(5, 5), textcoords='offset points')
        ax1.set_title(f'最近邻算法\n总距离: {result["initial_distance"]:.2f}')
        ax1.grid(True, alpha=0.3)

        # 绘制优化后路径
        optimized_path = result['optimized_path'] + [result['optimized_path'][0]]
        ax2.scatter(cities_array[:, 0], cities_array[:, 1], c='red', s=100, zorder=5)
        ax2.plot(cities_array[optimized_path, 0], cities_array[optimized_path, 1], 'b-', linewidth=2, alpha=0.7)
        for j, (x, y) in enumerate(self.cities):
            ax2.annotate(str(j), (x, y), xytext=(5, 5), textcoords='offset points')
        ax2.set_title(f'2-opt优化后\n总距离: {result["optimized_distance"]:.2f}')
        ax2.grid(True, alpha=0.3)

        self.canvas.figure.tight_layout()
        self.canvas.draw()


class TSPSolver:
    def __init__(self, cities):
        self.cities = np.array(cities)
        self.n_cities = len(cities)
        self.distance_matrix = self._calculate_distance_matrix()

    def _calculate_distance_matrix(self):
        dist_matrix = np.zeros((self.n_cities, self.n_cities))
        for i in range(self.n_cities):
            for j in range(i + 1, self.n_cities):
                dist = np.sqrt((self.cities[i][0] - self.cities[j][0]) ** 2 +
                               (self.cities[i][1] - self.cities[j][1]) ** 2)
                dist_matrix[i][j] = dist
                dist_matrix[j][i] = dist
        return dist_matrix

    def total_distance(self, path):
        return sum(self.distance_matrix[path[i], path[(i + 1) % self.n_cities]]
                   for i in range(self.n_cities))

    def nearest_neighbor(self, start_city=0):
        unvisited = set(range(self.n_cities))
        unvisited.remove(start_city)
        path = [start_city]
        current = start_city

        while unvisited:
            next_city = min(unvisited,
                            key=lambda city: self.distance_matrix[current, city])
            path.append(next_city)
            unvisited.remove(next_city)
            current = next_city

        return path, self.total_distance(path)

    def two_opt(self, path, max_iterations=1000):
        best_path = path[:]
        best_distance = self.total_distance(path)
        improved = True
        iterations = 0

        while improved and iterations < max_iterations:
            improved = False
            for i in range(1, self.n_cities - 2):
                for j in range(i + 1, self.n_cities):
                    if j - i == 1: continue

                    new_path = best_path[:i] + best_path[i:j][::-1] + best_path[j:]
                    new_distance = self.total_distance(new_path)

                    if new_distance < best_distance:
                        best_path = new_path
                        best_distance = new_distance
                        improved = True
                        break
                if improved:
                    break
            iterations += 1

        return best_path, best_distance

    def solve_tsp(self):
        initial_path, initial_dist = self.nearest_neighbor()
        optimized_path, optimized_dist = self.two_opt(initial_path)

        return {
            'initial_path': initial_path,
            'initial_distance': initial_dist,
            'optimized_path': optimized_path,
            'optimized_distance': optimized_dist
        }