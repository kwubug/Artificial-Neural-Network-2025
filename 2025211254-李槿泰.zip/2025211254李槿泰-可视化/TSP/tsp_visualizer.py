"""
TSP问题可视化程序
使用PyQt5实现旅行商问题的可视化界面
"""

import sys
import math
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QSpinBox, 
                             QComboBox, QMessageBox, QFileDialog)
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QPainter, QPen, QColor, QFont


class City:
    """城市类，表示TSP问题中的一个城市"""
    def __init__(self, x, y, name=""):
        self.x = x
        self.y = y
        self.name = name if name else f"城市{id(self)}"
    
    def distance_to(self, other):
        """计算到另一个城市的欧几里得距离"""
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
    
    def __repr__(self):
        return f"City({self.x}, {self.y}, '{self.name}')"


class TSPAlgorithm:
    """TSP算法类"""
    
    @staticmethod
    def calculate_total_distance(cities, path):
        """计算路径的总距离"""
        if len(path) < 2:
            return 0
        total = 0
        for i in range(len(path)):
            total += cities[path[i]].distance_to(cities[path[(i+1) % len(path)]])
        return total
    
    @staticmethod
    def nearest_neighbor(cities):
        """最近邻算法"""
        if len(cities) < 2:
            return list(range(len(cities)))
        
        n = len(cities)
        unvisited = set(range(1, n))
        path = [0]
        current = 0
        
        while unvisited:
            nearest = min(unvisited, key=lambda i: cities[current].distance_to(cities[i]))
            path.append(nearest)
            unvisited.remove(nearest)
            current = nearest
        
        return path
    
    @staticmethod
    def greedy(cities):
        """贪心算法：每次选择最短的边，避免形成子环"""
        if len(cities) < 2:
            return list(range(len(cities)))
        
        n = len(cities)
        edges = []
        
        # 生成所有边
        for i in range(n):
            for j in range(i+1, n):
                edges.append((i, j, cities[i].distance_to(cities[j])))
        
        # 按距离排序
        edges.sort(key=lambda x: x[2])
        
        # 使用并查集避免形成子环
        parent = list(range(n))
        
        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]
        
        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py
                return True
            return False
        
        # 构建邻接表
        adj = [[] for _ in range(n)]
        edge_count = 0
        
        for i, j, dist in edges:
            if edge_count >= n:
                break
            if find(i) != find(j) or edge_count == n - 1:
                if len(adj[i]) < 2 and len(adj[j]) < 2:
                    adj[i].append(j)
                    adj[j].append(i)
                    union(i, j)
                    edge_count += 1
        
        # 从邻接表构建路径
        if not adj[0]:
            return list(range(n))
        
        path = [0]
        current = 0
        visited = {0}
        
        while len(path) < n:
            for neighbor in adj[current]:
                if neighbor not in visited:
                    path.append(neighbor)
                    visited.add(neighbor)
                    current = neighbor
                    break
            else:
                break
        
        return path if len(path) == n else list(range(n))
    
    @staticmethod
    def two_opt(cities, path):
        """2-opt优化算法"""
        if len(path) < 4:
            return path
        
        improved = True
        best_path = path[:]
        best_distance = TSPAlgorithm.calculate_total_distance(cities, best_path)
        
        while improved:
            improved = False
            for i in range(len(best_path) - 2):
                for j in range(i + 2, len(best_path)):
                    if j == len(best_path) - 1 and i == 0:
                        continue
                    
                    # 尝试交换边
                    new_path = best_path[:]
                    new_path[i+1:j+1] = reversed(new_path[i+1:j+1])
                    new_distance = TSPAlgorithm.calculate_total_distance(cities, new_path)
                    
                    if new_distance < best_distance:
                        best_path = new_path
                        best_distance = new_distance
                        improved = True
                        break
                if improved:
                    break
        
        return best_path


class TSPCanvas(QWidget):
    """TSP可视化画布"""
    
    def __init__(self):
        super().__init__()
        self.cities = []
        self.path = []
        self.total_distance = 0
        self.setMinimumSize(800, 600)
        self.setStyleSheet("background-color: white;")
    
    def add_city(self, x, y, name=""):
        """添加城市"""
        self.cities.append(City(x, y, name))
        self.update()
    
    def clear_cities(self):
        """清除所有城市"""
        self.cities = []
        self.path = []
        self.total_distance = 0
        self.update()
    
    def set_path(self, path, distance):
        """设置路径"""
        self.path = path
        self.total_distance = distance
        self.update()
    
    def generate_random_cities(self, count):
        """生成随机城市"""
        self.clear_cities()
        margin = 50
        for i in range(count):
            x = random.randint(margin, self.width() - margin)
            y = random.randint(margin, self.height() - margin)
            self.add_city(x, y, f"城市{i+1}")
    
    def paintEvent(self, event):
        """绘制事件"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # 绘制路径
        if len(self.path) > 1:
            pen = QPen(QColor(100, 150, 255), 2)
            painter.setPen(pen)
            for i in range(len(self.path)):
                city1 = self.cities[self.path[i]]
                city2 = self.cities[self.path[(i+1) % len(self.path)]]
                painter.drawLine(int(city1.x), int(city1.y), int(city2.x), int(city2.y))
        
        # 绘制城市点
        for i, city in enumerate(self.cities):
            # 绘制城市圆圈
            if i in self.path:
                color = QColor(255, 100, 100)
            else:
                color = QColor(100, 200, 100)
            
            painter.setBrush(color)
            painter.setPen(QPen(QColor(0, 0, 0), 1))
            painter.drawEllipse(int(city.x - 8), int(city.y - 8), 16, 16)
            
            # 绘制城市名称
            painter.setPen(QPen(QColor(0, 0, 0), 1))
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(int(city.x + 12), int(city.y - 12), city.name)
        
        # 绘制总距离信息
        if self.total_distance > 0:
            painter.setPen(QPen(QColor(0, 0, 0), 1))
            font = QFont("Arial", 12, QFont.Bold)
            painter.setFont(font)
            info_text = f"总距离: {self.total_distance:.2f}"
            painter.drawText(10, 30, info_text)
    
    def mousePressEvent(self, event):
        """鼠标点击事件"""
        if event.button() == Qt.LeftButton:
            x = event.x()
            y = event.y()
            self.add_city(x, y, f"城市{len(self.cities)+1}")


class TSPMainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        """初始化UI"""
        self.setWindowTitle("TSP问题可视化")
        self.setGeometry(100, 100, 1200, 700)
        
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = QWidget()
        control_panel.setFixedWidth(250)
        control_layout = QVBoxLayout(control_panel)
        control_layout.setSpacing(10)
        
        # 标题
        title = QLabel("TSP问题求解器")
        title.setFont(QFont("Arial", 14, QFont.Bold))
        control_layout.addWidget(title)
        
        # 算法选择
        algorithm_label = QLabel("选择算法:")
        control_layout.addWidget(algorithm_label)
        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["最近邻算法", "贪心算法", "2-opt优化"])
        control_layout.addWidget(self.algorithm_combo)
        
        # 随机生成城市
        random_label = QLabel("随机生成城市:")
        control_layout.addWidget(random_label)
        random_layout = QHBoxLayout()
        self.city_count_spin = QSpinBox()
        self.city_count_spin.setMinimum(3)
        self.city_count_spin.setMaximum(100)
        self.city_count_spin.setValue(10)
        random_layout.addWidget(self.city_count_spin)
        random_btn = QPushButton("生成")
        random_btn.clicked.connect(self.generate_random)
        random_layout.addWidget(random_btn)
        control_layout.addLayout(random_layout)
        
        # 求解按钮
        solve_btn = QPushButton("求解TSP")
        solve_btn.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 10px;")
        solve_btn.clicked.connect(self.solve_tsp)
        control_layout.addWidget(solve_btn)
        
        # 清除按钮
        clear_btn = QPushButton("清除所有")
        clear_btn.setStyleSheet("background-color: #f44336; color: white; padding: 10px;")
        clear_btn.clicked.connect(self.clear_all)
        control_layout.addWidget(clear_btn)
        
        # 说明
        info_label = QLabel("说明:\n1. 点击画布添加城市\n2. 选择算法后点击求解\n3. 可以随机生成城市")
        info_label.setWordWrap(True)
        control_layout.addWidget(info_label)
        
        control_layout.addStretch()
        
        # 画布
        self.canvas = TSPCanvas()
        
        # 添加到主布局
        main_layout.addWidget(control_panel)
        main_layout.addWidget(self.canvas, 1)
    
    def generate_random(self):
        """生成随机城市"""
        count = self.city_count_spin.value()
        self.canvas.generate_random_cities(count)
    
    def solve_tsp(self):
        """求解TSP问题"""
        if len(self.canvas.cities) < 3:
            QMessageBox.warning(self, "警告", "至少需要3个城市才能求解TSP问题！")
            return
        
        algorithm = self.algorithm_combo.currentText()
        cities = self.canvas.cities
        
        if algorithm == "最近邻算法":
            path = TSPAlgorithm.nearest_neighbor(cities)
        elif algorithm == "贪心算法":
            path = TSPAlgorithm.greedy(cities)
        else:  # 2-opt优化
            # 先用最近邻算法得到初始解
            initial_path = TSPAlgorithm.nearest_neighbor(cities)
            path = TSPAlgorithm.two_opt(cities, initial_path)
        
        distance = TSPAlgorithm.calculate_total_distance(cities, path)
        self.canvas.set_path(path, distance)
        
        QMessageBox.information(self, "求解完成", 
                               f"算法: {algorithm}\n总距离: {distance:.2f}\n城市数量: {len(cities)}")
    
    def clear_all(self):
        """清除所有"""
        reply = QMessageBox.question(self, "确认", "确定要清除所有城市吗？",
                                     QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.canvas.clear_cities()


def main():
    """主函数"""
    app = QApplication(sys.argv)
    window = TSPMainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()

