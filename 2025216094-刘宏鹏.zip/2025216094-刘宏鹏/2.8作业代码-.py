import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import random

class AdvancedNeuralNetwork:

    def __init__(self, input_size=6, learning_rate=0.1):
        self.input_size = input_size
        self.learning_rate = learning_rate
        self.weights = np.random.uniform(-0.5, 0.5, input_size)  # 初始化权重
        self.bias = np.random.uniform(-0.5, 0.5)  # 添加偏置项
        self.training_history = []
        self.activation_funcs = ['sigmoid', 'tanh', 'relu']

    def activation_function(self, x, func_type):
        """
        根据指定的激活函数类型计算输出
        """
        # 防止数值溢出
        x_clipped = np.clip(x, -500, 500)

        if func_type == 'sigmoid':
            return 1 / (1 + np.exp(-x_clipped))
        elif func_type == 'tanh':
            return np.tanh(x)
        elif func_type == 'relu':
            return np.maximum(0, x)
        elif func_type == 'linear':
            return x
        else:
            raise ValueError(f"不支持的激活函数类型: {func_type}")

    def activation_derivative(self, x, func_type):
        """
        计算激活函数的导数
        """
        if func_type == 'sigmoid':
            sig = self.activation_function(x, 'sigmoid')
            return sig * (1 - sig)
        elif func_type == 'tanh':
            return 1 - np.tanh(x) ** 2
        elif func_type == 'relu':
            return (x > 0).astype(float)
        elif func_type == 'linear':
            return np.ones_like(x)
        else:
            raise ValueError(f"不支持的激活函数类型: {func_type}")

    def net_input(self, inputs):
        """
        计算神经元的净输入（包含偏置）
        """
        return np.dot(inputs, self.weights) + self.bias

    def predict(self, inputs, activation_func):
        """
        预测给定输入的输出
        """
        net = self.net_input(inputs)
        output = self.activation_function(net, activation_func)
        return output, net

    def hebbian_learning(self, training_data, activation_func, epochs=100, verbose=True):
        """
        Hebbian学习规则 - 无监督学习，根据输入调整权重
        """
        if verbose:
            print(f"开始Hebbian学习，激活函数: {activation_func}")
            print(f"初始权重: {self.weights}")
            print(f"初始偏置: {self.bias}")

        for epoch in range(epochs):
            epoch_details = []
            for i, inputs in enumerate(training_data):
                # 前向传播
                output, net_input = self.predict(inputs, activation_func)

                # Hebbian权重更新规则: Δw = η * x * y
                delta_weights = self.learning_rate * output * inputs
                delta_bias = self.learning_rate * output  # 偏置项更新

                # 保存更新前的状态
                old_weights = self.weights.copy()
                old_bias = self.bias

                # 更新权重和偏置
                self.weights += delta_weights
                self.bias += delta_bias

                epoch_details.append({
                    'sample': i + 1,
                    'inputs': inputs,
                    'net_input': net_input,
                    'output': output,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights,
                    'old_bias': old_bias,
                    'new_bias': self.bias,
                    'delta_bias': delta_bias
                })

            self.training_history.append({
                'epoch': epoch + 1,
                'rule': 'Hebbian',
                'activation_func': activation_func,
                'details': epoch_details
            })

            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1}/{epochs}, 激活函数: {activation_func}")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch)
    def hebbian_learning(self, training_data, activation_func, epochs=100, verbose=True):
        """1. Hebbian学习规则 - 无监督学习，根据输入调整权重"""
        print(f"开始Hebbian学习，激活函数: {activation_func}")
        print(f"初始权重: {self.weights}")

        for epoch in range(epochs):
            epoch_details = []
            for i, inputs in enumerate(training_data):
                # 前向传播
                output, net_input = self.predict(inputs, activation_func)
                # Hebbian权重更新
                delta_weights = self.learning_rate * output * inputs
                old_weights = self.weights.copy()
                self.weights += delta_weights

                epoch_details.append({
                    'sample': i + 1,
                    'inputs':inputs,
                    'net_input': net_input,
                    'output': output,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights
                })
            self.training_history.append({
                'epoch': epoch + 1,
                'rule': 'Hebbian',
                'activation_func': activation_func,
                'details': epoch_details
            })
            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1}/{epochs}, 激活函数: {activation_func}")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch) # 打印首尾epoch的详细信息

    def continuous_perceptron_learning(self, training_data, targets, activation_func, epochs=100, verbose=True):
        """2.连续感知器学习规则 - 监督学习，根据错误调整权重"""
        print(f"开始训练 - 连续感知器学习规则，激活函数: {activation_func}")
        print(f"初始权重: {self.weights}")

        for epoch in range(epochs):
            total_error = 0
            epoch_details = []
            for i, (inputs, target) in enumerate(zip(training_data, targets)):
                # 前向传播
                output, net_input = self.predict(inputs, activation_func)
                error = target - output
                total_error += error ** 2 # 计算总误差（均方误差）
                # 连续感知器权重更新
                derivative = self.activation_derivative(net_input, activation_func)
                delta_weights = self.learning_rate * error * derivative * inputs
                old_weights = self.weights.copy()
                self.weights += delta_weights

                epoch_details.append({
                    'sample': i + 1,
                    'inputs': inputs,
                    'net_input': net_input,
                    'output': output,
                    'target': target,
                    'error': error,
                    'derivative': derivative,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights
                })
            self.training_history.append({
                'epoch': epoch + 1,
                'rule': 'Continuous Perceptron',
                'activation_func': activation_func,
                'total_error': total_error / len(training_data), # 平均误差
                'details': epoch_details
            })
            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1}/{epochs}, 平均误差: {total_error / len(training_data)}")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch) # 打印首尾epoch的详细信息
            # 检查收敛
            if total_error / len(training_data) < 0.001:
                print(f"训练在第 {epoch + 1} 轮收敛。")
                break
    


    def winner_take_all_learning(self, training_data, epochs=100, verbose=True):
        """3.胜者取所有学习规则 - 监督学习，根据错误调整权重"""
        print(f"开始训练 - 胜者取所有学习规则")
        print(f"初始权重: {self.weights}")

        self.weights = self.weights / np.linalg.norm(self.weights) # 归一化初始权重

        for epoch in range(epochs):
            epoch_details = []

            for i, inputs in enumerate(training_data):
                net_input = np.dot(inputs, self.weights)
                delta_weights = self.learning_rate * (inputs - self.weights)
                old_weights = self.weights.copy()
                self.weights += delta_weights
                self.weights = self.weights / np.linalg.norm(self.weights) # 归一化权重
                epoch_details.append({
                    'sample': i + 1,
                    'inputs': inputs,
                    'net_input': net_input,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights
                })
            self.training_history.append({
                'epoch': epoch + 1,
                'rule': 'Winner Take All',
                'activation': 'N/A', # 胜者取所有学习规则没有激活函数
                'details': epoch_details
            })
            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1}/{epochs}")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch) # 打印首尾epoch的详细信息
    
    def _print_epoch_details(self, epoch):
        """打印指定epoch的详细信息"""
        print(f"\n--- Epoch {epoch + 1} 详细训练过程 ---")
        details = self.training_history[epoch]['details']
        rule = self.training_history[epoch]['rule']
        
        for detail in details:
            print(f"样本数据 {detail['sample']}:")
            print(f"  输入数据: {detail['inputs']}")
            # print(f"  净输入: {detail['net_input']:.4f}")
            
            if 'output' in detail:
                print(f"  输出数据: {detail['output']:.4f}")
            if 'target' in detail:
                print(f"  目标结果: {detail['target']}")
            if 'error' in detail:
                print(f"  误差: {detail['error']:.4f}")
            if 'derivative' in detail:
                print(f"  导数: {detail['derivative']:.4f}")

            print(f"  权重调整前: {detail['old_weights']}")
            print(f"  权重调整量: {detail['delta_weights']}")
            print(f"  权重调整后: {detail['new_weights']}")
            print()
    
    def demonstrate_all_rules():
        """演示所有规则"""
        print("生成随机训练数据...")
        training_data = np.array([[random.uniform(-1, 1) for _ in range(6)] for _ in range(10)])
        targets = np.array([random.choice([-1, 1]) for _ in range(10)]) # 二分类目标
        results = {}
        # 1. Hebbian学习规则
        print("\n" + "="*70)
        print("1. Hebbian学习规则演示")
        print("="*70)
        nn1 = AdvancedNeuralNetwork(learning_rate=0.01)
        nn1.hebbian_learning(training_data, epochs=5, activation_func='sigmoid', verbose=True)
        results['Hebbian'] = nn1

        print("\n" + "="*70)
        print("2. 连续感知器学习规则演示 (Sigmoid)")
        print("="*70)
        nn3 = AdvancedNeuralNetwork(learning_rate=0.1)
        nn3.continuous_perceptron_learning(training_data, targets, epochs=10, 
                                     activation_func='sigmoid', verbose=True)
        results['Continuous_Perceptron_Sigmoid'] = nn3
    

        print("\n" + "="*70)
        print("2. 连续感知器学习规则演示 (ReLU)")
        print("="*70)
        nn3_relu = AdvancedNeuralNetwork(learning_rate=0.1)
        nn3_relu.continuous_perceptron_learning(training_data, targets, epochs=10,
                                          activation_func='relu', verbose=True)
        results['Continuous_Perceptron_ReLU'] = nn3_relu
    

        print("\n" + "="*70)
        print("3. 胜者为王学习规则演示")
        print("="*70)
        nn6 = AdvancedNeuralNetwork(learning_rate=0.1)
        nn6.winner_take_all_learning(training_data, epochs=5, verbose=True)
        results['Winner_Take_All'] = nn6
    
        return results
    

    def plot_training_history(self):
        """绘制训练误差曲线"""
        if not self.training_history:
            print("没有训练历史数据")
            return
        
        plt.figure(figsize=(12, 8))
        
        # 为有误差的学习规则绘制误差曲线
        rules_with_error = ['Discrete_Perceptron', 'Continuous_Perceptron', 'LMS']
        
        for rule in rules_with_error:
            errors = []
            epochs_list = []
            
            for epoch_data in self.training_history:
                if epoch_data['rule'] == rule and 'total_error' in epoch_data:
                    errors.append(epoch_data['total_error'])
                    epochs_list.append(epoch_data['epoch'])
            
            if errors:
                plt.plot(epochs_list, errors, marker='o', label=f'{rule}')
        
        if any('total_error' in epoch_data for epoch_data in self.training_history):
            plt.xlabel('Epoch')
            plt.ylabel('误差')
            plt.title('训练误差曲线')
            plt.legend()
            plt.grid(True)
            plt.show()
        else:
            print("当前学习规则没有误差数据可绘制")

    def activation_derivative(self, x, func_type):

        if func_type == 'sigmoid':
            sig = self.activation_function(x, 'sigmoid')
            return sig * (1 - sig)  # sigmoid函数的导数: σ(x)(1-σ(x))
        elif func_type == 'tanh':
            return 1 - np.tanh(x)**2  # tanh函数的导数: 1-tanh²(x)
        elif func_type == 'relu':
            return 1 if x > 0 else 0  # ReLU函数的导数: 0处定义为0，正数处为1
        elif func_type == 'linear':
            return 1  # 线性函数的导数恒为1
        else:
            raise ValueError(f"不支持的激活函数类型: {func_type}")
        

if __name__ == "__main__":
    print("6输入单节点网络 - 六种学习规则 + 三种变换函数")
    print("="*70)
    
    while True:
        # print("\n请选择操作:")
        print("1. 实现规则（随机生成6组数据，再分别从三种学习规则，三种变换函数中各随机选择一种）")
        # print("2. 交互式训练")
        print("2. 结束")
        
        choice = input("请选择 (1-2): ")
        
        if choice == "1":
            results = AdvancedNeuralNetwork.demonstrate_all_rules()
            # 绘制部分网络的训练曲线
            for name, nn in results.items():
                if any('total_error' in epoch_data for epoch_data in nn.training_history):
                    print(f"\n{name} 训练曲线:")
                    nn.plot_training_history()

            
        elif choice == "2":
            print("程序结束")
            break
        else:
            print("无效选择，请重新输入")


    def __init__(self, input_size=6, learning_rate=0.1):
        self.input_size = input_size
        self.learning_rate = learning_rate
        self.weights = np.random.uniform(-0.5, 0.5, input_size)  # 使用偏置项
        self.training_history = []
        self.activation_funcs = ['sigmoid', 'tanh', 'relu']


    def activation_function(self, x, func_type):
        if func_type == 'sigmoid':
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))  # 防止溢出
        elif func_type == 'tanh':
            return np.tanh(x)
        elif func_type == 'relu':
            return np.maximum(0, x)
        elif func_type == 'linear':
            return x
        else:
            raise ValueError(f"不支持的激活函数类型: {func_type}")


    def net_input(self, inputs):
        return np.dot(inputs, self.weights)  # 矩阵乘法


    def predict(self, inputs, activation_func):
        net = self.net_input(inputs)
        return self.activation_function(net, activation_func), net