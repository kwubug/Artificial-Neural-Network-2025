import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
import random

def sgn(x):
    """符号函数：离散神经元激活函数"""
    return 1 if x > 0 else -1 if x < 0 else 0
def train_weights(samples):
    """
    训练Hopfield网络权重矩阵（Hebbian规则）
    :param samples: 训练样本列表，每个样本为n维向量（元素为1或-1）
    :return: 权重矩阵W（n×n）
    """
    m = len(samples)
    n = len(samples[0])
    W = np.zeros((n, n))

    for x in samples:
        x = np.array(x).reshape(-1, 1)
        W += np.dot(x, x.T)

    W /= n
    np.fill_diagonal(W, 0)
    return W


def async_update(W, s):
    """
    异步更新神经元状态（随机顺序更新）
    :param W: 权重矩阵（n×n）
    :param s: 当前状态向量（n维）
    :return: 更新后的状态向量s_new
    """
    n = len(s)
    s_new = s.copy()
    i = random.randint(0, n - 1)
    net_i = np.dot(W[i], s_new)
    s_new[i] = sgn(net_i) if net_i != 0 else s_new[i]
    return s_new


def compute_energy(W, s):
    """
    计算Hopfield网络的能量函数
    :param W: 权重矩阵（n×n）
    :param s: 状态向量（n维）
    :return: 能量值E
    """
    s = np.array(s)
    return -0.5 * np.dot(np.dot(s.T, W), s)


def run_hopfield(W, initial_state, max_iter=1000):
    """
    运行Hopfield网络，直到收敛到吸引子
    :param W: 权重矩阵（n×n）
    :param initial_state: 初始状态向量（n维）
    :param max_iter: 最大迭代次数（防止无限循环）
    :return: 收敛后的吸引子状态、能量变化列表
    """
    s_current = np.array(initial_state)
    energy_history = [compute_energy(W, s_current)]  # 记录能量变化
    iter_count = 0

    while iter_count < max_iter:
        s_next = async_update(W, s_current)
        energy_next = compute_energy(W, s_next)

        if np.array_equal(s_next, s_current):
            break

        s_current = s_next
        energy_history.append(energy_next)
        iter_count += 1

    return s_current, energy_history


if __name__ == "__main__":
    sample_0 = [
        1, 1, 1, 1, 1,
        1, -1, -1, -1, 1,
        1, -1, -1, -1, 1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, 1
    ]

    sample_1 = [
        -1, 1, 1, -1, -1,
        -1, -1, 1, -1, -1,
        -1, -1, 1, -1, -1,
        -1, -1, 1, -1, -1,
        -1, -1, 1, -1, -1
    ]

    sample_2 = [
        1, 1, 1, 1, -1,
        -1, -1, -1, 1, -1,
        -1, 1, 1, 1, -1,
        1, -1, -1, -1, -1,
        1, 1, 1, 1, 1
    ]

    samples = [sample_0, sample_1, sample_2]
    n = len(sample_0)

    W = train_weights(samples)

    noisy_sample_0 = sample_0.copy()
    noise_indices = random.sample(range(n), 5)
    for idx in noise_indices:
        noisy_sample_0[idx] *= -1
    attractor, energy_history = run_hopfield(W, noisy_sample_0)


    def vec_to_mat(vec):
        return np.array(vec).reshape(5, 5)



    plt.figure(figsize=(12, 4))
    plt.subplot(1, 3, 1)
    plt.imshow(vec_to_mat(noisy_sample_0), cmap='binary', interpolation='none')
    plt.title('Initial State (Noisy Sample 0)')
    plt.xticks([]), plt.yticks([])

    plt.subplot(1, 3, 2)
    plt.imshow(vec_to_mat(attractor), cmap='binary', interpolation='none')
    plt.title('Attractor (Converged State)')
    plt.xticks([]), plt.yticks([])

    plt.subplot(1, 3, 3)
    plt.plot(energy_history, 'b-', linewidth=2)
    plt.xlabel('Iteration')
    plt.ylabel('Energy')
    plt.title('Energy Change During Convergence')
    plt.grid(True)

    plt.tight_layout()
    plt.show()

    print("初始状态（带噪声）是否为训练样本：", noisy_sample_0 in samples)
    print("收敛后的吸引子是否为训练样本：", list(attractor) in samples)
    print("能量变化：从", energy_history[0], "降至", energy_history[-1])
    print("迭代次数：", len(energy_history) - 1)