from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QDoubleSpinBox, QPushButton, QTextEdit,
                               QLabel, QSpinBox, QFileDialog, QMessageBox, QGridLayout)
from PySide6.QtCore import Slot
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os

# 适配旧Matplotlib版本：强化负号和字体显示
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


# Hopfield-TSP核心求解类（保留完整功能）
class HopfieldTSPSolver:
    def __init__(self, cities, A=500, B=500, C=200, D=500):
        """
        初始化Hopfield TSP求解器
        cities: 城市坐标数组 (n, 2)
        A/B/C/D: 能量函数参数（控制约束和路径长度权重）
        """
        self.cities = cities
        self.n = len(cities)  # 城市数量
        self.A = A  # 约束1：每个城市只访问一次
        self.B = B  # 约束2：每个位置只访问一个城市
        self.C = C  # 约束3：总访问数=城市数
        self.D = D  # 约束4：最小化路径长度

        # 计算城市间距离矩阵
        self.dist_matrix = self._compute_distances()

        # 神经元状态矩阵 V[n][n]：V[i][j]表示城市i在第j个位置被访问
        self.V = np.random.rand(self.n, self.n)  # 初始状态[0,1]
        self.U = np.zeros((self.n, self.n))  # 神经元输入电位

    def _compute_distances(self):
        """计算城市间欧氏距离矩阵"""
        n = self.n
        dist_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    dist_matrix[i][j] = np.linalg.norm(self.cities[i] - self.cities[j])
        return dist_matrix

    def activation(self, x):
        """Sigmoid激活函数：将输入电位U转为状态V"""
        return 0.5 * (1 + np.tanh(x))

    def energy_function(self):
        """计算总能量（Hopfield能量函数，包含4个约束）"""
        V = self.V
        D = self.dist_matrix

        # 约束1：每个城市只被访问一次（行和=1）
        term1 = np.sum((np.sum(V, axis=1) - 1) ** 2)

        # 约束2：每个位置只访问一个城市（列和=1）
        term2 = np.sum((np.sum(V, axis=0) - 1) ** 2)

        # 约束3：总访问数=城市数（全局和=n）
        term3 = (np.sum(V) - self.n) ** 2

        # 约束4：最小化路径长度（相邻城市距离之和）
        term4 = 0
        for i in range(self.n):
            for j in range(self.n):
                for k in range(self.n):
                    next_k = (k + 1) % self.n  # 环形路径，最后一个位置的下一个是第一个
                    term4 += D[i][j] * V[i, k] * V[j, next_k]

        return 0.5 * (self.A * term1 + self.B * term2 + self.C * term3 + self.D * term4)

    def update_neurons(self, dt=0.0001, tau=1.0):
        """更新神经元状态（异步更新）"""
        for i in range(self.n):
            for j in range(self.n):
                # 计算输入电位U的变化率
                sum1 = -self.A * (np.sum(self.V[i, :]) - 1)  # 约束1贡献
                sum2 = -self.B * (np.sum(self.V[:, j]) - 1)  # 约束2贡献
                sum3 = -self.C * (np.sum(self.V) - self.n)  # 约束3贡献

                # 约束4贡献（相邻位置的距离惩罚）
                sum4 = 0
                prev_j = (j - 1) % self.n
                next_j = (j + 1) % self.n
                for k in range(self.n):
                    sum4 -= self.D * self.dist_matrix[i][k] * (self.V[k, prev_j] + self.V[k, next_j])

                # 更新输入电位U
                dU = (-self.U[i][j] + sum1 + sum2 + sum3 + sum4) / tau
                self.U[i][j] += dt * dU

        # 更新状态V（激活函数）
        self.V = self.activation(self.U)

    def solve(self, max_iter=1000, dt=0.0001):
        """求解TSP：迭代更新神经元直到收敛"""
        energy_history = []
        for iter_idx in range(max_iter):
            self.update_neurons(dt=dt)
            # 每10次迭代记录一次能量
            if iter_idx % 10 == 0:
                energy = self.energy_function()
                energy_history.append(energy)
                # 能量变化小于阈值时提前收敛
                if len(energy_history) > 1 and abs(energy_history[-1] - energy_history[-2]) < 1e-3:
                    break
        return energy_history

    def get_tour(self):
        """从神经元状态矩阵V中提取TSP路径"""
        # 每行取最大值对应的列（城市i的访问位置）
        tour_positions = np.argmax(self.V, axis=1)
        # 按访问位置排序，得到路径（城市索引顺序）
        tour = [city for _, city in sorted(zip(tour_positions, range(self.n)))]
        # 确保路径合法（无重复城市）
        if len(set(tour)) != self.n:
            return None  # 路径无效
        return tour

    def calculate_path_length(self, tour):
        """计算路径总长度"""
        if not tour:
            return float('inf')
        total_len = 0
        n = len(tour)
        for i in range(n):
            city1 = tour[i]
            city2 = tour[(i + 1) % n]  # 环形路径
            total_len += self.dist_matrix[city1][city2]
        return total_len


class HopfieldTSPWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None
        self.canvas = None
        self.init_ui()
        self.cities = None  # 城市坐标
        self.tsp_solver = None  # TSP求解器实例
        self.tour = None  # 求解得到的路径
        self.energy_history = None  # 能量变化历史

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 控制面板（分两部分：城市参数 + 能量函数参数）
        control_group = QGroupBox("参数设置（Hopfield-TSP：旅行商问题求解）")
        control_layout = QGridLayout()

        # 第一部分：城市参数
        control_layout.addWidget(QLabel("城市数量:"), 0, 0)
        self.city_num_spin = QSpinBox()
        self.city_num_spin.setRange(3, 30)  # 3~30个城市
        self.city_num_spin.setValue(10)
        control_layout.addWidget(self.city_num_spin, 0, 1)

        # 第二部分：能量函数参数（A/B/C/D）
        control_layout.addWidget(QLabel("能量函数参数:"), 1, 0, 1, 2)

        # 参数A
        control_layout.addWidget(QLabel("A（城市唯一访问）:"), 2, 0)
        self.A_spin = QDoubleSpinBox()
        self.A_spin.setRange(100, 2000)
        self.A_spin.setValue(500)
        self.A_spin.setSingleStep(100)
        control_layout.addWidget(self.A_spin, 2, 1)

        # 参数B
        control_layout.addWidget(QLabel("B（位置唯一城市）:"), 3, 0)
        self.B_spin = QDoubleSpinBox()
        self.B_spin.setRange(100, 2000)
        self.B_spin.setValue(500)
        self.B_spin.setSingleStep(100)
        control_layout.addWidget(self.B_spin, 3, 1)

        # 参数C
        control_layout.addWidget(QLabel("C（总访问数约束）:"), 4, 0)
        self.C_spin = QDoubleSpinBox()
        self.C_spin.setRange(50, 1000)
        self.C_spin.setValue(200)
        self.C_spin.setSingleStep(50)
        control_layout.addWidget(self.C_spin, 4, 1)

        # 参数D
        control_layout.addWidget(QLabel("D（路径长度权重）:"), 5, 0)
        self.D_spin = QDoubleSpinBox()
        self.D_spin.setRange(100, 2000)
        self.D_spin.setValue(500)
        self.D_spin.setSingleStep(100)
        control_layout.addWidget(self.D_spin, 5, 1)

        # 第三部分：训练参数
        control_layout.addWidget(QLabel("迭代次数:"), 6, 0)
        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(500, 10000)
        self.iter_spin.setValue(2000)
        self.iter_spin.setSingleStep(500)
        control_layout.addWidget(self.iter_spin, 6, 1)

        # 按钮布局
        button_layout = QHBoxLayout()

        self.gen_cities_btn = QPushButton("生成随机城市")
        self.gen_cities_btn.clicked.connect(self.generate_cities)
        button_layout.addWidget(self.gen_cities_btn)

        self.solve_btn = QPushButton("求解TSP路径")
        self.solve_btn.clicked.connect(self.solve_tsp)
        button_layout.addWidget(self.solve_btn)

        self.save_btn = QPushButton("保存结果图")
        self.save_btn.clicked.connect(self.save_figure)
        button_layout.addWidget(self.save_btn)

        control_layout.addLayout(button_layout, 7, 0, 1, 2)

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 结果显示区域
        result_layout = QHBoxLayout()

        # 文本输出
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用Hopfield-TSP界面！")
        self.text_output.append("功能：用Hopfield神经网络求解旅行商问题（TSP）")
        self.text_output.append("步骤：1. 生成随机城市 → 2. 调整参数 → 3. 求解TSP → 4. 查看路径")
        result_layout.addWidget(self.text_output, 1)

        # 图形显示
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)

        main_layout.addLayout(result_layout, 1)

    def initialize_plot(self):
        """初始化绘图区域（主窗口调用）"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(8, 6), dpi=100)
            # 强化显示设置，避免被覆盖
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        # 初始绘制提示图
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "等待生成随机城市...", ha='center', va='center', fontsize=14)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot()
    def generate_cities(self):
        """生成随机城市坐标（在100×100区域内）"""
        self.text_output.append("\n[步骤1] 生成随机城市...")
        n_cities = self.city_num_spin.value()
        # 生成[0,100]范围内的随机坐标
        self.cities = np.random.rand(n_cities, 2) * 100

        self.text_output.append(f"生成 {n_cities} 个随机城市（坐标范围：[0,100]×[0,100]）")
        for i, (x, y) in enumerate(self.cities):
            self.text_output.append(f"城市 {i}: ({x:.2f}, {y:.2f})")

        # 绘制城市分布
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, zorder=5)
        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            ax.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points', fontsize=10)
        ax.set_title(f"Hopfield-TSP：{n_cities}个城市分布")
        ax.set_xlabel("X坐标")
        ax.set_ylabel("Y坐标")
        ax.grid(True, alpha=0.3)  # 手动设置透明度
        self.canvas.draw()

    @Slot()
    def solve_tsp(self):
        """求解TSP路径"""
        if self.cities is None:
            self.text_output.append("\n[错误] 请先生成随机城市！")
            QMessageBox.warning(self, "警告", "请先点击「生成随机城市」按钮！")
            return

        self.text_output.append("\n[步骤2] 开始求解TSP路径...")

        # 获取参数
        A = self.A_spin.value()
        B = self.B_spin.value()
        C = self.C_spin.value()
        D = self.D_spin.value()
        max_iter = self.iter_spin.value()
        n_cities = len(self.cities)

        self.text_output.append(f"求解参数：")
        self.text_output.append(f"能量函数参数：A={A}, B={B}, C={C}, D={D}")
        self.text_output.append(f"最大迭代次数：{max_iter}")

        # 初始化TSP求解器
        self.tsp_solver = HopfieldTSPSolver(
            cities=self.cities,
            A=A, B=B, C=C, D=D
        )

        # 求解（记录时间）
        import time
        start_time = time.time()
        self.energy_history = self.tsp_solver.solve(max_iter=max_iter)
        end_time = time.time()

        # 提取路径并计算长度
        self.tour = self.tsp_solver.get_tour()
        if self.tour:
            path_length = self.tsp_solver.calculate_path_length(self.tour)
            self.text_output.append(f"\n求解完成！耗时：{end_time - start_time:.2f}秒")
            self.text_output.append(f"收敛迭代次数：{len(self.energy_history) * 10}")
            self.text_output.append(f"最终能量值：{self.energy_history[-1]:.2f}")
            self.text_output.append(f"TSP路径（城市编号）：{self.tour}")
            self.text_output.append(f"路径总长度：{path_length:.2f}")
        else:
            self.text_output.append(f"\n求解完成！但未找到有效路径（可能参数需要调整）")
            self.text_output.append(f"建议：增大A/B/C参数，或增加迭代次数")

        # 绘制结果（4个子图：城市分布+路径、能量变化、神经元状态矩阵）
        self.figure.clear()

        # 子图1：TSP路径结果
        ax1 = self.figure.add_subplot(2, 2, 1)
        ax1.scatter(self.cities[:, 0], self.cities[:, 1], c='red', s=100, zorder=5)
        # 绘制路径
        if self.tour:
            tour_cities = self.cities[self.tour]
            # 连接路径（包括回到起点）
            ax1.plot(tour_cities[:, 0], tour_cities[:, 1], 'b-', linewidth=2, alpha=0.8)
            ax1.plot([tour_cities[-1, 0], tour_cities[0, 0]],
                     [tour_cities[-1, 1], tour_cities[0, 1]], 'b-', linewidth=2, alpha=0.8)
        # 标注城市编号
        for i, (x, y) in enumerate(self.cities):
            ax1.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points')
        ax1.set_title("TSP路径结果")
        ax1.set_xlabel("X坐标")
        ax1.set_ylabel("Y坐标")
        ax1.grid(True, alpha=0.3)

        # 子图2：能量变化曲线
        ax2 = self.figure.add_subplot(2, 2, 2)
        ax2.plot(self.energy_history, 'b-', linewidth=1.5)
        ax2.set_title("能量函数收敛过程")
        ax2.set_xlabel("迭代次数（×10）")
        ax2.set_ylabel("能量值")
        ax2.set_yscale('log')
        ax2.grid(True, alpha=0.3)

        # 子图3：神经元状态矩阵V
        ax3 = self.figure.add_subplot(2, 2, 3)
        im = ax3.imshow(self.tsp_solver.V, cmap='hot', interpolation='nearest')
        ax3.set_title("神经元状态矩阵V（行=城市，列=位置）")
        ax3.set_xlabel("访问位置")
        ax3.set_ylabel("城市编号")
        self.figure.colorbar(im, ax=ax3, shrink=0.8)

        # 子图4：路径长度统计（若有有效路径）
        ax4 = self.figure.add_subplot(2, 2, 4)
        if self.tour:
            # 绘制路径片段长度
            segment_lengths = []
            segment_labels = []
            for i in range(n_cities):
                city1 = self.tour[i]
                city2 = self.tour[(i + 1) % n_cities]
                seg_len = self.tsp_solver.dist_matrix[city1][city2]
                segment_lengths.append(seg_len)
                segment_labels.append(f"{city1}→{city2}")
            ax4.bar(range(n_cities), segment_lengths, alpha=0.7, color='steelblue')
            ax4.set_title("各路段长度")
            ax4.set_xlabel("路段（城市→城市）")
            ax4.set_ylabel("长度")
            ax4.set_xticks(range(n_cities))
            ax4.set_xticklabels(segment_labels, rotation=45, ha='right')
        else:
            ax4.text(0.5, 0.5, "无有效路径", ha='center', va='center', fontsize=12)
            ax4.set_xlim(0, 1)
            ax4.set_ylim(0, 1)
        ax4.grid(True, alpha=0.3, axis='y')

        # 调整布局
        self.figure.tight_layout()
        self.canvas.draw()

    @Slot()
    def save_figure(self):
        """保存结果图（适配旧Matplotlib版本）"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先求解TSP，生成结果图后再保存！")
            return

        # 选择保存路径
        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存Hopfield-TSP结果图",
            os.path.join(os.getcwd(), "hopfield_tsp_result.png"),
            "图片文件 (*.png *.jpg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        # 手动添加bbox_inches，避免标签截断
        try:
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}")
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}")