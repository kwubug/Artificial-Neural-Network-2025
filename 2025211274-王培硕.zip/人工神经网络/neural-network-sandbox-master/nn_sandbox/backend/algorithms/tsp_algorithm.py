import numpy as np
import copy
import threading
import time
import random
from collections import defaultdict


class TSPAlgorithm:
    """旅行商问题（TSP）神经网络解法实现"""
    
    def __init__(self, cities=None, learning_rate=0.2, temperature=100.0, cooling_rate=0.99):
        """
        初始化TSP算法
        
        Args:
            cities: 城市坐标列表，每个城市是一个(x, y)坐标
            learning_rate: 学习率
            temperature: 初始温度（用于模拟退火）
            cooling_rate: 冷却率
        """
        self.cities = np.array(cities) if cities else None
        self.learning_rate = learning_rate
        self.temperature = temperature
        self.cooling_rate = cooling_rate
        self.num_cities = len(cities) if cities else 0
        self.distances = None
        self.current_path = None
        self.current_distance = None
        self.best_path = None
        self.best_distance = float('inf')
        self.distance_history = []
        self.path_history = []
        self._should_stop = False
        
        # 如果提供了城市，计算距离矩阵
        if cities:
            self._initialize_distances()
    
    def stop(self):
        """停止算法"""
        self._should_stop = True
    
    def _initialize_distances(self):
        """初始化城市间距离矩阵"""
        self.num_cities = len(self.cities)
        self.distances = np.zeros((self.num_cities, self.num_cities))
        
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                if i != j:
                    self.distances[i][j] = np.sqrt(
                        (self.cities[i][0] - self.cities[j][0])**2 + 
                        (self.cities[i][1] - self.cities[j][1])**2
                    )
    
    def _calculate_path_distance(self, path):
        """计算路径的总距离"""
        if not path or len(path) < 2:
            return float('inf')
        
        total_distance = 0
        for i in range(len(path)):
            total_distance += self.distances[path[i]][path[(i + 1) % len(path)]]
        
        return total_distance
    
    def _initialize_random_path(self):
        """生成随机初始路径"""
        path = list(range(self.num_cities))
        random.shuffle(path)
        return path
    
    def _two_opt_swap(self, path, i, j):
        """2-opt交换操作"""
        new_path = copy.copy(path)
        new_path[i:j+1] = new_path[i:j+1][::-1]
        return new_path
    
    def _two_opt_algorithm(self, initial_path, max_iterations=1000):
        """2-opt算法求解TSP"""
        current_path = copy.copy(initial_path)
        current_distance = self._calculate_path_distance(current_path)
        improved = True
        
        iteration = 0
        while improved and iteration < max_iterations:
            if self._should_stop:
                break
                
            improved = False
            
            for i in range(len(current_path) - 1):
                for j in range(i + 2, len(current_path)):
                    if self._should_stop:
                        break
                        
                    new_path = self._two_opt_swap(current_path, i, j)
                    new_distance = self._calculate_path_distance(new_path)
                    
                    if new_distance < current_distance:
                        current_path = new_path
                        current_distance = new_distance
                        improved = True
                        
                        # 更新历史记录
                        self.distance_history.append(current_distance)
                        self.path_history.append(copy.copy(current_path))
                        
                        # 模拟延迟以支持实时可视化
                        time.sleep(0.01)
                
                if self._should_stop:
                    break
            
            iteration += 1
        
        return current_path, current_distance
    
    def _simulated_annealing(self, initial_path, max_iterations=1000):
        """模拟退火算法求解TSP"""
        current_path = copy.copy(initial_path)
        current_distance = self._calculate_path_distance(current_path)
        
        self.best_path = copy.copy(current_path)
        self.best_distance = current_distance
        
        temperature = self.temperature
        
        for iteration in range(max_iterations):
            if self._should_stop:
                break
            
            # 生成邻域解（随机交换两个城市）
            i, j = random.sample(range(len(current_path)), 2)
            new_path = self._two_opt_swap(current_path, min(i, j), max(i, j))
            new_distance = self._calculate_path_distance(new_path)
            
            # 计算能量差
            delta_e = new_distance - current_distance
            
            # 接受准则
            if delta_e < 0 or random.random() < np.exp(-delta_e / temperature):
                current_path = new_path
                current_distance = new_distance
                
                # 更新最佳解
                if current_distance < self.best_distance:
                    self.best_path = copy.copy(current_path)
                    self.best_distance = current_distance
                
                # 更新历史记录
                self.distance_history.append(current_distance)
                self.path_history.append(copy.copy(current_path))
            
            # 降温
            temperature *= self.cooling_rate
            
            # 模拟延迟以支持实时可视化
            time.sleep(0.01)
        
        return current_path, current_distance
    
    def solve_tsp(self, method='simulated_annealing', max_iterations=1000):
        """求解TSP问题
        
        Args:
            method: 求解方法 ('2opt' 或 'simulated_annealing')
            max_iterations: 最大迭代次数
            
        Returns:
            best_path: 最佳路径
            best_distance: 最佳距离
        """
        if self.cities is None:
            return None, float('inf')
        
        # 初始化
        self.distance_history = []
        self.path_history = []
        self.best_distance = float('inf')
        
        # 生成初始路径
        initial_path = self._initialize_random_path()
        self.current_path = initial_path
        self.current_distance = self._calculate_path_distance(initial_path)
        
        # 记录初始状态
        self.distance_history.append(self.current_distance)
        self.path_history.append(copy.copy(self.current_path))
        
        # 根据方法选择算法
        if method == '2opt':
            final_path, final_distance = self._two_opt_algorithm(initial_path, max_iterations)
        elif method == 'simulated_annealing':
            final_path, final_distance = self._simulated_annealing(initial_path, max_iterations)
        else:
            raise ValueError(f"Unknown method: {method}")
        
        self.current_path = final_path
        self.current_distance = final_distance
        
        # 确保最佳路径被设置
        if method == '2opt' or final_distance < self.best_distance:
            self.best_path = copy.copy(final_path)
            self.best_distance = final_distance
        
        return self.best_path, self.best_distance
    
    def get_visualization_data(self):
        """获取可视化数据
        
        Returns:
            dict: 包含路径历史、距离历史、城市坐标等可视化所需数据
        """
        return {
            'cities': self.cities,
            'path_history': self.path_history,
            'distance_history': self.distance_history,
            'current_path': self.current_path,
            'current_distance': self.current_distance,
            'best_path': self.best_path,
            'best_distance': self.best_distance,
            'distances': self.distances
        }