import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'Hopfield'

    Flickable {
        anchors.fill: parent
        contentHeight: mainLayout.implicitHeight
        clip: true

        ColumnLayout {
            id: mainLayout
            width: parent.width
            spacing: 15

            // ==================== 模式管理区 ====================
            GroupBox {
                title: 'Pattern Management'
                Layout.fillWidth: true

                ColumnLayout {
                    width: parent.width
                    spacing: 8

                    GridLayout {
                        Layout.fillWidth: true
                        columns: 2
                        rowSpacing: 6
                        columnSpacing: 12

                        Label {
                            text: 'Stored Patterns:'
                            font.bold: true
                        }
                        Label {
                            text: hopfieldBridge.pattern_count
                            Layout.fillWidth: true
                        }

                        Label {
                            text: 'Network Capacity:'
                            font.bold: true
                        }
                        Label {
                            text: hopfieldBridge.calculate_pattern_capacity()
                            Layout.fillWidth: true
                        }

                        Label {
                            text: 'Neurons:'
                            font.bold: true
                        }
                        Label {
                            text: hopfieldBridge.num_neurons
                            Layout.fillWidth: true
                        }

                        Label {
                            text: 'Network Info:'
                            font.bold: true
                        }
                        Label {
                            text: hopfieldBridge.get_network_info()
                            wrapMode: Text.Wrap
                            Layout.fillWidth: true
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 10

                        Button {
                            text: 'Store Random Pattern'
                            Layout.fillWidth: true
                            enabled: !hopfieldBridge.retrieval_in_progress
                            onClicked: {
                                var pattern = hopfieldBridge.generate_random_pattern()
                                hopfieldBridge.store_pattern(pattern)
                            }
                        }

                        Button {
                            text: 'Clear All'
                            Layout.fillWidth: true
                            enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                            onClicked: hopfieldBridge.clear_patterns()
                        }
                    }
                }
            }

            // ==================== 检索配置区 ====================
            GroupBox {
                title: 'Retrieval Configuration'
                Layout.fillWidth: true

                ColumnLayout {
                    width: parent.width
                    spacing: 8

                    GridLayout {
                        Layout.fillWidth: true
                        columns: 2
                        rowSpacing: 8
                        columnSpacing: 12

                        Label {
                            text: 'Select Pattern:'
                        }
                        ComboBox {
                            id: patternSelector
                            model: hopfieldBridge.pattern_count
                            Layout.fillWidth: true
                            enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                        }

                        Label {
                            text: 'Noise Level:'
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            Slider {
                                id: noiseSlider
                                from: 0
                                to: 1
                                value: 0.1
                                Layout.fillWidth: true
                                enabled: !hopfieldBridge.retrieval_in_progress
                            }
                            Label {
                                text: (noiseSlider.value * 100).toFixed(0) + '%'
                                width: 50
                            }
                        }

                        Label {
                            text: 'Update Rule:'
                        }
                        ComboBox {
                            id: updateRuleSelector
                            model: ['Async', 'Sync']
                            Layout.fillWidth: true
                            enabled: !hopfieldBridge.retrieval_in_progress
                        }

                        Label {
                            text: 'Max Iterations:'
                        }
                        SpinBox {
                            id: maxIterInput
                            value: 1000
                            to: 100000
                            Layout.fillWidth: true
                            enabled: !hopfieldBridge.retrieval_in_progress
                            editable: true
                        }
                    }
                }
            }

            // ==================== 控制按钮 ====================
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Button {
                    text: 'Create Noisy Pattern'
                    Layout.fillWidth: true
                    enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                    onClicked: {
                        var patternIdx = patternSelector.currentIndex
                        var noiseRate = noiseSlider.value
                        hopfieldBridge.create_noisy_pattern(patternIdx, noiseRate)
                    }
                }

                Button {
                    text: 'Single Step'
                    Layout.fillWidth: true
                    enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                    onClicked: {
                        var rule = updateRuleSelector.currentText.toLowerCase()
                        hopfieldBridge.step(rule)
                    }
                }

                Button {
                    text: 'Retrieve'
                    Layout.fillWidth: true
                    highlighted: true
                    enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                    onClicked: {
                        var rule = updateRuleSelector.currentText.toLowerCase()
                        var maxIter = maxIterInput.value
                        hopfieldBridge.retrieve(maxIter, rule)
                    }
                }
            }

            // ==================== 实时状态显示 ====================
            GroupBox {
                title: 'Network State'
                Layout.fillWidth: true

                GridLayout {
                    width: parent.width
                    columns: 2
                    rowSpacing: 8
                    columnSpacing: 12

                    Label {
                        text: 'Energy:'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.energy.toFixed(2)
                        color: hopfieldBridge.energy < -1000 ? '#00AA00' : '#FF9900'
                    }

                    Label {
                        text: 'Iteration:'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.iteration
                    }

                    Label {
                        text: 'Converged:'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.converged ? 'Yes ✓' : 'No'
                        color: hopfieldBridge.converged ? '#00AA00' : '#FF0000'
                    }

                    Label {
                        text: 'Similarity:'
                        font.bold: true
                    }
                    Label {
                        text: (hopfieldBridge.similarity * 100).toFixed(1) + '%'
                    }

                    Label {
                        text: 'Status:'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.retrieval_in_progress ? '⏳ Retrieving...' : '✓ Ready'
                        color: hopfieldBridge.retrieval_in_progress ? '#FF6600' : '#00AA00'
                    }
                }
            }

            // ==================== 状态可视化 ====================
            GroupBox {
                title: 'State Visualization'
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 300

                ColumnLayout {
                    width: parent.width
                    spacing: 8

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 200
                        color: '#FFFFFF'
                        border.color: '#CCCCCC'
                        border.width: 1

                        Canvas {
                            id: stateCanvas
                            anchors.fill: parent
                            anchors.margins: 2

                            Connections {
                                target: hopfieldBridge
                                function onCurrent_stateChanged() {
                                    stateCanvas.requestPaint()
                                }
                            }

                            onPaint: {
                                var ctx = getContext('2d')
                                ctx.fillStyle = '#FFFFFF'
                                ctx.fillRect(0, 0, width, height)

                                var state = hopfieldBridge.current_state
                                if (!state || state.length === 0) {
                                    ctx.fillStyle = '#DDDDDD'
                                    ctx.font = '14px Arial'
                                    ctx.fillText('No state to display', width/3, height/2)
                                    return
                                }

                                var neuronSize = Math.min(width, height) / Math.ceil(Math.sqrt(state.length))
                                var cols = Math.ceil(width / neuronSize)

                                for (var i = 0; i < state.length; i++) {
                                    var row = Math.floor(i / cols)
                                    var col = i % cols
                                    var x = col * neuronSize
                                    var y = row * neuronSize

                                    ctx.fillStyle = state[i] > 0 ? '#0066FF' : '#FF6600'
                                    ctx.fillRect(x + 2, y + 2, neuronSize - 4, neuronSize - 4)

                                    ctx.strokeStyle = '#999999'
                                    ctx.lineWidth = 1
                                    ctx.strokeRect(x, y, neuronSize, neuronSize)
                                }
                            }
                        }
                    }

                    // 能量曲线图
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 150
                        color: '#F5F5F5'
                        border.color: '#CCCCCC'
                        border.width: 1

                        Column {
                            anchors.fill: parent
                            anchors.margins: 8
                            spacing: 4

                            Text {
                                text: 'Energy Curve (Evolution)'
                                font.bold: true
                                font.pixelSize: 12
                                color: '#333333'
                            }

                            Canvas {
                                id: energyCanvas
                                width: parent.width - 16
                                height: 110

                                Connections {
                                    target: hopfieldBridge
                                    function onEnergyChanged() {
                                        energyCanvas.requestPaint()
                                    }
                                    function onIterationChanged() {
                                        energyCanvas.requestPaint()
                                    }
                                }

                                onPaint: {
                                    var ctx = getContext('2d')
                                    var w = width
                                    var h = height
                                    var margin = 30

                                    // 清空
                                    ctx.fillStyle = '#FFFFFF'
                                    ctx.fillRect(0, 0, w, h)

                                    // 绘制坐标轴
                                    ctx.strokeStyle = '#999999'
                                    ctx.lineWidth = 1
                                    ctx.beginPath()
                                    ctx.moveTo(margin, 10)
                                    ctx.lineTo(margin, h - margin)
                                    ctx.lineTo(w, h - margin)
                                    ctx.stroke()

                                    // 获取历史数据
                                    var stateHistory = hopfieldBridge.state_history
                                    if (!stateHistory || stateHistory.length === 0) {
                                        ctx.fillStyle = '#999999'
                                        ctx.font = '12px Arial'
                                        ctx.fillText('No history yet', margin + 10, h/2)
                                        return
                                    }

                                    // 计算能量并绘制曲线
                                    var maxEnergy = -10000
                                    var minEnergy = 10000
                                    var energies = []

                                    // 简单估算：使用 similarity 作为代理
                                    // 实际上应该计算真实能量，但这里简化处理
                                    for (var i = 0; i < stateHistory.length; i++) {
                                        var sim = stateHistory[i]
                                        var energy = -sim * 100  // 负相关
                                        energies.push(energy)
                                        if (energy > maxEnergy) maxEnergy = energy
                                        if (energy < minEnergy) minEnergy = energy
                                    }

                                    if (minEnergy === maxEnergy) {
                                        maxEnergy = minEnergy + 1
                                    }

                                    var range = maxEnergy - minEnergy
                                    var plotW = w - margin - 10
                                    var plotH = h - margin - 20
                                    var xStep = plotW / Math.max(1, energies.length - 1)

                                    // 绘制曲线
                                    ctx.strokeStyle = '#0066FF'
                                    ctx.lineWidth = 2
                                    ctx.beginPath()

                                    for (var i = 0; i < energies.length; i++) {
                                        var x = margin + i * xStep
                                        var y = h - margin - ((energies[i] - minEnergy) / range) * plotH
                                        if (i === 0) {
                                            ctx.moveTo(x, y)
                                        } else {
                                            ctx.lineTo(x, y)
                                        }
                                    }
                                    ctx.stroke()

                                    // 绘制数据点
                                    ctx.fillStyle = '#FF6600'
                                    for (var i = 0; i < energies.length; i++) {
                                        var x = margin + i * xStep
                                        var y = h - margin - ((energies[i] - minEnergy) / range) * plotH
                                        ctx.beginPath()
                                        ctx.arc(x, y, 3, 0, 2 * Math.PI)
                                        ctx.fill()
                                    }

                                    // 标注当前点
                                    if (energies.length > 0) {
                                        var lastIdx = energies.length - 1
                                        var lastX = margin + lastIdx * xStep
                                        var lastY = h - margin - ((energies[lastIdx] - minEnergy) / range) * plotH
                                        ctx.fillStyle = '#00AA00'
                                        ctx.beginPath()
                                        ctx.arc(lastX, lastY, 5, 0, 2 * Math.PI)
                                        ctx.fill()
                                    }

                                    // 标注轴
                                    ctx.fillStyle = '#666666'
                                    ctx.font = '10px Arial'
                                    ctx.fillText('0', margin - 20, h - margin + 5)
                                    ctx.fillText('Iter', margin - 10, h - margin + 20)
                                    ctx.fillText('E', margin - 20, 15)
                                }
                            }
                        }
                    }
                }
            }

            Item {
                Layout.fillHeight: true
            }
        }
    }
}
