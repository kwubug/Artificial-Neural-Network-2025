import numpy as np
from .bridge import Bridge, BridgeProperty


class GradientDescentBridge(Bridge):
    def __init__(self):
        super().__init__()
        self._current_algorithm = "steepest_descent"
        self._iterations = 100
        self._is_running = False
        self._loss_history = []
        self._gradient_norms = []
        self._current_status = "Ready"

        # 使用BridgeProperty定义属性 - 添加类型检查
        self.algorithmType = BridgeProperty(str, self._current_algorithm)
        self.iterations = BridgeProperty(int, self._iterations)
        self.isRunning = BridgeProperty(bool, self._is_running)
        self.lossHistory = BridgeProperty(list, self._loss_history)
        self.gradientNorms = BridgeProperty(list, self._gradient_norms)
        self.currentStatus = BridgeProperty(str, self._current_status)

    def startVisualization(self):
        """开始优化算法可视化"""
        try:
            if self._is_running:
                return  # 防止重复运行

            self._is_running = True
            self.isRunning = True
            self.currentStatus = "正在运行优化算法..."

            # 使用小规模数据测试
            self._simulate_simple_optimization()

            self.currentStatus = f"优化完成，共{self._iterations}次迭代"

        except Exception as e:
            self.currentStatus = f"错误: {str(e)}"
        finally:
            self._is_running = False
            self.isRunning = False

    def _simulate_simple_optimization(self):
        """简化版的优化模拟，避免栈溢出"""
        # 清空历史数据
        self._loss_history = []
        self._gradient_norms = []

        # 模拟简单的优化过程
        for i in range(self._iterations):
            # 生成模拟数据 - 避免复杂计算
            if self._current_algorithm == "steepest_descent":
                loss = 10.0 / (1 + i * 0.1)  # 最速下降
                gradient = 5.0 / (1 + i * 0.05)
            elif self._current_algorithm == "newton_method":
                loss = 10.0 / (1 + i * 0.2)  # 牛顿法收敛更快
                gradient = 5.0 / (1 + i * 0.1)
            else:  # conjugate_gradient
                loss = 10.0 / (1 + i * 0.15)  # 共轭梯度法
                gradient = 5.0 / (1 + i * 0.08)

            # 限制数据大小
            if len(self._loss_history) < 1000:  # 安全限制
                self._loss_history.append(float(loss))
                self._gradient_norms.append(float(gradient))

        # 批量更新属性，避免频繁信号发射
        self.lossHistory = self._loss_history.copy()
        self.gradientNorms = self._gradient_norms.copy()

    def setAlgorithmType(self, algorithm_type):
        if algorithm_type in ["steepest_descent", "newton_method", "conjugate_gradient"]:
            self._current_algorithm = algorithm_type
            self.algorithmType = algorithm_type

    def setIterations(self, iterations):
        iterations = max(10, min(1000, int(iterations)))  # 安全范围
        self._iterations = iterations
        self.iterations = iterations