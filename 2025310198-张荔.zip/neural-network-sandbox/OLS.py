import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体
plt.rcParams['font.family'] = ['DejaVu Sans', 'SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class EnhancedOLSVisualization:
    def __init__(self, X, y):
        self.X = X
        self.y = y
        self.n_samples = X.shape[0]

        # OLS参数
        self.w = 0  # 斜率
        self.b = 0  # 截距

        # 存储历史记录用于动画
        self.w_history = []
        self.b_history = []
        self.loss_history = []

    def compute_loss(self, w, b):
        """计算均方误差损失"""
        y_pred = w * self.X + b
        return np.mean((self.y - y_pred) ** 2)

    def compute_gradient(self, w, b):
        """计算梯度"""
        y_pred = w * self.X + b
        dw = -2 * np.mean(self.X * (self.y - y_pred))
        db = -2 * np.mean(self.y - y_pred)
        return dw, db

    def gradient_descent_step(self, learning_rate=0.01):
        """执行一次梯度下降"""
        dw, db = self.compute_gradient(self.w, self.b)
        self.w -= learning_rate * dw
        self.b -= learning_rate * db

        # 记录历史
        self.w_history.append(self.w)
        self.b_history.append(self.b)
        self.loss_history.append(self.compute_loss(self.w, self.b))

    def fit_gradient_descent(self, n_iterations=100, learning_rate=0.01):
        """使用梯度下降拟合"""
        # 重置参数
        self.w = 0
        self.b = 0
        self.w_history = [self.w]
        self.b_history = [self.b]
        self.loss_history = [self.compute_loss(self.w, self.b)]

        for i in range(n_iterations):
            self.gradient_descent_step(learning_rate)

    def fit_analytical(self):
        """使用解析解（正规方程）拟合"""
        X_mean = np.mean(self.X)
        y_mean = np.mean(self.y)

        # 计算斜率 w
        numerator = np.sum((self.X - X_mean) * (self.y - y_mean))
        denominator = np.sum((self.X - X_mean) ** 2)
        self.w = numerator / denominator

        # 计算截距 b
        self.b = y_mean - self.w * X_mean

        return self.w, self.b

    def predict(self, X):
        """预测"""
        return self.w * X + self.b


# 生成示例数据
np.random.seed(42)
n_points = 50
X = np.linspace(-2, 2, n_points)
true_w = 1.5
true_b = 0.5
y = true_w * X + true_b + np.random.normal(0, 0.5, n_points)

# 创建OLS可视化对象
ols_viz = EnhancedOLSVisualization(X, y)

# 使用解析解拟合
w_analytical, b_analytical = ols_viz.fit_analytical()
y_pred_analytical = ols_viz.predict(X)

# 使用梯度下降拟合
ols_viz.fit_gradient_descent(n_iterations=200, learning_rate=0.1)
y_pred_gd = ols_viz.predict(X)

# ==================== 单独显示每个图表 ====================

# 1. 数据生成过程可视化
plt.figure(figsize=(10, 6))
X_clean = np.linspace(-2, 2, 100)
y_clean = true_w * X_clean + true_b
plt.plot(X_clean, y_clean, 'r-', linewidth=3, label='真实关系', alpha=0.8)
plt.scatter(X, y, alpha=0.6, color='blue', s=30, label='带噪声的观测数据')

# 添加噪声说明
for i in range(5):  # 只显示几个点的噪声
    plt.plot([X[i], X[i]], [true_w * X[i] + true_b, y[i]], 'k--', alpha=0.5)
    plt.annotate('噪声', xy=(X[i], (true_w * X[i] + true_b + y[i]) / 2),
                 xytext=(5, 5), textcoords='offset points', fontsize=8)

plt.xlabel('特征 X')
plt.ylabel('目标 y')
plt.title('1. 数据生成过程\n(真实关系 + 噪声)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 2. OLS目标函数可视化
plt.figure(figsize=(10, 6))

# 计算不同参数下的损失
w_range = np.linspace(0, 3, 100)
losses = [ols_viz.compute_loss(w, 0) for w in w_range]

plt.plot(w_range, losses, 'b-', linewidth=2)
plt.axvline(x=true_w, color='red', linestyle='--', alpha=0.7, label='真实斜率')
plt.xlabel('斜率 w')
plt.ylabel('均方误差损失')
plt.title('2. OLS目标函数\n(最小化均方误差)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 3. 残差可视化
plt.figure(figsize=(10, 6))

plt.scatter(X, y, alpha=0.6, color='blue', label='数据点')
plt.plot(X, y_pred_analytical, 'g-', linewidth=2, label='OLS拟合直线')

# 绘制残差
for i in range(len(X)):
    plt.plot([X[i], X[i]], [y[i], y_pred_analytical[i]], 'r--', alpha=0.5)

plt.xlabel('特征 X')
plt.ylabel('目标 y')
plt.title('3. 残差可视化\n(观测值 - 预测值)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 4. 梯度下降原理
plt.figure(figsize=(10, 6))


# 简化的梯度下降示例
def simple_loss(w):
    return (w - true_w) ** 2 + 0.5


w_test = np.linspace(0, 3, 100)
loss_test = simple_loss(w_test)

plt.plot(w_test, loss_test, 'b-', linewidth=2, label='损失函数')

# 模拟梯度下降步骤
current_w = 0.5
learning_rate = 0.3
for i in range(5):
    next_w = current_w - learning_rate * 2 * (current_w - true_w)
    plt.arrow(current_w, simple_loss(current_w),
              next_w - current_w, simple_loss(next_w) - simple_loss(current_w),
              head_width=0.05, head_length=0.1, fc='red', ec='red')
    current_w = next_w

plt.xlabel('参数 w')
plt.ylabel('损失')
plt.title('4. 梯度下降原理\n(沿负梯度方向更新)', fontsize=14, fontweight='bold')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 5. 解析解方法
plt.figure(figsize=(10, 6))

plt.scatter(X, y, alpha=0.6, color='blue', label='数据点')
plt.plot(X, y_pred_analytical, 'g-', linewidth=2, label='解析解拟合')
plt.plot(X, true_w * X + true_b, 'r--', alpha=0.7, label='真实关系')
plt.xlabel('特征 X')
plt.ylabel('目标 y')
plt.title('5. 解析解方法\n(正规方程)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 6. 梯度下降过程
plt.figure(figsize=(10, 6))

# 运行梯度下降
ols_viz.fit_gradient_descent(n_iterations=50, learning_rate=0.1)

# 显示几个关键迭代步骤
iterations_to_show = [0, 5, 10, 20, 49]
colors = ['orange', 'purple', 'brown', 'pink', 'green']

plt.scatter(X, y, alpha=0.3, color='blue', label='数据点')

for i, iter_idx in enumerate(iterations_to_show):
    w_temp = ols_viz.w_history[iter_idx]
    b_temp = ols_viz.b_history[iter_idx]
    y_temp = w_temp * X + b_temp
    plt.plot(X, y_temp, color=colors[i], alpha=0.7,
             label=f'迭代 {iter_idx + 1}')

plt.plot(X, y_pred_analytical, 'k-', linewidth=2, label='最终解')
plt.xlabel('特征 X')
plt.ylabel('目标 y')
plt.title('6. 梯度下降过程\n(迭代优化)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 7. 参数空间和损失曲面
plt.figure(figsize=(10, 6))

w_range = np.linspace(0.5, 2.5, 50)
b_range = np.linspace(-0.5, 1.5, 50)
W, B = np.meshgrid(w_range, b_range)
Z = np.zeros_like(W)

for i in range(W.shape[0]):
    for j in range(W.shape[1]):
        Z[i, j] = ols_viz.compute_loss(W[i, j], B[i, j])

contour = plt.contour(W, B, Z, levels=15, alpha=0.7)
plt.clabel(contour, inline=True, fontsize=8)

# 绘制梯度下降路径
plt.plot(ols_viz.w_history[:50], ols_viz.b_history[:50], 'ro-',
         markersize=3, alpha=0.8, linewidth=1, label='梯度下降路径')
plt.plot([w_analytical], [b_analytical], 'g*', markersize=15,
         label='解析解')
plt.plot([true_w], [true_b], 'b*', markersize=15, label='真实参数')

plt.xlabel('斜率 w')
plt.ylabel('截距 b')
plt.title('7. 参数空间\n(损失曲面和优化路径)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 8. 收敛性分析
plt.figure(figsize=(10, 6))

plt.plot(ols_viz.loss_history[:50], 'b-', linewidth=2, label='梯度下降')
plt.axhline(y=ols_viz.compute_loss(w_analytical, b_analytical),
            color='red', linestyle='--', label='最小损失')
plt.xlabel('迭代次数')
plt.ylabel('损失值')
plt.title('8. 收敛性分析\n(损失函数下降)', fontsize=14, fontweight='bold')
plt.yscale('log')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 9. 残差分析
plt.figure(figsize=(10, 6))

residuals = y - y_pred_analytical
plt.scatter(y_pred_analytical, residuals, alpha=0.6, color='blue')
plt.axhline(y=0, color='red', linestyle='--', linewidth=2)
plt.xlabel('预测值')
plt.ylabel('残差')
plt.title('9. 残差分析\n(检查模型假设)', fontsize=14, fontweight='bold')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 10. 预测效果
plt.figure(figsize=(10, 6))

plt.scatter(y, y_pred_analytical, alpha=0.6, color='blue')
min_val = min(y.min(), y_pred_analytical.min())
max_val = max(y.max(), y_pred_analytical.max())
plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2,
         label='完美预测线')
plt.xlabel('真实值')
plt.ylabel('预测值')
plt.title('10. 预测效果\n(预测 vs 真实)', fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# 11. 学习率影响
plt.figure(figsize=(10, 6))

learning_rates = [0.01, 0.05, 0.1, 0.2]
colors = ['blue', 'green', 'red', 'purple']

for i, lr in enumerate(learning_rates):
    ols_temp = EnhancedOLSVisualization(X, y)
    ols_temp.fit_gradient_descent(n_iterations=50, learning_rate=lr)
    plt.plot(ols_temp.loss_history[:50], color=colors[i],
             label=f'LR={lr}', alpha=0.8)

plt.xlabel('迭代次数')
plt.ylabel('损失值')
plt.title('11. 学习率影响\n(收敛速度比较)', fontsize=14, fontweight='bold')
plt.yscale('log')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()


# # 12. 算法总结比较
# plt.figure(figsize=(12, 8))

# # # 创建算法比较表格
# # algorithms = ['解析解(正规方程)', '梯度下降']
# # time_complexity = ['O(n³)', 'O(kn)']
# # memory_usage = ['O(n²)', 'O(n)']
# # advantages = ['精确解\n一次计算', '可扩展\n在线学习']
# # disadvantages = ['数值不稳定\n内存消耗大', '收敛速度依赖\n学习率选择']

# # # 清除坐标轴
# # plt.axis('off')

# # # 创建表格
# # table_data = [
# #     ['算法', '时间复杂度', '内存使用', '优点', '缺点'],
# #     [algorithms[0], time_complexity[0], memory_usage[0], advantages[0], disadvantages[0]],
# #     [algorithms[1], time_complexity[1], memory_usage[1], advantages[1], disadvantages[1]]
# # ]

# # table = plt.table(cellText=table_data,
# #                  loc='center',
# #                  cellLoc='center',
# #                  colWidths=[0.15, 0.15, 0.15, 0.25, 0.3])

# # table.auto_set_font_size(False)
# # table.set_fontsize(10)
# # table.scale(1, 2)

# # plt.title('12. 算法总结比较', fontsize=14, fontweight='bold', pad=20)
# # plt.tight_layout()
# # plt.show()

# ==================== 性能评估和总结 ====================

def performance_evaluation():
    """性能评估和总结"""

    print("=" * 60)
    print("              OLS学习算法全面评估")
    print("=" * 60)

    # 重新计算预测值以确保变量存在
    w_analytical, b_analytical = ols_viz.fit_analytical()
    y_pred_analytical = ols_viz.predict(X)

    # 基本统计信息
    print(f"\n1. 数据统计:")
    print(f"   样本数量: {len(X)}")
    print(f"   特征范围: [{X.min():.2f}, {X.max():.2f}]")
    print(f"   目标范围: [{y.min():.2f}, {y.max():.2f}]")
    print(f"   噪声水平: 标准差 = {np.std(y - (true_w * X + true_b)):.3f}")

    # 参数估计
    print(f"\n2. 参数估计结果:")
    print(f"   真实参数:     w = {true_w:.4f}, b = {true_b:.4f}")
    print(f"   解析解估计:   w = {w_analytical:.4f}, b = {b_analytical:.4f}")
    print(f"   梯度下降估计: w = {ols_viz.w_history[-1]:.4f}, b = {ols_viz.b_history[-1]:.4f}")

    # 误差分析
    print(f"\n3. 模型性能:")
    r2_analytical = r2_score(y, y_pred_analytical)
    mse_analytical = np.mean((y - y_pred_analytical) ** 2)

    y_pred_gd = ols_viz.predict(X)
    r2_gd = r2_score(y, y_pred_gd)
    mse_gd = np.mean((y - y_pred_gd) ** 2)

    print(f"   解析解 - R²: {r2_analytical:.6f}, MSE: {mse_analytical:.6f}")
    print(f"   梯度下降 - R²: {r2_gd:.6f}, MSE: {mse_gd:.6f}")

    # 收敛分析
    print(f"\n4. 梯度下降收敛分析:")
    final_loss = ols_viz.loss_history[-1]
    optimal_loss = ols_viz.compute_loss(w_analytical, b_analytical)
    convergence_error = abs(final_loss - optimal_loss)
    print(f"   最终损失: {final_loss:.6f}")
    print(f"   最优损失: {optimal_loss:.6f}")
    print(f"   收敛误差: {convergence_error:.6e}")
    print(f"   相对误差: {convergence_error / optimal_loss * 100:.4f}%")


#     # 算法比较
#     print(f"\n5. 算法特性比较:")
#     print(f"   解析解优势: 精确解，一次计算完成")
#     print(f"   梯度下降优势: 可处理大规模数据，支持在线学习")
#     print(f"   推荐使用场景:")
#     print(f"     - 小数据集(n < 10,000): 解析解")
#     print(f"     - 大数据集(n > 10,000): 梯度下降")
#     print(f"     - 流式数据: 随机梯度下降")

#     print(f"\n6. 学习要点总结:")
#     points = [
#         "OLS通过最小化残差平方和寻找最佳拟合直线",
#         "解析解使用正规方程，直接计算得到精确解",
#         "梯度下降通过迭代逐步逼近最优解",
#         "学习率影响收敛速度和稳定性",
#         "残差分析用于验证模型假设",
#         "R²衡量模型解释的方差比例"
#     ]

#     for i, point in enumerate(points, 1):
#         print(f"   {i}. {point}")

# ==================== 主执行程序 ====================

def main():
    """主执行函数"""

    print("开始OLS学习算法可视化演示...")

    # 执行性能评估
    print("\n进行性能评估...")
    performance_evaluation()

    print("\nOLS学习算法可视化演示完成！")


# 运行主程序
if __name__ == "__main__":
    main()