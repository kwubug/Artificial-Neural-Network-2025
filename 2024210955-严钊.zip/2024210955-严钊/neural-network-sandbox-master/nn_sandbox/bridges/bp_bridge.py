import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(100)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.95)
    initial_learning_rate = BridgeProperty(0.1)
    search_iteration_constant = BridgeProperty(1000)
    test_ratio = BridgeProperty(0.3)
    hidden_neurons_count = BridgeProperty(4)

    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_loss = BridgeProperty(0.0)

    # BP网络特有的属性
    hidden_weights = BridgeProperty([])
    output_weights = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        self.bp_algorithm = ObservableBpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
            hidden_neurons=self.hidden_neurons_count
        )
        self.bp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        if self.bp_algorithm:
            self.bp_algorithm.stop()

    @property
    def _most_correct_rate(self):
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableBpAlgorithm(Observable, BpAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            # 更新权重信息
            weights_info = self.current_synaptic_weights
            self.notify('hidden_weights', weights_info['hidden_weights'])
            self.notify('output_weights', weights_info['output_weights'])
            self.notify('current_loss', self.current_loss)
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        self.notify('current_loss', 0)
        super().run()

        # 训练完成后更新最终权重
        weights_info = self.current_synaptic_weights
        self.notify('hidden_weights', weights_info['hidden_weights'])
        self.notify('output_weights', weights_info['output_weights'])
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 防止GUI阻塞
        time.sleep(self.ui_refresh_interval)