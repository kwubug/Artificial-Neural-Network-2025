import matplotlib
matplotlib.use('TkAgg')

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# ---------- 新增：设置中文字体 ----------
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  


# ----------------------------------------

# 玻尔兹曼机类
class BoltzmannMachine:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons

        self.weights = np.random.randn(num_neurons, num_neurons) * 0.1
        self.weights = (self.weights + self.weights.T) / 2
        np.fill_diagonal(self.weights, 0)

        self.biases = np.random.randn(num_neurons) * 0.1

        self.states = np.random.randint(0, 2, num_neurons)

    def energy(self):
        """计算系统总能量"""
        energy = -0.5 * np.dot(np.dot(self.states, self.weights), self.states)
        energy -= np.dot(self.biases, self.states)
        return energy

    def update_state(self, temperature):
        """更新神经元状态（Metropolis算法）"""

        neuron = np.random.randint(0, self.num_neurons)

        old_state = self.states[neuron]
        new_state = 1 - old_state

        delta_E = (new_state - old_state) * (
                np.dot(self.weights[neuron], self.states) + self.biases[neuron]
        )

        if delta_E < 0 or np.random.rand() < np.exp(-delta_E / temperature):
            self.states[neuron] = new_state
            return True
        return False


bm = BoltzmannMachine(3)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

scatter = ax1.scatter(
    range(bm.num_neurons),
    bm.states,
    s=500,
    c=bm.states,
    cmap='coolwarm',
    edgecolors='black'
)
ax1.set_xlim(-1, 3)
ax1.set_ylim(-0.5, 1.5)
ax1.set_xticks(range(bm.num_neurons))
ax1.set_xticklabels([f'神经元{i + 1}' for i in range(bm.num_neurons)])
ax1.set_yticks([0, 1])
ax1.set_yticklabels(['抑制', '激活'])
ax1.set_title('神经元状态')
ax1.grid(True)

energy_history = []
line, = ax2.plot([], [], 'b-', linewidth=2)
ax2.set_xlabel('迭代次数')
ax2.set_ylabel('系统能量')
ax2.set_title('系统能量变化')
ax2.grid(True)


def update(frame):
    temperature = max(0.1, 2.0 / (1 + frame * 0.01))

    bm.update_state(temperature)

    scatter.set_offsets(np.c_[range(bm.num_neurons), bm.states])
    scatter.set_array(bm.states)
    energy = bm.energy()
    energy_history.append(energy)
    line.set_data(range(len(energy_history)), energy_history)
    ax2.set_xlim(0, len(energy_history))
    ax2.set_ylim(min(energy_history) - 1, max(energy_history) + 1)

    ax1.set_title(f'神经元状态（温度：{temperature:.2f}）')
    ax2.set_title(f'系统能量变化（当前能量：{energy:.2f}）')

    return scatter, line
ani = FuncAnimation(
    fig,
    update,
    frames=1000,
    interval=50,
    blit=True
)

plt.suptitle('玻尔兹曼机（3个神经元）运行过程可视化', fontsize=16)
plt.tight_layout()
plt.show()

print("最终神经元状态：", bm.states)
print("最终系统能量：", bm.energy())