from PyQt5.QtCore import pyqtSlot
from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.gradient_descent_algorithm import ObservableNewtonAlgorithm


class NewtonBridge(Bridge):
    """
    牛顿法的Bridge类
    连接算法和QML界面
    """
    
    # 定义Bridge属性
    current_iteration = BridgeProperty(0)
    current_point = BridgeProperty([0.0, 0.0])
    current_value = BridgeProperty(0.0)
    best_point = BridgeProperty([0.0, 0.0])
    best_value = BridgeProperty(0.0)
    statistics = BridgeProperty({})
    is_running = BridgeProperty(False)
    
    def __init__(self):
        super().__init__()
        self.algorithm = None
        
    @pyqtSlot(float, float, float, int, float, str)
    def start(self, initial_x, initial_y, learning_rate, max_iterations, tolerance, function_type):
        """启动牛顿法"""
        if self.algorithm and self.algorithm.is_alive():
            self.algorithm.stop()
            self.algorithm.join()
            
        self.algorithm = ObservableNewtonAlgorithm(
            observer=self,
            initial_point=[initial_x, initial_y],
            learning_rate=learning_rate,
            max_iterations=max_iterations,
            tolerance=tolerance,
            function_type=function_type
        )
        self.is_running = True
        
        # 立即发送初始统计信息
        self.statistics = self.algorithm.get_statistics()
        
        self.algorithm.start()
        
        # 创建一个线程来监控算法是否完成
        import threading
        def check_completion():
            if self.algorithm:
                self.algorithm.join()
                self.is_running = False
        threading.Thread(target=check_completion, daemon=True).start()
        
    @pyqtSlot()
    def stop(self):
        """停止算法"""
        if self.algorithm:
            self.algorithm.stop()
            self.algorithm.join()
        self.is_running = False

