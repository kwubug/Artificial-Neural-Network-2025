import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm

# 定义目标函数 f(x) = x1^2 + x2^2
def f(x):
    return np.sum(x ** 2)

# 定义目标函数的梯度
def grad_f(x):
    return 2 * x

# 最速下降法
def steepest_descent(start, lr=0.1, max_iter=20, save_step=2):
    x = start
    path = [x.copy()]

    for i in range(max_iter):
        grad = grad_f(x)
        x = x - lr * grad
        path.append(x.copy())

        # 每 save_step 步保存一次图像
        if i % save_step == 0:
            plot_steepest_descent(np.array(path), i)

    return np.array(path)

# 绘制最速下降法优化路径
def plot_steepest_descent(path, step):
    x_vals = np.linspace(-6, 6, 100)
    y_vals = np.linspace(-6, 6, 100)

    X, Y = np.meshgrid(x_vals, y_vals)
    Z = X ** 2 + Y ** 2

    plt.contour(X, Y, Z, 50, cmap=cm.coolwarm)
    plt.colorbar()
    plt.plot(path[:, 0], path[:, 1], marker='o', label="Steepest Descent", color='red')
    plt.title(f'Steepest Descent Optimization Path - Step {step}')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True)
    plt.legend()
    plt.show()

# 初始化起始点
start_point = np.array([5, 5])

# 获取路径
path_sd = steepest_descent(start_point)
