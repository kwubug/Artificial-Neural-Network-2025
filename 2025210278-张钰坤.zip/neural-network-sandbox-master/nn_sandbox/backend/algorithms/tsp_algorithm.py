import numpy as np
from .base_algorithm import BaseAlgorithm
import copy


class TspAlgorithm(BaseAlgorithm):
    def __init__(self):
        super().__init__()
        self.reset()

    def reset(self, cities=None, population_size=100, mutation_rate=0.01,
              crossover_rate=0.8, max_iterations=1000):
        self.cities = np.array(cities, dtype=float) if cities is not None else None
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.max_iterations = max_iterations
        self.population = []
        self.best_route = None
        self.best_distance = float('inf')
        self.current_iteration = 0
        if self.cities is not None:
            self._initialize_population()
    
    def _initialize_population(self):
        # 创建随机种群
        num_cities = len(self.cities)
        for _ in range(self.population_size):
            route = np.random.permutation(num_cities)
            self.population.append(route)

    def step(self):
        if self.cities is None:
            raise RuntimeError('TSP algorithm has not been configured with cities.')
        if not self.population:
            self._initialize_population()

        fitness = self._calculate_fitness()
        selected = self._selection(fitness)
        new_population = self._crossover(selected)
        self.population = self._mutation(new_population)
        self._update_best_route()
        self.current_iteration += 1
        return self.current_iteration < self.max_iterations

    def run(self, train_data=None, train_labels=None, test_data=None, test_labels=None):
        while self.step():
            pass
        return self.best_route, self.best_distance
    
    def _calculate_distance(self, route):
        # 计算路径总距离
        distance = 0
        for i in range(len(route)):
            city_a = self.cities[route[i]]
            city_b = self.cities[route[(i+1) % len(route)]]
            distance += np.sqrt(np.sum((city_a - city_b) ** 2))
        return distance
    
    def _calculate_fitness(self):
        # 计算适应度（距离的倒数）
        fitness = []
        for route in self.population:
            distance = self._calculate_distance(route)
            fitness.append(1 / distance)
        return np.array(fitness)
    
    def _selection(self, fitness):
        # 轮盘赌选择
        probabilities = fitness / np.sum(fitness)
        selected_indices = np.random.choice(range(self.population_size), 
                                           size=self.population_size, 
                                           p=probabilities)
        return [self.population[i] for i in selected_indices]
    
    def _crossover(self, selected):
        # 顺序交叉
        new_population = []
        for i in range(0, self.population_size, 2):
            if np.random.random() < self.crossover_rate and i+1 < self.population_size:
                parent1, parent2 = selected[i], selected[i+1]
                child1, child2 = self._order_crossover(parent1, parent2)
                new_population.extend([child1, child2])
            else:
                new_population.extend([selected[i], selected[i+1] if i+1 < self.population_size else selected[0]])
        return new_population
    
    def _order_crossover(self, parent1, parent2):
        # 顺序交叉实现
        size = len(parent1)
        start, end = sorted(np.random.choice(range(size), 2, replace=False))
        
        child1 = np.full(size, -1)
        child2 = np.full(size, -1)
        
        # 复制父本的基因片段
        child1[start:end+1] = parent1[start:end+1]
        child2[start:end+1] = parent2[start:end+1]
        
        # 填充剩余位置
        self._fill_remaining(child1, parent2, start, end)
        self._fill_remaining(child2, parent1, start, end)
        
        return child1, child2
    
    def _fill_remaining(self, child, parent, start, end):
        # 填充交叉后的剩余基因
        size = len(child)
        current_pos = (end + 1) % size
        parent_pos = (end + 1) % size
        
        while -1 in child:
            if parent[parent_pos] not in child:
                child[current_pos] = parent[parent_pos]
                current_pos = (current_pos + 1) % size
            parent_pos = (parent_pos + 1) % size
    
    def _mutation(self, population):
        # 交换变异
        for i in range(len(population)):
            if np.random.random() < self.mutation_rate:
                route = population[i]
                idx1, idx2 = np.random.choice(range(len(route)), 2, replace=False)
                route[idx1], route[idx2] = route[idx2], route[idx1]
        return population
    
    def _update_best_route(self):
        # 更新最佳路径
        for route in self.population:
            distance = self._calculate_distance(route)
            if distance < self.best_distance:
                self.best_distance = distance
                self.best_route = copy.deepcopy(route)
    
    @property
    def current_route(self):
        # 返回当前种群中的最佳路径，用于可视化
        if not self.population:
            return None
        
        current_best = None
        current_best_distance = float('inf')
        
        for route in self.population:
            distance = self._calculate_distance(route)
            if distance < current_best_distance:
                current_best_distance = distance
                current_best = route
        
        return current_best