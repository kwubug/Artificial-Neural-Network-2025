import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'BoltzmannMachine'

    property bool bridgeReady: typeof bmBridge !== 'undefined' && bmBridge !== null

    RowLayout {
        anchors.fill: parent
        spacing: 10
        
        // 左侧控制面板
        ColumnLayout {
            Layout.preferredWidth: 400
            Layout.fillHeight: true
            spacing: 10
            
            GroupBox {
                title: '神经元状态可视化'
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                
                label: Label {
                    text: '神经元状态可视化'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                Item {
                    anchors.fill: parent
                    
                    Row {
                        anchors.centerIn: parent
                        spacing: 30
                        
                        Repeater {
                            model: 3
                            
                            Column {
                                spacing: 10
                                
                                Rectangle {
                                    width: 80
                                    height: 80
                                    radius: 40
                                    color: {
                                        if (!bridgeReady || !bmBridge.current_state)
                                            return "lightgray"
                                        return bmBridge.current_state[index] === 1 ? "#4CAF50" : "#F44336"
                                    }
                                    border.color: "black"
                                    border.width: 3
                                    
                                    Label {
                                        anchors.centerIn: parent
                                        text: bridgeReady && bmBridge.current_state ? 
                                              bmBridge.current_state[index] : "0"
                                        font.pixelSize: 32
                                        font.bold: true
                                        color: "white"
                                    }
                                    
                                    Behavior on color {
                                        ColorAnimation { duration: 200 }
                                    }
                                }
                                
                                Label {
                                    text: "神经元 " + (index + 1)
                                    font.bold: true
                                    font.pixelSize: 16
                                    anchors.horizontalCenter: parent.horizontalCenter
                                }
                            }
                        }
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                
                label: Label {
                    text: '参数设置'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 8
                    columnSpacing: 10
                    
                    Label { 
                        text: '温度 T'
                        font.pixelSize: 16
                    }
                    DoubleSpinBox {
                        enabled: bridgeReady ? bmBridge.has_finished : false
                        value: 1.0 * 100
                        from: 0.1 * 100
                        to: 10.0 * 100
                        onValueChanged: { if (bridgeReady) bmBridge.set_temperature(value / 100) }
                        Layout.fillWidth: true
                        font.pixelSize: 14
                    }
                    
                    Label { 
                        text: '最大迭代次数'
                        font.pixelSize: 16
                    }
                    SpinBox {
                        enabled: bridgeReady ? bmBridge.has_finished : false
                        value: 1000
                        from: 100
                        to: 10000
                        stepSize: 100
                        onValueChanged: { if (bridgeReady) bmBridge.set_max_iterations(value) }
                        Layout.fillWidth: true
                        font.pixelSize: 14
                    }
                    
                    Label { 
                        text: 'UI刷新间隔'
                        font.pixelSize: 16
                    }
                    DoubleSpinBox {
                        enabled: bridgeReady ? bmBridge.has_finished : false
                        value: 0.05 * 100
                        from: 0
                        to: 100
                        onValueChanged: { if (bridgeReady) bmBridge.ui_refresh_interval = value / 100 }
                        Layout.fillWidth: true
                        font.pixelSize: 14
                    }
                    
                    Button {
                        text: '开始模拟'
                        font.pixelSize: 16
                        enabled: bridgeReady ? bmBridge.has_finished : false
                        onClicked: { 
                            console.log("开始BM模拟")
                            if (bridgeReady) bmBridge.start_simulation() 
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 40
                    }
                    
                    Button {
                        text: '计算理论分布'
                        font.pixelSize: 16
                        enabled: bridgeReady ? bmBridge.has_finished : false
                        onClicked: { 
                            if (bridgeReady) bmBridge.calculate_theoretical_distribution()
                        }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 40
                    }
                    
                    Button {
                        text: '停止'
                        font.pixelSize: 16
                        enabled: bridgeReady ? !bmBridge.has_finished : false
                        onClicked: { if (bridgeReady) bmBridge.stop_algorithm() }
                        Layout.fillWidth: true
                        Layout.columnSpan: 2
                        Layout.preferredHeight: 40
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                
                label: Label {
                    text: '网络信息'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 8
                    
                    Label { 
                        text: '当前迭代'
                        font.pixelSize: 16
                    }
                    Label { 
                        text: bridgeReady ? bmBridge.current_iterations : '0'
                        font.bold: true
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Label { 
                        text: '当前能量'
                        font.pixelSize: 16
                    }
                    Label { 
                        text: bridgeReady ? bmBridge.current_energy.toFixed(4) : '0.0000'
                        font.bold: true
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Label { 
                        text: '是否平衡'
                        font.pixelSize: 16
                    }
                    Label { 
                        text: bridgeReady ? (bmBridge.is_equilibrium ? '是' : '否') : '否'
                        color: bridgeReady && bmBridge.is_equilibrium ? 'green' : 'red'
                        font.bold: true
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Label { 
                        text: '当前状态'
                        font.pixelSize: 16
                    }
                    Label { 
                        text: bridgeReady && bmBridge.current_state ? 
                              "[" + bmBridge.current_state.join(", ") + "]" : "[0, 0, 0]"
                        font.bold: true
                        font.pixelSize: 16
                        font.family: "Courier New"
                        Layout.fillWidth: true
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                label: Label {
                    text: '权重矩阵'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                GridLayout {
                    anchors.fill: parent
                    columns: 4
                    rowSpacing: 8
                    columnSpacing: 12
                    
                    Label { text: ""; font.pixelSize: 16 }
                    Label { 
                        text: "N1"
                        font.bold: true
                        font.pixelSize: 16
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: "N2"
                        font.bold: true
                        font.pixelSize: 16
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: "N3"
                        font.bold: true
                        font.pixelSize: 16
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    
                    Label { text: "N1"; font.bold: true; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[0][0].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[0][1].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[0][2].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Label { text: "N2"; font.bold: true; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[1][0].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[1][1].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[1][2].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Label { text: "N3"; font.bold: true; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[2][0].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[2][1].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    Label { 
                        text: bridgeReady && bmBridge.weights ? bmBridge.weights[2][2].toFixed(2) : "0.00"
                        horizontalAlignment: Text.AlignHCenter
                        font.pixelSize: 16
                        Layout.fillWidth: true
                    }
                    
                    Item { Layout.columnSpan: 4; Layout.fillHeight: true }
                    
                    Label { 
                        text: "偏置:"
                        font.bold: true
                        font.pixelSize: 16
                        Layout.columnSpan: 4
                    }
                    Label { text: "b1:"; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.bias ? bmBridge.bias[0].toFixed(2) : "0.00"
                        font.pixelSize: 16
                        Layout.columnSpan: 3
                    }
                    Label { text: "b2:"; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.bias ? bmBridge.bias[1].toFixed(2) : "0.00"
                        font.pixelSize: 16
                        Layout.columnSpan: 3
                    }
                    Label { text: "b3:"; font.pixelSize: 16 }
                    Label { 
                        text: bridgeReady && bmBridge.bias ? bmBridge.bias[2].toFixed(2) : "0.00"
                        font.pixelSize: 16
                        Layout.columnSpan: 3
                    }
                }
            }
        }
        
        // 右侧显示区域
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 10
            
            GroupBox {
                Layout.fillWidth: true
                Layout.preferredHeight: 400
                Layout.minimumHeight: 350
                
                label: Label {
                    text: '能量变化曲线'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                ChartView {
                    id: energyChart
                    anchors.fill: parent
                    antialiasing: true
                    legend.visible: true
                    legend.alignment: Qt.AlignBottom
                    legend.font.pixelSize: 15
                    
                    ValueAxis {
                        id: xAxis
                        titleText: "迭代次数"
                        titleFont.pixelSize: 15
                        labelsFont.pixelSize: 14
                        min: 0
                        max: 1000
                    }
                    
                    ValueAxis {
                        id: yAxis
                        titleText: "能量"
                        titleFont.pixelSize: 15
                        labelsFont.pixelSize: 14
                        min: -5
                        max: 0
                    }
                    
                    LineSeries {
                        id: energySeries
                        name: "系统能量"
                        axisX: xAxis
                        axisY: yAxis
                        useOpenGL: true
                        color: "#2196F3"
                        width: 2
                    }
                }
            }

            GroupBox {
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                label: Label {
                    text: '热平衡状态分布对比'
                    font.pixelSize: 18
                    font.bold: true
                }
                
                RowLayout {
                    anchors.fill: parent
                    spacing: 10
                    
                    // 实际分布
                    GroupBox {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        
                        label: Label {
                            text: '实际分布（采样）'
                            font.pixelSize: 16
                            font.bold: true
                        }
                        
                        ScrollView {
                            anchors.fill: parent
                            clip: true
                            
                            ColumnLayout {
                                width: parent.width
                                spacing: 8
                                
                                Repeater {
                                    model: bridgeReady && bmBridge.equilibrium_distribution ? 
                                           Object.keys(bmBridge.equilibrium_distribution).sort() : []
                                    
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 15
                                        
                                        Label {
                                            text: modelData
                                            font.family: "Courier New"
                                            font.pixelSize: 18
                                            font.bold: true
                                            Layout.preferredWidth: 100
                                        }
                                        
                                        Rectangle {
                                            height: 28
                                            width: {
                                                if (!bridgeReady || !bmBridge.equilibrium_distribution)
                                                    return 0
                                                var prob = bmBridge.equilibrium_distribution[modelData]
                                                return Math.max(3, prob * 250)
                                            }
                                            color: "#4CAF50"
                                        }
                                        
                                        Label {
                                            text: {
                                                if (!bridgeReady || !bmBridge.equilibrium_distribution)
                                                    return "0.000"
                                                return bmBridge.equilibrium_distribution[modelData].toFixed(3)
                                            }
                                            font.bold: true
                                            font.pixelSize: 18
                                            Layout.preferredWidth: 70
                                        }
                                        
                                        Item { Layout.fillWidth: true }
                                    }
                                }
                            }
                        }
                    }
                    
                    // 理论分布
                    GroupBox {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        
                        label: Label {
                            text: '理论分布（Boltzmann）'
                            font.pixelSize: 16
                            font.bold: true
                        }
                        
                        ScrollView {
                            anchors.fill: parent
                            clip: true
                            
                            ColumnLayout {
                                width: parent.width
                                spacing: 8
                                
                                Repeater {
                                    model: bridgeReady && bmBridge.theoretical_distribution ? 
                                           Object.keys(bmBridge.theoretical_distribution).sort() : []
                                    
                                    RowLayout {
                                        Layout.fillWidth: true
                                        spacing: 15
                                        
                                        Label {
                                            text: modelData
                                            font.family: "Courier New"
                                            font.pixelSize: 18
                                            font.bold: true
                                            Layout.preferredWidth: 100
                                        }
                                        
                                        Rectangle {
                                            height: 28
                                            width: {
                                                if (!bridgeReady || !bmBridge.theoretical_distribution)
                                                    return 0
                                                var prob = bmBridge.theoretical_distribution[modelData]
                                                return Math.max(3, prob * 250)
                                            }
                                            color: "#2196F3"
                                        }
                                        
                                        Label {
                                            text: {
                                                if (!bridgeReady || !bmBridge.theoretical_distribution)
                                                    return "0.000"
                                                return bmBridge.theoretical_distribution[modelData].toFixed(3)
                                            }
                                            font.bold: true
                                            font.pixelSize: 18
                                            Layout.preferredWidth: 70
                                        }
                                        
                                        Item { Layout.fillWidth: true }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Connections {
        target: bridgeReady ? bmBridge : null
        enabled: bridgeReady
        
        function onEnergy_historyChanged() {
            if (!bridgeReady || !bmBridge.energy_history)
                return
            
            energySeries.clear()
            var history = bmBridge.energy_history
            
            if (history.length === 0)
                return
            
            var minE = Math.min.apply(null, history)
            var maxE = Math.max.apply(null, history)
            yAxis.min = minE - 0.5
            yAxis.max = maxE + 0.5
            xAxis.max = Math.max(1000, history.length)
            
            for (var i = 0; i < history.length; i++) {
                energySeries.append(i, history[i])
            }
        }
    }
    
    Component.onCompleted: {
        console.log("BM 页面加载完成")
        console.log("Bridge 就绪:", bridgeReady)
    }
}