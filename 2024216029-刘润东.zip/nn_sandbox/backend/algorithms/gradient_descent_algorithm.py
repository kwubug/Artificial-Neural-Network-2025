import numpy as np
import threading
import time


class GradientDescentBase(threading.Thread):
    """
    梯度下降算法基类
    优化目标函数: f(x, y) = (x-1)² + (y-1)²
    最小点在 (1, 1)，最小值为 0
    """
    
    def __init__(self, initial_point=None, learning_rate=0.1, max_iterations=100, 
                 tolerance=1e-6, function_type='quadratic'):
        super().__init__()
        self.initial_point = np.array(initial_point) if initial_point is not None else np.array([5.0, 5.0])
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.function_type = function_type
        self._should_stop = False
        
        # 当前状态
        self.current_point = self.initial_point.copy()
        self.current_iteration = 0
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        
        # 历史记录
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        
    def _objective_function(self, point):
        """目标函数: f(x, y) = (x-1)² + (y-1)²"""
        if self.function_type == 'quadratic':
            return np.sum((point - 1.0) ** 2)
        elif self.function_type == 'rosenbrock':
            # Rosenbrock函数: f(x,y) = (1-x)² + 100(y-x²)²
            x, y = point[0], point[1]
            return (1 - x) ** 2 + 100 * (y - x ** 2) ** 2
        else:
            return np.sum((point - 1.0) ** 2)
    
    def _gradient(self, point):
        """计算梯度"""
        if self.function_type == 'quadratic':
            return 2 * (point - 1.0)
        elif self.function_type == 'rosenbrock':
            x, y = point[0], point[1]
            dx = -2 * (1 - x) - 400 * x * (y - x ** 2)
            dy = 200 * (y - x ** 2)
            return np.array([dx, dy])
        else:
            return 2 * (point - 1.0)
    
    def _hessian(self, point):
        """计算Hessian矩阵（用于牛顿法）"""
        if self.function_type == 'quadratic':
            return 2 * np.eye(len(point))
        elif self.function_type == 'rosenbrock':
            x, y = point[0], point[1]
            h11 = 2 - 400 * (y - x ** 2) + 800 * x ** 2
            h12 = -400 * x
            h21 = -400 * x
            h22 = 200
            return np.array([[h11, h12], [h21, h22]])
        else:
            return 2 * np.eye(len(point))
    
    def stop(self):
        """停止算法运行"""
        self._should_stop = True
    
    def get_statistics(self):
        """返回统计信息"""
        return {
            'current_point': self.current_point.tolist(),
            'current_value': float(self.current_value),
            'best_point': self.best_point.tolist(),
            'best_value': float(self.best_value),
            'point_history': [p.tolist() for p in self.point_history],
            'value_history': [float(v) for v in self.value_history]
        }


class SteepestDescentAlgorithm(GradientDescentBase):
    """
    最速下降法（梯度下降法）
    x_{k+1} = x_k - α * ∇f(x_k)
    """
    
    def run(self):
        """运行最速下降算法"""
        self.current_point = self.initial_point.copy()
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 计算梯度
            grad = self._gradient(self.current_point)
            
            # 更新点
            self.current_point = self.current_point - self.learning_rate * grad
            
            # 计算新的函数值
            self.current_value = self._objective_function(self.current_point)
            
            # 更新最佳值
            if self.current_value < self.best_value:
                self.best_value = self.current_value
                self.best_point = self.current_point.copy()
            
            # 记录历史
            self.point_history.append(self.current_point.copy())
            self.value_history.append(self.current_value)
            
            # 检查收敛
            if np.linalg.norm(grad) < self.tolerance:
                break
            
            time.sleep(0.05)


class NewtonAlgorithm(GradientDescentBase):
    """
    牛顿法
    x_{k+1} = x_k - H^{-1}(x_k) * ∇f(x_k)
    其中H是Hessian矩阵
    """
    
    def run(self):
        """运行牛顿法"""
        self.current_point = self.initial_point.copy()
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 计算梯度和Hessian矩阵
            grad = self._gradient(self.current_point)
            hessian = self._hessian(self.current_point)
            
            # 计算Hessian的逆矩阵
            try:
                hessian_inv = np.linalg.inv(hessian)
            except np.linalg.LinAlgError:
                # 如果Hessian不可逆，使用伪逆
                hessian_inv = np.linalg.pinv(hessian)
            
            # 更新点
            self.current_point = self.current_point - hessian_inv @ grad
            
            # 计算新的函数值
            self.current_value = self._objective_function(self.current_point)
            
            # 更新最佳值
            if self.current_value < self.best_value:
                self.best_value = self.current_value
                self.best_point = self.current_point.copy()
            
            # 记录历史
            self.point_history.append(self.current_point.copy())
            self.value_history.append(self.current_value)
            
            # 检查收敛
            if np.linalg.norm(grad) < self.tolerance:
                break
            
            time.sleep(0.05)


class ConjugateGradientAlgorithm(GradientDescentBase):
    """
    共轭梯度法
    使用共轭方向进行优化
    """
    
    def run(self):
        """运行共轭梯度法"""
        self.current_point = self.initial_point.copy()
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        
        # 初始梯度
        grad = self._gradient(self.current_point)
        direction = -grad  # 初始搜索方向
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 线搜索（使用固定步长或Armijo条件）
            alpha = self._line_search(self.current_point, direction)
            
            # 更新点
            new_point = self.current_point + alpha * direction
            new_value = self._objective_function(new_point)
            
            # 计算新梯度
            new_grad = self._gradient(new_point)
            
            # 计算共轭方向（Polak-Ribiere公式）
            beta = np.dot(new_grad, new_grad - grad) / (np.dot(grad, grad) + 1e-10)
            beta = max(0, beta)  # 确保下降方向
            
            # 更新搜索方向
            direction = -new_grad + beta * direction
            
            # 更新当前点
            self.current_point = new_point
            self.current_value = new_value
            grad = new_grad
            
            # 更新最佳值
            if self.current_value < self.best_value:
                self.best_value = self.current_value
                self.best_point = self.current_point.copy()
            
            # 记录历史
            self.point_history.append(self.current_point.copy())
            self.value_history.append(self.current_value)
            
            # 检查收敛
            if np.linalg.norm(grad) < self.tolerance:
                break
            
            time.sleep(0.05)
    
    def _line_search(self, point, direction):
        """简单的线搜索（使用固定步长）"""
        # 可以改进为使用Armijo条件或Wolfe条件
        return self.learning_rate


class ObservableSteepestDescentAlgorithm(SteepestDescentAlgorithm):
    """Observable版本的最速下降算法"""
    
    def __init__(self, observer, **kwargs):
        SteepestDescentAlgorithm.__init__(self, **kwargs)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            try:
                self._observer.update(name, value)
            except Exception as e:
                print(f"Error notifying {name}: {e}")
                import traceback
                traceback.print_exc()
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_point', 'current_value', 
                   'best_point', 'best_value']:
            if hasattr(self, '_observer'):
                # 将numpy数组转换为Python列表
                if name in ['current_point', 'best_point']:
                    if hasattr(value, 'tolist'):
                        value = [float(x) for x in value.tolist()]
                    elif isinstance(value, np.ndarray):
                        value = [float(x) for x in value]
                elif name in ['current_value', 'best_value']:
                    if isinstance(value, (np.integer, np.floating)):
                        value = float(value)
                elif name == 'current_iteration':
                    if isinstance(value, np.integer):
                        value = int(value)
                self.notify(name, value)
    
    def run(self):
        """重写run方法以添加通知"""
        try:
            print("Algorithm run() started")
            # 初始化状态
            self.current_point = self.initial_point.copy()
            self.current_value = self._objective_function(self.current_point)
            self.best_point = self.current_point.copy()
            self.best_value = self.current_value
            self.point_history = [self.current_point.copy()]
            self.value_history = [self.current_value]
            self.current_iteration = 0
            
            print(f"Initial state: point={self.current_point}, value={self.current_value}")
            
            # 通知初始状态（确保转换为Python原生类型）
            self.notify('current_iteration', int(self.current_iteration))
            self.notify('current_point', [float(x) for x in self.current_point.tolist()])
            self.notify('current_value', float(self.current_value))
            self.notify('best_point', [float(x) for x in self.best_point.tolist()])
            self.notify('best_value', float(self.best_value))
            self.notify('statistics', self.get_statistics())
            
            print("Starting iterations...")
            for self.current_iteration in range(1, self.max_iterations + 1):
                if self._should_stop:
                    print("Algorithm stopped by user")
                    break
                
                # 计算梯度
                grad = self._gradient(self.current_point)
                
                # 更新点
                self.current_point = self.current_point - self.learning_rate * grad
                
                # 计算新的函数值
                self.current_value = self._objective_function(self.current_point)
                
                # 更新最佳值
                if self.current_value < self.best_value:
                    self.best_value = self.current_value
                    self.best_point = self.current_point.copy()
                
                # 记录历史
                self.point_history.append(self.current_point.copy())
                self.value_history.append(self.current_value)
                
                # 通知观察者（每次迭代都通知，确保转换为Python原生类型）
                self.notify('current_iteration', int(self.current_iteration))
                self.notify('current_point', [float(x) for x in self.current_point.tolist()])
                self.notify('current_value', float(self.current_value))
                self.notify('best_point', [float(x) for x in self.best_point.tolist()])
                self.notify('best_value', float(self.best_value))
                self.notify('statistics', self.get_statistics())
                
                # 检查收敛
                if np.linalg.norm(grad) < self.tolerance:
                    print(f"Algorithm converged at iteration {self.current_iteration}")
                    break
                
                time.sleep(0.05)
            
            # 最终通知（确保转换为Python原生类型）
            print(f"Algorithm completed. Final iteration: {self.current_iteration}, value: {self.current_value}")
            self.notify('current_iteration', int(self.current_iteration))
            self.notify('current_point', [float(x) for x in self.current_point.tolist()])
            self.notify('current_value', float(self.current_value))
            self.notify('best_point', [float(x) for x in self.best_point.tolist()])
            self.notify('best_value', float(self.best_value))
            self.notify('statistics', self.get_statistics())
        except Exception as e:
            print(f"Error in algorithm run(): {e}")
            import traceback
            traceback.print_exc()


class ObservableNewtonAlgorithm(NewtonAlgorithm):
    """Observable版本的牛顿法"""
    
    def __init__(self, observer, **kwargs):
        NewtonAlgorithm.__init__(self, **kwargs)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            try:
                self._observer.update(name, value)
            except Exception as e:
                print(f"Error notifying {name}: {e}")
                import traceback
                traceback.print_exc()
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_point', 'current_value', 
                   'best_point', 'best_value']:
            if hasattr(self, '_observer'):
                # 将numpy数组转换为Python列表
                if name in ['current_point', 'best_point']:
                    if hasattr(value, 'tolist'):
                        value = [float(x) for x in value.tolist()]
                    elif isinstance(value, np.ndarray):
                        value = [float(x) for x in value]
                elif name in ['current_value', 'best_value']:
                    if isinstance(value, (np.integer, np.floating)):
                        value = float(value)
                elif name == 'current_iteration':
                    if isinstance(value, np.integer):
                        value = int(value)
                self.notify(name, value)
    
    def run(self):
        """重写run方法以添加通知"""
        # 初始化状态
        self.current_point = self.initial_point.copy()
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        self.current_iteration = 0
        
        # 通知初始状态（确保转换为Python原生类型）
        self.notify('current_iteration', int(self.current_iteration))
        self.notify('current_point', [float(x) for x in self.current_point.tolist()])
        self.notify('current_value', float(self.current_value))
        self.notify('best_point', [float(x) for x in self.best_point.tolist()])
        self.notify('best_value', float(self.best_value))
        self.notify('statistics', self.get_statistics())
        
        for self.current_iteration in range(1, self.max_iterations + 1):
            if self._should_stop:
                break
            
            # 计算梯度和Hessian矩阵
            grad = self._gradient(self.current_point)
            hessian = self._hessian(self.current_point)
            
            # 计算Hessian的逆矩阵
            try:
                hessian_inv = np.linalg.inv(hessian)
            except np.linalg.LinAlgError:
                # 如果Hessian不可逆，使用伪逆
                hessian_inv = np.linalg.pinv(hessian)
            
            # 更新点
            self.current_point = self.current_point - hessian_inv @ grad
            
            # 计算新的函数值
            self.current_value = self._objective_function(self.current_point)
            
            # 更新最佳值
            if self.current_value < self.best_value:
                self.best_value = self.current_value
                self.best_point = self.current_point.copy()
            
            # 记录历史
            self.point_history.append(self.current_point.copy())
            self.value_history.append(self.current_value)
            
            # 通知观察者（每次迭代都通知，确保转换为Python原生类型）
            self.notify('current_iteration', int(self.current_iteration))
            self.notify('current_point', [float(x) for x in self.current_point.tolist()])
            self.notify('current_value', float(self.current_value))
            self.notify('best_point', [float(x) for x in self.best_point.tolist()])
            self.notify('best_value', float(self.best_value))
            self.notify('statistics', self.get_statistics())
            
            # 检查收敛
            if np.linalg.norm(grad) < self.tolerance:
                break
            
            time.sleep(0.05)
        
        # 最终通知（确保转换为Python原生类型）
        self.notify('current_iteration', int(self.current_iteration))
        self.notify('current_point', [float(x) for x in self.current_point.tolist()])
        self.notify('current_value', float(self.current_value))
        self.notify('best_point', [float(x) for x in self.best_point.tolist()])
        self.notify('best_value', float(self.best_value))
        self.notify('statistics', self.get_statistics())


class ObservableConjugateGradientAlgorithm(ConjugateGradientAlgorithm):
    """Observable版本的共轭梯度法"""
    
    def __init__(self, observer, **kwargs):
        ConjugateGradientAlgorithm.__init__(self, **kwargs)
        self._observer = observer
    
    def notify(self, name, value):
        """通知观察者"""
        if hasattr(self, '_observer') and self._observer:
            try:
                self._observer.update(name, value)
            except Exception as e:
                print(f"Error notifying {name}: {e}")
                import traceback
                traceback.print_exc()
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ['current_iteration', 'current_point', 'current_value', 
                   'best_point', 'best_value']:
            if hasattr(self, '_observer'):
                # 将numpy数组转换为Python列表
                if name in ['current_point', 'best_point']:
                    if hasattr(value, 'tolist'):
                        value = [float(x) for x in value.tolist()]
                    elif isinstance(value, np.ndarray):
                        value = [float(x) for x in value]
                elif name in ['current_value', 'best_value']:
                    if isinstance(value, (np.integer, np.floating)):
                        value = float(value)
                elif name == 'current_iteration':
                    if isinstance(value, np.integer):
                        value = int(value)
                self.notify(name, value)
    
    def run(self):
        """重写run方法以添加通知"""
        self.notify('statistics', self.get_statistics())
        # 调用父类的run方法，但需要重写迭代逻辑以添加通知
        self.current_point = self.initial_point.copy()
        self.current_value = self._objective_function(self.current_point)
        self.best_point = self.current_point.copy()
        self.best_value = self.current_value
        self.point_history = [self.current_point.copy()]
        self.value_history = [self.current_value]
        
        # 初始梯度
        grad = self._gradient(self.current_point)
        direction = -grad  # 初始搜索方向
        
        for self.current_iteration in range(self.max_iterations):
            if self._should_stop:
                break
            
            # 线搜索（使用固定步长或Armijo条件）
            alpha = self._line_search(self.current_point, direction)
            
            # 更新点
            new_point = self.current_point + alpha * direction
            new_value = self._objective_function(new_point)
            
            # 计算新梯度
            new_grad = self._gradient(new_point)
            
            # 计算共轭方向（Polak-Ribiere公式）
            beta = np.dot(new_grad, new_grad - grad) / (np.dot(grad, grad) + 1e-10)
            beta = max(0, beta)  # 确保下降方向
            
            # 更新搜索方向
            direction = -new_grad + beta * direction
            
            # 更新当前点
            self.current_point = new_point
            self.current_value = new_value
            grad = new_grad
            
            # 更新最佳值
            if self.current_value < self.best_value:
                self.best_value = self.current_value
                self.best_point = self.current_point.copy()
            
            # 记录历史
            self.point_history.append(self.current_point.copy())
            self.value_history.append(self.current_value)
            
            # 通知观察者（每次迭代都通知，确保转换为Python原生类型）
            self.notify('current_iteration', int(self.current_iteration))
            self.notify('current_point', [float(x) for x in self.current_point.tolist()])
            self.notify('current_value', float(self.current_value))
            self.notify('best_point', [float(x) for x in self.best_point.tolist()])
            self.notify('best_value', float(self.best_value))
            self.notify('statistics', self.get_statistics())
            
            # 检查收敛
            if np.linalg.norm(grad) < self.tolerance:
                break
            
            time.sleep(0.05)
        
        # 最终通知（确保转换为Python原生类型）
        self.notify('current_iteration', int(self.current_iteration))
        self.notify('current_point', [float(x) for x in self.current_point.tolist()])
        self.notify('current_value', float(self.current_value))
        self.notify('best_point', [float(x) for x in self.best_point.tolist()])
        self.notify('best_value', float(self.best_value))
        self.notify('statistics', self.get_statistics())

