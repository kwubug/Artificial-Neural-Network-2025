import numpy as np
import matplotlib.pyplot as plt
from enum import Enum

class LearningRule(Enum):
    """学习规则"""
    PERCEPTRON = 1
    DELTA = 2
    LMS = 3
    CORRELATION = 4

class ActivationFunction(Enum):
    """变换函数"""
    SIGN = 1  # 符号函数，用于离散感知器
    SIGMOID = 2 # S型函数，用于连续感知器(Delta规则)
    LINEAR = 3  # 线性函数，用于LMS规则

class SingleNodeNetwork:
    def __init__(self, num_inputs=6, learning_rate=0.1):
        """
        初始化单节点网络
        Args:
            num_inputs: 输入数量，默认为6
            learning_rate: 学习率
        """
        # 权值初始化，增加一个偏置项，所以是 num_inputs + 1
        self.weights = np.random.uniform(-0.5, 0.5, num_inputs + 1)
        self.learning_rate = learning_rate
        self.history = []  # 用于记录训练历史

    def _add_bias(self, X):
        """为输入向量添加偏置项（值为1）"""
        return np.append(X, 1)

    def _activation(self, net, func):
        """计算激活函数输出"""
        if func == ActivationFunction.SIGN:
            return 1 if net >= 0 else -1  # 或者 1/0，根据期望输出定
        elif func == ActivationFunction.SIGMOID:
            return 1 / (1 + np.exp(-net))
        elif func == ActivationFunction.LINEAR:
            return net
        else:
            raise ValueError("不支持的激活函数")

    def _activation_derivative(self, output, func):
        """计算激活函数的导数（用于Delta规则）"""
        if func == ActivationFunction.SIGMOID:
            return output * (1 - output)
        elif func == ActivationFunction.LINEAR:
            return 1
        else:
            # 对于SIGN函数，导数在0处未定义，通常在使用Delta规则时不会用SIGN
            return 1  # 简单处理

    def train(self, X, d, rule, activation_func, epochs=10):
        """
        训练网络
        Args:
            X: 输入数据，形状为 (n_samples, 6) 的数组
            d: 期望输出，形状为 (n_samples,) 的数组
            rule: 学习规则 (LearningRule 枚举)
            activation_func: 激活函数 (ActivationFunction 枚举)
            epochs: 训练轮数
        """
        # 确保输入数据是numpy数组
        X = np.array(X)
        d = np.array(d)

        print(f"开始训练，学习规则: {rule.name}, 激活函数: {activation_func.name}")
        print(f"初始权值: {self.weights}")
        print("-" * 60)

        for epoch in range(epochs):
            total_error = 0
            print(f"第 {epoch + 1} 轮训练:")

            for i in range(len(X)):
                # 准备输入，添加偏置
                x_input = self._add_bias(X[i])
                target = d[i]

                # 前向传播：计算净输入和输出
                net_input = np.dot(self.weights, x_input)
                output = self._activation(net_input, activation_func)

                # 计算误差
                error = target - output
                total_error += error ** 2  # 计算均方误差

                # 记录当前步骤信息
                step_info = {
                    'epoch': epoch,
                    'sample': i,
                    'X': X[i],
                    'd': target,
                    'net': net_input,
                    'output': output,
                    'weights_before': self.weights.copy(),
                    'error': error
                }

                # 根据不同的学习规则调整权值
                delta_weights = np.zeros_like(self.weights)

                if rule == LearningRule.PERCEPTRON:
                    # 离散感知器规则: ΔW = η * (d - sign(net)) * X
                    if output != target:
                        delta_weights = self.learning_rate * error * x_input

                elif rule == LearningRule.DELTA:
                    # Delta规则: ΔW = η * (d - o) * f'(net) * X
                    derivative = self._activation_derivative(output, activation_func)
                    delta_weights = self.learning_rate * error * derivative * x_input

                elif rule == LearningRule.LMS:
                    # LMS规则: ΔW = η * (d - net) * X
                    delta_weights = self.learning_rate * (target - net_input) * x_input

                elif rule == LearningRule.CORRELATION:
                    # 相关规则: ΔW = η * d * X
                    delta_weights = self.learning_rate * target * x_input

                # 更新权值
                self.weights += delta_weights

                # 记录调整量
                step_info['delta_weights'] = delta_weights
                step_info['weights_after'] = self.weights.copy()
                self.history.append(step_info)

                # 打印每一步的详细信息
                print(f"  样本 {i+1}:")
                print(f"    输入: {X[i]}")
                print(f"    净输入: {net_input:.4f}")
                print(f"    实际输出: {output:.4f}")
                print(f"    期望输出: {target}")
                print(f"    误差: {error:.4f}")
                print(f"    权值调整量: {delta_weights}")
                print(f"    更新后权值: {self.weights}")
                print()

            avg_error = total_error / len(X)
            print(f"第 {epoch + 1} 轮平均误差: {avg_error:.4f}")
            print("-" * 60)

    def predict(self, X, activation_func):
        """使用训练好的网络进行预测"""
        X = np.array(X)
        results = []
        for i in range(len(X)):
            x_input = self._add_bias(X[i])
            net_input = np.dot(self.weights, x_input)
            output = self._activation(net_input, activation_func)
            results.append(output)
        return np.array(results)

# 使用和测试
def main():
    # 创建网络实例
    network = SingleNodeNetwork(num_inputs=6, learning_rate=0.1)

    # 示例训练数据 (6个输入，1个输出)
    X_train = np.array([
        [0, 0, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [1, 1, 1, 1, 1, 1]
    ])
    
    # 简单逻辑：当所有输入都是1时输出1，否则输出0
    y_train = np.array([0, 0, 0, 1])

    try:
        # 不同的学习规则和激活函数组合
        print("=" * 60)
        
        # Delta规则 + Sigmoid激活函数
        network1 = SingleNodeNetwork(num_inputs=6, learning_rate=0.5)
        network1.train(X_train, y_train, 
                      LearningRule.DELTA, 
                      ActivationFunction.SIGMOID, 
                      epochs=5)
        
        print("\n" + "=" * 60)
        
        # 感知器规则 + 符号函数
        network2 = SingleNodeNetwork(num_inputs=6, learning_rate=0.1)
        # 对于感知器规则，期望输出需要调整为1/-1
        y_train_perceptron = np.array([-1, -1, -1, 1])
        network2.train(X_train, y_train_perceptron,
                      LearningRule.PERCEPTRON,
                      ActivationFunction.SIGN,
                      epochs=10)

    except Exception as e:
        print(f"训练过程中出现错误: {e}")

if __name__ == "__main__":
    main()