from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QComboBox
from nn_sandbox.bridges.HopfieldVisualizer import HopfieldVisualizer
import sys
0
class HopfieldMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Neural Network Sandbox - Hopfield 可视化")

        # 主容器
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Hopfield 可视化组件
        self.hop_widget = HopfieldVisualizer(n_neurons=16)
        layout.addWidget(self.hop_widget)

        # 异步步数选择下拉框
        self.steps_combo = QComboBox()
        self.steps_combo.addItems([str(i) for i in [10, 20, 50, 100]])
        layout.addWidget(self.steps_combo)

        # 按钮
        self.refresh_btn = QPushButton("🔁 随机生成模式并异步更新")
        self.refresh_btn.clicked.connect(self.on_refresh)
        layout.addWidget(self.refresh_btn)

        # 初次绘制
        self.hop_widget.refresh(n_patterns=2, n_steps=50)

    def on_refresh(self):
        steps = int(self.steps_combo.currentText())
        self.hop_widget.refresh(n_patterns=2, n_steps=steps)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = HopfieldMainWindow()
    win.resize(800, 450)
    win.show()
    sys.exit(app.exec_())
