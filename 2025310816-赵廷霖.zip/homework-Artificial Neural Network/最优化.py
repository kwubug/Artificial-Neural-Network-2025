import numpy as np
import matplotlib.pyplot as plt


def f(x):
    """Rosenbrock函数: f(x) = 100*(x2 - x1^2)^2 + (1 - x1)^2"""
    return 100 * (x[1] - x[0] ** 2) ** 2 + (1 - x[0]) ** 2


def gradient(x):
    """计算梯度"""
    df_dx1 = -400 * x[0] * (x[1] - x[0] ** 2) - 2 * (1 - x[0])
    df_dx2 = 200 * (x[1] - x[0] ** 2)
    return np.array([df_dx1, df_dx2])


def hessian(x):
    """计算Hessian矩阵"""
    d2f_dx1dx1 = 1200 * x[0] ** 2 - 400 * x[1] + 2
    d2f_dx1dx2 = -400 * x[0]
    d2f_dx2dx1 = -400 * x[0]
    d2f_dx2dx2 = 200
    return np.array([[d2f_dx1dx1, d2f_dx1dx2],
                     [d2f_dx2dx1, d2f_dx2dx2]])


def steepest_descent(initial_x, tol=1e-3, max_iter=10000):
    """最速下降法"""
    x = initial_x.copy()
    f_values = [f(x)]
    x_history = [x.copy()]

    for i in range(max_iter):
        g = gradient(x)

        # 检查收敛
        if np.linalg.norm(g) < tol:
            break

        # 精确线搜索 - 通过求解一维优化问题找到最优步长
        def phi(alpha):
            return f(x - alpha * g)

        # 使用黄金分割法进行线搜索
        a, b = 0, 1
        golden_ratio = (np.sqrt(5) - 1) / 2

        for _ in range(50):  # 线搜索迭代
            alpha1 = b - golden_ratio * (b - a)
            alpha2 = a + golden_ratio * (b - a)

            if phi(alpha1) < phi(alpha2):
                b = alpha2
            else:
                a = alpha1

        alpha_opt = (a + b) / 2

        # 更新位置
        x = x - alpha_opt * g
        f_values.append(f(x))
        x_history.append(x.copy())

    return x, f_values, x_history


def newton_method(initial_x, tol=1e-3, max_iter=100):
    """牛顿法"""
    x = initial_x.copy()
    f_values = [f(x)]
    x_history = [x.copy()]

    for i in range(max_iter):
        g = gradient(x)
        H = hessian(x)

        # 检查收敛
        if np.linalg.norm(g) < tol:
            break

        # 求解牛顿方向: H * d = -g
        try:
            d = np.linalg.solve(H, -g)
        except np.linalg.LinAlgError:
            # 如果Hessian矩阵奇异，使用伪逆
            d = -np.linalg.pinv(H) @ g

        # 更新位置
        x = x + d
        f_values.append(f(x))
        x_history.append(x.copy())

    return x, f_values, x_history


def main():
    """主函数 - 避免变量作用域问题"""
    # 初始点
    initial_point = np.array([-1.9, 2.0])
    tolerance = 1e-3

    print("初始点:", initial_point)
    print("初始函数值:", f(initial_point))
    print("初始梯度范数:", np.linalg.norm(gradient(initial_point)))
    print()

    # 运行最速下降法
    print("=== 最速下降法 ===")
    x_sd, f_sd, xhist_sd = steepest_descent(initial_point, tolerance)
    print(f"迭代次数: {len(f_sd) - 1}")
    print(f"最优解: {x_sd}")
    print(f"最优值: {f(x_sd)}")
    print(f"梯度范数: {np.linalg.norm(gradient(x_sd))}")
    print()

    # 运行牛顿法
    print("=== 牛顿法 ===")
    x_nt, f_nt, xhist_nt = newton_method(initial_point, tolerance)
    print(f"迭代次数: {len(f_nt) - 1}")
    print(f"最优解: {x_nt}")
    print(f"最优值: {f(x_nt)}")
    print(f"梯度范数: {np.linalg.norm(gradient(x_nt))}")

    # 绘制收敛曲线
    plt.figure(figsize=(12, 4))

    plt.subplot(1, 2, 1)
    plt.semilogy(f_sd, 'b-', linewidth=2, label='Steepest Descent')
    plt.semilogy(f_nt, 'r-', linewidth=2, label='Newton')
    plt.xlabel('Iteration')
    plt.ylabel('Function Value (log scale)')
    plt.title('Convergence Curve')
    plt.legend()
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(f_sd, 'b-', linewidth=2, label='Steepest Descent')
    plt.plot(f_nt, 'r-', linewidth=2, label='Newton')
    plt.xlabel('Iteration')
    plt.ylabel('Function Value')
    plt.title('Convergence Curve (Linear Scale)')
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    plt.show()

    # 算法比较
    print("\n=== 算法比较 ===")
    print("最速下降法:")
    print(f"  迭代次数: {len(f_sd) - 1}")
    print(f"  最终函数值: {f_sd[-1]:.6e}")
    print(f"  收敛速度: 较慢，呈现锯齿形收敛")

    print("\n牛顿法:")
    print(f"  迭代次数: {len(f_nt) - 1}")
    print(f"  最终函数值: {f_nt[-1]:.6e}")
    print(f"  收敛速度: 较快，二次收敛")

    print("\n比较说明:")
    print("1. 收敛速度: 牛顿法明显快于最速下降法")
    print("2. 计算复杂度: 牛顿法需要计算Hessian矩阵，计算量更大")
    print("3. 对于Rosenbrock函数，牛顿法能更快找到谷底方向")
    print("4. 最速下降法在峡谷地形中容易产生锯齿现象")


# 运行主函数
if __name__ == "__main__":
    main()