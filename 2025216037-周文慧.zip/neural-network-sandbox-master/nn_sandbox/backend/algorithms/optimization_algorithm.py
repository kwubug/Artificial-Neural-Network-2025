import numpy as np
from threading import Thread


class OptimizationAlgorithm(Thread):
    """
    Optimization algorithms visualization on various test functions
    Implements: Steepest Descent, Newton Method, Conjugate Gradient
    Supports: Rosenbrock, Himmelblau, Rastrigin, Ackley, Beale, Sphere
    """

    def __init__(self, objective_function, optimization_method, learning_rate, max_iterations, threshold, start_x, start_y):
        super().__init__()
        self.objective_function_index = objective_function  # 函数索引 0-5
        self.optimization_method = optimization_method
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self.threshold = threshold
        self.x = start_x
        self.y = start_y

        self.current_iteration = 0
        self.current_x = start_x
        self.current_y = start_y
        self.current_value = 0.0
        self.gradient_norm = 0.0
        self._running = True

        # For conjugate gradient
        self.prev_gradient = None
        self.prev_direction = None

    def objective_function(self, x, y):
        """根据选择的函数索引计算目标函数值"""
        if self.objective_function_index == 0:
            # Rosenbrock function: f(x,y) = (1-x)^2 + 100(y-x^2)^2
            return (1 - x) ** 2 + 100 * (y - x ** 2) ** 2
        
        elif self.objective_function_index == 1:
            # Himmelblau function
            return (x**2 + y - 11)**2 + (x + y**2 - 7)**2
        
        elif self.objective_function_index == 2:
            # Rastrigin function
            A = 10
            return A * 2 + (x**2 - A * np.cos(2 * np.pi * x)) + (y**2 - A * np.cos(2 * np.pi * y))
        
        elif self.objective_function_index == 3:
            # Ackley function
            a = 20
            b = 0.2
            c = 2 * np.pi
            sum_sq = x**2 + y**2
            cos_term = np.cos(c * x) + np.cos(c * y)
            return -a * np.exp(-b * np.sqrt(sum_sq / 2)) - np.exp(cos_term / 2) + a + np.e
        
        elif self.objective_function_index == 4:
            # Beale function
            term1 = (1.5 - x + x * y)**2
            term2 = (2.25 - x + x * y**2)**2
            term3 = (2.625 - x + x * y**3)**2
            return term1 + term2 + term3
        
        else:  # self.objective_function_index == 5
            # Sphere function
            return x**2 + y**2

    def gradient(self, x, y):
        """根据选择的函数索引计算梯度"""
        if self.objective_function_index == 0:
            # Rosenbrock gradient
            dx = -2 * (1 - x) - 400 * x * (y - x ** 2)
            dy = 200 * (y - x ** 2)
            return np.array([dx, dy])
        
        elif self.objective_function_index == 1:
            # Himmelblau gradient
            dx = 4 * x * (x**2 + y - 11) + 2 * (x + y**2 - 7)
            dy = 2 * (x**2 + y - 11) + 4 * y * (x + y**2 - 7)
            return np.array([dx, dy])
        
        elif self.objective_function_index == 2:
            # Rastrigin gradient
            A = 10
            dx = 2 * x + 2 * np.pi * A * np.sin(2 * np.pi * x)
            dy = 2 * y + 2 * np.pi * A * np.sin(2 * np.pi * y)
            return np.array([dx, dy])
        
        elif self.objective_function_index == 3:
            # Ackley gradient (数值微分)
            h = 1e-5
            dx = (self.objective_function(x + h, y) - self.objective_function(x - h, y)) / (2 * h)
            dy = (self.objective_function(x, y + h) - self.objective_function(x, y - h)) / (2 * h)
            return np.array([dx, dy])
        
        elif self.objective_function_index == 4:
            # Beale gradient
            term1 = 1.5 - x + x * y
            term2 = 2.25 - x + x * y**2
            term3 = 2.625 - x + x * y**3
            
            dx = 2 * term1 * (y - 1) + 2 * term2 * (y**2 - 1) + 2 * term3 * (y**3 - 1)
            dy = 2 * term1 * x + 2 * term2 * (2 * x * y) + 2 * term3 * (3 * x * y**2)
            return np.array([dx, dy])
        
        else:  # self.objective_function_index == 5
            # Sphere gradient
            return np.array([2 * x, 2 * y])

    def hessian(self, x, y):
        """根据选择的函数索引计算Hessian矩阵"""
        if self.objective_function_index == 0:
            # Rosenbrock Hessian (解析解)
            h11 = 2 - 400 * (y - 3 * x ** 2)
            h12 = -400 * x
            h21 = -400 * x
            h22 = 200
            return np.array([[h11, h12], [h21, h22]])
        
        elif self.objective_function_index == 1:
            # Himmelblau Hessian (解析解)
            h11 = 12 * x**2 + 4 * y - 42
            h12 = 4 * x + 4 * y
            h21 = 4 * x + 4 * y
            h22 = 4 * x + 12 * y**2 - 26
            return np.array([[h11, h12], [h21, h22]])
        
        elif self.objective_function_index == 5:
            # Sphere Hessian (解析解)
            return np.array([[2, 0], [0, 2]])
        
        else:
            # 其他函数使用数值微分计算Hessian
            h = 1e-5
            f_xx = (self.objective_function(x+h, y) - 2*self.objective_function(x, y) + 
                    self.objective_function(x-h, y)) / (h**2)
            f_yy = (self.objective_function(x, y+h) - 2*self.objective_function(x, y) + 
                    self.objective_function(x, y-h)) / (h**2)
            f_xy = (self.objective_function(x+h, y+h) - self.objective_function(x+h, y-h) - 
                    self.objective_function(x-h, y+h) + self.objective_function(x-h, y-h)) / (4*h**2)
            
            return np.array([[f_xx, f_xy], [f_xy, f_yy]])

    def steepest_descent(self):
        """Steepest Descent Method"""
        grad = self.gradient(self.x, self.y)
        self.x -= self.learning_rate * grad[0]
        self.y -= self.learning_rate * grad[1]
        return grad

    def newton_method(self):
        """Newton Method"""
        grad = self.gradient(self.x, self.y)
        hess = self.hessian(self.x, self.y)

        try:
            # Newton step: x_new = x - H^(-1) * grad
            # 添加正则化以提高稳定性
            hess_reg = hess + 1e-6 * np.eye(2)
            hess_inv = np.linalg.inv(hess_reg)
            delta = hess_inv @ grad
            self.x -= self.learning_rate * delta[0]
            self.y -= self.learning_rate * delta[1]
        except np.linalg.LinAlgError:
            # If Hessian is singular, fall back to steepest descent
            self.x -= self.learning_rate * grad[0]
            self.y -= self.learning_rate * grad[1]

        return grad

    def conjugate_gradient(self):
        """Conjugate Gradient Method"""
        grad = self.gradient(self.x, self.y)

        if self.prev_gradient is None:
            # First iteration: use steepest descent direction
            direction = -grad
        else:
            # Calculate beta (Fletcher-Reeves formula)
            beta = np.dot(grad, grad) / (np.dot(self.prev_gradient, self.prev_gradient) + 1e-10)
            direction = -grad + beta * self.prev_direction

        self.x += self.learning_rate * direction[0]
        self.y += self.learning_rate * direction[1]

        self.prev_gradient = grad.copy()
        self.prev_direction = direction.copy()

        return grad

    def run(self):
        """Main optimization loop"""
        self.add_path_point(self.x, self.y, self.objective_function(self.x, self.y))

        for i in range(self.max_iterations):
            if not self._running:
                break

            # Perform optimization step
            if self.optimization_method == 0:
                grad = self.steepest_descent()
            elif self.optimization_method == 1:
                grad = self.newton_method()
            else:  # self.optimization_method == 2
                grad = self.conjugate_gradient()

            # Update state
            self.current_iteration = i + 1
            self.current_x = self.x
            self.current_y = self.y
            self.current_value = self.objective_function(self.x, self.y)
            self.gradient_norm = np.linalg.norm(grad)

            # Add point to path
            self.add_path_point(self.x, self.y, self.current_value)

            # Check convergence
            if self.gradient_norm < self.threshold:
                break

    def add_path_point(self, x, y, value):
        """Override this method in observer"""
        pass

    def stop(self):
        """Stop the optimization"""
        self._running = False