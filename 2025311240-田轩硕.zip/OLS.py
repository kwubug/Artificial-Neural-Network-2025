import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.animation as animation
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# 设置中文显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  # 正确显示负号

# 生成模拟数据
np.random.seed(42)
x = np.linspace(0, 10, 100)
true_slope = 2.5
true_intercept = 3.0
y = true_slope * x + true_intercept + np.random.normal(0, 1.5, size=len(x))

# 初始化参数
initial_slope = np.random.uniform(-2, 6)
initial_intercept = np.random.uniform(-5, 10)

# 计算解析解
lr = LinearRegression()
lr.fit(x.reshape(-1, 1), y)
optimal_slope = lr.coef_[0]
optimal_intercept = lr.intercept_

# 梯度下降参数
learning_rate = 0.01
num_iterations = 200

# 存储迭代过程
slopes = [initial_slope]
intercepts = [initial_intercept]
losses = [mean_squared_error(y, initial_slope * x + initial_intercept)]

# 梯度下降迭代
for i in range(num_iterations):
    current_slope = slopes[-1]
    current_intercept = intercepts[-1]
    y_pred = current_slope * x + current_intercept

    slope_gradient = 2 * np.mean((y_pred - y) * x)
    intercept_gradient = 2 * np.mean(y_pred - y)

    new_slope = current_slope - learning_rate * slope_gradient
    new_intercept = current_intercept - learning_rate * intercept_gradient

    slopes.append(new_slope)
    intercepts.append(new_intercept)
    losses.append(mean_squared_error(y, new_slope * x + new_intercept))

# 创建动画
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle('OLS算法可视化：梯度下降过程')

ax1.scatter(x, y, alpha=0.6, label='数据点')
line, = ax1.plot(x, initial_slope * x + initial_intercept, 'r-', label='拟合直线')
true_line, = ax1.plot(x, true_slope * x + true_intercept, 'g--', label='真实直线')
ax1.set_xlabel('X')
ax1.set_ylabel('Y')
ax1.set_title('数据与拟合直线')
ax1.legend()
ax1.grid(True)

loss_line, = ax2.plot([0], losses[:1], 'b-')
ax2.set_xlim(0, num_iterations)
ax2.set_ylim(0, max(losses) * 1.1)
ax2.set_xlabel('迭代次数')
ax2.set_ylabel('均方误差 (MSE)')
ax2.set_title('损失函数变化')
ax2.grid(True)

param_text = ax1.text(0.05, 0.95, '', transform=ax1.transAxes,
                      verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))


def update(frame):
    current_slope = slopes[frame]
    current_intercept = intercepts[frame]
    line.set_ydata(current_slope * x + current_intercept)
    loss_line.set_xdata(range(frame + 1))
    loss_line.set_ydata(losses[:frame + 1])
    param_text.set_text(f'迭代次数: {frame}\n斜率: {current_slope:.4f}\n截距: {current_intercept:.4f}\n损失: {losses[frame]:.4f}')
    return line, loss_line, param_text


ani = FuncAnimation(fig, update, frames=range(num_iterations + 1),
                    interval=50, blit=True)

final_text = ax1.text(0.05, 0.8,
                      f'最优解:\n斜率: {optimal_slope:.4f}\n截距: {optimal_intercept:.4f}',
                      transform=ax1.transAxes, verticalalignment='top',
                      bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.5))

plt.tight_layout()
plt.show()