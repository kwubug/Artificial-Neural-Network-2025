import sys
import numpy as np

# Try PyQt6 first, then fallback to PyQt5
try:
    from PyQt6.QtWidgets import (QApplication, QWidget, QLabel, QSpinBox, QDoubleSpinBox,
                                 QComboBox, QPushButton, QHBoxLayout, QVBoxLayout, QGroupBox,
                                 QGridLayout, QProgressBar, QFileDialog, QMessageBox)
    from PyQt6.QtCore import QThread, pyqtSignal, Qt
    PYQT_VERSION = 6
except Exception:
    from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QSpinBox, QDoubleSpinBox,
                                 QComboBox, QPushButton, QHBoxLayout, QVBoxLayout, QGroupBox,
                                 QGridLayout, QProgressBar, QFileDialog, QMessageBox)
    from PyQt5.QtCore import QThread, pyqtSignal, Qt
    PYQT_VERSION = 5

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from bpnn_core import ThreeLayerBP

class TrainerThread(QThread):
    progress = pyqtSignal(int, float)  # epoch, loss
    finished = pyqtSignal()

    def __init__(self, model, X, Y, epochs=100, parent=None):
        super().__init__(parent)
        self.model = model
        self.X = X
        self.Y = Y
        self.epochs = int(epochs)
        self._stop = False

    def run(self):
        for e in range(1, self.epochs + 1):
            if self._stop:
                break
            loss = self.model.fit_epoch(self.X, self.Y, shuffle=True)
            self.progress.emit(e, float(loss))
        self.finished.emit()

    def stop(self):
        self._stop = True


class MplCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("三层前馈神经网络 BP 学习可视化 (PyQt)")
        self.model = None
        self.thread = None
        self.X = None
        self.Y = None
        self.loss_history = []

        self._build_ui()
        self._generate_xor_dataset()
        self._init_model()

    # ---------- UI ----------
    def _build_ui(self):
        # Network structure
        gb_net = QGroupBox("网络结构")
        lbl_in = QLabel("输入节点数:")
        lbl_h = QLabel("隐藏节点数:")
        lbl_out = QLabel("输出节点数:")
        self.s_in = QSpinBox(); self.s_in.setRange(1, 20); self.s_in.setValue(2)
        self.s_h  = QSpinBox(); self.s_h.setRange(1, 100); self.s_h.setValue(4)
        self.s_out= QSpinBox(); self.s_out.setRange(1, 10); self.s_out.setValue(1)

        grid = QGridLayout()
        grid.addWidget(lbl_in, 0, 0); grid.addWidget(self.s_in, 0, 1)
        grid.addWidget(lbl_h,  1, 0); grid.addWidget(self.s_h,  1, 1)
        grid.addWidget(lbl_out,2, 0); grid.addWidget(self.s_out,2, 1)
        gb_net.setLayout(grid)

        # Learning rates
        gb_lr = QGroupBox("学习率")
        lbl_lrih = QLabel("输入→隐藏 lr:")
        lbl_lrho = QLabel("隐藏→输出 lr:")
        self.d_lrih = QDoubleSpinBox(); self.d_lrih.setDecimals(4); self.d_lrih.setRange(0.0001, 10.0); self.d_lrih.setValue(0.1); self.d_lrih.setSingleStep(0.05)
        self.d_lrho = QDoubleSpinBox(); self.d_lrho.setDecimals(4); self.d_lrho.setRange(0.0001, 10.0); self.d_lrho.setValue(0.1); self.d_lrho.setSingleStep(0.05)
        grid2 = QGridLayout()
        grid2.addWidget(lbl_lrih, 0, 0); grid2.addWidget(self.d_lrih, 0, 1)
        grid2.addWidget(lbl_lrho, 1, 0); grid2.addWidget(self.d_lrho, 1, 1)
        gb_lr.setLayout(grid2)

        # Activation
        gb_act = QGroupBox("激活函数")
        self.cb_act = QComboBox()
        self.cb_act.addItems(["单极性Sigmoid (0..1)", "双极性Sigmoid (-1..1)"])
        v_act = QVBoxLayout(); v_act.addWidget(self.cb_act); gb_act.setLayout(v_act)

        # Buttons
        self.btn_init = QPushButton("初始化权值 [-1,1]")
        self.btn_gen = QPushButton("生成/重置 XOR 数据集")
        self.btn_train = QPushButton("训练 200 epoch")
        self.btn_stop = QPushButton("停止")
        self.btn_predict = QPushButton("查看当前预测")

        self.btn_init.clicked.connect(self._init_model)
        self.btn_gen.clicked.connect(self._generate_xor_dataset)
        self.btn_train.clicked.connect(self._train_epochs)
        self.btn_stop.clicked.connect(self._stop_training)
        self.btn_predict.clicked.connect(self._show_prediction_dialog)

        # Progress + Status
        self.progress = QProgressBar(); self.progress.setRange(0, 0); self.progress.setVisible(False)
        self.lbl_status = QLabel("准备就绪")

        # Plot
        self.canvas = MplCanvas(self, width=5, height=4, dpi=100)

        # Layouts
        left = QVBoxLayout()
        left.addWidget(gb_net)
        left.addWidget(gb_lr)
        left.addWidget(gb_act)
        left.addWidget(self.btn_init)
        left.addWidget(self.btn_gen)
        left.addWidget(self.btn_train)
        left.addWidget(self.btn_stop)
        left.addWidget(self.btn_predict)
        left.addStretch()
        left.addWidget(self.progress)
        left.addWidget(self.lbl_status)

        main = QHBoxLayout()
        main.addLayout(left, 0)
        main.addWidget(self.canvas, 1)

        self.setLayout(main)
        self.resize(980, 620)

    # ---------- Data & Model ----------
    def _generate_xor_dataset(self, n_repeat=200, noise=0.10):
        # XOR in [0,1]^2 with noise
        base_X = np.array([[0,0],[0,1],[1,0],[1,1]], dtype=float)
        base_y = np.array([0, 1, 1, 0], dtype=float)  # labels in {0,1}

        X_list = []
        y_list = []
        rng = np.random.default_rng(1234)
        for _ in range(n_repeat):
            idx = rng.integers(0, 4)
            point = base_X[idx] + rng.normal(0, noise, size=2)
            label = base_y[idx]
            X_list.append(point)
            y_list.append(label)

        X = np.vstack(X_list)  # (N, 2)
        y = np.array(y_list)   # (N,)

        self.X = X.T  # (2, N)
        self.y_raw = y  # keep raw for display
        self.lbl_status.setText(f"数据集: XOR，样本数 {self.X.shape[1]}")
        self.loss_history = []
        self._redraw_plot()

    def _init_model(self):
        n_in = self.s_in.value()
        n_h = self.s_h.value()
        n_out = self.s_out.value()
        act = "unipolar" if self.cb_act.currentIndex() == 0 else "bipolar"

        self.model = ThreeLayerBP(n_in, n_h, n_out, activation=act,
                                  lr_ih=self.d_lrih.value(),
                                  lr_ho=self.d_lrho.value(),
                                  seed=42)
        # prepare labels in correct range
        y_scaled, self.label_map = self.model.normalize_labels(self.y_raw if hasattr(self, "y_raw") else np.zeros(1))
        self.Y = y_scaled.reshape(1, -1) if n_out == 1 else None  # simple demo for 1-output XOR
        self.loss_history = []
        self.lbl_status.setText("模型已初始化（权值范围 [-1,1]）")
        self._redraw_plot()

    # ---------- Training ----------
    def _train_epochs(self):
        if self.model is None or self.X is None or self.Y is None:
            QMessageBox.warning(self, "缺少数据", "请先生成数据并初始化模型。")
            return
        if self.s_in.value() != self.X.shape[0]:
            QMessageBox.warning(self, "维度不匹配", f"当前输入维度为 {self.X.shape[0]}，请将输入节点数设置为相同数值。")
            return
        if self.s_out.value() != self.Y.shape[0]:
            QMessageBox.warning(self, "维度不匹配", f"当前输出维度为 {self.Y.shape[0]}，请将输出节点数设置为相同数值。")
            return

        # Update LR & activation (in case user changed)
        act = "unipolar" if self.cb_act.currentIndex() == 0 else "bipolar"
        self.model.set_activation(act)
        self.model.set_learning_rates(self.d_lrih.value(), self.d_lrho.value())

        self.progress.setVisible(True)
        self.lbl_status.setText("训练中...")

        self.thread = TrainerThread(self.model, self.X, self.Y, epochs=200)
        self.thread.progress.connect(self._on_progress)
        self.thread.finished.connect(self._on_finished)
        self.thread.start()

    def _stop_training(self):
        if self.thread and self.thread.isRunning():
            self.thread.stop()

    def _on_progress(self, epoch, loss):
        self.loss_history.append(loss)
        self.lbl_status.setText(f"训练中 - Epoch {epoch}, Loss={loss:.5f}")
        self._redraw_plot()

    def _on_finished(self):
        self.progress.setVisible(False)
        self.lbl_status.setText("训练完成 / 停止")

    # ---------- Visualization ----------
    def _redraw_plot(self):
        self.canvas.ax.clear()
        # Left y-axis: loss curve
        if len(self.loss_history) > 0:
            self.canvas.ax.plot(np.arange(1, len(self.loss_history)+1), self.loss_history, label="Loss")
            self.canvas.ax.set_xlabel("Epoch")
            self.canvas.ax.set_ylabel("MSE Loss")
            self.canvas.ax.legend(loc="upper right")

        # Decision boundary for 2D -> 1D
        if self.model is not None and self.X is not None and self.s_in.value() == 2 and self.s_out.value() == 1:
            # scatter training points (raw labels)
            colors = np.where(self.y_raw > 0.5, 1, 0)
            self.canvas.ax.scatter(self.X[0], self.X[1], c=colors, alpha=0.25, s=10)

            # draw decision boundary
            xx, yy = np.meshgrid(np.linspace(-0.5, 1.5, 120), np.linspace(-0.5, 1.5, 120))
            grid = np.vstack([xx.ravel(), yy.ravel()])
            preds = self.model.predict(grid).reshape(xx.shape)
            if self.model.activation_name == "unipolar":
                boundary = 0.5
            else:
                boundary = 0.0
            cs = self.canvas.ax.contour(xx, yy, preds, levels=[boundary])
            self.canvas.ax.clabel(cs, inline=True, fontsize=8)

            self.canvas.ax.set_xlim(-0.5, 1.5); self.canvas.ax.set_ylim(-0.5, 1.5)
            self.canvas.ax.set_title("Loss 曲线与决策边界")

        self.canvas.draw_idle()

    # ---------- Predict Dialog ----------
    def _show_prediction_dialog(self):
        if self.model is None:
            QMessageBox.information(self, "提示", "请先初始化模型。")
            return
        # quick demo: predict the four XOR corners
        X_demo = np.array([[0,0,1,1],[0,1,0,1]], dtype=float)
        y_hat = self.model.predict(X_demo)
        if self.model.activation_name == "unipolar":
            pred_cls = (y_hat >= 0.5).astype(int)
        else:
            pred_cls = (y_hat >= 0.0).astype(int)
        msg = "输入点 (x1, x2) | 预测输出 y_hat | 预测类别\n"
        for i in range(X_demo.shape[1]):
            msg += f"({X_demo[0,i]:.0f}, {X_demo[1,i]:.0f}) | {float(y_hat[0,i]):.4f} | {int(pred_cls[0,i])}\n"
        QMessageBox.information(self, "当前预测", msg)


def main():
    app = QApplication(sys.argv)
    w = App()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()