import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import OlsAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(20)
    initial_learning_rate = BridgeProperty(0.1)
    search_iteration_constant = BridgeProperty(1000)
    test_ratio = BridgeProperty(0.3)

    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    r2_training = BridgeProperty(0.0)
    r2_testing = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    # model parameters
    a = BridgeProperty(0.0)
    b = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self.ols_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_ols_algorithm(self):
        self.ols_algorithm = ObservableOlsAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=None,  # for regression we keep running full schedule by default
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            test_ratio=self.test_ratio,
        )
        self.ols_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols_algorithm(self):
        if self.ols_algorithm:
            self.ols_algorithm.stop()

class ObservableOlsAlgorithm(Observable, OlsAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        # Guard to avoid premature notifications during initialization
        object.__setattr__(self, '_init_done', False)
        # Initialize observer first so it's available later
        Observable.__init__(self, observer)
        # Initialize algorithm (defines a/b later as needed)
        OlsAlgorithm.__init__(self, **kwargs)
        object.__setattr__(self, 'ui_refresh_interval', ui_refresh_interval)
        object.__setattr__(self, '_last_ui_time', 0.0)
        object.__setattr__(self, '_init_done', True)
        # Emit initial values so QML can render immediately
        if self.training_dataset is not None:
            self.notify('training_dataset', self.training_dataset.tolist())
        if self.testing_dataset is not None:
            self.notify('testing_dataset', self.testing_dataset.tolist())
        self.notify('a', self.a)
        self.notify('b', self.b)
        self.notify('r2_training', self._correct_rate(self.training_dataset))
        self.notify('r2_testing', self.test())

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # Do not notify until fully initialized and observer is ready
        if not getattr(self, '_init_done', False) or not hasattr(self, '_observer'):
            return
        if name == 'current_iterations':
            import time as _t
            now = _t.time()
            # throttle UI updates by ui_refresh_interval seconds
            if now - getattr(self, '_last_ui_time', 0.0) >= max(self.ui_refresh_interval, 0.0):
                object.__setattr__(self, '_last_ui_time', now)
                self.notify(name, value)
                # update metrics for charts
                self.notify('r2_training', self._correct_rate(self.training_dataset))
                self.notify('r2_testing', self.test())
            return
        elif name in ('a', 'b'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())
        elif name in ('r2_training', 'r2_testing'):
            self.notify(name, value)

    def run(self):
        self.notify('has_finished', False)
        self.notify('r2_testing', 0)
        try:
            super().run()
        finally:
            # 确保无论如何都会执行最终更新
            self.notify('r2_testing', self.test())
            self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # 改进：使用小的 sleep 间隔来检查停止标志
        if self.ui_refresh_interval > 0:
            # 将 sleep 时间分成小块，每次检查是否需要停止
            sleep_chunks = 10  # 分成10小块
            chunk_time = self.ui_refresh_interval / sleep_chunks
            for _ in range(sleep_chunks):
                if self._should_stop:  # 检查停止标志
                    break
                time.sleep(chunk_time)

    @property
    def current_learning_rate(self):
        value = super().current_learning_rate
        self.notify('current_learning_rate', value)
        return value

    @property
    def r2_training(self):
        value = self._correct_rate(self.training_dataset)
        self.notify('r2_training', value)
        return value