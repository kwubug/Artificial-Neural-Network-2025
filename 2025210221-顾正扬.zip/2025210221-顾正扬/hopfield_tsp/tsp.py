import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.animation import FuncAnimation
import time

# 设置matplotlib支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


class TSPVisualizer:
    def __init__(self, num_cities=20, width=10, height=10):
        self.num_cities = num_cities
        self.width = width
        self.height = height
        self.cities = None
        self.dist_matrix = None
        self.best_route = None
        self.best_distance = float('inf')
        self.fig, self.ax = plt.subplots(figsize=(10, 8))

    def generate_cities(self):
        """随机生成城市坐标"""
        np.random.seed(42)  # 设置随机种子以确保结果可复现
        self.cities = np.random.rand(self.num_cities, 2) * np.array([self.width, self.height])
        self._calculate_dist_matrix()
        return self.cities

    def _calculate_dist_matrix(self):
        """计算城市间距离矩阵"""
        self.dist_matrix = np.zeros((self.num_cities, self.num_cities))
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                if i != j:
                    self.dist_matrix[i, j] = np.linalg.norm(self.cities[i] - self.cities[j])

    def calculate_total_distance(self, route):
        """计算路径总距离"""
        total_distance = 0
        for i in range(len(route) - 1):
            total_distance += self.dist_matrix[route[i], route[i + 1]]
        # 添加返回起点的距离
        total_distance += self.dist_matrix[route[-1], route[0]]
        return total_distance

    def greedy_algorithm(self):
        """贪婪算法求解TSP"""
        start_city = 0
        unvisited = set(range(self.num_cities))
        unvisited.remove(start_city)
        route = [start_city]

        current_city = start_city
        while unvisited:
            # 找到距离当前城市最近的未访问城市
            nearest_city = min(unvisited, key=lambda city: self.dist_matrix[current_city, city])
            route.append(nearest_city)
            unvisited.remove(nearest_city)
            current_city = nearest_city

        # 返回到起点
        route.append(start_city)

        distance = self.calculate_total_distance(route[:-1])  # 不包括重复的起点
        self.best_route = route
        self.best_distance = distance

        return route, distance

    def simulated_annealing(self, initial_temp=1000, cooling_rate=0.99, max_iterations=10000):
        """模拟退火算法求解TSP"""
        # 从贪婪算法的解开始，作为初始解
        current_route, current_distance = self.greedy_algorithm()
        current_route = current_route[:-1]  # 移除重复的起点

        best_route = current_route.copy()
        best_distance = current_distance

        temp = initial_temp

        # 用于记录优化过程
        history = []

        for iteration in range(max_iterations):
            # 生成新解（交换两个城市的位置）
            new_route = current_route.copy()
            i, j = np.random.randint(0, self.num_cities, 2)
            if i != j:
                new_route[i], new_route[j] = new_route[j], new_route[i]

                # 计算新路径的距离
                new_distance = self.calculate_total_distance(new_route)

                # 判断是否接受新解
                delta = new_distance - current_distance
                if delta < 0 or np.random.rand() < np.exp(-delta / temp):
                    current_route = new_route
                    current_distance = new_distance

                    # 更新全局最优解
                    if current_distance < best_distance:
                        best_route = current_route.copy()
                        best_distance = current_distance

            # 记录当前最优解
            if iteration % 100 == 0:
                history.append((best_route.copy(), best_distance))

            # 降温
            temp *= cooling_rate

        # 完成路径（添加返回起点）
        best_route_complete = best_route.copy()
        best_route_complete.append(best_route_complete[0])

        self.best_route = best_route_complete
        self.best_distance = best_distance

        return best_route_complete, best_distance, history

    def visualize_cities(self):
        """可视化城市分布"""
        self.ax.clear()

        # 绘制普通城市（排除起点）
        self.ax.scatter(self.cities[1:, 0], self.cities[1:, 1], c='red', s=100, label='城市')

        # 突出显示起点（城市0）
        self.ax.scatter(self.cities[0, 0], self.cities[0, 1], c='green', s=150, edgecolor='black', linewidth=2,
                        label='起点 (城市0)')

        # 为城市添加标签
        for i, (x, y) in enumerate(self.cities):
            self.ax.annotate(str(i), (x, y), fontsize=12, ha='center', va='center')

        self.ax.set_title('TSP问题 - 城市分布')
        self.ax.set_xlabel('X坐标')
        self.ax.set_ylabel('Y坐标')
        self.ax.grid(True)
        self.ax.legend()
        plt.show()

    def visualize_route(self, route, title='TSP最优路径'):
        """可视化TSP路径"""
        self.ax.clear()

        # 绘制普通城市（排除起点）
        self.ax.scatter(self.cities[1:, 0], self.cities[1:, 1], c='red', s=100, label='城市')

        # 突出显示起点（城市0）
        self.ax.scatter(self.cities[0, 0], self.cities[0, 1], c='green', s=150, edgecolor='black', linewidth=2,
                        label='起点 (城市0)')

        # 添加城市标签
        for i, (x, y) in enumerate(self.cities):
            self.ax.annotate(str(i), (x, y), fontsize=12, ha='center', va='center')

        # 绘制路径
        route_cities = self.cities[route]
        self.ax.plot(route_cities[:, 0], route_cities[:, 1], 'b-', linewidth=2, label='路径')

        # 突出显示路径的起始段
        if len(route) >= 2:
            self.ax.plot(route_cities[0:2, 0], route_cities[0:2, 1], 'g-', linewidth=3, label='起始段')

        self.ax.set_title(f'{title}\n总距离: {self.calculate_total_distance(route[:-1]):.2f}\n起点: 城市0')
        self.ax.set_xlabel('X坐标')
        self.ax.set_ylabel('Y坐标')
        self.ax.grid(True)
        self.ax.legend()
        plt.show()

    def animate_optimization(self, history):
        """动画展示优化过程"""
        # 创建一个新的图形窗口以避免与其他可视化冲突
        ani_fig, ani_ax = plt.subplots(figsize=(10, 8))

        def update(frame):
            ani_ax.clear()
            route, distance = history[frame]
            route_complete = route.copy()
            route_complete.append(route[0])

            # 绘制普通城市（排除起点）
            ani_ax.scatter(self.cities[1:, 0], self.cities[1:, 1], c='red', s=100, label='城市')

            # 突出显示起点（城市0）
            ani_ax.scatter(self.cities[0, 0], self.cities[0, 1], c='green', s=150, edgecolor='black', linewidth=2,
                           label='起点 (城市0)')

            # 添加城市标签
            for i, (x, y) in enumerate(self.cities):
                ani_ax.annotate(str(i), (x, y), fontsize=12, ha='center', va='center')

            # 绘制路径
            route_cities = self.cities[route_complete]
            ani_ax.plot(route_cities[:, 0], route_cities[:, 1], 'b-', linewidth=2, label='路径')

            # 突出显示路径的起始段
            if len(route) >= 2:
                ani_ax.plot(route_cities[0:2, 0], route_cities[0:2, 1], 'g-', linewidth=3, label='起始段')

            ani_ax.set_title(f'迭代: {frame * 100}, 距离: {distance:.2f}\n起点: 城市0')
            ani_ax.set_xlabel('X坐标')
            ani_ax.set_ylabel('Y坐标')
            ani_ax.grid(True)
            ani_ax.legend()

        # 创建动画对象并保持引用
        ani = FuncAnimation(ani_fig, update, frames=len(history), interval=200, repeat=False)
        plt.tight_layout()
        plt.show()


def main():
    # 创建TSP可视化器实例
    tsp = TSPVisualizer(num_cities=20)

    # 生成城市
    print("生成城市...")
    tsp.generate_cities()

    # 可视化城市分布
    print("可视化城市分布...")
    tsp.visualize_cities()

    # 使用贪婪算法求解
    print("使用贪婪算法求解...")
    greedy_route, greedy_distance = tsp.greedy_algorithm()
    print(f"贪婪算法结果: 距离 = {greedy_distance:.2f}")
    tsp.visualize_route(greedy_route, "贪婪算法路径")

    # 使用模拟退火算法求解
    print("使用模拟退火算法求解...")
    sa_route, sa_distance, history = tsp.simulated_annealing(
        initial_temp=1000,
        cooling_rate=0.99,
        max_iterations=10000
    )
    print(f"模拟退火算法结果: 距离 = {sa_distance:.2f}")
    print(f"优化率: {(greedy_distance - sa_distance) / greedy_distance * 100:.2f}%")

    # 可视化优化过程
    print("动画展示优化过程...")
    tsp.animate_optimization(history)

    # 展示最终结果
    print("展示最终最优路径...")
    tsp.visualize_route(sa_route, "模拟退火最优路径")


if __name__ == "__main__":
    main()
