import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: '优化'
    
    property int animationIndex: 0
    property bool isAnimating: false
    property var fullTrajectory: []
    
    ColumnLayout {
        Layout.maximumWidth: 350
        Layout.preferredWidth: 320
        
        GroupBox {
            title: '优化设置'
            Layout.fillWidth: true
            font.pointSize: 9
            
            GridLayout {
                anchors.fill: parent
                columns: 2
                columnSpacing: 8
                rowSpacing: 5
                
                Label {
                    text: '测试函数'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                ComboBox {
                    id: testFunctionCombobox
                    enabled: optimizationBridge.has_finished
                    model: [
                        'Rosenbrock函数', 
                        '球函数 (Sphere)', 
                        'Beale函数',
                        'Booth函数'
                    ]
                    currentIndex: 0
                    onActivated: {
                        const funcs = ['rosenbrock', 'sphere', 'beale', 'booth']
                        optimizationBridge.test_function = funcs[currentIndex]
                        updateContour()
                    }
                    Component.onCompleted: {
                        optimizationBridge.test_function = 'rosenbrock'
                    }
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '优化方法'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                ComboBox {
                    id: methodCombobox
                    enabled: optimizationBridge.has_finished
                    model: ['最速下降法', '牛顿下降法', '共轭梯度法']
                    currentIndex: 0
                    onActivated: {
                        const methods = ['steepest', 'newton', 'conjugate']
                        optimizationBridge.optimization_method = methods[currentIndex]
                    }
                    Component.onCompleted: {
                        optimizationBridge.optimization_method = 'steepest'
                    }
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '最大迭代'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                SpinBox {
                    id: maxIterations
                    enabled: optimizationBridge.has_finished
                    editable: true
                    value: 100
                    from: 10
                    to: 1000
                    onValueChanged: optimizationBridge.max_iterations = value
                    Component.onCompleted: optimizationBridge.max_iterations = value
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '收敛容差'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                ComboBox {
                    id: toleranceCombobox
                    enabled: optimizationBridge.has_finished
                    model: ['1e-4', '1e-5', '1e-6', '1e-7', '1e-8']
                    currentIndex: 2
                    onActivated: {
                        const values = [1e-4, 1e-5, 1e-6, 1e-7, 1e-8]
                        optimizationBridge.tolerance = values[currentIndex]
                    }
                    Component.onCompleted: {
                        optimizationBridge.tolerance = 1e-6
                    }
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '初始点X'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                DoubleSpinBox {
                    id: initialX
                    enabled: optimizationBridge.has_finished
                    editable: true
                    value: -1.0 * 100
                    from: -10 * 100
                    to: 10 * 100
                    onValueChanged: optimizationBridge.initial_x = value / 100
                    Component.onCompleted: optimizationBridge.initial_x = value / 100
                    Layout.fillWidth: true
                }
                
                Label {
                    text: '初始点Y'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                DoubleSpinBox {
                    id: initialY
                    enabled: optimizationBridge.has_finished
                    editable: true
                    value: 1.0 * 100
                    from: -10 * 100
                    to: 10 * 100
                    onValueChanged: optimizationBridge.initial_y = value / 100
                    Component.onCompleted: optimizationBridge.initial_y = value / 100
                    Layout.fillWidth: true
                }
                
                Label {
                    text: '动画速度'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                SpinBox {
                    id: animationSpeed
                    enabled: true
                    editable: true
                    value: 150
                    from: 10
                    to: 1000
                    stepSize: 10
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
            }
        }
        
        GroupBox {
            title: '执行控制'
            Layout.fillWidth: true
            font.pointSize: 9
            
            ColumnLayout {
                anchors.fill: parent
                spacing: 5
                
                GridLayout {
                    columns: 2
                    columnSpacing: 5
                    rowSpacing: 5
                    Layout.fillWidth: true
                    
                    Button {
                        text: "▶ 运行"
                        enabled: optimizationBridge.has_finished && !isAnimating
                        onClicked: {
                            optimizationBridge.ui_refresh_interval = 0
                            optimizationBridge.start_optimization()
                            lossChart.reset()
                            gradientChart.reset()
                            trajectoryChart.clearTrajectory()
                            updateContour()
                        }
                        Layout.fillWidth: true
                        font.pointSize: 8
                    }
                    
                    Button {
                        text: "🎬 动画"
                        enabled: optimizationBridge.has_finished && 
                                fullTrajectory.length > 0 &&
                                !isAnimating
                        onClicked: {
                            startAnimation()
                        }
                        Layout.fillWidth: true
                        font.pointSize: 8
                    }
                    
                    Button {
                        text: "⏹ 停止"
                        enabled: isAnimating
                        onClicked: {
                            stopAnimation()
                        }
                        Layout.fillWidth: true
                        font.pointSize: 8
                    }
                    
                    Button {
                        text: "🔄 重置"
                        enabled: optimizationBridge.has_finished && !isAnimating
                        onClicked: {
                            resetVisualization()
                        }
                        Layout.fillWidth: true
                        font.pointSize: 8
                    }
                }
                
                ProgressBar {
                    id: progressBar
                    Layout.fillWidth: true
                    value: isAnimating ? 
                           (animationIndex / Math.max(1, fullTrajectory.length)) :
                           (optimizationBridge.current_iteration / maxIterations.value)
                }
                
                Label {
                    text: isAnimating ? 
                          ("动画: " + animationIndex + "/" + fullTrajectory.length) :
                          ("进度: " + optimizationBridge.current_iteration)
                    font.pointSize: 8
                    Layout.fillWidth: true
                }
            }
        }
        
        GroupBox {
            title: '优化信息'
            Layout.fillWidth: true
            Layout.fillHeight: true
            font.pointSize: 9
            
            GridLayout {
                anchors.fill: parent
                columns: 2
                columnSpacing: 5
                rowSpacing: 3
                
                Label {
                    text: '迭代'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                Label {
                    text: isAnimating ? animationIndex : optimizationBridge.current_iteration
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    font.pointSize: 8
                    
                    Connections {
                        target: optimizationBridge
                        function onCurrent_iterationChanged() {
                            if (!isAnimating) {
                                if (optimizationBridge.loss_history.length > 0) {
                                    lossChart.updateData(optimizationBridge.loss_history)
                                }
                                if (optimizationBridge.gradient_norm_history.length > 0) {
                                    gradientChart.updateData(optimizationBridge.gradient_norm_history)
                                }
                                if (optimizationBridge.trajectory.length > 0) {
                                    trajectoryChart.updateTrajectory(optimizationBridge.trajectory)
                                }
                            }
                        }
                        
                        function onHas_finishedChanged() {
                            if (optimizationBridge.has_finished && !isAnimating) {
                                fullTrajectory = optimizationBridge.trajectory.slice()
                            }
                        }
                    }
                }
                
                Label {
                    text: '位置'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                Label {
                    text: '(' + optimizationBridge.current_x.toFixed(2) + ',' + 
                          optimizationBridge.current_y.toFixed(2) + ')'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '损失'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                Label {
                    text: optimizationBridge.current_loss.toExponential(2)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '梯度'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                Label {
                    text: optimizationBridge.current_gradient_norm.toExponential(2)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
                
                Label {
                    text: '收敛'
                    Layout.alignment: Qt.AlignHCenter
                    font.pointSize: 8
                }
                Label {
                    text: optimizationBridge.has_converged ? '是' : '否'
                    horizontalAlignment: Text.AlignHCenter
                    color: optimizationBridge.has_converged ? 'green' : 'gray'
                    Layout.fillWidth: true
                    font.pointSize: 8
                }
            }
        }
    }
    
    ColumnLayout {
        // 优化轨迹可视化（等高线图）
        GroupBox {
            title: '优化轨迹 (等高线图)'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ChartView {
                id: trajectoryChart
                anchors.fill: parent
                anchors.margins: 5
                antialiasing: true
                legend.visible: true
                margins.left: 60
                margins.right: 20
                margins.top: 20
                margins.bottom: 50
                
                ValueAxis {
                    id: xAxis
                    min: -2
                    max: 2
                    titleText: "X"
                    labelFormat: "%.1f"
                }
                
                ValueAxis {
                    id: yAxis
                    min: -1
                    max: 3
                    titleText: "Y"
                    labelFormat: "%.1f"
                }
                
                // 等高线近似 - 使用多条散点线
                ScatterSeries {
                    id: contourSeries
                    name: "函数曲面"
                    axisX: xAxis
                    axisY: yAxis
                    markerSize: 2
                    color: "#E0E0E0"
                }
                
                // 优化轨迹
                LineSeries {
                    id: trajectorySeries
                    name: "优化轨迹"
                    axisX: xAxis
                    axisY: yAxis
                    color: "red"
                    width: 2
                }
                
                // 起点标记
                ScatterSeries {
                    id: startPoint
                    name: "起点"
                    axisX: xAxis
                    axisY: yAxis
                    markerSize: 10
                    color: "green"
                }
                
                // 终点标记
                ScatterSeries {
                    id: endPoint
                    name: "当前点"
                    axisX: xAxis
                    axisY: yAxis
                    markerSize: 10
                    color: "blue"
                }
                
                function clearTrajectory() {
                    trajectorySeries.clear()
                    startPoint.clear()
                    endPoint.clear()
                }
                
                function updateTrajectory(trajectory) {
                    if (trajectory.length === 0) return
                    
                    trajectorySeries.clear()
                    startPoint.clear()
                    endPoint.clear()
                    
                    // 添加轨迹点
                    for (let i = 0; i < trajectory.length; i++) {
                        trajectorySeries.append(trajectory[i][0], trajectory[i][1])
                    }
                    
                    // 标记起点和终点
                    if (trajectory.length > 0) {
                        startPoint.append(trajectory[0][0], trajectory[0][1])
                        const last = trajectory[trajectory.length - 1]
                        endPoint.append(last[0], last[1])
                    }
                }
            }
        }
        
        // Loss下降曲线
        GroupBox {
            title: '损失函数下降曲线'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ChartView {
                id: lossChart
                anchors.fill: parent
                anchors.margins: 5
                antialiasing: true
                legend.visible: false
                margins.left: 80
                margins.right: 20
                margins.top: 20
                margins.bottom: 50
                
                ValueAxis {
                    id: lossXAxis
                    min: 0
                    max: 100
                    titleText: "迭代次数"
                    labelFormat: "%d"
                }
                
                LogValueAxis {
                    id: lossYAxis
                    min: 0.0001
                    max: 1000
                    base: 10
                    titleText: "损失值 (对数尺度)"
                    labelFormat: "%.0e"
                }
                
                LineSeries {
                    id: lossSeries
                    axisX: lossXAxis
                    axisY: lossYAxis
                    color: "blue"
                    width: 2
                }
                
                // 当前点标记
                ScatterSeries {
                    id: lossCurrentPoint
                    axisX: lossXAxis
                    axisY: lossYAxis
                    markerSize: 12
                    color: "red"
                }
                
                function reset() {
                    lossSeries.clear()
                    lossCurrentPoint.clear()
                    lossXAxis.max = 100
                }
                
                function updateData(lossHistory) {
                    lossSeries.clear()
                    
                    if (lossHistory.length === 0) return
                    
                    let minLoss = Math.min(...lossHistory)
                    let maxLoss = Math.max(...lossHistory)
                    
                    // 更新Y轴范围
                    lossYAxis.min = Math.max(0.0001, minLoss * 0.1)
                    lossYAxis.max = Math.max(1, maxLoss * 2)
                    
                    // 更新X轴范围
                    lossXAxis.max = Math.max(100, lossHistory.length)
                    
                    // 添加数据点
                    for (let i = 0; i < lossHistory.length; i++) {
                        lossSeries.append(i, Math.max(0.0001, lossHistory[i]))
                    }
                }
                
                function updateCurrentPoint(index) {
                    lossCurrentPoint.clear()
                    if (index >= 0 && index < optimizationBridge.loss_history.length) {
                        lossCurrentPoint.append(index, 
                            Math.max(0.0001, optimizationBridge.loss_history[index]))
                    }
                }
            }
        }
        
        // 梯度范数下降曲线
        GroupBox {
            title: '梯度范数下降曲线'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            ChartView {
                id: gradientChart
                anchors.fill: parent
                anchors.margins: 5
                antialiasing: true
                legend.visible: false
                margins.left: 80
                margins.right: 20
                margins.top: 20
                margins.bottom: 50
                
                ValueAxis {
                    id: gradXAxis
                    min: 0
                    max: 100
                    titleText: "迭代次数"
                    labelFormat: "%d"
                }
                
                LogValueAxis {
                    id: gradYAxis
                    min: 0.0001
                    max: 1000
                    base: 10
                    titleText: "梯度范数 (对数尺度)"
                    labelFormat: "%.0e"
                }
                
                LineSeries {
                    id: gradientSeries
                    axisX: gradXAxis
                    axisY: gradYAxis
                    color: "green"
                    width: 2
                }
                
                function reset() {
                    gradientSeries.clear()
                    gradXAxis.max = 100
                }
                
                function updateData(gradHistory) {
                    gradientSeries.clear()
                    
                    if (gradHistory.length === 0) return
                    
                    let minGrad = Math.min(...gradHistory)
                    let maxGrad = Math.max(...gradHistory)
                    
                    // 更新Y轴范围
                    gradYAxis.min = Math.max(0.0001, minGrad * 0.1)
                    gradYAxis.max = Math.max(1, maxGrad * 2)
                    
                    // 更新X轴范围
                    gradXAxis.max = Math.max(100, gradHistory.length)
                    
                    // 添加数据点
                    for (let i = 0; i < gradHistory.length; i++) {
                        gradientSeries.append(i, Math.max(0.0001, gradHistory[i]))
                    }
                }
            }
        }
    }
    
    function updateContour() {
        // 生成等高线近似点
        contourSeries.clear()
        
        // 根据不同函数调整范围
        let xMin = -2, xMax = 2, yMin = -1, yMax = 3
        
        if (optimizationBridge.test_function === 'sphere') {
            xMin = -3; xMax = 3; yMin = -3; yMax = 3
        } else if (optimizationBridge.test_function === 'beale') {
            xMin = -4.5; xMax = 4.5; yMin = -4.5; yMax = 4.5
        } else if (optimizationBridge.test_function === 'booth') {
            xMin = -10; xMax = 10; yMin = -10; yMax = 10
        }
        
        xAxis.min = xMin
        xAxis.max = xMax
        yAxis.min = yMin
        yAxis.max = yMax
        
        // 生成网格点
        const gridSize = 30
        for (let i = 0; i < gridSize; i++) {
            for (let j = 0; j < gridSize; j++) {
                let x = xMin + (xMax - xMin) * i / gridSize
                let y = yMin + (yMax - yMin) * j / gridSize
                contourSeries.append(x, y)
            }
        }
    }
    
    // 动画定时器
    Timer {
        id: animationTimer
        interval: animationSpeed.value
        running: false
        repeat: true
        onTriggered: {
            if (animationIndex < fullTrajectory.length) {
                updateAnimationFrame(animationIndex)
                animationIndex++
            } else {
                stopAnimation()
            }
        }
    }
    
    // 动画控制函数
    function startAnimation() {
        if (fullTrajectory.length === 0) return
        
        isAnimating = true
        animationIndex = 0
        trajectoryChart.clearTrajectory()
        lossChart.reset()
        animationTimer.start()
    }
    
    function stopAnimation() {
        isAnimating = false
        animationTimer.stop()
    }
    
    function resetVisualization() {
        trajectoryChart.clearTrajectory()
        lossChart.reset()
        gradientChart.reset()
        fullTrajectory = []
        animationIndex = 0
    }
    
    function updateAnimationFrame(index) {
        if (index >= fullTrajectory.length) return
        
        // 更新轨迹（显示到当前帧）
        const partialTrajectory = fullTrajectory.slice(0, index + 1)
        trajectoryChart.updateTrajectory(partialTrajectory)
        
        // 更新loss曲线（如果有数据）
        if (optimizationBridge.loss_history.length > index) {
            const partialLoss = optimizationBridge.loss_history.slice(0, index + 1)
            lossChart.updateData(partialLoss)
            
            // 更新当前点标记
            lossChart.updateCurrentPoint(index)
        }
        
        // 更新梯度曲线
        if (optimizationBridge.gradient_norm_history.length > index) {
            const partialGrad = optimizationBridge.gradient_norm_history.slice(0, index + 1)
            gradientChart.updateData(partialGrad)
        }
    }
    
    Component.onCompleted: {
        updateContour()
    }
}

