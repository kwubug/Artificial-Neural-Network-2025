import numpy as np
import matplotlib.pyplot as plt


class SOM:
    def __init__(self, grid_size=(5, 5), input_dim=4):
        self.grid_size = grid_size
        self.input_dim = input_dim
        # 初始化权重向量为小的随机值
        self.weights = np.random.rand(grid_size[0], grid_size[1], input_dim) * 0.1

    def find_bmu(self, x):
        """
        找到最佳匹配单元(BMU - Best Matching Unit)
        公式: BMU = argmin_j ||x - w_j||
        其中x是输入向量，w_j是第j个神经元的权重向量
        """
        min_dist = float('inf')
        bmu_idx = (0, 0)

        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                # 计算欧几里得距离
                dist = np.linalg.norm(x - self.weights[i, j])
                if dist < min_dist:
                    min_dist = dist
                    bmu_idx = (i, j)
        return bmu_idx

    def get_neighborhood(self, center, radius):
        """
        获取邻域内的神经元索引
        使用高斯邻域函数，距离中心越远的神经元影响越小
        """
        neighbors = []
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                # 计算网格距离
                dist = np.sqrt((i - center[0]) ** 2 + (j - center[1]) ** 2)
                if dist <= radius:
                    neighbors.append((i, j))
        return neighbors

    def train(self, data, total_steps=10000, save_interval=200):
        """
        训练SOM网络

        参数:
        - data: 输入数据
        - total_steps: 总训练步数
        - save_interval: 保存权重的间隔步数

        主要公式:
        1. 学习率: η(t) = η_initial - (η_initial - η_final) * (t/T1) 当 t < T1
                   η(t) = η_final - η_final * ((t-T1)/(T_total-T1)) 当 t >= T1
        2. 邻域半径: σ(t) = σ_initial - σ_initial * (t/T1)
        3. 权重更新: w_ij(t+1) = w_ij(t) + η(t) * h_ij(t) * (x - w_ij(t))
        4. 邻域函数: h_ij(t) = exp(-d_ij^2 / (2σ(t)^2))
        """
        # 存储每200步的权重
        saved_weights = []

        for step in range(total_steps):
            # 计算当前学习率
            if step < 1000:
                # 前1000步线性下降: 0.5 -> 0.04
                learning_rate = 0.5 - (0.5 - 0.04) * (step / 1000)
                # 邻域半径线性下降: 2 -> 0
                neighborhood_radius = 2 - 2 * (step / 1000)
            else:
                # 1000步后继续线性下降至0
                learning_rate = 0.04 - 0.04 * ((step - 1000) / 9000)
                neighborhood_radius = 0

            # 随机选择一个输入模式
            x = data[np.random.randint(len(data))]

            # 找到BMU
            bmu_idx = self.find_bmu(x)

            # 获取邻域内的神经元
            neighbors = self.get_neighborhood(bmu_idx, neighborhood_radius)

            # 更新权重
            for i, j in neighbors:
                # 计算神经元(i,j)与BMU的网格距离
                distance = np.sqrt((i - bmu_idx[0]) ** 2 + (j - bmu_idx[1]) ** 2)

                # 计算邻域函数（高斯函数）
                # h_ij(t) = exp(-d_ij^2 / (2σ(t)^2))
                if neighborhood_radius > 0:
                    influence = np.exp(-distance ** 2 / (2 * neighborhood_radius ** 2))
                else:
                    # 当邻域半径为0时，只有BMU本身被更新
                    influence = 1.0 if (i, j) == bmu_idx else 0.0

                # 更新权重: w_ij(t+1) = w_ij(t) + η(t) * h_ij(t) * (x - w_ij(t))
                self.weights[i, j] += learning_rate * influence * (x - self.weights[i, j])

            # 每200步保存一次权重
            if step % save_interval == 0:
                saved_weights.append(self.weights.copy())
                print(
                    f"Step {step}: Learning rate = {learning_rate:.4f}, Neighborhood radius = {neighborhood_radius:.4f}")

        return saved_weights

    def map_data(self, data):
        """将数据映射到输出平面"""
        mappings = []
        for x in data:
            bmu_idx = self.find_bmu(x)
            mappings.append(bmu_idx)
        return mappings


# 输入数据
X1 = np.array([1, 0, 0, 0])
X2 = np.array([1, 1, 0, 0])
X3 = np.array([1, 1, 1, 0])  # 与X2不同
X4 = np.array([0, 1, 0, 0])
X5 = np.array([1, 1, 1, 1])

data = np.array([X1, X2, X3, X4, X5])

print("输入数据:")
for i, x in enumerate(data):
    print(f"X{i + 1} = {x}")

# 设置随机种子以便结果可重现
np.random.seed(42)

# 创建并训练SOM
som = SOM(grid_size=(5, 5), input_dim=4)
saved_weights = som.train(data, total_steps=10000, save_interval=200)

# 获取最终映射结果
final_mappings = som.map_data(data)

# 可视化结果
plt.figure(figsize=(15, 10))

# 绘制最终映射图
plt.subplot(2, 3, 1)
for i, mapping in enumerate(final_mappings):
    plt.scatter(mapping[1], mapping[0], s=200, label=f'X{i + 1}')
    plt.text(mapping[1], mapping[0], f'X{i + 1}', fontsize=12, ha='center', va='center')

plt.xlim(-0.5, 4.5)
plt.ylim(-0.5, 4.5)
plt.grid(True)
plt.title('Final Mapping of Input Patterns')
plt.xlabel('Column Index')
plt.ylabel('Row Index')
plt.legend()

# 绘制几个训练阶段的权重变化
selected_steps = [0, 200, 1000, 5000, 10000]
for idx, step in enumerate(selected_steps):
    if step == 10000:
        weights_to_plot = som.weights
        title = f'Step {step} (Final)'
    else:
        weight_idx = step // 200
        if weight_idx < len(saved_weights):
            weights_to_plot = saved_weights[weight_idx]
            title = f'Step {step}'
        else:
            continue

    plt.subplot(2, 3, idx + 2)

    # 可视化权重向量的第一个分量
    plt.imshow(weights_to_plot[:, :, 0], cmap='viridis', aspect='equal')
    plt.colorbar(label='Weight Value (1st component)')
    plt.title(title)

    # 标记神经元位置
    for i in range(5):
        for j in range(5):
            plt.text(j, i, f'({i},{j})', ha='center', va='center',
                     color='white' if weights_to_plot[i, j, 0] > 0.5 else 'black', fontsize=8)

plt.tight_layout()
plt.show()

# 打印详细的映射结果
print("\n最终映射结果:")
print("=" * 40)
for i, (pattern, mapping) in enumerate(zip(data, final_mappings)):
    print(f"X{i + 1} = {pattern} -> 神经元位置: {mapping}")

# 分析权重向量的相似性
print("\n权重向量分析:")
print("=" * 40)
for i in range(5):
    for j in range(5):
        print(f"神经元({i},{j})权重: {som.weights[i, j].round(3)}")

# 计算输入模式与对应BMU权重的相似度
print("\n输入模式与对应BMU权重的相似度:")
print("=" * 40)
for i, (pattern, mapping) in enumerate(zip(data, final_mappings)):
    bmu_weights = som.weights[mapping[0], mapping[1]]
    similarity = np.dot(pattern, bmu_weights) / (np.linalg.norm(pattern) * np.linalg.norm(bmu_weights))
    print(f"X{i + 1} 与 BMU权重 的余弦相似度: {similarity:.4f}")

# 绘制输入模式的相似性分析
plt.figure(figsize=(10, 8))

# 计算输入模式之间的欧几里得距离矩阵
distance_matrix = np.zeros((5, 5))
for i in range(5):
    for j in range(5):
        distance_matrix[i, j] = np.linalg.norm(data[i] - data[j])

plt.subplot(1, 2, 1)
plt.imshow(distance_matrix, cmap='viridis', interpolation='nearest')
plt.colorbar(label='Euclidean Distance')
plt.title('Input Pattern Distance Matrix')
plt.xticks(range(5), [f'X{i + 1}' for i in range(5)])
plt.yticks(range(5), [f'X{i + 1}' for i in range(5)])

# 添加距离数值
for i in range(5):
    for j in range(5):
        plt.text(j, i, f'{distance_matrix[i, j]:.2f}', ha='center', va='center',
                 color='white' if distance_matrix[i, j] > 0.5 else 'black')

# 绘制输出映射的距离关系
plt.subplot(1, 2, 2)
mapping_coords = np.array(final_mappings)
for i in range(5):
    plt.scatter(mapping_coords[i, 1], mapping_coords[i, 0], s=200, label=f'X{i + 1}')
    plt.text(mapping_coords[i, 1], mapping_coords[i, 0], f'X{i + 1}', fontsize=12, ha='center', va='center')

plt.xlim(-0.5, 4.5)
plt.ylim(-0.5, 4.5)
plt.grid(True)
plt.title('Output Mapping Topology')
plt.xlabel('Column Index')
plt.ylabel('Row Index')
plt.legend()

plt.tight_layout()
plt.show()