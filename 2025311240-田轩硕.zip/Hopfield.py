import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Qt5Agg')  # 或 'TkAgg'
import matplotlib.pyplot as plt

# 解决matplotlib中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']  # 适配中文字体
plt.rcParams['axes.unicode_minus'] = False    # 正常显示负号

class DiscreteHopfieldNetwork:
    def __init__(self, num_neurons):
        """
        初始化网络
        :param num_neurons: 神经元数量（输入/输出向量维度）
        """
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))  # 权值矩阵 (n×n)
        self.state = np.zeros(num_neurons)  # 神经元当前状态（1 或 -1）

    def train(self, training_patterns):
        """
        训练网络：通过 Hebbian 规则计算权值矩阵
        """
        num_samples = len(training_patterns)
        if num_samples == 0:
            raise ValueError("训练样本不能为空！")

        # 验证样本有效性（维度匹配 + 元素值合法）
        for idx, pattern in enumerate(training_patterns):
            if len(pattern) != self.num_neurons:
                raise ValueError(f"样本 {idx+1} 维度错误！期望 {self.num_neurons} 维，实际 {len(pattern)} 维")
            if not set(pattern).issubset({1, -1}):
                raise ValueError(f"样本 {idx+1} 元素值非法！仅支持 1 和 -1")

        # 计算权值矩阵：累加每个样本的外积，再除以样本数
        for pattern in training_patterns:
            pattern_col = pattern.reshape(-1, 1)  # 转换为列向量
            self.weights += np.dot(pattern_col, pattern_col.T)  # 外积计算

        # 归一化 + 对角线置 0（无自连接）
        self.weights /= num_samples
        np.fill_diagonal(self.weights, 0)

        print(f"训练完成！权值矩阵形状：{self.weights.shape}")

    def _update_neuron(self, neuron_idx):
        """
        异步更新单个神经元状态
        """
        # 计算输入总和
        net_input = np.dot(self.weights[neuron_idx], self.state)
        # 计算新状态
        new_state = 1 if net_input >= 0 else -1
        # 检查状态变化
        state_changed = (new_state != self.state[neuron_idx])
        # 更新状态
        self.state[neuron_idx] = new_state
        return state_changed

    def predict(self, input_pattern, max_iter=1000, verbose=False):
        """
        预测：输入模式 -> 异步更新 -> 收敛到吸引子
        :param input_pattern: 输入模式（长度为 num_neurons 的向量，元素为 1 或 -1）
        :param max_iter: 最大迭代次数（防止无限循环）
        :param verbose: 是否打印迭代过程信息（状态 + 能量）
        :return: 收敛后的状态（吸引子）
        """
        # 验证输入模式有效性
        if len(input_pattern) != self.num_neurons:
            raise ValueError(f"输入模式维度错误！期望 {self.num_neurons} 维，实际 {len(input_pattern)} 维")
        if not set(input_pattern).issubset({1, -1}):
            raise ValueError("输入模式元素值非法！仅支持 1 和 -1")

        # 初始化网络状态
        self.state = np.array(input_pattern, dtype=int)
        initial_energy = self.calculate_energy()

        if verbose:
            print("=" * 50)
            print("预测开始")
            print(f"初始状态：{self.state}")
            print(f"初始能量：{initial_energy:.4f}")
            print("=" * 50)

        iter_count = 0
        state_changed = True  # 标记是否有神经元状态变化

        # 迭代更新直到收敛（无状态变化）或达到最大迭代次数
        while state_changed and iter_count < max_iter:
            state_changed = False  # 重置变化标记
            # 随机顺序更新所有神经元（异步更新的核心：避免同步更新的极限环）
            neuron_indices = list(range(self.num_neurons))
            random.shuffle(neuron_indices)

            # 逐个更新神经元
            for idx in neuron_indices:
                if self._update_neuron(idx):
                    state_changed = True  # 只要有一个神经元变化，就标记为变化

            iter_count += 1

            # 打印迭代信息（每 100 次或收敛时）
            if verbose and (iter_count % 100 == 0 or not state_changed):
                current_energy = self.calculate_energy()
                print(f"迭代 {iter_count:4d} | 状态：{self.state} | 能量：{current_energy:.4f}")

        # 检查是否达到最大迭代次数
        if iter_count >= max_iter and state_changed:
            print(f"警告：已达到最大迭代次数 {max_iter}，网络可能未完全收敛！")
        elif verbose:
            print("=" * 50)
            print(f"预测结束，共迭代 {iter_count} 次，收敛到吸引子")
            print("=" * 50)

        return self.state.copy()  # 返回收敛后的状态（吸引子）

    def calculate_energy(self):
        """
        计算当前网络状态的能量函数值
        能量公式：E = -0.5 * sum_{i,j} (W[i][j] * s[i] * s[j])
        意义：能量越低，网络状态越稳定；每次异步更新后能量非递增（保证收敛）
        :return: float - 能量值
        """
        energy = -0.5 * np.dot(np.dot(self.state.T, self.weights), self.state)
        return energy

    def visualize_pattern(self, pattern, title="模式可视化"):
        """
        可视化模式（适用于图像类模式，如字母、数字，要求神经元数量为完全平方数）
        :param pattern: 待可视化的模式（长度为 num_neurons 的向量）
        :param title: 图像标题
        """
        # 验证模式维度
        if len(pattern) != self.num_neurons:
            raise ValueError(f"模式维度错误！期望 {self.num_neurons} 维，实际 {len(pattern)} 维")

        # 检查是否能转换为方阵（神经元数量为完全平方数）
        size = int(np.sqrt(self.num_neurons))
        if size * size != self.num_neurons:
            print(f"警告：神经元数量 {self.num_neurons} 不是完全平方数，无法以方阵形式可视化！")
            return

        # 转换为方阵并可视化
        pattern_matrix = pattern.reshape(size, size)
        plt.figure(figsize=(4, 4))
        # 二进制颜色映射（1 为白色，-1 为黑色）
        plt.imshow(pattern_matrix, cmap="binary", interpolation="nearest", vmin=-1, vmax=1)
        plt.title(title, fontsize=12)
        plt.xticks([])  # 隐藏 x 轴刻度
        plt.yticks([])  # 隐藏 y 轴刻度
        plt.show()


# ------------------------------
# 演示：Hopfield 网络联想记忆（字母识别）
# 任务：存储字母 A、B、C，输入带噪声的字母，测试网络恢复能力
# ------------------------------
if __name__ == "__main__":
    # 1. 定义训练模式（5x5 像素字母，展平为 25 维向量，1=白色，-1=黑色）
    letter_A = np.array([
        -1, 1, 1, 1, -1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, 1,
        1, -1, -1, -1, 1,
        1, -1, -1, -1, 1
    ])

    letter_B = np.array([
        1, 1, 1, 1, -1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, -1,
        1, -1, -1, -1, 1,
        1, 1, 1, 1, -1
    ])

    letter_C = np.array([
        -1, 1, 1, 1, 1,
        1, -1, -1, -1, -1,
        1, -1, -1, -1, -1,
        1, -1, -1, -1, -1,
        -1, 1, 1, 1, 1
    ])

    training_patterns = [letter_A, letter_B, letter_C]
    num_neurons = 25  # 5x5=25 个神经元

    # 2. 创建并训练网络
    hnn = DiscreteHopfieldNetwork(num_neurons=num_neurons)
    hnn.train(training_patterns)

    # 3. 可视化训练模式
    print("\n" + "=" * 50)
    print("训练模式可视化")
    print("=" * 50)
    hnn.visualize_pattern(letter_A, title="训练模式 - 字母 A")
    hnn.visualize_pattern(letter_B, title="训练模式 - 字母 B")
    hnn.visualize_pattern(letter_C, title="训练模式 - 字母 C")

    # 4. 定义噪声添加函数（翻转部分像素）
    def add_noise(pattern, noise_ratio=0.2):
        """
        为模式添加噪声
        :param pattern: 原始模式
        :param noise_ratio: 噪声比例（0~1，例如 0.2 表示 20% 的像素被翻转）
        :return: 带噪声的模式
        """
        noisy_pattern = pattern.copy()
        num_noise = int(len(pattern) * noise_ratio)
        # 随机选择要翻转的像素索引
        noise_indices = random.sample(range(len(pattern)), num_noise)
        for idx in noise_indices:
            noisy_pattern[idx] *= -1  # 翻转像素（1↔-1）
        return noisy_pattern

    # 5. 测试：输入带噪声的模式，验证网络恢复能力
    print("\n" + "=" * 50)
    print("联想记忆测试（30% 噪声）")
    print("=" * 50)

    # 测试 1：带噪声的字母 A
    print("\n【测试 1：带噪声的字母 A】")
    noisy_A = add_noise(letter_A, noise_ratio=0.3)  # 30% 噪声
    hnn.visualize_pattern(noisy_A, title="输入模式 - 带噪声的 A（30%）")
    recovered_A = hnn.predict(noisy_A, verbose=True)
    hnn.visualize_pattern(recovered_A, title="恢复模式 - 字母 A")
    is_recovered_A = np.array_equal(recovered_A, letter_A)
    print(f"字母 A 恢复成功：{is_recovered_A}")

    # 测试 2：带噪声的字母 B
    print("\n【测试 2：带噪声的字母 B】")
    noisy_B = add_noise(letter_B, noise_ratio=0.3)  # 30% 噪声
    hnn.visualize_pattern(noisy_B, title="输入模式 - 带噪声的 B（30%）")
    recovered_B = hnn.predict(noisy_B, verbose=True)
    hnn.visualize_pattern(recovered_B, title="恢复模式 - 字母 B")
    is_recovered_B = np.array_equal(recovered_B, letter_B)
    print(f"字母 B 恢复成功：{is_recovered_B}")

    # 测试 3：带噪声的字母 C
    print("\n【测试 3：带噪声的字母 C】")
    noisy_C = add_noise(letter_C, noise_ratio=0.3)  # 30% 噪声
    hnn.visualize_pattern(noisy_C, title="输入模式 - 带噪声的 C（30%）")
    recovered_C = hnn.predict(noisy_C, verbose=True)
    hnn.visualize_pattern(recovered_C, title="恢复模式 - 字母 C")
    is_recovered_C = np.array_equal(recovered_C, letter_C)
    print(f"字母 C 恢复成功：{is_recovered_C}")

    print("\n" + "=" * 50)
    print("所有测试完成！")
    print("=" * 50)