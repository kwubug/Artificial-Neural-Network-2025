import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid , sigmoid1


class MlpAlgorithm(PredictiveAlgorithm):

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.1, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight
        self.sigmod = 1
        self.network_shape = network_shape if network_shape else (4, 4)
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)
        self.p = 1
        self.q = 1

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]),
                                     result)

        print(f'p:{self.p}')
        self.p = self.p + 1

        self._adjust_synaptic_weights(deltas)

    def _initialize_neurons(self):
        if self.sigmod == 1:
            self._neurons = tuple((Perceptron(sigmoid),) * size
                                  for size in list(self.network_shape) + [1])
        else:
            self._neurons = tuple((Perceptron(sigmoid1),) * size
                                  for size in list(self.network_shape) + [1])

    def _feed_forward(self, data):
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    def _pass_backward(self, expect, result):
        self.q = 1
        deltas = {}

        if self.sigmod == 1:
            deltas[self._neurons[-1][0]] = (expect - result) * result * (1 - result)
        else:
            deltas[self._neurons[-1][0]] = (expect - result) * (1 - result ** 2)

        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                if self.sigmod == 1:
                    derivative = neuron.result * (1 - neuron.result)
                else:
                    derivative = (1 - neuron.result ** 2)

                deltas[neuron] = (
                        sum(deltas[n] * n.synaptic_weight[neuron_idx]
                            for n in self._neurons[layer_idx + 1])
                        * derivative
                )
                self.q += 1
                print(f'q:{self.q}')
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))


def get_layer_results(layer, data):
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)
