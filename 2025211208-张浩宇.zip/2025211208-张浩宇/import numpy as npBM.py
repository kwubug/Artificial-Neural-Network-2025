import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.patches as patches
import time

# 基础字体配置（确保无警告）
plt.rcParams["font.family"] = ["SimHei", "SimSun"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["animation.html"] = "jshtml"  # 确保动画在所有环境可渲染


class BMAnimation:
    def __init__(self):
        # BM核心参数
        self.n_neurons = 3
        self.weights = np.array([[0, 1.2, -0.8],
                                 [1.2, 0, 0.5],
                                 [-0.8, 0.5, 0]])  # 增强权重差异，让状态变化更明显
        self.biases = np.array([0.3, -0.2, 0.5])
        self.temp = 1.0  # 降低温度，加速收敛，状态变化更显著
        self.state = np.array([1, -1, 1])  # 初始状态

        # 记录历史（增加初始数据点）
        self.states = [self.state.copy()]
        self.energies = [self.get_energy()]

        # 创建画布（使用TkAgg后端确保动画兼容性）
        plt.switch_backend('TkAgg')  # 强制使用Tkinter渲染，解决大部分动画不播放问题
        self.fig, (self.ax_net, self.ax_energy) = plt.subplots(1, 2, figsize=(12, 6))
        self.fig.suptitle('三个神经元BM动态运行过程', fontsize=16)

        # 初始化网络可视化
        self.init_network_plot()

        # 初始化能量曲线
        self.init_energy_plot()

        # 动画控制变量
        self.iteration = 0
        self.animation = None

    def get_energy(self, state=None):
        """计算能量（核心公式）"""
        if state is None:
            state = self.state
        return -0.5 * np.dot(state.T, np.dot(self.weights, state)) - np.dot(self.biases, state)

    def update_neuron(self):
        """更新神经元状态（让变化更频繁）"""
        # 每次更新随机选择2个神经元，加速状态变化
        for _ in range(2):
            idx = np.random.randint(self.n_neurons)
            activation = np.dot(self.weights[idx], self.state) + self.biases[idx]
            prob = 1 / (1 + np.exp(-2 * activation / self.temp))
            self.state[idx] = 1 if np.random.rand() < prob else -1
        return self.state.copy()

    def init_network_plot(self):
        """神经元网络可视化（布局更清晰）"""
        self.positions = np.array([[1, 1], [4, 1], [2.5, 3.5]])  # 大三角形布局，便于观察
        self.circles = [
            patches.Circle(pos, 0.6, edgecolor='black', linewidth=3)
            for pos in self.positions
        ]
        for c in self.circles:
            self.ax_net.add_patch(c)

        # 神经元连接线（初始显示）
        self.connections = [(0, 1), (0, 2), (1, 2)]
        self.lines = [self.ax_net.plot([], [], linewidth=2)[0] for _ in range(3)]
        for i, (a, b) in enumerate(self.connections):
            x = [self.positions[a][0], self.positions[b][0]]
            y = [self.positions[a][1], self.positions[b][1]]
            self.lines[i].set_data(x, y)

        # 神经元标签
        for i, pos in enumerate(self.positions):
            self.ax_net.text(pos[0], pos[1], f'N{i + 1}',
                             ha='center', va='center', fontsize=12, fontweight='bold')

        self.ax_net.set_xlim(0, 5)
        self.ax_net.set_ylim(0, 4)
        self.ax_net.set_aspect('equal')
        self.ax_net.set_title('神经元状态（红=激活，蓝=抑制）')
        self.ax_net.axis('off')

    def init_energy_plot(self):
        """能量曲线（实时刷新）"""
        self.energy_line, = self.ax_energy.plot([0], [self.energies[0]], 'b-', linewidth=2)
        self.ax_energy.set_xlabel('迭代次数', fontsize=10)
        self.ax_energy.set_ylabel('系统能量', fontsize=10)
        self.ax_energy.set_title('能量变化（趋于稳定即平衡）', fontsize=10)
        self.ax_energy.grid(alpha=0.3)
        self.ax_energy.set_xlim(0, 100)  # 固定x轴范围，避免闪烁

    def animate(self, frame):
        """动画核心更新函数（强制刷新）"""
        self.iteration += 1
        # 更新状态
        new_state = self.update_neuron()
        self.states.append(new_state)
        new_energy = self.get_energy()
        self.energies.append(new_energy)

        # 更新神经元颜色（明显的颜色对比）
        for i, c in enumerate(self.circles):
            c.set_facecolor('crimson' if new_state[i] == 1 else 'deepskyblue')

        # 更新连接线（权重可视化更明显）
        for i, (a, b) in enumerate(self.connections):
            w = self.weights[a][b]
            self.lines[i].set_linewidth(abs(w) * 1.5)  # 线宽放大，更易观察
            self.lines[i].set_color('limegreen' if w > 0 else 'purple')  # 鲜明颜色

        # 更新能量曲线（强制重绘）
        self.energy_line.set_data(range(len(self.energies)), self.energies)
        self.ax_energy.set_ylim(min(self.energies) - 0.5, max(self.energies) + 0.5)  # 动态调整y轴
        self.ax_energy.draw_artist(self.ax_energy.patch)  # 强制刷新背景
        self.ax_energy.draw_artist(self.energy_line)  # 强制刷新曲线

        # 显示迭代进度
        self.ax_net.set_title(f'迭代 {self.iteration}/100 | 状态: {new_state}', fontsize=10)

        # 强制画布更新
        self.fig.canvas.draw_idle()
        return self.circles + self.lines + [self.energy_line]

    def run(self):
        """运行动画（优化参数确保流畅）"""
        self.animation = FuncAnimation(
            self.fig,
            self.animate,
            frames=100,  # 固定100帧，确保足够的动画时长
            interval=150,  # 150ms/帧，速度适中
            init_func=lambda: self.circles + self.lines + [self.energy_line],
            blit=False,  # 关闭blit，确保所有环境都能渲染
            repeat=False  # 不重复播放，便于观察最终状态
        )

        plt.tight_layout()
        plt.subplots_adjust(top=0.9)
        plt.show()

        # 输出平衡状态
        final_state = self.states[-1]
        final_energy = self.energies[-1]
        print(f"\n最终热平衡状态: {final_state}")
        print(f"对应能量值: {final_energy:.4f}")


if __name__ == "__main__":
    # 确保动画运行的兼容性处理
    try:
        bm = BMAnimation()
        bm.run()
    except Exception as e:
        print(f"动画启动失败: {e}")
        # 备用方案：显示静态步骤图
        print("显示静态过程图...")
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.text(0.5, 0.5, "BM运行过程（示例）\n1. 神经元状态不断更新\n2. 能量逐渐稳定\n3. 最终达到热平衡",
                ha='center', va='center', fontsize=12)
        ax.axis('off')
        plt.show()