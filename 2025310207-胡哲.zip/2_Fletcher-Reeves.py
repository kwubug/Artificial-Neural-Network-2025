import numpy as np
import matplotlib.pyplot as plt


# 定义目标函数 F(x) = 1/2 * x^T * A * x
def F(x):
    A = np.array([[2, 1], [1, 2]])  # 系数矩阵
    return 0.5 * np.dot(x.T, np.dot(A, x))


# 定义梯度函数 ∇F(x)
def grad_F(x):
    A = np.array([[2, 1], [1, 2]])
    return np.dot(A, x)


# Fletcher–Reeves 共轭梯度算法
def fletcher_reeves(start, max_iter=20, tol=1e-6, plot_interval=1):
    """
    实现 Fletcher-Reeves 共轭梯度法，并在每个时间步显示3D图像。
    plot_interval: 每隔多少步绘制一次（1 = 每步都显示）
    """
    x = np.array(start, dtype=float)
    grad = grad_F(x)
    p = -grad  # 初始方向
    path = [x.copy()]

    for i in range(max_iter):
        A = np.array([[2, 1], [1, 2]])

        # ✅ 正确的步长公式：alpha = -(g^T p) / (p^T A p)
        alpha = -np.dot(grad, p) / np.dot(p, np.dot(A, p))

        # 更新位置
        x = x + alpha * p
        grad_new = grad_F(x)

        # 记录轨迹
        path.append(x.copy())

        # 判断收敛
        if np.linalg.norm(grad_new) < tol:
            print(f"✅ 在第 {i} 步收敛: x = {x}, F(x) = {F(x):.6f}")
            visualize_path(path, i)
            break

        # 更新方向 (Fletcher-Reeves 公式)
        beta = np.dot(grad_new, grad_new) / np.dot(grad, grad)
        p = -grad_new + beta * p

        grad = grad_new

        # ✅ 控制显示频率
        if i % plot_interval == 0:
            visualize_path(path, i)

    return np.array(path)


# 绘制路径的3D图像（不保存，只显示）
def visualize_path(path, step):
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')

    # 绘制目标函数曲面
    x_vals = np.linspace(-2, 2, 100)
    y_vals = np.linspace(-2, 2, 100)
    X, Y = np.meshgrid(x_vals, y_vals)
    Z = 0.5 * (2 * X ** 2 + 2 * Y ** 2 + 2 * X * Y)

    ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.6)

    # 绘制优化路径
    path = np.array(path)
    Z_path = 0.5 * (2 * path[:, 0] ** 2 + 2 * path[:, 1] ** 2 + 2 * path[:, 0] * path[:, 1])
    ax.plot(path[:, 0], path[:, 1], Z_path, marker='o', color='yellow', label='Optimization Path')

    ax.set_title(f'Fletcher-Reeves Optimization (Step {step})')
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('F(x)')
    ax.legend()

    plt.show()
    plt.close()


# 主程序
if __name__ == "__main__":
    start_point = [0.8, -0.25]
    path = fletcher_reeves(start_point, max_iter=20, plot_interval=1)
    print("🎨 Fletcher-Reeves 迭代图像已显示完成。")
