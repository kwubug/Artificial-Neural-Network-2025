import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BmAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BmBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.1)
    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(100)
    initial_temperature = BridgeProperty(10.0)
    cooling_rate = BridgeProperty(0.95)
    min_temperature = BridgeProperty(0.1)
    num_neurons = BridgeProperty(3)
    current_iterations = BridgeProperty(0)
    current_temperature = BridgeProperty(10.0)
    current_energy = BridgeProperty(0.0)
    current_neuron_states = BridgeProperty([])
    equilibrium_reached = BridgeProperty(False)
    energy_history = BridgeProperty([])
    state_history = BridgeProperty([])
    weights = BridgeProperty([])
    biases = BridgeProperty([])
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.bm_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm_algorithm(self):
        self.bm_algorithm = ObservableBmAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=[],  # BM算法不需要数据集
            total_epoches=self.total_epoches,
            initial_temperature=self.initial_temperature,
            cooling_rate=self.cooling_rate,
            min_temperature=self.min_temperature,
            num_neurons=self.num_neurons
        )
        self.bm_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()


class ObservableBmAlgorithm(Observable, BmAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BmAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
        elif name == 'current_temperature':
            self.notify(name, value)
        elif name == 'current_energy':
            self.notify(name, value)
        elif name == 'equilibrium_reached':
            self.notify(name, value)
        elif name == '_neuron_states':
            self.notify('current_neuron_states', value.tolist())
        elif name == '_energy_history':
            self.notify('energy_history', value)
        elif name == '_state_history':
            self.notify('state_history', [state.tolist() for state in value])
        elif name == '_weights':
            self.notify('weights', value.tolist())
        elif name == '_biases':
            self.notify('biases', value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('equilibrium_reached', False)
        # 初始化时通知初始状态
        self._notify_all_states()
        super().run()
        self.notify('has_finished', True)
        # 确保最后通知一次所有状态
        self._notify_all_states()
    
    def _notify_all_states(self):
        """通知所有状态到UI"""
        self.notify('current_neuron_states', self._neuron_states.tolist())
        self.notify('current_energy', self.current_energy)
        self.notify('current_temperature', self.current_temperature)
        self.notify('current_iterations', self.current_iterations)
        self.notify('equilibrium_reached', self.equilibrium_reached)
        self.notify('energy_history', self._energy_history)
        self.notify('state_history', [state.tolist() for state in self._state_history])
        self.notify('weights', self._weights.tolist())
        self.notify('biases', self._biases.tolist())

    def _iterate(self):
        super()._iterate()
        # 通知UI更新
        self.notify('current_iterations', self.current_iterations)
        self.notify('current_temperature', self.current_temperature)
        self.notify('current_energy', self.current_energy)
        self.notify('current_neuron_states', self._neuron_states.tolist())
        self.notify('equilibrium_reached', self.equilibrium_reached)
        self.notify('energy_history', self._energy_history)
        self.notify('state_history', [state.tolist() for state in self._state_history])
        # 保持GUI响应
        time.sleep(self.ui_refresh_interval)

