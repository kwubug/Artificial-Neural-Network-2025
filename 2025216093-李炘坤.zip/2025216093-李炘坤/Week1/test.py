import numpy as np
import matplotlib.pyplot as plt

class SingleLayerNeuralNetwork:
    def __init__(self, input_size=6, learning_rate=0.1):
        self.input_size = input_size
        self.learning_rate = learning_rate
        self.weights = np.random.uniform(-0.5, 0.5, input_size + 1)  # +1 for bias
        self.training_history = []
    
    def activation_function(self, x, func_type='sigmoid'):
        """选择不同的激活函数"""
        if func_type == 'sigmoid':
            return 1 / (1 + np.exp(-x))
        elif func_type == 'tanh':
            return np.tanh(x)
        elif func_type == 'relu':
            return np.maximum(0, x)
        elif func_type == 'linear':
            return x
        elif func_type == 'step':
            return 1 if x >= 0 else 0
        else:
            raise ValueError("不支持的激活函数类型")
    
    def activation_derivative(self, x, func_type='sigmoid'):
        """激活函数的导数"""
        if func_type == 'sigmoid':
            sig = self.activation_function(x, 'sigmoid')
            return sig * (1 - sig)
        elif func_type == 'tanh':
            return 1 - np.tanh(x)**2
        elif func_type == 'relu':
            return 1 if x > 0 else 0
        elif func_type == 'linear':
            return 1
        elif func_type == 'step':
            return 0  # 阶跃函数导数在0处未定义，这里返回0
        else:
            raise ValueError("不支持的激活函数类型")
    
    def net_input(self, inputs):
        """计算净输入"""
        inputs_with_bias = np.insert(inputs, 0, 1)  # 添加偏置项
        return np.dot(inputs_with_bias, self.weights)
    
    def predict(self, inputs, activation_func='sigmoid'):
        """预测输出"""
        net = self.net_input(inputs)
        return self.activation_function(net, activation_func), net
    
    def train_delta_rule(self, training_data, targets, epochs=100, activation_func='sigmoid', verbose=True):
        """Delta学习规则（有监督学习）"""
        print(f"开始训练 - Delta规则，激活函数: {activation_func}")
        print(f"初始权重: {self.weights}")
        
        for epoch in range(epochs):
            total_error = 0
            epoch_details = []
            
            for i, (inputs, target) in enumerate(zip(training_data, targets)):
                # 前向传播
                output, net_input = self.predict(inputs, activation_func)
                error = target - output
                total_error += error**2
                
                # 计算权重调整
                inputs_with_bias = np.insert(inputs, 0, 1)
                if activation_func == 'step':
                    # 对于阶跃函数，使用感知器学习规则
                    delta_weights = self.learning_rate * error * inputs_with_bias
                else:
                    # Delta规则
                    derivative = self.activation_derivative(net_input, activation_func)
                    delta_weights = self.learning_rate * error * derivative * inputs_with_bias
                
                # 更新权重
                old_weights = self.weights.copy()
                self.weights += delta_weights
                
                # 记录训练细节
                epoch_details.append({
                    'sample': i+1,
                    'inputs': inputs,
                    'target': target,
                    'net_input': net_input,
                    'output': output,
                    'error': error,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights
                })
            
            # 记录每个epoch的信息
            self.training_history.append({
                'epoch': epoch + 1,
                'total_error': total_error / len(training_data),
                'details': epoch_details
            })
            
            # 输出训练信息
            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1}: 平均误差 = {total_error / len(training_data):.6f}")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch)
            
            # 检查收敛
            if total_error / len(training_data) < 0.001:
                print(f"训练在第 {epoch + 1} 轮收敛")
                break
    
    def train_hebb_rule(self, training_data, epochs=100, activation_func='sigmoid', verbose=True):
        """Hebb学习规则（无监督学习）"""
        print(f"开始训练 - Hebb规则，激活函数: {activation_func}")
        print(f"初始权重: {self.weights}")
        
        for epoch in range(epochs):
            epoch_details = []
            
            for i, inputs in enumerate(training_data):
                # 前向传播
                output, net_input = self.predict(inputs, activation_func)
                
                # Hebb规则：权重调整与输入和输出相关
                inputs_with_bias = np.insert(inputs, 0, 1)
                delta_weights = self.learning_rate * output * inputs_with_bias
                
                # 更新权重
                old_weights = self.weights.copy()
                self.weights += delta_weights
                
                # 记录训练细节
                epoch_details.append({
                    'sample': i+1,
                    'inputs': inputs,
                    'net_input': net_input,
                    'output': output,
                    'old_weights': old_weights,
                    'new_weights': self.weights.copy(),
                    'delta_weights': delta_weights
                })
            
            self.training_history.append({
                'epoch': epoch + 1,
                'details': epoch_details
            })
            
            if verbose and (epoch == 0 or (epoch + 1) % 10 == 0 or epoch == epochs - 1):
                print(f"Epoch {epoch + 1} 完成")
                if epoch == 0 or epoch == epochs - 1:
                    self._print_epoch_details(epoch, rule='hebb')
    
    def _print_epoch_details(self, epoch, rule='delta'):
        """打印训练细节"""
        print(f"\n--- Epoch {epoch + 1} 详细训练过程 ---")
        details = self.training_history[epoch]['details']
        
        for detail in details:
            print(f"样本 {detail['sample']}:")
            print(f"  输入: {detail['inputs']}")
            print(f"  净输入: {detail['net_input']:.4f}")
            
            if rule == 'delta':
                print(f"  目标输出: {detail['target']}")
                print(f"  实际输出: {detail['output']:.4f}")
                print(f"  误差: {detail['error']:.4f}")
            
            print(f"  权重调整前: {detail['old_weights']}")
            print(f"  权重调整量: {detail['delta_weights']}")
            print(f"  权重调整后: {detail['new_weights']}")
            print()
    
    def plot_training_history(self):
        """绘制训练误差曲线"""
        if not self.training_history:
            print("没有训练历史数据")
            return
        
        errors = [epoch['total_error'] for epoch in self.training_history if 'total_error' in epoch]
        if errors:
            plt.figure(figsize=(10, 6))
            plt.plot(range(1, len(errors) + 1), errors)
            plt.xlabel('Epoch')
            plt.ylabel('平均误差')
            plt.title('训练误差曲线')
            plt.grid(True)
            plt.show()

# 测试函数
def test_neural_network():
    # 创建神经网络实例
    nn = SingleLayerNeuralNetwork(input_size=6, learning_rate=0.1)
    
    # 测试数据1: AND逻辑函数（扩展到6输入）
    print("=" * 60)
    print("测试1: AND逻辑函数")
    print("=" * 60)
    
    # 生成训练数据
    training_data_and = np.array([
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 1],
        [0, 0, 0, 0, 1, 0],
        [0, 0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0, 0],
        [0, 1, 0, 0, 0, 0],
        [1, 0, 0, 0, 0, 0],
        [1, 1, 1, 1, 1, 1]
    ])
    
    targets_and = np.array([0, 0, 0, 0, 0, 0, 0, 1])
    
    # 使用Delta规则和sigmoid函数训练
    nn.train_delta_rule(training_data_and, targets_and, epochs=50, 
                       activation_func='sigmoid', verbose=True)
    
    # 测试训练结果
    print("\n训练后测试:")
    for inputs in training_data_and:
        output, net_input = nn.predict(inputs, 'sigmoid')
        print(f"输入: {inputs} -> 输出: {output:.4f}, 净输入: {net_input:.4f}")
    
    # 测试2: 使用不同的激活函数
    print("\n" + "=" * 60)
    print("测试2: 使用tanh激活函数")
    print("=" * 60)
    
    nn2 = SingleLayerNeuralNetwork(input_size=6, learning_rate=0.1)
    nn2.train_delta_rule(training_data_and, targets_and, epochs=50,
                        activation_func='tanh', verbose=False)
    
    print("训练完成，最终误差:", nn2.training_history[-1]['total_error'])
    
    # 测试3: Hebb规则
    print("\n" + "=" * 60)
    print("测试3: Hebb学习规则")
    print("=" * 60)
    
    nn3 = SingleLayerNeuralNetwork(input_size=6, learning_rate=0.01)
    nn3.train_hebb_rule(training_data_and, epochs=20, 
                       activation_func='sigmoid', verbose=True)
    
    return nn, nn2, nn3

# 自定义训练函数
def custom_training():
    """允许用户自定义训练参数"""
    print("\n" + "=" * 60)
    print("自定义训练")
    print("=" * 60)
    
    # 获取用户输入
    learning_rate = float(input("请输入学习率 (默认0.1): ") or 0.1)
    epochs = int(input("请输入训练轮数 (默认100): ") or 100)
    
    print("\n请选择激活函数:")
    print("1. sigmoid")
    print("2. tanh")
    print("3. relu")
    print("4. linear")
    print("5. step")
    act_choice = input("请选择 (默认1): ") or "1"
    
    activation_map = {'1': 'sigmoid', '2': 'tanh', '3': 'relu', 
                     '4': 'linear', '5': 'step'}
    activation_func = activation_map.get(act_choice, 'sigmoid')
    
    print("\n请选择学习规则:")
    print("1. Delta规则 (有监督)")
    print("2. Hebb规则 (无监督)")
    rule_choice = input("请选择 (默认1): ") or "1"
    
    # 获取训练数据
    print("\n请输入训练数据 (6个输入值，用空格分隔，每行一个样本，输入空行结束):")
    training_data = []
    while True:
        line = input()
        if not line:
            break
        values = list(map(float, line.split()))
        if len(values) == 6:
            training_data.append(values)
        else:
            print("请输入6个数值")
    
    training_data = np.array(training_data)
    
    if rule_choice == "1":
        # Delta规则需要目标输出
        print("\n请输入对应的目标输出 (每行一个值):")
        targets = []
        for i in range(len(training_data)):
            target = float(input(f"样本 {i+1} 的目标输出: "))
            targets.append(target)
        targets = np.array(targets)
    
    # 创建并训练网络
    nn = SingleLayerNeuralNetwork(input_size=6, learning_rate=learning_rate)
    
    if rule_choice == "1":
        nn.train_delta_rule(training_data, targets, epochs=epochs,
                           activation_func=activation_func, verbose=True)
    else:
        nn.train_hebb_rule(training_data, epochs=epochs,
                          activation_func=activation_func, verbose=True)
    
    return nn

if __name__ == "__main__":
    print("人工神经网络课程作业 - 6输入单节点网络")
    print("作者: AI助手")
    print("=" * 60)
    
    while True:
        print("\n请选择操作:")
        print("1. 运行标准测试")
        print("2. 自定义训练")
        print("3. 退出")
        
        choice = input("请选择 (1-3): ")
        
        if choice == "1":
            nn1, nn2, nn3 = test_neural_network()
            # 绘制训练误差曲线
            nn1.plot_training_history()
            
        elif choice == "2":
            nn = custom_training()
            # 绘制训练误差曲线（如果适用）
            if hasattr(nn, 'plot_training_history'):
                nn.plot_training_history()
                
        elif choice == "3":
            print("程序结束")
            break
        else:
            print("无效选择，请重新输入")