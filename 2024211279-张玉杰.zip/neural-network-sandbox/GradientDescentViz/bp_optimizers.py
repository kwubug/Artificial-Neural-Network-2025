"""BP Neural Network with Different Optimization Algorithms"""
import numpy as np
from typing import Tuple, List, Dict


class BPNeuralNetwork:
    """
    BP Neural Network with multiple optimization algorithms.
    支持梯度下降法、牛顿法、共轭梯度法
    """
    
    def __init__(self, input_size: int, hidden_size: int, output_size: int, 
                 optimizer: str = 'gradient_descent', learning_rate: float = 0.1):
        """
        初始化神经网络
        
        Args:
            input_size: 输入层大小
            hidden_size: 隐藏层大小
            output_size: 输出层大小
            optimizer: 优化算法 ('gradient_descent', 'newton', 'conjugate_gradient')
            learning_rate: 学习率
        """
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate
        self.optimizer = optimizer
        
        # 初始化权重和偏置（使用小的随机值）
        self.W1 = np.random.randn(input_size, hidden_size) * 0.5
        self.b1 = np.zeros((1, hidden_size), dtype=np.float64)
        self.W2 = np.random.randn(hidden_size, output_size) * 0.5
        self.b2 = np.zeros((1, output_size), dtype=np.float64)
        
        # 用于共轭梯度法
        self.prev_gradient = None
        
        # 记录训练历史
        self.loss_history = []
        self.weight_history = []
        
    def sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid激活函数"""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
    
    def sigmoid_derivative(self, x: np.ndarray) -> np.ndarray:
        """Sigmoid导数"""
        return x * (1 - x)
    
    def forward(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        前向传播
        
        Returns:
            z1: 隐藏层输入
            a1: 隐藏层输出
            output: 网络输出
        """
        # 隐藏层
        z1 = np.dot(X, self.W1) + self.b1
        a1 = self.sigmoid(z1)
        
        # 输出层
        z2 = np.dot(a1, self.W2) + self.b2
        output = self.sigmoid(z2)
        
        return z1, a1, output
    
    def compute_loss(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        """计算MSE损失"""
        return np.mean((y_true - y_pred) ** 2)
    
    def backward(self, X: np.ndarray, y: np.ndarray, a1: np.ndarray, 
                 output: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        反向传播计算梯度
        
        Returns:
            dW1, db1, dW2, db2: 各层权重和偏置的梯度
        """
        m = X.shape[0]
        
        # 输出层梯度
        output_error = output - y
        output_delta = output_error * self.sigmoid_derivative(output)
        
        # 隐藏层梯度
        hidden_error = output_delta.dot(self.W2.T)
        hidden_delta = hidden_error * self.sigmoid_derivative(a1)
        
        # 计算梯度
        dW2 = np.dot(a1.T, output_delta) / m
        db2 = np.sum(output_delta, axis=0, keepdims=True) / m
        dW1 = np.dot(X.T, hidden_delta) / m
        db1 = np.sum(hidden_delta, axis=0, keepdims=True) / m
        
        return dW1, db1, dW2, db2
    
    def update_gradient_descent(self, dW1: np.ndarray, db1: np.ndarray, 
                               dW2: np.ndarray, db2: np.ndarray):
        """标准梯度下降更新"""
        self.W1 -= self.learning_rate * dW1
        self.b1 -= self.learning_rate * db1
        self.W2 -= self.learning_rate * dW2
        self.b2 -= self.learning_rate * db2
    
    def update_newton(self, X: np.ndarray, y: np.ndarray, 
                     dW1: np.ndarray, db1: np.ndarray, 
                     dW2: np.ndarray, db2: np.ndarray):
        """
        牛顿法更新（使用近似Hessian矩阵）
        使用对角近似来简化计算
        """
        epsilon = 1e-8
        
        # 对于简化，使用梯度的平方作为Hessian对角线的近似
        # 这类似于 AdaGrad 的思想
        H_W1 = dW1 ** 2 + epsilon
        H_b1 = db1 ** 2 + epsilon
        H_W2 = dW2 ** 2 + epsilon
        H_b2 = db2 ** 2 + epsilon
        
        # 牛顿法更新：theta = theta - H^(-1) * gradient
        self.W1 -= self.learning_rate * dW1 / np.sqrt(H_W1)
        self.b1 -= self.learning_rate * db1 / np.sqrt(H_b1)
        self.W2 -= self.learning_rate * dW2 / np.sqrt(H_W2)
        self.b2 -= self.learning_rate * db2 / np.sqrt(H_b2)
    
    def update_conjugate_gradient(self, dW1: np.ndarray, db1: np.ndarray, 
                                  dW2: np.ndarray, db2: np.ndarray):
        """
        共轭梯度法更新
        使用 Fletcher-Reeves 公式计算共轭方向
        """
        # 将所有梯度展平为一个向量
        current_gradient = np.concatenate([
            dW1.flatten(), db1.flatten(), 
            dW2.flatten(), db2.flatten()
        ])
        
        if self.prev_gradient is None:
            # 第一次迭代，使用负梯度方向
            search_direction = -current_gradient
        else:
            # 计算 beta (Fletcher-Reeves 公式)
            beta = np.dot(current_gradient, current_gradient) / \
                   (np.dot(self.prev_gradient, self.prev_gradient) + 1e-8)
            
            # 计算共轭方向
            prev_direction = np.concatenate([
                (-self.prev_gradient[:self.W1.size]).reshape(self.W1.shape).flatten(),
                (-self.prev_gradient[self.W1.size:self.W1.size + self.b1.size]).flatten(),
                (-self.prev_gradient[self.W1.size + self.b1.size:
                                   self.W1.size + self.b1.size + self.W2.size]).reshape(self.W2.shape).flatten(),
                (-self.prev_gradient[-self.b2.size:]).flatten()
            ])
            search_direction = -current_gradient + beta * prev_direction
        
        # 保存当前梯度供下次使用
        self.prev_gradient = current_gradient.copy()
        
        # 将搜索方向重新整形并更新权重
        idx = 0
        W1_update = search_direction[idx:idx + self.W1.size].reshape(self.W1.shape)
        idx += self.W1.size
        b1_update = search_direction[idx:idx + self.b1.size].reshape(self.b1.shape)
        idx += self.b1.size
        W2_update = search_direction[idx:idx + self.W2.size].reshape(self.W2.shape)
        idx += self.W2.size
        b2_update = search_direction[idx:].reshape(self.b2.shape)
        
        self.W1 += self.learning_rate * W1_update
        self.b1 += self.learning_rate * b1_update
        self.W2 += self.learning_rate * W2_update
        self.b2 += self.learning_rate * b2_update
    
    def train_step(self, X: np.ndarray, y: np.ndarray) -> float:
        """
        执行一步训练
        
        Returns:
            loss: 当前损失值
        """
        # 前向传播
        z1, a1, output = self.forward(X)
        
        # 计算损失
        loss = self.compute_loss(y, output)
        
        # 反向传播
        dW1, db1, dW2, db2 = self.backward(X, y, a1, output)
        
        # 根据优化器选择更新方法
        if self.optimizer == 'gradient_descent':
            self.update_gradient_descent(dW1, db1, dW2, db2)
        elif self.optimizer == 'newton':
            self.update_newton(X, y, dW1, db1, dW2, db2)
        elif self.optimizer == 'conjugate_gradient':
            self.update_conjugate_gradient(dW1, db1, dW2, db2)
        
        # 记录历史
        self.loss_history.append(loss)
        self.weight_history.append({
            'W1': self.W1.copy(),
            'b1': self.b1.copy(),
            'W2': self.W2.copy(),
            'b2': self.b2.copy()
        })
        
        return loss
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """预测"""
        _, _, output = self.forward(X)
        return output
    
    def get_weight_vector(self) -> np.ndarray:
        """获取权重向量（用于可视化）"""
        # 返回W1的前两个权重（用于2D可视化）
        return self.W1.flatten()[:2]
    
    def get_flat_weights(self) -> np.ndarray:
        """获取展平的所有权重"""
        return np.concatenate([
            self.W1.flatten(), 
            self.b1.flatten(), 
            self.W2.flatten(), 
            self.b2.flatten()
        ])


def generate_classification_data(n_samples: int = 100) -> Tuple[np.ndarray, np.ndarray]:
    """
    生成二分类数据集
    
    Returns:
        X: 特征矩阵 (n_samples, 2)
        y: 标签 (n_samples, 1)
    """
    np.random.seed(42)
    
    # 生成两类数据
    n_class = n_samples // 2
    
    # 类别 0：中心在 (2, 2)
    X0 = np.random.randn(n_class, 2) * 0.8 + np.array([2, 2])
    y0 = np.zeros((n_class, 1))
    
    # 类别 1：中心在 (-2, -2)
    X1 = np.random.randn(n_class, 2) * 0.8 + np.array([-2, -2])
    y1 = np.ones((n_class, 1))
    
    # 合并数据
    X = np.vstack([X0, X1])
    y = np.vstack([y0, y1])
    
    # 打乱数据
    indices = np.random.permutation(n_samples)
    X = X[indices]
    y = y[indices]
    
    return X, y


def generate_xor_data(n_samples: int = 200) -> Tuple[np.ndarray, np.ndarray]:
    """
    生成XOR数据集（非线性问题）
    
    Returns:
        X: 特征矩阵 (n_samples, 2)
        y: 标签 (n_samples, 1)
    """
    np.random.seed(42)
    
    n_class = n_samples // 4
    
    # 四个角落的数据
    X00 = np.random.randn(n_class, 2) * 0.5 + np.array([-2, -2])
    X01 = np.random.randn(n_class, 2) * 0.5 + np.array([-2, 2])
    X10 = np.random.randn(n_class, 2) * 0.5 + np.array([2, -2])
    X11 = np.random.randn(n_class, 2) * 0.5 + np.array([2, 2])
    
    # XOR标签
    y00 = np.zeros((n_class, 1))
    y01 = np.ones((n_class, 1))
    y10 = np.ones((n_class, 1))
    y11 = np.zeros((n_class, 1))
    
    # 合并数据
    X = np.vstack([X00, X01, X10, X11])
    y = np.vstack([y00, y01, y10, y11])
    
    # 打乱数据
    indices = np.random.permutation(X.shape[0])
    X = X[indices]
    y = y[indices]
    
    return X, y

