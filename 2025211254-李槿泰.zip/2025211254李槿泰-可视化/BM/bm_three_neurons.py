import sys
import math
import time
from dataclasses import dataclass
from typing import List, Tuple

import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets


# ------------------------------
# Boltzmann Machine core (3 neurons)
# ------------------------------


Spin = int  # values are -1 or +1


@dataclass
class BMConfig:
    weights: np.ndarray  # shape (3, 3), symmetric, zero diagonal
    biases: np.ndarray   # shape (3,)
    temperature: float   # T > 0


class ThreeNeuronBM:
    def __init__(self) -> None:
        self.num_neurons: int = 3
        self.state: np.ndarray = np.ones(self.num_neurons, dtype=int)
        self.config: BMConfig = BMConfig(
            weights=np.array(
                [
                    [0.0, 0.6, -0.2],
                    [0.6, 0.0, 0.5],
                    [-0.2, 0.5, 0.0],
                ],
                dtype=float,
            ),
            biases=np.array([0.0, 0.0, 0.0], dtype=float),
            temperature=1.0,
        )
        # For equilibrium detection
        self.recent_states: List[Tuple[int, int, int]] = []
        self.max_recent_buffer: int = 50
        self.equilibrium: bool = False

    def set_parameters(self, weights: np.ndarray, biases: np.ndarray, temperature: float) -> None:
        assert weights.shape == (3, 3)
        assert biases.shape == (3,)
        # Symmetrize and zero diagonal to satisfy BM energy form
        w = 0.5 * (weights + weights.T)
        np.fill_diagonal(w, 0.0)
        self.config = BMConfig(weights=w, biases=biases.astype(float), temperature=max(temperature, 1e-6))
        self.equilibrium = False
        self.recent_states.clear()

    def reset_state(self, state: np.ndarray | None = None) -> None:
        if state is None:
            self.state = np.random.choice([-1, 1], size=(self.num_neurons,)).astype(int)
        else:
            assert state.shape == (3,)
            self.state = state.astype(int)
        self.equilibrium = False
        self.recent_states.clear()

    def energy(self, state: np.ndarray | None = None) -> float:
        s = self.state if state is None else state
        w = self.config.weights
        b = self.config.biases
        # E(s) = -1/2 s^T W s - b^T s
        quad = -0.5 * float(s.T @ w @ s)
        lin = -float(b.T @ s)
        return quad + lin

    def _conditional_prob(self, neuron_index: int, proposed_spin: Spin) -> float:
        # P(s_i = proposed | s_-i) = sigmoid(2 * proposed * (sum_j w_ij s_j + b_i) / T)
        local_field = float(self.config.weights[neuron_index] @ self.state + self.config.biases[neuron_index])
        x = 2.0 * proposed_spin * local_field / self.config.temperature
        # numerically stable sigmoid
        if x >= 0:
            z = math.exp(-x)
            return 1.0 / (1.0 + z)
        else:
            z = math.exp(x)
            return z / (1.0 + z)

    def gibbs_update_one(self) -> None:
        # Asynchronous Gibbs: update neurons in random order
        order = np.random.permutation(self.num_neurons)
        for i in order:
            p_plus = self._conditional_prob(i, +1)
            # sample new spin
            self.state[i] = 1 if np.random.rand() < p_plus else -1
        self._update_equilibrium_buffer()

    def _update_equilibrium_buffer(self) -> None:
        tuple_state = (int(self.state[0]), int(self.state[1]), int(self.state[2]))
        self.recent_states.append(tuple_state)
        if len(self.recent_states) > self.max_recent_buffer:
            self.recent_states.pop(0)
        # Simple equilibrium criterion: state repeats frequently and transition rate is low
        if len(self.recent_states) >= self.max_recent_buffer:
            unique = {s for s in self.recent_states}
            # If only a small set of states are visited and last N_tail are identical, consider equilibrium
            tail = self.recent_states[-10:]
            if len(set(tail)) == 1:
                self.equilibrium = True

    def is_in_equilibrium(self) -> bool:
        return self.equilibrium


# ------------------------------
# Qt Node View
# ------------------------------


class NodeView(QtWidgets.QWidget):
    def __init__(self, get_state_callable, parent=None) -> None:
        super().__init__(parent)
        self.get_state = get_state_callable
        self.setMinimumSize(260, 220)

    def paintEvent(self, event: QtGui.QPaintEvent) -> None:
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        rect = self.rect()
        cx = rect.center().x()
        cy = rect.center().y()
        radius = min(rect.width(), rect.height()) // 2 - 20

        # positions of 3 nodes on a circle
        positions: List[QtCore.QPointF] = []
        for k in range(3):
            angle = 2 * math.pi * k / 3.0 - math.pi / 2
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            positions.append(QtCore.QPointF(x, y))

        # draw edges
        pen_edge = QtGui.QPen(QtGui.QColor(160, 160, 160))
        pen_edge.setWidth(2)
        painter.setPen(pen_edge)
        for i in range(3):
            for j in range(i + 1, 3):
                painter.drawLine(positions[i], positions[j])

        # draw nodes, color by spin
        spins = self.get_state()
        for i, pos in enumerate(positions):
            spin = int(spins[i])
            color = QtGui.QColor(220, 60, 60) if spin == 1 else QtGui.QColor(60, 120, 220)
            painter.setBrush(color)
            painter.setPen(QtCore.Qt.NoPen)
            r = 24
            painter.drawEllipse(pos, r, r)
            # Outline
            painter.setPen(QtGui.QPen(QtGui.QColor(30, 30, 30), 2))
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawEllipse(pos, r, r)
            # label
            painter.setPen(QtGui.QPen(QtGui.QColor(20, 20, 20)))
            text = f"s{i+1}={spin:+d}"
            painter.drawText(
                QtCore.QRectF(pos.x() - 28, pos.y() - 44, 56, 18),
                QtCore.Qt.AlignCenter,
                text,
            )


# ------------------------------
# Main Window
# ------------------------------


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("三神经元Boltzmann机 - 运行与热平衡演示")
        self.resize(860, 560)

        self.bm = ThreeNeuronBM()
        self.timer = QtCore.QTimer(self)
        self.timer.setInterval(120)  # ms per step
        self.timer.timeout.connect(self._on_timer_tick)

        central = QtWidgets.QWidget(self)
        self.setCentralWidget(central)
        layout = QtWidgets.QHBoxLayout(central)

        # Left: visualization
        self.node_view = NodeView(self._get_state)
        layout.addWidget(self.node_view, 1)

        # Right: controls and status
        controls = QtWidgets.QVBoxLayout()
        layout.addLayout(controls, 0)

        # Weights grid inputs
        controls.addWidget(QtWidgets.QLabel("权重矩阵 W (对称，自动置零对角):"))
        self.weight_edits: List[List[QtWidgets.QLineEdit]] = []
        grid = QtWidgets.QGridLayout()
        for i in range(3):
            row_edits: List[QtWidgets.QLineEdit] = []
            for j in range(3):
                edit = QtWidgets.QLineEdit()
                edit.setFixedWidth(70)
                edit.setAlignment(QtCore.Qt.AlignRight)
                val = self.bm.config.weights[i, j]
                if i == j:
                    edit.setText("0.0")
                    edit.setDisabled(True)
                else:
                    edit.setText(f"{val:.3f}")
                grid.addWidget(edit, i, j)
                row_edits.append(edit)
            self.weight_edits.append(row_edits)
        controls.addLayout(grid)

        # Biases
        controls.addSpacing(8)
        controls.addWidget(QtWidgets.QLabel("偏置 b:"))
        self.bias_edits: List[QtWidgets.QLineEdit] = []
        bias_layout = QtWidgets.QHBoxLayout()
        for i in range(3):
            edit = QtWidgets.QLineEdit()
            edit.setFixedWidth(70)
            edit.setAlignment(QtCore.Qt.AlignRight)
            edit.setText(f"{self.bm.config.biases[i]:.3f}")
            bias_layout.addWidget(QtWidgets.QLabel(f"b{i+1}:"))
            bias_layout.addWidget(edit)
            self.bias_edits.append(edit)
        controls.addLayout(bias_layout)

        # Temperature
        controls.addSpacing(8)
        temp_layout = QtWidgets.QHBoxLayout()
        temp_layout.addWidget(QtWidgets.QLabel("温度 T:"))
        self.temp_spin = QtWidgets.QDoubleSpinBox()
        self.temp_spin.setRange(0.01, 10.0)
        self.temp_spin.setSingleStep(0.05)
        self.temp_spin.setDecimals(2)
        self.temp_spin.setValue(self.bm.config.temperature)
        temp_layout.addWidget(self.temp_spin)
        controls.addLayout(temp_layout)

        # Auto-anneal option
        self.anneal_checkbox = QtWidgets.QCheckBox("退火：逐步降低T")
        self.anneal_checkbox.setChecked(False)
        controls.addWidget(self.anneal_checkbox)

        # Buttons
        btn_row = QtWidgets.QHBoxLayout()
        self.btn_run = QtWidgets.QPushButton("运行")
        self.btn_pause = QtWidgets.QPushButton("暂停")
        self.btn_step = QtWidgets.QPushButton("单步")
        self.btn_reset = QtWidgets.QPushButton("重置状态")
        btn_row.addWidget(self.btn_run)
        btn_row.addWidget(self.btn_pause)
        btn_row.addWidget(self.btn_step)
        btn_row.addWidget(self.btn_reset)
        controls.addLayout(btn_row)

        # Apply parameters button
        self.btn_apply = QtWidgets.QPushButton("应用参数")
        controls.addWidget(self.btn_apply)

        # Status labels
        controls.addSpacing(8)
        self.label_state = QtWidgets.QLabel()
        self.label_energy = QtWidgets.QLabel()
        self.label_equil = QtWidgets.QLabel()
        font_bold = self.label_equil.font()
        font_bold.setBold(True)
        self.label_equil.setFont(font_bold)
        controls.addWidget(self.label_state)
        controls.addWidget(self.label_energy)
        controls.addWidget(self.label_equil)

        # Log
        controls.addSpacing(8)
        controls.addWidget(QtWidgets.QLabel("运行日志:"))
        self.text_log = QtWidgets.QPlainTextEdit()
        self.text_log.setReadOnly(True)
        self.text_log.setMinimumHeight(180)
        controls.addWidget(self.text_log, 1)

        # Connections
        self.btn_run.clicked.connect(self._on_run)
        self.btn_pause.clicked.connect(self._on_pause)
        self.btn_step.clicked.connect(self._on_step)
        self.btn_reset.clicked.connect(self._on_reset)
        self.btn_apply.clicked.connect(self._on_apply)

        self._refresh_status()

    # ---------- Helpers ----------

    def _get_state(self) -> np.ndarray:
        return self.bm.state

    def _log(self, message: str) -> None:
        timestamp = time.strftime("%H:%M:%S")
        self.text_log.appendPlainText(f"[{timestamp}] {message}")
        # Keep log scrolled
        self.text_log.verticalScrollBar().setValue(self.text_log.verticalScrollBar().maximum())

    def _read_weights_biases(self) -> Tuple[np.ndarray, np.ndarray, float]:
        w = np.zeros((3, 3), dtype=float)
        for i in range(3):
            for j in range(3):
                if i == j:
                    continue
                try:
                    w[i, j] = float(self.weight_edits[i][j].text())
                except Exception:
                    w[i, j] = 0.0
        b = np.zeros(3, dtype=float)
        for i in range(3):
            try:
                b[i] = float(self.bias_edits[i].text())
            except Exception:
                b[i] = 0.0
        T = float(self.temp_spin.value())
        return w, b, T

    def _refresh_status(self) -> None:
        s = self.bm.state
        E = self.bm.energy()
        T = self.bm.config.temperature
        self.label_state.setText(f"状态 s = [{int(s[0]):+d}, {int(s[1]):+d}, {int(s[2]):+d}]， T = {T:.2f}")
        self.label_energy.setText(f"能量 E(s) = {E:.4f}")
        if self.bm.is_in_equilibrium():
            self.label_equil.setText("热平衡：已达到（最近状态稳定）")
            self.label_equil.setStyleSheet("color: #0a8;")
        else:
            self.label_equil.setText("热平衡：未达到")
            self.label_equil.setStyleSheet("color: #c33;")
        self.node_view.update()

    # ---------- Slots ----------

    def _on_apply(self) -> None:
        w, b, T = self._read_weights_biases()
        self.bm.set_parameters(w, b, T)
        self._log("参数已应用（W对称化，零对角）。")
        self._refresh_status()

    def _on_reset(self) -> None:
        self.bm.reset_state()
        self._log("状态已随机重置。")
        self._refresh_status()

    def _on_run(self) -> None:
        if not self.timer.isActive():
            self.timer.start()
            self._log("开始运行。")

    def _on_pause(self) -> None:
        if self.timer.isActive():
            self.timer.stop()
            self._log("已暂停。")

    def _on_step(self) -> None:
        self._single_step()

    def _on_timer_tick(self) -> None:
        self._single_step()

    def _single_step(self) -> None:
        # Optional annealing
        if self.anneal_checkbox.isChecked():
            new_T = max(0.01, self.bm.config.temperature * 0.995)
            self.bm.config.temperature = new_T
            self.temp_spin.setValue(new_T)
        prev_state = tuple(int(x) for x in self.bm.state)
        self.bm.gibbs_update_one()
        new_state = tuple(int(x) for x in self.bm.state)
        self._log(f"单步更新：{prev_state} -> {new_state}，E={self.bm.energy():.4f}")
        self._refresh_status()
        if self.bm.is_in_equilibrium():
            if self.timer.isActive():
                self.timer.stop()
                self._log("检测到热平衡：状态已稳定，自动停止运行。")


def main() -> None:
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


