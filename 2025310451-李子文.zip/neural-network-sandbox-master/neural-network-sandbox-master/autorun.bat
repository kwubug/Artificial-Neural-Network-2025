@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem === 基本路径 ===
set "ROOT=%~dp0"
set "VENV=%ROOT%.venv"
set "REQ=%ROOT%requirements.txt"

rem === 可选：是否使用清华镜像（1=用，0=不用）===
set "USE_MIRROR=1"

rem === 选择 Python 启动器（优先 py，回退到 python） ===
where py >nul 2>&1 && (set "PY=py") || (set "PY=python")

rem === 1) 若无虚拟环境则创建（优先 3.10，回退 3.9 或默认） ===
if not exist "%VENV%\Scripts\python.exe" (
  echo [+] Creating virtual env...
  "%PY%" -3.10 -m venv "%VENV%" 2>nul || "%PY%" -3.9 -m venv "%VENV%" 2>nul || "%PY%" -m venv "%VENV%"
  if not exist "%VENV%\Scripts\python.exe" (
    echo [!] Failed to create venv. Please ensure Python is installed and on PATH.
    pause
    exit /b 1
  )
)

rem === 2) 仅在 requirements.txt 变化时安装依赖（用 SHA256 校验） ===
set "NEED_INSTALL=1"
set "HASHFILE=%VENV%\.reqhash"
set "CURHASH="
if exist "%REQ%" (
  rem 计算当前 req 的 hash（若 certutil 不可用，则强制安装）
  for /f "tokens=1" %%H in ('certutil -hashfile "%REQ%" SHA256 ^| find /i /v "hash" ^| find /i /v "certutil"') do set "CURHASH=%%H"
  if exist "%HASHFILE%" (
    for /f "usebackq delims=" %%A in ("%HASHFILE%") do set "OLDHASH=%%A"
    if defined CURHASH if /i "!OLDHASH!"=="!CURHASH!" set "NEED_INSTALL=0"
  ) else (
    if not defined CURHASH set "NEED_INSTALL=1"
  )
) else (
  rem 没有 requirements.txt 就不装依赖
  set "NEED_INSTALL=0"
)

if "%NEED_INSTALL%"=="1" (
  echo [+] Installing / updating dependencies...
  "%VENV%\Scripts\python.exe" -m pip install -U pip
  if "%USE_MIRROR%"=="1" (
    "%VENV%\Scripts\python.exe" -m pip install -r "%REQ%" -i https://pypi.tuna.tsinghua.edu.cn/simple
  ) else (
    "%VENV%\Scripts\python.exe" -m pip install -r "%REQ%"
  )
  if defined CURHASH ( >"%HASHFILE%" echo %CURHASH% )
)

rem === 3) 若 PyQt5/QML 组件缺失，补装一次（防止环境不完整） ===
"%VENV%\Scripts\python.exe" -c "import PyQt5, PyQt5.QtQuick" >nul 2>&1
if errorlevel 1 (
  echo [+] Installing PyQt5 runtime...
  if "%USE_MIRROR%"=="1" (
    "%VENV%\Scripts\python.exe" -m pip install PyQt5 PyQtChart -i https://pypi.tuna.tsinghua.edu.cn/simple
  ) else (
    "%VENV%\Scripts\python.exe" -m pip install PyQt5 PyQtChart
  )
)

rem === 4) 设置 Qt/QML 运行环境（每次启动设置，避免找不到插件） ===
set "QML2_IMPORT_PATH=%VENV%\Lib\site-packages\PyQt5\Qt5\qml"
set "QT_QPA_PLATFORM_PLUGIN_PATH=%VENV%\Lib\site-packages\PyQt5\Qt5\plugins\platforms"

rem 可选：快速自检平台插件是否存在（qwindows.dll）
if not exist "%QT_QPA_PLATFORM_PLUGIN_PATH%\qwindows.dll" (
  echo [!] Qt platform plugin not found. Trying to reinstall PyQt5...
  if "%USE_MIRROR%"=="1" (
    "%VENV%\Scripts\python.exe" -m pip install --force-reinstall PyQt5 PyQtChart -i https://pypi.tuna.tsinghua.edu.cn/simple
  ) else (
    "%VENV%\Scripts\python.exe" -m pip install --force-reinstall PyQt5 PyQtChart
  )
)

rem === 5) 启动应用 ===
echo [+] Launching app...
"%VENV%\Scripts\python.exe" "%ROOT%main.py"

endlocal
