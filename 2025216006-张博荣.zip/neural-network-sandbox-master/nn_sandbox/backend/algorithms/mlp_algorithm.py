# nn_sandbox/backend/algorithms/mlp_algorithm.py
import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bipolar_sigmoid


class MlpAlgorithm(PredictiveAlgorithm):
    """ Backpropagation prototype. """

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None,
                 activation_function='sigmoid'):  # 添加激活函数参数
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight

        # 选择激活函数
        if activation_function == 'sigmoid':
            self.activation = sigmoid
        elif activation_function == 'bipolar_sigmoid':
            self.activation = bipolar_sigmoid
        else:
            raise ValueError(f"不支持的激活函数: {activation_function}")

        # the default network shape is (2 * 5)
        self.network_shape = network_shape if network_shape else (5, 5)

        # for momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]),
                                     result)
        self._adjust_synaptic_weights(deltas)

    def _initialize_neurons(self):
        """ Build the neuron network with single neuron as output layer. """
        # 使用选定的激活函数
        self._neurons = tuple((Perceptron(self.activation),) * size
                              for size in list(self.network_shape) + [1])

    def _feed_forward(self, data):
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron. """
        deltas = {}

        # 根据激活函数类型调整导数计算
        if self.activation == sigmoid:
            # 单极性sigmoid导数: f'(x) = f(x) * (1 - f(x))
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * result * (1 - result))
        elif self.activation == bipolar_sigmoid:
            # 双极性sigmoid导数: f'(x) = 0.5 * (1 - f(x)^2)
            deltas[self._neurons[-1][0]] = ((expect - result)
                                            * 0.5 * (1 - result**2))

        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                # 计算下一层的delta和权重的总和
                sum_delta = sum(deltas[n] * n.synaptic_weight[neuron_idx]
                               for n in self._neurons[layer_idx + 1])
                
                # 根据激活函数类型调整导数计算
                if self.activation == sigmoid:
                    deltas[neuron] = sum_delta * neuron.result * (1 - neuron.result)
                elif self.activation == bipolar_sigmoid:
                    deltas[neuron] = sum_delta * 0.5 * (1 - neuron.result**2)
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """根据激活函数调整输出归一化范围"""
        if self.activation == sigmoid:
            # 单极性sigmoid输出范围(0,1)
            return (value - np.amin(self.group_types)) / (np.amax(self.group_types) - np.amin(self.group_types))
        elif self.activation == bipolar_sigmoid:
            # 双极性sigmoid输出范围(-1,1)
            return 2 * (value - np.amin(self.group_types)) / (np.amax(self.group_types) - np.amin(self.group_types)) - 1


def get_layer_results(layer, data):
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)