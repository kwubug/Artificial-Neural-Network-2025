import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtQuick.Dialogs 1.3
import '..'

Page {
    id: mainPage
    name: "TSP Problem Solver"


    ColumnLayout {
                Button {
                    text: "Start Training"
                    onClicked: {
                        TSP.solve()

                    }
                }
        }
}
