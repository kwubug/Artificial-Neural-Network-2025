# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Neural Network Sandbox application built with Python and QML/Qt. It implements four different neural network algorithms:
- Perceptron
- Multi-Layer Perceptron (MLP)
- Radial Basis Function Network (RBFN)
- Self-Organizing Map (SOM)

The application features a clean separation between backend algorithms and frontend UI through a custom observer pattern implementation.

## Architecture

### Core Architecture Pattern

The project uses a custom bridge pattern to decouple backend algorithms from the Qt/QML frontend:

1. **Backend Algorithms** (`nn_sandbox/backend/algorithms/`) - Pure Python implementations of neural network algorithms that inherit from abstract base classes
2. **Bridge Classes** (`nn_sandbox/bridges/`) - Connect backend algorithms to the frontend using PyQt properties and signals
3. **Frontend** (`nn_sandbox/frontend/`) - QML-based UI that communicates with Python through context properties

### Key Components

- **BridgeProperty**: Custom PyQt property that automatically emits signals when values change
- **Observable/Observers**: Custom implementation that notifies bridges when backend algorithm properties change
- **Threaded Algorithms**: Backend algorithms run in separate threads to prevent UI blocking

## Development Commands

### Installation
```bash
pip install -r requirements.txt
```

### Running the Application
```bash
python main.py
```

### Project Structure
```
neural-network-sandbox/
├── main.py                 # Entry point
├── requirements.txt        # Dependencies
├── nn_sandbox/
│   ├── backend/           # Pure Python algorithms
│   │   ├── algorithms/    # Neural network implementations
│   │   └── neurons/       # Individual neuron classes
│   ├── bridges/           # Bridge pattern implementation
│   └── frontend/          # QML UI components
```

## Key Implementation Details

### Bridge Pattern Implementation
1. Backend algorithms inherit from `Observable`
2. Bridge classes inherit from `Bridge` (which combines QObject and Observer)
3. Bridge properties are defined using `BridgeProperty` which automatically creates PyQt signals
4. When backend properties change, they notify observers (bridges) which update the UI

### Thread Management
Algorithms run in separate threads inheriting from `threading.Thread` to prevent UI blocking. The `_iterate()` method includes a `time.sleep()` call to control UI refresh rate.

### Data Flow
1. UI actions trigger slots in bridge classes
2. Bridges instantiate and configure backend algorithms
3. Algorithms run in background threads
4. Property changes in algorithms notify bridges
5. Bridges emit PyQt signals to update QML UI