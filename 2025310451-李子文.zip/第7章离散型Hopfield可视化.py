# -*- coding: utf-8 -*-
"""
离散型 Hopfield 一体化可视化（单画布 + 动态演示 + 开始按钮）
- 左侧：按类别（H/E/N）每行两列：
    左：原型（静态）
    右：当前状态（动态图，从噪声输入逐步回忆）
- 右上：能量随异步更新的实时曲线（每类一条）
- 右下：存储态与伪吸引子能量（静态柱状图）
- 底部：'开始演示' 按钮，不点击不运行

说明：
- 使用“异步更新（asynchronous）”，每帧对所有样本各更新若干个神经元；
- 更新到稳定（一个 sweep 内无翻转）或达到最大 sweep 后停止。
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import gridspec
from matplotlib.widgets import Button
from matplotlib import font_manager as fm
from itertools import combinations
from types import SimpleNamespace

# ================= 工具函数（与你的原始代码一致/兼容） =================
def set_chinese_font():
    # 尽量设置中文字体，若失败则忽略
    try:
        candidates = ["Microsoft YaHei", "SimHei", "PingFang SC", "Noto Sans CJK SC", "Arial Unicode MS"]
        available = set(f.name for f in fm.fontManager.ttflist)
        for name in candidates:
            if name in available:
                plt.rcParams["font.sans-serif"] = [name]
                break
        plt.rcParams["axes.unicode_minus"] = False
    except Exception:
        pass

def bin01_to_pm1(arr01):
    return np.where(arr01 > 0, 1, -1)

def pm1_to_01(arrpm):
    return np.where(arrpm > 0, 1, 0)

def energy(x, W, theta=None):
    if theta is None:
        return -0.5 * float(x.T @ W @ x)
    return -0.5 * float(x.T @ W @ x) + float(theta.T @ x)

def sign_no_zero(v):
    s = np.sign(v)
    s[s == 0] = 1
    return s

def add_flip_noise(x, flip_rate=0.25, rng=None):
    if rng is None:
        rng = np.random.default_rng()
    x_noisy = x.copy()
    N = x.size
    k = int(np.round(flip_rate * N))
    if k > 0:
        idx = rng.choice(N, size=k, replace=False)
        x_noisy[idx] *= -1
    return x_noisy

def hamming_distance(x, y):
    return np.mean(x != y)

def vector_to_image(x, n):
    return pm1_to_01(x).reshape(n, n)

# ============== 生成三个 10x10 原型（H / E / N） ==============
def make_H(n=10):
    A = np.zeros((n, n), dtype=int)
    A[:, 0] = 1; A[:, -1] = 1; A[n // 2, :] = 1
    return A

def make_E(n=10):
    A = np.zeros((n, n), dtype=int)
    A[:, 0] = 1; A[0, :] = 1; A[n // 2, :] = 1; A[-1, :] = 1
    return A

def make_N(n=10):
    A = np.zeros((n, n), dtype=int)
    A[:, 0] = 1; A[:, -1] = 1
    for i in range(n):
        A[i, i] = 1
    return A

# ============== Hebb 学习（与你的代码保持一致） ==============
def hopfield_hebb_train(patterns_pm1):
    P, N = patterns_pm1.shape
    W = np.zeros((N, N), dtype=float)
    for p in patterns_pm1:
        W += np.outer(p, p)
    W /= N
    np.fill_diagonal(W, 0.0)
    return W

# ============== 伪吸引子：两两/三三组合的多数表决 ==============
def spurious_states_from_patterns(patterns_pm1):
    P, N = patterns_pm1.shape
    spurious = []
    for i, j in combinations(range(P), 2):
        s = sign_no_zero(patterns_pm1[i] + patterns_pm1[j]); spurious.append(s)
    if P >= 3:
        for i, j, k in combinations(range(P), 3):
            s = sign_no_zero(patterns_pm1[i] + patterns_pm1[j] + patterns_pm1[k]); spurious.append(s)
    if not spurious:
        return np.empty((0, N), dtype=int)
    uniq = []
    seen = set()
    for s in spurious:
        key = tuple(s.tolist())
        if key not in seen:
            seen.add(key); uniq.append(s)
    return np.array(uniq, dtype=int)

# ============== 异步更新“逐步器”（为动画而写） ==============
class HopfieldRunner:
    """
    维护一个样本的异步更新过程，使其可“逐步 step”：
    - 每个 sweep 对所有神经元按随机顺序各更新一次；
    - 若一个 sweep 内没有翻转，则认为稳定并停止。
    """
    def __init__(self, x0, W, n_side, rng=None, max_sweeps=60):
        self.W = W
        self.x = x0.copy()
        self.n_side = n_side
        self.N = x0.size
        self.rng = np.random.default_rng() if rng is None else rng
        self.max_sweeps = max_sweeps

        # 初始化一个 sweep
        self.sweep_idx = 0
        self.order = np.arange(self.N)
        self.rng.shuffle(self.order)
        self.ptr = 0  # 当前 sweep 中的位置
        self.changed_this_sweep = False
        self.stable = False
        self.energies = [energy(self.x, self.W)]  # 记录每次“单元更新后”的能量

    def step_unit(self):
        """更新一个神经元，返回当前是否仍在运行（True=还没结束）。"""
        if self.stable or self.sweep_idx >= self.max_sweeps:
            return False

        i = self.order[self.ptr]
        old = self.x[i]
        h = self.W[i, :] @ self.x
        self.x[i] = 1 if h >= 0 else -1
        self.changed_this_sweep |= (self.x[i] != old)

        # 记录能量
        self.energies.append(energy(self.x, self.W))

        # 前进指针
        self.ptr += 1
        if self.ptr >= self.N:  # 完成一个 sweep
            # 稳定性判定
            if not self.changed_this_sweep:
                self.stable = True
            else:
                # 开启下一 sweep
                self.sweep_idx += 1
                if self.sweep_idx >= self.max_sweeps:
                    return False
                self.ptr = 0
                self.changed_this_sweep = False
                self.rng.shuffle(self.order)
        return not self.stable

    def step_many(self, k):
        """一次更新 k 个神经元。返回是否仍在运行。"""
        still_running = True
        for _ in range(k):
            still_running = self.step_unit()
            if not still_running:
                break
        return still_running

    def current_image(self):
        return vector_to_image(self.x, self.n_side)

# ============================== 主程序 ==============================
def main():
    set_chinese_font()
    rng = np.random.default_rng(0)

    # ---- 数据与权重 ----
    n = 10
    proto_imgs_01 = [make_H(n), make_E(n), make_N(n)]
    class_names = ["H 类", "E 类", "N 类"]
    P = len(proto_imgs_01)

    protos_pm1 = np.array([bin01_to_pm1(img.reshape(-1)) for img in proto_imgs_01])  # (P, N)
    N = protos_pm1.shape[1]
    W = hopfield_hebb_train(protos_pm1)

    # 选每类一个带噪声样本 + 初始化 Runner
    noise_rate = 0.25
    picked = []
    for ci in range(P):
        x0 = add_flip_noise(protos_pm1[ci], flip_rate=noise_rate, rng=rng)
        runner = HopfieldRunner(x0, W, n_side=n, rng=rng, max_sweeps=60)
        picked.append(SimpleNamespace(true=ci, runner=runner))

    # 存储态与伪吸引子能量（静态柱状图用）
    store_states = protos_pm1
    store_energies = np.array([energy(s, W) for s in store_states])
    spurious = spurious_states_from_patterns(protos_pm1)
    spurious_energies = np.array([energy(s, W) for s in spurious]) if spurious.size else np.array([])

    names = [f"{name}(存储)" for name in class_names]
    energies_all = store_energies.tolist()
    if spurious.size:
        for i in range(spurious.shape[0]):
            names.append(f"伪吸引子 {i+1}")
            energies_all.append(spurious_energies[i])

    order = np.argsort(energies_all)
    names_sorted = [names[i] for i in order]
    energies_sorted = np.array(energies_all)[order]

    # ================== 画布布局（单画布） ==================
    fig = plt.figure(figsize=(13.5, 8.0))
    gs = gridspec.GridSpec(2, 2, width_ratios=[1.4, 1.0], height_ratios=[1.0, 1.0])
    fig.suptitle("离散 Hopfield 一体化可视化：动态回忆 + 能量曲线 + 吸引子能量", fontsize=14)

    # 左列：3行2列（原型 / 当前状态）
    gs_left = gridspec.GridSpecFromSubplotSpec(3, 2, subplot_spec=gs[:, 0], wspace=0.15, hspace=0.25)

    axes_proto = []
    axes_dyn = []
    ims_dyn = []
    for i in range(P):
        axp = fig.add_subplot(gs_left[i, 0])
        axd = fig.add_subplot(gs_left[i, 1])

        # 原型
        axp.imshow(proto_imgs_01[i], cmap="gray_r", vmin=0, vmax=1)
        axp.set_title(f"原型：{class_names[i]}")
        axp.axis("off")

        # 当前状态（动态）
        im = axd.imshow(picked[i].runner.current_image(), cmap="gray_r", vmin=0, vmax=1, animated=False)
        axd.set_title(f"动态回忆：{class_names[i]}")
        axd.axis("off")

        axes_proto.append(axp)
        axes_dyn.append(axd)
        ims_dyn.append(im)

    # 右上：能量曲线（动态，每类一条）
    ax_energy = fig.add_subplot(gs[0, 1])
    ax_energy.set_title("异步更新下的能量下降曲线（每类一条）")
    ax_energy.set_xlabel("单元更新步数（每次仅更新 1 个神经元）")
    ax_energy.set_ylabel("能量 E(x)")
    ax_energy.grid(True, alpha=0.35)

    lines_energy = []
    for i in range(P):
        line_i, = ax_energy.plot(picked[i].runner.energies, label=class_names[i])
        lines_energy.append(line_i)
    ax_energy.legend()
    ax_energy.set_xlim(0, 50)   # 先给个小范围，后面自适应扩展
    ax_energy.set_ylim(min(le.get_ydata()[0] for le in lines_energy) - 1.0,
                       max(le.get_ydata()[0] for le in lines_energy) + 1.0)

    # 右下：吸引子能量柱状图（静态）
    ax_bar = fig.add_subplot(gs[1, 1])
    ax_bar.set_title("吸引子（存储/伪吸引子）能量比较（静态）")
    bars = ax_bar.bar(np.arange(len(energies_sorted)), energies_sorted)
    ax_bar.set_xticks(np.arange(len(energies_sorted)))
    ax_bar.set_xticklabels(names_sorted, rotation=30, ha="right")
    ax_bar.set_ylabel("能量 E(x)")
    ax_bar.grid(axis="y", alpha=0.3)
    if len(energies_sorted) > 0:
        ymin_idx = int(np.argmin(energies_sorted))
        bars[ymin_idx].set_edgecolor("red")
        bars[ymin_idx].set_linewidth(2.0)

    # 给按钮留出空间
    fig.tight_layout(rect=[0, 0.08, 1, 0.97])

    # ================== 动画控制 ==================
    # 节奏参数：每帧对每个样本更新多少个神经元；帧间隔（毫秒）
    UPDATES_PER_FRAME = 5     # 更慢/更平滑可调小，如 2 或 1
    INTERVAL_MS = 40          # 帧间隔：越大越慢

    # 状态
    running = {'flag': False}  # 不点按钮不运行

    def on_start(event):
        running['flag'] = True
        btn_start.label.set_text('运行中...')
        btn_start.ax.set_facecolor('#cccccc')
        btn_start.hovercolor = '#cccccc'
        btn_start.eventson = False
        fig.canvas.draw_idle()

    # 按钮
    btn_ax = fig.add_axes([0.80, 0.01, 0.16, 0.06])
    btn_start = Button(btn_ax, '开始演示', color='#efefef', hovercolor='#dddddd')
    btn_start.on_clicked(on_start)

    # 动画更新函数（使用 fig.canvas.new_timer 循环调用）
    timer = fig.canvas.new_timer(interval=INTERVAL_MS)

    def update_frame(*args):
        if not running['flag']:
            return

        # “每帧”：让每个 runner 更新若干步
        all_done = True
        for i in range(P):
            r = picked[i].runner
            if r.stable or r.sweep_idx >= r.max_sweeps:
                # 已完成
                pass
            else:
                all_done = False
                r.step_many(UPDATES_PER_FRAME)

            # 更新左侧动态图像
            ims_dyn[i].set_data(r.current_image())

            # 更新右上能量曲线
            y = np.asarray(r.energies, dtype=float)
            x = np.arange(len(y))
            lines_energy[i].set_data(x, y)

        # 右上坐标轴自适应范围
        # x 轴到当前最大长度 + 5%
        max_len = max(len(p.runner.energies) for p in picked)
        ax_energy.set_xlim(0, max(50, int(max_len * 1.05)))
        # y 轴包络
        ymin = min(np.min(np.asarray(p.runner.energies)) for p in picked)
        ymax = max(np.max(np.asarray(p.runner.energies)) for p in picked)
        if ymax - ymin < 1e-9:
            ax_energy.set_ylim(ymin - 1.0, ymax + 1.0)
        else:
            pad = 0.05 * (ymax - ymin)
            ax_energy.set_ylim(ymin - pad, ymax + pad)

        fig.canvas.draw_idle()

        # 若全部完成，停止计时器
        if all_done:
            timer.stop()
            btn_start.label.set_text('已完成')
            fig.canvas.draw_idle()

    timer.add_callback(update_frame)
    timer.start()  # 启动计时器，但 running['flag']=False，所以不会动；点击按钮后才真正开始

    plt.show()

if __name__ == "__main__":
    main()
