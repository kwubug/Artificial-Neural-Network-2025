import sys
import numpy as np
import random
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QGroupBox,
                             QGridLayout, QTextEdit, QProgressBar, QSlider)
from PyQt5.QtCore import QTimer, Qt, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QColor, QPainter, QPen, QPalette
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis


class NeuronWidget(QWidget):
    """神经元可视化组件"""

    def __init__(self, index, state=1):
        super().__init__()
        self.index = index
        self.state = state
        self.setFixedSize(80, 80)

    def setState(self, state, animate=True):
        old_state = self.state
        self.state = state
        if animate and old_state != state:
            # 添加脉冲动画
            self.pulse_animation()
        self.update()

    def pulse_animation(self):
        """脉冲动画效果"""
        self.animation = QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(300)
        self.animation.setEasingCurve(QEasingCurve.OutBack)
        self.animation.setStartValue(self.geometry())
        self.animation.setEndValue(self.geometry().adjusted(-5, -5, 5, 5))
        self.animation.start()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制神经元圆圈
        if self.state == 1:
            color = QColor(76, 175, 80)  # 绿色 - 激活
            border_color = QColor(56, 142, 60)
        else:
            color = QColor(244, 67, 54)  # 红色 - 抑制
            border_color = QColor(183, 28, 28)

        painter.setBrush(color)
        painter.setPen(QPen(border_color, 3))
        painter.drawEllipse(5, 5, 70, 70)

        # 绘制状态符号
        painter.setPen(QPen(Qt.white, 2))
        if self.state == 1:
            # 加号
            painter.drawLine(30, 40, 50, 40)
            painter.drawLine(40, 30, 40, 50)
        else:
            # 减号
            painter.drawLine(30, 40, 50, 40)

        # 绘制标签
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(self.rect(), Qt.AlignBottom, f"N{self.index + 1}")


class HopfieldNetworkPure(QMainWindow):
    """纯PyQt5实现的Hopfield神经网络"""

    def __init__(self):
        super().__init__()
        # 初始化网络参数
        self.num_neurons = 25  # 5x5网格
        self.neurons = np.random.choice([-1, 1], size=self.num_neurons)
        self.weights = np.zeros((self.num_neurons, self.num_neurons))
        self.temperature = 1.0
        self.iteration = 0
        self.is_running = False
        self.energy_history = []
        self.attractors = []
        self.current_attractor = None
        self.patterns = []

        # 训练一些示例模式
        self.train_sample_patterns()

        self.timer = QTimer()
        self.timer.timeout.connect(self.async_update)

        self.init_ui()
        self.update_display()

    def train_sample_patterns(self):
        """训练示例模式"""
        sample_patterns = [
            # 字母X模式
            [-1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, -1],
            # 字母O模式
            [1, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1, -1, -1, 1, 1, -1, -1, -1, 1, 1, 1, 1, 1, 1],
        ]

        for pattern in sample_patterns:
            self.train_pattern(pattern)

    def train_pattern(self, pattern):
        """训练一个模式"""
        pattern_array = np.array(pattern)
        for i in range(self.num_neurons):
            for j in range(self.num_neurons):
                if i != j:
                    self.weights[i, j] += pattern_array[i] * pattern_array[j]
        self.patterns.append(pattern_array)

    def calculate_energy(self):
        """计算系统能量"""
        energy = 0
        for i in range(self.num_neurons):
            for j in range(i + 1, self.num_neurons):
                energy -= 0.5 * self.weights[i, j] * self.neurons[i] * self.neurons[j]
        return energy

    def async_update(self):
        """异步更新"""
        if not self.is_running:
            return

        # 随机选择神经元
        neuron_idx = random.randint(0, self.num_neurons - 1)

        # 计算输入
        input_sum = sum(self.weights[neuron_idx, j] * self.neurons[j]
                        for j in range(self.num_neurons) if j != neuron_idx)

        # 更新状态
        new_state = 1 if input_sum >= 0 else -1
        if new_state != self.neurons[neuron_idx]:
            self.neurons[neuron_idx] = new_state
            self.neuron_widgets[neuron_idx].setState(new_state)
            self.log(f"神经元 {neuron_idx + 1} 状态更新")

        # 更新能量
        energy = self.calculate_energy()
        self.energy_history.append(energy)
        self.iteration += 1

        self.update_display()
        self.check_attractor()

    def check_attractor(self):
        """检查吸引子"""
        if len(self.energy_history) < 10:
            return

        recent = self.energy_history[-10:]
        if np.std(recent) < 0.01:
            self.current_attractor = self.neurons.copy()
            if self.is_new_attractor(self.current_attractor):
                self.attractors.append(self.current_attractor.copy())
                self.log(f"🎯 发现吸引子！能量: {self.calculate_energy():.4f}")

    def is_new_attractor(self, state):
        """检查是否为新的吸引子"""
        for attractor in self.attractors:
            if np.array_equal(attractor, state) or np.array_equal(attractor, -state):
                return False
        return True

    def init_ui(self):
        """初始化界面"""
        self.setWindowTitle("离散型Hopfield神经网络 - 纯PyQt5实现")
        self.setGeometry(100, 100, 1200, 800)

        # 设置样式
        self.setStyleSheet("""
            QMainWindow { background-color: #2b2b2b; }
            QGroupBox { 
                border: 2px solid #555; 
                border-radius: 8px; 
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title { color: white; }
            QLabel { color: white; }
            QPushButton { 
                background-color: #2196F3; 
                color: white; 
                border: none; 
                padding: 8px; 
                border-radius: 4px;
            }
            QPushButton:hover { background-color: #1976D2; }
            QPushButton:disabled { background-color: #555; }
        """)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 标题
        title = QLabel("🧠 离散型Hopfield神经网络沙箱")
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #2196F3;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # 主要内容区域
        content_layout = QHBoxLayout()

        # 左侧：神经网络可视化
        left_panel = self.create_neural_network_panel()
        content_layout.addWidget(left_panel)

        # 右侧：控制面板
        right_panel = self.create_control_panel()
        content_layout.addWidget(right_panel)

        layout.addLayout(content_layout)

        # 底部：日志区域
        log_panel = self.create_log_panel()
        layout.addWidget(log_panel)

    def create_neural_network_panel(self):
        """创建神经网络可视化面板"""
        panel = QGroupBox("🔬 神经网络可视化 (5×5)")
        layout = QVBoxLayout(panel)

        # 创建5x5网格
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setSpacing(5)

        self.neuron_widgets = []
        for i in range(5):
            for j in range(5):
                index = i * 5 + j
                neuron = NeuronWidget(index, self.neurons[index])
                self.neuron_widgets.append(neuron)
                grid_layout.addWidget(neuron, i, j)

        layout.addWidget(grid_widget)

        # 状态信息
        info_layout = QGridLayout()
        info_layout.addWidget(QLabel("当前能量:"), 0, 0)
        self.energy_label = QLabel("0.0000")
        info_layout.addWidget(self.energy_label, 0, 1)

        info_layout.addWidget(QLabel("迭代次数:"), 1, 0)
        self.iteration_label = QLabel("0")
        info_layout.addWidget(self.iteration_label, 1, 1)

        info_layout.addWidget(QLabel("运行状态:"), 2, 0)
        self.status_label = QLabel("已停止")
        info_layout.addWidget(self.status_label, 2, 1)

        layout.addLayout(info_layout)

        return panel

    def create_control_panel(self):
        """创建控制面板"""
        panel = QGroupBox("🎮 控制面板")
        layout = QVBoxLayout(panel)

        # 控制按钮
        self.start_btn = QPushButton("🚀 开始模拟")
        self.stop_btn = QPushButton("⏹️ 停止模拟")
        self.reset_btn = QPushButton("🔄 重置网络")

        self.start_btn.clicked.connect(self.start_simulation)
        self.stop_btn.clicked.connect(self.stop_simulation)
        self.reset_btn.clicked.connect(self.reset_simulation)

        self.stop_btn.setEnabled(False)

        layout.addWidget(self.start_btn)
        layout.addWidget(self.stop_btn)
        layout.addWidget(self.reset_btn)

        # 速度控制
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("速度:"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(100, 1000)
        self.speed_slider.setValue(500)
        self.speed_slider.valueChanged.connect(self.change_speed)
        speed_layout.addWidget(self.speed_slider)

        layout.addLayout(speed_layout)

        return panel

    def create_log_panel(self):
        """创建日志面板"""
        panel = QGroupBox("📝 运行日志")
        layout = QVBoxLayout(panel)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(120)
        layout.addWidget(self.log_text)

        return panel

    def update_display(self):
        """更新显示"""
        energy = self.calculate_energy()
        self.energy_label.setText(f"{energy:.4f}")
        self.iteration_label.setText(str(self.iteration))

        # 更新状态标签颜色
        if self.is_running:
            self.status_label.setText("运行中")
            self.status_label.setStyleSheet("color: #4CAF50;")
        else:
            self.status_label.setText("已停止")
            self.status_label.setStyleSheet("color: #f44336;")

    def start_simulation(self):
        """开始模拟"""
        self.is_running = True
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.timer.start(self.speed_slider.value())
        self.log("🚀 开始Hopfield网络模拟")

    def stop_simulation(self):
        """停止模拟"""
        self.is_running = False
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.timer.stop()
        self.log("⏹️ 模拟停止")

    def reset_simulation(self):
        """重置模拟"""
        self.stop_simulation()
        self.neurons = np.random.choice([-1, 1], size=self.num_neurons)
        self.iteration = 0
        self.energy_history = []
        self.current_attractor = None

        # 更新所有神经元显示
        for i, widget in enumerate(self.neuron_widgets):
            widget.setState(self.neurons[i], animate=False)

        self.update_display()
        self.log("🔄 网络已重置")

    def change_speed(self, value):
        """改变模拟速度"""
        if self.is_running:
            self.timer.setInterval(value)

    def log(self, message):
        """添加日志"""
        timestamp = QTimer().remainingTime()  # 简单时间戳
        self.log_text.append(f"[{self.iteration:04d}] {message}")
        # 自动滚动到底部
        scrollbar = self.log_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())


def main():
    app = QApplication(sys.argv)

    # 设置应用字体
    font = QFont("Microsoft YaHei", 10)
    app.setFont(font)

    window = HopfieldNetworkPure()
    window.show()

    print("✅ Hopfield神经网络启动成功！")
    print("   网络规模: 5×5 (25个神经元)")
    print("   更新模式: 异步更新")
    print("   预训练模式: 2个")

    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())