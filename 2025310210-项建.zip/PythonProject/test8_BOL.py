import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.animation import FuncAnimation
from matplotlib.colors import LinearSegmentedColormap
import warnings

warnings.filterwarnings('ignore')


class BoltzmannMachine:
    def __init__(self, n_neurons=3, weights=None, biases=None, temperature=1.0):
        """
        初始化玻尔兹曼机

        Args:
            n_neurons: 神经元数量
            weights: 权重矩阵 (对称，对角线为0)
            biases: 偏置向量
            temperature: 温度参数
        """
        self.n_neurons = n_neurons

        if weights is None:
            # 随机初始化对称权重矩阵
            self.weights = np.random.uniform(-1, 1, (n_neurons, n_neurons))
            np.fill_diagonal(self.weights, 0)  # 无自连接
            # 确保对称
            self.weights = (self.weights + self.weights.T) / 2
        else:
            self.weights = weights

        if biases is None:
            self.biases = np.random.uniform(-0.5, 0.5, n_neurons)
        else:
            self.biases = biases

        self.temperature = temperature
        self.state = np.random.choice([-1, 1], size=n_neurons)  # 随机初始状态
        self.energy_history = []
        self.state_history = []
        self.probability_history = []

    def calculate_energy(self, state=None):
        """计算当前状态的能量"""
        if state is None:
            state = self.state
        energy = -0.5 * np.dot(state.T, np.dot(self.weights, state)) - np.dot(self.biases, state)
        return energy

    def calculate_probability(self, neuron_idx, proposed_state):
        """计算神经元状态改变的概率"""
        current_energy = self.calculate_energy()

        # 创建新状态
        new_state = self.state.copy()
        new_state[neuron_idx] = proposed_state
        new_energy = self.calculate_energy(new_state)

        # 计算能量差
        delta_energy = new_energy - current_energy

        # 玻尔兹曼概率
        probability = 1 / (1 + np.exp(delta_energy / self.temperature))

        return probability, delta_energy

    def update_neuron(self, neuron_idx):
        """更新单个神经元状态"""
        # 计算切换到相反状态的概率
        current_value = self.state[neuron_idx]
        proposed_value = -current_value

        probability, delta_energy = self.calculate_probability(neuron_idx, proposed_value)

        # 根据概率决定是否更新
        if np.random.random() < probability:
            self.state[neuron_idx] = proposed_value

        return probability, delta_energy

    def run_iteration(self, n_steps=100):
        """运行一次迭代"""
        for step in range(n_steps):
            # 随机选择神经元更新
            neuron_idx = np.random.randint(self.n_neurons)
            probability, delta_energy = self.update_neuron(neuron_idx)

            # 记录历史
            self.energy_history.append(self.calculate_energy())
            self.state_history.append(self.state.copy())
            self.probability_history.append(probability)

    def anneal_temperature(self, initial_temp, final_temp, steps):
        """模拟退火过程"""
        temperatures = np.linspace(initial_temp, final_temp, steps)
        state_distribution = []

        for temp in temperatures:
            self.temperature = temp
            self.run_iteration(n_steps=50)  # 每个温度运行一些步骤

            # 记录状态分布
            state_distribution.append(self.state.copy())

        return temperatures, state_distribution

    def find_thermal_equilibrium(self, convergence_threshold=0.01, max_iterations=1000):
        """寻找热平衡状态"""
        energy_std_history = []

        for iteration in range(max_iterations):
            # 运行一批更新
            batch_size = 100
            batch_energies = []

            for _ in range(batch_size):
                neuron_idx = np.random.randint(self.n_neurons)
                self.update_neuron(neuron_idx)
                batch_energies.append(self.calculate_energy())

            # 计算能量标准差
            energy_std = np.std(batch_energies)
            energy_std_history.append(energy_std)

            # 检查是否达到热平衡
            if energy_std < convergence_threshold:
                print(f"Reached thermal equilibrium after {iteration} iterations")
                print(f"Final energy standard deviation: {energy_std:.4f}")
                break

        return energy_std_history

    def get_state_probabilities(self, n_samples=10000):
        """通过采样估计各状态的概率分布"""
        state_counts = {}

        # 保存当前状态
        original_state = self.state.copy()
        original_temp = self.temperature

        # 采样
        for _ in range(n_samples):
            neuron_idx = np.random.randint(self.n_neurons)
            self.update_neuron(neuron_idx)

            # 将状态转换为字符串作为键
            state_key = tuple(self.state)
            state_counts[state_key] = state_counts.get(state_key, 0) + 1

        # 恢复原始状态
        self.state = original_state
        self.temperature = original_temp

        # 计算概率
        total_samples = sum(state_counts.values())
        state_probs = {state: count / total_samples for state, count in state_counts.items()}

        return state_probs


def visualize_boltzmann_machine(bm, num_iterations=200):
    """可视化玻尔兹曼机的运行过程"""
    fig = plt.figure(figsize=(15, 10))

    # 创建子图布局
    gs = plt.GridSpec(3, 3, figure=fig)

    # 神经元状态可视化
    ax1 = fig.add_subplot(gs[0, 0])
    # 能量变化
    ax2 = fig.add_subplot(gs[0, 1:])
    # 权重矩阵
    ax3 = fig.add_subplot(gs[1, 0])
    # 概率变化
    ax4 = fig.add_subplot(gs[1, 1])
    # 状态分布
    ax5 = fig.add_subplot(gs[1, 2])
    # 神经元活动
    ax6 = fig.add_subplot(gs[2, :])

    # 清除历史记录
    bm.energy_history = []
    bm.state_history = []
    bm.probability_history = []

    # 运行初始迭代以填充数据
    bm.run_iteration(n_steps=num_iterations)

    # 1. 神经元状态可视化（热图）
    def plot_neuron_states(ax, state):
        cmap = LinearSegmentedColormap.from_list('neuron_state', ['red', 'white', 'blue'])
        state_matrix = state.reshape(1, -1)
        im = ax.imshow(state_matrix, cmap=cmap, vmin=-1, vmax=1, aspect='auto')
        ax.set_xticks(range(bm.n_neurons))
        ax.set_xticklabels([f'N{i + 1}' for i in range(bm.n_neurons)])
        ax.set_yticks([])
        ax.set_title('Neuron States\n(Red: -1, Blue: +1)')

        # 添加数值标签
        for i, val in enumerate(state):
            color = 'white' if abs(val) < 0.5 else 'black'
            ax.text(i, 0, f'{val}', ha='center', va='center', color=color, fontweight='bold')

        return im

    # 2. 能量变化图
    def plot_energy(ax, energy_history):
        ax.clear()
        ax.plot(energy_history, 'b-', alpha=0.7, linewidth=2)
        ax.set_xlabel('Iteration')
        ax.set_ylabel('Energy')
        ax.set_title('Energy Convergence')
        ax.grid(True, alpha=0.3)

        # 添加当前能量值
        if energy_history:
            current_energy = energy_history[-1]
            ax.axhline(y=current_energy, color='r', linestyle='--', alpha=0.8)
            ax.text(0.7, 0.9, f'Current: {current_energy:.3f}',
                    transform=ax.transAxes, bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

    # 3. 权重矩阵可视化
    def plot_weights(ax, weights):
        im = ax.imshow(weights, cmap='coolwarm', vmin=-1, vmax=1)
        ax.set_xticks(range(bm.n_neurons))
        ax.set_yticks(range(bm.n_neurons))
        ax.set_xticklabels([f'N{i + 1}' for i in range(bm.n_neurons)])
        ax.set_yticklabels([f'N{i + 1}' for i in range(bm.n_neurons)])
        ax.set_title('Weight Matrix')

        # 添加数值标签
        for i in range(bm.n_neurons):
            for j in range(bm.n_neurons):
                color = 'white' if abs(weights[i, j]) > 0.5 else 'black'
                ax.text(j, i, f'{weights[i, j]:.2f}', ha='center', va='center', color=color, fontsize=8)

        return im

    # 4. 概率变化图
    def plot_probability(ax, prob_history):
        ax.clear()
        ax.plot(prob_history, 'g-', alpha=0.7)
        ax.set_xlabel('Iteration')
        ax.set_ylabel('Update Probability')
        ax.set_title('State Update Probability')
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 1)

        if prob_history:
            current_prob = prob_history[-1]
            ax.axhline(y=current_prob, color='r', linestyle='--', alpha=0.8)

    # 5. 状态分布图
    def plot_state_distribution(ax, state_history):
        if len(state_history) < 10:
            return

        recent_states = state_history[-100:]  # 最近100个状态
        state_strings = [''.join(map(str, state)) for state in recent_states]

        state_counts = {}
        for state in state_strings:
            state_counts[state] = state_counts.get(state, 0) + 1

        if state_counts:
            states = list(state_counts.keys())
            counts = list(state_counts.values())

            ax.clear()
            bars = ax.bar(range(len(states)), counts, color='skyblue', alpha=0.7)
            ax.set_xlabel('State')
            ax.set_ylabel('Frequency')
            ax.set_title('Recent State Distribution')
            ax.set_xticks(range(len(states)))
            ax.set_xticklabels(states, rotation=45)

            # 在柱子上添加数值
            for bar, count in zip(bars, counts):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width() / 2., height,
                        f'{count}', ha='center', va='bottom', fontsize=8)

    # 6. 神经元活动时间序列
    def plot_neuron_activity(ax, state_history):
        if len(state_history) < 2:
            return

        recent_history = state_history[-50:]  # 最近50个时间步
        activity_matrix = np.array(recent_history).T

        ax.clear()
        for i in range(bm.n_neurons):
            ax.plot(activity_matrix[i], 'o-', label=f'N{i + 1}', alpha=0.7, markersize=4)

        ax.set_xlabel('Time Step (recent)')
        ax.set_ylabel('State')
        ax.set_title('Neuron Activity Timeline')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim(-1.5, 1.5)

    # 初始绘图
    plot_neuron_states(ax1, bm.state)
    plot_energy(ax2, bm.energy_history)
    plot_weights(ax3, bm.weights)
    plot_probability(ax4, bm.probability_history)
    plot_state_distribution(ax5, bm.state_history)
    plot_neuron_activity(ax6, bm.state_history)

    plt.tight_layout()
    plt.show()

    return bm


def analyze_thermal_equilibrium(bm):
    """分析热平衡状态"""
    print("=== Thermal Equilibrium Analysis ===")

    # 寻找热平衡
    print("\n1. Finding thermal equilibrium...")
    energy_std_history = bm.find_thermal_equilibrium()

    # 估计状态概率分布
    print("\n2. Estimating state probabilities...")
    state_probs = bm.get_state_probabilities(n_samples=5000)

    # 显示结果
    print("\n3. Results:")
    print(f"Current temperature: {bm.temperature:.3f}")
    print(f"Current state: {bm.state}")
    print(f"Current energy: {bm.calculate_energy():.3f}")

    print("\nState probability distribution:")
    sorted_states = sorted(state_probs.items(), key=lambda x: x[1], reverse=True)
    for state, prob in sorted_states:
        energy = bm.calculate_energy(np.array(state))
        print(f"  State {state}: Probability = {prob:.4f}, Energy = {energy:.3f}")

    # 绘制能量标准差收敛图
    plt.figure(figsize=(10, 6))
    plt.plot(energy_std_history, 'r-', linewidth=2)
    plt.xlabel('Iteration Batch')
    plt.ylabel('Energy Standard Deviation')
    plt.title('Convergence to Thermal Equilibrium')
    plt.grid(True, alpha=0.3)
    plt.yscale('log')
    plt.show()

    return state_probs


def demo_temperature_effect():
    """演示温度对玻尔兹曼机行为的影响"""
    print("=== Temperature Effect Demonstration ===")

    # 使用固定的权重和偏置以便比较
    fixed_weights = np.array([[0, 0.8, -0.5],
                              [0.8, 0, 0.6],
                              [-0.5, 0.6, 0]])

    fixed_biases = np.array([0.2, -0.3, 0.1])

    temperatures = [2.0, 1.0, 0.5, 0.1]

    plt.figure(figsize=(15, 10))

    for i, temp in enumerate(temperatures):
        bm = BoltzmannMachine(n_neurons=3, weights=fixed_weights,
                              biases=fixed_biases, temperature=temp)

        # 运行网络达到平衡
        bm.find_thermal_equilibrium()

        # 采样状态分布
        state_probs = bm.get_state_probabilities(n_samples=3000)

        # 绘制状态分布
        plt.subplot(2, 2, i + 1)
        states = list(state_probs.keys())
        probs = list(state_probs.values())

        # 将状态转换为字符串标签
        state_labels = [''.join(map(str, state)) for state in states]

        bars = plt.bar(state_labels, probs, color='lightcoral', alpha=0.7)
        plt.title(f'Temperature = {temp}')
        plt.ylabel('Probability')
        plt.xticks(rotation=45)

        # 在柱子上添加概率值
        for bar, prob in zip(bars, probs):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width() / 2., height,
                     f'{prob:.3f}', ha='center', va='bottom', fontsize=8)

    plt.suptitle('State Distributions at Different Temperatures')
    plt.tight_layout()
    plt.show()


# 主演示函数
def main():
    print("=== 3-Neuron Boltzmann Machine Demo ===")

    # 创建玻尔兹曼机实例
    print("\n1. Creating Boltzmann Machine with 3 neurons...")

    # 使用示例权重和偏置
    example_weights = np.array([[0, 0.5, -0.3],
                                [0.5, 0, 0.7],
                                [-0.3, 0.7, 0]])

    example_biases = np.array([0.1, -0.2, 0.05])

    bm = BoltzmannMachine(n_neurons=3, weights=example_weights,
                          biases=example_biases, temperature=1.0)

    print("Initial state:", bm.state)
    print("Initial energy:", bm.calculate_energy())
    print("Temperature:", bm.temperature)

    # 可视化运行过程
    print("\n2. Visualizing BM operation...")
    bm = visualize_boltzmann_machine(bm, num_iterations=300)

    # 分析热平衡
    print("\n3. Analyzing thermal equilibrium...")
    state_probs = analyze_thermal_equilibrium(bm)

    # 演示温度影响
    print("\n4. Demonstrating temperature effects...")
    demo_temperature_effect()

    # 模拟退火演示
    print("\n5. Simulated annealing demonstration...")
    bm_anneal = BoltzmannMachine(n_neurons=3, weights=example_weights,
                                 biases=example_biases, temperature=2.0)

    temperatures, state_distribution = bm_anneal.anneal_temperature(initial_temp=2.0,
                                                                    final_temp=0.1,
                                                                    steps=50)

    # 绘制退火过程
    plt.figure(figsize=(12, 8))

    # 能量随温度变化
    energies = [bm_anneal.calculate_energy(state) for state in state_distribution]

    plt.subplot(2, 1, 1)
    plt.plot(temperatures, energies, 'bo-', linewidth=2, markersize=4)
    plt.xlabel('Temperature')
    plt.ylabel('Energy')
    plt.title('Energy vs Temperature during Annealing')
    plt.grid(True, alpha=0.3)

    # 状态随温度变化
    plt.subplot(2, 1, 2)
    state_matrix = np.array(state_distribution)
    for i in range(3):
        plt.plot(temperatures, state_matrix[:, i], 'o-', label=f'Neuron {i + 1}', markersize=3)
    plt.xlabel('Temperature')
    plt.ylabel('State')
    plt.title('Neuron States vs Temperature')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()