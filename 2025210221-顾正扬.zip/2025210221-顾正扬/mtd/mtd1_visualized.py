import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# 定义函数 F(x)
def F1(x1, x2):
    return 2 * x1 ** 2 + 50 * x2 ** 2


def F2(x1, x2):
    return x1 ** 2 + x1 * x2 + x2 ** 2


# 创建 x1 和 x2 的网格
x1 = np.linspace(-1, 1, 400)
x2 = np.linspace(-1, 1, 400)
X1, X2 = np.meshgrid(x1, x2)

Z = F1(X1, X2)
# Z = F2(X1, X2)

# 绘制等高线图
plt.figure(figsize=(8, 6))
contour = plt.contour(X1, X2, Z, levels=200, cmap='viridis')
plt.clabel(contour, inline=True, fontsize=8)
plt.title('Contour plot')
plt.xlabel('x1')
plt.ylabel('x2')
plt.colorbar(contour)
plt.grid(True)

'''m1_固定学习率进行性能优化，f1,f2 50次学习'''
# f1 = pd.read_excel('m1_F1_1.xlsx')
# plt.plot(f1['x1'], f1['x2'], label='F1_1', marker='.', linestyle='-', color='red')
# f2 = pd.read_excel('m1_F1_2.xlsx')
# plt.plot(f2['x1'], f2['x2'], label='F1_2', marker='.', linestyle='-', color='green')
'''m1_固定学习率进行性能优化，f3学习25次, f4学习15次'''
# f3 = pd.read_excel('m1_F1_3.xlsx')
# plt.plot(f3['x1'], f3['x2'], label='F1_3', marker='.', linestyle='-', color='blue')
# f4 = pd.read_excel('m1_F1_4.xlsx')
# plt.plot(f4['x1'], f4['x2'], label='F1_4', marker='.', linestyle='-', color='purple')

'''m2_NEWTON 二元二次多项式，1次学习'''
f = pd.read_excel('m2_F1.xlsx')
plt.plot(f['x1'], f['x2'], label='F1_m2_NEWTON', marker='.', linestyle='-', color='lime')

# 添加图例
plt.legend()
plt.show()
