# 三神经元 Boltzmann Machine 模块设计方案

## 🎯 项目目标

实现一个**可视化的三神经元 Boltzmann Machine**，展示：

1. ✅ **概率性神经元动态** — 不像 Hopfield 的确定性更新
2. ✅ **温度退火过程** — 从高温混乱到低温有序
3. ✅ **热平衡状态** — 最终收敛到 Boltzmann 分布
4. ✅ **状态空间轨迹** — 可视化 8 种可能状态的转移
5. ✅ **能量景观** — 实时显示每个状态的能量和概率

---

## 📐 三神经元 BM 的数学基础

### 状态空间

由 3 个二值神经元组成，共 $2^3 = 8$ 种可能状态：

```
状态编号  神经元状态  二进制
─────────────────────────
0         (0,0,0)    000
1         (0,0,1)    001
2         (0,1,0)    010
3         (0,1,1)    011
4         (1,0,0)    100
5         (1,0,1)    101
6         (1,1,0)    110
7         (1,1,1)    111
```

### 能量函数

$$E(x) = -\frac{1}{2} \sum_{i,j} W_{ij} x_i x_j - \sum_i b_i x_i$$

其中：
- $W_{ij}$ = 神经元 i 和 j 之间的连接权重（对称）
- $b_i$ = 神经元 i 的偏置
- $x_i \in \{0, 1\}$

### Boltzmann 分布

在温度 T 下，系统在状态 s 的概率为：

$$P(s|T) = \frac{e^{-E(s)/T}}{\sum_{s'} e^{-E(s')/T}}$$

关键性质：
- **高温 T → ∞**：所有状态概率相等（完全随机）
- **低温 T → 0**：最低能量状态概率最高（接近确定性）
- **T = 1**：平衡点（标准 Boltzmann 分布）

### 概率性更新（Gibbs Sampling）

对于神经元 i，在温度 T 下的激活概率：

$$P(x_i = 1) = \frac{1}{1 + e^{-(\sum_j W_{ij} x_j + b_i)/T}}$$

（这是 sigmoid 函数，温度 T 作为"软化"参数）

---

## 🎨 UI 设计规划

### 主要组件

```
┌─────────────────────────────────────────────────────┐
│  Boltzmann Machine - 三神经元热平衡状态可视化      │
├─────────────────────────────────────────────────────┤
│                                                      │
│  【第一行】Temperature Control                      │
│  ├─ Temperature Slider: 0.1 ~ 5.0                 │
│  ├─ Current Temperature: 显示当前温度              │
│  └─ Annealing Speed: 温度冷却速率                 │
│                                                      │
│  【第二行】Network Visualization (左侧)            │
│  ├─ 三个神经元（圆形）                            │
│  │   ├─ 神经元 1 (顶部)                          │
│  │   ├─ 神经元 2 (左下)                          │
│  │   ├─ 神经元 3 (右下)                          │
│  │   └─ 连接线显示权重（粗细/颜色表示）          │
│  │                                                │
│  ├─ 当前状态显示                                 │
│  │   Current State: (x1, x2, x3) = (0, 1, 0)   │
│  │   Current Energy: -2.5                       │
│  │   Probability: 15.3%                         │
│  │   Converged: Yes/No                          │
│                                                      │
│  【第三行】State Space Exploration (右侧)         │
│  ├─ 8 个方块代表 8 种状态：                       │
│  │   ┌─────────────────────┐                    │
│  │   │ 000 │ 001 │ 010 │ 011 │                  │
│  │   │ 100 │ 101 │ 110 │ 111 │                  │
│  │   └─────────────────────┘                    │
│  │                                                │
│  │   颜色深度 = 该状态被访问的频率               │
│  │   当前状态 = 高亮显示                        │
│  │   大小 = 该状态在 Boltzmann 分布中的概率     │
│  │                                                │
│  ├─ Energy Distribution                          │
│  │   显示每个状态的能量值和概率（柱状图）        │
│  │                                                │
│  【第四行】Control Buttons                         │
│  ├─ Initialize: 随机初始化状态和权重             │
│  ├─ Step: 执行一次 Gibbs 采样                    │
│  ├─ Run Annealing: 从高温自动冷却到低温         │
│  └─ Reset: 重置所有参数                         │
│                                                      │
│  【第五行】Statistics Panel                        │
│  ├─ Visited States: 访问过多少种状态              │
│  ├─ State Distribution: 各状态被访问频率          │
│  ├─ Average Energy: 平均能量                      │
│  └─ Convergence Time: 收敛用时                   │
│                                                      │
│  【第六行】History Timeline                        │
│  ├─ 显示状态转移序列：000 → 001 → 011 → 101 → ...
│  ├─ Energy Evolution 曲线                        │
│  └─ Temperature Schedule 曲线                    │
│                                                      │
└─────────────────────────────────────────────────────┘
```

### 交互流程

```
1. Initialize
   ├─ 随机设置权重 W 和偏置 b
   ├─ 显示权重矩阵和能量景观
   ├─ 设置初始温度 T（比如 3.0）
   └─ 随机初始化神经元状态

2. Step
   ├─ 随机选择一个神经元 i
   ├─ 计算激活概率 P(x_i=1 | other neurons, T)
   ├─ 按概率采样新状态：x_i_new ~ Bernoulli(P)
   ├─ 计算新能量
   ├─ 更新能量和概率显示
   └─ 记录状态访问

3. Run Annealing (自动)
   ├─ 循环调用 Step
   ├─ 每 N 步降低温度 T = T / (1 + cooling_rate × step)
   ├─ 直到 T < 0.01（接近 0）
   ├─ 绘制温度和能量的演化曲线
   └─ 显示最终收敛状态

4. 实时显示
   ├─ Network Visualization: 神经元状态实时更新
   ├─ State Space: 当前状态高亮，访问频率热力图
   ├─ Energy Distribution: 实时更新概率分布
   └─ Statistics: 更新访问统计
```

---

## 🛠️ 文件结构规划

```
nn_sandbox/
├── backend/
│   └── algorithms/
│       └── bm_algorithm.py          # 核心算法
│
├── bridges/
│   └── bm_bridge.py                 # Qt 桥接
│
└── frontend/
    └── components/
        └── dashboards/
            └── BoltzmannMachine.qml  # UI 界面
```

---

## 🔬 后端实现要点（bm_algorithm.py）

### 核心类结构

```python
class BoltzmannMachine:
    def __init__(self, num_neurons=3):
        self._num_neurons = 3
        self._state = [0, 0, 0]                    # 当前状态
        self._weights = random_matrix(3, 3)       # 权重矩阵
        self._biases = random_vector(3)           # 偏置项
        self._temperature = 3.0                   # 当前温度
        self._energy = 0.0                        # 当前能量
        self._probabilities = [0.0] * 8          # 8 种状态的概率
        self._state_history = []                  # 状态转移历史
        self._visit_count = [0] * 8              # 每种状态访问次数
        self._converged = False
    
    def calculate_energy(self, state):
        """计算给定状态的能量"""
        E = 0.0
        for i in range(3):
            for j in range(i+1, 3):
                E -= self._weights[i][j] * state[i] * state[j]
            E -= self._biases[i] * state[i]
        return E
    
    def calculate_all_energies(self):
        """计算所有 8 种状态的能量"""
        energies = []
        for s in range(8):
            state = [(s >> i) & 1 for i in range(3)]
            E = self.calculate_energy(state)
            energies.append(E)
        return energies
    
    def calculate_probabilities(self, temperature):
        """计算 Boltzmann 分布"""
        energies = self.calculate_all_energies()
        # P(s) = exp(-E(s)/T) / Z
        # 使用 log-sum-exp trick 避免数值溢出
        min_E = min(energies)
        exp_energies = [np.exp(-(E - min_E)/temperature) for E in energies]
        Z = sum(exp_energies)
        return [e / Z for e in exp_energies]
    
    def gibbs_sampling_step(self):
        """执行一次 Gibbs 采样"""
        # 随机选择一个神经元
        i = np.random.randint(0, 3)
        
        # 计算激活概率
        energy_diff = self._calculate_activation_probability(i)
        prob = 1.0 / (1.0 + np.exp(-energy_diff / self._temperature))
        
        # 按概率采样
        self._state[i] = 1 if np.random.random() < prob else 0
        
        # 更新能量和概率
        self._energy = self.calculate_energy(self._state)
        self._probabilities = self.calculate_probabilities(self._temperature)
        
        # 记录历史
        state_id = self._state_to_id(self._state)
        self._state_history.append(state_id)
        self._visit_count[state_id] += 1
    
    def anneal(self, num_steps=100, cooling_rate=0.01):
        """温度退火过程"""
        for step in range(num_steps):
            # 执行 Gibbs 采样
            self.gibbs_sampling_step()
            
            # 降低温度
            self._temperature *= 1.0 / (1.0 + cooling_rate * step)
            
            # 更新概率
            self._probabilities = self.calculate_probabilities(self._temperature)
        
        # 检查收敛
        self._converged = (self._temperature < 0.01)
    
    def set_temperature(self, T):
        """设置温度并更新概率"""
        self._temperature = T
        self._probabilities = self.calculate_probabilities(T)
```

---

## 🎬 UI 实现要点（BoltzmannMachine.qml）

### 三神经元网络可视化

```qml
Canvas {
    id: networkCanvas
    
    onPaint: {
        var ctx = getContext('2d')
        
        // 绘制三个神经元（圆形）
        var positions = [
            {x: width/2, y: 50},      // 顶部
            {x: 80, y: height-80},     // 左下
            {x: width-80, y: height-80} // 右下
        ]
        
        // 绘制连接线（权重）
        for (var i = 0; i < 3; i++) {
            for (var j = i+1; j < 3; j++) {
                var w = bmBridge.weights_matrix[i*3+j]
                ctx.lineWidth = 1 + Math.abs(w) * 3
                ctx.strokeStyle = w > 0 ? '#0066FF' : '#FF6600'
                ctx.beginPath()
                ctx.moveTo(positions[i].x, positions[i].y)
                ctx.lineTo(positions[j].x, positions[j].y)
                ctx.stroke()
            }
        }
        
        // 绘制神经元（圆形）
        for (var i = 0; i < 3; i++) {
            ctx.fillStyle = current_state[i] === 1 ? '#0066FF' : '#CCCCCC'
            ctx.beginPath()
            ctx.arc(positions[i].x, positions[i].y, 30, 0, 2*Math.PI)
            ctx.fill()
            
            // 标注
            ctx.fillStyle = '#FFFFFF'
            ctx.font = 'bold 16px Arial'
            ctx.textAlign = 'center'
            ctx.textBaseline = 'middle'
            ctx.fillText('x' + (i+1), positions[i].x, positions[i].y)
        }
    }
}
```

### 状态空间热力图

```qml
Rectangle {
    id: stateSpaceGrid
    
    // 8 个方块 (2x4 网格)
    Grid {
        columns: 4
        spacing: 4
        
        Repeater {
            model: 8
            
            Rectangle {
                width: 60
                height: 60
                
                // 颜色深度 = 访问频率
                color: {
                    var freq = visit_count[index] / total_visits
                    return Qt.hsla(0.6, 0.8, 1.0 - freq * 0.8, 1.0)
                }
                
                // 大小 = 概率
                scale: 0.5 + probabilities[index] * 1.5
                
                border.color: current_state_id === index ? '#00FF00' : '#999999'
                border.width: current_state_id === index ? 3 : 1
                
                Text {
                    anchors.centerIn: parent
                    text: {
                        var binary = index.toString(2).padStart(3, '0')
                        return '(' + binary[0] + ',' + binary[1] + ',' + binary[2] + ')'
                    }
                    font.pixelSize: 12
                    color: '#000000'
                }
            }
        }
    }
}
```

---

## 📊 关键显示指标

### 实时更新的信息

| 指标 | 更新频率 | 说明 |
|-----|--------|------|
| Current State | 每 Step | 当前三神经元状态 (0/1, 0/1, 0/1) |
| Current Energy | 每 Step | 当前状态的能量值 |
| Temperature | 每 Step（退火时） | 当前温度 T |
| Probability | 每 Step | 当前状态在 Boltzmann 分布中的概率 |
| Avg Energy | 每 N Step | 历史平均能量 |
| State Diversity | 实时 | 访问过的不同状态数 |
| Convergence Progress | 退火时 | 温度下降进度 |

---

## 🎯 演示场景

### 场景 1：从高温混乱到低温有序

```
初始：T = 3.0（高温）
├─ 状态随机转移
├─ 所有 8 种状态被访问的概率近似
├─ 能量在 8 个值之间随机波动

中期：T = 1.0（中温）
├─ 倾向于低能量状态
├─ 某些状态被访问更频繁
├─ 能量均值下降

最终：T = 0.1（低温）
├─ 几乎确定地停在最低能量状态
├─ 能量稳定
├─ 状态基本不变

效果：直观展示温度如何影响系统行为
```

### 场景 2：不同权重配置的吸引子

```
配置 1：所有权重正（相互兴奋）
→ 最终在 (1,1,1) 或 (0,0,0) 状态

配置 2：混合权重（相互竞争）
→ 最终在多个吸引子之间转移

配置 3：随机权重
→ 可能多个局部最小值
```

---

## ✨ 相比 Hopfield 的优势

| 特性 | Hopfield | Boltzmann Machine |
|-----|---------|------------------|
| **更新方式** | 确定性 | 概率性 ✨ |
| **避免陷阱** | 容易陷入局部最小值 | 通过温度可以逃脱 ✨ |
| **输出** | 单一稳定状态 | 可采样，分布式表示 |
| **应用** | 关联记忆 | 生成模型、采样 |
| **可视化** | 2D 路径 | 完整概率分布 ✨ |

---

## 📅 实现步骤（建议）

1. **第一步**：实现 bm_algorithm.py（核心算法）
   - 能量计算
   - Gibbs 采样
   - Boltzmann 分布

2. **第二步**：实现 bm_bridge.py（Qt 桥接）
   - 暴露所有属性
   - 暴露所有 Slots

3. **第三步**：实现 BoltzmannMachine.qml（UI）
   - 基础布局
   - Canvas 绘制
   - 交互控制

4. **第四步**：集成和调试
   - 注册到 main.py
   - 添加标签页
   - 完整测试

5. **第五步**：文档编写
   - 使用指南
   - 架构说明

---

这就是完整的三神经元 BM 模块设计方案！

需要我现在开始实现吗？我建议从 **bm_algorithm.py** 开始。要我继续吗？ 🚀
