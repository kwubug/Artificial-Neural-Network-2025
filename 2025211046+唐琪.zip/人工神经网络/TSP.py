import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
import random
from matplotlib.animation import FuncAnimation

def create_cities(num_cities, seed=42):
    """创建随机的城市坐标"""
    np.random.seed(seed)
    return np.random.rand(num_cities, 2) * 100



NUM_CITIES = 20
POPULATION_SIZE = 100
NUM_GENERATIONS = 200
MUTATION_RATE = 0.01
CROSSOVER_RATE = 0.8


def calculate_distance(city1, city2):
    """计算两个城市之间的欧几里得距离"""
    return np.linalg.norm(city1 - city2)


def calculate_path_length(path, cities):
    """计算一条路径的总长度"""
    total_length = 0
    num_cities = len(path)
    for i in range(num_cities - 1):
        total_length += calculate_distance(cities[path[i]], cities[path[i + 1]])
    total_length += calculate_distance(cities[path[-1]], cities[path[0]])
    return total_length


def fitness(path, cities):
    """适应度函数：路径越短，适应度越高"""
    return 1 / (1 + calculate_path_length(path, cities))


def create_initial_population(num_cities, population_size):
    """创建初始种群"""
    population = []
    for _ in range(population_size):
        path = list(np.random.permutation(num_cities))
        population.append(path)
    return population


def selection(population, fitnesses):
    """轮盘赌选择法"""
    total_fitness = sum(fitnesses)
    probabilities = [f / total_fitness for f in fitnesses]

    r = random.random()
    cumulative_prob = 0
    for i, prob in enumerate(probabilities):
        cumulative_prob += prob
        if r <= cumulative_prob:
            return population[i]
    return population[-1]


def order_crossover(parent1, parent2):
    """顺序交叉 (OX)"""
    size = len(parent1)

    start, end = sorted(random.sample(range(size), 2))
    child = [None] * size
    child[start:end + 1] = parent1[start:end + 1]
    p2_filtered = [item for item in parent2 if item not in child]

    ptr = 0
    for i in range(size):
        if child[i] is None:
            child[i] = p2_filtered[ptr]
            ptr += 1
    return child


def mutate(path, mutation_rate):
    """变异：随机交换两个城市的位置"""
    if random.random() < mutation_rate:
        i, j = random.sample(range(len(path)), 2)
        path[i], path[j] = path[j], path[i]
    return path




def main():

    cities = create_cities(NUM_CITIES)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    fig.suptitle('TSP Genetic Algorithm Visualization')

    ax1.scatter(cities[:, 0], cities[:, 1], color='red', s=100, zorder=5)
    for i, (x, y) in enumerate(cities):
        ax1.annotate(str(i), (x, y), fontsize=12, ha='center', va='center', color='white', fontweight='bold')

    line, = ax1.plot([], [], 'b-', linewidth=2, zorder=1)
    best_path_text = ax1.text(0.05, 0.95, '', transform=ax1.transAxes, fontsize=12,
                              verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    ax2.set_xlabel('Generation')
    ax2.set_ylabel('Best Fitness')
    ax2.set_xlim(0, NUM_GENERATIONS)
    fitness_history = []
    fitness_line, = ax2.plot([], [], 'g-', linewidth=2)
    population = create_initial_population(NUM_CITIES, POPULATION_SIZE)
    best_fitness = -float('inf')
    best_path = None

    def update(frame):
        nonlocal population, best_fitness, best_path, fitness_history

        fitnesses = [fitness(path, cities) for path in population]
        current_best_idx = np.argmax(fitnesses)
        current_best_fitness = fitnesses[current_best_idx]
        current_best_path = population[current_best_idx]
        if current_best_fitness > best_fitness:
            best_fitness = current_best_fitness
            best_path = current_best_path.copy()
        fitness_history.append(best_fitness)
        path_coords = cities[best_path]
        path_coords = np.append(path_coords, [path_coords[0]], axis=0)
        line.set_data(path_coords[:, 0], path_coords[:, 1])
        best_path_text.set_text(f'Best Path (Gen {frame + 1})\nLength: {calculate_path_length(best_path, cities):.2f}')
        fitness_line.set_data(range(len(fitness_history)), fitness_history)
        ax2.set_ylim(0, max(fitness_history) * 1.1 if fitness_history else 1)
        new_population = []
        new_population.append(best_path)
        while len(new_population) < POPULATION_SIZE:
            parent1 = selection(population, fitnesses)
            parent2 = selection(population, fitnesses)
            if random.random() < CROSSOVER_RATE:
                child1 = order_crossover(parent1, parent2)
                child2 = order_crossover(parent2, parent1)
            else:
                child1, child2 = parent1.copy(), parent2.copy()
            child1 = mutate(child1, MUTATION_RATE)
            child2 = mutate(child2, MUTATION_RATE)
            new_population.append(child1)
            if len(new_population) < POPULATION_SIZE:
                new_population.append(child2)
        population = new_population
        return line, fitness_line, best_path_text
    ani = FuncAnimation(fig, update, frames=NUM_GENERATIONS, interval=100, blit=True)
    plt.tight_layout()
    plt.show()
    print("\n遗传算法优化完成！")
    print(f"最佳路径长度: {calculate_path_length(best_path, cities):.2f}")
    print(f"最佳路径顺序: {best_path}")
if __name__ == "__main__":
    main()