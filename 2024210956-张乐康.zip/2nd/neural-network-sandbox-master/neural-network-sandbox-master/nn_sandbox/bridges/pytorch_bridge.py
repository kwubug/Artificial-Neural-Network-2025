from PyQt5.QtCore import QObject, pyqtProperty, pyqtSignal
import torch
import torch.nn as nn
import numpy as np


class PyTorchBridge(QObject):
    def __init__(self):
        super().__init__()
        self._model = None
        self._loss = float('inf')
        self._dataset_name = ""
        self._training_data = None
        self._training_labels = None

    # 信号定义
    lossChanged = pyqtSignal(float)
    datasetChanged = pyqtSignal(str)
    trainingStarted = pyqtSignal()
    trainingFinished = pyqtSignal()

    @pyqtProperty(float, notify=lossChanged)
    def loss(self):
        return self._loss

    @pyqtProperty(str, notify=datasetChanged)
    def datasetName(self):
        return self._dataset_name

    def set_training_data(self, data, labels, dataset_name=""):
        """设置训练数据"""
        self._training_data = torch.FloatTensor(data)
        self._training_labels = torch.FloatTensor(labels)
        self._dataset_name = dataset_name
        self.datasetChanged.emit(dataset_name)

    def init_model(self, input_size, hidden_size, output_size):
        """初始化模型"""
        self._model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.Sigmoid() if output_size == 1 else nn.Softmax(dim=1)
        )

    def train(self, epochs=1000, learning_rate=0.01):
        """训练方法"""
        if self._training_data is None or self._model is None:
            return

        self.trainingStarted.emit()

        criterion = nn.BCELoss() if self._training_labels.shape[1] == 1 else nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(self._model.parameters(), lr=learning_rate)

        for epoch in range(epochs):
            optimizer.zero_grad()
            outputs = self._model(self._training_data)
            loss = criterion(outputs, self._training_labels)
            loss.backward()
            optimizer.step()

            # 更新界面
            self._loss = loss.item()
            self.lossChanged.emit(self._loss)

        self.trainingFinished.emit()

    def get_predictions(self, data):
        """获取预测结果"""
        if self._model is None:
            return None
        with torch.no_grad():
            return self._model(torch.FloatTensor(data)).numpy()