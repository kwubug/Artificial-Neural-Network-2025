import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BoltzmannMachineAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BoltzmannBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.2)
    total_iterations = BridgeProperty(200)
    has_finished = BridgeProperty(True)
    current_iterations = BridgeProperty(0)
    current_state = BridgeProperty([1, 0, 1])
    current_energy = BridgeProperty(0.0)
    current_temperature = BridgeProperty(2.0)
    weight_matrix = BridgeProperty([
        [0.0, -1.2, 0.6],
        [-1.2, 0.0, -0.9],
        [0.6, -0.9, 0.0],
    ])
    bias_vector = BridgeProperty([0.0, 0.3, -0.2])
    initial_state = BridgeProperty([1, 0, 1])
    initial_temperature = BridgeProperty(2.0)
    cooling_rate = BridgeProperty(0.92)
    min_temperature = BridgeProperty(0.05)
    stability_window = BridgeProperty(5)
    neuron_history = BridgeProperty([])
    equilibrium_state = BridgeProperty([])
    equilibrium_iteration = BridgeProperty(-1)
    final_energy = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self._algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_boltzmann_algorithm(self):
        if self._algorithm and self._algorithm.is_alive():
            return

        self.has_finished = False
        self.current_iterations = 0
        self.equilibrium_state = []
        self.equilibrium_iteration = -1
        self.neuron_history = []
        self.final_energy = 0.0
        self.current_energy = 0.0

        normalized_weights = self._normalize_matrix(self.weight_matrix)
        normalized_bias = self._normalize_vector(self.bias_vector)
        normalized_state = self._normalize_state(self.initial_state)

        self.current_state = normalized_state
        self.current_temperature = float(self.initial_temperature)

        self._algorithm = ObservableBoltzmannAlgorithm(
            observer=self,
            ui_refresh_interval=self.ui_refresh_interval,
            weight_matrix=normalized_weights,
            bias_vector=normalized_bias,
            initial_state=normalized_state,
            total_iterations=int(self.total_iterations),
            initial_temperature=float(self.initial_temperature),
            cooling_rate=float(self.cooling_rate),
            min_temperature=float(self.min_temperature),
            stability_window=int(self.stability_window),
        )
        self._algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_boltzmann_algorithm(self):
        if self._algorithm and self._algorithm.is_alive():
            self._algorithm.stop()
            self._algorithm.join()
        self._algorithm = None
        self.has_finished = True

    @staticmethod
    def _normalize_matrix(matrix):
        return [[float(value) for value in row] for row in matrix]

    @staticmethod
    def _normalize_vector(vector):
        return [float(value) for value in vector]

    @staticmethod
    def _normalize_state(state):
        normalized = [1 if bool(value) else 0 for value in state]
        if len(normalized) != 3:
            raise ValueError("Boltzmann Machine demo expects exactly 3 neurons.")
        return normalized


class ObservableBoltzmannAlgorithm(Observable, BoltzmannMachineAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        self._ui_refresh_interval = ui_refresh_interval
        self._has_initialized = False
        Observable.__init__(self, observer)
        BoltzmannMachineAlgorithm.__init__(self, **kwargs)
        self._has_initialized = True

        # Push the initial snapshot to the UI.
        self.notify('current_state', self.neuron_state)
        self.notify('neuron_history', self._serialize_history())
        self.notify('current_energy', self.current_energy)
        self.notify('current_temperature', self.current_temperature)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if getattr(self, '_has_initialized', False) and name in {'equilibrium_state', 'equilibrium_iteration'}:
            self.notify(name, value)
            if name == 'equilibrium_state':
                self.notify('final_energy', self.current_energy)

    def run(self):
        self.notify('has_finished', False)
        super().run()
        self.notify('neuron_history', self._serialize_history())
        self.notify('current_state', self.neuron_state)
        self.notify('current_energy', self.current_energy)
        self.notify('current_temperature', self.current_temperature)
        self.notify('final_energy', self.current_energy)
        self.notify('has_finished', True)

    def _record_snapshot(self):
        snapshot = super()._record_snapshot()
        if self._has_initialized:
            self.notify('current_iterations', snapshot['iteration'])
            self.notify('current_state', snapshot['state'])
            self.notify('current_energy', snapshot['energy'])
            self.notify('current_temperature', snapshot['temperature'])
            self.notify('neuron_history', self._serialize_history())
            time.sleep(max(self._ui_refresh_interval, 0))
        return snapshot

    def _serialize_history(self):
        serialized = []
        for entry in self.state_history:
            serialized.append({
                'iteration': int(entry['iteration']),
                'state': [int(value) for value in entry['state']],
                'energy': float(entry['energy']),
                'temperature': float(entry['temperature']),
            })
        return serialized
