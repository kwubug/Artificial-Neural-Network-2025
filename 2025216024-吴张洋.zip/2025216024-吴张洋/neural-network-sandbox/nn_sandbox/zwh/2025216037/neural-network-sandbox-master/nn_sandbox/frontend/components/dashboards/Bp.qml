import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'BP'
    ColumnLayout {
        GroupBox {
            title: 'Dataset'
            Layout.fillWidth: true
            ComboBox {
                id: datasetCombobox
                anchors.fill: parent
                model: Object.keys(bpBridge.dataset_dict)
                enabled: bpBridge.has_finished
                onActivated: () => {
                    bpBridge.current_dataset_name = currentText
                    dataChart.updateDataset(bpBridge.dataset_dict[datasetCombobox.currentText])
                }
                Component.onCompleted: () => {
                    bpBridge.current_dataset_name = currentText
                    dataChart.updateDataset(bpBridge.dataset_dict[datasetCombobox.currentText])
                }
            }
        }
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label {
                    text: 'Total Training Epoches'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: totalEpoches
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 10
                    to: 999999
                    onValueChanged: bpBridge.total_epoches = value
                    Component.onCompleted: bpBridge.total_epoches = value
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Initial Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 0.1 * 100
                    onValueChanged: bpBridge.initial_learning_rate = value / 100
                    Component.onCompleted: bpBridge.initial_learning_rate = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Test-Train Ratio'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 0.3 * 100
                    from: 10
                    to: 90
                    onValueChanged: bpBridge.test_ratio = value / 100
                    Component.onCompleted: bpBridge.test_ratio = value / 100
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Activation Function'
                    Layout.alignment: Qt.AlignHCenter
                }
                ComboBox {
                    id: activationFunctionCombobox
                    enabled: bpBridge.has_finished
                    model: ['Unipolar Sigmoid', 'Bipolar Sigmoid']
                    onActivated: bpBridge.activation_function = currentIndex
                    Component.onCompleted: bpBridge.activation_function = currentIndex
                    Layout.fillWidth: true
                }
                Label {
                    text: 'UI Refresh Interval'
                    Layout.alignment: Qt.AlignHCenter
                }
                DoubleSpinBox {
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 0 * 100
                    from: 0 * 100
                    to: 5 * 100
                    onValueChanged: bpBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: bpBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Network Structure (3-Layer Feedforward)'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 3
                Label {
                    text: 'Input Layer'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: 'Hidden Layer'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: 'Output Layer'
                    Layout.alignment: Qt.AlignHCenter
                }
                SpinBox {
                    id: inputLayerSpinBox
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 2
                    from: 1
                    to: 100
                    onValueChanged: updateNetworkShape()
                    Component.onCompleted: updateNetworkShape()
                    Layout.fillWidth: true
                }
                SpinBox {
                    id: hiddenLayerSpinBox
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 5
                    from: 1
                    to: 100
                    onValueChanged: updateNetworkShape()
                    Layout.fillWidth: true
                }
                SpinBox {
                    id: outputLayerSpinBox
                    enabled: bpBridge.has_finished
                    editable: true
                    value: 1
                    from: 1
                    to: 100
                    onValueChanged: updateNetworkShape()
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Weight Initialization'
            Layout.fillWidth: true
            Button {
                text: 'Initialize Weights (Random [-1, 1])'
                enabled: bpBridge.has_finished
                onClicked: bpBridge.initialize_weights()
                anchors.fill: parent
            }
        }
        GroupBox {
            title: 'Information'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                columns: 2
                ExecutionControls {
                    startButton.enabled: bpBridge.has_finished
                    startButton.onClicked: () => {
                        bpBridge.start_bp_algorithm()
                        dataChart.clear()
                        dataChart.updateTrainingDataset(bpBridge.training_dataset)
                        dataChart.updateTestingDataset(bpBridge.testing_dataset)
                        rateChart.reset()
                    }
                    stopButton.enabled: !bpBridge.has_finished
                    stopButton.onClicked: bpBridge.stop_bp_algorithm()
                    progressBar.value: (bpBridge.current_iterations + 1) / (totalEpoches.value * bpBridge.training_dataset.length)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Epoch'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: currentEpoch()
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    function currentEpoch() {
                        const epoch = Math.floor(bpBridge.current_iterations / bpBridge.training_dataset.length) + 1
                        if (isNaN(epoch))
                            return 1
                        return epoch
                    }
                }
                Label {
                    text: 'Current Training Iteration'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_iterations + 1
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: ''
                    visible: false
                    property real lastBestRate: 0
                    property int updateCounter: bpBridge.current_iterations
                    onUpdateCounterChanged: {
                        // 每次迭代都添加数据点，即使best_correct_rate没变
                        rateChart.bestCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.best_correct_rate
                        )
                        rateChart.trainingCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.current_correct_rate
                        )
                        rateChart.testingCorrectRate.append(
                            bpBridge.current_iterations + 1,
                            bpBridge.test_correct_rate
                        )
                    }
                }
                Label {
                    text: 'Current Learning Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_learning_rate.toFixed(8)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Best Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.best_correct_rate.toFixed(8)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Training Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.current_correct_rate.toFixed(8)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
                Label {
                    text: 'Current Testing Correct Rate'
                    Layout.alignment: Qt.AlignHCenter
                }
                Label {
                    text: bpBridge.test_correct_rate.toFixed(8)
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                }
            }
        }
    }
    ColumnLayout {
        DataChart {
            id: dataChart
            width: 700
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
        RateChart {
            id: rateChart
            Layout.fillWidth: true
            Layout.fillHeight: true
        }
    }

    function updateNetworkShape() {
        bpBridge.network_shape = [
            inputLayerSpinBox.value,
            hiddenLayerSpinBox.value,
            outputLayerSpinBox.value
        ]
    }
}
