"""
PyQt5主窗口，实现Hopfield神经网络的可视化界面
"""
import sys
import numpy as np
from typing import List, Tuple
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QSpinBox, QTextEdit, QFileDialog,
                             QMessageBox, QGroupBox, QGridLayout, QSlider)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QPainter, QColor, QPen, QFont
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from hopfield_network import HopfieldNetwork


class NetworkCanvas(QWidget):
    """网络状态可视化画布"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.network = None
        self.state = None
        self.setMinimumSize(400, 400)
        self.setStyleSheet("background-color: white;")
        
    def set_network(self, network: HopfieldNetwork):
        """设置网络对象"""
        self.network = network
        if network is not None:
            self.state = network.state.copy()
        self.update()
        
    def set_state(self, state: np.ndarray):
        """设置当前状态"""
        self.state = state.copy()
        self.update()
        
    def paintEvent(self, event):
        """绘制网络状态"""
        if self.network is None or self.state is None:
            return
            
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        width = self.width()
        height = self.height()
        n = len(self.state)
        
        # 计算网格布局
        cols = int(np.ceil(np.sqrt(n)))
        rows = int(np.ceil(n / cols))
        
        cell_width = width / cols
        cell_height = height / rows
        
        # 绘制每个神经元
        for i, value in enumerate(self.state):
            row = i // cols
            col = i % cols
            
            x = col * cell_width
            y = row * cell_height
            
            # 根据状态选择颜色：1为黑色，-1为白色
            if value == 1:
                color = QColor(0, 0, 0)
            else:
                color = QColor(255, 255, 255)
            
            painter.fillRect(int(x), int(y), int(cell_width), int(cell_height), color)
            
            # 绘制边框
            painter.setPen(QPen(QColor(128, 128, 128), 1))
            painter.drawRect(int(x), int(y), int(cell_width), int(cell_height))


class EnergyPlot(FigureCanvas):
    """能量曲线图"""
    
    def __init__(self, parent=None):
        self.fig = Figure(figsize=(8, 4))
        super().__init__(self.fig)
        self.setParent(parent)
        
        self.ax = self.fig.add_subplot(111)
        self.ax.set_xlabel('迭代次数', fontsize=10)
        self.ax.set_ylabel('能量', fontsize=10)
        self.ax.set_title('网络能量变化曲线', fontsize=12)
        self.ax.grid(True, alpha=0.3)
        
        self.energy_history = []
        
    def update_plot(self, energy_history: List[float]):
        """更新能量曲线"""
        self.energy_history = energy_history
        self.ax.clear()
        self.ax.set_xlabel('迭代次数', fontsize=10)
        self.ax.set_ylabel('能量', fontsize=10)
        self.ax.set_title('网络能量变化曲线', fontsize=12)
        self.ax.grid(True, alpha=0.3)
        
        if energy_history:
            self.ax.plot(energy_history, 'b-', linewidth=2, label='能量')
            self.ax.legend()
        
        self.draw()


class AttractorCanvas(QWidget):
    """吸引子状态画布"""
    
    def __init__(self, state: np.ndarray, parent=None):
        super().__init__(parent)
        self.state = state
        self.setFixedSize(100, 100)
        self.setStyleSheet("background-color: white; border: 1px solid gray;")
        
    def paintEvent(self, event):
        """绘制吸引子状态"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        n = len(self.state)
        cols = int(np.ceil(np.sqrt(n)))
        rows = int(np.ceil(n / cols))
        cell_w = 100 / cols
        cell_h = 100 / rows
        
        for idx, val in enumerate(self.state):
            r = idx // cols
            c = idx % cols
            x = c * cell_w
            y = r * cell_h
            color = QColor(0, 0, 0) if val == 1 else QColor(255, 255, 255)
            painter.fillRect(int(x), int(y), int(cell_w), int(cell_h), color)
            painter.setPen(QPen(QColor(200, 200, 200), 1))
            painter.drawRect(int(x), int(y), int(cell_w), int(cell_h))


class AttractorWidget(QWidget):
    """吸引子展示组件"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.attractors = []
        
    def set_attractors(self, attractors: List[Tuple[np.ndarray, float]]):
        """设置吸引子列表"""
        self.attractors = attractors
        self._update_display()
        
    def _update_display(self):
        """更新显示"""
        # 清除旧组件
        for i in reversed(range(self.layout.count())):
            self.layout.itemAt(i).widget().setParent(None)
        
        if not self.attractors:
            label = QLabel("暂无吸引子")
            self.layout.addWidget(label)
            return
        
        # 显示吸引子信息
        for i, (state, energy) in enumerate(self.attractors):
            group = QGroupBox(f"吸引子 {i+1} (能量: {energy:.2f})")
            layout = QHBoxLayout()
            
            # 创建小画布显示状态
            canvas = AttractorCanvas(state)
            layout.addWidget(canvas)
            
            # 状态文本
            state_str = " ".join(["●" if s == 1 else "○" for s in state[:20]])
            if len(state) > 20:
                state_str += "..."
            label = QLabel(f"状态: {state_str}")
            layout.addWidget(label)
            
            group.setLayout(layout)
            self.layout.addWidget(group)


class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.network = None
        self.training_patterns = []
        self.init_ui()
        
    def init_ui(self):
        """初始化界面"""
        self.setWindowTitle("离散型Hopfield神经网络可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel, 1)
        
        # 右侧可视化区域
        viz_layout = QVBoxLayout()
        
        # 网络状态显示
        state_group = QGroupBox("网络状态")
        state_layout = QVBoxLayout()
        self.network_canvas = NetworkCanvas()
        state_layout.addWidget(self.network_canvas)
        state_group.setLayout(state_layout)
        viz_layout.addWidget(state_group, 2)
        
        # 能量曲线
        energy_group = QGroupBox("能量曲线")
        energy_layout = QVBoxLayout()
        self.energy_plot = EnergyPlot()
        energy_layout.addWidget(self.energy_plot)
        energy_group.setLayout(energy_layout)
        viz_layout.addWidget(energy_group, 2)
        
        # 吸引子展示
        attractor_group = QGroupBox("吸引子")
        attractor_layout = QVBoxLayout()
        self.attractor_widget = AttractorWidget()
        attractor_layout.addWidget(self.attractor_widget)
        attractor_group.setLayout(attractor_layout)
        viz_layout.addWidget(attractor_group, 2)
        
        main_layout.addLayout(viz_layout, 3)
        
    def create_control_panel(self):
        """创建控制面板"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        
        # 网络参数设置
        param_group = QGroupBox("网络参数")
        param_layout = QGridLayout()
        
        param_layout.addWidget(QLabel("神经元数量:"), 0, 0)
        self.n_neurons_spin = QSpinBox()
        self.n_neurons_spin.setRange(4, 100)
        self.n_neurons_spin.setValue(16)
        param_layout.addWidget(self.n_neurons_spin, 0, 1)
        
        param_layout.addWidget(QLabel("最大迭代次数:"), 1, 0)
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(10, 10000)
        self.max_iter_spin.setValue(1000)
        param_layout.addWidget(self.max_iter_spin, 1, 1)
        
        param_group.setLayout(param_layout)
        layout.addWidget(param_group)
        
        # 训练模式
        train_group = QGroupBox("训练模式")
        train_layout = QVBoxLayout()
        
        self.pattern_text = QTextEdit()
        self.pattern_text.setPlaceholderText("输入训练模式，每行一个模式\n例如：\n1 1 -1 -1\n-1 -1 1 1")
        self.pattern_text.setMaximumHeight(100)
        train_layout.addWidget(self.pattern_text)
        
        btn_load = QPushButton("加载训练模式")
        btn_load.clicked.connect(self.load_patterns)
        train_layout.addWidget(btn_load)
        
        btn_train = QPushButton("训练网络")
        btn_train.clicked.connect(self.train_network)
        train_layout.addWidget(btn_train)
        
        train_group.setLayout(train_layout)
        layout.addWidget(train_group)
        
        # 运行控制
        run_group = QGroupBox("运行控制")
        run_layout = QVBoxLayout()
        
        btn_random_init = QPushButton("随机初始化状态")
        btn_random_init.clicked.connect(self.random_init)
        run_layout.addWidget(btn_random_init)
        
        btn_update = QPushButton("异步更新")
        btn_update.clicked.connect(self.async_update)
        run_layout.addWidget(btn_update)
        
        btn_find_attractors = QPushButton("查找所有吸引子")
        btn_find_attractors.clicked.connect(self.find_all_attractors)
        run_layout.addWidget(btn_find_attractors)
        
        run_group.setLayout(run_layout)
        layout.addWidget(run_group)
        
        # 信息显示
        info_group = QGroupBox("信息")
        info_layout = QVBoxLayout()
        self.info_text = QTextEdit()
        self.info_text.setReadOnly(True)
        self.info_text.setMaximumHeight(150)
        info_layout.addWidget(self.info_text)
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        layout.addStretch()
        return panel
    
    def log_info(self, message: str):
        """记录信息"""
        self.info_text.append(message)
        
    def load_patterns(self):
        """加载训练模式"""
        text = self.pattern_text.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "警告", "请输入训练模式")
            return
        
        patterns = []
        lines = text.split('\n')
        n_neurons = self.n_neurons_spin.value()
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                values = [int(x) for x in line.split()]
                if len(values) != n_neurons:
                    QMessageBox.warning(self, "错误", 
                                      f"模式长度必须为 {n_neurons}，当前为 {len(values)}")
                    return
                # 转换为-1和1
                pattern = np.array([1 if v > 0 else -1 for v in values])
                patterns.append(pattern)
            except ValueError:
                QMessageBox.warning(self, "错误", f"无效的模式: {line}")
                return
        
        self.training_patterns = patterns
        self.log_info(f"已加载 {len(patterns)} 个训练模式")
        
    def train_network(self):
        """训练网络"""
        if not self.training_patterns:
            QMessageBox.warning(self, "警告", "请先加载训练模式")
            return
        
        n_neurons = self.n_neurons_spin.value()
        self.network = HopfieldNetwork(n_neurons)
        self.network.train(self.training_patterns)
        
        # 初始化状态为第一个训练模式
        self.network.state = self.training_patterns[0].copy()
        self.network_canvas.set_network(self.network)
        
        self.log_info(f"网络训练完成，神经元数量: {n_neurons}")
        self.log_info(f"训练模式数量: {len(self.training_patterns)}")
        
    def random_init(self):
        """随机初始化状态"""
        if self.network is None:
            QMessageBox.warning(self, "警告", "请先训练网络")
            return
        
        n = self.network.n_neurons
        self.network.state = np.random.choice([-1, 1], size=n)
        self.network_canvas.set_state(self.network.state)
        energy = self.network.energy()
        self.log_info(f"随机初始化完成，当前能量: {energy:.2f}")
        
    def async_update(self):
        """异步更新"""
        if self.network is None:
            QMessageBox.warning(self, "警告", "请先训练网络")
            return
        
        max_iter = self.max_iter_spin.value()
        final_state, energy_history, iterations = self.network.async_update(max_iter)
        
        self.network_canvas.set_state(final_state)
        self.energy_plot.update_plot(energy_history)
        
        final_energy = energy_history[-1] if energy_history else 0
        self.log_info(f"异步更新完成，迭代次数: {iterations}")
        self.log_info(f"最终能量: {final_energy:.2f}")
        
    def find_all_attractors(self):
        """查找所有吸引子"""
        if self.network is None:
            QMessageBox.warning(self, "警告", "请先训练网络")
            return
        
        self.log_info("正在查找吸引子...")
        attractors = self.network.get_all_attractors(max_patterns=500)
        self.attractor_widget.set_attractors(attractors)
        
        self.log_info(f"找到 {len(attractors)} 个吸引子")
        for i, (state, energy) in enumerate(attractors):
            self.log_info(f"吸引子 {i+1}: 能量 = {energy:.2f}")


def main():
    """主函数"""
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    from PyQt5.QtWidgets import QApplication
    main()

