#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BP算法综合测试脚本
测试三层前馈神经网络的BP学习算法在不同数据集上的表现
"""

import numpy as np
import matplotlib.pyplot as plt
from nn_sandbox.backend.algorithms import BPAlgorithm
from nn_sandbox.backend.utils import read_data

def test_xor_problem():
    """测试XOR问题"""
    print("=== 测试XOR问题 ===")
    
    data_dict = read_data()
    xor_data = np.array(data_dict['xor'])
    print(f"XOR数据: {xor_data}")
    
    # 测试单极性Sigmoid
    print("\n--- 单极性Sigmoid ---")
    bp_unipolar = BPAlgorithm(
        dataset=xor_data,
        total_epoches=1000,
        initial_learning_rate=0.5,
        input_nodes=2,
        hidden_nodes=4,
        output_nodes=1,
        sigmoid_type='unipolar',
        test_ratio=0.25  # 使用25%作为测试集
    )
    
    bp_unipolar.run()
    print(f"训练正确率: {bp_unipolar.best_correct_rate:.4f}")
    print(f"测试正确率: {bp_unipolar.test():.4f}")
    print(f"训练轮次: {len(bp_unipolar.training_errors)}")
    
    # 测试预测
    print("预测结果:")
    for sample in xor_data:
        prediction = bp_unipolar.predict(sample[:-1])
        print(f"输入: {sample[:-1]}, 期望: {sample[-1]}, 预测: {prediction:.4f}")
    
    # 测试双极性Sigmoid
    print("\n--- 双极性Sigmoid ---")
    bp_bipolar = BPAlgorithm(
        dataset=xor_data,
        total_epoches=1000,
        initial_learning_rate=0.5,
        input_nodes=2,
        hidden_nodes=4,
        output_nodes=1,
        sigmoid_type='bipolar',
        test_ratio=0.25
    )
    
    bp_bipolar.run()
    print(f"训练正确率: {bp_bipolar.best_correct_rate:.4f}")
    print(f"测试正确率: {bp_bipolar.test():.4f}")
    print(f"训练轮次: {len(bp_bipolar.training_errors)}")
    
    # 绘制训练误差对比
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(bp_unipolar.training_errors, label='单极性Sigmoid')
    plt.plot(bp_bipolar.training_errors, label='双极性Sigmoid')
    plt.title('XOR问题训练误差对比')
    plt.xlabel('训练轮次')
    plt.ylabel('平均误差')
    plt.legend()
    plt.grid(True)
    
    plt.subplot(1, 2, 2)
    plt.plot(bp_unipolar.training_errors[-100:], label='单极性Sigmoid (最后100轮)')
    plt.plot(bp_bipolar.training_errors[-100:], label='双极性Sigmoid (最后100轮)')
    plt.title('XOR问题训练误差对比 (最后100轮)')
    plt.xlabel('训练轮次')
    plt.ylabel('平均误差')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.savefig('xor_training_comparison.png', dpi=300, bbox_inches='tight')
    print("XOR训练对比图已保存为 xor_training_comparison.png")

def test_circle_problem():
    """测试圆形分类问题"""
    print("\n=== 测试圆形分类问题 ===")
    
    data_dict = read_data()
    circle_data = np.array(data_dict['2Circle1'])
    print(f"2Circle1数据集大小: {circle_data.shape}")
    
    # 显示数据分布
    class1_data = circle_data[circle_data[:, -1] == 1]
    class2_data = circle_data[circle_data[:, -1] == 2]
    print(f"类别1样本数: {len(class1_data)}")
    print(f"类别2样本数: {len(class2_data)}")
    
    bp_circle = BPAlgorithm(
        dataset=circle_data,
        total_epoches=500,
        initial_learning_rate=0.1,
        input_nodes=2,
        hidden_nodes=8,
        output_nodes=1,
        sigmoid_type='unipolar',
        test_ratio=0.3
    )
    
    bp_circle.run()
    print(f"训练正确率: {bp_circle.best_correct_rate:.4f}")
    print(f"测试正确率: {bp_circle.test():.4f}")
    print(f"训练轮次: {len(bp_circle.training_errors)}")
    
    # 绘制训练误差曲线
    plt.figure(figsize=(10, 6))
    plt.plot(bp_circle.training_errors)
    plt.title('圆形分类问题训练误差曲线')
    plt.xlabel('训练轮次')
    plt.ylabel('平均误差')
    plt.grid(True)
    plt.savefig('circle_training_error.png', dpi=300, bbox_inches='tight')
    print("圆形分类训练误差图已保存为 circle_training_error.png")

def test_learning_rate_sensitivity():
    """测试学习率敏感性"""
    print("\n=== 测试学习率敏感性 ===")
    
    data_dict = read_data()
    xor_data = np.array(data_dict['xor'])
    
    learning_rates = [0.1, 0.3, 0.5, 0.8, 1.0]
    results = []
    
    for lr in learning_rates:
        print(f"\n测试学习率: {lr}")
        bp = BPAlgorithm(
            dataset=xor_data,
            total_epoches=500,
            initial_learning_rate=lr,
            input_nodes=2,
            hidden_nodes=4,
            output_nodes=1,
            sigmoid_type='unipolar',
            test_ratio=0.25
        )
        
        bp.run()
        test_rate = bp.test()
        training_epochs = len(bp.training_errors)
        final_error = bp.training_errors[-1] if bp.training_errors else 0
        
        results.append({
            'learning_rate': lr,
            'test_accuracy': test_rate,
            'training_epochs': training_epochs,
            'final_error': final_error,
            'training_errors': bp.training_errors.copy()
        })
        
        print(f"学习率 {lr}: 测试正确率 {test_rate:.4f}, 训练轮次 {training_epochs}, 最终误差 {final_error:.6f}")
    
    # 绘制学习率对比图
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
    
    lrs = [r['learning_rate'] for r in results]
    test_accs = [r['test_accuracy'] for r in results]
    epochs = [r['training_epochs'] for r in results]
    final_errors = [r['final_error'] for r in results]
    
    ax1.plot(lrs, test_accs, 'bo-')
    ax1.set_xlabel('学习率')
    ax1.set_ylabel('测试正确率')
    ax1.set_title('学习率对测试正确率的影响')
    ax1.grid(True)
    
    ax2.plot(lrs, epochs, 'ro-')
    ax2.set_xlabel('学习率')
    ax2.set_ylabel('训练轮次')
    ax2.set_title('学习率对收敛速度的影响')
    ax2.grid(True)
    
    ax3.plot(lrs, final_errors, 'go-')
    ax3.set_xlabel('学习率')
    ax3.set_ylabel('最终误差')
    ax3.set_title('学习率对最终误差的影响')
    ax3.grid(True)
    
    # 绘制训练曲线对比
    for result in results:
        ax4.plot(result['training_errors'], label=f"LR={result['learning_rate']}")
    ax4.set_xlabel('训练轮次')
    ax4.set_ylabel('平均误差')
    ax4.set_title('不同学习率的训练曲线对比')
    ax4.legend()
    ax4.grid(True)
    
    plt.tight_layout()
    plt.savefig('learning_rate_analysis.png', dpi=300, bbox_inches='tight')
    print("学习率分析图已保存为 learning_rate_analysis.png")

def test_network_architecture():
    """测试不同网络结构"""
    print("\n=== 测试不同网络结构 ===")
    
    data_dict = read_data()
    xor_data = np.array(data_dict['xor'])
    
    architectures = [
        (2, 2, 1),  # 最小网络
        (2, 4, 1),  # 标准网络
        (2, 8, 1),  # 较大网络
        (2, 16, 1), # 大网络
    ]
    
    results = []
    
    for input_nodes, hidden_nodes, output_nodes in architectures:
        print(f"\n测试网络结构: {input_nodes}-{hidden_nodes}-{output_nodes}")
        bp = BPAlgorithm(
            dataset=xor_data,
            total_epoches=500,
            initial_learning_rate=0.5,
            input_nodes=input_nodes,
            hidden_nodes=hidden_nodes,
            output_nodes=output_nodes,
            sigmoid_type='unipolar',
            test_ratio=0.25
        )
        
        bp.run()
        test_rate = bp.test()
        training_epochs = len(bp.training_errors)
        
        results.append({
            'architecture': f"{input_nodes}-{hidden_nodes}-{output_nodes}",
            'hidden_nodes': hidden_nodes,
            'test_accuracy': test_rate,
            'training_epochs': training_epochs,
            'training_errors': bp.training_errors.copy()
        })
        
        print(f"网络 {input_nodes}-{hidden_nodes}-{output_nodes}: 测试正确率 {test_rate:.4f}, 训练轮次 {training_epochs}")
    
    # 绘制网络结构对比图
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    hidden_nodes = [r['hidden_nodes'] for r in results]
    test_accs = [r['test_accuracy'] for r in results]
    epochs = [r['training_epochs'] for r in results]
    
    ax1.plot(hidden_nodes, test_accs, 'bo-')
    ax1.set_xlabel('隐藏层节点数')
    ax1.set_ylabel('测试正确率')
    ax1.set_title('网络大小对测试正确率的影响')
    ax1.grid(True)
    
    ax2.plot(hidden_nodes, epochs, 'ro-')
    ax2.set_xlabel('隐藏层节点数')
    ax2.set_ylabel('训练轮次')
    ax2.set_title('网络大小对收敛速度的影响')
    ax2.grid(True)
    
    plt.tight_layout()
    plt.savefig('network_architecture_analysis.png', dpi=300, bbox_inches='tight')
    print("网络结构分析图已保存为 network_architecture_analysis.png")

def main():
    """主函数"""
    print("开始BP算法综合测试...")
    
    try:
        # 设置matplotlib参数
        plt.rcParams['font.size'] = 10
        plt.rcParams['figure.figsize'] = (10, 6)
        
        # 运行各项测试
        test_xor_problem()
        test_circle_problem()
        test_learning_rate_sensitivity()
        test_network_architecture()
        
        print("\n=== 测试总结 ===")
        print("1. XOR问题测试完成 - 验证了单极性和双极性Sigmoid函数")
        print("2. 圆形分类问题测试完成 - 验证了复杂分类任务")
        print("3. 学习率敏感性测试完成 - 分析了不同学习率的影响")
        print("4. 网络结构测试完成 - 分析了不同网络大小的影响")
        print("\n所有测试完成! 生成的图片文件:")
        print("- xor_training_comparison.png: XOR问题训练对比")
        print("- circle_training_error.png: 圆形分类训练误差")
        print("- learning_rate_analysis.png: 学习率分析")
        print("- network_architecture_analysis.png: 网络结构分析")
        
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
