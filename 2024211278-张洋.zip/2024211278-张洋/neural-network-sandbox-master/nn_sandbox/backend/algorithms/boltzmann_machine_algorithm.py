import numpy as np
import time
from .base_algorithm import TraningAlgorithm


class BoltzmannMachineAlgorithm(TraningAlgorithm):
    """
    三神经元玻尔兹曼机算法，使用模拟退火进行训练
    """
    def __init__(self, T0=1.0, alpha=0.995, max_iter=1000, 
                 update_freq=10, ui_refresh_interval=0.05,
                 initial_state=None):
        super().__init__(dataset=[], total_epoches=1)
        
        # 网络参数
        self.W = np.array([
            [0, 0.55, 0.45],
            [0.55, 0, 0.2],
            [0.45, 0.2, 0]
        ])
        self.B = np.array([-0.65, -0.3, -0.4])
        self.NUM_NEURONS = 3
        self.NEURON_LABELS = ['V1', 'V2', 'V3']
        self.TARGET_STATE = np.array([1, 1, 1])
        
        # 训练参数
        self.T0 = float(T0)
        self.alpha = float(alpha)
        self.max_iter = int(max_iter)
        self.update_freq = int(update_freq)
        self.ui_refresh_interval = float(ui_refresh_interval)
        
        # 初始状态
        if initial_state is None:
            self.initial_state = np.array([0, 0, 0])
        else:
            self.initial_state = np.array(initial_state)
        
        # 运行时状态
        self.current_state = None
        self.current_iter = 0
        self.current_energy = 0.0
        self.current_temperature = self.T0
        self.has_finished = True
        
        # 历史记录
        self.energy_history = []
        self.temperature_history = []
        self.state_history = []
        self.detailed_history = []  # 详细历史记录（用于表格显示）
        
    def calculate_net_input(self, V, i):
        """计算第 i 个神经元的净输入 Net_i"""
        net_input = np.dot(self.W[i, :], V) + self.B[i]
        return net_input
    
    def activation_probability(self, net_input, T):
        """使用 Logistic Sigmoid 函数计算 P(V_i = 1)"""
        if T < 1e-6:
            return 1.0 if net_input > 0 else 0.0
        return 1.0 / (1.0 + np.exp(-net_input / T))
    
    def calculate_energy(self, V):
        """计算系统的全局能量 E(V)"""
        energy = -0.5 * np.dot(V, np.dot(self.W, V)) - np.dot(self.B, V)
        return energy
    
    def run(self):
        self.has_finished = False
        
        # 初始化状态
        self.current_state = self.initial_state.copy()
        self.current_temperature = self.T0
        self.current_iter = 0
        
        # 清空历史
        self.energy_history = []
        self.temperature_history = []
        self.state_history = []
        self.detailed_history = []
        
        # 记录初始状态
        initial_energy = self.calculate_energy(self.current_state)
        self.energy_history.append(float(initial_energy))
        self.temperature_history.append(float(self.current_temperature))
        self.state_history.append(self.current_state.copy())
        
        # 记录初始详细信息
        initial_record = {
            'step': 0,
            'v1': int(self.current_state[0]),
            'v2': int(self.current_state[1]),
            'v3': int(self.current_state[2]),
            'energy': float(initial_energy),
            'temperature': float(self.current_temperature),
            'updated_neuron': '-',
            'prob_activation': 0.0,
            'net_input': 0.0,
            'state_change': 'None'
        }
        self.detailed_history.append(initial_record)
        
        # 初始通知
        if hasattr(self, 'notify'):
            self.notify('current_iter', 0)
            self.notify('current_energy', float(initial_energy))
            self.notify('current_temperature', float(self.current_temperature))
            self.notify('current_state', self.current_state.tolist())
        
        # 用于检测稳定在目标状态
        target_state_count = 0
        
        # 主循环
        for step in range(1, self.max_iter + 1):
            if self._should_stop:
                break
            
            # 模拟退火：温度降低
            self.current_temperature = self.T0 * (self.alpha ** step)
            self.current_iter = step
            
            # 随机选择一个神经元进行异步更新
            i = np.random.randint(self.NUM_NEURONS)
            old_Vi = self.current_state[i]
            neuron_label = self.NEURON_LABELS[i]
            
            # 计算净输入和激活概率
            net_input = self.calculate_net_input(self.current_state, i)
            prob_activation = self.activation_probability(net_input, self.current_temperature)
            
            # 随机更新
            r = np.random.rand()
            new_Vi = 1 if r < prob_activation else 0
            self.current_state[i] = new_Vi
            
            # 计算能量
            self.current_energy = self.calculate_energy(self.current_state)
            
            # 记录状态变化
            if old_Vi != new_Vi:
                state_change = f"{old_Vi}->{new_Vi}"
            else:
                state_change = "保持"
            
            # 记录历史
            self.energy_history.append(float(self.current_energy))
            self.temperature_history.append(float(self.current_temperature))
            self.state_history.append(self.current_state.copy())
            
            # 记录详细信息
            detail_record = {
                'step': step,
                'v1': int(self.current_state[0]),
                'v2': int(self.current_state[1]),
                'v3': int(self.current_state[2]),
                'energy': float(self.current_energy),
                'temperature': float(self.current_temperature),
                'updated_neuron': neuron_label,
                'prob_activation': float(prob_activation),
                'net_input': float(net_input),
                'state_change': state_change
            }
            self.detailed_history.append(detail_record)
            
            # 定期通知更新
            if step % self.update_freq == 0 or step == self.max_iter:
                if hasattr(self, 'notify'):
                    self.notify('current_iter', self.current_iter)
                    self.notify('current_energy', self.current_energy)
                    self.notify('current_temperature', self.current_temperature)
                    self.notify('current_state', self.current_state.tolist())
                    self.notify('energy_history', self.energy_history[-100:])  # 只发送最近100个点
                    self.notify('temperature_history', self.temperature_history[-100:])
                
                if self.ui_refresh_interval > 0:
                    time.sleep(self.ui_refresh_interval)
            
            # 检查是否稳定在目标状态
            if np.array_equal(self.current_state, self.TARGET_STATE):
                target_state_count += 1
                if target_state_count >= 5:
                    break
            else:
                target_state_count = 0
        
        # 最终通知
        if hasattr(self, 'notify'):
            self.notify('current_iter', self.current_iter)
            self.notify('current_energy', self.current_energy)
            self.notify('current_temperature', self.current_temperature)
            self.notify('current_state', self.current_state.tolist())
            self.notify('energy_history', self.energy_history)
            self.notify('temperature_history', self.temperature_history)
            self.notify('detailed_history', self.detailed_history[-50:])  # 发送最后50步的详细数据
            self.notify('has_finished', True)
        
        self.has_finished = True

