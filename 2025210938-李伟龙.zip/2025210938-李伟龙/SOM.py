import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

# --------------------------
# 解决中文显示问题（适配Windows系统）
# --------------------------
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]  # 仅保留Windows默认中文字体
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

# --------------------------
# 1. 定义输入模式（根据题目中的5个输入模式调整）
# --------------------------
inputs = np.array([
    [0, 0],  # 输入模式1
    [1, 0],  # 输入模式2
    [0, 1],  # 输入模式3
    [1, 1],  # 输入模式4
    [0.5, 0.5]  # 输入模式5
])
n_inputs = inputs.shape[0]
input_dim = inputs.shape[1]

# --------------------------
# 2. SOM网络参数设置
# --------------------------
som_size = (5, 5)
total_steps = 10000
save_interval = 200
np.random.seed(42)
weights = np.random.rand(*som_size, input_dim)
saved_weights = []

# --------------------------
# 3. SOM训练过程
# --------------------------
for step in range(total_steps):
    x = inputs[np.random.randint(n_inputs)]
    distances = np.linalg.norm(weights - x, axis=2)
    bmu_idx = np.unravel_index(np.argmin(distances), som_size)

    # 学习率调度
    if step <= 1000:
        eta = 0.5 - (0.5 - 0.04) * (step / 1000)
    else:
        eta = 0.04 - 0.04 * ((step - 1000) / (total_steps - 1000))

    # 邻域半径调度
    if step <= 1000:
        sigma = 2 - 2 * (step / 1000)
    else:
        sigma = 0

    # 更新权重
    for i in range(som_size[0]):
        for j in range(som_size[1]):
            grid_dist = np.sqrt((i - bmu_idx[0]) ** 2 + (j - bmu_idx[1]) ** 2)
            if sigma == 0:
                h = 1 if grid_dist == 0 else 0
            else:
                h = np.exp(-(grid_dist ** 2) / (2 * sigma ** 2))
            weights[i, j] += eta * h * (x - weights[i, j])

    if (step + 1) % save_interval == 0:
        saved_weights.append(weights.copy())

# --------------------------
# 4. 训练结果可视化
# --------------------------
# 4.1 输入模式映射图
plt.figure(figsize=(8, 8))
for i in range(som_size[0] + 1):
    plt.plot([i - 0.5, i - 0.5], [-0.5, som_size[1] - 0.5], 'k-', linewidth=0.5)
for j in range(som_size[1] + 1):
    plt.plot([-0.5, som_size[0] - 0.5], [j - 0.5, j - 0.5], 'k-', linewidth=0.5)

labels = [f'输入模式 {i + 1}' for i in range(n_inputs)]
colors = ['r', 'g', 'b', 'y', 'm']
mapping = []
for x in inputs:
    distances = np.linalg.norm(weights - x, axis=2)
    bmu = np.unravel_index(np.argmin(distances), som_size)
    mapping.append(bmu)

for idx, (i, j) in enumerate(mapping):
    plt.scatter(i, j, color=colors[idx], s=150, label=labels[idx], edgecolors='k')
    plt.text(i, j, str(idx + 1), color='white', ha='center', va='center', fontweight='bold')

plt.xlim(-0.5, som_size[0] - 0.5)
plt.ylim(-0.5, som_size[1] - 0.5)
plt.xticks(range(som_size[0]), [f'({i},*)' for i in range(som_size[0])])
plt.yticks(range(som_size[1]), [f'(*,{j})' for j in range(som_size[1])])
plt.title('输入模式在SOM输出平面的映射')
plt.legend(loc='upper right')
plt.grid(False)
plt.tight_layout()
plt.show()

# 4.2 权值变化过程
n_plots = 5
plt.figure(figsize=(15, 3))
gs = GridSpec(1, n_plots)
for i in range(n_plots):
    step_idx = i * (len(saved_weights) // n_plots)
    step = (step_idx + 1) * save_interval
    w = saved_weights[step_idx]

    ax = plt.subplot(gs[i])
    ax.scatter(w[:, :, 0].flatten(), w[:, :, 1].flatten(),
               c='blue', s=80, alpha=0.7, label='神经元权值')
    ax.scatter(inputs[:, 0], inputs[:, 1],
               c='red', marker='x', s=100, label='输入模式')
    ax.set_title(f'训练步数: {step}')
    ax.set_xlim(-0.1, 1.1)
    ax.set_ylim(-0.1, 1.1)
    ax.legend(fontsize=8)

plt.suptitle('训练过程中神经元权值分布变化')
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()