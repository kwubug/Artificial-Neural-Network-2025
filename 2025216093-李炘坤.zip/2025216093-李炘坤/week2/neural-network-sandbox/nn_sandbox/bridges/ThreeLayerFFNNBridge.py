from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot, QTimer
from nn_sandbox.backend.algorithms.three_layer_ffnn import ThreeLayerFFNN
import numpy as np

class ThreeLayerFFNNBridge(QObject):
    # 定义信号，用于与前端交互
    training_done = pyqtSignal(list)  # 训练完成信号，传递训练结果
    training_progress = pyqtSignal(float, float)  # 训练进度信号，传递当前轮数和损失值

    def __init__(self):
        super().__init__()
        self.model = None
        self.dataset_dict = {}
        self.training_data = None  # 存储训练数据用于可视化

    @pyqtSlot(int, int, int, float)
    def create_model(self, input_size, hidden_size, output_size, learning_rate=0.1):
        # 创建三层前馈神经网络模型
        self.model = ThreeLayerFFNN(input_size, hidden_size, output_size, learning_rate)
        print(f"Model created with input_size={input_size}, hidden_size={hidden_size}, output_size={output_size}, learning_rate={learning_rate}")

    @pyqtSlot(int)
    def train_model(self, epochs=1000):
        # 训练模型
        print(f"Starting training with {epochs} epochs...")
        if self.model and self.dataset_dict:
            # 获取数据集中的第一个键
            dataset_keys = list(self.dataset_dict.keys())
            print(f"Available datasets: {dataset_keys}")
            if dataset_keys:
                dataset_key = dataset_keys[0]  # 使用第一个数据集
                data = self.dataset_dict[dataset_key]
                print(f"Using dataset: {dataset_key}")
                # 确保数据格式正确
                if len(data) > 0:
                    # 将数据转换为numpy数组
                    all_data = np.array(data)
                    print(f"Dataset shape: {all_data.shape}")
                    # 分离输入和输出
                    # 假设最后一列是标签，其余列是特征
                    if all_data.shape[1] >= 2:
                        X = all_data[:, :-1]  # 所有列除了最后一列作为输入
                        y = all_data[:, -1:]  # 最后一列作为输出
                        
                        # 保存训练数据用于可视化
                        self.training_data = (X.copy(), y.copy(), dataset_key)
                        
                        # 确保y的形状正确（二维数组）
                        if y.ndim == 1:
                            y = y.reshape(-1, 1)
                            
                        print(f"X shape: {X.shape}, y shape: {y.shape}")
                        print("Starting model training...")
                        try:
                            self.model.train(X, y, epochs, self.training_progress)  # 训练
                            print("Model training completed!")
                        except Exception as e:
                            print(f"Error during model training: {e}")
                            import traceback
                            traceback.print_exc()
                            return
                            
                        print("About to emit training_done signal...")
                        # 使用QTimer.singleShot确保信号在事件循环中异步发射
                        # 这样可以避免因训练过快而导致的信号丢失问题
                        QTimer.singleShot(0, self._emit_training_done_signal)
                    else:
                        print("Invalid dataset format: not enough columns")
                else:
                    print("Dataset is empty")
            else:
                print("No datasets available")
        else:
            print("Model or dataset not available!")

    def _emit_training_done_signal(self):
        """异步发射训练完成信号"""
        try:
            self.training_done.emit(["Training complete!"])  # 发出信号通知前端
            print("Training done signal emitted successfully")
        except Exception as e:
            print(f"Error emitting training_done signal: {e}")
            import traceback
            traceback.print_exc()

    @pyqtSlot(list)
    def predict(self, X_list):
        # 进行预测
        if self.model:
            X = np.array(X_list)
            # 确保输入是二维数组
            if X.ndim == 1:
                X = X.reshape(1, -1)
            return self.model.forward(X).tolist()  # 返回预测结果
        return None
        
    @pyqtSlot(result=list)
    def get_training_data(self):
        """获取训练数据用于可视化"""
        if self.training_data is not None:
            X, y, dataset_name = self.training_data
            # 合并X和y以便于可视化
            data_with_labels = np.hstack([X, y])
            return data_with_labels.tolist()
        return []