import numpy as np
import matplotlib.pyplot as plt

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class BoltzmannMachine:
    def __init__(self, n_neurons=3):
        """
        初始化玻尔兹曼机
        :param n_neurons: 神经元数量
        """
        self.n_neurons = n_neurons
        # 初始化权重矩阵（对称且对角线为0）
        self.weights = np.random.normal(0, 0.5, (n_neurons, n_neurons))
        self.weights = (self.weights + self.weights.T) / 2  # 确保对称
        np.fill_diagonal(self.weights, 0)  # 对角线为0

        # 初始化阈值
        self.thresholds = np.random.normal(0, 0.1, n_neurons)

        # 网络状态
        self.state = np.random.choice([-1, 1], n_neurons)

        # 记录历史状态
        self.state_history = []
        self.energy_history = []
        self.temperature_history = []

    def energy(self, state=None):
        """
        计算网络能量
        :param state: 网络状态
        :return: 能量值
        """
        if state is None:
            state = self.state

        # 能量函数: E = -1/2 * ΣΣ w_ij * s_i * s_j - Σ θ_i * s_i
        energy = -0.5 * np.dot(np.dot(state.T, self.weights), state) - np.dot(self.thresholds, state)
        return energy

    def update_neuron(self, neuron_idx, temperature=1.0):
        """
        更新单个神经元状态
        :param neuron_idx: 神经元索引
        :param temperature: 温度参数
        """
        # 计算局部场
        local_field = np.dot(self.weights[neuron_idx, :], self.state) + self.thresholds[neuron_idx]

        # 计算概率
        prob = 1 / (1 + np.exp(-2 * local_field / temperature))

        # 根据概率更新状态
        self.state[neuron_idx] = 1 if np.random.random() < prob else -1

    def update_random_neuron(self, temperature=1.0):
        """
        随机选择一个神经元进行更新
        :param temperature: 温度参数
        """
        neuron_idx = np.random.randint(0, self.n_neurons)
        self.update_neuron(neuron_idx, temperature)

        # 记录状态
        self.state_history.append(self.state.copy())
        self.energy_history.append(self.energy())
        self.temperature_history.append(temperature)

    def simulate_annealing(self, initial_temperature=5.0, final_temperature=0.1,
                           cooling_rate=0.99, steps_per_temp=100, max_steps=10000):
        """
        模拟退火过程
        :param initial_temperature: 初始温度
        :param final_temperature: 最终温度
        :param cooling_rate: 降温速率
        :param steps_per_temp: 每个温度下的步数
        :param max_steps: 最大步数
        """
        temperature = initial_temperature
        step = 0

        # 清空历史记录
        self.state_history = []
        self.energy_history = []
        self.temperature_history = []

        # 记录初始状态
        self.state_history.append(self.state.copy())
        self.energy_history.append(self.energy())
        self.temperature_history.append(temperature)

        while temperature > final_temperature and step < max_steps:
            # 在当前温度下运行几步
            for _ in range(steps_per_temp):
                self.update_random_neuron(temperature)
                step += 1
                if step >= max_steps:
                    break

            # 降温
            temperature *= cooling_rate

        return step

    def get_state_frequencies(self):
        """
        计算各个状态的出现频率
        """
        # 将状态转换为字符串以便计数
        state_strings = [''.join(['1' if s == 1 else '0' for s in state]) for state in self.state_history]

        # 计算频率
        unique_states, counts = np.unique(state_strings, return_counts=True)
        frequencies = counts / len(state_strings)

        # 转换回数值状态
        states = []
        for state_str in unique_states:
            state = np.array([1 if c == '1' else -1 for c in state_str])
            states.append(state)

        return states, frequencies

    def visualize_weights(self):
        """
        可视化权重矩阵
        """
        fig, ax = plt.subplots(figsize=(8, 6))
        im = ax.imshow(self.weights, cmap='RdBu_r', vmin=-np.max(np.abs(self.weights)),
                       vmax=np.max(np.abs(self.weights)))
        ax.set_title('权重矩阵')
        ax.set_xlabel('神经元')
        ax.set_ylabel('神经元')

        # 设置刻度
        ax.set_xticks(range(self.n_neurons))
        ax.set_yticks(range(self.n_neurons))
        ax.set_xticklabels([f'N{i}' for i in range(self.n_neurons)])
        ax.set_yticklabels([f'N{i}' for i in range(self.n_neurons)])

        # 添加数值标注
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                ax.text(j, i, f'{self.weights[i, j]:.2f}',
                        ha='center', va='center', color='black')

        plt.colorbar(im)
        plt.tight_layout()
        plt.show()

    def visualize_state_evolution(self):
        """
        可视化状态演化过程
        """
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 10))

        # 绘制状态演化
        state_array = np.array(self.state_history)
        for i in range(self.n_neurons):
            ax1.plot(state_array[:, i], label=f'神经元 {i}', linewidth=1)
        ax1.set_title('神经元状态演化过程')
        ax1.set_xlabel('时间步')
        ax1.set_ylabel('状态')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 绘制能量变化
        ax2.plot(self.energy_history, 'r-', linewidth=1)
        ax2.set_title('网络能量变化过程')
        ax2.set_xlabel('时间步')
        ax2.set_ylabel('能量')
        ax2.grid(True, alpha=0.3)

        # 绘制温度变化
        ax3.plot(self.temperature_history, 'g-', linewidth=1)
        ax3.set_title('温度变化过程')
        ax3.set_xlabel('时间步')
        ax3.set_ylabel('温度')
        ax3.grid(True, alpha=0.3)

        plt.tight_layout()
        plt.show()

    def visualize_state_distribution(self):
        """
        可视化状态分布
        """
        states, frequencies = self.get_state_frequencies()

        # 创建状态标签
        state_labels = [''.join(['↑' if s == 1 else '↓' for s in state]) for state in states]

        fig, ax = plt.subplots(figsize=(10, 6))
        bars = ax.bar(range(len(states)), frequencies, color='skyblue')
        ax.set_title('稳态下各状态出现频率')
        ax.set_xlabel('网络状态')
        ax.set_ylabel('出现频率')
        ax.set_xticks(range(len(states)))
        ax.set_xticklabels(state_labels, rotation=45, ha='right')

        # 在柱状图上添加数值标签
        for i, (bar, freq) in enumerate(zip(bars, frequencies)):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                    f'{freq:.3f}', ha='center', va='bottom')

        plt.tight_layout()
        plt.show()

    def print_details(self):
        """
        打印网络详细信息
        """
        print("玻尔兹曼机网络参数:")
        print("=" * 30)
        print(f"神经元数量: {self.n_neurons}")
        print("\n权重矩阵:")
        print(self.weights)
        print("\n阈值向量:")
        print(self.thresholds)
        print(f"\n初始状态: {self.state}")


def visualize_neural_dynamics(bm, sample_interval=500):
    """
    可视化神经元动态过程
    """
    # 选取部分历史数据进行可视化
    if len(bm.state_history) > sample_interval:
        indices = np.linspace(0, len(bm.state_history) - 1, sample_interval, dtype=int)
        sampled_states = [bm.state_history[i] for i in indices]
        sampled_energies = [bm.energy_history[i] for i in indices]
        sampled_temps = [bm.temperature_history[i] for i in indices]
    else:
        sampled_states = bm.state_history
        sampled_energies = bm.energy_history
        sampled_temps = bm.temperature_history

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))

    # 绘制神经元状态热力图
    state_array = np.array(sampled_states)
    im = ax1.imshow(state_array.T, cmap='RdBu', aspect='auto', vmin=-1, vmax=1)
    ax1.set_title('神经元状态演化热力图')
    ax1.set_xlabel('时间步')
    ax1.set_ylabel('神经元')
    ax1.set_yticks(range(bm.n_neurons))
    ax1.set_yticklabels([f'神经元 {i}' for i in range(bm.n_neurons)])

    # 添加颜色条
    cbar = plt.colorbar(im, ax=ax1)
    cbar.set_label('状态 (-1 或 1)')

    # 绘制能量和温度变化
    ax2_twin = ax2.twinx()
    line1, = ax2.plot(sampled_energies, 'b-', linewidth=1, label='能量')
    line2, = ax2_twin.plot(sampled_temps, 'r--', linewidth=1, label='温度')

    ax2.set_xlabel('时间步')
    ax2.set_ylabel('能量', color='b')
    ax2_twin.set_ylabel('温度', color='r')
    ax2.set_title('能量和温度变化')
    ax2.grid(True, alpha=0.3)

    # 添加图例
    lines = [line1, line2]
    labels = [line.get_label() for line in lines]
    ax2.legend(lines, labels, loc='center right')

    plt.tight_layout()
    plt.show()


def main():
    print("三神经元玻尔兹曼机运行过程可视化")
    print("=" * 40)

    # 创建三神经元的玻尔兹曼机
    bm = BoltzmannMachine(n_neurons=3)

    # 打印网络详细信息
    bm.print_details()

    # 可视化权重矩阵
    bm.visualize_weights()

    print("\n开始模拟退火过程...")
    print("初始状态:", bm.state)

    # 运行模拟退火
    steps = bm.simulate_annealing(
        initial_temperature=3.0,  # 初始温度
        final_temperature=0.01,  # 最终温度
        cooling_rate=0.98,  # 降温速率
        steps_per_temp=50,  # 每个温度步数
        max_steps=5000  # 最大步数
    )

    print(f"模拟完成，总步数: {steps}")
    print("最终状态:", bm.state)
    print(f"最终能量: {bm.energy():.4f}")

    # 可视化神经元动态过程
    visualize_neural_dynamics(bm)

    # 可视化状态演化过程
    bm.visualize_state_evolution()

    # 可视化状态分布
    bm.visualize_state_distribution()

    # 显示状态频率统计
    states, frequencies = bm.get_state_frequencies()
    print("\n稳态下各状态出现频率:")
    print("-" * 30)
    for state, freq in zip(states, frequencies):
        state_str = ''.join(['↑' if s == 1 else '↓' for s in state])
        print(f"状态 {state_str}: {freq:.4f}")

    # 分析热平衡过程
    print("\n热平衡过程分析:")
    print("-" * 30)
    initial_energy = bm.energy_history[0]
    final_energy = bm.energy_history[-1]
    print(f"初始能量: {initial_energy:.4f}")
    print(f"最终能量: {final_energy:.4f}")
    print(f"能量变化: {final_energy - initial_energy:.4f}")

    # 检查最后1000步的能量变化，判断是否达到热平衡
    if len(bm.energy_history) > 1000:
        last_1000_energies = bm.energy_history[-1000:]
        energy_variance = np.var(last_1000_energies)
        print(f"最后1000步能量方差: {energy_variance:.6f}")
        if energy_variance < 0.1:
            print("网络已达到热平衡状态")
        else:
            print("网络尚未完全达到热平衡状态")


if __name__ == "__main__":
    main()
