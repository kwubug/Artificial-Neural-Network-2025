import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体为 SimHei（黑体）
plt.rcParams['font.family'] = 'Microsoft YaHei'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class SteepestDescent:
    def __init__(self, function, gradient, learning_rate_type='fixed', fixed_lr=0.1, max_iter=100, tol=1e-6):
        self.function = function
        self.gradient = gradient
        self.learning_rate_type = learning_rate_type
        self.fixed_lr = fixed_lr
        self.max_iter = max_iter
        self.tol = tol
        self.history = []
        self.converged_iter = 0

    def line_search(self, x, direction, max_alpha=1.0, num_points=100):
        """线搜索找到最优学习率"""
        alphas = np.linspace(0, max_alpha, num_points)
        best_alpha = 0
        best_value = float('inf')

        for alpha in alphas:
            candidate = x + alpha * direction
            value = self.function(candidate)
            if value < best_value:
                best_value = value
                best_alpha = alpha

        return best_alpha

    def optimize(self, x0):
        """执行最速下降优化"""
        x = np.array(x0, dtype=float)
        self.history = [x.copy()]
        self.converged_iter = 0

        for k in range(self.max_iter):
            # 计算梯度
            g = self.gradient(x)

            # 检查收敛
            if np.linalg.norm(g) < self.tol:
                self.converged_iter = k
                print(f"最速下降法在 {k} 次迭代后收敛")
                break

            # 确定搜索方向 (最速下降方向)
            p = -g

            # 确定学习率
            if self.learning_rate_type == 'line_search':
                alpha = self.line_search(x, p)
            elif self.learning_rate_type == 'decaying':
                alpha = self.fixed_lr / (k + 1)
            else:  # fixed
                alpha = self.fixed_lr

            # 更新参数
            x = x + alpha * p
            self.history.append(x.copy())

        if self.converged_iter == 0 and np.linalg.norm(self.gradient(x)) >= self.tol:
            self.converged_iter = self.max_iter
            print(f"最速下降法在 {self.max_iter} 次迭代后未收敛")

        return x


class NewtonMethod:
    def __init__(self, function, gradient, hessian, max_iter=100, tol=1e-6, alpha=1.0):
        self.function = function
        self.gradient = gradient
        self.hessian = hessian
        self.max_iter = max_iter
        self.tol = tol
        self.alpha = alpha  # 牛顿法也可以使用学习率
        self.history = []
        self.converged_iter = 0

    def optimize(self, x0):
        """执行牛顿法优化"""
        x = np.array(x0, dtype=float)
        self.history = [x.copy()]
        self.converged_iter = 0

        for k in range(self.max_iter):
            # 计算梯度和Hessian矩阵
            g = self.gradient(x)

            # 检查收敛
            if np.linalg.norm(g) < self.tol:
                self.converged_iter = k
                print(f"牛顿法在 {k} 次迭代后收敛")
                break

            H = self.hessian(x)

            try:
                # 计算搜索方向: p = -H^{-1}g
                # 添加正则化项避免奇异矩阵
                H_reg = H + 1e-8 * np.eye(H.shape[0])
                p = -np.linalg.solve(H_reg, g)
            except np.linalg.LinAlgError:
                print(f"第 {k} 次迭代: Hessian矩阵奇异，使用最速下降方向")
                p = -g

            # 更新参数 (牛顿法通常使用步长1，但可以结合线搜索)
            x_new = x + self.alpha * p

            # 检查步长是否过大
            if np.linalg.norm(x_new - x) > 10:  # 限制最大步长
                print(f"第 {k} 次迭代: 步长过大，使用缩减步长")
                x_new = x + 0.1 * p

            x = x_new
            self.history.append(x.copy())

        if self.converged_iter == 0 and np.linalg.norm(self.gradient(x)) >= self.tol:
            self.converged_iter = self.max_iter
            print(f"牛顿法在 {self.max_iter} 次迭代后未收敛")

        return x


class ConjugateGradient:
    def __init__(self, function, gradient, max_iter=100, tol=1e-6, beta_method='FR'):
        """
        共轭梯度法

        参数:
        - beta_method: 选择beta计算方法
          'HS': Hestenes-Stiefel方法
          'FR': Fletcher-Reeves方法 (默认)
          'PR': Polak-Ribiere方法
        """
        self.function = function
        self.gradient = gradient
        self.max_iter = max_iter
        self.tol = tol
        self.beta_method = beta_method
        self.history = []
        self.converged_iter = 0

    def line_search(self, x, direction, max_alpha=1.0, num_points=100):
        """线搜索找到最优学习率"""
        alphas = np.linspace(0, max_alpha, num_points)
        best_alpha = 0
        best_value = float('inf')

        for alpha in alphas:
            candidate = x + alpha * direction
            value = self.function(candidate)
            if value < best_value:
                best_value = value
                best_alpha = alpha

        return best_alpha

    def compute_beta(self, g_current, g_prev, p_prev, method):
        """计算beta参数"""
        if method == 'HS':  # Hestenes-Stiefel方法
            delta_g = g_current - g_prev
            numerator = np.dot(delta_g, g_current)
            denominator = np.dot(delta_g, p_prev)
            if denominator == 0:
                return 0
            return numerator / denominator

        elif method == 'FR':  # Fletcher-Reeves方法 (默认)
            numerator = np.dot(g_current, g_current)
            denominator = np.dot(g_prev, g_prev)
            if denominator == 0:
                return 0
            return numerator / denominator

        elif method == 'PR':  # Polak-Ribiere方法
            delta_g = g_current - g_prev
            numerator = np.dot(delta_g, g_current)
            denominator = np.dot(g_prev, g_prev)
            if denominator == 0:
                return 0
            return numerator / denominator

        else:
            raise ValueError("未知的beta计算方法")

    def optimize(self, x0):
        """执行共轭梯度法优化"""
        x = np.array(x0, dtype=float)
        self.history = [x.copy()]
        self.converged_iter = 0

        # 第一次迭代：使用负梯度方向
        g = self.gradient(x)
        p = -g  # 初始搜索方向为负梯度

        for k in range(self.max_iter):
            # 检查收敛
            if np.linalg.norm(g) < self.tol:
                self.converged_iter = k
                print(f"共轭梯度法({self.beta_method})在 {k} 次迭代后收敛")
                break

            # 保存上一次的梯度和方向
            g_prev = g.copy()
            p_prev = p.copy()

            # 线搜索确定步长
            alpha = self.line_search(x, p)

            # 更新参数
            x = x + alpha * p
            self.history.append(x.copy())

            # 计算新的梯度
            g = self.gradient(x)

            # 计算beta
            beta = self.compute_beta(g, g_prev, p_prev, self.beta_method)

            # 更新搜索方向
            p = -g + beta * p_prev

        if self.converged_iter == 0 and np.linalg.norm(self.gradient(x)) >= self.tol:
            self.converged_iter = self.max_iter
            print(f"共轭梯度法({self.beta_method})在 {self.max_iter} 次迭代后未收敛")

        return x


def quadratic_function(x):
    """二次函数示例: f(x) = x1^2 + 2x2^2 + x1*x2"""
    x = np.asarray(x)
    return x[0] ** 2 + 2 * x[1] ** 2 + x[0] * x[1]


def quadratic_gradient(x):
    """二次函数的梯度"""
    x = np.asarray(x)
    return np.array([2 * x[0] + x[1], 4 * x[1] + x[0]])


def quadratic_hessian(x):
    """二次函数的Hessian矩阵"""
    return np.array([[2, 1], [1, 4]])


def quadratic_function_book(x):
    """书中示例的二次函数: f(x) = 1/2 * x^T * A * x, 其中A = [[2,1],[1,2]]"""
    x = np.asarray(x)
    A = np.array([[2, 1], [1, 2]])
    return 0.5 * np.dot(x.T, np.dot(A, x))


def quadratic_gradient_book(x):
    """书中示例的二次函数的梯度"""
    x = np.asarray(x)
    A = np.array([[2, 1], [1, 2]])
    return np.dot(A, x)


def quadratic_hessian_book(x):
    """书中示例的二次函数的Hessian矩阵"""
    return np.array([[2, 1], [1, 2]])


def rosenbrock_function(x):
    """Rosenbrock函数 - 经典的优化测试函数"""
    x = np.asarray(x)
    return (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2


def rosenbrock_gradient(x):
    """Rosenbrock函数的梯度"""
    x = np.asarray(x)
    return np.array([
        -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2),
        200 * (x[1] - x[0] ** 2)
    ])


def rosenbrock_hessian(x):
    """Rosenbrock函数的Hessian矩阵"""
    x = np.asarray(x)
    return np.array([
        [2 - 400 * x[1] + 1200 * x[0] ** 2, -400 * x[0]],
        [-400 * x[0], 200]
    ])


def create_3d_optimization_view(optimizer, function, title, x_range=(-2, 2), y_range=(-2, 2)):
    """创建3D寻优视图展示优化路径"""
    fig = plt.figure(figsize=(14, 10))

    # 1. 3D曲面图
    ax1 = fig.add_subplot(2, 2, 1, projection='3d')

    # 创建网格
    x1 = np.linspace(x_range[0], x_range[1], 50)
    x2 = np.linspace(y_range[0], y_range[1], 50)
    X1, X2 = np.meshgrid(x1, x2)

    # 计算函数值
    Z = np.zeros_like(X1)
    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            Z[i, j] = function([X1[i, j], X2[i, j]])

    # 绘制曲面
    surf = ax1.plot_surface(X1, X2, Z, cmap=cm.viridis, alpha=0.7,
                            linewidth=0, antialiased=True)

    # 绘制优化路径
    history = np.array(optimizer.history)
    z_history = [function(point) for point in history]
    ax1.plot(history[:, 0], history[:, 1], z_history, 'ro-',
             markersize=6, linewidth=3, label='优化路径')

    # 标记起点和终点
    ax1.scatter([history[0, 0]], [history[0, 1]], [z_history[0]],
                color='green', s=100, label='起点')
    ax1.scatter([history[-1, 0]], [history[-1, 1]], [z_history[-1]],
                color='blue', s=100, label='终点')

    ax1.set_xlabel('x1')
    ax1.set_ylabel('x2')
    ax1.set_zlabel('f(x)')
    ax1.set_title(f'{title} - 3D曲面视图\n收敛迭代: {optimizer.converged_iter}')

    # 2. 等高线图
    ax2 = fig.add_subplot(2, 2, 2)
    contours = ax2.contour(X1, X2, Z, levels=20, alpha=0.6)
    ax2.clabel(contours, inline=True, fontsize=8)
    ax2.plot(history[:, 0], history[:, 1], 'ro-', markersize=4, linewidth=2, label='优化路径')
    ax2.plot(history[0, 0], history[0, 1], 'go', markersize=8, label='起点')
    ax2.plot(history[-1, 0], history[-1, 1], 'bo', markersize=8, label='终点')
    ax2.set_xlabel('x1')
    ax2.set_ylabel('x2')
    ax2.set_title(f'{title} - 等高线视图')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    # 3. 收敛曲线
    ax3 = fig.add_subplot(2, 2, 3)
    function_values = [function(point) for point in optimizer.history]
    ax3.plot(range(len(function_values)), function_values, 'b-o', markersize=4, linewidth=2)
    if hasattr(optimizer, 'converged_iter'):
        ax3.axvline(x=optimizer.converged_iter, color='r', linestyle='--',
                    label=f'收敛点 (迭代 {optimizer.converged_iter})')
    ax3.set_xlabel('迭代次数')
    ax3.set_ylabel('函数值 f(x)')
    ax3.set_title(f'{title} - 收敛曲线')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    ax3.set_yscale('log')

    # 4. 梯度范数变化
    ax4 = fig.add_subplot(2, 2, 4)
    gradient_norms = [np.linalg.norm(optimizer.gradient(point)) for point in optimizer.history]
    ax4.plot(range(len(gradient_norms)), gradient_norms, 'g-o', markersize=4, linewidth=2)
    ax4.axhline(y=optimizer.tol, color='r', linestyle='--', label=f'收敛阈值 ({optimizer.tol})')
    if hasattr(optimizer, 'converged_iter'):
        ax4.axvline(x=optimizer.converged_iter, color='r', linestyle='--',
                    label=f'收敛点 (迭代 {optimizer.converged_iter})')
    ax4.set_xlabel('迭代次数')
    ax4.set_ylabel('梯度范数 ||∇f(x)||')
    ax4.set_title(f'{title} - 梯度范数变化')
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    ax4.set_yscale('log')

    plt.tight_layout()
    return fig


def create_comparison_3d_view(optimizers, titles, function, x_range=(-2, 2), y_range=(-2, 2)):
    """创建多种算法的3D对比视图"""
    n_optimizers = len(optimizers)
    fig = plt.figure(figsize=(5 * n_optimizers, 5))

    # 创建网格
    x1 = np.linspace(x_range[0], x_range[1], 50)
    x2 = np.linspace(y_range[0], y_range[1], 50)
    X1, X2 = np.meshgrid(x1, x2)

    # 计算函数值
    Z = np.zeros_like(X1)
    for i in range(X1.shape[0]):
        for j in range(X1.shape[1]):
            Z[i, j] = function([X1[i, j], X2[i, j]])

    colors = ['red', 'blue', 'green', 'orange', 'purple']

    for idx, (optimizer, title, color) in enumerate(zip(optimizers, titles, colors)):
        ax = fig.add_subplot(1, n_optimizers, idx + 1, projection='3d')

        # 绘制曲面
        surf = ax.plot_surface(X1, X2, Z, cmap=cm.viridis, alpha=0.3,
                               linewidth=0, antialiased=True)

        # 绘制优化路径
        if optimizer and hasattr(optimizer, 'history') and optimizer.history:
            history = np.array(optimizer.history)
            z_history = [function(point) for point in history]

            # 绘制路径线
            ax.plot(history[:, 0], history[:, 1], z_history,
                    color=color, marker='o', markersize=4, linewidth=2,
                    label=f'{title}路径')

            # 标记起点和终点
            ax.scatter([history[0, 0]], [history[0, 1]], [z_history[0]],
                       color='green', s=80, label='起点')
            ax.scatter([history[-1, 0]], [history[-1, 1]], [z_history[-1]],
                       color='blue', s=80, label='终点')

        ax.set_xlabel('x1')
        ax.set_ylabel('x2')
        ax.set_zlabel('f(x)')
        if hasattr(optimizer, 'converged_iter'):
            ax.set_title(f'{title}\n收敛迭代: {optimizer.converged_iter}')
        else:
            ax.set_title(f'{title}')
        ax.legend()

    plt.tight_layout()
    return fig


def plot_convergence_comparison(optimizers, titles, function):
    """绘制收敛性对比图"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    colors = ['red', 'blue', 'green', 'orange', 'purple']

    for optimizer, title, color in zip(optimizers, titles, colors):
        if optimizer and hasattr(optimizer, 'history') and optimizer.history:
            # 函数值收敛
            function_values = [function(point) for point in optimizer.history]
            if hasattr(optimizer, 'converged_iter'):
                ax1.plot(range(len(function_values)), function_values, 'o-',
                         color=color, markersize=4, linewidth=2, label=f'{title} (迭代 {optimizer.converged_iter})')
            else:
                ax1.plot(range(len(function_values)), function_values, 'o-',
                         color=color, markersize=4, linewidth=2, label=f'{title}')

            # 梯度范数收敛
            gradient_norms = [np.linalg.norm(optimizer.gradient(point)) for point in optimizer.history]
            if hasattr(optimizer, 'converged_iter'):
                ax2.plot(range(len(gradient_norms)), gradient_norms, 'o-',
                         color=color, markersize=4, linewidth=2, label=f'{title} (迭代 {optimizer.converged_iter})')
            else:
                ax2.plot(range(len(gradient_norms)), gradient_norms, 'o-',
                         color=color, markersize=4, linewidth=2, label=f'{title}')

    ax1.set_xlabel('迭代次数')
    ax1.set_ylabel('函数值 f(x)')
    ax1.set_title('函数值收敛对比')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_yscale('log')

    ax2.set_xlabel('迭代次数')
    ax2.set_ylabel('梯度范数 ||∇f(x)||')
    ax2.set_title('梯度范数收敛对比')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    ax2.set_yscale('log')
    if optimizers:
        ax2.axhline(y=optimizers[0].tol, color='r', linestyle='--', label='收敛阈值')

    return fig, (ax1, ax2)


def demo_quadratic_function():
    """演示二次函数的优化"""
    print("二次函数 f(x) = x1² + 2x2² + x1*x2 优化演示")
    print("=" * 50)

    x0 = [-1.5, 1.5]

    # 最速下降法
    sd_quad = SteepestDescent(quadratic_function, quadratic_gradient,
                              learning_rate_type='line_search', max_iter=50)
    result_sd_quad = sd_quad.optimize(x0)

    # 牛顿法
    newton_quad = NewtonMethod(quadratic_function, quadratic_gradient,
                               quadratic_hessian, max_iter=10, alpha=1.0)
    result_newton_quad = newton_quad.optimize(x0)

    # 共轭梯度法 - 三种方法
    cg_fr = ConjugateGradient(quadratic_function, quadratic_gradient,
                              max_iter=10, beta_method='FR')
    result_cg_fr = cg_fr.optimize(x0)

    cg_pr = ConjugateGradient(quadratic_function, quadratic_gradient,
                              max_iter=10, beta_method='PR')
    result_cg_pr = cg_pr.optimize(x0)

    cg_hs = ConjugateGradient(quadratic_function, quadratic_gradient,
                              max_iter=10, beta_method='HS')
    result_cg_hs = cg_hs.optimize(x0)

    print(f"最速下降法结果: {result_sd_quad}, 函数值: {quadratic_function(result_sd_quad):.6f}")
    print(f"牛顿法结果: {result_newton_quad}, 函数值: {quadratic_function(result_newton_quad):.6f}")
    print(f"共轭梯度法(FR)结果: {result_cg_fr}, 函数值: {quadratic_function(result_cg_fr):.6f}")
    print(f"共轭梯度法(PR)结果: {result_cg_pr}, 函数值: {quadratic_function(result_cg_pr):.6f}")
    print(f"共轭梯度法(HS)结果: {result_cg_hs}, 函数值: {quadratic_function(result_cg_hs):.6f}")
    print(f"理论最小值在: [0, 0], 函数值: 0")

    return sd_quad, newton_quad, cg_fr, cg_pr, cg_hs


def demo_book_quadratic_function():
    """演示书中示例的二次函数优化"""
    print("\n书中示例二次函数 f(x) = 1/2 * x^T * A * x 优化演示")
    print("=" * 60)

    x0 = [0.8, -0.25]  # 书中示例的初始点

    # 最速下降法
    sd_book = SteepestDescent(quadratic_function_book, quadratic_gradient_book,
                              learning_rate_type='line_search', max_iter=50)
    result_sd_book = sd_book.optimize(x0)

    # 牛顿法
    newton_book = NewtonMethod(quadratic_function_book, quadratic_gradient_book,
                               quadratic_hessian_book, max_iter=10, alpha=1.0)
    result_newton_book = newton_book.optimize(x0)

    # 共轭梯度法 - 三种方法
    cg_fr_book = ConjugateGradient(quadratic_function_book, quadratic_gradient_book,
                                   max_iter=10, beta_method='FR')
    result_cg_fr_book = cg_fr_book.optimize(x0)

    cg_pr_book = ConjugateGradient(quadratic_function_book, quadratic_gradient_book,
                                   max_iter=10, beta_method='PR')
    result_cg_pr_book = cg_pr_book.optimize(x0)

    cg_hs_book = ConjugateGradient(quadratic_function_book, quadratic_gradient_book,
                                   max_iter=10, beta_method='HS')
    result_cg_hs_book = cg_hs_book.optimize(x0)

    print(f"最速下降法结果: {result_sd_book}, 函数值: {quadratic_function_book(result_sd_book):.6f}")
    print(f"牛顿法结果: {result_newton_book}, 函数值: {quadratic_function_book(result_newton_book):.6f}")
    print(f"共轭梯度法(FR)结果: {result_cg_fr_book}, 函数值: {quadratic_function_book(result_cg_fr_book):.6f}")
    print(f"共轭梯度法(PR)结果: {result_cg_pr_book}, 函数值: {quadratic_function_book(result_cg_pr_book):.6f}")
    print(f"共轭梯度法(HS)结果: {result_cg_hs_book}, 函数值: {quadratic_function_book(result_cg_hs_book):.6f}")
    print(f"理论最小值在: [0, 0], 函数值: 0")

    return sd_book, newton_book, cg_fr_book, cg_pr_book, cg_hs_book


def demo_rosenbrock_function():
    """演示Rosenbrock函数的优化"""
    print("\n\nRosenbrock函数优化演示")
    print("=" * 50)

    x0 = [-1.5, 1.5]

    # 最速下降法
    sd_rosen = SteepestDescent(rosenbrock_function, rosenbrock_gradient,
                               learning_rate_type='line_search', max_iter=100)
    result_sd_rosen = sd_rosen.optimize(x0)

    # 牛顿法 - 使用较小的学习率避免震荡
    newton_rosen = NewtonMethod(rosenbrock_function, rosenbrock_gradient,
                                rosenbrock_hessian, max_iter=50, alpha=0.5)
    result_newton_rosen = newton_rosen.optimize(x0)

    # 共轭梯度法 - 三种方法
    cg_fr_rosen = ConjugateGradient(rosenbrock_function, rosenbrock_gradient,
                                    max_iter=50, beta_method='FR')
    result_cg_fr_rosen = cg_fr_rosen.optimize(x0)

    cg_pr_rosen = ConjugateGradient(rosenbrock_function, rosenbrock_gradient,
                                    max_iter=50, beta_method='PR')
    result_cg_pr_rosen = cg_pr_rosen.optimize(x0)

    cg_hs_rosen = ConjugateGradient(rosenbrock_function, rosenbrock_gradient,
                                    max_iter=50, beta_method='HS')
    result_cg_hs_rosen = cg_hs_rosen.optimize(x0)

    print(f"最速下降法结果: {result_sd_rosen}, 函数值: {rosenbrock_function(result_sd_rosen):.6f}")
    print(f"牛顿法结果: {result_newton_rosen}, 函数值: {rosenbrock_function(result_newton_rosen):.6f}")
    print(f"共轭梯度法(FR)结果: {result_cg_fr_rosen}, 函数值: {rosenbrock_function(result_cg_fr_rosen):.6f}")
    print(f"共轭梯度法(PR)结果: {result_cg_pr_rosen}, 函数值: {rosenbrock_function(result_cg_pr_rosen):.6f}")
    print(f"共轭梯度法(HS)结果: {result_cg_hs_rosen}, 函数值: {rosenbrock_function(result_cg_hs_rosen):.6f}")
    print(f"理论最小值在: [1, 1], 函数值: 0")

    return sd_rosen, newton_rosen, cg_fr_rosen, cg_pr_rosen, cg_hs_rosen


# 主演示函数
def main():
    print("最速下降法、牛顿法与共轭梯度法对比演示")
    print("=" * 60)

    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 支持中文显示
    plt.rcParams['axes.unicode_minus'] = False

    try:
        # 演示1: 普通二次函数优化
        print("\n1. 普通二次函数优化演示")
        sd_quad, newton_quad, cg_fr, cg_pr, cg_hs = demo_quadratic_function()

        # 为算法创建3D寻优视图
        print("\n2. 创建3D寻优视图...")

        # 最速下降法的3D视图
        fig_sd_3d = create_3d_optimization_view(sd_quad, quadratic_function,
                                                "最速下降法 - 二次函数")

        # 牛顿法的3D视图
        fig_newton_3d = create_3d_optimization_view(newton_quad, quadratic_function,
                                                    "牛顿法 - 二次函数")

        # 共轭梯度法的3D视图 (以FR方法为例)
        fig_cg_fr_3d = create_3d_optimization_view(cg_fr, quadratic_function,
                                                   "共轭梯度法(FR) - 二次函数")

        # 所有算法的3D对比视图
        optimizers = [sd_quad, newton_quad, cg_fr, cg_pr, cg_hs]
        titles = ["最速下降法", "牛顿法", "共轭梯度法(FR)", "共轭梯度法(PR)", "共轭梯度法(HS)"]
        fig_compare_3d = create_comparison_3d_view(optimizers, titles, quadratic_function)

        # 收敛性对比
        fig_conv, (ax1, ax2) = plot_convergence_comparison(optimizers, titles, quadratic_function)

    except Exception as e:
        print(f"普通二次函数演示出错: {e}")

    try:
        # 演示2: 书中示例二次函数优化
        print("\n3. 书中示例二次函数优化演示")
        sd_book, newton_book, cg_fr_book, cg_pr_book, cg_hs_book = demo_book_quadratic_function()

        # 书中示例的对比视图
        optimizers_book = [sd_book, newton_book, cg_fr_book, cg_pr_book, cg_hs_book]
        titles_book = ["最速下降法", "牛顿法", "共轭梯度法(FR)", "共轭梯度法(PR)", "共轭梯度法(HS)"]
        fig_compare_book_3d = create_comparison_3d_view(optimizers_book, titles_book, quadratic_function_book,
                                                        x_range=(-0.5, 1), y_range=(-0.5, 0.5))

    except Exception as e:
        print(f"书中示例二次函数演示出错: {e}")

    try:
        # 演示3: Rosenbrock函数优化
        print("\n4. Rosenbrock函数优化演示")
        sd_rosen, newton_rosen, cg_fr_rosen, cg_pr_rosen, cg_hs_rosen = demo_rosenbrock_function()

        # Rosenbrock函数的对比视图
        optimizers_rosen = [sd_rosen, newton_rosen, cg_fr_rosen, cg_pr_rosen, cg_hs_rosen]
        titles_rosen = ["最速下降法", "牛顿法", "共轭梯度法(FR)", "共轭梯度法(PR)", "共轭梯度法(HS)"]
        fig_compare_rosen_3d = create_comparison_3d_view(optimizers_rosen, titles_rosen, rosenbrock_function,
                                                         x_range=(-2, 2), y_range=(-1, 3))

    except Exception as e:
        print(f"Rosenbrock函数演示出错: {e}")

    # 输出算法总结
    print("\n" + "=" * 80)
    print("算法总结:")
    print("最速下降法:")
    print(f"- 搜索方向: p_k = -∇F(x_k) (负梯度方向)")
    print(f"- 更新公式: x_{{k+1}} = x_k + α_k * p_k")
    print(f"- 学习率选择: 固定值、衰减值或线搜索")

    print("\n牛顿法:")
    print(f"- 搜索方向: p_k = -[∇²F(x_k)]⁻¹ ∇F(x_k)")
    print(f"- 更新公式: x_{{k+1}} = x_k + α_k * p_k")
    print(f"- 优点: 二次收敛速度，对于二次函数一步收敛")
    print(f"- 缺点: 需要计算Hessian矩阵，可能收敛到鞍点")

    print("\n共轭梯度法:")
    print(f"- 搜索方向: p_k = -g_k + β_k * p_{{k-1}}")
    print(f"- 更新公式: x_{{k+1}} = x_k + α_k * p_k")
    print(f"- 优点: 具有二次终结性质，不需要计算Hessian矩阵")
    print(f"- β计算方法:")
    print(f"  * Fletcher-Reeves (FR): β_k = (g_k^T g_k) / (g_{{k-1}}^T g_{{k-1}})")
    print(f"  * Polak-Ribiere (PR): β_k = (Δg_k^T g_k) / (g_{{k-1}}^T g_{{k-1}})")
    print(f"  * Hestenes-Stiefel (HS): β_k = (Δg_k^T g_k) / (Δg_k^T p_{{k-1}})")

    print("\n关键观察:")
    print(f"- 二次函数: 牛顿法和共轭梯度法应该快速收敛")
    print(f"- Rosenbrock函数: 不同算法表现不同")
    print(f"- 共轭梯度法结合了一阶方法的简单性和二阶方法的快速收敛性")

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()