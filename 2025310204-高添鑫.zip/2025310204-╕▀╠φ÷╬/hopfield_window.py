from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QPushButton, QTextEdit, QLabel,
                               QSpinBox, QFileDialog, QMessageBox, QGridLayout,
                               QRadioButton, QButtonGroup)
from PySide6.QtCore import Slot, Qt
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os

# 确保负号和字体显示正确
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


class HopfieldNetwork:
    def __init__(self, n_neurons):
        self.n = n_neurons  # 神经元数量（等于图案像素数）
        self.weights = np.zeros((n_neurons, n_neurons))  # 权重矩阵
        self.state = np.zeros(n_neurons)  # 神经元状态（-1=黑色，1=白色）

    def train(self, patterns):
        """训练：Hebbian学习规则"""
        n_patterns = len(patterns)
        for p in patterns:
            p = p.reshape(-1, 1)  # 转为列向量
            self.weights += np.dot(p, p.T)  # 外积更新权重
        # 权重归一化（除以神经元数量）
        self.weights /= self.n
        # 对角线元素置0（无自连接）
        np.fill_diagonal(self.weights, 0)

    def recall(self, initial_state, max_iter=100, async_update=True):
        """回忆：更新状态直到收敛"""
        self.state = initial_state.copy()
        state_history = [self.state.copy()]
        energy_history = [self.energy()]

        for _ in range(max_iter):
            if async_update:
                # 异步更新：随机顺序更新每个神经元
                indices = np.random.permutation(self.n)
                for i in indices:
                    self.update_neuron(i)
            else:
                # 同步更新：所有神经元同时更新
                new_state = np.sign(np.dot(self.weights, self.state))
                self.state = new_state

            # 记录历史
            state_history.append(self.state.copy())
            energy_history.append(self.energy())

            # 收敛判断：状态不再变化
            if np.array_equal(state_history[-1], state_history[-2]):
                break

        return state_history, energy_history

    def update_neuron(self, idx):
        """更新单个神经元状态"""
        net_input = np.dot(self.weights[idx], self.state)  # 输入总和
        self.state[idx] = 1 if net_input >= 0 else -1  # 符号函数

    def energy(self):
        """计算网络能量"""
        return -0.5 * np.dot(self.state.T, np.dot(self.weights, self.state))


class HopfieldWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None
        self.canvas = None
        self.hopfield = None  # Hopfield网络实例
        self.patterns = []  # 训练图案列表
        self.current_pattern = None  # 当前显示的图案
        self.init_ui()

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 1. 控制面板（参数设置）
        control_group = QGroupBox("参数设置（Hopfield网络）")
        control_layout = QGridLayout()

        # 图案大小
        control_layout.addWidget(QLabel("图案大小（N×N）:"), 0, 0)
        self.size_spin = QSpinBox()
        self.size_spin.setRange(3, 10)  # 3×3到10×10
        self.size_spin.setValue(5)
        self.size_spin.valueChanged.connect(self.on_size_changed)
        control_layout.addWidget(self.size_spin, 0, 1)

        # 更新模式（同步/异步）
        control_layout.addWidget(QLabel("更新模式:"), 1, 0)
        self.sync_radio = QRadioButton("同步更新")
        self.async_radio = QRadioButton("异步更新", checked=True)
        self.update_group = QButtonGroup()
        self.update_group.addButton(self.sync_radio)
        self.update_group.addButton(self.async_radio)
        update_layout = QHBoxLayout()
        update_layout.addWidget(self.sync_radio)
        update_layout.addWidget(self.async_radio)
        control_layout.addLayout(update_layout, 1, 1)

        # 最大迭代次数
        control_layout.addWidget(QLabel("最大迭代次数:"), 2, 0)
        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(10, 500)
        self.iter_spin.setValue(100)
        control_layout.addWidget(self.iter_spin, 2, 1)

        # 按钮布局
        button_layout = QHBoxLayout()
        self.init_btn = QPushButton("初始化网络")
        self.init_btn.clicked.connect(self.init_network)
        self.train_btn = QPushButton("训练网络")
        self.train_btn.clicked.connect(self.train_network)
        self.recall_btn = QPushButton("回忆测试")
        self.recall_btn.clicked.connect(self.recall_test)
        self.add_noise_btn = QPushButton("添加噪声")
        self.add_noise_btn.clicked.connect(self.add_noise)
        self.save_btn = QPushButton("保存结果")
        self.save_btn.clicked.connect(self.save_figure)
        button_layout.addWidget(self.init_btn)
        button_layout.addWidget(self.train_btn)
        button_layout.addWidget(self.recall_btn)
        button_layout.addWidget(self.add_noise_btn)
        button_layout.addWidget(self.save_btn)
        control_layout.addLayout(button_layout, 3, 0, 1, 2)

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 2. 结果显示区域
        result_layout = QHBoxLayout()

        # 文本输出（关键：提前创建，确保on_size_changed调用时存在）
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用Hopfield网络界面！")
        self.text_output.append("支持功能：图案训练、回忆测试、噪声添加")
        self.text_output.append("步骤：1. 设置图案大小 → 2. 初始化网络 → 3. 绘制训练图案 → 4. 训练 → 5. 回忆")
        result_layout.addWidget(self.text_output, 1)

        # 图形显示
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)

        main_layout.addLayout(result_layout, 1)

        # 3. 绘制训练图案的按钮网格（动态创建）
        self.pattern_grid = QGridLayout()
        self.pattern_buttons = []
        self.on_size_changed(self.size_spin.value())  # 初始化图案按钮（现在text_output已存在）

    def initialize_plot(self):
        """初始化绘图区域"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(8, 6), dpi=100)
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        # 初始绘制提示图
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "等待初始化网络...", ha='center', va='center', fontsize=14)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot(int)
    def on_size_changed(self, size):
        """图案大小变化时，更新按钮网格"""
        # 清空之前的按钮
        for btn in self.pattern_buttons:
            btn.deleteLater()
        self.pattern_buttons.clear()
        while self.pattern_grid.count():
            item = self.pattern_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # 创建新的按钮网格（用于绘制图案）
        pattern_group = QGroupBox(f"绘制训练图案（点击切换黑白）")
        for i in range(size):
            for j in range(size):
                btn = QPushButton()
                btn.setStyleSheet("background-color: white; border: 1px solid gray;")
                btn.setFixedSize(30, 30)
                btn.clicked.connect(lambda _, x=i, y=j: self.toggle_pixel(x, y))
                self.pattern_grid.addWidget(btn, i, j)
                self.pattern_buttons.append((i, j, btn))

        pattern_group.setLayout(self.pattern_grid)
        # 将图案组添加到主布局（插入到控制面板下方）
        self.layout().insertWidget(1, pattern_group)

        # 现在text_output已存在，可安全调用append
        self.text_output.append(f"\n图案大小设置为 {size}×{size}（神经元数量：{size * size}）")
        self.text_output.append("提示：点击网格按钮绘制图案，白色=1，黑色=-1")

    @Slot()
    def toggle_pixel(self, x, y):
        """切换像素颜色（白色↔黑色）"""
        for i, j, btn in self.pattern_buttons:
            if i == x and j == y:
                current_color = btn.styleSheet().split(': ')[1].split(';')[0]
                if current_color == 'white':
                    btn.setStyleSheet("background-color: black; border: 1px solid gray;")
                else:
                    btn.setStyleSheet("background-color: white; border: 1px solid gray;")
                break

    @Slot()
    def init_network(self):
        """初始化Hopfield网络"""
        size = self.size_spin.value()
        self.hopfield = HopfieldNetwork(n_neurons=size * size)
        self.text_output.append("\n[步骤1] 初始化Hopfield网络成功！")
        self.text_output.append(f"网络规模：{size}×{size} 神经元（共{size * size}个）")

        # 重置图案显示
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "绘制训练图案后点击「训练网络」", ha='center', va='center', fontsize=12)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot()
    def train_network(self):
        """训练网络（添加当前图案并更新权重）"""
        if self.hopfield is None:
            self.text_output.append("\n[错误] 请先初始化网络！")
            QMessageBox.warning(self, "警告", "请先点击「初始化网络」按钮！").exec()
            return

        # 提取当前绘制的图案（转为-1/1向量）
        size = self.size_spin.value()
        pattern = np.zeros(size * size)
        idx = 0
        for i in range(size):
            for j in range(size):
                for x, y, btn in self.pattern_buttons:
                    if i == x and j == y:
                        color = btn.styleSheet().split(': ')[1].split(';')[0]
                        pattern[idx] = 1 if color == 'white' else -1
                        idx += 1
                        break

        # 检查图案是否有效（不全为白/黑）
        if np.all(pattern == 1) or np.all(pattern == -1):
            self.text_output.append("\n[错误] 训练图案不能全为白色或全为黑色！")
            QMessageBox.warning(self, "警告", "请绘制非纯色的图案！").exec()
            return

        # 添加到训练集并训练
        self.patterns.append(pattern)
        self.hopfield.train(self.patterns)

        self.text_output.append(f"\n[步骤2] 训练成功！当前训练图案数：{len(self.patterns)}")
        self.text_output.append(f"图案向量：{pattern.round(0)}")

        # 显示训练后的图案
        self.current_pattern = pattern.reshape(size, size)
        self.plot_pattern(self.current_pattern, title=f"训练图案 {len(self.patterns)}")

    @Slot()
    def recall_test(self):
        """回忆测试（从当前图案开始迭代）"""
        if self.hopfield is None or len(self.patterns) == 0:
            self.text_output.append("\n[错误] 请先初始化网络并训练！")
            QMessageBox.warning(self, "警告", "请先初始化网络并添加训练图案！").exec()
            return

        size = self.size_spin.value()
        max_iter = self.iter_spin.value()
        async_update = self.async_radio.isChecked()

        self.text_output.append(f"\n[步骤3] 开始回忆测试（{['同步', '异步'][async_update]}更新，最大迭代{max_iter}次）")

        # 以当前图案为初始状态开始回忆
        initial_state = self.current_pattern.reshape(-1)
        state_history, energy_history = self.hopfield.recall(
            initial_state=initial_state,
            max_iter=max_iter,
            async_update=async_update
        )

        # 输出结果
        self.text_output.append(f"回忆完成！迭代次数：{len(state_history) - 1}")
        self.text_output.append(f"初始能量：{energy_history[0]:.2f} → 最终能量：{energy_history[-1]:.2f}")
        self.text_output.append(f"最终状态与初始状态是否一致：{np.array_equal(initial_state, state_history[-1])}")

        # 绘制回忆过程（初始状态→最终状态）
        self.figure.clear()

        # 子图1：初始状态
        ax1 = self.figure.add_subplot(121)
        ax1.imshow(initial_state.reshape(size, size), cmap='gray', vmin=-1, vmax=1)
        ax1.set_title("初始状态")
        ax1.set_xticks([])
        ax1.set_yticks([])

        # 子图2：最终状态
        ax2 = self.figure.add_subplot(122)
        final_state = state_history[-1].reshape(size, size)
        ax2.imshow(final_state, cmap='gray', vmin=-1, vmax=1)
        ax2.set_title(f"最终状态（迭代{len(state_history) - 1}次）")
        ax2.set_xticks([])
        ax2.set_yticks([])

        self.canvas.draw()

    @Slot()
    def add_noise(self):
        """为当前图案添加噪声"""
        if self.current_pattern is None:
            self.text_output.append("\n[错误] 请先绘制并训练图案！")
            QMessageBox.warning(self, "警告", "请先绘制图案并完成训练！").exec()
            return

        size = self.size_spin.value()
        # 随机翻转10%的像素（噪声比例）
        noise_ratio = 0.1
        n_noise = int(size * size * noise_ratio)
        noise_indices = np.random.choice(size * size, n_noise, replace=False)

        # 添加噪声
        noisy_pattern = self.current_pattern.reshape(-1).copy()
        for idx in noise_indices:
            noisy_pattern[idx] *= -1  # 翻转状态（1↔-1）

        self.current_pattern = noisy_pattern.reshape(size, size)
        self.text_output.append(f"\n[步骤4] 添加噪声完成！翻转 {n_noise} 个像素（噪声比例{noise_ratio * 100}%）")

        # 显示带噪声的图案
        self.plot_pattern(self.current_pattern, title="带噪声的图案")

    def plot_pattern(self, pattern, title):
        """绘制单个图案"""
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.imshow(pattern, cmap='gray', vmin=-1, vmax=1)
        ax.set_title(title)
        ax.set_xticks([])
        ax.set_yticks([])
        self.canvas.draw()

    @Slot()
    def save_figure(self):
        """保存当前结果图"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先运行回忆测试或添加噪声！").exec()
            return

        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存Hopfield结果图",
            os.path.join(os.getcwd(), "hopfield_result.png"),
            "图片文件 (*.png *.jpg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        try:
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}").exec()
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}").exec()