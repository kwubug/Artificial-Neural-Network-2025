#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
可视化三种梯度下降算法：最速下降法、牛顿法、非线性共轭梯度（默认 FR）
- 目标函数：Rosenbrock（默认）或正定二次函数
- 线搜索：Armijo 回溯线搜索（统一使用，便于公平对比）
- 每种方法均绘制：等高线+迭代轨迹、f(x_k) 收敛曲线
"""

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Callable, List

# ---------- 目标函数定义 ----------

def quad_A_b_c():
    # 正定二次：f(x)=0.5 x^T A x - b^T x + c
    A = np.array([[3.0, 1.0],
                  [1.0, 2.0]])
    b = np.array([1.0, 1.0])
    c = 0.0
    return A, b, c

def f_quadratic(x: np.ndarray) -> float:
    A, b, c = quad_A_b_c()
    return 0.5 * x @ A @ x - b @ x + c

def grad_quadratic(x: np.ndarray) -> np.ndarray:
    A, b, _ = quad_A_b_c()
    return A @ x - b

def hess_quadratic(x: np.ndarray) -> np.ndarray:
    A, _, _ = quad_A_b_c()
    return A

def f_rosenbrock(x: np.ndarray, a: float = 1.0, b: float = 100.0) -> float:
    return (a - x[0])**2 + b * (x[1] - x[0]**2)**2

def grad_rosenbrock(x: np.ndarray, a: float = 1.0, b: float = 100.0) -> np.ndarray:
    dfdx = -2*(a - x[0]) - 4*b*x[0]*(x[1] - x[0]**2)
    dfdy =  2*b*(x[1] - x[0]**2)
    return np.array([dfdx, dfdy])

def hess_rosenbrock(x: np.ndarray, a: float = 1.0, b: float = 100.0) -> np.ndarray:
    d2fdx2  = 2 - 4*b*(x[1] - x[0]**2) + 8*b*x[0]**2
    d2fdy2  = 2*b
    d2fdxdy = -4*b*x[0]
    return np.array([[d2fdx2, d2fdxdy],
                     [d2fdxdy, d2fdy2]])

# ---------- Armijo 回溯线搜索 ----------

def armijo_backtracking(f: Callable[[np.ndarray], float],
                        grad_f: Callable[[np.ndarray], np.ndarray],
                        x: np.ndarray,
                        p: np.ndarray,
                        alpha0: float = 1.0,
                        c1: float = 1e-4,
                        rho: float = 0.5,
                        max_iter: int = 30) -> float:
    """满足 Armijo 充分下降条件的回溯线搜索。"""
    alpha = alpha0
    fx = f(x)
    gT_p = grad_f(x) @ p
    for _ in range(max_iter):
        if f(x + alpha * p) <= fx + c1 * alpha * gT_p:
            return alpha
        alpha *= rho
    return alpha

# ---------- 三种方法 ----------

@dataclass
class Trace:
    xs: List[np.ndarray]
    fs: List[float]
    grads: List[np.ndarray]

def steepest_descent(f, grad_f, x0, max_iter=200, tol=1e-6) -> Trace:
    x = x0.copy()
    xs, fs, gs = [x.copy()], [f(x)], [grad_f(x)]
    for _ in range(max_iter):
        g = grad_f(x)
        if np.linalg.norm(g) < tol:
            break
        p = -g
        a = armijo_backtracking(f, grad_f, x, p)
        x = x + a * p
        xs.append(x.copy()); fs.append(f(x)); gs.append(g.copy())
    return Trace(xs, fs, gs)

def newton_method(f, grad_f, hess_f, x0, max_iter=100, tol=1e-6, damping=True) -> Trace:
    x = x0.copy()
    xs, fs, gs = [x.copy()], [f(x)], [grad_f(x)]
    for _ in range(max_iter):
        g = grad_f(x)
        if np.linalg.norm(g) < tol:
            break
        H = hess_f(x)
        # 简单阻尼，保证下降方向
        if damping:
            mu = 1e-6
            for _ in range(6):
                try:
                    p = -np.linalg.solve(H + mu*np.eye(len(x)), g)
                    if g @ p >= 0:  # 不是下降方向则增大阻尼
                        mu *= 10.0
                        continue
                    break
                except np.linalg.LinAlgError:
                    mu *= 10.0
            else:
                p = -g  # 失败则退化为最速下降
        else:
            try:
                p = -np.linalg.solve(H, g)
            except np.linalg.LinAlgError:
                p = -g
        a = armijo_backtracking(f, grad_f, x, p)
        x = x + a * p
        xs.append(x.copy()); fs.append(f(x)); gs.append(g.copy())
    return Trace(xs, fs, gs)

def conjugate_gradient_nonlinear(f, grad_f, x0, max_iter=200, tol=1e-6, beta_rule="FR") -> Trace:
    """
    非线性共轭梯度：
    - FR: Fletcher–Reeves
    - PR: Polak–Ribiere+（max(.,0)）
    """
    x = x0.copy()
    g = grad_f(x)
    p = -g
    xs, fs, gs = [x.copy()], [f(x)], [g.copy()]
    for _ in range(max_iter):
        if np.linalg.norm(g) < tol:
            break
        a = armijo_backtracking(f, grad_f, x, p)
        x_new = x + a * p
        g_new = grad_f(x_new)
        if beta_rule == "FR":
            beta = (g_new @ g_new) / max(g @ g, 1e-16)
        else:  # PR+
            y = g_new - g
            beta = max((g_new @ y) / max(g @ g, 1e-16), 0.0)
        p = -g_new + beta * p
        x, g = x_new, g_new
        xs.append(x.copy()); fs.append(f(x)); gs.append(g.copy())
    return Trace(xs, fs, gs)

# ---------- 可视化 ----------

def contour_with_path(f, xmin, xmax, ymin, ymax, path: List[np.ndarray], title: str, levels=40):
    X = np.linspace(xmin, xmax, 400)
    Y = np.linspace(ymin, ymax, 400)
    XX, YY = np.meshgrid(X, Y)
    ZZ = np.zeros_like(XX)
    for i in range(XX.shape[0]):
        for j in range(XX.shape[1]):
            ZZ[i, j] = f(np.array([XX[i, j], YY[i, j]]))

    plt.figure(figsize=(6,5))
    cs = plt.contour(XX, YY, ZZ, levels=levels)
    plt.clabel(cs, inline=True, fontsize=7)
    P = np.array(path)
    plt.plot(P[:,0], P[:,1], marker='o', linewidth=1.5, markersize=3)
    plt.title(title)
    plt.xlabel('x1'); plt.ylabel('x2'); plt.grid(True); plt.tight_layout()
    plt.show()

def plot_convergence(fs: List[float], title: str):
    plt.figure(figsize=(6,4))
    plt.plot(fs)
    plt.title(title)
    plt.xlabel("Iteration")
    plt.ylabel("f(x_k)")
    plt.grid(True); plt.tight_layout()
    plt.show()

# ---------- 运行实验 ----------

def main():
    # 选择目标：'rosenbrock' 或 'quadratic'
    objective = 'rosenbrock'

    if objective == 'quadratic':
        f, g, H = f_quadratic, grad_quadratic, hess_quadratic
        x0 = np.array([2.0, -1.0])
        bounds = (-2.5, 2.5, -2.5, 2.5)
        iters_sd, iters_cg = 500, 200
    else:
        f, g, H = f_rosenbrock, grad_rosenbrock, hess_rosenbrock
        x0 = np.array([-1.2, 1.0])  # 经典起点
        bounds = (-2.0, 2.0, -1.0, 3.0)
        iters_sd, iters_cg = 10000, 500

    sd = steepest_descent(f, g, x0, max_iter=iters_sd)
    nw = newton_method(f, g, H, x0, max_iter=200)
    cg = conjugate_gradient_nonlinear(f, g, x0, max_iter=iters_cg, beta_rule="FR")

    contour_with_path(f, *bounds, sd.xs, "Steepest Descent Path")
    contour_with_path(f, *bounds, nw.xs, "Newton's Method Path")
    contour_with_path(f, *bounds, cg.xs, "Conjugate Gradient (FR) Path")

    plot_convergence(sd.fs, "Steepest Descent: f(x_k) vs iteration")
    plot_convergence(nw.fs, "Newton's Method: f(x_k) vs iteration")
    plot_convergence(cg.fs, "Conjugate Gradient (FR): f(x_k) vs iteration")

if __name__ == "__main__":
    main()
