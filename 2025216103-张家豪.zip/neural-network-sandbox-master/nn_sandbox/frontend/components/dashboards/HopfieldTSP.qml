import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield TSP'

    ColumnLayout {
        Layout.preferredWidth: 350
        Layout.maximumWidth: 400
        
        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                Label { text: '城市数量预设'; Layout.alignment: Qt.AlignHCenter }
                ComboBox {
                    id: cityCountCombo
                    enabled: hopfieldTSPBridge.has_finished
                    model: ['5城市', '8城市', '10城市', '15城市']
                    currentIndex: 1
                    onActivated: generateCities()
                    Layout.fillWidth: true
                }

                Button {
                    text: '生成随机城市'
                    enabled: hopfieldTSPBridge.has_finished
                    onClicked: generateCities()
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: '参数A (行约束)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: paramA
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 800
                    from: 100
                    to: 2000
                    stepSize: 50
                    onValueChanged: hopfieldTSPBridge.param_A = value
                    Component.onCompleted: hopfieldTSPBridge.param_A = value
                    Layout.fillWidth: true
                }

                Label { text: '参数B (列约束)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: paramB
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 800
                    from: 100
                    to: 2000
                    stepSize: 50
                    onValueChanged: hopfieldTSPBridge.param_B = value
                    Component.onCompleted: hopfieldTSPBridge.param_B = value
                    Layout.fillWidth: true
                }

                Label { text: '参数C (总数约束)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: paramC
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 300
                    from: 50
                    to: 1000
                    stepSize: 50
                    onValueChanged: hopfieldTSPBridge.param_C = value
                    Component.onCompleted: hopfieldTSPBridge.param_C = value
                    Layout.fillWidth: true
                }

                Label { text: '参数D (距离优化)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: paramD
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 700
                    from: 100
                    to: 2000
                    stepSize: 50
                    onValueChanged: hopfieldTSPBridge.param_D = value
                    Component.onCompleted: hopfieldTSPBridge.param_D = value
                    Layout.fillWidth: true
                }


                Label { text: '最大迭代'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 5000
                    from: 1000
                    to: 20000
                    stepSize: 1000
                    onValueChanged: hopfieldTSPBridge.max_iterations = value
                    Component.onCompleted: hopfieldTSPBridge.max_iterations = value
                    Layout.fillWidth: true
                }

                Label { text: 'UI刷新间隔（秒）'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldTSPBridge.has_finished
                    editable: true
                    value: 0.02 * 100
                    from: 0 * 100
                    to: 0.2 * 100
                    onValueChanged: hopfieldTSPBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: hopfieldTSPBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }

        GroupBox {
            title: '控制与信息'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2

                ExecutionControls {
                    startButton.enabled: hopfieldTSPBridge.has_finished && hopfieldTSPBridge.cities.length >= 3
                    startButton.onClicked: () => {
                        hopfieldTSPBridge.start_tsp()
                        energyChart.reset()
                    }
                    stopButton.enabled: !hopfieldTSPBridge.has_finished
                    stopButton.onClicked: hopfieldTSPBridge.stop_tsp()
                    progressBar.value: hopfieldTSPBridge.current_iteration / Math.max(1, hopfieldTSPBridge.max_iterations)
                    Layout.columnSpan: 2
                    Layout.fillWidth: true
                }

                Label { text: '当前迭代'; Layout.alignment: Qt.AlignHCenter }
                Label { text: hopfieldTSPBridge.current_iteration; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                
                Label { text: '当前能量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: Number.isFinite(hopfieldTSPBridge.current_energy) ? hopfieldTSPBridge.current_energy.toFixed(2) : '-'; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                
                Label { text: '当前路径距离'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: Number.isFinite(hopfieldTSPBridge.current_distance) && hopfieldTSPBridge.current_distance < 1e6 
                          ? hopfieldTSPBridge.current_distance.toFixed(2) 
                          : '无效'; 
                    horizontalAlignment: Text.AlignHCenter; 
                    Layout.fillWidth: true 
                }
                
                Label { text: '最优路径距离'; Layout.alignment: Qt.AlignHCenter }
                Label { 
                    text: Number.isFinite(hopfieldTSPBridge.best_distance) && hopfieldTSPBridge.best_distance < 1e6 
                          ? hopfieldTSPBridge.best_distance.toFixed(2) 
                          : '未找到'; 
                    horizontalAlignment: Text.AlignHCenter; 
                    Layout.fillWidth: true;
                    color: hopfieldTSPBridge.best_distance < 1e6 ? 'green' : 'black'
                }
                
                Label { text: '城市数量'; Layout.alignment: Qt.AlignHCenter }
                Label { text: hopfieldTSPBridge.cities.length; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
                
                Label { 
                    text: '路径有效性'; 
                    Layout.alignment: Qt.AlignHCenter 
                }
                Label { 
                    text: isValidTour() ? '✓ 有效' : '✗ 无效'
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    color: isValidTour() ? 'green' : 'red'
                }
            }
        }
        
        GroupBox {
            title: '使用提示'
            Layout.fillWidth: true
            Label {
                anchors.fill: parent
                wrapMode: Text.WordWrap
                text: '• 多次运行: Hopfield网络对初始状态敏感，建议多运行几次\n' +
                      '• 推荐配置: A=800, B=800, C=300, D=700 (已优化为默认)\n' +
                      '• 城市数量: 5-8个较易找到最优解，10-15个需多次尝试\n' +
                      '• 判断标准: 绿色路径应无交叉，每个城市访问一次'
                font.pixelSize: 11
            }
        }
    }

    ColumnLayout {
        // TSP路径可视化
        GroupBox {
            title: '旅行路径可视化'
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.minimumHeight: 500
            Layout.preferredHeight: 600
            
            Canvas {
                id: tspCanvas
                anchors.fill: parent
                anchors.margins: 10
                
                property var cities: hopfieldTSPBridge.cities
                property var currentTour: hopfieldTSPBridge.current_tour
                property var bestTour: hopfieldTSPBridge.best_tour
                
                onPaint: {
                    var ctx = getContext("2d")
                    ctx.clearRect(0, 0, width, height)
                    
                    if (!cities || cities.length === 0) {
                        ctx.fillStyle = "#666"
                        ctx.font = "16px Arial"
                        ctx.fillText("点击'生成随机城市'开始", width/2 - 100, height/2)
                        return
                    }
                    
                    // 计算缩放比例
                    var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9
                    for (var i = 0; i < cities.length; i++) {
                        minX = Math.min(minX, cities[i][0])
                        maxX = Math.max(maxX, cities[i][0])
                        minY = Math.min(minY, cities[i][1])
                        maxY = Math.max(maxY, cities[i][1])
                    }
                    
                    var padding = 30
                    var scaleX = (width - 2 * padding) / (maxX - minX || 1)
                    var scaleY = (height - 2 * padding) / (maxY - minY || 1)
                    var scale = Math.min(scaleX, scaleY)
                    
                    function toCanvasX(x) {
                        return padding + (x - minX) * scale
                    }
                    
                    function toCanvasY(y) {
                        return padding + (y - minY) * scale
                    }
                    
                    // 绘制最优路径（如果存在）
                    if (bestTour && bestTour.length === cities.length) {
                        ctx.strokeStyle = "#00AA00"
                        ctx.lineWidth = 3
                        ctx.setLineDash([])
                        ctx.beginPath()
                        for (var i = 0; i < bestTour.length; i++) {
                            var cityIdx = bestTour[i]
                            var x = toCanvasX(cities[cityIdx][0])
                            var y = toCanvasY(cities[cityIdx][1])
                            if (i === 0) ctx.moveTo(x, y)
                            else ctx.lineTo(x, y)
                        }
                        // 回到起点
                        var firstCity = bestTour[0]
                        ctx.lineTo(toCanvasX(cities[firstCity][0]), toCanvasY(cities[firstCity][1]))
                        ctx.stroke()
                    }
                    
                    // 绘制当前路径（虚线）
                    if (currentTour && currentTour.length === cities.length && 
                        JSON.stringify(currentTour) !== JSON.stringify(bestTour)) {
                        ctx.strokeStyle = "#0088FF"
                        ctx.lineWidth = 2
                        ctx.setLineDash([5, 5])
                        ctx.beginPath()
                        for (var i = 0; i < currentTour.length; i++) {
                            var cityIdx = currentTour[i]
                            var x = toCanvasX(cities[cityIdx][0])
                            var y = toCanvasY(cities[cityIdx][1])
                            if (i === 0) ctx.moveTo(x, y)
                            else ctx.lineTo(x, y)
                        }
                        var firstCity = currentTour[0]
                        ctx.lineTo(toCanvasX(cities[firstCity][0]), toCanvasY(cities[firstCity][1]))
                        ctx.stroke()
                    }
                    
                    // 绘制城市点
                    for (var i = 0; i < cities.length; i++) {
                        var x = toCanvasX(cities[i][0])
                        var y = toCanvasY(cities[i][1])
                        
                        // 城市圆点
                        ctx.fillStyle = "#FF0000"
                        ctx.beginPath()
                        ctx.arc(x, y, 6, 0, 2 * Math.PI)
                        ctx.fill()
                        
                        // 城市编号
                        ctx.fillStyle = "#000000"
                        ctx.font = "12px Arial"
                        ctx.fillText(i.toString(), x + 10, y - 10)
                    }
                    
                    // 图例
                    ctx.font = "14px Arial"
                    ctx.fillStyle = "#00AA00"
                    ctx.fillText("━━ 最优路径", 10, height - 40)
                    ctx.fillStyle = "#0088FF"
                    ctx.fillText("- - - 当前路径", 10, height - 20)
                }
                
                Connections {
                    target: hopfieldTSPBridge
                    function onCitiesChanged() { tspCanvas.requestPaint() }
                    function onCurrent_tourChanged() { tspCanvas.requestPaint() }
                    function onBest_tourChanged() { tspCanvas.requestPaint() }
                }
            }
        }
        
        // 能量曲线
        GroupBox {
            title: '能量变化曲线'
            Layout.fillWidth: true
            Layout.preferredHeight: 300
            Layout.minimumHeight: 250
            
            ChartView {
                id: energyChart
                anchors.fill: parent
                antialiasing: true
                legend.visible: false

                ValueAxis { id: ex; min: 0; max: 100 }
                ValueAxis { id: ey; min: 0; max: 1000 }

                LineSeries {
                    id: energySeries
                    axisX: ex
                    axisY: ey
                    color: 'red'
                    width: 2
                }

                function reset() {
                    energySeries.clear()
                    ex.max = 100
                    ey.min = 0
                    ey.max = 1000
                }

                function updateData(history) {
                    energySeries.clear()
                    if (!history || history.length === 0) return
                    var minE = Math.min(...history)
                    var maxE = Math.max(...history)
                    ey.min = Math.max(0, minE * 0.9)
                    ey.max = maxE * 1.1
                    ex.max = Math.max(history.length, 100)
                    for (var i = 0; i < history.length; i++) {
                        energySeries.append(i + 1, history[i])
                    }
                }

                function appendPoint(iteration, energy) {
                    if (!Number.isFinite(energy)) return
                    energySeries.append(iteration, energy)
                    ex.max = Math.max(ex.max, iteration)
                    if (energy < ey.min) ey.min = energy * 0.9
                    if (energy > ey.max) ey.max = energy * 1.1
                }
            }
        }
    }

    Connections {
        target: hopfieldTSPBridge
        function onEnergy_historyChanged() {
            energyChart.updateData(hopfieldTSPBridge.energy_history)
        }
        function onCurrent_iterationChanged() {
            energyChart.appendPoint(hopfieldTSPBridge.current_iteration, hopfieldTSPBridge.current_energy)
        }
    }

    function generateCities() {
        var counts = [5, 8, 10, 15]
        var n = counts[cityCountCombo.currentIndex]
        var cities = []
        for (var i = 0; i < n; i++) {
            var x = Math.random() * 100
            var y = Math.random() * 100
            cities.push([x, y])
        }
        hopfieldTSPBridge.cities = cities
    }

    function isValidTour() {
        var tour = hopfieldTSPBridge.best_tour
        var n = hopfieldTSPBridge.cities.length
        
        if (!tour || tour.length !== n) return false
        
        // 检查是否每个城市恰好访问一次
        var visited = {}
        for (var i = 0; i < tour.length; i++) {
            if (visited[tour[i]]) return false
            visited[tour[i]] = true
        }
        
        return Object.keys(visited).length === n
    }

    Component.onCompleted: {
        generateCities()
    }
}
