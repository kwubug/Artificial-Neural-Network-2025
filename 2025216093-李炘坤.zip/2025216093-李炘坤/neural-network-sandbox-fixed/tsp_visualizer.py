import sys
import numpy as np
import random
import math
import time
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QSplitter, QProgressBar,
                             QComboBox, QCheckBox)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

class TSPAlgorithm:
    """TSP算法基类"""
    
    def __init__(self, cities):
        self.cities = cities
        self.n_cities = len(cities)
        self.best_tour = None
        self.best_distance = float('inf')
        self.distance_history = []
        self.tour_history = []
        
    def calculate_distance(self, city1, city2):
        """计算两个城市之间的距离"""
        return math.sqrt((city1[0] - city2[0])**2 + (city1[1] - city2[1])**2)
    
    def tour_distance(self, tour):
        """计算路径总距离"""
        total_distance = 0
        for i in range(len(tour)):
            total_distance += self.calculate_distance(self.cities[tour[i]], 
                                                     self.cities[tour[(i+1) % len(tour)]])
        return total_distance
    
    def solve(self):
        """求解TSP问题（需要在子类中实现）"""
        raise NotImplementedError

class NearestNeighbor(TSPAlgorithm):
    """最近邻算法"""
    
    def solve(self):
        unvisited = set(range(self.n_cities))
        current_city = random.choice(list(unvisited))
        tour = [current_city]
        unvisited.remove(current_city)
        
        while unvisited:
            nearest_city = min(unvisited, 
                              key=lambda city: self.calculate_distance(
                                  self.cities[current_city], self.cities[city]))
            tour.append(nearest_city)
            unvisited.remove(nearest_city)
            current_city = nearest_city
        
        self.best_tour = tour
        self.best_distance = self.tour_distance(tour)
        return tour

class TwoOpt(TSPAlgorithm):
    """2-opt局部搜索算法"""
    
    def solve(self, initial_tour=None, max_iterations=1000):
        if initial_tour is None:
            # 使用随机初始解
            tour = list(range(self.n_cities))
            random.shuffle(tour)
        else:
            tour = initial_tour.copy()
        
        improved = True
        iterations = 0
        
        while improved and iterations < max_iterations:
            improved = False
            for i in range(1, self.n_cities - 2):
                for j in range(i + 1, self.n_cities):
                    if j - i == 1:
                        continue
                    
                    # 尝试2-opt交换
                    new_tour = tour[:i] + tour[i:j][::-1] + tour[j:]
                    new_distance = self.tour_distance(new_tour)
                    
                    if new_distance < self.tour_distance(tour):
                        tour = new_tour
                        improved = True
                        self.distance_history.append(new_distance)
                        self.tour_history.append(tour.copy())
            
            iterations += 1
        
        self.best_tour = tour
        self.best_distance = self.tour_distance(tour)
        return tour

class SimulatedAnnealing(TSPAlgorithm):
    """模拟退火算法"""
    
    def solve(self, initial_temperature=1000, cooling_rate=0.995, max_iterations=10000):
        # 初始解
        current_tour = list(range(self.n_cities))
        random.shuffle(current_tour)
        current_distance = self.tour_distance(current_tour)
        
        best_tour = current_tour.copy()
        best_distance = current_distance
        
        temperature = initial_temperature
        iterations = 0
        
        while temperature > 1 and iterations < max_iterations:
            # 生成新解（2-opt交换）
            i, j = sorted(random.sample(range(self.n_cities), 2))
            if j - i == 1:
                iterations += 1
                continue
                
            new_tour = current_tour[:i] + current_tour[i:j][::-1] + current_tour[j:]
            new_distance = self.tour_distance(new_tour)
            
            # 计算接受概率
            delta = new_distance - current_distance
            if delta < 0 or random.random() < math.exp(-delta / temperature):
                current_tour = new_tour
                current_distance = new_distance
                
                if current_distance < best_distance:
                    best_tour = current_tour.copy()
                    best_distance = current_distance
            
            self.distance_history.append(current_distance)
            self.tour_history.append(current_tour.copy())
            
            # 降温
            temperature *= cooling_rate
            iterations += 1
        
        self.best_tour = best_tour
        self.best_distance = best_distance
        return best_tour

class GeneticAlgorithm(TSPAlgorithm):
    """遗传算法"""
    
    def solve(self, population_size=50, generations=1000, mutation_rate=0.1):
        # 初始化种群
        population = []
        for _ in range(population_size):
            tour = list(range(self.n_cities))
            random.shuffle(tour)
            population.append(tour)
        
        best_tour = min(population, key=lambda tour: self.tour_distance(tour))
        best_distance = self.tour_distance(best_tour)
        
        for generation in range(generations):
            # 评估适应度
            fitness = [1 / self.tour_distance(tour) for tour in population]
            
            # 选择
            selected = random.choices(population, weights=fitness, k=population_size)
            
            # 交叉（顺序交叉）
            new_population = []
            for i in range(0, population_size, 2):
                parent1, parent2 = selected[i], selected[i+1]
                
                # 顺序交叉
                start, end = sorted(random.sample(range(self.n_cities), 2))
                child1 = [None] * self.n_cities
                child2 = [None] * self.n_cities
                
                # 复制中间段
                child1[start:end] = parent1[start:end]
                child2[start:end] = parent2[start:end]
                
                # 填充剩余城市
                self._fill_child(child1, parent2, start, end)
                self._fill_child(child2, parent1, start, end)
                
                # 变异
                if random.random() < mutation_rate:
                    self._mutate(child1)
                if random.random() < mutation_rate:
                    self._mutate(child2)
                
                new_population.extend([child1, child2])
            
            population = new_population
            
            # 更新最佳解
            current_best_tour = min(population, key=lambda tour: self.tour_distance(tour))
            current_best_distance = self.tour_distance(current_best_tour)
            
            if current_best_distance < best_distance:
                best_tour = current_best_tour.copy()
                best_distance = current_best_distance
            
            self.distance_history.append(best_distance)
            self.tour_history.append(best_tour.copy())
        
        self.best_tour = best_tour
        self.best_distance = best_distance
        return best_tour
    
    def _fill_child(self, child, parent, start, end):
        """填充子代剩余城市"""
        parent_index = 0
        for i in range(self.n_cities):
            if child[i] is None:
                while parent[parent_index] in child:
                    parent_index += 1
                child[i] = parent[parent_index]
    
    def _mutate(self, tour):
        """变异操作（交换两个城市）"""
        i, j = random.sample(range(self.n_cities), 2)
        tour[i], tour[j] = tour[j], tour[i]

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class TSPVisualizer(QMainWindow):
    """TSP算法PyQt可视化器"""
    
    def __init__(self):
        super().__init__()
        self.cities = []
        self.algorithm = None
        self.running = False
        self.current_step = 0
        self.total_steps = 1000
        self.timer = QTimer()
        self.timer.timeout.connect(self.solve_step)
        
        self.init_ui()
        self.generate_cities()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("TSP旅行商问题可视化")
        self.setGeometry(100, 100, 1400, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 3)
        
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """创建控制面板"""
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)
        
        # 标题
        title_label = QLabel("TSP算法控制台")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # 参数设置
        params_group = QGroupBox("参数设置")
        params_layout = QVBoxLayout(params_group)
        
        # 城市数量
        cities_layout = QHBoxLayout()
        cities_label = QLabel("城市数量:")
        self.cities_input = QLineEdit("20")
        cities_layout.addWidget(cities_label)
        cities_layout.addWidget(self.cities_input)
        params_layout.addLayout(cities_layout)
        
        # 算法选择
        algorithm_layout = QHBoxLayout()
        algorithm_label = QLabel("算法选择:")
        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["最近邻", "2-opt", "模拟退火", "遗传算法"])
        algorithm_layout.addWidget(algorithm_label)
        algorithm_layout.addLayout(algorithm_layout)
        algorithm_layout.addWidget(self.algorithm_combo)
        params_layout.addLayout(algorithm_layout)
        
        # 迭代次数
        iterations_layout = QHBoxLayout()
        iterations_label = QLabel("迭代次数:")
        self.iterations_input = QLineEdit("1000")
        iterations_layout.addWidget(iterations_label)
        iterations_layout.addWidget(self.iterations_input)
        params_layout.addLayout(iterations_layout)
        
        # 实时更新
        self.realtime_checkbox = QCheckBox("实时更新可视化")
        self.realtime_checkbox.setChecked(True)
        params_layout.addWidget(self.realtime_checkbox)
        
        control_layout.addWidget(params_group)
        
        # 控制按钮
        buttons_group = QGroupBox("求解控制")
        buttons_layout = QVBoxLayout(buttons_group)
        
        self.start_button = QPushButton("开始求解")
        self.start_button.clicked.connect(self.start_solving)
        buttons_layout.addWidget(self.start_button)
        
        self.pause_button = QPushButton("暂停求解")
        self.pause_button.clicked.connect(self.pause_solving)
        self.pause_button.setEnabled(False)
        buttons_layout.addWidget(self.pause_button)
        
        self.reset_button = QPushButton("重置问题")
        self.reset_button.clicked.connect(self.reset_problem)
        buttons_layout.addWidget(self.reset_button)
        
        control_layout.addWidget(buttons_group)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        control_layout.addWidget(self.progress_bar)
        
        # 求解信息
        info_group = QGroupBox("求解信息")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(150)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 路径可视化标签页
        tour_tab = QWidget()
        tour_layout = QVBoxLayout(tour_tab)
        self.tour_canvas = MplCanvas(self, width=8, height=6)
        tour_layout.addWidget(self.tour_canvas)
        visualization_widget.addTab(tour_tab, "路径可视化")
        
        # 距离收敛标签页
        distance_tab = QWidget()
        distance_layout = QVBoxLayout(distance_tab)
        self.distance_canvas = MplCanvas(self, width=8, height=4)
        distance_layout.addWidget(self.distance_canvas)
        visualization_widget.addTab(distance_tab, "距离收敛")
        
        # 算法比较标签页
        comparison_tab = QWidget()
        comparison_layout = QVBoxLayout(comparison_tab)
        self.comparison_canvas = MplCanvas(self, width=8, height=4)
        comparison_layout.addWidget(self.comparison_canvas)
        visualization_widget.addTab(comparison_tab, "算法比较")
        
        return visualization_widget
    
    def generate_cities(self):
        """生成随机城市坐标"""
        n_cities = int(self.cities_input.text())
        self.cities = []
        for _ in range(n_cities):
            x = random.uniform(0, 100)
            y = random.uniform(0, 100)
            self.cities.append((x, y))
        
        # 绘制初始城市分布
        self.plot_cities()
        self.info_text.append(f"生成了 {n_cities} 个随机城市")
    
    def reset_problem(self):
        """重置问题"""
        self.running = False
        self.timer.stop()
        self.current_step = 0
        self.progress_bar.setValue(0)
        self.algorithm = None
        self.generate_cities()
        self.info_text.clear()
        self.info_text.append("问题已重置，准备开始求解...")
    
    def start_solving(self):
        """开始求解"""
        if not self.running:
            self.total_steps = int(self.iterations_input.text())
            algorithm_name = self.algorithm_combo.currentText()
            
            # 根据选择的算法创建实例
            if algorithm_name == "最近邻":
                self.algorithm = NearestNeighbor(self.cities)
            elif algorithm_name == "2-opt":
                self.algorithm = TwoOpt(self.cities)
            elif algorithm_name == "模拟退火":
                self.algorithm = SimulatedAnnealing(self.cities)
            elif algorithm_name == "遗传算法":
                self.algorithm = GeneticAlgorithm(self.cities)
            
            self.running = True
            self.start_button.setEnabled(False)
            self.pause_button.setEnabled(True)
            self.timer.start(50)  # 每50ms求解一步
            self.info_text.append(f"开始使用 {algorithm_name} 算法求解...")
    
    def pause_solving(self):
        """暂停求解"""
        if self.running:
            self.running = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("求解暂停...")
    
    def solve_step(self):
        """求解一步"""
        if self.current_step >= self.total_steps or self.algorithm is None:
            self.running = False
            self.timer.stop()
            self.start_button.setEnabled(True)
            self.pause_button.setEnabled(False)
            self.info_text.append("求解完成!")
            return
        
        # 执行一步求解
        if isinstance(self.algorithm, NearestNeighbor):
            # 最近邻算法一次性完成
            self.algorithm.solve()
            self.current_step = self.total_steps
        elif isinstance(self.algorithm, TwoOpt):
            if self.current_step == 0:
                # 先生成一个初始解
                initial_tour = list(range(len(self.cities)))
                random.shuffle(initial_tour)
                self.algorithm.solve(initial_tour, max_iterations=1)
            else:
                self.algorithm.solve(self.algorithm.best_tour, max_iterations=1)
        elif isinstance(self.algorithm, SimulatedAnnealing):
            if self.current_step == 0:
                self.algorithm.solve(max_iterations=1)
            else:
                self.algorithm.solve(max_iterations=1)
        elif isinstance(self.algorithm, GeneticAlgorithm):
            if self.current_step == 0:
                self.algorithm.solve(generations=1)
            else:
                self.algorithm.solve(generations=1)
        
        self.current_step += 1
        progress = int((self.current_step / self.total_steps) * 100)
        self.progress_bar.setValue(progress)
        
        # 更新信息显示
        if self.current_step % 10 == 0 or self.current_step == self.total_steps:
            best_distance = self.algorithm.best_distance if self.algorithm.best_tour else float('inf')
            self.info_text.append(f"迭代: {self.current_step}, 最佳距离: {best_distance:.2f}")
        
        # 更新可视化
        if self.realtime_checkbox.isChecked():
            self.update_plots()
    
    def plot_cities(self):
        """绘制城市分布"""
        self.tour_canvas.fig.clear()
        ax = self.tour_canvas.fig.add_subplot(111)
        
        if self.cities:
            cities_array = np.array(self.cities)
            ax.scatter(cities_array[:, 0], cities_array[:, 1], c='red', s=50, alpha=0.7)
            ax.set_title('城市分布', fontsize=12, color='white')
            ax.set_xlabel('X坐标', color='white')
            ax.set_ylabel('Y坐标', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.tour_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.tour_canvas.draw()
    
    def update_plots(self):
        """更新所有图表"""
        self.plot_tour()
        self.plot_distance_convergence()
        self.tour_canvas.draw()
        self.distance_canvas.draw()
    
    def plot_tour(self):
        """绘制当前路径"""
        self.tour_canvas.fig.clear()
        ax = self.tour_canvas.fig.add_subplot(111)
        
        if self.cities and self.algorithm and self.algorithm.best_tour:
            cities_array = np.array(self.cities)
            tour = self.algorithm.best_tour
            
            # 绘制城市点
            ax.scatter(cities_array[:, 0], cities_array[:, 1], c='red', s=50, alpha=0.7)
            
            # 绘制路径
            tour_cities = cities_array[tour + [tour[0]]]  # 添加回到起点的路径
            ax.plot(tour_cities[:, 0], tour_cities[:, 1], 'b-', alpha=0.7, linewidth=1)
            
            # 标记起点
            ax.scatter(cities_array[tour[0], 0], cities_array[tour[0], 1], 
                      c='green', s=100, marker='*', edgecolors='black')
            
            distance = self.algorithm.best_distance
            ax.set_title(f'当前路径 (距离: {distance:.2f})', fontsize=12, color='white')
            ax.set_xlabel('X坐标', color='white')
            ax.set_ylabel('Y坐标', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.tour_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.tour_canvas.draw()
    
    def plot_distance_convergence(self):
        """绘制距离收敛曲线"""
        self.distance_canvas.fig.clear()
        ax = self.distance_canvas.fig.add_subplot(111)
        
        if self.algorithm and self.algorithm.distance_history:
            ax.plot(range(len(self.algorithm.distance_history)), 
                   self.algorithm.distance_history, 'b-', linewidth=2)
            ax.set_title('距离收敛曲线', fontsize=12, color='white')
            ax.set_xlabel('迭代次数', color='white')
            ax.set_ylabel('路径距离', color='white')
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#2b2b2b')
            self.distance_canvas.fig.patch.set_facecolor('#2b2b2b')
            ax.tick_params(colors='white')
        
        self.distance_canvas.draw()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = TSPVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()