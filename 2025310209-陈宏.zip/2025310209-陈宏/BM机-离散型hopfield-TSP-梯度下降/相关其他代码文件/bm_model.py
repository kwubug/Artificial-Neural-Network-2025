import numpy as np
import random
from PyQt5.QtCore import QObject, pyqtSignal, pyqtProperty, QTimer
class BoltzmannMachine(QObject):
    stateChanged = pyqtSignal()
    temperatureChanged = pyqtSignal()
    energyChanged = pyqtSignal()
    iterationChanged = pyqtSignal()
    equilibriumReached = pyqtSignal(float)  # 热平衡信号，传递最终能量值

    def __init__(self, num_neurons=3):
        super().__init__()
        self._num_neurons = num_neurons
        self._neurons = np.random.choice([-1, 1], size=num_neurons)

        # 设置固定的权重矩阵，便于观察
        self._weights = np.array([
            [0, 0.5, -0.3],
            [0.5, 0, 0.2],
            [-0.3, 0.2, 0]
        ])

        # 训练参数
        self._temperature = 5.0  # 初始温度稍高，便于观察退火过程
        self._min_temperature = 0.01
        self._cooling_rate = 0.95
        self._iteration = 0
        self._is_running = False
        self._energy_history = []
        self._equilibrium_reached = False

        # 设置定时器用于模拟
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_state)
        self.timer.setInterval(300)  # 300ms间隔，便于观察

    @pyqtProperty(list, notify=stateChanged)
    def neurons(self):
        return self._neurons.tolist()

    @pyqtProperty(float, notify=temperatureChanged)
    def temperature(self):
        return self._temperature

    @pyqtProperty(float, notify=energyChanged)
    def energy(self):
        return self.calculate_energy()

    @pyqtProperty(int, notify=iterationChanged)
    def iteration(self):
        return self._iteration

    @pyqtProperty(list, notify=energyChanged)
    def energyHistory(self):
        return self._energy_history[-50:]  # 返回最近50个能量值

    @pyqtProperty(bool)
    def isRunning(self):
        return self._is_running

    @pyqtProperty(bool)
    def equilibriumReached(self):
        return self._equilibrium_reached

    def calculate_energy(self):
        """计算系统的能量"""
        energy = 0
        for i in range(self._num_neurons):
            for j in range(i + 1, self._num_neurons):  # 避免重复计算
                energy -= self._weights[i, j] * self._neurons[i] * self._neurons[j]
        return energy
    def update_state(self):
        """更新神经元状态（一次迭代）"""
        if not self._is_running or self._equilibrium_reached:
            return
        neuron_idx = random.randint(0, self._num_neurons - 1)
        # 计算该神经元的输入总和
        input_sum = 0
        for j in range(self._num_neurons):
            if j != neuron_idx:
                input_sum += self._weights[neuron_idx, j] * self._neurons[j]

        # 计算概率（使用玻尔兹曼分布）
        delta_energy = 2 * input_sum * self._neurons[neuron_idx]
        prob = 1 / (1 + np.exp(-delta_energy / max(self._temperature, 0.001)))

        # 根据概率决定是否翻转状态
        if random.random() < prob:
            self._neurons[neuron_idx] *= -1  # 翻转状态
            self.stateChanged.emit()

        # 计算当前能量并记录历史
        current_energy = self.calculate_energy()
        self._energy_history.append(current_energy)
        self.energyChanged.emit()

        # 降低温度（模拟退火）
        if self._temperature > self._min_temperature:
            old_temp = self._temperature
            self._temperature *= self._cooling_rate
            if abs(old_temp - self._temperature) > 0.001:
                self.temperatureChanged.emit()

        self._iteration += 1
        self.iterationChanged.emit()

        # 检查是否达到热平衡（能量稳定）
        if len(self._energy_history) > 20:
            recent_energies = self._energy_history[-20:]
            energy_std = np.std(recent_energies)

            if energy_std < 0.01 and self._temperature < 0.1:
                self._equilibrium_reached = True
                self.stop_simulation()
                self.equilibriumReached.emit(current_energy)
                print(f"🎯 达到热平衡状态！")
                print(f"   迭代次数: {self._iteration}")
                print(f"   最终温度: {self._temperature:.4f}")
                print(f"   最终能量: {current_energy:.4f}")
                print(f"   神经元状态: {self._neurons}")
                print(f"   能量标准差: {energy_std:.6f}")

    def start_simulation(self):
        """开始模拟"""
        self._is_running = True
        self._equilibrium_reached = False
        self.timer.start()
        print("🚀 开始玻尔兹曼机模拟...")

    def stop_simulation(self):
        """停止模拟"""
        self._is_running = False
        self.timer.stop()

    def reset_simulation(self):
        """重置模拟"""
        self.stop_simulation()
        self._neurons = np.random.choice([-1, 1], size=self._num_neurons)
        self._temperature = 5.0
        self._iteration = 0
        self._energy_history = []
        self._equilibrium_reached = False

        self.stateChanged.emit()
        self.temperatureChanged.emit()
        self.energyChanged.emit()
        self.iterationChanged.emit()
        print("🔄 系统已重置")

    def get_weights_matrix(self):
        """获取权重矩阵（用于显示）"""
        return self._weights.tolist()

    def get_network_info(self):
        """获取网络信息"""
        return {
            'weights': self._weights.tolist(),
            'current_state': self._neurons.tolist(),
            'current_energy': self.calculate_energy(),
            'temperature': self._temperature
        }