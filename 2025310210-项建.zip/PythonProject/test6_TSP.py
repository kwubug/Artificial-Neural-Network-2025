import numpy as np
import matplotlib.pyplot as plt
import random
from math import exp, sqrt


class HopfieldTSP:
    def __init__(self, cities, A=500, B=500, C=200, D=500, T=0.5, max_iterations=1000):
        """
        初始化Hopfield网络求解TSP问题

        参数:
        cities: 城市坐标列表
        A, B, C, D: 能量函数权重参数
        T: 初始温度(用于模拟退火)
        max_iterations: 最大迭代次数
        """
        self.cities = cities
        self.n = len(cities)  # 城市数量
        self.A = A
        self.B = B
        self.C = C
        self.D = D
        self.T = T
        self.max_iterations = max_iterations

        # 初始化神经元状态矩阵 (n x n)
        self.V = np.random.rand(self.n, self.n) * 0.2 + 0.1

        # 计算城市间距离矩阵
        self.distances = self.calculate_distances()

        # 存储能量历史
        self.energy_history = []

    def calculate_distances(self):
        """计算城市间距离矩阵"""
        distances = np.zeros((self.n, self.n))
        for i in range(self.n):
            for j in range(self.n):
                if i != j:
                    dx = self.cities[i][0] - self.cities[j][0]
                    dy = self.cities[i][1] - self.cities[j][1]
                    distances[i][j] = sqrt(dx * dx + dy * dy)
        return distances

    def calculate_energy(self):
        """计算Hopfield网络的能量函数值"""
        # 约束项1: 每行只有一个1
        term1 = 0
        for x in range(self.n):
            sum_row = np.sum(self.V[x, :])
            term1 += (sum_row - 1) ** 2

        # 约束项2: 每列只有一个1
        term2 = 0
        for i in range(self.n):
            sum_col = np.sum(self.V[:, i])
            term2 += (sum_col - 1) ** 2

        # 约束项3: 矩阵中恰好有n个1
        term3 = (np.sum(self.V) - self.n) ** 2

        # 目标项: 最小化总路径长度
        term4 = 0
        for x in range(self.n):
            for y in range(self.n):
                if x != y:
                    for i in range(self.n):
                        j = (i + 1) % self.n
                        term4 += self.distances[x][y] * self.V[x][i] * self.V[y][j]

        energy = (self.A / 2) * term1 + (self.B / 2) * term2 + (self.C / 2) * term3 + (self.D / 2) * term4
        return energy

    def update_neuron(self, x, i):
        """更新单个神经元的状态"""
        # 计算输入总和
        input_sum = 0

        # 行约束项
        for j in range(self.n):
            if j != i:
                input_sum -= self.A * self.V[x][j]

        # 列约束项
        for y in range(self.n):
            if y != x:
                input_sum -= self.B * self.V[y][i]

        # 全局约束项
        input_sum -= self.C * (np.sum(self.V) - self.n)

        # 路径长度项
        for y in range(self.n):
            if y != x:
                j1 = (i - 1) % self.n
                j2 = (i + 1) % self.n
                input_sum -= self.D * self.distances[x][y] * (self.V[y][j1] + self.V[y][j2])

        # 使用sigmoid激活函数，添加数值稳定性处理
        try:
            exponent = -input_sum / self.T
            # 限制指数范围，避免溢出
            if exponent > 700:  # exp(709) 是Python能处理的最大值
                exponent = 700
            elif exponent < -700:
                exponent = -700

            new_value = 1 / (1 + exp(exponent))
            return new_value
        except OverflowError:
            # 如果仍然溢出，返回边界值
            if input_sum > 0:
                return 0.0
            else:
                return 1.0

    def solve(self):
        """使用Hopfield网络求解TSP问题"""
        print("开始Hopfield网络求解TSP问题...")

        for iteration in range(self.max_iterations):
            # 随机选择一个神经元进行更新
            x = random.randint(0, self.n - 1)
            i = random.randint(0, self.n - 1)

            # 更新神经元状态
            self.V[x][i] = self.update_neuron(x, i)

            # 计算当前能量
            energy = self.calculate_energy()
            self.energy_history.append(energy)

            # 逐渐降低温度(模拟退火)
            self.T = max(0.01, self.T * 0.995)

            # 每100次迭代打印进度
            if iteration % 100 == 0:
                print(f"迭代 {iteration}, 能量: {energy:.4f}, 温度: {self.T:.4f}")

            # 检查是否收敛
            if iteration > 100 and abs(self.energy_history[-1] - self.energy_history[-2]) < 1e-6:
                print(f"在 {iteration} 次迭代后收敛")
                break

        # 将连续值转换为离散解
        solution = self.get_route_from_matrix()
        return solution

    def get_route_from_matrix(self):
        """从神经元状态矩阵中提取路径"""
        route = []
        used = set()  # 跟踪已经访问过的城市

        # 找到每列中值最大的行索引
        for i in range(self.n):
            max_val = -1
            city_idx = -1
            for x in range(self.n):
                if self.V[x][i] > max_val and x not in used:
                    max_val = self.V[x][i]
                    city_idx = x
            route.append(city_idx)
            used.add(city_idx)  # 标记城市已被访问

        return route

    def calculate_route_distance(self, route):
        """计算给定路径的总距离"""
        total_distance = 0
        for i in range(self.n):
            from_city = route[i]
            to_city = route[(i + 1) % self.n]
            total_distance += self.distances[from_city][to_city]
        return total_distance


def create_cities(n, width=800, height=600):
    """创建随机城市坐标"""
    cities = []
    for i in range(n):
        x = random.randint(50, width - 50)
        y = random.randint(50, height - 50)
        cities.append((x, y))
    return cities


def visualize_solution(cities, solution, energy_history, iteration=None):
    """可视化TSP解决方案"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    # 绘制路径
    ax1.set_title(f'TSP Solution - Hopfield Network')
    ax1.set_xlabel('X Coordinate')
    ax1.set_ylabel('Y Coordinate')

    # 绘制城市点
    x_coords = [city[0] for city in cities]
    y_coords = [city[1] for city in cities]
    ax1.scatter(x_coords, y_coords, c='red', s=100)

    # 标记城市编号
    for i, (x, y) in enumerate(cities):
        ax1.annotate(str(i), (x, y), xytext=(5, 5), textcoords='offset points')

    # 绘制路径
    route_x = [cities[i][0] for i in solution]
    route_y = [cities[i][1] for i in solution]
    route_x.append(cities[solution[0]][0])
    route_y.append(cities[solution[0]][1])

    ax1.plot(route_x, route_y, 'b-', linewidth=2, alpha=0.7)
    ax1.scatter(route_x, route_y, c='blue', s=50)

    # 绘制能量变化
    ax2.plot(energy_history, 'g-')
    ax2.set_title('Energy Convergence')
    ax2.set_xlabel('Iteration')
    ax2.set_ylabel('Energy')
    ax2.grid(True)

    plt.tight_layout()
    plt.show()


def main():
    # 设置随机种子以便结果可重现
    random.seed(42)
    np.random.seed(42)

    # 创建城市
    n_cities = 10
    cities = create_cities(n_cities)

    print("城市坐标:")
    for i, (x, y) in enumerate(cities):
        print(f"城市 {i}: ({x}, {y})")

    # 使用Hopfield网络求解TSP
    hopfield_tsp = HopfieldTSP(
        cities,
        A=500,  # 减小行约束权重
        B=500,  # 减小列约束权重
        C=200,  # 减小全局约束权重
        D=300,  # 减小路径长度权重
        T=2.0,  # 增加初始温度
        max_iterations=5000
    )

    solution = hopfield_tsp.solve()
    distance = hopfield_tsp.calculate_route_distance(solution)

    print(f"\n最优路径: {solution}")
    print(f"路径总距离: {distance:.2f}")

    # 可视化结果
    visualize_solution(cities, solution, hopfield_tsp.energy_history)


if __name__ == "__main__":
    main()
