"""Layouts for BP Neural Network Visualization"""
from dash import html, dcc


def entry_layout() -> html.Div:
    """Layout for configuration"""
    return [
        html.H3("BP神经网络训练可视化配置"),
        
        html.H5("优化算法"),
        dcc.Dropdown(
            [
                {"label": "梯度下降法 (Gradient Descent)", "value": "gradient_descent"},
                {"label": "牛顿法 (Newton Method)", "value": "newton"},
                {"label": "共轭梯度法 (Conjugate Gradient)", "value": "conjugate_gradient"},
            ],
            value="gradient_descent",
            id="drop_down_optimizer",
        ),
        
        html.H5("学习率 (Learning Rate)"),
        dcc.Dropdown(
            [
                "0.01",
                "0.05",
                "0.1",
                "0.2",
                "0.5",
                "1.0",
            ],
            value="0.1",
            id="drop_down_lr",
        ),
        
        html.H5("隐藏层神经元数量"),
        dcc.Slider(
            id="slider_hidden",
            min=2,
            max=10,
            step=1,
            value=4,
            marks={i: str(i) for i in range(2, 11)},
            tooltip={"placement": "bottom", "always_visible": True},
        ),
        
        html.H5("数据集类型"),
        dcc.Dropdown(
            [
                {"label": "二分类数据 (Linear Separable)", "value": "classification"},
                {"label": "XOR数据 (Non-linear)", "value": "xor"},
            ],
            value="classification",
            id="drop_down_dataset",
        ),
        
        html.Hr(),
        
        dcc.Markdown(
            """
            ### 使用说明
            
            这是一个BP神经网络训练过程的可视化工具，支持三种优化算法：
            
            - **梯度下降法**: 标准的BP反向传播算法，沿负梯度方向更新权重
            - **牛顿法**: 使用二阶导数信息（Hessian矩阵近似）加速收敛
            - **共轭梯度法**: 使用共轭方向搜索，避免zigzag现象
            
            **参数说明：**
            - 学习率越大，训练速度越快，但可能不稳定
            - 隐藏层神经元数量影响网络的表达能力
            - 二分类数据是线性可分的，XOR数据需要非线性分类
            
            点击"开始训练"按钮查看训练过程动画！
            """
        ),
        
        html.A(
            "基于 bp_algorithm.py 实现",
            href="#",
            style={
                "position": "fixed",
                "bottom": "10px",
                "left": "50%",
                "transform": "translateX(-50%)",
            },
        ),
    ]


def viz_layout() -> html.Div:
    """Layout for visualization"""
    return [
        # 自动训练定时器 (每1秒触发，执行50次迭代)
        dcc.Interval(
            id='training-interval',
            interval=1000,  # 1秒
            n_intervals=0,
            disabled=True  # 默认禁用
        ),
        
        html.Div([
            html.H4("训练控制", style={"display": "inline-block", "margin-right": "20px"}),
            
            html.Button(
                "开始训练", 
                id="sim-button", 
                n_clicks=0,
                style={
                    "display": "inline-block",
                    "background-color": "#4CAF50",
                    "color": "white",
                    "padding": "10px 20px",
                    "border": "none",
                    "border-radius": "4px",
                    "cursor": "pointer",
                    "font-weight": "bold",
                }
            ),
            
            html.Button(
                "重置", 
                id="reset-button", 
                n_clicks=0,
                style={
                    "display": "inline-block",
                    "background-color": "#f44336",
                    "color": "white",
                    "padding": "10px 20px",
                    "border": "none",
                    "border-radius": "4px",
                    "cursor": "pointer",
                    "margin-left": "10px",
                }
            ),
        ]),
        
        html.Hr(),
        
        # 训练信息展示
        html.Div(id="training-info", style={
            "padding": "15px",
            "background-color": "#f0f0f0",
            "border-radius": "5px",
            "margin-bottom": "20px",
            "font-size": "16px",
        }),
        
        # 图表区域
        html.Div([
            # 第一行：数据分布和决策边界
            html.Div([
                html.Div(
                    dcc.Graph(id="data-scatter"),
                    style={"display": "inline-block", "width": "50%"},
                ),
                html.Div(
                    dcc.Graph(id="decision-boundary"),
                    style={"display": "inline-block", "width": "50%"},
                ),
            ]),
            
            # 第二行：损失曲线和损失地形图
            html.Div([
                html.Div(
                    dcc.Graph(id="loss-curve"),
                    style={"display": "inline-block", "width": "50%"},
                ),
                html.Div(
                    dcc.Graph(id="weight-trajectory"),
                    style={"display": "inline-block", "width": "50%"},
                ),
            ]),
        ]),
    ]
