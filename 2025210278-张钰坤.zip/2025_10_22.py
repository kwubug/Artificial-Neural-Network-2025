# som_train_and_visualize.py
# -*- coding: utf-8 -*-
"""
Train a 5x5 SOM on 5 four-dimensional patterns with the exact schedules
specified in the prompt. Save snapshots every 200 steps and visualize
final mapping of the 5 inputs on the output plane.

Charts: use matplotlib only, one chart per figure, no explicit colors.
All exported filenames are in English.
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Tuple, List

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

GRID_H, GRID_W = 5, 5
INPUT_DIM = 4
TOTAL_STEPS = 10_000
SNAPSHOT_EVERY = 200
SEED = 7  # reproducibility

# Five 4D patterns from the image
patterns = np.array(
    [
        [1, 0, 0, 0],  # X1
        [1, 1, 0, 0],  # X2
        [1, 1, 1, 0],  # X3
        [0, 1, 0, 0],  # X4
        [1, 1, 1, 1],  # X5
    ],
    dtype=np.float64,
)

@dataclass
class SOM:
    height: int
    width: int
    dim: int
    rng: np.random.Generator

    def __post_init__(self) -> None:
        self.weights = self.rng.random((self.height, self.width, self.dim))
        ys, xs = np.meshgrid(np.arange(self.height), np.arange(self.width), indexing="ij")
        self.coords = np.stack([ys, xs], axis=-1)  # (H, W, 2)

    @staticmethod
    def _linear(a: float, b: float, t: float, t0: float, t1: float) -> float:
        if t <= t0: return a
        if t >= t1: return b
        r = (t - t0) / float(t1 - t0)
        return (1 - r) * a + r * b

    def learning_rate(self, t: int) -> float:
        # Why: exact schedule per problem statement
        if t < 1000: return self._linear(0.5, 0.04, t, 0, 999)
        return self._linear(0.04, 0.0, t, 1000, TOTAL_STEPS - 1)

    def sigma(self, t: int) -> float:
        # Why: neighborhood shrinks to BMU-only after 1000 steps
        if t < 1000: return self._linear(2.0, 0.0, t, 0, 999)
        return 0.0

    def bmu(self, x: np.ndarray) -> Tuple[int, int]:
        d = np.linalg.norm(self.weights - x[None, None, :], axis=-1)
        idx = np.unravel_index(np.argmin(d), d.shape)
        return int(idx[0]), int(idx[1])

    def step(self, x: np.ndarray, t: int) -> None:
        lr = self.learning_rate(t)
        sig = self.sigma(t)
        by, bx = self.bmu(x)

        if sig <= 0.0 or lr <= 0.0:
            self.weights[by, bx, :] += lr * (x - self.weights[by, bx, :])
            return

        d2 = np.sum((self.coords - np.array([by, bx])) ** 2, axis=-1)
        h = np.exp(-d2 / (2.0 * (sig ** 2)))  # Gaussian neighborhood
        self.weights += lr * h[..., None] * (x[None, None, :] - self.weights)

    def quantization_error(self, inputs: np.ndarray) -> float:
        d = []
        for x in inputs:
            y, xj = self.bmu(x)
            d.append(np.linalg.norm(self.weights[y, xj, :] - x))
        return float(np.mean(d))

def train_and_export(output_dir: str = "./out") -> None:
    os.makedirs(output_dir, exist_ok=True)
    rng = np.random.default_rng(SEED)
    som = SOM(GRID_H, GRID_W, INPUT_DIM, rng)

    snapshot_steps: List[int] = [0]
    snapshots: List[np.ndarray] = [som.weights.copy()]
    qe_history: List[float] = [som.quantization_error(patterns)]

    for t in range(TOTAL_STEPS):
        x = patterns[t % len(patterns)]
        som.step(x, t)
        qe_history.append(som.quantization_error(patterns))
        if (t + 1) % SNAPSHOT_EVERY == 0:
            snapshot_steps.append(t + 1)
            snapshots.append(som.weights.copy())

    np.savez(
        os.path.join(output_dir, "som_snapshots.npz"),
        weights=np.stack(snapshots, axis=0),
        steps=np.array(snapshot_steps, dtype=np.int32),
    )

    # Learning rate plot
    lrs = [som.learning_rate(t) for t in range(TOTAL_STEPS)]
    plt.figure(); plt.plot(np.arange(TOTAL_STEPS), lrs)
    plt.title("Learning Rate Schedule"); plt.xlabel("Training Step"); plt.ylabel("Learning Rate")
    plt.tight_layout(); plt.savefig(os.path.join(output_dir, "som_lr.png"), dpi=160); plt.close()

    # Radius plot
    sigs = [som.sigma(t) for t in range(TOTAL_STEPS)]
    plt.figure(); plt.plot(np.arange(TOTAL_STEPS), sigs)
    plt.title("Neighborhood Radius (sigma)"); plt.xlabel("Training Step"); plt.ylabel("Sigma (nodes)")
    plt.tight_layout(); plt.savefig(os.path.join(output_dir, "som_radius.png"), dpi=160); plt.close()

    # QE plot
    plt.figure(); plt.plot(np.arange(len(qe_history)), qe_history)
    plt.title("Quantization Error"); plt.xlabel("Training Step"); plt.ylabel("Mean BMU Distance")
    plt.tight_layout(); plt.savefig(os.path.join(output_dir, "som_qe.png"), dpi=160); plt.close()

    # Final mapping
    yy, xx = np.meshgrid(np.arange(GRID_H), np.arange(GRID_W), indexing="ij")
    plt.figure()
    plt.scatter(xx.flatten(), yy.flatten(), s=30, alpha=0.5)
    final_bmus = []
    for i, x in enumerate(patterns, start=1):
        by, bx = som.bmu(x); final_bmus.append((f"X{i}", by, bx))
        plt.scatter([bx], [by], s=80)
        plt.text(bx + 0.1, by + 0.1, f"X{i}", fontsize=10)
    plt.gca().invert_yaxis()
    plt.title("Final Mapping of 5 Inputs on 5x5 SOM Grid")
    plt.xlabel("X (column index)"); plt.ylabel("Y (row index)")
    plt.xticks(range(GRID_W)); plt.yticks(range(GRID_H))
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.5)
    plt.tight_layout(); plt.savefig(os.path.join(output_dir, "som_final_mapping.png"), dpi=160); plt.close()

    # BMU CSV
    pd.DataFrame(final_bmus, columns=["pattern", "row", "col"]) \
      .to_csv(os.path.join(output_dir, "som_final_bmu.csv"), index=False)

if __name__ == "__main__":
    train_and_export(output_dir="./out")
