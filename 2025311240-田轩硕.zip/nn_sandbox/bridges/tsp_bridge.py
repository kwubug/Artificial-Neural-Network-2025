import time
import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import TSPAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class TspBridge(Bridge):
    # 算法参数
    population_size = BridgeProperty(100)
    generations = BridgeProperty(500)
    mutation_rate = BridgeProperty(1.0)  # 存储百分比值(1.0表示1%)
    elite_size = BridgeProperty(20)
    num_cities = BridgeProperty(20)
    
    # 运行时状态
    current_generation = BridgeProperty(0)
    current_best_distance = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    
    # 可视化数据
    cities = BridgeProperty([])
    best_route = BridgeProperty([])
    best_distance_history = BridgeProperty([])
    avg_distance_history = BridgeProperty([])
    
    # UI刷新间隔
    ui_refresh_interval = BridgeProperty(0.05)
    
    def __init__(self):
        super().__init__()
        self.tsp_algorithm = None
        self._generate_random_cities()
        
    def _generate_random_cities(self):
        """生成随机城市坐标"""
        np.random.seed(int(time.time()))
        cities = np.random.rand(self.num_cities, 2) * 100
        self.cities = cities.tolist()
    
    @PyQt5.QtCore.pyqtSlot()
    def generate_cities(self):
        """重新生成城市"""
        self._generate_random_cities()
    
    @PyQt5.QtCore.pyqtSlot()
    def start_tsp_algorithm(self):
        """启动TSP算法"""
        self.tsp_algorithm = ObservableTSPAlgorithm(
            self,
            self.ui_refresh_interval,
            cities=self.cities,
            population_size=self.population_size,
            generations=self.generations,
            mutation_rate=self.mutation_rate / 100.0,  # 前端以百分比形式输入
            elite_size=self.elite_size
        )
        self.tsp_algorithm.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp_algorithm(self):
        """停止TSP算法"""
        if self.tsp_algorithm:
            self.tsp_algorithm.stop()


class ObservableTSPAlgorithm(Observable, TSPAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        TSPAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 只通知基本属性的变化
        if name == 'current_generation' and hasattr(self, '_observer'):
            self.notify(name, value)
    
    def run(self):
        """运行遗传算法并通知UI更新"""
        try:
            self.notify('has_finished', False)
            self.notify('best_distance_history', [])
            self.notify('avg_distance_history', [])
            self.notify('current_generation', 0)
            self.notify('current_best_distance', 0.0)
            self.notify('best_route', [])
            
            # 检查城市数量
            if len(self.cities) < 2:
                print("Error: Need at least 2 cities")
                self.notify('has_finished', True)
                return
                
            # 初始化种群
            self._initialize_population()
            
            # 运行遗传算法
            for self.current_generation in range(self.generations):
                if self._should_stop:
                    break
                    
                # 评估适应度
                fitness_scores = self._evaluate_fitness()
                
                # 记录最佳路径
                best_idx = np.argmax(fitness_scores)
                best_route = self.population[best_idx]
                best_distance = self._calculate_route_distance(best_route)
                
                if best_distance < self.current_best_distance:
                    self.current_best_distance = best_distance
                    self.current_best_route = best_route.copy()
                
                self.best_distance_history.append(self.current_best_distance)
                self.avg_distance_history.append(
                    np.mean([self._calculate_route_distance(route) for route in self.population])
                )
                
                # 通知UI更新（每代都更新）
                self.notify('current_generation', self.current_generation)
                self.notify('current_best_distance', self.current_best_distance)
                self.notify('best_route', self.get_best_route_coordinates())
                self.notify('best_distance_history', list(self.best_distance_history))
                self.notify('avg_distance_history', list(self.avg_distance_history))
                
                # 选择、交叉、变异产生新种群
                self.population = self._evolve_population(fitness_scores)
                
                # 保持GUI响应
                time.sleep(self.ui_refresh_interval)
            
            self.notify('has_finished', True)
            
        except Exception as e:
            print(f"Error in TSP run: {e}")
            import traceback
            traceback.print_exc()
            self.notify('has_finished', True)
