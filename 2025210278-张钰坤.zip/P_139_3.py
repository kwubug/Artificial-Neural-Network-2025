# file: rbf_hermite_approx.py
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple

# ---------- data generation ----------
def F(x: np.ndarray) -> np.ndarray:
    return 1.1 * (1 - x + 2 * x**2) * np.exp(-x**2 / 2.0)

def make_dataset(P: int = 100, x_low: float = -4.0, x_high: float = 4.0,
                 noise_std: float = 0.1, seed: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    x = rng.uniform(x_low, x_high, size=P)
    y_clean = F(x)
    y = y_clean + rng.normal(0.0, noise_std, size=P)
    order = np.argsort(x)
    return x[order], y[order]

# ---------- RBF utilities ----------
def gaussian_phi(x: np.ndarray, c: np.ndarray, s: np.ndarray) -> np.ndarray:
    # x: (P,), c: (M,), s: (M,)
    x_col = x[:, None]
    return np.exp(- (x_col - c[None, :])**2 / (2.0 * (s[None, :]**2)))

def design_matrix(x: np.ndarray, c: np.ndarray, s: np.ndarray) -> np.ndarray:
    Phi = gaussian_phi(x, c, s)  # (P, M)
    return np.concatenate([Phi, np.ones((Phi.shape[0], 1))], axis=1)  # + bias

# ---------- K-Means (1D) ----------
def kmeans_1d(x: np.ndarray, K: int, init_centers: np.ndarray,
              max_iter: int = 100) -> np.ndarray:
    c = init_centers.astype(float).copy()
    for _ in range(max_iter):
        # assignment
        dist = np.abs(x[:, None] - c[None, :])
        idx = np.argmin(dist, axis=1)
        new_c = c.copy()
        for k in range(K):
            pts = x[idx == k]
            if len(pts) > 0:
                new_c[k] = np.mean(pts)
        if np.allclose(new_c, c):
            break
        c = new_c
    return np.sort(c)

def widths_from_nn(c: np.ndarray, lam: float = 1.0) -> np.ndarray:
    M = len(c)
    s = np.empty(M, dtype=float)
    for j in range(M):
        d = np.min(np.abs(c[j] - np.delete(c, j)))
        s[j] = lam * d / np.sqrt(2.0)
    # 边界情形（孤立中心）兜底
    eps = np.median(s[s > 0]) if np.any(s > 0) else 0.5
    s[s <= 1e-8] = eps
    return s

# ---------- Method (1): clustering + pseudoinverse ----------
@dataclass
class ClusterRBFResult:
    c: np.ndarray
    s: np.ndarray
    w: np.ndarray
    b: float
    rmse: float

def rbf_cluster_fit(x: np.ndarray, y: np.ndarray, M: int = 10, lam: float = 1.0) -> ClusterRBFResult:
    init_c = x[:M]  # 题意：前 10 个样本为初始中心
    c = kmeans_1d(x, M, init_c)
    s = widths_from_nn(c, lam)
    Phi_b = design_matrix(x, c, s)  # (P, M+1)
    theta = np.linalg.pinv(Phi_b) @ y  # [w;b]
    w, b = theta[:-1], float(theta[-1])
    y_hat = Phi_b @ theta
    rmse = float(np.sqrt(np.mean((y_hat - y) ** 2)))
    return ClusterRBFResult(c=c, s=s, w=w, b=b, rmse=rmse)

# ---------- Method (2): gradient descent ----------
@dataclass
class GDConfig:
    M: int = 10
    lr: float = 1e-3
    max_iter: int = 5000
    rmse_goal: float = 0.09
    seed: int = 1

@dataclass
class GDRBFResult:
    c: np.ndarray
    s: np.ndarray
    w: np.ndarray
    b: float
    rmse_hist: np.ndarray

def rbf_gd_fit(x: np.ndarray, y: np.ndarray, cfg: GDConfig = GDConfig()) -> GDRBFResult:
    rng = np.random.default_rng(cfg.seed)
    # 初始化
    w = rng.uniform(-0.1, 0.1, size=cfg.M)
    c = rng.uniform(-4.0, 4.0, size=cfg.M)
    s = rng.uniform(0.1, 0.3, size=cfg.M)
    b = 0.0

    rmse_hist = []

    for t in range(cfg.max_iter):
        Phi = gaussian_phi(x, c, s)                  # (P, M)
        y_hat = Phi @ w + b                          # (P,)
        err = y_hat - y                              # (P,)
        P = x.shape[0]
        # RMSE
        rmse = float(np.sqrt(np.mean(err**2)))
        rmse_hist.append(rmse)
        if rmse <= cfg.rmse_goal:
            break

        # 梯度（批量）
        # why: 一次性批量梯度更稳定
        grad_w = (2.0 / P) * (Phi * err[:, None]).sum(axis=0)
        # dφ/dc = φ * (x - c)/s^2
        dphi_dc = Phi * (x[:, None] - c[None, :]) / (s[None, :] ** 2)
        grad_c = (2.0 / P) * (err[:, None] * (w[None, :] * dphi_dc)).sum(axis=0)
        # dφ/ds = φ * (x - c)^2 / s^3
        dphi_ds = Phi * ((x[:, None] - c[None, :]) ** 2) / (s[None, :] ** 3)
        grad_s = (2.0 / P) * (err[:, None] * (w[None, :] * dphi_ds)).sum(axis=0)
        grad_b = float((2.0 / P) * err.sum())

        # 参数更新
        w -= cfg.lr * grad_w
        c -= cfg.lr * grad_c
        s -= cfg.lr * grad_s
        b -= cfg.lr * grad_b
        s = np.clip(s, 1e-3, 3.0)  # 宽度稳定性约束

    return GDRBFResult(c=c, s=s, w=w, b=b, rmse_hist=np.array(rmse_hist, dtype=float))

# ---------- evaluation ----------
def predict(x: np.ndarray, c: np.ndarray, s: np.ndarray, w: np.ndarray, b: float) -> np.ndarray:
    return gaussian_phi(x, c, s) @ w + b

# ---------- main experiment ----------
def main() -> None:
    # 数据
    x, y = make_dataset(P=100, seed=7)
    x_grid = np.linspace(-4, 4, 400)
    y_true = F(x_grid)

    # 方法(1)
    cl_res = rbf_cluster_fit(x, y, M=10, lam=1.0)
    y_cl = predict(x_grid, cl_res.c, cl_res.s, cl_res.w, cl_res.b)

    # 方法(2)
    gd_cfg = GDConfig(M=10, lr=1e-3, max_iter=5000, rmse_goal=0.09, seed=3)
    gd_res = rbf_gd_fit(x, y, cfg=gd_cfg)
    y_gd = predict(x_grid, gd_res.c, gd_res.s, gd_res.w, gd_res.b)

    # 可视化：拟合曲线
    fig1, ax1 = plt.subplots(figsize=(7, 5))
    ax1.plot(x_grid, y_true, label="True F(x)")
    ax1.scatter(x, y, s=16, alpha=0.6, label="Noisy samples")
    ax1.plot(x_grid, y_cl, linestyle="--", label="Cluster + pinv")
    ax1.plot(x_grid, y_gd, linestyle="-.", label="GD-trained RBF")
    ax1.set_title("Hermite-like function approximation with RBF (M=10)")
    ax1.set_xlabel("x")
    ax1.set_ylabel("y")
    ax1.legend()
    fig1.tight_layout()
    fig1.savefig("rbf_approximation.png", dpi=150)

    # 可视化：损失
    fig2, ax2 = plt.subplots(figsize=(6, 4))
    ax2.plot(gd_res.rmse_hist)
    ax2.axhline(gd_cfg.rmse_goal, linestyle="--")
    ax2.set_title("Gradient Descent Training RMSE")
    ax2.set_xlabel("Iteration")
    ax2.set_ylabel("RMSE")
    fig2.tight_layout()
    fig2.savefig("rbf_gd_rmse.png", dpi=150)

    # 汇总
    rmse_cl = np.sqrt(np.mean((predict(x, cl_res.c, cl_res.s, cl_res.w, cl_res.b) - y)**2))
    rmse_gd = np.sqrt(np.mean((predict(x, gd_res.c, gd_res.s, gd_res.w, gd_res.b) - y)**2))
    print("=== Cluster + pinv ===")
    print(f"RMSE(train) = {rmse_cl:.4f}")
    print(f"Centers (sorted) = {np.round(cl_res.c, 3)}")
    print(f"Widths  = {np.round(cl_res.s, 3)}")
    print(f"Bias b  = {cl_res.b:.4f}")
    print("=== GD-trained RBF ===")
    print(f"RMSE(train) = {rmse_gd:.4f}")
    print(f"iters = {len(gd_res.rmse_hist)}")
    print(f"Centers (sorted) = {np.round(np.sort(gd_res.c), 3)}")
    print(f"Widths  = {np.round(gd_res.s, 3)}")
    print(f"Bias b  = {gd_res.b:.4f}")
    print("Saved figures: rbf_approximation.png, rbf_gd_rmse.png")

if __name__ == "__main__":
    main()
