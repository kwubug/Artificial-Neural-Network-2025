import math
import numpy as np

from . import TraningAlgorithm


class BmAlgorithm(TraningAlgorithm):
    """Boltzmann Machine with 3 neurons."""
    
    def __init__(self, dataset=None, total_epoches=100, initial_temperature=10.0,
                 min_temperature=0.1, cooling_rate=0.95, equilibrium_threshold=10,
                 weight_range=(-2, 2), bias_range=(-1, 1)):
        # BM doesn't need dataset for basic operation, but we keep it for compatibility
        if dataset is None:
            dataset = []
        super().__init__(dataset, total_epoches)
        
        self._initial_temperature = initial_temperature
        self._min_temperature = min_temperature
        self._cooling_rate = cooling_rate
        self._equilibrium_threshold = equilibrium_threshold  # iterations without change to consider equilibrium
        
        # Initialize 3 neurons
        self.num_neurons = 3
        
        # Initialize weights (symmetric matrix, diagonal = 0)
        np.random.seed(42)  # For reproducibility
        self.weights = np.random.uniform(weight_range[0], weight_range[1], 
                                        (self.num_neurons, self.num_neurons))
        # Make symmetric and zero diagonal
        self.weights = (self.weights + self.weights.T) / 2
        np.fill_diagonal(self.weights, 0)
        
        # Initialize biases
        self.biases = np.random.uniform(bias_range[0], bias_range[1], self.num_neurons)
        
        # Initialize neuron states (0 or 1)
        self.states = np.random.randint(0, 2, self.num_neurons)
        
        # Track history
        self.current_iterations = 0
        self.energy_history = []
        self.states_history = []
        self.temperature_history = []
        self.is_equilibrium = False
        self.equilibrium_iteration = -1
        self.stable_count = 0  # Count of consecutive iterations without state change
        
        # Initialize temperature
        self._temp = self._initial_temperature
        
    def run(self):
        """Run the Boltzmann Machine simulation."""
        # Record initial state only if history is empty
        # (it might already be initialized by the bridge)
        if len(self.energy_history) == 0:
            self.states_history.append(self.states.copy())
            self.energy_history.append(self._calculate_energy())
            self.temperature_history.append(self._current_temperature)
        
        for self.current_iterations in range(self._total_epoches):
            if self._should_stop:
                break
            
            # Update state
            self._iterate()
            
            # Record history after iteration
            self.states_history.append(self.states.copy())
            self.energy_history.append(self._calculate_energy())
            
            # Check for equilibrium after iteration
            if self._check_equilibrium():
                self.is_equilibrium = True
                if self.equilibrium_iteration == -1:
                    self.equilibrium_iteration = self.current_iterations
            
            # Update temperature (simulated annealing)
            if self._current_temperature > self._min_temperature:
                self._current_temperature *= self._cooling_rate
            else:
                self._current_temperature = self._min_temperature
            
            # Record temperature after update
            self.temperature_history.append(self._current_temperature)
    
    def _iterate(self):
        """Perform one iteration: update one random neuron."""
        # Store old state for comparison
        old_state = self.states.copy()
        
        # Randomly select a neuron to update
        neuron_idx = np.random.randint(0, self.num_neurons)
        
        # Calculate the input to this neuron
        input_sum = np.dot(self.weights[neuron_idx], self.states) + self.biases[neuron_idx]
        
        # Calculate probability of neuron being 1
        # Using Boltzmann distribution: P(s=1) = 1 / (1 + exp(-input / T))
        if self._current_temperature > 1e-10:  # Avoid division by very small numbers
            probability = 1 / (1 + math.exp(-input_sum / self._current_temperature))
        else:
            # At zero temperature, use deterministic threshold
            probability = 1.0 if input_sum > 0 else 0.0
        
        # Update state probabilistically
        new_state = 1 if np.random.random() < probability else 0
        self.states[neuron_idx] = new_state
        
        # Check if state changed (compare with old state)
        if np.array_equal(self.states, old_state):
            self.stable_count += 1
        else:
            self.stable_count = 0
    
    def _calculate_energy(self):
        """Calculate the energy of the current state."""
        # E = -0.5 * sum_i sum_j W_ij * s_i * s_j - sum_i b_i * s_i
        energy = -0.5 * np.dot(self.states, np.dot(self.weights, self.states))
        energy -= np.dot(self.biases, self.states)
        return energy
    
    def _check_equilibrium(self):
        """Check if the system has reached equilibrium."""
        # Equilibrium: states haven't changed for equilibrium_threshold iterations
        return self.stable_count >= self._equilibrium_threshold
    
    @property
    def _current_temperature(self):
        """Get current temperature."""
        if not hasattr(self, '_temp'):
            self._temp = self._initial_temperature
        return self._temp
    
    @_current_temperature.setter
    def _current_temperature(self, value):
        """Set current temperature."""
        self._temp = value
    
    def get_current_energy(self):
        """Get current energy."""
        return self._calculate_energy()
    
    def get_current_states(self):
        """Get current neuron states."""
        return self.states.copy()
    
    def get_weights(self):
        """Get weight matrix."""
        return self.weights.copy()
    
    def get_biases(self):
        """Get bias vector."""
        return self.biases.copy()
    
    def reset(self):
        """Reset the BM to initial state (keep weights and biases, reset states and history)."""
        # Reset states to random initial values
        self.states = np.random.randint(0, 2, self.num_neurons)
        self._current_temperature = self._initial_temperature
        self.energy_history = []
        self.states_history = []
        self.temperature_history = []
        self.is_equilibrium = False
        self.equilibrium_iteration = -1
        self.stable_count = 0
        self.current_iterations = 0

