import sys
import numpy as np
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QTextEdit, QLineEdit, QMessageBox, QGridLayout
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib


matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False


# ========= 变换函数 =========
def discrete_function(net):
    """离散型变换函数"""
    return np.where(net >= 0, 1, -1)


def piecewise_linear_function(net, c=0.5, x_c=1):
    """分段线性变换函数（双极性形式）"""
    out = []
    for n in net:
        if n <= -x_c:
            out.append(-1)
        elif n >= x_c:
            out.append(1)
        else:
            out.append(c * n)
    return np.array(out)


def bipolar_sigmoid_function(net):
    """双极性 Sigmoid 变换函数"""
    return 2 / (1 + np.exp(-net)) - 1


# 变换函数字典
activation_functions = {
    "离散型变换函数": discrete_function,
    "分段线性变换函数": piecewise_linear_function,
    "双极性Sigmoid函数": bipolar_sigmoid_function
}


# ========= 学习规则 =========
def hebbian(w, x, d, y, eta):
    delta_w = eta * y * x
    return w + delta_w, delta_w

def perceptron(w, x, d, y, eta):
    delta_w = eta * (d - y) * x
    return w + delta_w, delta_w

def delta_rule(w, x, d, y, eta):
    delta_w = eta * (d - y) * x
    return w + delta_w, delta_w

def LMS(w, x, d, y, eta):
    delta_w = eta * (d - np.dot(w, x)) * x
    return w + delta_w, delta_w

learning_rules = {
    "Hebbian": hebbian,
    "Perceptron": perceptron,
    "Delta": delta_rule,
    "LMS": LMS
}


# ========= 主训练函数 =========
def train(samples, w, rule, act_func, eta, epochs, log_callback):
    mse_list = []
    update_func = learning_rules[rule]
    act = activation_functions[act_func]
    has_d = samples[0][1] is not None
    if rule == "Hebbian":
        has_d = False

    log_callback(f"检测到{'有监督' if has_d else '无监督'}学习。")

    for epoch in range(epochs):
        mse = 0
        log_callback(f"=== 第 {epoch + 1} 轮训练开始 ===")
        for i, (x, d) in enumerate(samples):
            net = np.dot(w, x)
            y = float(act(np.array([net])))
            new_w, delta_w = update_func(w, x, d, y, eta) if has_d else update_func(w, x, 0, y, eta)
            if has_d:
                mse += (d - y) ** 2

            log_callback(
                f"样本 {i + 1}：x={x.tolist()}, d={d if d is not None else '—'}\n"
                f"净输入 net={net:.4f}, 输出 y={y:.4f}\n"
                f"Δw={np.round(delta_w, 4).tolist()}\n"
                f"更新前权值={np.round(w, 4).tolist()}\n"
                f"更新后权值={np.round(new_w, 4).tolist()}\n"
                f"--------------------------------------"
            )
            w = new_w
        if has_d:
            mse_list.append(mse / len(samples))
    return mse_list if has_d else []


# ========= 图形界面 =========
class NeuralTrainingGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("神经网络第2.8题训练程序")
        self.setGeometry(150, 80, 1050, 850)

        layout = QVBoxLayout()

        # 参数设置区
        params = QHBoxLayout()
        self.rule_box = QComboBox()
        self.rule_box.addItems(learning_rules.keys())
        self.act_box = QComboBox()
        self.act_box.addItems(activation_functions.keys())

        self.lr_input = QLineEdit()
        self.w_input = QLineEdit()
        self.epoch_input = QLineEdit()

        params.addWidget(QLabel("学习规则："))
        params.addWidget(self.rule_box)
        params.addWidget(QLabel("变换函数："))
        params.addWidget(self.act_box)
        params.addWidget(QLabel("学习率 η："))
        params.addWidget(self.lr_input)
        params.addWidget(QLabel("初始权值 w："))
        params.addWidget(self.w_input)
        params.addWidget(QLabel("训练轮数："))
        params.addWidget(self.epoch_input)
        layout.addLayout(params)

        # ===== 输入区（每个框一组样本） =====
        grid = QGridLayout()
        self.x_inputs = [QLineEdit() for _ in range(6)]
        for i in range(6):
            grid.addWidget(QLabel(f"X{i + 1} 向量："), 0, i)
            grid.addWidget(self.x_inputs[i], 1, i)
        self.d_input = QLineEdit()
        grid.addWidget(QLabel("输出 d（多个值以逗号分隔）："), 2, 0, 1, 3)
        grid.addWidget(self.d_input, 2, 3, 1, 3)

        self.start_btn = QPushButton("开始训练")
        self.start_btn.clicked.connect(self.run_training)
        self.clear_btn = QPushButton("清空输出")
        self.clear_btn.clicked.connect(self.clear_output)
        grid.addWidget(self.start_btn, 3, 4)
        grid.addWidget(self.clear_btn, 3, 5)
        layout.addLayout(grid)

        # ===== 日志输出 =====
        self.text_log = QTextEdit()
        self.text_log.setReadOnly(True)
        layout.addWidget(self.text_log)

        # ===== 绘图区域 =====
        self.figure = Figure(figsize=(8, 4))
        self.canvas = FigureCanvas(self.figure)
        layout.addWidget(self.canvas)

        self.setLayout(layout)

    def clear_output(self):
        self.text_log.clear()
        self.text_log.append("已清空输出。")

    def run_training(self):
        # === 读取参数 ===
        try:
            w = np.array([float(i) for i in self.w_input.text().split(",")])
            eta = float(self.lr_input.text())
            epochs = int(self.epoch_input.text())
        except:
            QMessageBox.warning(self, "输入错误", "请正确输入学习率、初始权值和训练轮数！")
            return

        rule = self.rule_box.currentText()
        act = self.act_box.currentText()

        # === 解析输入向量 ===
        vectors = []
        for inp in self.x_inputs:
            txt = inp.text().strip()
            if txt:
                nums = [float(x) for x in txt.replace("，", ",").replace(" ", ",").split(",") if x != ""]
                vectors.append(np.array(nums))

        if not vectors:
            QMessageBox.warning(self, "输入错误", "请至少输入一个样本向量！")
            return

        # === 解析 d ===
        d_txt = self.d_input.text().strip()
        if d_txt:
            d_values = [float(x) for x in d_txt.replace("，", ",").replace(" ", ",").split(",") if x != ""]
            if len(d_values) != len(vectors):
                QMessageBox.warning(self, "输入错误", "d 的数量与输入样本数量不一致！")
                return
        else:
            d_values = [None] * len(vectors)

        samples = list(zip(vectors, d_values))
        self.text_log.append(f"\n开始训练：规则={rule}, 变换函数={act}, η={eta}\n")

        mse = train(samples, w, rule, act, eta, epochs,
                    log_callback=lambda s: self.text_log.append(s))

        # === 绘图 ===
        self.figure.clear()  # 关键：清空画布，防止叠加导致图越来越小
        ax = self.figure.add_subplot(111)

        if mse:
            ax.plot(range(1, len(mse) + 1), mse, marker='o', label='MSE')
            ax.set_title("均方误差曲线", fontsize=12)
            ax.set_xlabel("训练轮数", fontsize=10)
            ax.set_ylabel("MSE", fontsize=10)
            ax.legend()
            ax.grid(True)
        else:
            ax.text(0.5, 0.5, "无监督学习（无误差曲线）", ha='center', va='center', fontsize=12)

        # 自动调整布局，防止挤压
        self.figure.tight_layout(pad=2.0)
        self.canvas.draw()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    gui = NeuralTrainingGUI()
    gui.show()
    sys.exit(app.exec_())
