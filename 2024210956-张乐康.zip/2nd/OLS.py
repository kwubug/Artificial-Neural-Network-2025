import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

#Hermit多项式函数
def F(x):
    return 1.1 * (1 - x + 2 * x ** 2) * torch.exp(-x ** 2 / 2)

torch.manual_seed(10)
P = 100
x_i = torch.FloatTensor(P).uniform_(-4, 4)
e_i = torch.normal(0, 0.1, size=(P,))
y_i = F(x_i) + e_i
X_train = x_i.unsqueeze(1)
y_train = y_i.unsqueeze(1)

class RBFNet(nn.Module):
    def __init__(self, M=10):
        super(RBFNet, self).__init__()
        self.M = M
        self.centers = nn.Parameter(torch.randn(M, 1))
        self.sigmas = nn.Parameter(torch.ones(M, 1))
        self.weights = nn.Parameter(torch.randn(M, 1))
        self.bias = nn.Parameter(torch.randn(1))

    def gaussian_rbf(self, x):
        x_expanded = x.unsqueeze(1)
        centers_expanded = self.centers.unsqueeze(0)
        distances = torch.sum((x_expanded - centers_expanded) ** 2, dim=2)
        phi = torch.exp(-distances / (2 * self.sigmas.squeeze() ** 2))
        return phi

    def forward(self, x):
        phi = self.gaussian_rbf(x)
        output = torch.matmul(phi, self.weights) + self.bias
        return output


class LinearRegressionOLS:
    def __init__(self):
        self.w = None
        self.b = None

    def fit(self, X, y):
        """OLS: w = (X^T X)^-1 X^T y"""
        X_with_bias = torch.cat([torch.ones(X.shape[0], 1), X], dim=1)
        try:
            parameters = torch.inverse(X_with_bias.T @ X_with_bias) @ X_with_bias.T @ y
            self.b = parameters[0]
            self.w = parameters[1:]
        except:
            parameters = torch.pinverse(X_with_bias.T @ X_with_bias) @ X_with_bias.T @ y
            self.b = parameters[0]
            self.w = parameters[1:]

    def predict(self, X):
        return X @ self.w + self.b


class PolynomialRegressionOLS:
    def __init__(self, degree=3):
        self.degree = degree
        self.coefficients = None

    def fit(self, X, y):
        X_poly = torch.ones(X.shape[0], 1)
        for d in range(1, self.degree + 1):
            X_poly = torch.cat([X_poly, X ** d], dim=1)
        try:
            self.coefficients = torch.inverse(X_poly.T @ X_poly) @ X_poly.T @ y
        except:
            self.coefficients = torch.pinverse(X_poly.T @ X_poly) @ X_poly.T @ y

    def predict(self, X):
        X_poly = torch.ones(X.shape[0], 1)
        for d in range(1, self.degree + 1):
            X_poly = torch.cat([X_poly, X ** d], dim=1)
        return X_poly @ self.coefficients


def kmeans_manual(X, k, max_iters=100):
    indices = torch.randperm(X.shape[0])[:k]
    centers = X[indices].clone()
    for _ in range(max_iters):
        distances = torch.cdist(X, centers)
        labels = torch.argmin(distances, dim=1)
        new_centers = torch.zeros_like(centers)
        for i in range(k):
            cluster_points = X[labels == i]
            if len(cluster_points) > 0:
                new_centers[i] = cluster_points.mean(dim=0)
        if torch.allclose(centers, new_centers):
            break
        centers = new_centers
    return centers, labels


def part1_cluster_pseudoinverse():
    centers_cluster, labels = kmeans_manual(X_train, k=10)

    sigmas_cluster = []
    for i in range(10):
        cluster_points = X_train[labels == i]
        if len(cluster_points) > 1:
            distances = torch.norm(cluster_points - centers_cluster[i], dim=1)
            sigma = torch.sqrt(torch.mean(distances ** 2))
            sigmas_cluster.append(sigma.item())
        else:
            sigmas_cluster.append(1.0)
    sigmas_cluster = torch.FloatTensor(sigmas_cluster).unsqueeze(1)

    model1 = RBFNet(M=10)
    model1.centers.data = centers_cluster
    model1.sigmas.data = sigmas_cluster

    with torch.no_grad():
        phi_matrix = model1.gaussian_rbf(X_train)
        phi_matrix_with_bias = torch.cat([phi_matrix, torch.ones(phi_matrix.size(0), 1)], dim=1)
        pseudoinverse = torch.pinverse(phi_matrix_with_bias)
        weights_with_bias = torch.matmul(pseudoinverse, y_train)
        model1.weights.data = weights_with_bias[:-1]
        model1.bias.data = weights_with_bias[-1:]

    model1.eval()
    with torch.no_grad():
        y_pred1 = model1(X_train)
        mse1 = torch.mean((y_pred1 - y_train) ** 2)

    return model1


def part2_gradient_descent():
    model2 = RBFNet(M=10)
    model2.centers.data = torch.FloatTensor(10, 1).uniform_(-4.0, 4.0)
    model2.sigmas.data = torch.FloatTensor(10, 1).uniform_(0.1, 0.3)
    model2.weights.data = torch.FloatTensor(10, 1).uniform_(-0.1, 0.1)
    model2.bias.data = torch.FloatTensor(1).uniform_(-0.1, 0.1)

    criterion = nn.MSELoss()
    optimizer = optim.SGD(model2.parameters(), lr=0.001)

    losses = []
    for epoch in range(2000):
        model2.train()
        optimizer.zero_grad()
        y_pred = model2(X_train)
        loss = criterion(y_pred, y_train)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())

        if epoch % 500 == 0:
            print(f"Epoch {epoch}, Loss: {loss.item():.6f}")

    print(f"最终训练Loss: {losses[-1]:.6f}")
    return model2, losses


def visualize_ols_comparison(model1, model2, losses):
    linear_ols = LinearRegressionOLS()
    linear_ols.fit(X_train, y_train)

    poly_ols = PolynomialRegressionOLS(degree=3)
    poly_ols.fit(X_train, y_train)
    x_test = torch.linspace(-4, 4, 200).unsqueeze(1)
    y_true = F(x_test)

    with torch.no_grad():
        y_pred_linear = linear_ols.predict(x_test)
        y_pred_poly = poly_ols.predict(x_test)
        y_pred_rbf1 = model1(x_test)
        y_pred_rbf2 = model2(x_test)

        y_train_linear = linear_ols.predict(X_train)
        y_train_poly = poly_ols.predict(X_train)
        y_train_rbf1 = model1(X_train)
        y_train_rbf2 = model2(X_train)

    fig = plt.figure(figsize=(20, 12))

    plt.subplot(2, 3, 1)
    plt.plot(x_test.numpy(), y_true.numpy(), 'k-', linewidth=3, label='True Function', alpha=0.8)
    plt.plot(x_test.numpy(), y_pred_linear.numpy(), 'r--', linewidth=2, label='Linear OLS')
    plt.plot(x_test.numpy(), y_pred_poly.numpy(), 'g--', linewidth=2, label='Poly OLS (deg=3)')
    plt.plot(x_test.numpy(), y_pred_rbf1.numpy(), 'b-', linewidth=2, label='RBF Cluster+PI', alpha=0.7)
    plt.plot(x_test.numpy(), y_pred_rbf2.numpy(), 'm-', linewidth=2, label='RBF Gradient Descent', alpha=0.7)
    plt.scatter(X_train.numpy(), y_train.numpy(), alpha=0.3, color='gray', s=20, label='Training Data')
    plt.xlabel('x')
    plt.ylabel('F(x)')
    plt.title('Function Approximation Comparison')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.subplot(2, 3, 2)
    residuals = [
        (y_train - y_train_linear).numpy(),
        (y_train - y_train_poly).numpy(),
        (y_train - y_train_rbf1).numpy(),
        (y_train - y_train_rbf2).numpy()
    ]
    labels = ['Linear OLS', 'Poly OLS', 'RBF Cluster', 'RBF GD']

    try:
        plt.boxplot([r.squeeze() for r in residuals], tick_labels=labels)
    except TypeError:
        plt.boxplot([r.squeeze() for r in residuals], labels=labels)

    plt.axhline(y=0, color='red', linestyle='--', alpha=0.5)
    plt.ylabel('Residuals')
    plt.title('Residual Distribution Comparison')
    plt.grid(True, alpha=0.3)

    plt.subplot(2, 3, 3)
    mse_values = [
        torch.mean((y_train - y_train_linear) ** 2).item(),
        torch.mean((y_train - y_train_poly) ** 2).item(),
        torch.mean((y_train - y_train_rbf1) ** 2).item(),
        torch.mean((y_train - y_train_rbf2) ** 2).item()
    ]

    bars = plt.bar(labels, mse_values, color=['red', 'green', 'blue', 'purple'], alpha=0.7)
    plt.ylabel('MSE')
    plt.title('Mean Squared Error Comparison')
    plt.yscale('log')
    for bar, value in zip(bars, mse_values):
        plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f'{value:.4f}',
                 ha='center', va='bottom')
    plt.grid(True, alpha=0.3)

    plt.subplot(2, 3, 4)
    plt.plot(losses)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('RBF Network Training Loss (Gradient Descent)')
    plt.yscale('log')
    plt.grid(True, alpha=0.3)

    plt.subplot(2, 3, 5)
    models_predictions = [y_train_linear, y_train_poly, y_train_rbf1, y_train_rbf2]
    model_names = ['Linear OLS', 'Poly OLS', 'RBF Cluster', 'RBF GD']
    colors = ['red', 'green', 'blue', 'purple']

    for i, (y_pred, name, color) in enumerate(zip(models_predictions, model_names, colors)):
        plt.scatter(y_train.numpy(), y_pred.numpy(), alpha=0.5, label=name, color=color, s=30)

    min_val = min(y_train.min(), y_pred.min())
    max_val = max(y_train.max(), y_pred.max())
    plt.plot([min_val, max_val], [min_val, max_val], 'k--', alpha=0.5, label='Ideal')
    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')
    plt.title('Predicted vs True Values')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.subplot(2, 3, 6)
    with torch.no_grad():
        phi_test = model1.gaussian_rbf(x_test)
        for i in range(min(5, model1.M)):  # 显示前5个基函数
            plt.plot(x_test.numpy(), phi_test[:, i].numpy(),
                     label=f'RBF Center {i + 1}', alpha=0.7)

    plt.xlabel('x')
    plt.ylabel('RBF Value')
    plt.title('RBF Basis Functions (Cluster Method)')
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    results = []
    for name, y_pred in zip(['Linear OLS', 'Poly OLS (deg=3)', 'RBF Cluster+PI', 'RBF Gradient Descent'],
                            [y_train_linear, y_train_poly, y_train_rbf1, y_train_rbf2]):
        mse = torch.mean((y_train - y_pred) ** 2).item()
        mae = torch.mean(torch.abs(y_train - y_pred)).item()
        results.append((name, mse, mae))

    for name, mse, mae in results:
        print(f'{name, mse, mae}')
    test_results = []
    for name, model in [('Linear OLS', linear_ols), ('Poly OLS', poly_ols),
                        ('RBF Cluster', model1), ('RBF GD', model2)]:
        if hasattr(model, 'predict'):
            y_test_pred = model.predict(x_test)
        else:
            with torch.no_grad():
                y_test_pred = model(x_test)
        test_mse = torch.mean((y_test_pred - y_true) ** 2).item()
        test_results.append((name, test_mse))

    for name, test_mse in test_results:
        print(f"{name:<25} {test_mse:<12.6f}")

if __name__ == "__main__":
    model1 = part1_cluster_pseudoinverse()
    model2, losses = part2_gradient_descent()
    visualize_ols_comparison(model1, model2, losses)