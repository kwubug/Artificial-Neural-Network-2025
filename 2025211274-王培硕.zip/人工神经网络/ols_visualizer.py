import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import ttk
import random

class OLSVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("OLS学习算法可视化")
        self.root.geometry("1200x800")
        
        # 数据点
        self.x_data = []
        self.y_data = []
        
        # OLS参数
        self.slope = 0
        self.intercept = 0
        
        # 创建界面
        self.setup_ui()
        
        # 生成初始数据
        self.generate_sample_data()
        
        # 计算OLS参数
        self.calculate_ols()
        
        # 更新可视化
        self.update_visualization()
        
    def setup_ui(self):
        # 主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 控制面板
        control_frame = tk.LabelFrame(main_frame, text="控制面板", padx=10, pady=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 按钮框架
        button_frame = tk.Frame(control_frame)
        button_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(button_frame, text="数据操作:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        # 数据操作按钮
        generate_button = tk.Button(button_frame, text="生成样本数据", command=self.generate_sample_data)
        generate_button.pack(pady=2)
        
        clear_button = tk.Button(button_frame, text="清空数据", command=self.clear_data)
        clear_button.pack(pady=2)
        
        add_noise_button = tk.Button(button_frame, text="添加噪声", command=self.add_noise)
        add_noise_button.pack(pady=2)
        
        # 手动添加点框架
        manual_frame = tk.Frame(control_frame)
        manual_frame.pack(side=tk.LEFT, padx=(0, 20))
        
        tk.Label(manual_frame, text="手动添加点:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        x_frame = tk.Frame(manual_frame)
        x_frame.pack(pady=2)
        tk.Label(x_frame, text="X:").pack(side=tk.LEFT)
        self.x_entry = tk.Entry(x_frame, width=10)
        self.x_entry.pack(side=tk.LEFT, padx=(5, 0))
        
        y_frame = tk.Frame(manual_frame)
        y_frame.pack(pady=2)
        tk.Label(y_frame, text="Y:").pack(side=tk.LEFT)
        self.y_entry = tk.Entry(y_frame, width=10)
        self.y_entry.pack(side=tk.LEFT, padx=(5, 0))
        
        add_point_button = tk.Button(manual_frame, text="添加点", command=self.add_point)
        add_point_button.pack(pady=2)
        
        # 算法控制框架
        algo_frame = tk.Frame(control_frame)
        algo_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Label(algo_frame, text="算法控制:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        calculate_button = tk.Button(algo_frame, text="计算OLS参数", command=self.calculate_ols)
        calculate_button.pack(pady=2)
        
        # 参数显示框架
        param_frame = tk.Frame(control_frame)
        param_frame.pack(side=tk.LEFT, padx=(20, 0))
        
        tk.Label(param_frame, text="OLS参数:", font=("Arial", 10, "bold")).pack(anchor=tk.W)
        
        self.slope_label = tk.Label(param_frame, text="斜率: 0.0000")
        self.slope_label.pack(anchor=tk.W)
        
        self.intercept_label = tk.Label(param_frame, text="截距: 0.0000")
        self.intercept_label.pack(anchor=tk.W)
        
        self.mse_label = tk.Label(param_frame, text="MSE: 0.0000")
        self.mse_label.pack(anchor=tk.W)
        
        # 显示区域
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # 图形显示区域
        plot_frame = tk.LabelFrame(display_frame, text="数据可视化", padx=10, pady=10)
        plot_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建matplotlib图形
        self.fig, self.ax = plt.subplots(figsize=(10, 6))
        self.canvas = FigureCanvasTkAgg(self.fig, plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 信息显示区域
        info_frame = tk.Frame(main_frame)
        info_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # 算法说明
        explanation_frame = tk.LabelFrame(info_frame, text="算法说明", padx=10, pady=10)
        explanation_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        explanation_text = tk.Text(explanation_frame, height=8, wrap=tk.WORD)
        explanation_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        scrollbar = tk.Scrollbar(explanation_frame, command=explanation_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        explanation_text.config(yscrollcommand=scrollbar.set)
        
        # 插入算法说明
        explanation = """普通最小二乘法(OLS)是线性回归中最基本的参数估计方法。

算法原理:
1. 目标是最小化残差平方和: SSE = Σ(y_i - ŷ_i)²
2. 其中 ŷ_i = β₀ + β₁x_i 是预测值
3. 通过求偏导数并令其为零，得到OLS估计量:
   - 斜率: β₁ = Σ[(x_i - x̄)(y_i - ȳ)] / Σ(x_i - x̄)²
   - 截距: β₀ = ȳ - β₁x̄

优点:
- 计算简单，有闭式解
- 不需要迭代优化
- 在满足经典假设时具有良好的统计性质

应用:
- 线性关系建模
- 因果推断
- 预测分析"""
        
        explanation_text.insert(tk.END, explanation)
        explanation_text.config(state=tk.DISABLED)
        
        # 日志信息
        log_frame = tk.LabelFrame(info_frame, text="运行日志", padx=10, pady=10)
        log_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=8)
        self.log_text.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        
        log_scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=log_scrollbar.set)
        
    def log_message(self, message):
        """添加日志信息"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        
    def generate_sample_data(self):
        """生成样本数据"""
        self.x_data = []
        self.y_data = []
        
        # 生成线性关系数据并添加噪声
        for i in range(20):
            x = i * 0.5
            y = 2 * x + 1 + random.gauss(0, 1)  # y = 2x + 1 + 噪声
            self.x_data.append(x)
            self.y_data.append(y)
            
        self.log_message(f"生成了 {len(self.x_data)} 个样本数据点")
        self.calculate_ols()
        self.update_visualization()
        
    def clear_data(self):
        """清空数据"""
        self.x_data = []
        self.y_data = []
        self.slope = 0
        self.intercept = 0
        self.log_message("数据已清空")
        self.update_visualization()
        
    def add_noise(self):
        """为现有数据添加噪声"""
        if len(self.x_data) == 0:
            self.log_message("错误: 没有数据可添加噪声")
            return
            
        # 为每个数据点添加随机噪声
        for i in range(len(self.y_data)):
            self.y_data[i] += random.gauss(0, 0.5)
            
        self.log_message("已为数据添加噪声")
        self.calculate_ols()
        self.update_visualization()
        
    def add_point(self):
        """手动添加数据点"""
        try:
            x = float(self.x_entry.get())
            y = float(self.y_entry.get())
            self.x_data.append(x)
            self.y_data.append(y)
            self.log_message(f"添加点 ({x}, {y})")
            self.calculate_ols()
            self.update_visualization()
        except ValueError:
            self.log_message("错误: 请输入有效的数字")
            
    def calculate_ols(self):
        """计算OLS参数"""
        if len(self.x_data) < 2:
            self.log_message("数据点不足，无法计算OLS参数")
            return
            
        # 转换为numpy数组
        x = np.array(self.x_data)
        y = np.array(self.y_data)
        
        # 计算均值
        x_mean = np.mean(x)
        y_mean = np.mean(y)
        
        # 计算OLS参数
        # 斜率: β₁ = Σ[(x_i - x̄)(y_i - ȳ)] / Σ(x_i - x̄)²
        numerator = np.sum((x - x_mean) * (y - y_mean))
        denominator = np.sum((x - x_mean) ** 2)
        
        if denominator == 0:
            self.log_message("错误: X方差为零，无法计算斜率")
            return
            
        self.slope = numerator / denominator
        # 截距: β₀ = ȳ - β₁x̄
        self.intercept = y_mean - self.slope * x_mean
        
        # 计算MSE
        y_pred = self.slope * x + self.intercept
        mse = np.mean((y - y_pred) ** 2)
        
        # 更新标签显示
        self.slope_label.config(text=f"斜率: {self.slope:.4f}")
        self.intercept_label.config(text=f"截距: {self.intercept:.4f}")
        self.mse_label.config(text=f"MSE: {mse:.4f}")
        
        self.log_message(f"OLS参数计算完成 - 斜率: {self.slope:.4f}, 截距: {self.intercept:.4f}, MSE: {mse:.4f}")
        
    def update_visualization(self):
        """更新可视化"""
        self.ax.clear()
        
        # 绘制数据点
        if len(self.x_data) > 0:
            self.ax.scatter(self.x_data, self.y_data, color='blue', alpha=0.7, s=50, label='数据点')
            
            # 绘制回归线
            x_min, x_max = min(self.x_data), max(self.x_data)
            x_range = np.linspace(x_min - 1, x_max + 1, 100)
            y_range = self.slope * x_range + self.intercept
            self.ax.plot(x_range, y_range, color='red', linewidth=2, label=f'回归线: y = {self.slope:.2f}x + {self.intercept:.2f}')
            
            # 绘制残差线
            for i in range(len(self.x_data)):
                x_point = self.x_data[i]
                y_actual = self.y_data[i]
                y_pred = self.slope * x_point + self.intercept
                self.ax.plot([x_point, x_point], [y_actual, y_pred], color='green', linestyle='--', alpha=0.5)
                
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_title('OLS线性回归可视化')
        self.ax.legend()
        self.ax.grid(True, alpha=0.3)
        
        self.canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = OLSVisualizer(root)
    root.mainloop()