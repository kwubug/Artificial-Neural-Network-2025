import numpy as np
import matplotlib.pyplot as plt

# ======================
# 1. 数据准备
# ======================
p = np.arange(-1, 1.0001, 0.1)
t = np.array([
    -0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336,
    -0.2013, -0.4344, -0.5000, -0.39390, -0.1647, 0.0988, 0.3072, 0.3960,
    0.3449, 0.1816, -0.0312, -0.2189, -0.3201
])

# ======================
# 2. 定义RBF核函数与训练函数
# ======================
def rbf_matrix(x, centers, sigma):
    """构造RBF基函数矩阵"""
    diff = x[:, None] - centers[None, :]
    return np.exp(-((diff) ** 2) / (2 * sigma ** 2))

def train_rbf(x, y, lam=1e-8):
    """训练RBF网络（岭回归）并搜索最优sigma"""
    sigmas = np.linspace(0.05, 1.0, 40)
    best_sigma, best_mse, best_w = None, np.inf, None
    for sigma in sigmas:
        Phi = rbf_matrix(x, x, sigma)
        w = np.linalg.solve(Phi.T @ Phi + lam * np.eye(len(x)), Phi.T @ y)
        mse = np.mean((Phi @ w - y) ** 2)
        if mse < best_mse:
            best_sigma, best_mse, best_w = sigma, mse, w
    return best_sigma, best_mse, best_w

# ======================
# 3. 训练RBF神经网络
# ======================
sigma, mse, w = train_rbf(p, t)
print(f"最优 σ = {sigma:.4f}, 训练误差 MSE = {mse:.3e}")

# ======================
# 4. 预测与绘图
# ======================
xq = np.linspace(-1, 1, 400)
Phi_q = rbf_matrix(xq, p, sigma)
yq = Phi_q @ w

plt.figure(figsize=(8,5))
plt.plot(p, t, 'ko', label='Target Samples')
plt.plot(xq, yq, 'r-', linewidth=2, label='RBF Fitted Curve')
plt.title(f'RBF Neural Network Fitting (σ={sigma:.4f}, MSE={mse:.2e})')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.show()
