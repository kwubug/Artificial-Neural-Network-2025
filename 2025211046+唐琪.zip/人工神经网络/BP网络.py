import numpy as np
import math

def tanh(x):
    return (1 - math.exp(-2 * x)) / (1 + math.exp(-2 * x))


tanh_vec = np.vectorize(tanh)


def tanh_deriv(y):
    return 1 - y ** 2



def bp_batch_train(X, D, n_hidden, eta=0.1, max_epoch=10000, e_min=0.01):
    n_input = X.shape[1]
    n_output = D.shape[1]
    P = X.shape[0]

    V = np.random.uniform(-1, 1, (n_input, n_hidden))
    W = np.random.uniform(-1, 1, (n_hidden, n_output))

    epoch = 0
    while epoch < max_epoch:
        total_error = 0

        for p in range(P):
            x = X[p:p + 1, :]
            d = D[p:p + 1, :]

            net_h = x @ V
            h = tanh_vec(net_h)

            net_o = h @ W
            o = tanh_vec(net_o)

            error = d - o
            total_error += 0.5 * np.sum(error ** 2)

        ERMS = math.sqrt(2 * total_error / (P * n_output))
        if ERMS < e_min:
            print(f"满足误差要求！迭代次数：{epoch}, 均方根误差ERMS：{ERMS:.4f}")
            break

        delta_W = np.zeros_like(W)
        delta_V = np.zeros_like(V)

        for p in range(P):
            x = X[p:p + 1, :]
            d = D[p:p + 1, :]

            net_h = x @ V
            h = tanh_vec(net_h)
            net_o = h @ W
            o = tanh_vec(net_o)

            error = d - o
            delta_o = error * tanh_deriv(o)
            delta_h = (delta_o @ W.T) * tanh_deriv(h)

            delta_W += h.T @ delta_o
            delta_V += x.T @ delta_h

        W += eta * delta_W
        V += eta * delta_V

        epoch += 1
        if epoch % 1000 == 0:
            print(f"迭代次数：{epoch}, 均方根误差ERMS：{ERMS:.4f}")

    return V, W, ERMS, epoch
if __name__ == "__main__":

    X = np.array([
        [0.5, 0.5],
        [0.9, 0.7],
        [1.0, 0.8],
        [0.2, 0.7]
    ])

    D = np.array([
        [1, -1],
        [1, -1],
        [-1, 1],
        [-1, 1]
    ])

    V_trained, W_trained, erms, epochs = bp_batch_train(
        X, D, n_hidden=2, eta=0.2, max_epoch=20000, e_min=0.001
    )

    def predict(x, V, W):
        net_h = x @ V
        h = tanh_vec(net_h)
        net_o = h @ W
        o = tanh_vec(net_o)
        return o

    print("\n=== 测试结果 ===")
    for i in range(X.shape[0]):
        x_test = X[i:i + 1, :]
        d_test = D[i:i + 1, :]
        o_test = predict(x_test, V_trained, W_trained)
        print(f"输入：{x_test[0]}, 期望输出：{d_test[0]}, 实际输出：{o_test[0].round(2)}")