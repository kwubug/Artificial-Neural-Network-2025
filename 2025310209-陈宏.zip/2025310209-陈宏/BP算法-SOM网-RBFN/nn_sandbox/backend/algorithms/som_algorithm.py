import time
import math
import operator
from enum import Enum

import numpy as np

from . import TraningAlgorithm
from ..neurons import SomNeuron
from ..utils import dist, flatten


class NeighborhoodType(Enum):
    GAUSSIAN = "gaussian"
    LINEAR = "linear"
    BUBBLE = "bubble"
    EXPONENTIAL = "exponential"
    MEXICAN_HAT = "mexican_hat"


class LearningRateDecay(Enum):
    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    INVERSET = "inverse_t"
    STEP = "step"


class SomAlgorithm(TraningAlgorithm):
    def __init__(self, dataset, total_epoches=10, initial_learning_rate=0.8,
                 initial_standard_deviation=1, topology_shape=None,
                 neighborhood_type=NeighborhoodType.GAUSSIAN,
                 learning_rate_decay=LearningRateDecay.EXPONENTIAL,
                 winner_selection="min_distance",
                 initialization="data_range",
                 random_state=None):
        super().__init__(dataset, total_epoches)
        self._initial_learning_rate = initial_learning_rate
        self._initial_standard_deviation = initial_standard_deviation

        # the default topology shape is (10 * 10)
        self.topology_shape = topology_shape if topology_shape else [10, 10]

        # 新增可配置参数
        self.neighborhood_type = neighborhood_type
        self.learning_rate_decay = learning_rate_decay
        self.winner_selection = winner_selection
        self.initialization = initialization
        self.random_state = random_state

        # 设置随机种子
        if random_state is not None:
            np.random.seed(random_state)

        self.current_iterations = 0
        self.winner_history = []  # 记录获胜神经元历史

    def run(self):
        self._initialize_neurons()
        for self.current_iterations in range(self._total_epoches * len(self._dataset)):
            if self._should_stop:
                break
            if self.current_iterations % len(self._dataset) == 0:
                np.random.shuffle(self._dataset)
            self._iterate()

    def _initialize_neurons(self):
        if self.initialization == "random":
            # 随机初始化
            data_dim = len(self._dataset[0]) - 1
            self._neurons = [[SomNeuron.random_init(data_dim)
                              for _ in range(self.topology_shape[0])]
                             for _ in range(self.topology_shape[1])]
        elif self.initialization == "pca_direction":
            # PCA方向初始化（简化版）
            data = self._dataset[:, :-1]
            cov_matrix = np.cov(data.T)
            eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
            principal_direction = eigenvectors[:, np.argmax(eigenvalues)]

            self._neurons = [[self._create_pca_neuron(i, j, principal_direction, data)
                              for j in range(self.topology_shape[0])]
                             for i in range(self.topology_shape[1])]
        else:
            # 默认基于数据范围初始化
            data_range = tuple(zip(np.amin(self._dataset[:, :-1], axis=0),
                                   np.amax(self._dataset[:, :-1], axis=0)))
            self._neurons = [[SomNeuron(data_range)
                              for _ in range(self.topology_shape[0])]
                             for _ in range(self.topology_shape[1])]

    def _create_pca_neuron(self, i, j, principal_direction, data):
        """创建基于PCA方向的神经元"""
        # 简化实现，实际需要更复杂的PCA初始化
        data_mean = np.mean(data, axis=0)
        # 在PCA方向上创建网格
        pca_offset = principal_direction * (i - self.topology_shape[1] / 2) * 0.1
        orthogonal_offset = np.random.randn(len(data_mean)) * 0.1  # 随机正交方向

        initial_weight = data_mean + pca_offset + orthogonal_offset
        neuron = SomNeuron([])
        neuron.synaptic_weight = initial_weight
        return neuron

    def _iterate(self):
        self._feed_forward()
        winner = self._get_winner()
        self.winner_history.append(winner)  # 记录历史
        self._adjust_synaptic_weight(winner)

    def _feed_forward(self):
        for row in self._neurons:
            for neuron in row:
                neuron.data = self.current_data[:-1]

    def _get_winner(self):
        if self.winner_selection == "probabilistic":
            # 概率性选择（模拟退火）
            neurons = list(flatten(self._neurons))
            distances = [neuron.dist for neuron in neurons]

            # 避免除零错误
            min_dist = max(min(distances), 1e-10)
            # 基于距离的概率分布（距离越小概率越大）
            temperatures = max(0.1, 1 - self.current_iterations / (self._total_epoches * len(self._dataset)))
            probabilities = np.exp(-np.array(distances) / (min_dist * temperatures))
            probabilities /= probabilities.sum()  # 归一化

            return np.random.choice(neurons, p=probabilities)
        elif self.winner_selection == "top_k":
            # 选择前k个中最随机的一个
            neurons = list(flatten(self._neurons))
            sorted_neurons = sorted(neurons, key=operator.attrgetter('dist'))
            k = max(1, len(neurons) // 10)  # 前10%
            return np.random.choice(sorted_neurons[:k])
        else:
            # 默认：最小距离
            return min(flatten(self._neurons), key=operator.attrgetter('dist'))

    def _adjust_synaptic_weight(self, winner: SomNeuron):
        for i, row in enumerate(self._neurons):
            if winner in row:
                winner_index = (i, row.index(winner))
                break

        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                distance = dist(winner_index, (i, j))
                neighborhood = self._calculate_neighborhood(distance)

                neuron.synaptic_weight += (
                        self.current_learning_rate
                        * neighborhood
                        * (self.current_data[:-1] - neuron.synaptic_weight)
                )

    def _calculate_neighborhood(self, distance):
        """计算邻域函数"""
        if self.neighborhood_type == NeighborhoodType.LINEAR:
            # 线性衰减
            return max(0, 1 - distance / (self.current_standard_deviation * 2))
        elif self.neighborhood_type == NeighborhoodType.BUBBLE:
            # 矩形函数（只有邻域内更新）
            return 1.0 if distance <= self.current_standard_deviation else 0.0
        elif self.neighborhood_type == NeighborhoodType.EXPONENTIAL:
            # 指数衰减
            return math.exp(-distance / self.current_standard_deviation)
        elif self.neighborhood_type == NeighborhoodType.MEXICAN_HAT:
            # Mexican Hat函数（抑制远距离神经元）
            x = distance / self.current_standard_deviation
            return (1 - x ** 2) * math.exp(-x ** 2 / 2)
        else:
            # 默认高斯函数
            return math.exp(-distance ** 2 / (2 * self.current_standard_deviation ** 2))

    @property
    def current_data(self):
        return self._dataset[self.current_iterations % len(self._dataset)]

    @property
    def current_learning_rate(self):
        progress = self.current_iterations / (self._total_epoches * len(self._dataset))

        if self.learning_rate_decay == LearningRateDecay.LINEAR:
            # 线性衰减
            return self._initial_learning_rate * (1 - progress)
        elif self.learning_rate_decay == LearningRateDecay.INVERSET:
            # 逆时间衰减
            return self._initial_learning_rate / (1 + progress * 10)
        elif self.learning_rate_decay == LearningRateDecay.STEP:
            # 分段衰减
            if progress < 0.3:
                return self._initial_learning_rate
            elif progress < 0.6:
                return self._initial_learning_rate * 0.5
            else:
                return self._initial_learning_rate * 0.1
        else:
            # 默认指数衰减
            return self._initial_learning_rate * math.exp(-progress)

    @property
    def current_standard_deviation(self):
        # 邻域半径也随时间衰减
        progress = self.current_iterations / (self._total_epoches * len(self._dataset))
        return self._initial_standard_deviation * (1 - progress * 0.8)

    # 新增方法：获取网格状态（用于可视化）
    def get_neuron_grid(self):
        """返回神经元权重网格"""
        grid = []
        for row in self._neurons:
            grid_row = []
            for neuron in row:
                grid_row.append(neuron.synaptic_weight.copy())
            grid.append(grid_row)
        return np.array(grid)

    # 新增方法：获取获胜神经元分布
    def get_winner_distribution(self):
        """返回获胜神经元分布统计"""
        if not self.winner_history:
            return None

        distribution = np.zeros(self.topology_shape)
        for winner in self.winner_history:
            for i, row in enumerate(self._neurons):
                if winner in row:
                    j = row.index(winner)
                    distribution[i, j] += 1
                    break
        return distribution

