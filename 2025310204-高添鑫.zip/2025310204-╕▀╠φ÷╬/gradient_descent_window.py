from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QDoubleSpinBox, QPushButton, QTextEdit,
                               QLabel, QSpinBox, QFileDialog, QMessageBox, QComboBox)
from PySide6.QtCore import Slot
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import os

# 确保负号和字体显示正确
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


# 梯度下降优化器基类
class GradientDescentOptimizer:
    def __init__(self, learning_rate=0.01, max_iter=1000, tol=1e-6):
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.tol = tol
        self.loss_history = []
        self.weight_history = []  # 记录权重迭代历史（用于动画）

    def loss_function(self, X, y, weights):
        """MSE损失函数"""
        y_pred = X @ weights
        return np.mean((y - y_pred) ** 2)

    def gradient(self, X, y, weights):
        """计算梯度"""
        y_pred = X @ weights
        return (2 / len(X)) * X.T @ (y_pred - y)

    def optimize_step(self, X, y):
        """单步优化（用于动画），返回是否收敛"""
        raise NotImplementedError("子类必须实现单步优化方法")

    def optimize(self, X, y):
        """完整优化（一次性执行所有步骤）"""
        self.loss_history = []
        self.weight_history = []
        weights = np.zeros((X.shape[1], 1))
        self.weight_history.append(weights.copy())
        self.loss_history.append(self.loss_function(X, y, weights))

        for _ in range(self.max_iter):
            if self.optimize_step(X, y):
                break

        return weights


# 最速下降法 (Steepest Descent)
class SteepestDescent(GradientDescentOptimizer):
    def __init__(self, learning_rate=0.01, max_iter=1000, tol=1e-6):
        super().__init__(learning_rate, max_iter, tol)
        self.weights = None

    def optimize_step(self, X, y):
        """单步优化"""
        if self.weights is None:
            self.weights = np.zeros((X.shape[1], 1))
            self.loss_history.append(self.loss_function(X, y, self.weights))
            self.weight_history.append(self.weights.copy())

        # 计算梯度
        grad = self.gradient(X, y, self.weights)

        # 更新权重
        self.weights -= self.learning_rate * grad
        self.weight_history.append(self.weights.copy())

        # 计算新损失
        new_loss = self.loss_function(X, y, self.weights)
        self.loss_history.append(new_loss)

        # 收敛判断
        if abs(new_loss - self.loss_history[-2]) < self.tol:
            return True  # 收敛
        return False  # 未收敛


# 牛顿梯度法 (Newton's Method)
class NewtonMethod(GradientDescentOptimizer):
    def __init__(self, learning_rate=1.0, max_iter=1000, tol=1e-6, epsilon=1e-6):
        super().__init__(learning_rate, max_iter, tol)
        self.epsilon = epsilon
        self.weights = None

    def hessian(self, X):
        """计算海森矩阵"""
        return (2 / len(X)) * X.T @ X

    def optimize_step(self, X, y):
        """单步优化"""
        if self.weights is None:
            self.weights = np.zeros((X.shape[1], 1))
            self.loss_history.append(self.loss_function(X, y, self.weights))
            self.weight_history.append(self.weights.copy())

        # 计算梯度和海森矩阵
        grad = self.gradient(X, y, self.weights)
        hess = self.hessian(X)
        hess += self.epsilon * np.eye(hess.shape[0])  # 数值稳定

        # 求解牛顿方程
        try:
            delta = np.linalg.solve(hess, -grad)
        except np.linalg.LinAlgError:
            delta = -self.learning_rate * grad  # 降级为梯度下降

        # 更新权重
        self.weights += self.learning_rate * delta
        self.weight_history.append(self.weights.copy())

        # 计算新损失
        new_loss = self.loss_function(X, y, self.weights)
        self.loss_history.append(new_loss)

        # 收敛判断
        if abs(new_loss - self.loss_history[-2]) < self.tol:
            return True
        return False


# 共轭梯度法 (Conjugate Gradient)
class ConjugateGradient(GradientDescentOptimizer):
    def __init__(self, max_iter=1000, tol=1e-6):
        super().__init__(learning_rate=1.0, max_iter=max_iter, tol=tol)
        self.weights = None
        self.grad = None
        self.p = None

    def optimize_step(self, X, y):
        """单步优化"""
        if self.weights is None:
            self.weights = np.zeros((X.shape[1], 1))
            self.grad = self.gradient(X, y, self.weights)
            self.p = -self.grad
            self.loss_history.append(self.loss_function(X, y, self.weights))
            self.weight_history.append(self.weights.copy())

        # 计算步长
        y_pred = X @ self.weights
        r = y - y_pred
        alpha = (r.T @ r) / (self.p.T @ X.T @ X @ self.p)

        # 更新权重
        self.weights += alpha * self.p
        self.weight_history.append(self.weights.copy())

        # 计算新梯度
        new_grad = self.gradient(X, y, self.weights)
        self.loss_history.append(self.loss_function(X, y, self.weights))

        # 收敛判断
        if np.linalg.norm(new_grad) < self.tol:
            return True

        # 更新搜索方向
        beta = (new_grad.T @ new_grad) / (self.grad.T @ self.grad)
        self.p = -new_grad + beta * self.p
        self.grad = new_grad

        return False


class GradientDescentWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None
        self.canvas = None
        self.ax3d = None
        self.ax2d = None
        self.animation = None  # 动画实例
        self.optimizers = {
            '最速下降法 (Steepest Descent)': SteepestDescent,
            '牛顿梯度法 (Newton\'s Method)': NewtonMethod,
            '共轭梯度法 (Conjugate Gradient)': ConjugateGradient
        }
        self.selected_optimizer = None
        self.optimizer_instance = None
        self.X = None
        self.y = None
        self.true_weights = None
        self.w0_grid = None
        self.w1_grid = None
        self.loss_grid = None
        self.init_ui()

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 控制面板
        control_group = QGroupBox("参数设置（梯度下降优化器对比）")
        control_layout = QFormLayout()

        # 选择优化器
        self.optimizer_combo = QComboBox()
        self.optimizer_combo.addItems(self.optimizers.keys())
        self.optimizer_combo.currentTextChanged.connect(self.on_optimizer_changed)
        control_layout.addRow("选择优化器:", self.optimizer_combo)

        # 动态参数布局
        self.dynamic_params_layout = QFormLayout()
        control_layout.addRow(self.dynamic_params_layout)

        # 学习率
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(1e-5, 2.0)
        self.lr_spin.setValue(0.01)
        self.lr_spin.setSingleStep(0.001)
        self.lr_spin.setDecimals(5)
        control_layout.addRow("学习率 (η):", self.lr_spin)

        # 最大迭代次数
        self.max_iter_spin = QSpinBox()
        self.max_iter_spin.setRange(100, 10000)
        self.max_iter_spin.setValue(10)
        self.max_iter_spin.setSingleStep(100)
        control_layout.addRow("最大迭代次数:", self.max_iter_spin)

        # 按钮布局
        button_layout = QHBoxLayout()
        self.gen_data_btn = QPushButton("生成测试数据（线性回归）")
        self.gen_data_btn.clicked.connect(self.generate_test_data)
        self.train_btn = QPushButton("开始优化（动态演示）")
        self.train_btn.clicked.connect(self.start_optimization_animation)
        self.save_btn = QPushButton("保存结果图")
        self.save_btn.clicked.connect(self.save_figure)
        button_layout.addWidget(self.gen_data_btn)
        button_layout.addWidget(self.train_btn)
        button_layout.addWidget(self.save_btn)
        control_layout.addRow(button_layout)

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 结果显示区域
        result_layout = QHBoxLayout()
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用梯度下降优化器对比界面！")
        self.text_output.append("支持：最速下降法、牛顿梯度法、共轭梯度法")
        self.text_output.append("步骤：1. 选择优化器 → 2. 生成数据 → 3. 开始优化（动态演示）")
        result_layout.addWidget(self.text_output, 1)

        # 图形显示
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)
        main_layout.addLayout(result_layout, 1)

        self.on_optimizer_changed(self.optimizer_combo.currentText())

    def initialize_plot(self):
        """初始化绘图区域（3D+2D子图）"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(12, 6), dpi=100)
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']

        # 清空子图并重新创建
        self.figure.clear()
        self.ax3d = self.figure.add_subplot(121, projection='3d')
        self.ax2d = self.figure.add_subplot(122)

        # 初始状态提示
        self.ax3d.text(0.5, 0.5, 0.5, "等待生成数据...", ha='center', va='center',
                       transform=self.ax3d.transAxes, fontsize=14)
        self.ax3d.set_xlabel('w0 (截距)')
        self.ax3d.set_ylabel('w1 (斜率)')
        self.ax3d.set_zlabel('MSE 损失')
        self.ax3d.set_title('损失函数三维曲面与动态优化轨迹')

        self.ax2d.text(0.5, 0.5, "等待优化开始...", ha='center', va='center',
                       transform=self.ax2d.transAxes, fontsize=14)
        self.ax2d.set_xlabel('迭代次数')
        self.ax2d.set_ylabel('MSE 损失（对数坐标）')
        self.ax2d.set_title('损失函数变化曲线（动态更新）')
        self.ax2d.set_yscale('log')

        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        self.canvas.draw()

    @Slot(str)
    def on_optimizer_changed(self, optimizer_name):
        """优化器选择变化时更新参数面板"""
        self.selected_optimizer = self.optimizers[optimizer_name]
        while self.dynamic_params_layout.rowCount() > 0:
            self.dynamic_params_layout.removeRow(0)

        # 牛顿法添加正则化参数
        if self.selected_optimizer == NewtonMethod:
            self.epsilon_spin = QDoubleSpinBox()
            self.epsilon_spin.setRange(1e-10, 1e-3)
            self.epsilon_spin.setValue(1e-6)
            self.epsilon_spin.setDecimals(10)
            self.dynamic_params_layout.addRow("正则化参数 (ε):", self.epsilon_spin)

        # 共轭梯度法不需要学习率，禁用学习率控件
        if self.selected_optimizer == ConjugateGradient:
            self.lr_spin.setEnabled(False)
        else:
            self.lr_spin.setEnabled(True)

    @Slot()
    def generate_test_data(self):
        """生成线性回归测试数据并预计算损失网格"""
        self.text_output.append("\n[步骤1] 生成线性回归测试数据...")

        # 生成数据
        x = np.linspace(0, 10, 100).reshape(-1, 1)
        self.X = np.hstack((np.ones((100, 1)), x))
        self.true_weights = np.array([[2.5], [1.3]])
        self.y = self.X @ self.true_weights + 0.8 * np.random.randn(100, 1)

        self.text_output.append(f"生成 {len(self.X)} 个样本（特征维度：{self.X.shape[1] - 1}）")
        self.text_output.append(f"真实模型：y = {self.true_weights[0][0]:.2f} + {self.true_weights[1][0]:.2f}*x + 噪声")

        # 计算损失函数网格（用于3D曲面）
        self.calculate_loss_grid()

        # 绘制3D曲面和初始数据
        self.plot_loss_surface()
        self.ax2d.clear()
        self.ax2d.scatter(x, self.y, label='训练数据（带噪声）', color='#ff7f0e', alpha=0.6, s=30)
        self.ax2d.plot(x, self.X @ self.true_weights, 'k-',
                       label=f'真实模型：y={self.true_weights[0][0]:.2f}+{self.true_weights[1][0]:.2f}x', linewidth=2)
        self.ax2d.set_xlabel('X（特征）')
        self.ax2d.set_ylabel('Y（标签）')
        self.ax2d.legend()
        self.ax2d.grid(True, alpha=0.3)
        self.ax2d.set_yscale('linear')

        self.canvas.draw()

    def calculate_loss_grid(self):
        """计算损失函数的3D网格数据"""
        # 围绕真实权重设置网格范围
        w0_min, w0_max = self.true_weights[0][0] - 4, self.true_weights[0][0] + 4
        w1_min, w1_max = self.true_weights[1][0] - 2, self.true_weights[1][0] + 2

        # 创建网格点
        self.w0_grid, self.w1_grid = np.meshgrid(
            np.linspace(w0_min, w0_max, 50),
            np.linspace(w1_min, w1_max, 50)
        )

        # 计算每个网格点的损失
        self.loss_grid = np.zeros_like(self.w0_grid)
        for i in range(self.w0_grid.shape[0]):
            for j in range(self.w0_grid.shape[1]):
                weights = np.array([[self.w0_grid[i, j]], [self.w1_grid[i, j]]])
                self.loss_grid[i, j] = self.loss_function(self.X, self.y, weights)

    def loss_function(self, X, y, weights):
        """MSE损失函数"""
        y_pred = X @ weights
        return np.mean((y - y_pred) ** 2)

    def plot_loss_surface(self):
        """绘制3D损失曲面（不含图例）"""
        self.ax3d.clear()
        # 绘制曲面
        surf = self.ax3d.plot_surface(
            self.w0_grid, self.w1_grid, self.loss_grid,
            cmap='viridis', alpha=0.7, edgecolor='none'
        )
        # 添加颜色条（保留颜色条，仅删除图例）
        self.figure.colorbar(surf, ax=self.ax3d, shrink=0.5, aspect=5, label='MSE 损失')
        # 标记真实最优解（不添加图例标签）
        true_loss = self.loss_function(self.X, self.y, self.true_weights)
        self.ax3d.scatter(
            self.true_weights[0][0], self.true_weights[1][0], true_loss,
            color='red', s=100, zorder=5  # 移除label参数
        )
        self.ax3d.set_xlabel('w0 (截距)')
        self.ax3d.set_ylabel('w1 (斜率)')
        self.ax3d.set_zlabel('MSE 损失')
        self.ax3d.set_title('损失函数三维曲面与动态优化轨迹')

    @Slot()
    def start_optimization_animation(self):
        """开始优化动画"""
        if self.X is None or self.y is None:
            self.text_output.append("\n[错误] 请先生成测试数据！")
            QMessageBox.warning(self, "警告", "请先点击「生成测试数据」按钮！").exec()
            return

        # 初始化优化器实例
        self.text_output.append("\n[步骤2] 开始动态优化演示...")
        lr = self.lr_spin.value() if self.lr_spin.isEnabled() else 1.0
        max_iter = self.max_iter_spin.value()

        if self.selected_optimizer == SteepestDescent:
            self.optimizer_instance = SteepestDescent(learning_rate=lr, max_iter=max_iter)
        elif self.selected_optimizer == NewtonMethod:
            self.optimizer_instance = NewtonMethod(
                learning_rate=lr, max_iter=max_iter,
                epsilon=self.epsilon_spin.value()
            )
        elif self.selected_optimizer == ConjugateGradient:
            self.optimizer_instance = ConjugateGradient(max_iter=max_iter)

        # 重置动画相关状态
        self.optimizer_instance.weights = None
        self.optimizer_instance.loss_history = []
        self.optimizer_instance.weight_history = []

        # 绘制初始状态（第0步）
        self.plot_loss_surface()
        self.ax2d.clear()
        self.ax2d.set_xlabel('迭代次数')
        self.ax2d.set_ylabel('MSE 损失（对数坐标）')
        self.ax2d.set_title('损失函数变化曲线（动态更新）')
        self.ax2d.set_yscale('log')
        self.ax2d.grid(True, alpha=0.3)

        # 启动动画
        self.animation = FuncAnimation(
            self.figure, self.update_animation,
            frames=self.get_animation_frames(),
            interval=200,  # 每帧间隔200ms（可调整速度）
            blit=False,  # 关闭blit以避免3D动画闪烁
            repeat=False
        )

        self.canvas.draw()

    def get_animation_frames(self):
        """生成动画帧（迭代步数）"""
        frames = []
        # 执行优化直到收敛或达到最大迭代次数
        for i in range(self.optimizer_instance.max_iter):
            if self.optimizer_instance.optimize_step(self.X, self.y):
                frames.append(i + 1)
                break
            frames.append(i + 1)
        return frames

    def update_animation(self, frame):
        """动画帧更新函数（不含3D图例）"""
        # 获取当前迭代的权重和损失
        weight_history = self.optimizer_instance.weight_history[:frame + 1]
        loss_history = self.optimizer_instance.loss_history[:frame + 1]

        # 3D图更新：绘制轨迹（不含图例）
        self.plot_loss_surface()  # 重绘曲面
        w0 = [w[0][0] for w in weight_history]
        w1 = [w[1][0] for w in weight_history]
        loss = loss_history

        # 绘制轨迹线和点（不添加图例标签）
        self.ax3d.plot(w0, w1, loss, color='blue', linewidth=2)
        self.ax3d.scatter(w0[0], w1[0], loss[0], color='green', s=80, zorder=6)
        self.ax3d.scatter(w0[-1], w1[-1], loss[-1], color='orange', s=80, zorder=6)

        # 2D图更新：绘制损失曲线（保留2D图例）
        self.ax2d.clear()
        self.ax2d.plot(range(len(loss_history)), loss_history, 'b-', linewidth=1.5, label='损失变化')
        self.ax2d.scatter(len(loss_history) - 1, loss_history[-1], color='orange', s=50, label=f'第{frame}步损失')
        self.ax2d.set_xlabel('迭代次数')
        self.ax2d.set_ylabel('MSE 损失（对数坐标）')
        self.ax2d.set_title(f'损失函数变化曲线（第{frame}步）')
        self.ax2d.set_yscale('log')
        self.ax2d.legend()
        self.ax2d.grid(True, alpha=0.3)

        # 文本输出更新
        if frame == len(self.optimizer_instance.weight_history) - 1:
            self.text_output.append(f"\n优化完成！总迭代次数：{frame}")
            self.text_output.append(f"最终损失（MSE）：{loss_history[-1]:.6f}")
            self.text_output.append(f"优化后权重：w0={w0[-1]:.4f}, w1={w1[-1]:.4f}")
            self.text_output.append(f"真实权重：w0={self.true_weights[0][0]:.4f}, w1={self.true_weights[1][0]:.4f}")

        return self.ax3d, self.ax2d

    @Slot()
    def save_figure(self):
        """保存最终结果图"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先运行优化，生成结果图后再保存！").exec()
            return

        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存梯度下降动态结果图",
            os.path.join(os.getcwd(), "gradient_descent_3d_animation_result.png"),
            "图片文件 (*.png *.jpg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        try:
            # 保存动画最终帧
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 最终结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}").exec()
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}").exec()