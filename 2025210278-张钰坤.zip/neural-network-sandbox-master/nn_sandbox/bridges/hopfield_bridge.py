import PyQt5.QtCore
import numpy as np

from .bridge import Bridge, BridgeProperty
from ..backend.algorithms.hopfield_algorithm import HopfieldAlgorithm


class HopfieldBridge(Bridge):
    dataset_dict = BridgeProperty({})
    patterns = BridgeProperty([])
    currentState = BridgeProperty([])
    attractor = BridgeProperty([])
    energy = BridgeProperty(0.0)
    status = BridgeProperty('Idle')
    isTrained = BridgeProperty(False)

    def __init__(self):
        super().__init__()
        self._algorithm = HopfieldAlgorithm()
        self._pattern_size = 0

    @PyQt5.QtCore.pyqtSlot('QVariantList')
    def train(self, raw_patterns):
        """Train the Hopfield network with a list of patterns."""
        patterns = self._normalize_patterns(raw_patterns)
        if not patterns:
            self.status = 'Training failed: provide at least one pattern.'
            return

        lengths = {len(p) for p in patterns}
        if len(lengths) != 1:
            self.status = 'Training failed: all patterns must have the same length.'
            return

        self._pattern_size = lengths.pop()
        self._algorithm.train(patterns)
        self.patterns = [p.tolist() for p in patterns]
        self.currentState = []
        self.attractor = []
        self.energy = 0.0
        self.isTrained = True
        self.status = f'Training complete: stored {len(self.patterns)} patterns.'

    @PyQt5.QtCore.pyqtSlot('QVariantList', int)
    def run_async_update(self, initial_state, max_iters=100):
        """Run asynchronous updates starting from an initial pattern."""
        if not self.isTrained:
            self.status = 'Train the network first.'
            return

        state = self._normalize_pattern(initial_state)
        if state is None:
            self.status = 'Invalid initial state.'
            return
        if len(state) != self._pattern_size:
            self.status = 'Initial state length mismatch.'
            return

        generator = self._algorithm.predict(state, max_iters=max_iters)
        final_result = None

        try:
            while True:
                step = next(generator)
                final_result = step
                self.currentState = step['state'].tolist()
                self.energy = float(step['energy'])
                PyQt5.QtCore.QCoreApplication.processEvents()
        except StopIteration as stop:
            if stop.value is not None:
                final_result = stop.value

        if final_result is None:
            final_state = state
            final_energy = float(self._algorithm.calculate_energy(state))
        else:
            final_state = final_result['state']
            final_energy = float(final_result['energy'])

        self.currentState = final_state.tolist()
        self.attractor = final_state.tolist()
        self.energy = final_energy
        self.status = 'Converged to attractor.'

    @PyQt5.QtCore.pyqtSlot()
    def reset(self):
        """Reset the bridge state without clearing learned patterns."""
        self.currentState = []
        self.attractor = []
        self.energy = 0.0
        self.status = 'Cleared current state.'

    def _normalize_patterns(self, raw_patterns):
        return [p for p in (self._normalize_pattern(pattern) for pattern in raw_patterns) if p is not None]

    def _normalize_pattern(self, pattern):
        values = list(pattern)
        if not values:
            return None
        arr = np.array(values, dtype=float)
        # Convert any non-zero value to 1, zeros to -1 to keep bipolar form.
        arr = np.where(arr >= 0, 1, -1)
        return arr
