# -*- coding: utf-8 -*-
"""
Common utilities used by backend algorithms.
本文件在原 sigmoid 的基础上，新增 bipolar_sigmoid（双极性 sigmoid）。
"""

import pathlib
import math
import numpy as np


def sigmoid(value: float) -> float:
    """单极性 Sigmoid: 1 / (1 + e^-x)  →  (0,1)"""
    return 1.0 / (1.0 + math.exp(-value))


def bipolar_sigmoid(value: float) -> float:
    """双极性 Sigmoid: (1 - e^-x) / (1 + e^-x) = tanh(x/2)  →  (-1,1)"""
    e = math.exp(-value)
    return (1.0 - e) / (1.0 + e)

# 高斯径向基函数（兼容两种常见调用方式）
# 1) gaussian(distance, sigma)
# 2) gaussian(x_vec, center_vec, beta)
import math
import numpy as np

def gaussian(*args):
    """
    兼容：
      - gaussian(distance, sigma)
      - gaussian(x_vec, center_vec, beta)
    """
    if len(args) == 2:
        distance, sigma = args
        d = float(distance)
        s = float(sigma)
        return math.exp(-(d * d) / (2.0 * s * s))
    elif len(args) == 3:
        x, center, beta = args
        diff = np.asarray(x, dtype=float) - np.asarray(center, dtype=float)
        r2 = float(np.dot(diff, diff))
        return math.exp(-float(beta) * r2)
    else:
        raise TypeError("gaussian expects (distance, sigma) or (x, center, beta)")

# 欧氏距离（兼容标量/列表/ndarray，自动扁平化）
def dist(a, b):
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    # 长度不一致时，尽量对齐较短者（与项目内典型用法兼容）
    n = min(a.size, b.size)
    if n == 0:
        return 0.0
    return float(np.linalg.norm(a[:n] - b[:n]))

# 符号函数：标量/向量均可
def sign(x):
    arr = np.asarray(x)
    if arr.ndim == 0:  # 标量
        v = float(arr)
        if v > 0:
            return 1
        elif v < 0:
            return -1
        else:
            return 0
    # 向量/数组
    return np.where(arr > 0, 1, np.where(arr < 0, -1, 0))

# 将嵌套的序列/数组拍平成一维列表（SOM 等算法会用到）
def flatten(obj):
    """
    支持 list / tuple / set / numpy.ndarray 的任意嵌套；
    字符串当作标量处理，不会被逐字符展开。
    返回一维 Python list。
    """
    if isinstance(obj, np.ndarray):
        return obj.ravel().tolist()
    if isinstance(obj, (list, tuple, set)):
        out = []
        for item in obj:
            out.extend(flatten(item))
        return out
    # 标量或其它类型
    return [obj]

# ---------- Toy datasets for the app ----------

def _stack_xy_label(xy: np.ndarray, label: int):
    """把二维坐标拼上标签列；统一为 float 数组。"""
    lab = np.full((xy.shape[0], 1), float(label), dtype=float)
    return np.hstack([xy.astype(float), lab])

def _make_linear(n=200, seed=0):
    rng = np.random.default_rng(seed)
    xy = rng.uniform(-1, 1, size=(n, 2))
    # 随机一条分割线：ax + by + c = 0
    a, b = rng.normal(size=2)
    c = rng.normal()
    y = (a*xy[:,0] + b*xy[:,1] + c >= 0).astype(float)
    return np.hstack([xy, y[:, None]])

def _make_xor(n=400, seed=1):
    rng = np.random.default_rng(seed)
    xy = rng.uniform(-1, 1, size=(n, 2))
    y = ((xy[:,0] > 0) ^ (xy[:,1] > 0)).astype(float)
    # 加一点噪声更有意思
    xy += rng.normal(scale=0.05, size=xy.shape)
    return np.hstack([xy, y[:, None]])

def _make_circles(n=400, seed=2):
    """两圈同心圆（内圈=0，外圈=1），带少量噪声。"""
    rng = np.random.default_rng(seed)
    n1 = n//2; n2 = n - n1
    r1 = 0.35 + 0.02*rng.standard_normal(n1)
    r2 = 0.75 + 0.02*rng.standard_normal(n2)
    t1 = rng.uniform(0, 2*np.pi, size=n1)
    t2 = rng.uniform(0, 2*np.pi, size=n2)
    x1 = np.c_[r1*np.cos(t1), r1*np.sin(t1)]
    x2 = np.c_[r2*np.cos(t2), r2*np.sin(t2)]
    x1 += rng.normal(scale=0.02, size=x1.shape)
    x2 += rng.normal(scale=0.02, size=x2.shape)
    return np.vstack([_stack_xy_label(x1, 0), _stack_xy_label(x2, 1)])

def _make_gaussians(n=400, seed=3):
    rng = np.random.default_rng(seed)
    n1 = n//2; n2 = n - n1
    m1 = np.array([-0.5, -0.2]);  C1 = np.array([[0.08, 0.0],[0.0, 0.04]])
    m2 = np.array([ 0.5,  0.3]);  C2 = np.array([[0.06, 0.02],[0.02, 0.06]])
    x1 = rng.multivariate_normal(m1, C1, size=n1)
    x2 = rng.multivariate_normal(m2, C2, size=n2)
    return np.vstack([_stack_xy_label(x1, 0), _stack_xy_label(x2, 1)])

def _make_spiral(n=600, seed=4):
    """经典双螺旋：非线性可分，适合测 MLP/RBFN。"""
    rng = np.random.default_rng(seed)
    n1 = n//2; n2 = n - n1
    t1 = np.linspace(0, 3*np.pi, n1)
    t2 = t1 + np.pi
    r1 = np.linspace(0.1, 0.9, n1)
    r2 = np.linspace(0.1, 0.9, n2)
    x1 = np.c_[r1*np.cos(t1), r1*np.sin(t1)] + rng.normal(scale=0.02, size=(n1,2))
    x2 = np.c_[r2*np.cos(t2), r2*np.sin(t2)] + rng.normal(scale=0.02, size=(n2,2))
    return np.vstack([_stack_xy_label(x1, 0), _stack_xy_label(x2, 1)])

def read_data() -> dict:
    """
    供 main.py 使用：返回 {数据集名称: ndarray}。
    ndarray 形状为 [N, D+1]，最后一列是标签 y ∈ {0,1}。
    SOM 等无监督算法只会用到前两列特征；感知机/MLP/RBFN 会用到标签。
    """
    data = {
        "Linear (separable)": _make_linear(240, seed=0),
        "XOR": _make_xor(400, seed=1),
        "Two Circles": _make_circles(480, seed=2),
        "Two Gaussians": _make_gaussians(480, seed=3),
        "Double Spiral": _make_spiral(600, seed=4),
    }
    # 统一打乱一下，避免顺序偏差
    for k, arr in list(data.items()):
        idx = np.random.default_rng(2024).permutation(arr.shape[0])
        data[k] = arr[idx]
    return data




# 若你的项目里 utils.py 还有其它工具函数，保持原样放在本文件任意位置即可。
