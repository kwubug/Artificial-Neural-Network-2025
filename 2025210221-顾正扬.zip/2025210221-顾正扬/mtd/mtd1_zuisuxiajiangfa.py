import pandas as pd


def main1():
    data = []

    # 最速下降法更新最小值
    def F(x: list):
        # A = [[2, 0], [0, 50]]
        return x[1] ** 2 + 25 * x[2] ** 2

    def g_F(x: list):
        return [2 * x[1], 50 * x[2]]

    def lr(mtd: int):
        # 1，2、为静态学习率，3，4、为稳定学习率的 ± 0.001
        if mtd == 1:
            return 0.01
        if mtd == 2:
            return 0.035
        if mtd == 3:
            # A = [[2, 0], [0, 50]]
            lbd_A = [2, 50]
            return 2 / max(lbd_A) - 0.001
        if mtd == 4:
            # A = [[2, 0], [0, 50]]
            lbd_A = [2, 50]
            return 2 / max(lbd_A) + 0.001

    def learn(mtd: int, x: list):
        g = g_F(x)
        n = lr(mtd)
        # delta_x = 学习率乘以反方向梯度
        for i in range(2):
            x[i + 1] = x[i + 1] - n * g[i]
        print(f'1_本次学习率为：{n}')
        print(f'2_本次迭代结果：{x}')
        return True

    # 解析解为x = [1, 0, 0]
    mtd = 1
    # 设置初始值x=[1,0.5,0.5]，x[0]表示数据类型，1为数据类型，其他为数据值
    x = [1, 0.5, 0.5]
    print(x)
    data.append({'x1': x[1], 'x2': x[2]})

    for i in range(50):
        learn(mtd, x)
        data.append({'x1': x[1], 'x2': x[2]})

    df = pd.DataFrame(data)
    df.to_excel(f"m1_F1_{mtd}.xlsx", index=False)


main1()


# 直线最小化
def main2():
    data = []

    def F(x: list):
        return x[1] ** 2 + x[1] * x[2] + x[2] ** 2

    def g_F(x: list):
        return [2 * x[1] + x[2], 2 * x[2] + x[1]]

    def lr(x: list):
        g = g_F(x)
        A = [[2, 1], [1, 2]]

        n = 0
        for i in g:
            n += i ** 2

        s1 = [g[0] * A[0][0] + g[1] * A[1][0], g[0] * A[0][1] + g[1] * A[1][1]]
        m = s1[0] * g[0] + s1[1] * g[1]

        return n / m

    def learn(x: list):
        g = g_F(x)
        n = lr(x)
        for i in range(2):
            x[i + 1] = x[i + 1] - n * g[i]
        print(f'1_本次学习率为：{n}')
        print(f'2_本次迭代结果：{x}')
        return True

    x = [1, 0.8, -0.25]
    data.append({'x1': x[1], 'x2': x[2]})
    print(x)
    for i in range(5):
        learn(x)
        data.append({'x1': x[1], 'x2': x[2]})

    df = pd.DataFrame(data)
    df.to_excel(f"m1_F2.xlsx", index=False)

# main2()
