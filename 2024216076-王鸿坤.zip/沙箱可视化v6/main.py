import os
import sys

from PyQt5.QtQml import QQmlApplicationEngine
from PyQt5.QtCore import QObject
from PyQt5.QtWidgets import QApplication
from nn_sandbox.bridges import (
    PerceptronBridge,
    MlpBridge,
    RbfnBridge,
    SomBridge,
    BpBridge,
    HopfieldBridge,
    BoltzmannBridge,
    TspBridge,
)
import nn_sandbox.backend.utils


def handle_qml_errors(warnings):
    for warning in warnings:
        print(f"QML Warning: {warning.toString()}")


if __name__ == '__main__':
    try:
        os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

        # 使用 QApplication 而不是 QGuiApplication，确保 QML 图表库加载正常
        app = QApplication(sys.argv)
        engine = QQmlApplicationEngine()

        # 捕获 QML 警告和错误
        engine.warnings.connect(handle_qml_errors)

        # 初始化 bridge 对象
        bridges = {
            'perceptronBridge': PerceptronBridge(),
            'mlpBridge': MlpBridge(),
            'rbfnBridge': RbfnBridge(),
            'somBridge': SomBridge(),
            'bpBridge': BpBridge(),
            'hopfieldBridge': HopfieldBridge(),
            'boltzmannBridge': BoltzmannBridge(),
            'tspBridge': TspBridge(),
        }

        for name in bridges:
            # TspBridge不需要dataset_dict
            if hasattr(bridges[name], 'dataset_dict'):
                bridges[name].dataset_dict = nn_sandbox.backend.utils.read_data()
            engine.rootContext().setContextProperty(name, bridges[name])

        # 加载 QML 界面
        engine.load('./nn_sandbox/frontend/main.qml')

        # 检查是否成功加载 QML 文件
        if not engine.rootObjects():
            print("Error: QML file did not load correctly.")
            sys.exit(-1)

        sys.exit(app.exec_())

    except Exception as e:
        print(f"An error occurred: {e}")



