import numpy as np
import time
from .base_algorithm import TraningAlgorithm


class HopfieldAlgorithm(TraningAlgorithm):
    """
    2D Discrete Hopfield Network with asynchronous updates.
    Supports pattern storage via Hebbian rule, noise corruption, and real-time recovery visualization.
    """
    def __init__(self, n_dim=8, patterns=None, selected_pattern_idx=0, noise_level=0.25,
                 max_iter=2000, ui_refresh_interval=0.01):
        super().__init__(dataset=[], total_epoches=1)
        self.n_dim = int(n_dim)
        self.size = self.n_dim * self.n_dim
        self.patterns = patterns if patterns is not None else []
        self.selected_pattern_idx = int(selected_pattern_idx)
        self.noise_level = float(noise_level)
        self.max_iter = int(max_iter)
        self.ui_refresh_interval = float(ui_refresh_interval)
        
        self.weights = np.zeros((self.size, self.size))
        self.original_pattern = None  # The selected pattern before corruption
        self.corrupted_state = None   # The corrupted initial state
        self.current_state = None
        self.current_iter = 0
        self.energy = 0.0
        self.has_finished = True

    def _store_patterns(self, patterns):
        """Store patterns using Hebbian rule (as in hop.py)."""
        if not patterns or len(patterns) == 0:
            return
        # Convert patterns to numpy array
        patterns_array = np.array([np.asarray(p, dtype=float).reshape(-1) for p in patterns])
        # Hebb rule: W = patterns.T @ patterns
        self.weights = patterns_array.T @ patterns_array
        # Remove self-connections (W_ii = 0)
        np.fill_diagonal(self.weights, 0.0)

    def _compute_energy(self, state_vec):
        """Compute network energy."""
        return -0.5 * float(np.dot(state_vec, self.weights @ state_vec))

    def _corrupt_pattern(self, pattern, noise_level):
        """Corrupt pattern by randomly flipping (noise_level * 100)% of bits."""
        corrupted = pattern.copy().reshape(-1)
        n_neurons = len(corrupted)
        n_to_flip = int(n_neurons * noise_level)
        
        if n_to_flip > 0:
            indices_to_flip = np.random.choice(n_neurons, size=min(n_to_flip, n_neurons), replace=False)
            corrupted[indices_to_flip] *= -1
        
        return corrupted

    def _update_single_neuron(self, state, neuron_index):
        """
        Update a single neuron asynchronously (as in hop.py).
        Returns: (new_state, h_i, state_changed)
        """
        n = len(state)
        x_new = state.copy()
        
        h_i = float(np.dot(self.weights[neuron_index, :], state))
        
        if h_i > 0:
            x_new[neuron_index] = 1
        elif h_i < 0:
            x_new[neuron_index] = -1
        # else: keep current value (h_i == 0)
        
        state_changed = (x_new[neuron_index] != state[neuron_index])
        
        return x_new, h_i, state_changed

    def run(self):
        self.has_finished = False
        
        # Validate patterns
        if not self.patterns or len(self.patterns) == 0:
            if hasattr(self, 'notify'):
                self.notify('has_finished', True)
            return
        
        if self.selected_pattern_idx < 0 or self.selected_pattern_idx >= len(self.patterns):
            if hasattr(self, 'notify'):
                self.notify('has_finished', True)
            return
        
        # Store patterns
        self._store_patterns(self.patterns)
        
        # Get selected pattern and corrupt it
        selected_pattern = np.asarray(self.patterns[self.selected_pattern_idx], dtype=float)
        self.original_pattern = selected_pattern.reshape(-1).copy()
        self.corrupted_state = self._corrupt_pattern(selected_pattern, self.noise_level)
        self.current_state = self.corrupted_state.copy()
        self.current_iter = 0
        self.energy = self._compute_energy(self.current_state)
        
        # Notify initial state
        if hasattr(self, 'notify'):
            self.notify('has_finished', False)
            self.notify('original_pattern', self.original_pattern.tolist())
            self.notify('corrupted_state', self.corrupted_state.tolist())
            self.notify('current_state', self.current_state.tolist())
            self.notify('current_iter', self.current_iter)
            self.notify('current_energy', self.energy)
        
        # Iterate until convergence or max_iter
        # As in hop.py: round-robin through neurons, one at a time
        consecutive_unchanged_steps = 0
        
        for k in range(1, self.max_iter + 1):
            if self._should_stop:
                break
            
            # Round-robin: select neuron i = (k-1) % n
            i = (k - 1) % self.size
            
            x_old = self.current_state.copy()
            
            # Update single neuron asynchronously
            x_new, h_i, changed = self._update_single_neuron(x_old, i)
            
            # Update state
            self.current_state = x_new
            self.current_iter = k
            self.energy = self._compute_energy(self.current_state)
            
            if hasattr(self, 'notify'):
                self.notify('current_state', self.current_state.tolist())
                self.notify('current_iter', self.current_iter)
                self.notify('current_energy', self.energy)
            
            if self.ui_refresh_interval > 0:
                time.sleep(self.ui_refresh_interval)
            
            # Check convergence: if no changes for n consecutive steps (one full round), network is stable
            if changed:
                consecutive_unchanged_steps = 0  # Reset counter
            else:
                consecutive_unchanged_steps += 1
            
            # If n consecutive steps with no changes, network has converged
            if consecutive_unchanged_steps == self.size:
                break
        
        # Finished
        self.has_finished = True
        if hasattr(self, 'notify'):
            self.notify('has_finished', True)
            self.notify('attractor_state', self.current_state.tolist())
            self.notify('attractor_energy', self.energy)


