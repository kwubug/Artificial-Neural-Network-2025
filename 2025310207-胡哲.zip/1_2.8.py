import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"  # 设置环境变量，允许多个 OpenMP 运行时并行


# 定义激活函数及其导数
def sigmoid(x):
    return 1 / (1 + torch.exp(-x))  # Sigmoid激活函数


def sigmoid_derivative(x):
    return sigmoid(x) * (1 - sigmoid(x))  # Sigmoid的导数


def relu(x):
    return torch.maximum(x, torch.zeros_like(x))  # ReLU激活函数


def relu_derivative(x):
    return torch.where(x > 0, torch.ones_like(x), torch.zeros_like(x))  # ReLU导数


def bipolar_continuous(x):
    return 2 / (1 + torch.exp(-x)) - 1  # 双极性连续型激活函数


def bipolar_continuous_derivative(x):
    return 1 - bipolar_continuous(x) ** 2  # 双极性连续型激活函数的导数


# 定义Hebbian学习规则
def hebbian_update(weights, inputs, output, lr=0.01):
    return weights + lr * torch.outer(inputs, output)  # 更新权重


# 定义最小均方误差（LMS）学习规则
def lms_update(weights, inputs, target_output, output, lr=0.01):
    error = target_output - output  # 计算误差
    return weights + lr * error * inputs  # 更新权重


# 定义Delta学习规则
def delta_update(weights, inputs, target_output, output, net_input, lr=0.01, activation_func='sigmoid'):
    error = target_output - output  # 计算误差

    # 根据激活函数选择导数
    if activation_func == 'sigmoid':
        derivative = sigmoid_derivative(net_input)  # Sigmoid导数
    elif activation_func == 'relu':
        derivative = relu_derivative(net_input)  # ReLU导数
    elif activation_func == 'bipolar':
        derivative = bipolar_continuous_derivative(net_input)  # Bipolar Continuous导数

    return weights + lr * error * inputs * derivative  # 更新权重


# 定义简单的神经网络（单层感知机，可变激活函数）
class SimpleNN(nn.Module):
    def __init__(self, input_size, output_size, weights=None, activation_func='sigmoid'):
        super(SimpleNN, self).__init__()

        # 如果没有传入权重，则使用给定的权重
        if weights is None:
            self.weights = nn.Parameter(torch.randn(input_size, output_size))  # 随机初始化权重
        else:
            self.weights = nn.Parameter(weights)  # 使用给定的权重初始化

        self.activation_func = activation_func  # 激活函数类型

    def forward(self, x):
        net_input = torch.matmul(x, self.weights)  # 计算加权输入（没有偏置项）

        # 根据选择的激活函数进行处理
        if self.activation_func == 'sigmoid':
            output = sigmoid(net_input)
        elif self.activation_func == 'relu':
            output = relu(net_input)
        elif self.activation_func == 'bipolar':
            output = bipolar_continuous(net_input)

        return output, net_input  # 返回输出和加权输入


# 训练过程和权重更新（增加记录净输入变化）
def train_with_net_input(model, data, targets, learning_rule, lr=0.01, epochs=10):
    all_weights = []  # 用于存储每一步的权重向量
    all_net_inputs = []  # 用于存储每一步的净输入

    for epoch in range(epochs):
        for i in range(len(data)):
            inputs = data[i]
            target = targets[i]
            output, net_input = model(inputs)  # 获取输出和加权输入

            # 记录净输入
            all_net_inputs.append(net_input[0].cpu().detach().numpy())  # 选择第一个元素，避免维度不一致

            # 根据不同的学习规则更新权重
            if learning_rule == "hebbian":
                model.weights.data = hebbian_update(model.weights.data, inputs, output, lr)
            elif learning_rule == "lms":
                model.weights.data = lms_update(model.weights.data, inputs, target, output, lr)
            elif learning_rule == "delta":
                model.weights.data = delta_update(model.weights.data, inputs, target, output, net_input, lr,
                                                  model.activation_func)

            # 记录每一步的权重向量
            all_weights.append(model.weights.data.clone())

    return all_weights, np.array(all_net_inputs)  # 返回净输入和权重


# 可视化学习率对权向量和净输入的影响
def visualize_weight_and_net_input_vectors(data, targets, learning_rules, learning_rates, activation_funcs):
    for rule in learning_rules:
        for activation_func in activation_funcs:
            # 净输入图
            plt.figure(figsize=(10, 6))
            plt.title(f"Net Input Vectors over Epochs using {rule} Rule with {activation_func} Activation")
            colors = ['b', 'g', 'r']  # Blue, Green, Red for lr=0.01, lr=0.1, lr=0.001
            labels = ['lr=0.01', 'lr=0.1', 'lr=0.001']  # 对应的学习率标签

            for idx, lr in enumerate(learning_rates):
                model = SimpleNN(input_size=6, output_size=1, activation_func=activation_func)  # 使用给定的权重
                all_weights, all_net_inputs = train_with_net_input(model, data, targets, learning_rule=rule, lr=lr,
                                                                   epochs=10)  # 训练10次
                all_net_inputs_np = all_net_inputs[:]  # 只绘制Net Input 1

                # 绘制净输入变化曲线
                plt.plot(all_net_inputs_np, label=f'Net Input 1 {labels[idx]}', linestyle='--',
                         color=colors[idx])  # 只绘制Net Input 1

            plt.xlabel("Epochs")
            plt.ylabel("Net Input Value")
            plt.legend()
            plt.show()

            # 权重图
            plt.figure(figsize=(10, 6))
            plt.title(f"Weight Vectors over Epochs using {rule} Rule with {activation_func} Activation")

            for idx, lr in enumerate(learning_rates):
                model = SimpleNN(input_size=6, output_size=1, activation_func=activation_func)  # 使用给定的权重
                all_weights, all_net_inputs = train_with_net_input(model, data, targets, learning_rule=rule, lr=lr,
                                                                   epochs=10)  # 训练10次
                all_weights_np = torch.stack(all_weights).cpu().numpy()  # 将所有权重向量转为numpy数组

                # 绘制权重变化曲线
                plt.plot(all_weights_np[:, 0], label=f'Weight 1 {labels[idx]}', color=colors[idx])  # 只绘制Weight 1

            plt.xlabel("Epochs")
            plt.ylabel("Weight Value")
            plt.legend()
            plt.show()


# 训练样本数据（假设为6维输入）
data = torch.tensor([
    [0, 0, 0, 0, 0, 0],
    [0, 1, 0, 1, 0, 1],
    [1, 0, 1, 0, 1, 0],
    [1, 1, 1, 1, 1, 1],
], dtype=torch.float32)  # 显式指定为float32

# 目标输出数据（假设为1维输出）
targets = torch.tensor([
    [0.0],
    [1.0],
    [1.0],
    [0.0],
], dtype=torch.float32)  # 显式指定为float32

# 定义学习规则和学习率
learning_rules = ["hebbian", "delta", "lms"]  # 包括Hebbian、Delta和LMS规则
learning_rates = [0.01, 0.1, 0.001]  # 不同的学习率
activation_funcs = ['sigmoid', 'relu', 'bipolar']  # 包括sigmoid, relu, bipolar

# 权重
weights = torch.tensor([[1.5907], [1.1105], [0.6849], [0.4039], [0.0497], [0.6938]], dtype=torch.float32)

# 可视化不同学习率下的权向量和净输入变化
visualize_weight_and_net_input_vectors(data, targets, learning_rules, learning_rates, activation_funcs)
