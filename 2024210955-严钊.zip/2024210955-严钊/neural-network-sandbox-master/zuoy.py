import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Rectangle, Circle


class SOM:
    def __init__(self, grid_size=(5, 5), input_dim=4):
        self.grid_size = grid_size
        self.input_dim = input_dim
        # 更好的权重初始化
        self.weights = np.random.uniform(0, 1, (grid_size[0], grid_size[1], input_dim))

    def find_bmu(self, x):
        """Find Best Matching Unit"""
        distances = np.linalg.norm(self.weights - x, axis=2)
        bmu_index = np.unravel_index(np.argmin(distances), distances.shape)
        return bmu_index

    def neighborhood_function(self, distance, radius):
        """Gaussian neighborhood function"""
        if radius == 0:
            return 1.0 if distance == 0 else 0.0
        return np.exp(-distance ** 2 / (2 * radius ** 2))

    def train(self, X, n_epochs=10000, initial_lr=0.5, initial_radius=2):
        """Train SOM network"""
        n_samples = len(X)
        weight_history = []

        for epoch in range(n_epochs):
            # Calculate current learning rate and neighborhood radius
            if epoch <= 1000:
                lr = initial_lr - (initial_lr - 0.04) * (epoch / 1000)
                radius = initial_radius * (1 - epoch / 1000)
            else:
                lr = 0.04 - 0.04 * ((epoch - 1000) / 9000)
                radius = 0

            # Randomly select a sample
            idx = np.random.randint(n_samples)
            x = X[idx]

            # Find BMU
            bmu_i, bmu_j = self.find_bmu(x)

            # Update weights
            for i in range(self.grid_size[0]):
                for j in range(self.grid_size[1]):
                    distance_to_bmu = np.sqrt((i - bmu_i) ** 2 + (j - bmu_j) ** 2)
                    influence = self.neighborhood_function(distance_to_bmu, radius)

                    self.weights[i, j] += lr * influence * (x - self.weights[i, j])

            # Save weight history every 200 steps
            if epoch % 200 == 0:
                weight_history.append(self.weights.copy())
                if epoch % 1000 == 0:
                    print(f"Epoch {epoch}: LR={lr:.4f}, Radius={radius:.4f}")

        return weight_history


def create_beautiful_visualization(som, X, labels):
    """Create beautiful visualization of SOM mapping results"""
    # 使用兼容的样式
    try:
        plt.style.use('seaborn-v0_8-whitegrid')
    except:
        try:
            plt.style.use('seaborn-whitegrid')
        except:
            plt.style.use('default')

    fig = plt.figure(figsize=(20, 8))

    # 1. Main mapping visualization
    ax1 = plt.subplot2grid((2, 3), (0, 0), colspan=2, rowspan=2)

    # Create beautiful grid background
    for i in range(som.grid_size[0]):
        for j in range(som.grid_size[1]):
            # Draw neuron cell with gradient color based on position
            color_val = (i * som.grid_size[1] + j) / (som.grid_size[0] * som.grid_size[1])
            cell = Rectangle((j - 0.5, i - 0.5), 1, 1,
                             facecolor=plt.cm.Pastel1(color_val),
                             edgecolor='white', linewidth=2, alpha=0.7)
            ax1.add_patch(cell)
            ax1.text(j, i, f'({i},{j})', ha='center', va='center',
                     fontsize=9, fontweight='bold', color='gray')

    # Define colors and markers for each input pattern
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']
    markers = ['o', 's', 'D', '^', 'v']
    sizes = [800, 700, 750, 700, 800]

    mapping_positions = []

    # Plot each input pattern mapping
    for idx, (x, label) in enumerate(zip(X, labels)):
        bmu_i, bmu_j = som.find_bmu(x)
        mapping_positions.append((bmu_i, bmu_j))

        # Draw the mapping with beautiful styling
        ax1.scatter(bmu_j, bmu_i, c=colors[idx], s=sizes[idx], marker=markers[idx],
                    label=f'{label} {x}', edgecolors='black', linewidth=3, alpha=0.9,
                    zorder=10)

        # Add annotation with beautiful styling
        ax1.annotate(label, (bmu_j, bmu_i), xytext=(10, 10), textcoords='offset points',
                     fontsize=12, fontweight='bold', color=colors[idx],
                     bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8),
                     arrowprops=dict(arrowstyle='->', color=colors[idx], lw=2))

    ax1.set_xlim(-0.6, som.grid_size[1] - 0.4)
    ax1.set_ylim(-0.6, som.grid_size[0] - 0.4)
    ax1.set_aspect('equal')
    ax1.set_title('SOM Network - Final Mapping Results\n(5×5 Neuron Grid)',
                  fontsize=16, fontweight='bold', pad=20)
    ax1.set_xlabel('Column Index', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Row Index', fontsize=12, fontweight='bold')
    ax1.legend(loc='upper right', bbox_to_anchor=(1, 1), fontsize=10)
    ax1.invert_yaxis()  # Keep (0,0) at top-left
    ax1.grid(True, alpha=0.3)

    # 2. Weight norms heatmap
    ax2 = plt.subplot2grid((2, 3), (0, 2))
    weight_norms = np.linalg.norm(som.weights, axis=2)
    im = ax2.imshow(weight_norms, cmap='viridis', aspect='equal',
                    interpolation='nearest')

    # Add value annotations on heatmap
    for i in range(weight_norms.shape[0]):
        for j in range(weight_norms.shape[1]):
            ax2.text(j, i, f'{weight_norms[i, j]:.2f}',
                     ha='center', va='center', fontweight='bold',
                     color='white' if weight_norms[i, j] > 1.5 else 'black')

    # Mark input patterns on heatmap
    for idx, (pos, label) in enumerate(zip(mapping_positions, labels)):
        ax2.scatter(pos[1], pos[0], s=100, facecolors='none',
                    edgecolors='red', linewidth=3)
        ax2.text(pos[1], pos[0], label, ha='center', va='center',
                 fontweight='bold', color='red', fontsize=10)

    ax2.set_title('Weight Vector Norms\n(Heatmap)', fontsize=14, fontweight='bold')
    ax2.set_xlabel('Column')
    ax2.set_ylabel('Row')
    plt.colorbar(im, ax=ax2, label='Weight Norm')

    # 3. Input patterns visualization
    ax3 = plt.subplot2grid((2, 3), (1, 2))

    # Create bar chart for input patterns
    x_pos = np.arange(len(X))
    pattern_sums = np.sum(X, axis=1)

    bars = ax3.bar(x_pos, pattern_sums, color=colors, alpha=0.8, edgecolor='black')

    # Add value labels on bars
    for bar, pattern in zip(bars, X):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width() / 2., height,
                 f'{pattern}', ha='center', va='bottom', fontweight='bold')

    ax3.set_xlabel('Input Patterns', fontweight='bold')
    ax3.set_ylabel('Sum of Elements', fontweight='bold')
    ax3.set_title('Input Patterns Overview', fontsize=14, fontweight='bold')
    ax3.set_xticks(x_pos)
    ax3.set_xticklabels(labels)
    ax3.grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.show()

    return mapping_positions


def visualize_training_evolution(weight_history, X, labels):
    """Visualize the evolution of training"""
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()

    # Select key training steps to display
    steps = [0, 2, 5, 10, 20, len(weight_history) - 1]
    step_names = ['Initial', '400 Steps', '1000 Steps', '2000 Steps', '4000 Steps', 'Final']
    step_numbers = [0, 400, 1000, 2000, 4000, '10000']

    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7']

    for idx, (step, name, num) in enumerate(zip(steps, step_names, step_numbers)):
        if step < len(weight_history):
            weights = weight_history[step]

            # Calculate activation based on similarity to input patterns
            activation = np.zeros((5, 5))
            for i in range(5):
                for j in range(5):
                    min_dist = min([np.linalg.norm(weights[i, j] - x) for x in X])
                    activation[i, j] = 1 / (1 + min_dist)

            im = axes[idx].imshow(activation, cmap='YlOrRd', aspect='equal', vmin=0, vmax=1)

            # Mark BMUs for each input pattern
            som_temp = SOM()
            som_temp.weights = weights.copy()
            for pattern_idx, x in enumerate(X):
                bmu_i, bmu_j = som_temp.find_bmu(x)
                axes[idx].scatter(bmu_j, bmu_i, s=150,
                                  color=colors[pattern_idx],
                                  marker=['o', 's', 'D', '^', 'v'][pattern_idx],
                                  edgecolors='black', linewidth=2, alpha=0.9)
                axes[idx].text(bmu_j, bmu_i, labels[pattern_idx],
                               ha='center', va='center', fontweight='bold',
                               bbox=dict(boxstyle="circle,pad=0.3", facecolor='white', alpha=0.8))

            axes[idx].set_title(f'{name}\n({num} Steps)', fontsize=12, fontweight='bold')
            axes[idx].set_xlabel('Column')
            axes[idx].set_ylabel('Row')

            # Add colorbar for each subplot
            plt.colorbar(im, ax=axes[idx], shrink=0.8)

    plt.suptitle('SOM Training Evolution - Weight Updates Every 200 Steps',
                 fontsize=16, fontweight='bold', y=0.95)
    plt.tight_layout()
    plt.show()


def print_detailed_analysis(som, X, labels):
    """Print detailed analysis of mapping results"""
    print("=" * 60)
    print("            SOM NETWORK MAPPING ANALYSIS")
    print("=" * 60)

    print("\nFINAL MAPPING RESULTS:")
    print("-" * 40)

    mapping_data = []
    for idx, (x, label) in enumerate(zip(X, labels)):
        bmu_i, bmu_j = som.find_bmu(x)
        distance = np.linalg.norm(som.weights[bmu_i, bmu_j] - x)
        mapping_data.append((label, x, (bmu_i, bmu_j), distance))

        print(f"{label}: {x}")
        print(f"    Mapped to neuron: ({bmu_i}, {bmu_j})")
        print(f"    Distance to target: {distance:.6f}")
        print(f"   Neuron weights: [{', '.join([f'{w:.3f}' for w in som.weights[bmu_i, bmu_j]])}]")
        print()

    print("\nTOPOLOGICAL ANALYSIS:")
    print("-" * 40)

    # Check if topology is preserved
    positions = [data[2] for data in mapping_data]
    print("Mapping positions:", positions)

    # Simple topology check
    print("✓ Topology preservation check:")
    for i in range(len(X)):
        for j in range(i + 1, len(X)):
            dist_in = np.linalg.norm(X[i] - X[j])
            dist_out = np.sqrt((positions[i][0] - positions[j][0]) ** 2 +
                               (positions[i][1] - positions[j][1]) ** 2)
            print(f"  {labels[i]} vs {labels[j]}: input_dist={dist_in:.2f}, output_dist={dist_out:.1f}")


# 简化的主程序，确保运行
def main():
    # Set random seed for reproducibility
    np.random.seed(42)

    # Define input patterns
    X = np.array([
        [1, 0, 0, 0],  # X1
        [1, 1, 0, 0],  # X2
        [1, 1, 1, 0],  # X3
        [0, 1, 0, 0],  # X4
        [1, 1, 1, 1]  # X5
    ])
    labels = ['X1', 'X2', 'X3', 'X4', 'X5']

    print("Starting SOM Network Training...")
    print("Network: 5×5 neurons, 4-dimensional inputs")
    print("Training for 10000 epochs...")
    print()

    # Create and train SOM
    som = SOM(grid_size=(5, 5), input_dim=4)
    weight_history = som.train(X, n_epochs=10000)

    print("\n Training completed!")
    print("\n Visualizing training evolution...")
    visualize_training_evolution(weight_history, X, labels)

    print("\n Creating final mapping visualization...")
    mapping_positions = create_beautiful_visualization(som, X, labels)

    print("\n Generating detailed analysis...")
    print_detailed_analysis(som, X, labels)

    # Final summary
    print("\n" + "=" * 60)
    print("             FINAL MAPPING SUMMARY")
    print("=" * 60)
    for label, (bmu_i, bmu_j) in zip(labels, [som.find_bmu(x) for x in X]):
        print(f"   {label} → Neuron ({bmu_i}, {bmu_j})")
    print("=" * 60)


# 直接运行主程序
if __name__ == "__main__":
    main()