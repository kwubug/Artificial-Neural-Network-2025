import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.ols_algorithm import OlsAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class OlsBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')

    total_epoches = BridgeProperty(20)
    learning_rate = BridgeProperty(0.05)
    batch_size = BridgeProperty(0)  # 0 视为全量
    normalize_data = BridgeProperty(True)

    has_finished = BridgeProperty(True)
    current_epoch = BridgeProperty(0)
    current_iteration = BridgeProperty(0)
    current_loss = BridgeProperty(0.0)

    # 当前回归直线参数
    w0 = BridgeProperty(0.0)
    w1 = BridgeProperty(0.0)

    def __init__(self):
        super().__init__()
        self._ols = None

    @PyQt5.QtCore.pyqtSlot()
    def start_ols(self):
        ds = self.dataset_dict[self.current_dataset_name]
        self._ols = ObservableOlsAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=ds,
            total_epoches=self.total_epoches,
            learning_rate=self.learning_rate,
            batch_size=(self.batch_size if self.batch_size > 0 else None),
            normalize_data=self.normalize_data,
        )
        self._ols.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols(self):
        if self._ols:
            self._ols.stop()


class ObservableOlsAlgorithm(Observable, OlsAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        object.__setattr__(self, '_obs_ready', False)
        OlsAlgorithm.__init__(self, **kwargs, ui_refresh_interval=ui_refresh_interval)
        object.__setattr__(self, '_obs_ready', True)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if not getattr(self, '_obs_ready', False):
            return
        if name in ('current_epoch', 'current_iteration', 'current_loss', 'w0', 'w1'):
            self.notify(name, value)

    def run(self):
        self.notify('has_finished', False)
        self.notify('current_loss', 0.0)
        super().run()
        self.notify('w0', self.w0)
        self.notify('w1', self.w1)
        self.notify('has_finished', True)

