import PyQt5.QtCore

from nn_sandbox.backend.algorithms.hopfield_tsp_algorithm import HopfieldTspAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class HopfieldTspBridge(Bridge):
    """
    Bridge for Hopfield-TSP visualization.
    """
    n = BridgeProperty(8)
    seed = BridgeProperty(42)
    A = BridgeProperty(50.0)
    B = BridgeProperty(50.0)
    C = BridgeProperty(0.1)
    lam = BridgeProperty(1.0)
    dt = BridgeProperty(0.001)
    max_iter = BridgeProperty(5000)
    update_freq = BridgeProperty(50)
    ui_refresh_interval = BridgeProperty(0.15)

    has_finished = BridgeProperty(True)
    current_iter = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    total_distance = BridgeProperty(0.0)

    # data for visualization
    cities = BridgeProperty([])
    x_path = BridgeProperty([])
    y_path = BridgeProperty([])
    V = BridgeProperty([])

    @PyQt5.QtCore.pyqtSlot()
    def start(self):
        self.has_finished = False
        self._algo = ObservableHopfieldTspAlgorithm(
            self,
            n_cities=self.n,
            seed=self.seed,
            A=self.A, B=self.B, C=self.C,
            lam=self.lam, dt=self.dt,
            max_iter=self.max_iter, update_freq=self.update_freq,
            ui_refresh_interval=self.ui_refresh_interval
        )
        self._algo.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop(self):
        if hasattr(self, '_algo') and self._algo:
            self._algo.stop()


class ObservableHopfieldTspAlgorithm(Observable, HopfieldTspAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        HopfieldTspAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ('cities', 'x_path', 'y_path', 'V') and value is not None:
            self.notify(name, value.tolist() if hasattr(value, 'tolist') else list(value))
        elif name in ('current_iter', 'current_energy', 'total_distance', 'has_finished'):
            self.notify(name, value)


