import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# 1. Generate training samples
np.random.seed(42)  # Set random seed for reproducibility
P = 100  # Number of samples
x = np.linspace(-4, 4, P)  # Generate uniformly distributed input samples in [-4,4]
# Calculate true function value F(x)
F = 1.1 * (1 - x + 2 * x**2) * np.exp(-x**2 / 2)
# Add Gaussian noise with mean 0 and standard deviation 0.1
noise = np.random.normal(0, 0.1, P)
y = F + noise  # Noisy output samples


# 2. Determine hidden node centers (use first 10 samples as initial cluster centers, then optimize with K-means)
n_centers = 10  # Number of hidden nodes
initial_centers = x[:n_centers].reshape(-1, 1)  # First 10 samples as initial centers

# Optimize centers with K-means clustering (required initial centers are first 10, optimized here)
kmeans = KMeans(n_clusters=n_centers, init=initial_centers, n_init=1)
kmeans.fit(x.reshape(-1, 1))
c = kmeans.cluster_centers_.flatten()  # Cluster centers (hidden node centers)
c = np.sort(c)  # Sort centers for convenient calculation of spread constant


# 3. Calculate spread constant σ (based on average distance between adjacent centers)
lambda_ = 1  # Overlap coefficient
sigma = []
for m in range(n_centers):
    # Calculate distance between m-th center and all other centers
    distances = np.abs(c[m] - c[c != c[m]])
    avg_dist = np.mean(distances)  # Average distance
    sigma_m = lambda_ * avg_dist  # Spread constant
    sigma.append(sigma_m)
sigma = np.array(sigma)


# 4. Construct radial basis function matrix Φ (Gaussian function as radial basis)
def rbf(x, c, sigma):
    """Gaussian radial basis function: φ(x) = exp(-(x-c)²/(2σ²))"""
    return np.exp(-(x - c)**2 / (2 * sigma**2))

# Construct 100×10 basis function matrix
Phi = np.zeros((P, n_centers))
for m in range(n_centers):
    Phi[:, m] = rbf(x, c[m], sigma[m])


# 5. Solve weights and bias using pseudoinverse method
# Construct augmented matrix (add all-1 column for solving bias b)
Phi_aug = np.hstack((Phi, np.ones((P, 1))))  # 100×11 matrix

# Calculate parameters using pseudoinverse: W = [w1, w2, ..., w10, b]^T
W = np.linalg.pinv(Phi_aug) @ y  # Pseudoinverse formula: (Φ^TΦ)^(-1)Φ^T y
w = W[:-1]  # Weights (first 10 parameters)
b = W[-1]   # Bias (last parameter)


# 6. Model prediction and error calculation
y_pred = Phi @ w + b  # Predicted output
mse = np.mean((y_pred - y)**2)  # Mean squared error
print(f"Mean Squared Error (MSE): {mse:.6f}")


# 7. Visualize results
plt.figure(figsize=(10, 6))
plt.plot(x, F, 'b-', linewidth=2, label='True Function F(x)')
plt.scatter(x, y, c='orange', s=15, alpha=0.6, label='Noisy Samples')
plt.plot(x, y_pred, 'r--', linewidth=2, label='RBF Network Approximation')
plt.scatter(c, np.zeros_like(c), c='green', s=50, marker='*', label='Hidden Node Centers')
plt.xlabel('x')
plt.ylabel('y')
plt.title('RBF Neural Network Approximation Result')
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()