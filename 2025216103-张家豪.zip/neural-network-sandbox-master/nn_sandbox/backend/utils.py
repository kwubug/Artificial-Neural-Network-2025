import pathlib
import math
import csv
import io
import urllib.request

import numpy as np


def sign(value):
    return 1 if value >= 0 else -1


def sigmoid(value):
    """单极性sigmoid函数 (0, 1)"""
    return 1 / (1 + math.exp(-value))


def bipolar_sigmoid(value):
    """双极性sigmoid函数 (-1, 1)"""
    return (2 / (1 + math.exp(-value))) - 1


def gaussian(value: np.ndarray, mean: np.ndarray, standard_deviation):
    if standard_deviation == 0:
        return 0
    return math.exp((value - mean).dot(value - mean) / (-2 * standard_deviation**2))


def dist(p1, p2):
    return sum((x1 - x2)**2 for x1, x2 in zip(p1, p2))**0.5


def flatten(list_or_tuple):
    for element in list_or_tuple:
        if isinstance(element, (list, tuple)):
            yield from flatten(element)
        else:
            yield element


def read_data(folder='nn_sandbox/assets/data'):
    data = {}
    for filepath in pathlib.Path(folder).glob('**/*.txt'):
        with filepath.open() as file_object:
            # make sure the data is stored in native Python type in order to
            # communicate with QML.
            data[filepath.stem] = np.loadtxt(file_object).tolist()
    return data


def ensure_ols_online_datasets(folder='nn_sandbox/assets/data'):
    """
    若本地不存在，则从网络下载两份适合OLS的数据并转换为三列txt：
    - Advertising: x=TV, y=Sales, label=0
    - Salary: x=YearsExperience, y=Salary, label=0
    """
    data_dir = pathlib.Path(folder)
    data_dir.mkdir(parents=True, exist_ok=True)

    targets = [
        dict(
            url='https://raw.githubusercontent.com/justmarkham/DAT8/master/data/advertising.csv',
            outfile=data_dir / 'ols_advertising_tv_sales.txt',
            x_col='TV',
            y_col='Sales'
        ),
        dict(
            url='https://raw.githubusercontent.com/AdiPersonalWorks/Random/master/Salary_Data.csv',
            outfile=data_dir / 'ols_salary_years_salary.txt',
            x_col='YearsExperience',
            y_col='Salary'
        )
    ]

    for item in targets:
        if item['outfile'].exists():
            continue
        try:
            with urllib.request.urlopen(item['url'], timeout=15) as resp:
                content_bytes = resp.read()
            content_text = content_bytes.decode('utf-8', errors='ignore')
            reader = csv.DictReader(io.StringIO(content_text))
            rows = []
            for row in reader:
                try:
                    x = float(row[item['x_col']])
                    y = float(row[item['y_col']])
                    rows.append(f'{x} {y} 0')
                except Exception:
                    continue
            if rows:
                item['outfile'].write_text('\n'.join(rows), encoding='utf-8')
        except Exception:
            # 静默失败，不影响主流程
            pass
