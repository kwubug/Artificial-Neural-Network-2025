import numpy as np
from typing import List, Tuple, Optional


class OLSAlgorithm:
    """普通最小二乘法（OLS）算法实现"""
    
    def __init__(self):
        self.coefficients: Optional[np.ndarray] = None  # [截距, 斜率]
        self.r_squared: Optional[float] = None
        self.mse: Optional[float] = None  # 均方误差
        self.mae: Optional[float] = None  # 平均绝对误差
        self.x_data: List[float] = []
        self.y_data: List[float] = []
    
    def add_data_point(self, x: float, y: float):
        """添加数据点"""
        self.x_data.append(x)
        self.y_data.append(y)
    
    def clear_data(self):
        """清空数据"""
        self.x_data.clear()
        self.y_data.clear()
        self.coefficients = None
        self.r_squared = None
        self.mse = None
        self.mae = None
    
    def fit(self) -> bool:
        """
        使用最小二乘法拟合线性回归模型
        返回True表示拟合成功，False表示数据不足
        """
        if len(self.x_data) < 2:
            return False
        
        X = np.array(self.x_data)
        y = np.array(self.y_data)
        
        # 构建设计矩阵 [1, x]
        X_matrix = np.column_stack([np.ones(len(X)), X])
        
        # 计算最小二乘解: (X^T * X)^(-1) * X^T * y
        try:
            XTX = np.dot(X_matrix.T, X_matrix)
            XTX_inv = np.linalg.inv(XTX)
            XTy = np.dot(X_matrix.T, y)
            self.coefficients = np.dot(XTX_inv, XTy)
        except np.linalg.LinAlgError:
            # 如果矩阵不可逆，使用伪逆
            self.coefficients = np.linalg.pinv(X_matrix) @ y
        
        # 计算R²（决定系数）
        y_pred = self.predict(X)
        ss_res = np.sum((y - y_pred) ** 2)
        ss_tot = np.sum((y - np.mean(y)) ** 2)
        
        if ss_tot == 0:
            self.r_squared = 1.0 if ss_res == 0 else 0.0
        else:
            self.r_squared = 1 - (ss_res / ss_tot)
        
        # 计算均方误差(MSE)和平均绝对误差(MAE)
        self.mse = np.mean((y - y_pred) ** 2)
        self.mae = np.mean(np.abs(y - y_pred))
        
        return True
    
    def predict(self, x: np.ndarray) -> np.ndarray:
        """预测y值"""
        if self.coefficients is None:
            raise ValueError("模型尚未拟合，请先调用fit()方法")
        
        return self.coefficients[0] + self.coefficients[1] * x
    
    def get_equation_string(self) -> str:
        """获取回归方程字符串"""
        if self.coefficients is None:
            return "y = --"
        
        intercept = self.coefficients[0]
        slope = self.coefficients[1]
        
        if slope >= 0:
            return f"y = {intercept:.3f} + {slope:.3f}x"
        else:
            return f"y = {intercept:.3f} - {abs(slope):.3f}x"
    
    def get_statistics(self) -> dict:
        """获取统计信息"""
        return {
            'coefficients': self.coefficients,
            'r_squared': self.r_squared,
            'mse': self.mse,
            'mae': self.mae,
            'equation': self.get_equation_string(),
            'n_points': len(self.x_data)
        }

