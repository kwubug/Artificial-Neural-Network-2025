# -*- coding: utf-8 -*-
"""
三层（可多隐层）BP算法，满足：
- 可选各层节点数（network_shape）
- 可选学习率（initial_learning_rate）
- 权值初始化到 [-1, 1]
- 可选单极/双极性 Sigmoid
"""

import collections
import enum
from typing import Callable, Sequence, Tuple, Optional, Dict

import numpy as np

from . import PredictiveAlgorithm


# ---------- 激活函数 ----------
class SigmoidKind(str, enum.Enum):
    UNIPOLAR = "unipolar"   # (0, 1)
    BIPOLAR = "bipolar"     # (-1, 1)


def _sigmoid_unipolar(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _sigmoid_unipolar_prime_from_y(y: np.ndarray) -> np.ndarray:
    return y * (1.0 - y)


def _sigmoid_bipolar(x: np.ndarray) -> np.ndarray:
    return 2.0 / (1.0 + np.exp(-x)) - 1.0

 
def _sigmoid_bipolar_prime_from_y(y: np.ndarray) -> np.ndarray:
    return (1.0 - y * y) * 0.5


# ---------- 轻量神经元 ----------
class _BpNeuron:
    __slots__ = ("activation", "activation_prime_from_y", "synaptic_weight", "data", "result")

    def __init__(self,
                 activation: Callable[[np.ndarray], np.ndarray],
                 activation_prime_from_y: Callable[[np.ndarray], np.ndarray]):
        self.activation = activation
        self.activation_prime_from_y = activation_prime_from_y
        self.synaptic_weight = None  # type: Optional[np.ndarray]
        self.data = None             # type: Optional[np.ndarray]
        self.result = None           # type: Optional[float]

    def _ensure_weights(self, in_dim: int):
        if self.synaptic_weight is None:
            self.synaptic_weight = np.random.uniform(-1.0, 1.0, size=(in_dim + 1,)).astype(float)

    def forward(self, input_vec: Sequence[float]) -> float:
        x = np.asarray(input_vec, dtype=float)
        self._ensure_weights(x.shape[0])
        # 拼偏置 1
        self.data = np.concatenate([x, np.array([1.0])], axis=0)
        net = float(np.dot(self.synaptic_weight, self.data))
        y = float(self.activation(np.array(net)))
        self.result = y
        return y


# ---------- 算法主体 ----------
class BpAlgorithm(PredictiveAlgorithm):
    def __init__(
        self,
        dataset,
        total_epoches: int = 10,
        most_correct_rate: Optional[float] = None,
        initial_learning_rate: float = 0.8,
        search_iteration_constant: int = 10000,
        momentum_weight: float = 0.5,
        test_ratio: float = 0.3,
        network_shape: Optional[Sequence[int]] = None,
        activation_kind: SigmoidKind = SigmoidKind.UNIPOLAR,
    ):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant, test_ratio)
        self._momentum_weight = float(momentum_weight)
        self.network_shape = tuple(network_shape) if network_shape else (5, 5)  # type: Tuple[int, ...]
        self.activation_kind = activation_kind

        # 动量缓存
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0.0)

        # 运行期构建
        self._neurons = None  # type: Optional[Tuple[Tuple[_BpNeuron, ...], ...]]

        # 激活与导数
        if self.activation_kind == SigmoidKind.UNIPOLAR:
            self._act = _sigmoid_unipolar
            self._act_prime_from_y = _sigmoid_unipolar_prime_from_y
            self._interval_scale = 1.0
        else:
            self._act = _sigmoid_bipolar
            self._act_prime_from_y = _sigmoid_bipolar_prime_from_y
            self._interval_scale = 2.0

    def _initialize_neurons(self):
        layer_sizes = list(self.network_shape) + [1]
        make = lambda: _BpNeuron(self._act, self._act_prime_from_y)
        self._neurons = tuple(tuple(make() for _ in range(sz)) for sz in layer_sizes)

    def _feed_forward(self, data: Sequence[float]) -> float:
        assert self._neurons is not None
        layer_input = np.asarray(data, dtype=float)
        for layer in self._neurons:
            layer_output = np.fromiter((n.forward(layer_input) for n in layer), dtype=float)
            layer_input = layer_output
        return float(layer_input[0])

    def _pass_backward(self, expect: float, result: float):
        assert self._neurons is not None
        deltas = {}  # type: Dict[_BpNeuron, float]

        # 输出层
        out_neuron = self._neurons[-1][0]
        deltas[out_neuron] = (expect - result) * float(out_neuron.activation_prime_from_y(np.array(result)))

        # 隐层
        for layer_idx in reversed(range(len(self._neurons) - 1)):
            layer = self._neurons[layer_idx]
            next_layer = self._neurons[layer_idx + 1]
            for ni, neuron in enumerate(layer):
                downstream = 0.0
                for nxt in next_layer:
                    downstream += deltas[nxt] * float(nxt.synaptic_weight[ni])
                deriv = float(neuron.activation_prime_from_y(np.array(neuron.result)))
                deltas[neuron] = downstream * deriv

        return deltas

    def _adjust_synaptic_weights(self, deltas: Dict[_BpNeuron, float]):
        for neuron, delta in deltas.items():
            x = neuron.data  # 已含偏置
            if not isinstance(self._synaptic_weight_diff[neuron], np.ndarray):
                self._synaptic_weight_diff[neuron] = np.zeros_like(neuron.synaptic_weight, dtype=float)
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * delta * x
            )
            neuron.synaptic_weight = neuron.synaptic_weight + self._synaptic_weight_diff[neuron]

    def _iterate(self):
        x = self.current_data[:-1]
        y_pred = self._feed_forward(x)
        y_exp = self._normalize(self.current_data[-1])
        deltas = self._pass_backward(y_exp, y_pred)
        self._adjust_synaptic_weights(deltas)

    def _correct_rate(self, dataset) -> float:
        if not self._neurons:
            return 0.0
        K = len(self.group_types)
        if K == 0:
            return 0.0
        half_interval = (1.0 / (2.0 * K)) * self._interval_scale
        correct = 0
        for row in dataset:
            pred = self._feed_forward(row[:-1])
            exp = self._normalize(row[-1])
            if (exp - half_interval) < pred < (exp + half_interval):
                correct += 1
        return 0.0 if correct == 0 else float(correct) / float(len(dataset))

    def _normalize(self, value: float) -> float:
        vmin = float(np.amin(self.group_types))
        K = float(len(self.group_types))
        u = (2.0 * (float(value) - vmin) + 1.0) / (2.0 * K)  # (0,1)
        if self.activation_kind == SigmoidKind.UNIPOLAR:
            return u
        return 2.0 * u - 1.0
