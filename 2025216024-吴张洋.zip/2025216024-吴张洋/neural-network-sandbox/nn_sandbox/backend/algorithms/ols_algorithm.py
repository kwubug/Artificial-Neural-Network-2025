import numpy as np

from . import PredictiveAlgorithm


class OlsAlgorithm(PredictiveAlgorithm):
    """
    普通最小二乘法（Ordinary Least Squares）算法
    用于线性回归：y = ax + b
    """
    def __init__(self, dataset, total_epoches=1, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 test_ratio=0.3):
        # OLS是解析解，只需要1个epoch
        super().__init__(dataset, 1, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.slope = 0.0  # 斜率 a
        self.intercept = 0.0  # 截距 b
        self.r_squared = 0.0  # R²决定系数
        self.mse = 0.0  # 均方误差
        self.fitted_line = []  # 拟合直线数据点
        self.residuals = []  # 残差

    def _initialize_neurons(self):
        """OLS不需要神经元，但需要实现抽象方法"""
        pass

    def _iterate(self):
        """执行OLS计算"""
        # 提取训练数据的x和y
        x_data = self.training_dataset[:, :-1]  # 所有特征列
        y_data = self.training_dataset[:, -1]  # 目标列
        
        # 对于1D输入（单特征），直接计算
        if x_data.shape[1] == 1:
            x = x_data.flatten()
            y = y_data.flatten()
            
            # 计算均值
            x_mean = np.mean(x)
            y_mean = np.mean(y)
            
            # 计算斜率 a = Σ(xi - x̄)(yi - ȳ) / Σ(xi - x̄)²
            numerator = np.sum((x - x_mean) * (y - y_mean))
            denominator = np.sum((x - x_mean) ** 2)
            
            if abs(denominator) < 1e-10:
                # 如果分母为0，说明x值都相同，无法拟合
                self.slope = 0.0
                self.intercept = y_mean
            else:
                self.slope = numerator / denominator
                self.intercept = y_mean - self.slope * x_mean
            
            # 计算拟合值
            y_pred = self.slope * x + self.intercept
            
            # 计算残差
            self.residuals = (y - y_pred).tolist()
            
            # 计算R²
            ss_res = np.sum((y - y_pred) ** 2)  # 残差平方和
            ss_tot = np.sum((y - y_mean) ** 2)  # 总平方和
            if ss_tot < 1e-10:
                self.r_squared = 1.0 if ss_res < 1e-10 else 0.0
            else:
                self.r_squared = 1 - (ss_res / ss_tot)
            
            # 计算MSE
            self.mse = ss_res / len(y)
            
            # 生成拟合直线数据点（用于可视化）
            x_min, x_max = np.min(x), np.max(x)
            x_range = x_max - x_min
            x_fit = np.linspace(x_min - x_range * 0.1, x_max + x_range * 0.1, 100)
            y_fit = self.slope * x_fit + self.intercept
            self.fitted_line = [[float(x_fit[i]), float(y_fit[i])] 
                                for i in range(len(x_fit))]
        else:
            # 多特征情况，使用矩阵方法
            # y = X * beta，其中beta = [b, a1, a2, ...]
            # 添加偏置项
            X = np.column_stack([np.ones(len(x_data)), x_data])
            
            # 使用正规方程：beta = (X^T * X)^(-1) * X^T * y
            try:
                beta = np.linalg.solve(X.T @ X, X.T @ y_data)
                self.intercept = float(beta[0])
                self.slope = float(beta[1]) if len(beta) > 1 else 0.0
                
                # 计算拟合值
                y_pred = X @ beta
                
                # 计算残差
                self.residuals = (y_data - y_pred).tolist()
                
                # 计算R²
                y_mean = np.mean(y_data)
                ss_res = np.sum((y_data - y_pred) ** 2)
                ss_tot = np.sum((y_data - y_mean) ** 2)
                if ss_tot < 1e-10:
                    self.r_squared = 1.0 if ss_res < 1e-10 else 0.0
                else:
                    self.r_squared = 1 - (ss_res / ss_tot)
                
                # 计算MSE
                self.mse = ss_res / len(y_data)
                
                # 对于多特征，拟合线使用第一个特征
                if x_data.shape[1] >= 1:
                    x = x_data[:, 0]
                    x_min, x_max = np.min(x), np.max(x)
                    x_range = x_max - x_min
                    x_fit = np.linspace(x_min - x_range * 0.1, x_max + x_range * 0.1, 100)
                    # 使用第一个特征的系数
                    y_fit = self.slope * x_fit + self.intercept
                    self.fitted_line = [[float(x_fit[i]), float(y_fit[i])] 
                                        for i in range(len(x_fit))]
            except np.linalg.LinAlgError:
                # 如果矩阵不可逆，使用伪逆
                beta = np.linalg.pinv(X) @ y_data
                self.intercept = float(beta[0])
                self.slope = float(beta[1]) if len(beta) > 1 else 0.0
                y_pred = X @ beta
                self.residuals = (y_data - y_pred).tolist()
                y_mean = np.mean(y_data)
                ss_res = np.sum((y_data - y_pred) ** 2)
                ss_tot = np.sum((y_data - y_mean) ** 2)
                self.r_squared = 1 - (ss_res / ss_tot) if ss_tot > 1e-10 else 0.0
                self.mse = ss_res / len(y_data)
                if x_data.shape[1] >= 1:
                    x = x_data[:, 0]
                    x_min, x_max = np.min(x), np.max(x)
                    x_range = x_max - x_min
                    x_fit = np.linspace(x_min - x_range * 0.1, x_max + x_range * 0.1, 100)
                    y_fit = self.slope * x_fit + self.intercept
                    self.fitted_line = [[float(x_fit[i]), float(y_fit[i])] 
                                        for i in range(len(x_fit))]

    def _correct_rate(self, dataset):
        """计算正确率（对于回归问题，使用R²作为正确率）"""
        return max(0.0, min(1.0, self.r_squared))

    def _feed_forward(self, x):
        """预测函数"""
        if isinstance(x, np.ndarray):
            if x.ndim == 1:
                return self.slope * x[0] + self.intercept
            else:
                return self.slope * x[:, 0] + self.intercept
        else:
            return self.slope * x + self.intercept


