import numpy as np
import math

from . import TraningAlgorithm


class DhnnAlgorithm(TraningAlgorithm):
    """
    Discrete Hopfield Neural Network (DHNN) Algorithm.
    Implements asynchronous update, attractor detection, and energy calculation.
    """
    def __init__(self, dataset=None, total_epoches=100, max_iterations_per_epoch=1000,
                 convergence_threshold=0.01, use_bipolar=True, num_neurons=9):
        # If dataset is None or empty, use num_neurons
        if dataset is None or len(dataset) == 0:
            dataset = []  # Empty dataset
        super().__init__(dataset, total_epoches)
        self._max_iterations_per_epoch = max_iterations_per_epoch
        self._convergence_threshold = convergence_threshold
        self._use_bipolar = use_bipolar  # True: [-1, 1], False: [0, 1]
        self._num_neurons = num_neurons  # Manual neuron count
        
        # Network parameters
        self.num_neurons = 0
        self.current_iterations = 0
        self._states = None  # Neuron states: [-1, 1] or [0, 1]
        self._weights = None  # Weight matrix (symmetric, diagonal = 0)
        self._biases = None  # Bias vector
        
        # Energy and attractor tracking
        self._energy = 0.0
        self._energy_history = []
        self._state_history = []
        self._attractors = []  # List of found attractors
        self._attractor_energies = []  # Energy of each attractor
        self._is_converged = False
        self._convergence_iteration = 0
        
        # Training patterns (memories to store)
        self._training_patterns = None

    def run(self):
        """Run the DHNN algorithm."""
        self._initialize_network()
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            self.current_iterations = epoch
            self._iterate()

    def _initialize_network(self):
        """Initialize the network from training patterns or use manual neuron count."""
        # Determine number of neurons
        if len(self._dataset) > 0:
            # Convert dataset to training patterns
            patterns = np.array(self._dataset)
            
            # If dataset has labels (last column), remove them
            if patterns.shape[1] > 1:
                # Check if last column looks like labels (integers or small set of values)
                last_col = patterns[:, -1]
                unique_labels = len(np.unique(last_col))
                if unique_labels < len(patterns) * 0.5:  # Likely labels
                    patterns = patterns[:, :-1]
            
            self._training_patterns = patterns
            self.num_neurons = patterns.shape[1]
            
            # Convert patterns to bipolar if needed
            if self._use_bipolar:
                # Convert [0, 1] to [-1, 1]
                patterns_bipolar = 2 * patterns - 1
            else:
                patterns_bipolar = patterns.copy()
            
            # Initialize weights using Hebbian learning rule
            # W = (1/N) * sum(x_i * x_i^T) for all patterns, where N is number of neurons
            self._weights = np.zeros((self.num_neurons, self.num_neurons))
            for pattern in patterns_bipolar:
                # Outer product: pattern * pattern^T
                self._weights += np.outer(pattern, pattern)
            
            # Normalize by number of neurons
            self._weights /= self.num_neurons
        else:
            # Use manual neuron count, initialize with random weights
            self.num_neurons = self._num_neurons
            self._training_patterns = None
            
            # Initialize weights randomly (small random values, symmetric)
            self._weights = np.random.uniform(-0.5, 0.5, (self.num_neurons, self.num_neurons))
            # Make symmetric
            self._weights = (self._weights + self._weights.T) / 2
        
        # Set diagonal to 0 (no self-connections)
        np.fill_diagonal(self._weights, 0)
        
        # Initialize biases to 0 (can be adjusted if needed)
        self._biases = np.zeros(self.num_neurons)
        
        # Initialize states randomly
        if self._use_bipolar:
            self._states = np.random.choice([-1, 1], size=self.num_neurons)
        else:
            self._states = np.random.choice([0, 1], size=self.num_neurons)
        
        # Calculate initial energy
        self._energy = self._calculate_energy()
        self._energy_history = [self._energy]
        self._state_history = [self._states.copy().tolist()]
        self._is_converged = False
        self._convergence_iteration = 0
        self._attractors = []
        self._attractor_energies = []

    def _calculate_energy(self):
        """
        Calculate the energy of the current state.
        E = -0.5 * sum_i sum_j (w_ij * s_i * s_j) - sum_i (b_i * s_i)
        """
        # Interaction terms: -0.5 * sum_i sum_j (w_ij * s_i * s_j)
        # Since weights are symmetric and diagonal is 0, we can compute efficiently
        interaction_energy = -0.5 * np.dot(self._states, np.dot(self._weights, self._states))
        # Bias terms: -sum_i (b_i * s_i)
        bias_energy = -np.dot(self._biases, self._states)
        return interaction_energy + bias_energy

    def _calculate_local_field(self, neuron_idx):
        """
        Calculate the local field (input) for a neuron.
        h_i = sum_j (w_ij * s_j) + b_i
        """
        local_field = np.dot(self._weights[neuron_idx, :], self._states) + self._biases[neuron_idx]
        return local_field

    def _update_neuron_async(self, neuron_idx):
        """
        Asynchronously update a single neuron's state.
        s_i(t+1) = sign(h_i(t)) where h_i is the local field
        """
        local_field = self._calculate_local_field(neuron_idx)
        
        if self._use_bipolar:
            # Bipolar: sign function
            new_state = 1 if local_field >= 0 else -1
        else:
            # Unipolar: step function
            new_state = 1 if local_field >= 0 else 0
        
        return new_state

    def _iterate(self):
        """
        Perform one epoch: asynchronous update until convergence or max iterations.
        """
        previous_states = self._states.copy()
        iterations_in_epoch = 0
        converged = False
        no_change_count = 0  # Count consecutive iterations with no state change
        
        # Asynchronous update loop
        for _ in range(self._max_iterations_per_epoch):
            if self._should_stop:
                break
            
            # Randomly select a neuron to update
            neuron_idx = np.random.randint(0, self.num_neurons)
            
            # Store old state of this neuron
            old_state = self._states[neuron_idx]
            
            # Update the selected neuron
            new_state = self._update_neuron_async(neuron_idx)
            self._states[neuron_idx] = new_state
            
            iterations_in_epoch += 1
            
            # Check if this neuron's state changed
            if old_state == new_state:
                no_change_count += 1
            else:
                no_change_count = 0
            
            # Convergence: if we've updated all neurons at least once and none changed
            # We consider converged if no change for a full cycle (num_neurons updates)
            if iterations_in_epoch >= self.num_neurons and no_change_count >= self.num_neurons:
                converged = True
                break
            
            # Also check if state is exactly the same as previous full state
            if iterations_in_epoch % self.num_neurons == 0:
                if np.array_equal(self._states, previous_states):
                    converged = True
                    break
                previous_states = self._states.copy()
                no_change_count = 0
        
        # Calculate new energy
        new_energy = self._calculate_energy()
        energy_change = abs(new_energy - self._energy)
        
        # Update energy and history
        self._energy = new_energy
        self._energy_history.append(self._energy)
        self._state_history.append(self._states.copy().tolist())
        
        # Check if we've reached an attractor (converged state)
        if converged:
            self._is_converged = True
            self._convergence_iteration = len(self._energy_history) - 1
            
            # Check if this is a new attractor
            state_tuple = tuple(self._states.tolist())
            is_new_attractor = True
            for attractor in self._attractors:
                if np.array_equal(attractor, self._states):
                    is_new_attractor = False
                    break
            
            if is_new_attractor:
                self._attractors.append(self._states.copy())
                self._attractor_energies.append(self._energy)
        
        # If not converged, reset for next iteration
        if not converged:
            self._is_converged = False
            # Optionally reset to a random state or use a pattern from dataset
            if len(self._training_patterns) > 0:
                # Reset to a random training pattern with some noise
                pattern_idx = np.random.randint(0, len(self._training_patterns))
                pattern = self._training_patterns[pattern_idx].copy()
                
                if self._use_bipolar:
                    pattern = 2 * pattern - 1
                
                # Add small random noise
                noise = np.random.normal(0, 0.1, self.num_neurons)
                pattern = pattern + noise
                
                # Binarize
                if self._use_bipolar:
                    self._states = np.sign(pattern)
                    self._states[self._states == 0] = 1  # Handle zero case
                else:
                    self._states = (pattern > 0).astype(float)
            else:
                # Random initialization
                if self._use_bipolar:
                    self._states = np.random.choice([-1, 1], size=self.num_neurons)
                else:
                    self._states = np.random.choice([0, 1], size=self.num_neurons)

    @property
    def current_data(self):
        """Return current data point (not used in DHNN, but required by base class)."""
        if len(self._dataset) > 0:
            return self._dataset[self.current_iterations % len(self._dataset)]
        return None

    @property
    def states(self):
        """Get current neuron states."""
        return self._states.copy() if self._states is not None else None

    @property
    def weights(self):
        """Get weight matrix."""
        return self._weights.copy() if self._weights is not None else None

    @property
    def biases(self):
        """Get bias vector."""
        return self._biases.copy() if self._biases is not None else None

    @property
    def energy(self):
        """Get current energy."""
        return self._energy

    @property
    def is_converged(self):
        """Check if network has converged to an attractor."""
        return self._is_converged

    @property
    def convergence_iteration(self):
        """Get iteration at which convergence occurred."""
        return self._convergence_iteration

    @property
    def energy_history(self):
        """Get energy history."""
        return self._energy_history.copy()

    @property
    def state_history(self):
        """Get state history."""
        return self._state_history.copy()

    @property
    def attractors(self):
        """Get list of found attractors."""
        return [attractor.copy() for attractor in self._attractors]

    @property
    def attractor_energies(self):
        """Get energies of found attractors."""
        return self._attractor_energies.copy()

    @property
    def num_attractors(self):
        """Get number of found attractors."""
        return len(self._attractors)
