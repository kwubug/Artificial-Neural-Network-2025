import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Button, Slider, TextBox, RadioButtons
import matplotlib.patches as patches
from scipy.spatial.distance import pdist, squareform
import time

# 设置matplotlib使用TkAgg后端
import matplotlib

matplotlib.use('TkAgg')

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


class ContinuousHopfieldTSP:
    def __init__(self, num_cities=10):
        """
        初始化连续型Hopfield神经网络解决TSP问题
        """
        self.num_cities = num_cities

        # 随机生成城市坐标
        self.cities = np.random.rand(num_cities, 2) * 10

        # 计算城市间距离矩阵
        self.distances = squareform(pdist(self.cities))

        # 初始化神经元状态 (num_cities x num_cities)
        # 每行表示一个城市，每列表示在路径中的位置
        self.neurons = np.random.rand(num_cities, num_cities)

        # 归一化神经元状态
        self.normalize_neurons()

        # 网络参数
        self.A = 500  # 路径有效性约束权重
        self.B = 500  # 每个位置只有一个城市的约束权重
        self.C = 200  # 每个城市只出现一次的约束权重
        self.D = 500  # 路径长度最小化权重

        # 时间常数
        self.tau = 1.0
        self.dt = 0.01

        # 记录历史
        self.energy_history = [self.calculate_energy()]
        self.path_length_history = [self.calculate_path_length()]
        self.neurons_history = [self.neurons.copy()]

        # 模拟状态
        self.is_running = False
        self.step_count = 0

        # 最佳路径记录
        self.best_path = None
        self.best_length = float('inf')

    def normalize_neurons(self):
        """
        归一化神经元状态，确保每行和每列的和接近1
        """
        # 行归一化 (每个城市在路径中只出现一次)
        row_sums = np.sum(self.neurons, axis=1, keepdims=True)
        self.neurons /= row_sums

        # 列归一化 (每个位置只有一个城市)
        col_sums = np.sum(self.neurons, axis=0, keepdims=True)
        self.neurons /= col_sums

    def calculate_energy(self):
        """
        计算Hopfield网络能量函数
        """
        # 路径有效性约束 (每行和每列的和为1)
        row_sums = np.sum(self.neurons, axis=1)
        col_sums = np.sum(self.neurons, axis=0)

        E_validity = 0.5 * self.A * (np.sum((row_sums - 1) ** 2) + np.sum((col_sums - 1) ** 2))

        # 路径长度约束
        E_length = 0
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                for k in range(self.num_cities):
                    # 避免重复计算
                    if j != k:
                        # 计算城市i在位置j和城市i在位置k的路径长度贡献
                        E_length += self.neurons[i, j] * self.neurons[i, k] * self.distances[j, k]

        E_length = 0.5 * self.D * E_length

        # 总能量
        total_energy = E_validity + E_length

        return total_energy

    def calculate_path_length(self, path=None):
        """
        计算当前路径长度
        """
        if path is None:
            path = self.get_current_path()

        if path is None:
            return float('inf')

        length = 0
        for i in range(self.num_cities):
            j = (i + 1) % self.num_cities
            length += self.distances[path[i], path[j]]

        return length

    def get_current_path(self):
        """
        从神经元状态解码当前路径
        """
        path = []
        for pos in range(self.num_cities):
            city = np.argmax(self.neurons[:, pos])
            if city in path:  # 无效路径
                return None
            path.append(city)

        return path

    def update_neurons(self):
        """
        更新神经元状态 (连续型Hopfield网络)
        """
        # 计算输入总和
        input_sum = np.zeros((self.num_cities, self.num_cities))

        # 路径有效性约束
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                # 行约束
                row_sum = np.sum(self.neurons[i, :]) - self.neurons[i, j]
                # 列约束
                col_sum = np.sum(self.neurons[:, j]) - self.neurons[i, j]

                input_sum[i, j] -= self.A * (row_sum - 1 + col_sum - 1)

        # 路径长度约束
        for i in range(self.num_cities):
            for j in range(self.num_cities):
                for k in range(self.num_cities):
                    if k != j:
                        input_sum[i, j] -= self.D * self.neurons[i, k] * self.distances[j, k]

        # 使用sigmoid激活函数
        self.neurons += self.dt * (-self.neurons / self.tau + input_sum)

        # 应用sigmoid函数
        self.neurons = 1 / (1 + np.exp(-self.neurons))

        # 归一化
        self.normalize_neurons()

    def step(self):
        """
        执行一步更新
        """
        self.update_neurons()
        self.step_count += 1

        # 记录历史
        self.energy_history.append(self.calculate_energy())
        current_path = self.get_current_path()

        if current_path is not None:
            current_length = self.calculate_path_length(current_path)
            self.path_length_history.append(current_length)

            # 更新最佳路径
            if current_length < self.best_length:
                self.best_length = current_length
                self.best_path = current_path.copy()
        else:
            self.path_length_history.append(float('inf'))

        self.neurons_history.append(self.neurons.copy())

    def reset(self, num_cities=None):
        """
        重置网络状态
        """
        if num_cities is not None:
            self.num_cities = num_cities
            self.cities = np.random.rand(num_cities, 2) * 10
            self.distances = squareform(pdist(self.cities))

        # 重新初始化神经元
        self.neurons = np.random.rand(self.num_cities, self.num_cities)
        self.normalize_neurons()

        # 重置历史记录
        self.energy_history = [self.calculate_energy()]
        current_path = self.get_current_path()
        self.path_length_history = [self.calculate_path_length(current_path)]
        self.neurons_history = [self.neurons.copy()]

        # 重置计数器
        self.step_count = 0

        # 重置最佳路径
        self.best_path = None
        self.best_length = float('inf')


class TSPVisualizer:
    def __init__(self, tsp_solver):
        """
        初始化TSP可视化界面
        """
        self.tsp = tsp_solver
        self.fig = plt.figure(figsize=(16, 10))
        self.setup_layout()
        self.setup_widgets()

        # 初始化可视化
        self.update_all_plots()

    def setup_layout(self):
        """
        设置可视化布局
        """
        # 创建所有子图使用绝对坐标
        # 第一行
        self.ax_cities = self.fig.add_axes([0.05, 0.65, 0.3, 0.3])  # 城市和路径
        self.ax_neurons = self.fig.add_axes([0.4, 0.65, 0.3, 0.3])  # 神经元状态
        self.ax_energy = self.fig.add_axes([0.75, 0.65, 0.2, 0.3])  # 能量变化

        # 第二行
        self.ax_path_length = self.fig.add_axes([0.05, 0.35, 0.4, 0.25])  # 路径长度变化
        self.ax_best_path = self.fig.add_axes([0.5, 0.35, 0.25, 0.25])  # 最佳路径

        # 控件区域
        self.ax_controls = self.fig.add_axes([0.8, 0.35, 0.15, 0.25])  # 控件区域
        self.ax_controls.axis('off')  # 隐藏控件区域的坐标轴

        # 参数调整区域
        self.ax_params = self.fig.add_axes([0.05, 0.05, 0.9, 0.25])  # 参数调整区域
        self.ax_params.axis('off')  # 隐藏参数区域的坐标轴

        self.fig.suptitle('连续型Hopfield神经网络解决旅行商问题(TSP)', fontsize=16, fontweight='bold')

    def setup_widgets(self):
        """
        设置交互控件
        """
        # 控制按钮
        ax_button_run = self.fig.add_axes([0.82, 0.55, 0.1, 0.04])
        ax_button_step = self.fig.add_axes([0.82, 0.50, 0.1, 0.04])
        ax_button_reset = self.fig.add_axes([0.82, 0.45, 0.1, 0.04])
        ax_button_new = self.fig.add_axes([0.82, 0.40, 0.1, 0.04])

        # 参数滑块
        ax_slider_A = self.fig.add_axes([0.1, 0.15, 0.2, 0.02])
        ax_slider_B = self.fig.add_axes([0.1, 0.12, 0.2, 0.02])
        ax_slider_C = self.fig.add_axes([0.1, 0.09, 0.2, 0.02])
        ax_slider_D = self.fig.add_axes([0.1, 0.06, 0.2, 0.02])

        ax_slider_tau = self.fig.add_axes([0.5, 0.15, 0.2, 0.02])
        ax_slider_dt = self.fig.add_axes([0.5, 0.12, 0.2, 0.02])

        # 城市数量输入框
        ax_text_cities = self.fig.add_axes([0.8, 0.15, 0.1, 0.04])

        # 创建按钮
        self.button_run = Button(ax_button_run, '运行/暂停')
        self.button_step = Button(ax_button_step, '单步更新')
        self.button_reset = Button(ax_button_reset, '重置网络')
        self.button_new = Button(ax_button_new, '新问题')

        # 创建滑块
        self.slider_A = Slider(ax_slider_A, 'A (有效性)', 100, 1000, valinit=self.tsp.A)
        self.slider_B = Slider(ax_slider_B, 'B (位置约束)', 100, 1000, valinit=self.tsp.B)
        self.slider_C = Slider(ax_slider_C, 'C (城市约束)', 100, 1000, valinit=self.tsp.C)
        self.slider_D = Slider(ax_slider_D, 'D (路径长度)', 100, 1000, valinit=self.tsp.D)

        self.slider_tau = Slider(ax_slider_tau, 'τ (时间常数)', 0.1, 5.0, valinit=self.tsp.tau)
        self.slider_dt = Slider(ax_slider_dt, 'Δt (步长)', 0.001, 0.1, valinit=self.tsp.dt)

        # 创建文本框
        self.text_cities = TextBox(ax_text_cities, '城市数:', initial=str(self.tsp.num_cities))

        # 绑定事件
        self.button_run.on_clicked(self.toggle_run)
        self.button_step.on_clicked(self.step_update)
        self.button_reset.on_clicked(self.reset_network)
        self.button_new.on_clicked(self.new_problem)

        self.slider_A.on_changed(self.update_parameter_A)
        self.slider_B.on_changed(self.update_parameter_B)
        self.slider_C.on_changed(self.update_parameter_C)
        self.slider_D.on_changed(self.update_parameter_D)
        self.slider_tau.on_changed(self.update_parameter_tau)
        self.slider_dt.on_changed(self.update_parameter_dt)

        self.text_cities.on_submit(self.update_cities)

    def toggle_run(self, event):
        """
        切换运行/暂停状态
        """
        self.tsp.is_running = not self.tsp.is_running
        if self.tsp.is_running:
            self.run_simulation()

    def step_update(self, event):
        """
        单步更新
        """
        self.tsp.step()
        self.update_all_plots()

    def reset_network(self, event):
        """
        重置网络状态
        """
        self.tsp.reset()
        self.update_all_plots()

    def new_problem(self, event):
        """
        生成新问题
        """
        self.tsp.reset(self.tsp.num_cities)
        self.update_all_plots()

    def update_parameter_A(self, val):
        """
        更新参数A
        """
        self.tsp.A = val

    def update_parameter_B(self, val):
        """
        更新参数B
        """
        self.tsp.B = val

    def update_parameter_C(self, val):
        """
        更新参数C
        """
        self.tsp.C = val

    def update_parameter_D(self, val):
        """
        更新参数D
        """
        self.tsp.D = val

    def update_parameter_tau(self, val):
        """
        更新参数tau
        """
        self.tsp.tau = val

    def update_parameter_dt(self, val):
        """
        更新参数dt
        """
        self.tsp.dt = val

    def update_cities(self, text):
        """
        更新城市数量
        """
        try:
            new_num = int(text)
            if new_num > 2 and new_num <= 20:  # 限制城市数量范围
                self.tsp.reset(new_num)
                self.update_all_plots()
            else:
                print("城市数量必须在3到20之间")
        except ValueError:
            print("请输入有效的整数")

    def run_simulation(self):
        """
        运行模拟
        """
        while self.tsp.is_running and self.tsp.step_count < 5000:
            self.tsp.step()
            self.update_all_plots()
            plt.pause(0.01)

            # 每100步显示一次进度
            if self.tsp.step_count % 100 == 0:
                print(f"已运行 {self.tsp.step_count} 步，当前路径长度: {self.tsp.path_length_history[-1]:.3f}")

    def update_all_plots(self):
        """
        更新所有子图
        """
        self.plot_cities()
        self.plot_neurons()
        self.plot_energy()
        self.plot_path_length()
        self.plot_best_path()
        self.plot_parameters()

    def plot_cities(self):
        """
        绘制城市和当前路径
        """
        self.ax_cities.clear()

        # 绘制城市
        self.ax_cities.scatter(self.tsp.cities[:, 0], self.tsp.cities[:, 1],
                               c='red', s=100, zorder=5)

        # 添加城市标签
        for i, (x, y) in enumerate(self.tsp.cities):
            self.ax_cities.text(x, y, f'{i}', fontsize=12, ha='center', va='center',
                                bbox=dict(boxstyle="circle,pad=0.3", facecolor="white", alpha=0.7))

        # 绘制当前路径
        current_path = self.tsp.get_current_path()
        if current_path is not None:
            # 连接城市形成路径
            path_coords = self.tsp.cities[current_path]
            path_coords = np.vstack([path_coords, path_coords[0]])  # 闭合路径

            self.ax_cities.plot(path_coords[:, 0], path_coords[:, 1], 'b-', linewidth=2, alpha=0.7)

            # 显示当前路径长度
            path_length = self.tsp.calculate_path_length(current_path)
            self.ax_cities.set_title(f'当前路径 (长度: {path_length:.3f})', fontsize=12, fontweight='bold')
        else:
            self.ax_cities.set_title('当前路径 (无效)', fontsize=12, fontweight='bold')

        self.ax_cities.set_xlabel('X坐标')
        self.ax_cities.set_ylabel('Y坐标')
        self.ax_cities.grid(True, alpha=0.3)
        self.ax_cities.set_aspect('equal')

    def plot_neurons(self):
        """
        绘制神经元状态
        """
        self.ax_neurons.clear()

        im = self.ax_neurons.imshow(self.tsp.neurons, cmap='hot', aspect='auto')

        self.ax_neurons.set_title('神经元状态矩阵', fontsize=12, fontweight='bold')
        self.ax_neurons.set_xlabel('路径位置')
        self.ax_neurons.set_ylabel('城市')

        # 添加颜色条
        plt.colorbar(im, ax=self.ax_neurons, shrink=0.8)

    def plot_energy(self):
        """
        绘制能量变化
        """
        self.ax_energy.clear()

        if len(self.tsp.energy_history) > 1:
            self.ax_energy.plot(self.tsp.energy_history, color='purple', linewidth=2)
            self.ax_energy.scatter(len(self.tsp.energy_history) - 1,
                                   self.tsp.energy_history[-1],
                                   color='purple', s=50, zorder=5)

        self.ax_energy.set_title('能量函数变化', fontsize=12, fontweight='bold')
        self.ax_energy.set_xlabel('时间步')
        self.ax_energy.set_ylabel('能量')
        self.ax_energy.grid(True, alpha=0.3)

        # 显示当前能量值
        if self.tsp.energy_history:
            current_energy = self.tsp.energy_history[-1]
            self.ax_energy.text(0.02, 0.98, f'当前能量: {current_energy:.3f}',
                                transform=self.ax_energy.transAxes, fontsize=10,
                                bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

    def plot_path_length(self):
        """
        绘制路径长度变化
        """
        self.ax_path_length.clear()

        if len(self.tsp.path_length_history) > 1:
            # 过滤无穷大值
            valid_lengths = [length for length in self.tsp.path_length_history if length != float('inf')]
            if valid_lengths:
                self.ax_path_length.plot(range(len(valid_lengths)), valid_lengths, color='green', linewidth=2)

                # 标记当前点
                if self.tsp.path_length_history[-1] != float('inf'):
                    self.ax_path_length.scatter(len(valid_lengths) - 1,
                                                self.tsp.path_length_history[-1],
                                                color='green', s=50, zorder=5)

        self.ax_path_length.set_title('路径长度变化', fontsize=12, fontweight='bold')
        self.ax_path_length.set_xlabel('时间步')
        self.ax_path_length.set_ylabel('路径长度')
        self.ax_path_length.grid(True, alpha=0.3)

        # 显示当前路径长度
        if self.tsp.path_length_history[-1] != float('inf'):
            current_length = self.tsp.path_length_history[-1]
            self.ax_path_length.text(0.02, 0.98, f'当前长度: {current_length:.3f}',
                                     transform=self.ax_path_length.transAxes, fontsize=10,
                                     bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8))

    def plot_best_path(self):
        """
        绘制最佳路径
        """
        self.ax_best_path.clear()

        if self.tsp.best_path is not None:
            # 绘制城市
            self.ax_best_path.scatter(self.tsp.cities[:, 0], self.tsp.cities[:, 1],
                                      c='red', s=100, zorder=5)

            # 添加城市标签
            for i, (x, y) in enumerate(self.tsp.cities):
                self.ax_best_path.text(x, y, f'{i}', fontsize=12, ha='center', va='center',
                                       bbox=dict(boxstyle="circle,pad=0.3", facecolor="white", alpha=0.7))

            # 绘制最佳路径
            best_path_coords = self.tsp.cities[self.tsp.best_path]
            best_path_coords = np.vstack([best_path_coords, best_path_coords[0]])  # 闭合路径

            self.ax_best_path.plot(best_path_coords[:, 0], best_path_coords[:, 1], 'g-', linewidth=2, alpha=0.7)

            self.ax_best_path.set_title(f'最佳路径 (长度: {self.tsp.best_length:.3f})', fontsize=12, fontweight='bold')
        else:
            self.ax_best_path.text(0.5, 0.5, '尚未找到有效路径',
                                   ha='center', va='center', transform=self.ax_best_path.transAxes,
                                   fontsize=12, bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow"))
            self.ax_best_path.set_title('最佳路径', fontsize=12, fontweight='bold')

        self.ax_best_path.set_xlabel('X坐标')
        self.ax_best_path.set_ylabel('Y坐标')
        self.ax_best_path.grid(True, alpha=0.3)
        self.ax_best_path.set_aspect('equal')

    def plot_parameters(self):
        """
        显示当前参数值
        """
        self.ax_params.clear()

        # 显示当前参数值
        params_text = (
            f"网络参数:\n"
            f"A (有效性约束): {self.tsp.A:.1f}\n"
            f"B (位置约束): {self.tsp.B:.1f}\n"
            f"C (城市约束): {self.tsp.C:.1f}\n"
            f"D (路径长度): {self.tsp.D:.1f}\n"
            f"τ (时间常数): {self.tsp.tau:.2f}\n"
            f"Δt (步长): {self.tsp.dt:.3f}\n"
            f"城市数量: {self.tsp.num_cities}\n"
            f"步数: {self.tsp.step_count}"
        )

        self.ax_params.text(0.02, 0.9, params_text, fontsize=10, va='top',
                            bbox=dict(boxstyle="round,pad=0.5", facecolor="lightblue", alpha=0.7))

        # 显示当前状态
        status = "运行中" if self.tsp.is_running else "暂停"
        current_path = self.tsp.get_current_path()
        path_status = "有效" if current_path is not None else "无效"

        status_text = (
            f"模拟状态: {status}\n"
            f"当前路径: {path_status}\n"
        )

        if current_path is not None:
            status_text += f"路径顺序: {current_path}"

        self.ax_params.text(0.5, 0.9, status_text, fontsize=10, va='top',
                            bbox=dict(boxstyle="round,pad=0.5", facecolor="lightgreen", alpha=0.7))

        self.ax_params.axis('off')


def main():
    """
    主函数 - 运行TSP可视化沙箱
    """
    print("初始化连续型Hopfield神经网络TSP求解器...")
    print("城市数量: 10")
    print("\n功能说明:")
    print("1. 动态演化过程: 可视化神经网络状态和路径优化过程")
    print("2. 城市节点和路径: 显示当前路径和最佳路径")
    print("3. 网络参数调整: 可调整权重矩阵和能量函数参数")
    print("4. 交互控制: 暂停/继续/重置模拟")
    print("5. 实时监控: 显示能量函数值和路径长度变化")
    print("6. 测试案例: 支持不同城市数量和初始配置")

    # 创建TSP求解器实例
    tsp_solver = ContinuousHopfieldTSP(num_cities=10)

    # 创建可视化器
    visualizer = TSPVisualizer(tsp_solver)

    print("\n沙箱已启动!")
    print("使用界面控件进行操作:")
    print("- 运行/暂停: 开始或暂停模拟")
    print("- 单步更新: 执行一次网络更新")
    print("- 重置网络: 重置网络状态")
    print("- 新问题: 生成新的城市布局")
    print("- 参数滑块: 调整网络参数")
    print("- 城市数: 修改问题规模")

    plt.show()


if __name__ == "__main__":
    main()