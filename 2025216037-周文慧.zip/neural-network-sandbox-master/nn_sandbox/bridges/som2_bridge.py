import time
import numpy as np
import PyQt5.QtCore
import threading

# 尝试从多个位置导入算法
try:
    from nn_sandbox.backend.algorithms.som2_algorithm import Som2Algorithm
except ImportError:
    Som2Algorithm = None

from . import Bridge, BridgeProperty
from .observer import Observable


class Som2Bridge(Bridge):
    """SOM2 Bridge实现，用于训练5×5的SOM网络"""

    ui_refresh_interval = BridgeProperty(0.05)
    dataset_dict = BridgeProperty({})  # 保留，但不使用
    current_dataset_name = BridgeProperty('5x5_fixed_dataset')
    total_epoches = BridgeProperty(10000)
    initial_learning_rate = BridgeProperty(0.5)
    initial_standard_deviation = BridgeProperty(2.0)
    topology_shape = BridgeProperty([5, 5])
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    current_standard_deviation = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_synaptic_weights = BridgeProperty([])
    current_winner_position = BridgeProperty([])

    def __init__(self):
        super().__init__()
        self.som2_algorithm = None
        self.weight_snapshots = []
        # 🔥 使用私有实例变量存储数据集
        self._som2_dataset = {
            'inputs': np.array([
                [1, 0, 0, 0],
                [1, 1, 0, 0],
                [1, 1, 1, 0],
                [0, 1, 0, 0],
                [1, 1, 1, 1]
            ]),
            'targets': None
        }
        
        self._initialize_weights()

    def _initialize_weights(self):
        """初始化神经元权重用于显示"""
        initial_weights = []
        for i in range(5):
            row = []
            for j in range(5):
                weight = np.random.rand(4).tolist()
                row.append(weight)
            initial_weights.append(row)
        self.current_synaptic_weights = initial_weights

    @PyQt5.QtCore.pyqtSlot()
    def start_som2_algorithm(self):
        """开始SOM2训练"""
        print(f"🔵 开始训练")
        
        # 🔥 使用私有数据集
        ui_refresh = self.ui_refresh_interval
        dataset = self._som2_dataset  # 不再依赖共享的 dataset_dict
        epoches = self.total_epoches
        lr = self.initial_learning_rate
        sd = self.initial_standard_deviation
        shape = self.topology_shape
        
        self.som2_algorithm = ObservableSom2Algorithm(
            self,
            ui_refresh,
            dataset=dataset,
            total_epoches=epoches,
            initial_learning_rate=lr,
            initial_standard_deviation=sd,
            topology_shape=shape
        )
        self.som2_algorithm.start()
        print(f"🟢 训练线程已启动")

    def on_notify(self, event_name, data):
        if event_name == 'weight_snapshot':
            self.weight_snapshots.append(data)
            print(f"已保存快照 {len(self.weight_snapshots)}: 迭代次数 {data['iteration']}")

    @PyQt5.QtCore.pyqtSlot()
    def stop_som2_algorithm(self):
        """停止SOM2训练"""
        if self.som2_algorithm:
            self.som2_algorithm.stop()

    @PyQt5.QtCore.pyqtSlot()
    def test_connection(self):
        print(">>> SOM2 Bridge connected successfully")


class ObservableSom2Algorithm(Observable, threading.Thread):
    """可观察的SOM2算法实现"""

    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)

        # 初始化算法参数
        self.dataset = kwargs.get('dataset', {})
        self.total_epoches = kwargs.get('total_epoches', 10000)
        self.initial_learning_rate = kwargs.get('initial_learning_rate', 0.5)
        self.initial_standard_deviation = kwargs.get('initial_standard_deviation', 2.0)
        self.topology_shape = kwargs.get('topology_shape', [5, 5])

        # 处理数据集
        if isinstance(self.dataset, dict) and 'inputs' in self.dataset:
            self.dataset = np.array(self.dataset['inputs'])
        else:
            self.dataset = np.array(self.dataset)

        # 初始化线程
        threading.Thread.__init__(self)

        # UI刷新间隔
        self.ui_refresh_interval = ui_refresh_interval
        self.min_learning_rate = 0.04
        self.min_standard_deviation = 0.0

        # 初始化神经元
        self._init_neurons()
        self.current_iterations = 0
        self._should_stop = False

    def _init_neurons(self):
        """初始化神经元网格"""
        rows, cols = self.topology_shape
        input_dim = self.dataset.shape[1] if len(self.dataset.shape) > 1 else 4

        self._neurons = []
        for i in range(rows):
            row = []
            for j in range(cols):
                neuron = type('Neuron', (), {
                    'synaptic_weight': np.random.rand(input_dim)
                })()
                row.append(neuron)
            self._neurons.append(row)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            # 通知权重更新
            if hasattr(self, '_neurons'):
                self.notify('current_synaptic_weights',
                           [[neuron.synaptic_weight.tolist()
                             for neuron in row] for row in self._neurons])

    def run(self):
        """运行训练过程"""
        self.notify('has_finished', False)

        # 训练主循环
        while self.current_iterations < self.total_epoches:
            if self._should_stop:
                break
            self._iterate()

        self.notify('has_finished', True)

    def stop(self):
        """停止训练"""
        self._should_stop = True

    def _iterate(self):
        """单次迭代"""
        # 随机选择一个输入模式
        idx = np.random.randint(0, len(self.dataset))
        input_vector = self.dataset[idx]

        # 找到优胜神经元
        winner = self._find_winner_neuron(input_vector)

        # 更新权重
        self._update_weights(input_vector, winner)

        # 增加迭代计数
        self.current_iterations += 1

        if self.current_iterations % 200 == 0:
            self._save_weight_snapshot()

        # 控制UI刷新频率
        time.sleep(self.ui_refresh_interval)

    def _save_weight_snapshot(self):
        """保存权重快照（用于后续分析）"""
        snapshot = {
            'iteration': self.current_iterations,
            'weights': [[neuron.synaptic_weight.copy()
                         for neuron in row] for row in self._neurons],
            'learning_rate': self.current_learning_rate,
            'neighborhood_radius': self.current_standard_deviation
        }
        # 可以通过notify发送快照数据
        self.get_output_mapping

    @property
    def current_learning_rate(self):
        """计算当前学习率，线性递减到0.04"""
        if self.current_iterations >= 10000:
            return self.min_learning_rate

        # 线性递减
        decay_rate = (self.initial_learning_rate - self.min_learning_rate) / 10000
        current_rate = self.initial_learning_rate - decay_rate * self.current_iterations

        ret = max(current_rate, self.min_learning_rate)
        self.notify('current_learning_rate', ret)
        return ret

    @property
    def current_standard_deviation(self):
        """计算当前邻域半径，线性递减到0"""
        if self.current_iterations >= 10000:
            return self.min_standard_deviation

        # 线性递减
        decay_rate = self.initial_standard_deviation / 10000
        current_sd = self.initial_standard_deviation - decay_rate * self.current_iterations

        ret = max(current_sd, self.min_standard_deviation)
        self.notify('current_standard_deviation', ret)
        return ret

    def _find_winner_neuron(self, input_vector):
        """找到优胜神经元"""
        min_distance = float('inf')
        winner = None
        winner_pos = (0, 0)

        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                distance = np.linalg.norm(input_vector - neuron.synaptic_weight)
                if distance < min_distance:
                    min_distance = distance
                    winner = neuron
                    winner_pos = (i, j)

        # 通知优胜神经元位置
        self.notify('current_winner_position', list(winner_pos))
        return winner

    def _get_neuron_position(self, target_neuron):
        """获取神经元位置"""
        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                if neuron == target_neuron:
                    return (i, j)
        return None

    def _calculate_influence(self, winner_pos, neuron_pos, radius):
        """计算邻域影响函数"""
        if radius <= 0:
            return 1.0 if winner_pos == neuron_pos else 0.0

        distance = np.sqrt((winner_pos[0] - neuron_pos[0]) ** 2 +
                           (winner_pos[1] - neuron_pos[1]) ** 2)
        return np.exp(-(distance ** 2) / (2 * radius ** 2))

    def _update_weights(self, input_vector, winner):
        """更新权重"""
        winner_pos = self._get_neuron_position(winner)
        if winner_pos is None:
            return

        learning_rate = self.current_learning_rate
        radius = self.current_standard_deviation

        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                influence = self._calculate_influence(winner_pos, (i, j), radius)
                if influence > 0:
                    delta = learning_rate * influence * (input_vector - neuron.synaptic_weight)
                    neuron.synaptic_weight += delta

    def get_output_mapping(self):
        """获取5个输入模式在输出平面的映射图"""
        mapping = {}

        for idx, input_pattern in enumerate(self.dataset):
            winner = self._find_winner_neuron(input_pattern)
            # 找到优胜神经元的网格位置
            position = self._get_neuron_position(winner)
            if position:
                mapping[f'X{idx + 1}'] = position

        return mapping