from PyQt5.QtCore import pyqtSignal, QThread, pyqtProperty, pyqtSlot, QVariant
import numpy as np
import plotly.graph_objects as go

class GradientDescentVisualizerBridge(QThread):
    # 定义信号
    iterationChanged = pyqtSignal()  # 迭代次数变化信号
    weightsUpdated = pyqtSignal()    # 权重更新信号（用于更新路径）
    visualizationUpdated = pyqtSignal()  # 更新可视化图形
    trainingComplete = pyqtSignal()  # 训练完成信号

    # 参数变化信号
    learningRateChanged = pyqtSignal()
    batchSizeChanged = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._learning_rate = 0.1
        self._batch_size = 10
        self._iteration = 0
        self._is_training = False


    # 学习率属性
    @pyqtProperty(float, notify=learningRateChanged)
    def learningRate(self):
        return self._learning_rate

    @learningRate.setter
    def learningRate(self, value):
        if self._learning_rate != value:
            self._learning_rate = value
            self.learningRateChanged.emit()

    # 批大小属性
    @pyqtProperty(int, notify=batchSizeChanged)
    def batchSize(self):
        return self._batch_size

    @batchSize.setter
    def batchSize(self, value):
        if self._batch_size != value:
            self._batch_size = value
            self.batchSizeChanged.emit()

    # 迭代属性
    @pyqtProperty(int, notify=iterationChanged)
    def iteration(self):
        return self._iteration

    @iteration.setter
    def iteration(self, value):
        if self._iteration != value:
            self._iteration = value
            self.iterationChanged.emit()

    # 修改后的 weightsList 属性
    @pyqtProperty(QVariant, notify=weightsUpdated)
    def weightsList(self):
        """获取权重列表并转换为 QVariantList 格式"""
        return [QVariant([float(w) for w in weight_row]) for weight_row in self.weights.tolist()]

    # 初始化路径
    def initialize_paths(self):
        self.path1 = []
        self.path2 = []
        self.path3 = []
        self.weightsUpdated.emit()

    # 梯度计算
    def gradient(self, x, y):
        return np.array([2 * x, 2 * y])

    # 使用 Plotly 进行可视化更新
    @pyqtSlot()
    def updateVisualization(self):
        # 创建3D图形
        fig = go.Figure()

        # 绘制 3D 表面
        x_range = np.linspace(-5, 5, 100)
        y_range = np.linspace(-5, 5, 100)
        X, Y = np.meshgrid(x_range, y_range)
        Z = X**2 + Y**2
        fig.add_trace(go.Surface(z=Z, x=X, y=Y, colorscale='Viridis', opacity=0.7))

        # 绘制路径
        for path, color in zip([self.path1, self.path2, self.path3], ['red', 'blue', 'yellow']):
            if len(path) > 1:
                path = np.array(path)
                fig.add_trace(go.Scatter3d(
                    x=path[:, 0],
                    y=path[:, 1],
                    z=path[:, 0]**2 + path[:, 1]**2,
                    mode='lines+markers',
                    line=dict(color=color),
                    marker=dict(size=4)
                ))

        # 更新布局
        fig.update_layout(
            title="Gradient Descent Visualization",
            scene=dict(
                xaxis_title='X',
                yaxis_title='Y',
                zaxis_title='Z'
            )
        )

        # 显示图形（可以在浏览器中查看）
        fig.show()
        self.visualizationUpdated.emit()

    # 样本训练
    def update_weights(self):
        for i in range(3):
            grad1 = self.gradient(self.x1, self.y1)
            grad2 = self.gradient(self.x2, self.y2)
            grad3 = self.gradient(self.x3, self.y3)

            # Standard Gradient Descent
            self.x1 -= self.learning_rate * grad1[0]
            self.y1 -= self.learning_rate * grad1[1]
            self.path1.append((self.x1, self.y1))

            self.x2 -= self.learning_rate * grad2[0] * np.random.random()
            self.y2 -= self.learning_rate * grad2[1] * np.random.random()
            self.path2.append((self.x2, self.y2))

            noise = np.random.randn() * 0.5 / self.batch_size
            self.x3 -= self.learning_rate * grad3[0] * (1 + noise)
            self.y3 -= self.learning_rate * grad3[1] * (1 + noise)
            self.path3.append((self.x3, self.y3))

            self.iteration += 1
        self.weightsUpdated.emit()

    # 启动训练
    @pyqtSlot()
    def startTraining(self):
        self.iteration=0
        self.x1 = np.random.uniform(-5, 5)
        self.y1 = np.random.uniform(-5, 5)
        self.x2 = self.x1
        self.y2 = self.y1
        self.x3 = self.x1
        self.y3 = self.y1
        self.batch_size = 10
        self.learning_rate = 0.1
        self.iteration = 0

        self.path1 = []
        self.path2 = []
        self.path3 = []

        self._is_training = True
        self.initialize_paths()

        # 第一次可视化更新（显示初始状态）
        self.updateVisualization()

        # 进行梯度下降训练，只在最后一次迭代进行可视化更新
        while self._is_training and self.iteration < 100:
            self.update_weights()
            self.iteration += 1

        # 训练结束后进行最后一次可视化更新
        self.updateVisualization()
        self._is_training = False
        self.trainingComplete.emit()
    # 停止训练
    @pyqtSlot()
    def stopTraining(self):
        self._is_training = False

