from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QPushButton, QTextEdit, QLabel,
                               QSpinBox, QFileDialog, QMessageBox, QGridLayout,
                               QDoubleSpinBox, QProgressBar)
from PySide6.QtCore import Slot, Qt, QThread, Signal
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os
import time

# 确保负号和字体显示正确
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


class BoltzmannMachine:
    def __init__(self, n_neurons, learning_rate=0.1, temperature=1.0):
        self.n = n_neurons  # 神经元数量
        self.lr = learning_rate  # 学习率
        self.T = temperature  # 温度参数（控制随机性）
        self.weights = np.zeros((n_neurons, n_neurons))  # 权重矩阵
        self.biases = np.zeros(n_neurons)  # 偏置项
        self.state = np.zeros(n_neurons)  # 当前状态（0=关闭，1=激活）

    def sigmoid(self, x):
        """Sigmoid激活函数"""
        return 1 / (1 + np.exp(-x / self.T))

    def energy(self):
        """计算网络能量"""
        return -0.5 * np.dot(self.state.T, np.dot(self.weights, self.state)) - np.dot(self.biases, self.state)

    def sample_state(self, idx):
        """采样单个神经元的状态（吉布斯采样）"""
        # 计算输入总和
        net_input = np.dot(self.weights[idx], self.state) + self.biases[idx]
        # 计算激活概率
        prob = self.sigmoid(net_input)
        # 采样状态
        self.state[idx] = 1 if np.random.rand() < prob else 0

    def gibbs_sampling(self, n_steps=1):
        """吉布斯采样（更新所有神经元状态）"""
        for _ in range(n_steps):
            # 随机顺序更新每个神经元
            indices = np.random.permutation(self.n)
            for idx in indices:
                self.sample_state(idx)

    def train(self, data, n_epochs=100, n_samples=10):
        """训练：对比散度（CD-k）算法"""
        n_data = len(data)
        for epoch in range(n_epochs):
            total_error = 0
            for i in range(n_data):
                # 1. 正相：从数据中采样（设置初始状态为数据）
                self.state = data[i].copy()
                positive_energy = self.energy()
                positive_corr = np.outer(self.state, self.state)  # 正相关矩阵

                # 2. 负相：从模型中采样（吉布斯采样）
                self.gibbs_sampling(n_steps=n_samples)
                negative_energy = self.energy()
                negative_corr = np.outer(self.state, self.state)  # 负相关矩阵

                # 3. 更新权重和偏置
                self.weights += self.lr * (positive_corr - negative_corr) / n_data
                self.biases += self.lr * (data[i] - self.state) / n_data

                # 计算误差（能量差）
                total_error += abs(positive_energy - negative_energy)

            # 每10轮输出一次进度
            if (epoch + 1) % 10 == 0:
                yield epoch + 1, total_error / n_data

    def generate_samples(self, n_samples=10, n_burn_in=100):
        """生成样本（先 burn-in 再采样）"""
        samples = []
        # Burn-in：丢弃初始不稳定的样本
        self.state = np.random.randint(0, 2, self.n)
        self.gibbs_sampling(n_steps=n_burn_in)

        # 采样
        for _ in range(n_samples):
            self.gibbs_sampling(n_steps=1)
            samples.append(self.state.copy())

        return samples


class TrainThread(QThread):
    """训练线程（避免UI卡死）"""
    progress = Signal(int, float)  # epoch, error
    finished = Signal()

    def __init__(self, bm, data, n_epochs, n_samples):
        super().__init__()
        self.bm = bm
        self.data = data
        self.n_epochs = n_epochs
        self.n_samples = n_samples

    def run(self):
        for epoch, error in self.bm.train(self.data, self.n_epochs, self.n_samples):
            self.progress.emit(epoch, error)
        self.finished.emit()


class BoltzmannMachineWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None
        self.canvas = None
        self.bm = None  # Boltzmann机实例
        self.train_data = []  # 训练数据
        self.train_thread = None  # 训练线程
        self.init_ui()

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 1. 控制面板（参数设置）
        control_group = QGroupBox("参数设置（Boltzmann机）")
        control_layout = QGridLayout()

        # 神经元数量
        control_layout.addWidget(QLabel("神经元数量:"), 0, 0)
        self.neuron_spin = QSpinBox()
        self.neuron_spin.setRange(2, 10)  # 2到10个神经元
        self.neuron_spin.setValue(3)
        self.neuron_spin.valueChanged.connect(self.on_neuron_count_changed)
        control_layout.addWidget(self.neuron_spin, 0, 1)

        # 学习率
        control_layout.addWidget(QLabel("学习率:"), 1, 0)
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.01, 1.0)
        self.lr_spin.setValue(0.1)
        self.lr_spin.setSingleStep(0.01)
        self.lr_spin.setDecimals(2)
        control_layout.addWidget(self.lr_spin, 1, 1)

        # 温度
        control_layout.addWidget(QLabel("温度（T）:"), 2, 0)
        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.1, 5.0)
        self.temp_spin.setValue(1.0)
        self.temp_spin.setSingleStep(0.1)
        self.temp_spin.setDecimals(1)
        control_layout.addWidget(self.temp_spin, 2, 1)

        # 训练轮数
        control_layout.addWidget(QLabel("训练轮数:"), 3, 0)
        self.epoch_spin = QSpinBox()
        self.epoch_spin.setRange(50, 1000)
        self.epoch_spin.setValue(200)
        self.epoch_spin.setSingleStep(50)
        control_layout.addWidget(self.epoch_spin, 3, 1)

        # CD-k 采样步数
        control_layout.addWidget(QLabel("CD-k 采样步数:"), 4, 0)
        self.sample_spin = QSpinBox()
        self.sample_spin.setRange(1, 20)
        self.sample_spin.setValue(10)
        self.sample_spin.setSingleStep(1)
        control_layout.addWidget(self.sample_spin, 4, 1)

        # 按钮布局
        button_layout = QHBoxLayout()
        self.init_btn = QPushButton("初始化Boltzmann机")
        self.init_btn.clicked.connect(self.init_bm)
        self.add_data_btn = QPushButton("添加训练数据")
        self.add_data_btn.clicked.connect(self.add_train_data)
        self.train_btn = QPushButton("开始训练")
        self.train_btn.clicked.connect(self.start_train)
        self.generate_btn = QPushButton("生成样本")
        self.generate_btn.clicked.connect(self.generate_samples)
        self.save_btn = QPushButton("保存结果")
        self.save_btn.clicked.connect(self.save_figure)
        button_layout.addWidget(self.init_btn)
        button_layout.addWidget(self.add_data_btn)
        button_layout.addWidget(self.train_btn)
        button_layout.addWidget(self.generate_btn)
        button_layout.addWidget(self.save_btn)
        control_layout.addLayout(button_layout, 5, 0, 1, 2)

        # 训练进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        control_layout.addWidget(self.progress_bar, 6, 0, 1, 2)

        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 2. 结果显示区域
        result_layout = QHBoxLayout()

        # 文本输出（关键：提前创建，确保on_neuron_count_changed调用时存在）
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用Boltzmann机界面！")
        self.text_output.append("支持功能：训练数据添加、模型训练、样本生成")
        self.text_output.append("步骤：1. 设置神经元数量 → 2. 初始化网络 → 3. 添加训练数据 → 4. 训练 → 5. 生成样本")
        result_layout.addWidget(self.text_output, 1)

        # 图形显示
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)

        main_layout.addLayout(result_layout, 1)

        # 3. 训练数据输入网格（动态创建）
        self.data_grid = QGridLayout()
        self.data_buttons = []
        self.on_neuron_count_changed(self.neuron_spin.value())  # 初始化数据输入网格（现在text_output已存在）

    def initialize_plot(self):
        """初始化绘图区域"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(8, 6), dpi=100)
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        # 初始绘制提示图
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "等待初始化Boltzmann机...", ha='center', va='center', fontsize=14)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot(int)
    def on_neuron_count_changed(self, count):
        """神经元数量变化时，更新训练数据输入网格"""
        # 清空之前的按钮
        for btn in self.data_buttons:
            btn.deleteLater()
        self.data_buttons.clear()
        while self.data_grid.count():
            item = self.data_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # 创建新的训练数据输入网格（每行一个样本，每列一个神经元状态）
        data_group = QGroupBox(f"训练数据输入（每行一个样本，点击切换0/1）")
        # 添加表头（神经元编号）
        for j in range(count):
            label = QLabel(f"神经元{j + 1}")
            label.setAlignment(Qt.AlignCenter)
            self.data_grid.addWidget(label, 0, j)

        # 添加第一行样本输入按钮
        for j in range(count):
            btn = QPushButton("0")
            btn.setStyleSheet("background-color: #f0f0f0; border: 1px solid gray;")
            btn.setFixedSize(40, 30)
            btn.clicked.connect(lambda _, row=1, col=j: self.toggle_data_bit(row, col))
            self.data_grid.addWidget(btn, 1, j)
            self.data_buttons.append((1, j, btn))

        # 添加"添加行"按钮
        add_row_btn = QPushButton("+ 添加样本行")
        add_row_btn.clicked.connect(self.add_data_row)
        self.data_grid.addWidget(add_row_btn, 2, 0, 1, count)

        data_group.setLayout(self.data_grid)
        # 将数据组添加到主布局（插入到控制面板下方）
        self.layout().insertWidget(1, data_group)

        # 现在text_output已存在，可安全调用append
        self.text_output.append(f"\n神经元数量设置为：{count}（状态总数：{2 ** count}种）")
        self.text_output.append("提示：点击数据网格按钮切换神经元状态（0/1）")

    @Slot()
    def add_data_row(self):
        """添加一行训练数据输入"""
        count = self.neuron_spin.value()
        current_rows = len(self.data_buttons) // count + 1  # 当前行数（表头+数据行）
        new_row = current_rows  # 新行号

        # 添加新行的按钮
        for j in range(count):
            btn = QPushButton("0")
            btn.setStyleSheet("background-color: #f0f0f0; border: 1px solid gray;")
            btn.setFixedSize(40, 30)
            btn.clicked.connect(lambda _, row=new_row, col=j: self.toggle_data_bit(row, col))
            self.data_grid.addWidget(btn, new_row, j)
            self.data_buttons.append((new_row, j, btn))

        # 移动"添加行"按钮到新行下方
        self.data_grid.addWidget(self.data_grid.takeAt(self.data_grid.count() - 1).widget(), new_row + 1, 0, 1, count)

    @Slot(int, int)
    def toggle_data_bit(self, row, col):
        """切换训练数据的某个比特（0↔1）"""
        for r, c, btn in self.data_buttons:
            if r == row and c == col:
                current_text = btn.text()
                new_text = "1" if current_text == "0" else "0"
                btn.setText(new_text)
                # 切换背景色（1=蓝色，0=灰色）
                btn.setStyleSheet(
                    f"background-color: {'#4a90e2' if new_text == '1' else '#f0f0f0'}; border: 1px solid gray;")
                break

    @Slot()
    def init_bm(self):
        """初始化Boltzmann机"""
        n_neurons = self.neuron_spin.value()
        lr = self.lr_spin.value()
        temp = self.temp_spin.value()
        self.bm = BoltzmannMachine(n_neurons=n_neurons, learning_rate=lr, temperature=temp)
        self.text_output.append("\n[步骤1] 初始化Boltzmann机成功！")
        self.text_output.append(f"参数：神经元数={n_neurons}, 学习率={lr}, 温度={temp}")

        # 重置图形显示
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.text(0.5, 0.5, "添加训练数据后点击「开始训练」", ha='center', va='center', fontsize=12)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')
        self.canvas.draw()

    @Slot()
    def add_train_data(self):
        """添加当前网格中的训练数据"""
        if self.bm is None:
            self.text_output.append("\n[错误] 请先初始化Boltzmann机！")
            QMessageBox.warning(self, "警告", "请先点击「初始化Boltzmann机」按钮！").exec()
            return

        n_neurons = self.neuron_spin.value()
        # 提取网格中的所有样本（每行一个样本）
        samples = []
        # 按行分组按钮
        rows = {}
        for r, c, btn in self.data_buttons:
            if r not in rows:
                rows[r] = []
            rows[r].append((c, btn))

        # 遍历每行，提取样本
        for r in sorted(rows.keys()):
            sample = np.zeros(n_neurons)
            for c, btn in sorted(rows[r], key=lambda x: x[0]):
                sample[c] = int(btn.text())
            samples.append(sample)

        # 去重并添加到训练数据
        new_samples = []
        for sample in samples:
            if not any(np.array_equal(sample, s) for s in self.train_data):
                self.train_data.append(sample)
                new_samples.append(sample)

        if new_samples:
            self.text_output.append(f"\n[步骤2] 添加训练数据成功！新增样本数：{len(new_samples)}，总样本数：{len(self.train_data)}")
            self.text_output.append(f"训练数据：{[s.astype(int) for s in self.train_data]}")
        else:
            self.text_output.append("\n[提示] 没有新增训练数据（已存在或为空）")

        # 绘制训练数据
        self.plot_train_data()

    def plot_train_data(self):
        """绘制训练数据"""
        if not self.train_data:
            return

        self.figure.clear()
        n_samples = len(self.train_data)
        n_neurons = self.bm.n

        # 绘制每个样本的神经元状态
        ax = self.figure.add_subplot(111)
        ax.set_title(f"训练数据（共{len(self.train_data)}个样本）")
        ax.set_xlabel("神经元编号")
        ax.set_ylabel("样本编号")
        ax.set_xticks(range(n_neurons))
        ax.set_xticklabels([f"神经元{j + 1}" for j in range(n_neurons)])
        ax.set_yticks(range(n_samples))
        ax.set_yticklabels([f"样本{i + 1}" for i in range(n_samples)])

        # 绘制热力图
        data_matrix = np.array(self.train_data)
        im = ax.imshow(data_matrix, cmap='binary', aspect='auto')

        # 添加数值标注
        for i in range(n_samples):
            for j in range(n_neurons):
                text = ax.text(j, i, int(data_matrix[i, j]), ha="center", va="center", color="red")

        self.canvas.draw()

    @Slot()
    def start_train(self):
        """开始训练（使用线程避免UI卡死）"""
        if self.bm is None:
            self.text_output.append("\n[错误] 请先初始化Boltzmann机！")
            QMessageBox.warning(self, "警告", "请先点击「初始化Boltzmann机」按钮！").exec()
            return
        if not self.train_data:
            self.text_output.append("\n[错误] 请先添加训练数据！")
            QMessageBox.warning(self, "警告", "请先点击「添加训练数据」按钮！").exec()
            return

        n_epochs = self.epoch_spin.value()
        n_samples = self.sample_spin.value()

        self.text_output.append(f"\n[步骤3] 开始训练！训练轮数：{n_epochs}，CD-k采样步数：{n_samples}")
        self.train_btn.setEnabled(False)
        self.add_data_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, n_epochs)

        # 创建并启动训练线程
        self.train_thread = TrainThread(self.bm, self.train_data, n_epochs, n_samples)
        self.train_thread.progress.connect(self.on_train_progress)
        self.train_thread.finished.connect(self.on_train_finished)
        self.train_thread.start()

    @Slot(int, float)
    def on_train_progress(self, epoch, error):
        """训练进度更新"""
        self.text_output.append(f"训练轮数：{epoch}/{self.epoch_spin.value()}，能量误差：{error:.4f}")
        self.progress_bar.setValue(epoch)

    @Slot()
    def on_train_finished(self):
        """训练完成"""
        self.text_output.append("\n[成功] 训练完成！")
        self.train_btn.setEnabled(True)
        self.add_data_btn.setEnabled(True)
        self.progress_bar.setVisible(False)

        # 绘制训练后的权重矩阵
        self.plot_weights()

    def plot_weights(self):
        """绘制权重矩阵"""
        if self.bm is None:
            return

        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.set_title("Boltzmann机权重矩阵")
        ax.set_xlabel("神经元编号")
        ax.set_ylabel("神经元编号")
        ax.set_xticks(range(self.bm.n))
        ax.set_xticklabels([f"神经元{j + 1}" for j in range(self.bm.n)])
        ax.set_yticks(range(self.bm.n))
        ax.set_yticklabels([f"神经元{j + 1}" for j in range(self.bm.n)])

        # 绘制权重热力图
        im = ax.imshow(self.bm.weights, cmap='coolwarm', aspect='auto')
        plt.colorbar(im, ax=ax, label='权重值')

        # 添加数值标注
        for i in range(self.bm.n):
            for j in range(self.bm.n):
                text = ax.text(j, i, f"{self.bm.weights[i, j]:.3f}", ha="center", va="center",
                               color="white" if abs(self.bm.weights[i, j]) > 0.5 else "black")

        self.canvas.draw()

    @Slot()
    def generate_samples(self):
        """生成样本"""
        if self.bm is None:
            self.text_output.append("\n[错误] 请先初始化并训练Boltzmann机！")
            QMessageBox.warning(self, "警告", "请先初始化并训练模型！").exec()
            return

        n_samples = 5  # 生成5个样本
        self.text_output.append(f"\n[步骤4] 生成样本（共{5}个）...")

        samples = self.bm.generate_samples(n_samples=n_samples)
        self.text_output.append(f"生成的样本：{[s.astype(int) for s in samples]}")

        # 绘制生成的样本
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.set_title(f"生成的样本（共{len(samples)}个）")
        ax.set_xlabel("神经元编号")
        ax.set_ylabel("样本编号")
        ax.set_xticks(range(self.bm.n))
        ax.set_xticklabels([f"神经元{j + 1}" for j in range(self.bm.n)])
        ax.set_yticks(range(len(samples)))
        ax.set_yticklabels([f"样本{i + 1}" for i in range(len(samples))])

        # 绘制热力图
        data_matrix = np.array(samples)
        im = ax.imshow(data_matrix, cmap='binary', aspect='auto')

        # 添加数值标注
        for i in range(len(samples)):
            for j in range(self.bm.n):
                text = ax.text(j, i, int(data_matrix[i, j]), ha="center", va="center", color="red")

        self.canvas.draw()

    @Slot()
    def save_figure(self):
        """保存当前结果图"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先训练模型或生成样本！").exec()
            return

        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存Boltzmann机结果图",
            os.path.join(os.getcwd(), "boltzmann_result.png"),
            "图片文件 (*.png *.jpg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        try:
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}").exec()
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}").exec()