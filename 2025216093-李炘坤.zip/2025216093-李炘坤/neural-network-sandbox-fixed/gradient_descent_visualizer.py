import sys
import numpy as np
import time
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QLineEdit, 
                             QGroupBox, QTextEdit, QTabWidget, QSplitter, QProgressBar,
                             QComboBox, QCheckBox)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QFont, QPalette, QColor
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

class GradientDescentAlgorithms:
    """梯度下降算法集合"""
    
    @staticmethod
    def map_problem_name(chinese_name):
        """将中文问题名称映射为英文名称"""
        mapping = {
            "二次函数": "quadratic",
            "Rosenbrock函数": "rosenbrock", 
            "球函数": "sphere"
        }
        return mapping.get(chinese_name, chinese_name)
    
    @staticmethod
    def make_problem(name):
        """创建目标函数"""
        # 首先映射中文名称到英文名称
        name = GradientDescentAlgorithms.map_problem_name(name)
        name = name.lower()
        
        if name == "quadratic":
            # 二次函数: f(x) = 0.5 * x^T A x + d^T x
            A = np.array([[2.0, 1.0], [1.0, 2.0]])
            d = np.array([0.0, 0.0])
            def f(x): return 0.5 * x @ A @ x + d @ x
            def g(x): return A @ x + d
            def H(x): return A
            box = np.array([[-3.0, 3.0], [-3.0, 3.0]])
            return f, g, H, box, True
        elif name == "rosenbrock":
            # Rosenbrock函数: f(x,y) = (1-x)^2 + 100(y-x^2)^2
            def f(x): return (1 - x[0])**2 + 100.0 * (x[1] - x[0]**2)**2
            def g(x):
                return np.array([
                    -2.0*(1 - x[0]) - 400.0*x[0]*(x[1] - x[0]**2),
                    200.0*(x[1] - x[0]**2)
                ])
            def H(x):
                return np.array([
                    [2.0 - 400.0*(x[1] - 3.0*x[0]**2), -400.0*x[0]],
                    [-400.0*x[0], 200.0]
                ])
            box = np.array([[-2.0, 2.0], [-1.0, 3.0]])
            return f, g, H, box, False
        elif name == "sphere":
            # 球函数: f(x) = x1^2 + x2^2
            def f(x): return x[0]**2 + x[1]**2
            def g(x): return np.array([2*x[0], 2*x[1]])
            def H(x): return np.array([[2, 0], [0, 2]])
            box = np.array([-2, 2, -2, 2]).reshape(2, 2)
            return f, g, H, box, True
        else:
            raise ValueError("未知问题名称")
    
    @staticmethod
    def backtracking_armijo(f, grad, x, p, alpha0, rho, c, max_bt):
        """Armijo线搜索"""
        alpha = alpha0
        fx = f(x); gx = grad(x)
        for _ in range(int(max_bt)):
            if f(x + alpha*p) <= fx + c * alpha * (gx @ p):
                return alpha
            alpha *= rho
        return max(alpha, 1e-12)
    
    @staticmethod
    def steepest_descent(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, use_exact_for_quad):
        """最速下降法"""
        x = x0.copy(); gx = g(x)
        traj = [x.copy()]
        is_quad = use_exact_for_quad
        steps = 0
        for k in range(int(itmax)):
            if np.linalg.norm(gx) < tol: break
            p = -gx
            if is_quad:
                A = H(x); alpha = (gx @ gx) / (p @ A @ p)
            else:
                alpha = GradientDescentAlgorithms.backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
            x = x + alpha * p
            gx = g(x)
            traj.append(x.copy()); steps += 1
        return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))
    
    @staticmethod
    def newton_method(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt):
        """牛顿法"""
        x = x0.copy(); gx = g(x)
        traj = [x.copy()]; steps = 0
        for k in range(int(itmax)):
            if np.linalg.norm(gx) < tol: break
            Hx = H(x)
            # 简单阻尼以保障下降
            try:
                p = -np.linalg.solve(Hx, gx)
            except np.linalg.LinAlgError:
                Hx = Hx + 1e-6*np.eye(2)
                p = -np.linalg.solve(Hx, gx)
            if gx @ p >= 0:
                mu = 1e-6; I = np.eye(2)
                for _ in range(10):
                    p = -np.linalg.solve(Hx + mu*I, gx)
                    if gx @ p < 0: break
                    mu *= 10
            alpha = GradientDescentAlgorithms.backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
            x = x + alpha * p
            gx = g(x)
            traj.append(x.copy()); steps += 1
        return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))
    
    @staticmethod
    def conjugate_gradient(f, g, H, x0, itmax, tol, alpha0, rho, c, maxbt, use_exact_for_quad):
        """共轭梯度法 (FR方法)"""
        x = x0.copy(); gx = g(x); p = -gx
        traj = [x.copy()]; steps = 0
        is_quad = use_exact_for_quad
        for k in range(int(itmax)):
            if np.linalg.norm(gx) < tol: break
            if is_quad:
                A = H(x); alpha = (gx @ gx) / (p @ A @ p)
            else:
                alpha = GradientDescentAlgorithms.backtracking_armijo(f, g, x, p, alpha0, rho, c, maxbt)
            x_new = x + alpha * p
            gx_new = g(x_new)
            traj.append(x_new.copy()); steps += 1
            if np.linalg.norm(gx_new) < tol:
                x, gx = x_new, gx_new; break
            beta = (gx_new @ gx_new) / (gx @ gx + 1e-16)
            p = -gx_new + beta * p
            if gx_new @ p >= 0:  # 重启
                p = -gx_new
            x, gx = x_new, gx_new
        return np.stack(traj, 1), steps, float(np.linalg.norm(gx)), float(f(x))

class MplCanvas(FigureCanvas):
    """Matplotlib画布封装"""
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(MplCanvas, self).__init__(self.fig)
        self.setParent(parent)

class GradientDescentVisualizer(QMainWindow):
    """梯度下降算法PyQt可视化器"""
    
    def __init__(self):
        super().__init__()
        self.trajectories = {}  # 存储不同算法的轨迹
        self.current_trajectory = None
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate_step)
        self.animation_step = 0
        self.animation_speed = 50  # 毫秒
        
        self.init_ui()
        
    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle("梯度下降算法可视化 - 最速下降/牛顿法/共轭梯度")
        self.setGeometry(100, 100, 1400, 900)
        
        # 设置深色主题
        self.set_dark_theme()
        
        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 主布局
        main_layout = QHBoxLayout(central_widget)
        
        # 左侧控制面板
        control_panel = self.create_control_panel()
        main_layout.addWidget(control_panel)
        
        # 右侧可视化区域
        visualization_area = self.create_visualization_area()
        main_layout.addWidget(visualization_area)
        
        main_layout.setStretchFactor(control_panel, 1)
        main_layout.setStretchFactor(visualization_area, 3)
    
    def set_dark_theme(self):
        """设置深色主题"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.WindowText, Qt.white)
        palette.setColor(QPalette.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ToolTipBase, Qt.white)
        palette.setColor(QPalette.ToolTipText, Qt.white)
        palette.setColor(QPalette.Text, Qt.white)
        palette.setColor(QPalette.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ButtonText, Qt.white)
        palette.setColor(QPalette.BrightText, Qt.red)
        palette.setColor(QPalette.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.HighlightedText, Qt.black)
        self.setPalette(palette)
        
    def create_control_panel(self):
        """创建控制面板"""
        control_group = QGroupBox("控制面板")
        control_layout = QVBoxLayout(control_group)
        
        # 标题
        title_label = QLabel("梯度下降算法控制台")
        title_label.setFont(QFont("Arial", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        control_layout.addWidget(title_label)
        
        # 问题选择
        problem_group = QGroupBox("优化问题")
        problem_layout = QVBoxLayout(problem_group)
        
        problem_label = QLabel("选择优化问题:")
        self.problem_combo = QComboBox()
        self.problem_combo.addItems(["二次函数", "Rosenbrock函数", "球函数"])
        problem_layout.addWidget(problem_label)
        problem_layout.addWidget(self.problem_combo)
        
        control_layout.addWidget(problem_group)
        
        # 算法选择
        algorithm_group = QGroupBox("算法选择")
        algorithm_layout = QVBoxLayout(algorithm_group)
        
        algorithm_label = QLabel("选择算法:")
        self.algorithm_combo = QComboBox()
        self.algorithm_combo.addItems(["最速下降法", "牛顿法", "共轭梯度法"])
        algorithm_layout.addWidget(algorithm_label)
        algorithm_layout.addWidget(self.algorithm_combo)
        
        control_layout.addWidget(algorithm_group)
        
        # 参数设置
        params_group = QGroupBox("参数设置")
        params_layout = QVBoxLayout(params_group)
        
        # 起始点
        start_layout = QHBoxLayout()
        start_label = QLabel("起始点 (x,y):")
        self.start_x_input = QLineEdit("2.0")
        self.start_y_input = QLineEdit("2.0")
        start_layout.addWidget(start_label)
        start_layout.addWidget(self.start_x_input)
        start_layout.addWidget(self.start_y_input)
        params_layout.addLayout(start_layout)
        
        # 最大迭代次数
        iter_layout = QHBoxLayout()
        iter_label = QLabel("最大迭代次数:")
        self.iter_input = QLineEdit("100")
        iter_layout.addWidget(iter_label)
        iter_layout.addWidget(self.iter_input)
        params_layout.addLayout(iter_layout)
        
        # 线搜索参数
        ls_layout = QHBoxLayout()
        ls_label = QLabel("初始步长:")
        self.alpha_input = QLineEdit("1.0")
        ls_layout.addWidget(ls_label)
        ls_layout.addWidget(self.alpha_input)
        params_layout.addLayout(ls_layout)
        
        # Armijo参数
        armijo_layout = QHBoxLayout()
        armijo_label = QLabel("Armijo参数:")
        self.rho_input = QLineEdit("0.5")
        self.c_input = QLineEdit("0.1")
        armijo_layout.addWidget(armijo_label)
        armijo_layout.addWidget(self.rho_input)
        armijo_layout.addWidget(self.c_input)
        params_layout.addLayout(armijo_layout)
        
        # 最大回溯次数
        bt_layout = QHBoxLayout()
        bt_label = QLabel("最大回溯次数:")
        self.bt_input = QLineEdit("20")
        bt_layout.addWidget(bt_label)
        bt_layout.addWidget(self.bt_input)
        params_layout.addLayout(bt_layout)
        
        # 精确步长选项
        self.exact_step_check = QCheckBox("对二次问题使用精确步长")
        self.exact_step_check.setChecked(True)
        params_layout.addWidget(self.exact_step_check)
        
        control_layout.addWidget(params_group)
        
        # 控制按钮
        buttons_group = QGroupBox("算法控制")
        buttons_layout = QVBoxLayout(buttons_group)
        
        self.run_button = QPushButton("运行算法")
        self.run_button.clicked.connect(self.run_algorithm)
        buttons_layout.addWidget(self.run_button)
        
        self.animate_button = QPushButton("开始动画")
        self.animate_button.clicked.connect(self.start_animation)
        self.animate_button.setEnabled(False)
        buttons_layout.addWidget(self.animate_button)
        
        self.pause_button = QPushButton("暂停动画")
        self.pause_button.clicked.connect(self.pause_animation)
        self.pause_button.setEnabled(False)
        buttons_layout.addWidget(self.pause_button)
        
        self.reset_button = QPushButton("重置视图")
        self.reset_button.clicked.connect(self.reset_view)
        buttons_layout.addWidget(self.reset_button)
        
        control_layout.addWidget(buttons_group)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        control_layout.addWidget(self.progress_bar)
        
        # 算法信息
        info_group = QGroupBox("算法信息")
        info_layout = QVBoxLayout(info_group)
        
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(200)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        control_layout.addWidget(info_group)
        
        control_layout.addStretch(1)
        
        return control_group
    
    def create_visualization_area(self):
        """创建可视化区域"""
        visualization_widget = QTabWidget()
        
        # 等高线图标签页
        contour_tab = QWidget()
        contour_layout = QVBoxLayout(contour_tab)
        self.contour_canvas = MplCanvas(self, width=8, height=6)
        contour_layout.addWidget(self.contour_canvas)
        visualization_widget.addTab(contour_tab, "Contour plot")
        
        # 收敛曲线标签页
        convergence_tab = QWidget()
        convergence_layout = QVBoxLayout(convergence_tab)
        self.convergence_canvas = MplCanvas(self, width=8, height=6)
        convergence_layout.addWidget(self.convergence_canvas)
        visualization_widget.addTab(convergence_tab, "Convergence curve")
        
        # 比较分析标签页
        comparison_tab = QWidget()
        comparison_layout = QVBoxLayout(comparison_tab)
        self.comparison_canvas = MplCanvas(self, width=8, height=6)
        comparison_layout.addWidget(self.comparison_canvas)
        visualization_widget.addTab(comparison_tab, "Comparison analysis")
        
        return visualization_widget
    
    def run_algorithm(self):
        """运行选定的算法"""
        try:
            # 获取参数
            problem_name = self.problem_combo.currentText()
            algorithm_name = self.algorithm_combo.currentText()
            x0 = np.array([float(self.start_x_input.text()), float(self.start_y_input.text())])
            itmax = int(self.iter_input.text())
            alpha0 = float(self.alpha_input.text())
            rho = float(self.rho_input.text())
            c = float(self.c_input.text())
            maxbt = int(self.bt_input.text())
            exact_step = self.exact_step_check.isChecked()
            
            # 创建问题（使用映射后的名称）
            mapped_problem_name = GradientDescentAlgorithms.map_problem_name(problem_name)
            f, g, H, box, is_quad = GradientDescentAlgorithms.make_problem(mapped_problem_name)
            
            # 运行算法
            if algorithm_name == "最速下降法":
                traj, steps, gnorm, fval = GradientDescentAlgorithms.steepest_descent(
                    f, g, H, x0, itmax, 1e-6, alpha0, rho, c, maxbt, exact_step and is_quad)
                color = 'C0'
                marker = 'o'
            elif algorithm_name == "牛顿法":
                traj, steps, gnorm, fval = GradientDescentAlgorithms.newton_method(
                    f, g, H, x0, itmax, 1e-6, alpha0, rho, c, maxbt)
                color = 'C1'
                marker = 's'
            else:  # 共轭梯度法
                traj, steps, gnorm, fval = GradientDescentAlgorithms.conjugate_gradient(
                    f, g, H, x0, itmax, 1e-6, alpha0, rho, c, maxbt, exact_step and is_quad)
                color = 'C2'
                marker = '^'
            
            # 存储轨迹
            self.trajectories[algorithm_name] = {
                'trajectory': traj,
                'color': color,
                'marker': marker,
                'steps': steps,
                'final_grad_norm': gnorm,
                'final_func_value': fval
            }
            
            # 更新可视化
            self.update_visualizations()
            
            # 显示结果信息
            self.info_text.append(f"{algorithm_name} 完成:")
            self.info_text.append(f"  iteration steps: {steps}")
            self.info_text.append(f"  final gradient norm: {gnorm:.6e}")
            self.info_text.append(f"  final function value: {fval:.6e}")
            self.info_text.append("")
            
            # 启用动画按钮
            self.animate_button.setEnabled(True)
            self.current_trajectory = algorithm_name
            self.animation_step = 0
            
        except Exception as e:
            self.info_text.append(f"错误: {str(e)}")
    
    def start_animation(self):
        """开始动画"""
        if self.current_trajectory and self.current_trajectory in self.trajectories:
            self.timer.start(self.animation_speed)
            self.animate_button.setEnabled(False)
            self.pause_button.setEnabled(True)
    
    def pause_animation(self):
        """暂停动画"""
        self.timer.stop()
        self.animate_button.setEnabled(True)
        self.pause_button.setEnabled(False)
    
    def animate_step(self):
        """动画步骤"""
        if self.current_trajectory in self.trajectories:
            traj = self.trajectories[self.current_trajectory]['trajectory']
            if self.animation_step < traj.shape[1]:
                self.animation_step += 1
                self.progress_bar.setValue(int(self.animation_step / traj.shape[1] * 100))
                self.plot_contour_with_animation()
            else:
                self.pause_animation()
    
    def reset_view(self):
        """重置视图"""
        self.trajectories = {}
        self.current_trajectory = None
        self.animation_step = 0
        self.progress_bar.setValue(0)
        self.info_text.clear()
        self.animate_button.setEnabled(False)
        self.pause_button.setEnabled(False)
        self.update_visualizations()
    
    def update_visualizations(self):
        """更新所有可视化图表"""
        self.plot_contour()
        self.plot_convergence()
        self.plot_comparison()
    
    def plot_contour(self):
        """绘制等高线图"""
        self.contour_canvas.fig.clear()
        ax = self.contour_canvas.fig.add_subplot(111)
        
        # 获取当前问题（使用映射后的名称）
        problem_name = self.problem_combo.currentText()
        mapped_problem_name = GradientDescentAlgorithms.map_problem_name(problem_name)
        f, g, H, box, is_quad = GradientDescentAlgorithms.make_problem(mapped_problem_name)
        
        # 创建网格
        x_min, x_max = box[0]
        y_min, y_max = box[1]
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50),
                            np.linspace(y_min, y_max, 50))
        
        # 计算函数值
        Z = np.zeros_like(xx)
        for i in range(xx.shape[0]):
            for j in range(xx.shape[1]):
                Z[i, j] = f(np.array([xx[i, j], yy[i, j]]))
        
        # 绘制等高线
        levels = np.logspace(-3, 3, 20)
        contour = ax.contour(xx, yy, Z, levels=levels, alpha=0.6, linewidths=0.5)
        ax.clabel(contour, inline=True, fontsize=8)
        
        # 绘制轨迹
        for algo_name, data in self.trajectories.items():
            traj = data['trajectory']
            color = data['color']
            marker = data['marker']
            
            # 绘制完整轨迹
            ax.plot(traj[0, :], traj[1, :], color=color, linewidth=2, alpha=0.7, label=algo_name)
            # 绘制起点和终点
            ax.scatter(traj[0, 0], traj[1, 0], color=color, marker='*', s=100, edgecolors='black')
            ax.scatter(traj[0, -1], traj[1, -1], color=color, marker=marker, s=80, edgecolors='black')
        
        ax.set_title(f'{problem_name} - Optimization trajectory', fontsize=12, color='white')
        ax.set_xlabel('x', color='white')
        ax.set_ylabel('y', color='white')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_facecolor('#2b2b2b')
        self.contour_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        
        self.contour_canvas.draw()
    
    def plot_contour_with_animation(self):
        """绘制带动画的等高线图"""
        self.contour_canvas.fig.clear()
        ax = self.contour_canvas.fig.add_subplot(111)
        
        # 获取当前问题（使用映射后的名称）
        problem_name = self.problem_combo.currentText()
        mapped_problem_name = GradientDescentAlgorithms.map_problem_name(problem_name)
        f, g, H, box, is_quad = GradientDescentAlgorithms.make_problem(mapped_problem_name)
        
        # 创建网格
        x_min, x_max = box[0]
        y_min, y_max = box[1]
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, 50),
                            np.linspace(y_min, y_max, 50))
        
        # 计算函数值
        Z = np.zeros_like(xx)
        for i in range(xx.shape[0]):
            for j in range(xx.shape[1]):
                Z[i, j] = f(np.array([xx[i, j], yy[i, j]]))
        
        # 绘制等高线
        levels = np.logspace(-3, 3, 20)
        contour = ax.contour(xx, yy, Z, levels=levels, alpha=0.6, linewidths=0.5)
        ax.clabel(contour, inline=True, fontsize=8)
        
        # 绘制动画轨迹
        if self.current_trajectory in self.trajectories:
            data = self.trajectories[self.current_trajectory]
            traj = data['trajectory']
            color = data['color']
            marker = data['marker']
            
            # 绘制已走过的轨迹
            if self.animation_step > 0:
                ax.plot(traj[0, :self.animation_step], traj[1, :self.animation_step], 
                       color=color, linewidth=2, alpha=0.7, label=self.current_trajectory)
                # 绘制当前点
                ax.scatter(traj[0, self.animation_step-1], traj[1, self.animation_step-1], 
                          color=color, marker=marker, s=100, edgecolors='black')
            
            # 绘制起点
            ax.scatter(traj[0, 0], traj[1, 0], color=color, marker='*', s=100, edgecolors='black')
        
        ax.set_title(f'{problem_name} - Optimization trajectory (step: {self.animation_step})', fontsize=12, color='white')
        ax.set_xlabel('x', color='white')
        ax.set_ylabel('y', color='white')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_facecolor('#2b2b2b')
        self.contour_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        
        self.contour_canvas.draw()

    def plot_convergence(self):
        """绘制收敛曲线"""
        self.convergence_canvas.fig.clear()
        ax = self.convergence_canvas.fig.add_subplot(111)
        
        # 获取当前问题（使用映射后的名称）
        problem_name = self.problem_combo.currentText()
        mapped_problem_name = GradientDescentAlgorithms.map_problem_name(problem_name)
        f, g, H, box, is_quad = GradientDescentAlgorithms.make_problem(mapped_problem_name)
        
        for algo_name, data in self.trajectories.items():
            traj = data['trajectory']
            color = data['color']
            
            # 计算每一步的函数值
            func_values = []
            for i in range(traj.shape[1]):
                func_values.append(f(traj[:, i]))
            
            # 绘制收敛曲线
            ax.semilogy(range(len(func_values)), func_values, color=color, 
                       linewidth=2, label=algo_name, marker='o', markersize=3)
        
        ax.set_title(f'{problem_name} - Convergence curve', fontsize=12, color='white')
        ax.set_xlabel('iteration steps', color='white')
        ax.set_ylabel('function value (log scale)', color='white')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_facecolor('#2b2b2b')
        self.convergence_canvas.fig.patch.set_facecolor('#2b2b2b')
        ax.tick_params(colors='white')
        
        self.convergence_canvas.draw()

    def plot_comparison(self):
        """绘制算法比较图"""
        self.comparison_canvas.fig.clear()
        
        if len(self.trajectories) < 2:
            ax = self.comparison_canvas.fig.add_subplot(111)
            ax.text(0.5, 0.5, '需要至少两种算法进行比较', 
                   horizontalalignment='center', verticalalignment='center',
                   transform=ax.transAxes, fontsize=14, color='white')
            ax.set_facecolor('#2b2b2b')
            self.comparison_canvas.fig.patch.set_facecolor('#2b2b2b')
        else:
            # 创建2x2的子图布局
            gs = gridspec.GridSpec(2, 2)
            
            # 获取当前问题（使用映射后的名称）
            problem_name = self.problem_combo.currentText()
            mapped_problem_name = GradientDescentAlgorithms.map_problem_name(problem_name)
            f, g, H, box, is_quad = GradientDescentAlgorithms.make_problem(mapped_problem_name)
            
            # 子图1: 收敛速度比较
            ax1 = self.comparison_canvas.fig.add_subplot(gs[0, 0])
            for algo_name, data in self.trajectories.items():
                traj = data['trajectory']
                color = data['color']
                
                func_values = []
                for i in range(traj.shape[1]):
                    func_values.append(f(traj[:, i]))
                
                ax1.semilogy(range(len(func_values)), func_values, color=color, 
                           linewidth=2, label=algo_name)
            
            ax1.set_title('Convergence rate comparison', fontsize=10, color='white')
            ax1.set_xlabel('iteration steps', color='white')
            ax1.set_ylabel('function value', color='white')
            ax1.legend(fontsize=8)
            ax1.grid(True, alpha=0.3)
            ax1.set_facecolor('#2b2b2b')
            
            # 子图2: 最终性能比较
            ax2 = self.comparison_canvas.fig.add_subplot(gs[0, 1])
            algorithms = list(self.trajectories.keys())
            final_values = [data['final_func_value'] for data in self.trajectories.values()]
            
            bars = ax2.bar(algorithms, final_values, color=['C0', 'C1', 'C2'][:len(algorithms)])
            ax2.set_title('final function value comparison', fontsize=10, color='white')
            ax2.set_ylabel('final function value', color='white')
            ax2.tick_params(axis='x', rotation=45, colors='white')
            ax2.tick_params(axis='y', colors='white')
            ax2.set_facecolor('#2b2b2b')
            
            # 在柱状图上添加数值
            for bar, value in zip(bars, final_values):
                ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                        f'{value:.2e}', ha='center', va='bottom', fontsize=8, color='white')
            
            # 子图3: 迭代步数比较
            ax3 = self.comparison_canvas.fig.add_subplot(gs[1, 0])
            steps = [data['steps'] for data in self.trajectories.values()]
            
            bars = ax3.bar(algorithms, steps, color=['C0', 'C1', 'C2'][:len(algorithms)])
            ax3.set_title('iteration step comparison', fontsize=10, color='white')
            ax3.set_ylabel('iteration steps', color='white')
            ax3.tick_params(axis='x', rotation=45, colors='white')
            ax3.tick_params(axis='y', colors='white')
            ax3.set_facecolor('#2b2b2b')
            
            # 在柱状图上添加数值
            for bar, value in zip(bars, steps):
                ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                        str(value), ha='center', va='bottom', fontsize=8, color='white')
            
            # 子图4: 最终梯度范数比较
            ax4 = self.comparison_canvas.fig.add_subplot(gs[1, 1])
            grad_norms = [data['final_grad_norm'] for data in self.trajectories.values()]
            
            bars = ax4.bar(algorithms, grad_norms, color=['C0', 'C1', 'C2'][:len(algorithms)])
            ax4.set_title('最终梯度范数比较', fontsize=10, color='white')
            ax4.set_ylabel('梯度范数', color='white')
            ax4.tick_params(axis='x', rotation=45, colors='white')
            ax4.tick_params(axis='y', colors='white')
            ax4.set_facecolor('#2b2b2b')
            
            # 在柱状图上添加数值
            for bar, value in zip(bars, grad_norms):
                ax4.text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                        f'{value:.2e}', ha='center', va='bottom', fontsize=8, color='white')
            
            self.comparison_canvas.fig.patch.set_facecolor('#2b2b2b')
            self.comparison_canvas.fig.tight_layout()
        
        self.comparison_canvas.draw()

def main():
    """主函数"""
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = GradientDescentVisualizer()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()