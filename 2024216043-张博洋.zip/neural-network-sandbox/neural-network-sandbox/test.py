from nn_sandbox.bridges.bm_bridge import BmBridge

bridge = BmBridge()
print(bridge)