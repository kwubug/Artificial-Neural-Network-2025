import collections
import math
import random
import threading
import time
from typing import List, Optional, Sequence, Tuple

import numpy as np


class BaseSimulationThread(threading.Thread):
    """Thread base class that adds cooperative stop handling."""

    def __init__(self, refresh_interval: float):
        super().__init__(daemon=True)
        self._should_stop = False
        self.refresh_interval = refresh_interval

    def stop(self) -> None:
        self._should_stop = True


class OLSAlgorithm(BaseSimulationThread):
    """Gradient-descent OLS learner used for interactive visualization."""

    def __init__(
        self,
        dataset: Sequence[Sequence[float]],
        learning_rate: float,
        max_iterations: int,
        use_lr_decay: bool,
        lr_decay: float,
        use_momentum: bool,
        momentum: float,
        enable_early_stop: bool,
        early_stop_delta: float,
        early_stop_patience: int,
        initial_a: float,
        initial_b: float,
        initial_c: float,
        refresh_interval: float,
    ) -> None:
        super().__init__(refresh_interval)
        self.dataset = np.array(dataset, dtype=float)
        self.learning_rate = float(learning_rate)
        self.max_iterations = int(max_iterations)
        self.use_lr_decay = bool(use_lr_decay)
        self.lr_decay = max(0.0, float(lr_decay))
        self.use_momentum = bool(use_momentum)
        self.momentum = max(0.0, min(0.99, float(momentum)))
        self.enable_early_stop = bool(enable_early_stop)
        self.early_stop_delta = max(0.0, float(early_stop_delta))
        self.early_stop_patience = max(1, int(early_stop_patience))
        self.a = float(initial_a)
        self.b = float(initial_b)
        self.c = float(initial_c)
        self.current_iteration = 0
        self.line_points: List[Tuple[float, float]] = []
        self.loss = 0.0
        self.loss_history: List[Tuple[int, float]] = []
        self.param_history: List[Tuple[int, float, float, float]] = []
        self.running = False
        self._x_range = self._compute_x_range()
        # momentum velocity terms
        self._va = 0.0
        self._vb = 0.0
        self._vc = 0.0

    def _compute_x_range(self) -> Tuple[float, float]:
        if self.dataset.size == 0:
            return (0.0, 1.0)
        x_min = float(self.dataset[:, 0].min())
        x_max = float(self.dataset[:, 0].max())
        if math.isclose(x_min, x_max):
            x_max = x_min + 1.0
        return (x_min, x_max)

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        if self.dataset.size == 0:
            self.running = False
            return
        self.running = True
        x = self.dataset[:, 0]
        y = self.dataset[:, 1]
        sample_count = len(x)
        x_min, x_max = self._x_range
        best_loss = float('inf')
        stagnant = 0
        for iteration in range(1, self.max_iterations + 1):
            if self._should_stop:
                break
            predictions = self.a * x**2 + self.b * x + self.c
            errors = predictions - y
            self.loss = float(np.mean(errors ** 2))
            gradient_a = float((2.0 / sample_count) * np.dot(errors, x**2))
            gradient_b = float((2.0 / sample_count) * np.dot(errors, x))
            gradient_c = float((2.0 / sample_count) * errors.sum())
            # effective learning rate with simple decay schedule
            if self.use_lr_decay:
                eff_lr = self.learning_rate / (1.0 + self.lr_decay * iteration)
            else:
                eff_lr = self.learning_rate
            if self.use_momentum:
                self._va = self.momentum * self._va - eff_lr * gradient_a
                self._vb = self.momentum * self._vb - eff_lr * gradient_b
                self._vc = self.momentum * self._vc - eff_lr * gradient_c
                self.a += self._va
                self.b += self._vb
                self.c += self._vc
            else:
                self.a -= eff_lr * gradient_a
                self.b -= eff_lr * gradient_b
                self.c -= eff_lr * gradient_c
            self.current_iteration = iteration
            self.loss_history = self.loss_history + [(iteration, self.loss)]
            self.param_history = self.param_history + [(iteration, self.a, self.b, self.c)]
            # sample 50 points for smooth curve
            x_curve = np.linspace(x_min, x_max, 50)
            self.line_points = [(float(xi), float(self.a * xi**2 + self.b * xi + self.c)) for xi in x_curve]
            # early stopping logic
            if self.enable_early_stop:
                if self.loss + 1e-12 < best_loss - self.early_stop_delta:
                    best_loss = self.loss
                    stagnant = 0
                else:
                    stagnant += 1
                if stagnant >= self.early_stop_patience:
                    break
            time.sleep(self.refresh_interval)
        self.running = False


class HopfieldAsyncAlgorithm(BaseSimulationThread):
    """Discrete Hopfield network with asynchronous updates and energy tracking."""

    def __init__(
        self,
        patterns: Sequence[Sequence[int]],
        max_iterations: int,
        refresh_interval: float,
    ) -> None:
        super().__init__(refresh_interval)
        self.patterns = np.array(patterns, dtype=int)
        if self.patterns.ndim != 2:
            raise ValueError("patterns must be a 2D sequence")
        self.max_iterations = int(max_iterations)
        self.neuron_count = int(self.patterns.shape[1])
        self.weights = self._build_weights()
        self._state = self._random_state()
        self.state: List[int] = self._state.tolist()
        self.energy = self._energy(self._state)
        self.energy_history: List[Tuple[int, float]] = []
        self.current_iteration = 0
        self.updated_index = -1
        self.attractor_state: List[int] = []
        self.attractor_energy = float(self.energy)
        self.running = False

    def _build_weights(self) -> np.ndarray:
        # Hebbian rule: sum over outer products, then normalize by neuron count.
        weight = np.zeros((self.neuron_count, self.neuron_count), dtype=float)
        for pattern in self.patterns:
            pattern_vec = pattern.reshape(-1, 1)
            weight += pattern_vec @ pattern_vec.T
        # ensure zero self-connection and symmetric weights (numerical safety)
        np.fill_diagonal(weight, 0.0)
        weight = 0.5 * (weight + weight.T)
        weight /= float(max(1, self.neuron_count))
        return weight

    def _random_state(self) -> np.ndarray:
        raw = np.random.choice([-1, 1], size=self.neuron_count)
        return raw.astype(int)

    def _energy(self, state: np.ndarray) -> float:
        return float(-0.5 * state.T @ self.weights @ state)

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        recent_states: collections.deque = collections.deque(maxlen=max(5, self.neuron_count))
        self._state = self._random_state()
        self.state = self._state.tolist()
        self.energy = self._energy(self._state)
        self.energy_history = []
        self.current_iteration = 0
        for iteration in range(1, self.max_iterations + 1):
            if self._should_stop:
                break
            index = random.randrange(self.neuron_count)
            net_input = float(np.dot(self.weights[index], self._state))
            self._state[index] = 1 if net_input >= 0 else -1
            self.state = self._state.tolist()
            self.energy = self._energy(self._state)
            self.current_iteration = iteration
            self.updated_index = index
            self.energy_history = self.energy_history + [(iteration, self.energy)]
            recent_states.append(tuple(self._state.tolist()))
            attractor = self._detect_attractor()
            if attractor is not None:
                self.attractor_state = attractor.tolist()
                self.attractor_energy = float(self._energy(attractor))
            if len(set(recent_states)) == 1 and len(recent_states) == recent_states.maxlen:
                break
            time.sleep(self.refresh_interval)
        self.running = False

    def _detect_attractor(self) -> Optional[np.ndarray]:
        for pattern in self.patterns:
            if np.array_equal(pattern, self._state):
                return pattern
        return None


class TSPSimulator(BaseSimulationThread):
    """Lightweight 2-opt TSP improvement loop for visualization."""

    def __init__(
        self,
        cities: Sequence[Sequence[float]],
        max_iterations: int,
        refresh_interval: float,
    ) -> None:
        super().__init__(refresh_interval)
        self.cities = np.array(cities, dtype=float)
        if self.cities.ndim != 2 or self.cities.shape[0] < 3:
            raise ValueError("TSP requires at least 3 two-dimensional cities")
        self.max_iterations = int(max_iterations)
        self.city_count = int(self.cities.shape[0])
        self.path = list(range(self.city_count))
        random.shuffle(self.path)
        self.current_iteration = 0
        self.best_length = self._tour_length(self.path)
        self.length_history: List[Tuple[int, float]] = []
        self.running = False

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        stagnation = 0
        for iteration in range(1, self.max_iterations + 1):
            if self._should_stop:
                break
            i, j = sorted(random.sample(range(1, self.city_count), 2))
            new_path = self.path[:i] + list(reversed(self.path[i:j])) + self.path[j:]
            new_length = self._tour_length(new_path)
            if new_length + 1e-6 < self.best_length:
                self.path = new_path
                self.best_length = new_length
                stagnation = 0
            else:
                stagnation += 1
            self.current_iteration = iteration
            self.length_history = self.length_history + [(iteration, self.best_length)]
            if stagnation >= max(30, self.max_iterations // 6):
                break
            time.sleep(self.refresh_interval)
        self.running = False

    def _tour_length(self, path: Sequence[int]) -> float:
        total = 0.0
        for idx in range(len(path)):
            a = self.cities[path[idx]]
            b = self.cities[path[(idx + 1) % len(path)]]
            total += float(np.linalg.norm(a - b))
        return total


class BoltzmannMachineSimulator(BaseSimulationThread):
    """Simple three-neuron Boltzmann Machine with simulated annealing."""

    def __init__(
        self,
        weights: Sequence[Sequence[float]],
        biases: Sequence[float],
        initial_temperature: float,
        cooling_rate: float,
        steps: int,
        refresh_interval: float,
    ) -> None:
        super().__init__(refresh_interval)
        w = np.array(weights, dtype=float)
        if w.shape != (3, 3):
            raise ValueError("Expected a 3x3 weight matrix for the demo BM")
        # ensure symmetry and zero diagonal for a proper Boltzmann demo
        w = 0.5 * (w + w.T)
        np.fill_diagonal(w, 0.0)
        self.weights = w
        self.biases = np.array(biases, dtype=float)
        if self.biases.shape != (3,):
            raise ValueError("Expected three bias values for the demo BM")
        self.temperature = float(initial_temperature)
        self.cooling_rate = float(cooling_rate)
        self.steps = int(steps)
        # start from a randomized initial state (better demo behavior)
        self.state: List[int] = np.random.choice([-1, 1], size=3).astype(int).tolist()
        self.energy = self._energy(np.array(self.state, dtype=float))
        self.energy_history: List[Tuple[int, float]] = []
        self.current_step = 0
        self.equilibrium_state: List[int] = []
        self.running = False

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        state = np.array(self.state, dtype=float)
        temperature = max(self.temperature, 0.01)
        recent_states: collections.deque = collections.deque(maxlen=12)
        for step in range(1, self.steps + 1):
            if self._should_stop:
                break
            for idx in range(3):
                field = float(np.dot(self.weights[idx], state) + self.biases[idx])
                prob = 1.0 / (1.0 + math.exp(-2.0 * field / max(temperature, 0.01)))
                state[idx] = 1.0 if random.random() < prob else -1.0
            self.current_step = step
            self.state = state.astype(int).tolist()
            self.energy = self._energy(state)
            self.energy_history = self.energy_history + [(step, self.energy, temperature)]
            self.temperature = temperature
            recent_states.append(tuple(self.state))
            if len(recent_states) == recent_states.maxlen and len(set(recent_states)) == 1:
                self.equilibrium_state = list(recent_states[-1])
                break
            temperature = max(temperature * self.cooling_rate, 0.01)
            time.sleep(self.refresh_interval)
        if not self.equilibrium_state:
            self.equilibrium_state = list(self.state)
        self.running = False

    def _energy(self, state: np.ndarray) -> float:
        interaction = -0.5 * float(state.T @ self.weights @ state)
        bias_term = -float(np.dot(self.biases, state))
        return interaction + bias_term


class SteepestDescentSimulator(BaseSimulationThread):
    """Simple steepest-descent on a quadratic function f(x)=0.5*x^T A x - b^T x.

    Records path history (list of 2D points) for visualization.
    """

    def __init__(self, A, b, initial_x, learning_rate, steps, refresh_interval):
        super().__init__(refresh_interval)
        self.A = np.array(A, dtype=float)
        self.b = np.array(b, dtype=float)
        self.x = np.array(initial_x, dtype=float)
        self.learning_rate = float(learning_rate)
        self.steps = int(steps)
        self.path_history = [self.x.tolist()]
        self.current_iteration = 0
        self.running = False

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        for k in range(1, self.steps + 1):
            if self._should_stop:
                break
            grad = self.A @ self.x - self.b
            self.x = self.x - self.learning_rate * grad
            self.current_iteration = k
            self.path_history = self.path_history + [self.x.tolist()]
            time.sleep(self.refresh_interval)
        self.running = False


class NewtonMethodSimulator(BaseSimulationThread):
    """Newton's method for quadratic problems; for f(x)=0.5 x^T A x - b^T x,
    Newton step is exact if A is invertible (one-step convergence).
    """

    def __init__(self, A, b, initial_x, steps, refresh_interval):
        super().__init__(refresh_interval)
        self.A = np.array(A, dtype=float)
        self.b = np.array(b, dtype=float)
        self.x = np.array(initial_x, dtype=float)
        self.steps = int(steps)
        self.path_history = [self.x.tolist()]
        self.current_iteration = 0
        self.running = False

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        # precompute inverse (small 2x2 demo, fine to invert)
        try:
            Ainv = np.linalg.inv(self.A)
        except np.linalg.LinAlgError:
            # fall back to pseudo-inverse if singular
            Ainv = np.linalg.pinv(self.A)
        for k in range(1, self.steps + 1):
            if self._should_stop:
                break
            grad = self.A @ self.x - self.b
            self.x = self.x - Ainv @ grad
            self.current_iteration = k
            self.path_history = self.path_history + [self.x.tolist()]
            time.sleep(self.refresh_interval)
        self.running = False


class ConjugateGradientSimulator(BaseSimulationThread):
    """Conjugate gradient to solve Ax = b for symmetric positive-definite A.

    Records path history of iterates x_k.
    """

    def __init__(self, A, b, initial_x, max_iterations, refresh_interval):
        super().__init__(refresh_interval)
        self.A = np.array(A, dtype=float)
        self.b = np.array(b, dtype=float)
        self.x = np.array(initial_x, dtype=float)
        self.max_iterations = int(max_iterations)
        self.path_history = [self.x.tolist()]
        self.current_iteration = 0
        self.running = False

    def stop(self) -> None:
        super().stop()

    def run(self) -> None:
        self.running = True
        r = self.b - self.A @ self.x
        p = r.copy()
        rs_old = float(r.dot(r))
        for k in range(1, self.max_iterations + 1):
            if self._should_stop:
                break
            Ap = self.A @ p
            alpha = rs_old / float(p.dot(Ap) + 1e-12)
            self.x = self.x + alpha * p
            r = r - alpha * Ap
            rs_new = float(r.dot(r))
            if np.sqrt(rs_new) < 1e-10:
                self.current_iteration = k
                self.path_history = self.path_history + [self.x.tolist()]
                break
            beta = rs_new / (rs_old + 1e-12)
            p = r + beta * p
            rs_old = rs_new
            self.current_iteration = k
            self.path_history = self.path_history + [self.x.tolist()]
            time.sleep(self.refresh_interval)
        self.running = False
