import numpy as np
from . import TraningAlgorithm


class HopfieldAlgorithm(TraningAlgorithm):
    """离散型Hopfield神经网络"""
    
    def __init__(self, patterns, max_iterations=100, total_epoches=1):
        """
        Args:
            patterns: 要存储的模式列表，每个模式是一个二值向量 (1/-1)
            max_iterations: 异步更新的最大迭代次数
            total_epoches: 训练轮数（Hopfield一般只需要1轮）
        """
        # Hopfield不需要传统的dataset，但为了兼容基类
        super().__init__(dataset=[], total_epoches=total_epoches)
        
        self.patterns = np.array(patterns) if len(patterns) > 0 else np.array([])
        self.n_neurons = len(patterns[0]) if len(patterns) > 0 else 0
        self.max_iterations = max_iterations
        
        # 权重矩阵
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        
        # 当前状态
        self.current_state = np.ones(self.n_neurons) if self.n_neurons > 0 else np.array([])
        self.state_history = []
        self.energy_history = []
        
        # 吸引子相关
        self.attractors = []
        self.attractor_energies = []
        
        self.current_iterations = 0
        self.is_converged = False
        
    def _initialize_neurons(self):
        """使用Hebb规则训练权重矩阵"""
        self._neurons = []  # 兼容基类
        
        if len(self.patterns) == 0 or self.n_neurons == 0:
            return
            
        # Hebb学习规则: W = (1/n) * Σ(p_i * p_i^T) - I
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        
        for pattern in self.patterns:
            pattern = pattern.reshape(-1, 1)
            self.weights += np.dot(pattern, pattern.T)
        
        self.weights /= self.n_neurons
        
        # 对角线设为0（神经元不自连接）
        np.fill_diagonal(self.weights, 0)
    
    def set_initial_state(self, state):
        """设置初始状态"""
        if len(state) != self.n_neurons:
            # 如果长度不匹配，创建默认状态
            self.current_state = np.ones(self.n_neurons)
        else:
            self.current_state = np.array(state).copy()
        
        self.state_history = [self.current_state.copy()]
        energy = self.calculate_energy(self.current_state)
        self.energy_history = [energy if np.isfinite(energy) else 0.0]
        self.current_iterations = 0
        self.is_converged = False
    
    def _iterate(self):
        """异步更新一个神经元"""
        if self.is_converged or self.n_neurons == 0:
            return
        
        # 随机选择一个神经元进行更新
        neuron_idx = np.random.randint(0, self.n_neurons)
        
        # 计算该神经元的输入
        net_input = np.dot(self.weights[neuron_idx], self.current_state)
        
        # 更新神经元状态（符号函数）
        self.current_state[neuron_idx] = 1 if net_input >= 0 else -1
        
        # 记录状态和能量
        self.state_history.append(self.current_state.copy())
        current_energy = self.calculate_energy(self.current_state)
        
        # 确保能量是有效的数值
        if np.isfinite(current_energy):
            self.energy_history.append(current_energy)
        else:
            # 如果计算出无效值，使用上一个有效值
            if len(self.energy_history) > 0:
                self.energy_history.append(self.energy_history[-1])
            else:
                self.energy_history.append(0.0)
        
        # 检查是否收敛（状态不再变化）
        if len(self.state_history) > 10:
            recent_states = self.state_history[-10:]
            if all(np.array_equal(self.current_state, s) for s in recent_states):
                self.is_converged = True
        
        self.current_iterations += 1
    
    def run(self):
        """运行网络直到收敛"""
        if self.n_neurons == 0:
            return
            
        self._initialize_neurons()
        
        while self.current_iterations < self.max_iterations and not self._should_stop:
            if self.is_converged:
                break
            self._iterate()
    
    def calculate_energy(self, state):
        """计算网络能量: E = -0.5 * Σ Σ w_ij * s_i * s_j"""
        if len(state) == 0 or self.n_neurons == 0:
            return 0.0
        
        try:
            energy = -0.5 * np.dot(state, np.dot(self.weights, state))
            # 确保返回有效数值
            if np.isfinite(energy):
                return float(energy)
            else:
                return 0.0
        except:
            return 0.0
    
    def find_attractors(self, n_trials=50):
        """通过随机初始状态寻找吸引子"""
        if self.n_neurons == 0:
            return
            
        self.attractors = []
        self.attractor_energies = []
        
        for _ in range(n_trials):
            if self._should_stop:
                break
                
            # 随机初始状态
            random_state = np.random.choice([-1, 1], size=self.n_neurons)
            self.set_initial_state(random_state)
            self.run()
            
            # 检查是否是新的吸引子
            is_new = True
            for attractor in self.attractors:
                if np.array_equal(self.current_state, attractor):
                    is_new = False
                    break
            
            if is_new and self.is_converged:
                self.attractors.append(self.current_state.copy())
                energy = self.calculate_energy(self.current_state)
                if np.isfinite(energy):
                    self.attractor_energies.append(float(energy))
                else:
                    self.attractor_energies.append(0.0)
        
        # 按能量排序
        if len(self.attractors) > 0:
            sorted_indices = np.argsort(self.attractor_energies)
            self.attractors = [self.attractors[i] for i in sorted_indices]
            self.attractor_energies = [self.attractor_energies[i] for i in sorted_indices]
    
    def pattern_recognition(self, noisy_pattern):
        """模式识别：从噪声模式恢复原始模式"""
        self.set_initial_state(noisy_pattern)
        self.run()
        return self.current_state
    
    def calculate_overlap(self, state, pattern):
        """计算状态与模式的重叠度"""
        if self.n_neurons == 0:
            return 0.0
        return float(np.dot(state, pattern)) / self.n_neurons