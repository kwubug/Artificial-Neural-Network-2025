import numpy as np
import matplotlib.pyplot as plt
import warnings


warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


class DiscreteHopfieldNN:
    def __init__(self, num_neurons):
        """
        初始化离散型Hopfield神经网络
        :param num_neurons: 神经元数量（即输入/输出向量的维度）
        """
        self.num_neurons = num_neurons
        self.weights = np.zeros((num_neurons, num_neurons))

    def train(self, train_samples):
        """
        用Hebbian学习规则训练权重矩阵
        :param train_samples: 训练样本集，shape=(样本数, 神经元数量)，每个样本元素为+1或-1
        """
        num_samples = len(train_samples)
        for x in train_samples:

            x = x.reshape(-1, 1)
            self.weights += (x @ x.T) / self.num_neurons

        np.fill_diagonal(self.weights, 0)

    def async_update(self, state, update_order='random'):
        """
        异步更新：每次更新一个神经元，返回更新后的状态
        :param state: 当前状态向量（元素为+1或-1）
        :param update_order: 更新顺序（'random'随机 / 'sequential'顺序）
        :return: 更新后的状态向量
        """
        new_state = state.copy()

        if update_order == 'random':
            neurons = np.random.permutation(self.num_neurons)
        else:
            neurons = np.arange(self.num_neurons)


        for i in neurons:

            input_sum = np.dot(self.weights[i], new_state)

            new_state[i] = 1 if input_sum >= 0 else -1
            break
        return new_state

    def energy(self, state):
        """
        计算当前状态的能量（能量越低越稳定）
        :param state: 状态向量（元素为+1或-1）
        :return: 能量值E
        """
        state = state.reshape(-1, 1)

        return -0.5 * np.dot(np.dot(state.T, self.weights), state).item()

    def converge_to_attractor(self, init_state, max_steps=100, update_order='random'):
        """
        从初始状态迭代至吸引子（状态不再变化）
        :param init_state: 初始状态（可含噪声）
        :param max_steps: 最大迭代步数（防止无限循环）
        :param update_order: 更新顺序
        :return: 吸引子状态、能量变化列表、迭代步数
        """
        state = init_state.copy()
        energy_history = [self.energy(state)]
        steps = 0

        while steps < max_steps:
            new_state = self.async_update(state, update_order)
            new_energy = self.energy(new_state)
            energy_history.append(new_energy)
            steps += 1


            if np.array_equal(new_state, state):
                break
            state = new_state

        return state, energy_history, steps



if __name__ == "__main__":

    A = np.array([
        [-1, 1, 1, 1, -1],
        [1, -1, -1, -1, 1],
        [1, 1, 1, 1, 1],
        [1, -1, -1, -1, 1],
        [1, -1, -1, -1, 1]
    ]).flatten()

    B = np.array([
        [1, 1, 1, 1, -1],
        [1, -1, -1, -1, 1],
        [1, 1, 1, 1, -1],
        [1, -1, -1, -1, 1],
        [1, 1, 1, 1, -1]
    ]).flatten()
    train_samples = np.array([A, B])


    num_neurons = 25
    hopfield = DiscreteHopfieldNN(num_neurons)
    hopfield.train(train_samples)



    def add_noise(state, noise_ratio=0.1):
        """添加噪声：随机翻转指定比例的像素（+1↔-1）"""
        noisy_state = state.copy()
        noise_indices = np.random.choice(
            num_neurons,
            size=int(noise_ratio * num_neurons),
            replace=False
        )
        noisy_state[noise_indices] *= -1
        return noisy_state


    noisy_A = add_noise(A, noise_ratio=0.2)
    noisy_B = add_noise(B, noise_ratio=0.2)


    attractor_A, energy_A, steps_A = hopfield.converge_to_attractor(noisy_A)
    attractor_B, energy_B, steps_B = hopfield.converge_to_attractor(noisy_B)


    fig, axes = plt.subplots(2, 4, figsize=(16, 8))
    fig.suptitle('离散型Hopfield神经网络：异步更新、吸引子与能量变化', fontsize=16, fontweight='bold')


    axes[0, 0].imshow(A.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[0, 0].set_title('原始字母A', fontsize=12)
    axes[0, 1].imshow(noisy_A.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[0, 1].set_title('20%噪声的A', fontsize=12)
    axes[0, 2].imshow(attractor_A.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[0, 2].set_title(f'A的吸引子（{steps_A}步收敛）', fontsize=12)

    axes[0, 3].plot(energy_A, marker='o', linewidth=2, color='blue', markersize=4)
    axes[0, 3].set_title('A的能量变化', fontsize=12)
    axes[0, 3].set_xlabel('迭代步数')
    axes[0, 3].set_ylabel('能量E')
    axes[0, 3].grid(True, alpha=0.3)


    axes[1, 0].imshow(B.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[1, 0].set_title('原始字母B', fontsize=12)
    axes[1, 1].imshow(noisy_B.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[1, 1].set_title('20%噪声的B', fontsize=12)
    axes[1, 2].imshow(attractor_B.reshape(5, 5), cmap='binary', vmin=-1, vmax=1)
    axes[1, 2].set_title(f'B的吸引子（{steps_B}步收敛）', fontsize=12)

    axes[1, 3].plot(energy_B, marker='o', linewidth=2, color='orange', markersize=4)
    axes[1, 3].set_title('B的能量变化', fontsize=12)
    axes[1, 3].set_xlabel('迭代步数')
    axes[1, 3].set_ylabel('能量E')
    axes[1, 3].grid(True, alpha=0.3)


    for ax in axes.flat:
        ax.axis('off')

    plt.tight_layout()
    plt.show()


    print("=" * 60)
    print("📊 Hopfield网络核心特性验证结果")
    print("=" * 60)
    print(f"训练样本是否为稳定吸引子？")
    print(f"→ 原始字母A：{'是' if np.array_equal(attractor_A, A) else '否'}")
    print(f"→ 原始字母B：{'是' if np.array_equal(attractor_B, B) else '否'}")
    print(f"\n吸引子能量（能量越低越稳定）：")
    print(f"→ A吸引子能量：{hopfield.energy(attractor_A):.2f}")
    print(f"→ B吸引子能量：{hopfield.energy(attractor_B):.2f}")
    print(f"\n收敛效率：")
    print(f"→ 带噪声A收敛步数：{steps_A}步")
    print(f"→ 带噪声B收敛步数：{steps_B}步")
    print("=" * 60)