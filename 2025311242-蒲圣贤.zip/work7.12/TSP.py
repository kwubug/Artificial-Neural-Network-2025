import itertools
import math
import random
import matplotlib.pyplot as plt

# 1. 生成随机城市
random.seed
N = 8  # 城市数量，小一点方便穷举
cities = [(random.random(), random.random()) for _ in range(N)]

def path_length(path, points):
    """计算路径总长度（包含回到起点）"""
    total = 0.0
    for i in range(len(path)):
        x1, y1 = points[path[i]]
        x2, y2 = points[(i + 1) % len(path)]
        total += math.dist((x1, y1), (x2, y2))
    return total

# 2. 穷举所有以城市0为起点的路径
best_path = None
best_len = float("inf")

for perm in itertools.permutations(range(1, N)):  # 固定起点0
    path = (0,) + perm
    length = path_length(path, cities)
    if length < best_len:
        best_len = length
        best_path = path

print("best path:", best_path)
print("best length:", best_len)

# 3. 可视化最优路径
x = [cities[i][0] for i in best_path] + [cities[best_path[0]][0]]
y = [cities[i][1] for i in best_path] + [cities[best_path[0]][1]]

plt.figure(figsize=(5, 5))
plt.scatter([c[0] for c in cities], [c[1] for c in cities])

for i, (cx, cy) in enumerate(cities):
    plt.text(cx, cy, str(i))

plt.plot(x, y, marker="o")
plt.title(f"Best TSP tour length = {best_len:.3f}")
plt.xlabel("X")
plt.ylabel("Y")
plt.show()
