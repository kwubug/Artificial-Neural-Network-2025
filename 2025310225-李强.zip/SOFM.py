import sys
import math
import random
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QSlider, QPushButton, QComboBox,
                             QSpinBox, QDoubleSpinBox, QGroupBox, QCheckBox, QTextEdit,
                             QMessageBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QPainter, QPen, QBrush, QColor, QFont, QLinearGradient


class SOFMNode:
    """SOFM网络节点"""

    def __init__(self, x, y, weights):
        self.x = x
        self.y = y
        self.weights = np.array(weights, dtype=np.float64)
        self.activation = 0.0
        self.is_bmu = False
        self.error = 0.0


class SOFMNetwork:
    """SOFM网络模型"""

    def __init__(self, grid_size=(10, 10), input_dim=3):
        self.grid_size = grid_size
        self.input_dim = input_dim
        self.nodes = []
        self.learning_rate = 0.3
        self.initial_learning_rate = 0.3
        self.neighborhood_radius = 3.0
        self.initial_radius = 3.0
        self.iteration = 0
        self.max_iterations = 1000
        self.training_phase = 0  # 0:排序阶段, 1:收敛阶段
        self.initialize_network()

    def initialize_network(self):
        """初始化网络节点"""
        self.nodes = []
        for i in range(self.grid_size[0]):
            for j in range(self.grid_size[1]):
                weights = [random.random() for _ in range(self.input_dim)]
                node = SOFMNode(i, j, weights)
                self.nodes.append(node)

    def find_bmu(self, input_vector):
        """找到最佳匹配单元"""
        input_vec = np.array(input_vector, dtype=np.float64)
        min_distance = float('inf')
        bmu = None

        for node in self.nodes:
            distance = np.linalg.norm(input_vec - node.weights)
            if distance < min_distance:
                min_distance = distance
                bmu = node
                bmu.error = distance

        return bmu, min_distance

    def train_step(self, input_vector):
        """单次训练步骤"""
        # 重置BMU标记
        for node in self.nodes:
            node.is_bmu = False

        bmu, distance = self.find_bmu(input_vector)
        if bmu:
            bmu.is_bmu = True

        # 动态调整学习率和邻域半径
        progress = self.iteration / self.max_iterations

        # 排序阶段和收敛阶段
        if progress < 0.3:  # 排序阶段
            current_lr = self.initial_learning_rate * (1 - progress / 0.3)
            current_radius = self.initial_radius * (1 - progress / 0.3)
            self.training_phase = 0
        else:  # 收敛阶段
            current_lr = self.initial_learning_rate * 0.1 * (1 - progress)
            current_radius = max(0.5, self.initial_radius * (1 - progress))
            self.training_phase = 1

        # 更新权重
        for node in self.nodes:
            dist_to_bmu = math.sqrt((node.x - bmu.x) ** 2 + (node.y - bmu.y) ** 2)

            if dist_to_bmu <= current_radius:
                # 计算邻域函数
                theta = math.exp(-(dist_to_bmu ** 2) / (2 * (current_radius ** 2)))

                # 更新权重
                delta = current_lr * theta * (np.array(input_vector) - node.weights)
                node.weights += delta

        self.iteration += 1
        return bmu, distance

    def generate_training_data(self, num_samples=500):
        """生成训练数据"""
        data = []
        # 生成多个聚类中心的数据
        centers = [
            [0.2, 0.2, 0.8],
            [0.8, 0.2, 0.2],
            [0.2, 0.8, 0.2],
            [0.8, 0.8, 0.8],
            [0.5, 0.2, 0.5],
            [0.2, 0.5, 0.8]
        ]

        for _ in range(num_samples):
            center = random.choice(centers)
            point = [center[i] + random.gauss(0, 0.08) for i in range(3)]
            point = [max(0.01, min(0.99, p)) for p in point]  # 限制在[0,1]范围内
            data.append(point)

        return data

    def get_quantization_error(self):
        """计算量化误差"""
        if not hasattr(self, '_training_data'):
            return 0
        total_error = 0
        for sample in self._training_data[:100]:  # 使用前100个样本计算
            _, distance = self.find_bmu(sample)
            total_error += distance
        return total_error / 100


class SOFMCanvas(QWidget):
    """SOFM网络可视化画布"""

    def __init__(self, network):
        super().__init__()
        self.network = network
        self.node_radius = 12
        self.grid_spacing = 35
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.animate_training)
        self.training_data = []
        self.current_data_index = 0
        self.is_training = False
        self.display_mode = "weights"  # "weights", "activation", "error"
        self.show_connections = True
        self.show_umatrix = False
        self.setMinimumSize(800, 600)

        # 生成训练数据
        self.training_data = self.network.generate_training_data(300)
        self.network._training_data = self.training_data

    def animate_training(self):
        """训练动画"""
        if self.current_data_index >= len(self.training_data):
            self.current_data_index = 0

        input_vector = self.training_data[self.current_data_index]
        bmu, distance = self.network.train_step(input_vector)

        self.current_data_index += 1

        # 检查训练是否完成
        if self.network.iteration >= self.network.max_iterations:
            self.stop_training()
            QMessageBox.information(self, "训练完成", f"SOFM网络训练完成！共进行了{self.network.iteration}次迭代。")

        self.update()

    def start_training(self):
        """开始训练"""
        if self.network.iteration >= self.network.max_iterations:
            reply = QMessageBox.question(self, "重新训练",
                                         "训练已完成，是否重置网络并重新开始？",
                                         QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.reset_network()

        self.is_training = True
        self.animation_timer.start(50)

    def stop_training(self):
        """停止训练"""
        self.is_training = False
        self.animation_timer.stop()

    def reset_network(self):
        """重置网络"""
        self.stop_training()
        self.network.initialize_network()
        self.network.iteration = 0
        self.current_data_index = 0
        self.update()

    def set_training_speed(self, speed):
        """设置训练速度"""
        interval = 110 - speed  # 10-100 ms
        self.animation_timer.setInterval(max(10, interval))

    def set_display_mode(self, mode):
        """设置显示模式"""
        self.display_mode = mode
        self.update()

    def toggle_connections(self, checked):
        """切换连接显示"""
        self.show_connections = checked
        self.update()

    def toggle_umatrix(self, checked):
        """切换U-Matrix显示"""
        self.show_umatrix = checked
        self.update()

    def paintEvent(self, event):
        """绘制SOFM网络"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 设置背景
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor(245, 248, 255))
        gradient.setColorAt(1, QColor(235, 240, 250))
        painter.fillRect(self.rect(), gradient)

        # 计算网格偏移以居中显示
        grid_width = (self.network.grid_size[0] - 1) * self.grid_spacing
        grid_height = (self.network.grid_size[1] - 1) * self.grid_spacing
        offset_x = (self.width() - grid_width) / 2
        offset_y = (self.height() - grid_height) / 2 + 20

        # 绘制连接线
        if self.show_connections:
            painter.setPen(QPen(QColor(180, 180, 200, 120), 1.5))

            # 水平连接线
            for i in range(self.network.grid_size[0]):
                for j in range(self.network.grid_size[1] - 1):
                    node1 = self.network.nodes[i * self.network.grid_size[1] + j]
                    node2 = self.network.nodes[i * self.network.grid_size[1] + j + 1]

                    x1 = offset_x + node1.x * self.grid_spacing
                    y1 = offset_y + node1.y * self.grid_spacing
                    x2 = offset_x + node2.x * self.grid_spacing
                    y2 = offset_y + node2.y * self.grid_spacing

                    painter.drawLine(int(x1), int(y1), int(x2), int(y2))

            # 垂直连接线
            for i in range(self.network.grid_size[0] - 1):
                for j in range(self.network.grid_size[1]):
                    node1 = self.network.nodes[i * self.network.grid_size[1] + j]
                    node2 = self.network.nodes[(i + 1) * self.network.grid_size[1] + j]

                    x1 = offset_x + node1.x * self.grid_spacing
                    y1 = offset_y + node1.y * self.grid_spacing
                    x2 = offset_x + node2.x * self.grid_spacing
                    y2 = offset_y + node2.y * self.grid_spacing

                    painter.drawLine(int(x1), int(y1), int(x2), int(y2))

        # 绘制节点
        for node in self.network.nodes:
            x = offset_x + node.x * self.grid_spacing
            y = offset_y + node.y * self.grid_spacing

            # 根据显示模式设置节点颜色
            if self.display_mode == "weights":
                # 使用权重值作为RGB颜色
                r = int(node.weights[0] * 255) if len(node.weights) > 0 else 128
                g = int(node.weights[1] * 255) if len(node.weights) > 1 else 128
                b = int(node.weights[2] * 255) if len(node.weights) > 2 else 128
                node_color = QColor(r, g, b)
            elif self.display_mode == "error":
                # 使用误差值作为颜色强度
                error_intensity = min(255, int(node.error * 100))
                node_color = QColor(255, 255 - error_intensity, 255 - error_intensity)
            else:  # activation
                gray = int(node.activation * 255)
                node_color = QColor(gray, gray, gray)

            # 绘制节点
            if node.is_bmu:
                # BMU用红色边框突出显示
                painter.setPen(QPen(QColor(255, 50, 50), 3))
                painter.setBrush(QBrush(node_color))
                painter.drawEllipse(int(x - self.node_radius - 2), int(y - self.node_radius - 2),
                                    int((self.node_radius + 2) * 2), int((self.node_radius + 2) * 2))

            painter.setPen(QPen(QColor(50, 50, 50), 1))
            painter.setBrush(QBrush(node_color))
            painter.drawEllipse(int(x - self.node_radius), int(y - self.node_radius),
                                int(self.node_radius * 2), int(self.node_radius * 2))

        # 绘制标题和信息
        painter.setPen(QColor(30, 30, 30))
        painter.setFont(QFont("Arial", 14, QFont.Bold))
        title = "SOFM自组织特征映射网络"
        painter.drawText(10, 25, title)

        # 显示模式说明
        mode_text = "显示模式: "
        if self.display_mode == "weights":
            mode_text += "权重颜色映射"
        elif self.display_mode == "error":
            mode_text += "误差显示"
        else:
            mode_text += "激活值显示"

        painter.setFont(QFont("Arial", 10))
        painter.drawText(10, 45, mode_text)

        # 训练信息
        phase_text = "阶段: " + ("排序" if self.network.training_phase == 0 else "收敛")
        info_text = f"迭代: {self.network.iteration}/{self.network.max_iterations} | 学习率: {self.network.learning_rate:.3f} | {phase_text}"
        painter.drawText(10, 65, info_text)

        # 量化误差
        q_error = self.network.get_quantization_error()
        error_text = f"量化误差: {q_error:.4f}"
        painter.drawText(10, 85, error_text)

        # 绘制颜色图例
        if self.display_mode == "weights":
            self.draw_color_legend(painter)

    def draw_color_legend(self, painter):
        """绘制颜色图例"""
        legend_width = 200
        legend_height = 20
        legend_x = self.width() - legend_width - 20
        legend_y = 30

        # 绘制图例标题
        painter.setPen(QColor(50, 50, 50))
        painter.setFont(QFont("Arial", 9))
        painter.drawText(legend_x, legend_y - 5, "权重值颜色映射 (RGB)")

        # 绘制颜色渐变条
        for i in range(legend_width):
            ratio = i / legend_width
            r = int(ratio * 255)
            g = int((1 - abs(ratio - 0.5) * 2) * 255)
            b = int((1 - ratio) * 255)

            painter.setPen(QColor(r, g, b))
            painter.drawLine(legend_x + i, legend_y, legend_x + i, legend_y + legend_height)

        # 绘制刻度标签
        painter.drawText(legend_x, legend_y + legend_height + 15, "0.0")
        painter.drawText(legend_x + legend_width - 20, legend_y + legend_height + 15, "1.0")


class ControlPanel(QWidget):
    """控制面板"""

    def __init__(self, network_canvas):
        super().__init__()
        self.network_canvas = network_canvas
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(10)

        # 网络参数控制
        params_group = QGroupBox("网络参数配置")
        params_layout = QVBoxLayout()

        # 网格大小
        grid_layout = QHBoxLayout()
        grid_layout.addWidget(QLabel("网格大小:"))
        self.grid_width = QSpinBox()
        self.grid_width.setRange(5, 20)
        self.grid_width.setValue(10)
        self.grid_height = QSpinBox()
        self.grid_height.setRange(5, 20)
        self.grid_height.setValue(10)
        grid_layout.addWidget(self.grid_width)
        grid_layout.addWidget(QLabel("x"))
        grid_layout.addWidget(self.grid_height)
        grid_layout.addWidget(QLabel("节点"))
        params_layout.addLayout(grid_layout)

        # 学习率控制
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("初始学习率:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.01, 1.0)
        self.lr_spin.setSingleStep(0.05)
        self.lr_spin.setValue(0.3)
        self.lr_spin.valueChanged.connect(self.change_learning_rate)
        lr_layout.addWidget(self.lr_spin)
        params_layout.addLayout(lr_layout)

        # 邻域半径控制
        radius_layout = QHBoxLayout()
        radius_layout.addWidget(QLabel("初始邻域半径:"))
        self.radius_spin = QDoubleSpinBox()
        self.radius_spin.setRange(0.5, 10.0)
        self.radius_spin.setSingleStep(0.5)
        self.radius_spin.setValue(3.0)
        self.radius_spin.valueChanged.connect(self.change_neighborhood_radius)
        radius_layout.addWidget(self.radius_spin)
        params_layout.addLayout(radius_layout)

        # 最大迭代次数
        iter_layout = QHBoxLayout()
        iter_layout.addWidget(QLabel("最大迭代次数:"))
        self.iter_spin = QSpinBox()
        self.iter_spin.setRange(100, 10000)
        self.iter_spin.setSingleStep(100)
        self.iter_spin.setValue(1000)
        self.iter_spin.valueChanged.connect(self.change_max_iterations)
        iter_layout.addWidget(self.iter_spin)
        params_layout.addLayout(iter_layout)

        params_group.setLayout(params_layout)
        layout.addWidget(params_group)

        # 训练控制
        training_group = QGroupBox("训练控制")
        training_layout = QVBoxLayout()

        # 训练按钮
        button_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始训练")
        self.stop_btn = QPushButton("停止训练")
        self.reset_btn = QPushButton("重置网络")
        self.start_btn.clicked.connect(self.network_canvas.start_training)
        self.stop_btn.clicked.connect(self.network_canvas.stop_training)
        self.reset_btn.clicked.connect(self.network_canvas.reset_network)
        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.stop_btn)
        button_layout.addWidget(self.reset_btn)
        training_layout.addLayout(button_layout)

        # 训练速度
        speed_layout = QHBoxLayout()
        speed_layout.addWidget(QLabel("训练速度:"))
        self.speed_slider = QSlider(Qt.Horizontal)
        self.speed_slider.setRange(10, 100)
        self.speed_slider.setValue(50)
        self.speed_slider.valueChanged.connect(self.network_canvas.set_training_speed)
        speed_layout.addWidget(self.speed_slider)
        training_layout.addLayout(speed_layout)

        training_group.setLayout(training_layout)
        layout.addWidget(training_group)

        # 显示设置
        display_group = QGroupBox("显示设置")
        display_layout = QVBoxLayout()

        # 显示模式
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(QLabel("显示模式:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["权重颜色映射", "误差显示", "激活值显示"])
        self.mode_combo.currentTextChanged.connect(self.change_display_mode)
        mode_layout.addWidget(self.mode_combo)
        display_layout.addLayout(mode_layout)

        # 显示选项
        option_layout = QHBoxLayout()
        self.conn_check = QCheckBox("显示连接")
        self.conn_check.setChecked(True)
        self.conn_check.toggled.connect(self.network_canvas.toggle_connections)
        option_layout.addWidget(self.conn_check)

        self.umatrix_check = QCheckBox("显示U-Matrix")
        self.umatrix_check.toggled.connect(self.network_canvas.toggle_umatrix)
        option_layout.addWidget(self.umatrix_check)
        display_layout.addLayout(option_layout)

        # 节点大小
        size_layout = QHBoxLayout()
        size_layout.addWidget(QLabel("节点大小:"))
        self.size_slider = QSlider(Qt.Horizontal)
        self.size_slider.setRange(8, 20)
        self.size_slider.setValue(12)
        self.size_slider.valueChanged.connect(self.change_node_size)
        size_layout.addWidget(self.size_slider)
        display_layout.addLayout(size_layout)

        display_group.setLayout(display_layout)
        layout.addWidget(display_group)

        # 信息显示
        info_group = QGroupBox("网络信息")
        info_layout = QVBoxLayout()
        self.info_text = QTextEdit()
        self.info_text.setMaximumHeight(120)
        self.info_text.setReadOnly(True)
        info_layout.addWidget(self.info_text)
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)

        layout.addStretch()
        self.setLayout(layout)
        self.update_info()

    def change_learning_rate(self, value):
        """改变学习率"""
        self.network_canvas.network.learning_rate = value
        self.network_canvas.network.initial_learning_rate = value
        self.update_info()

    def change_neighborhood_radius(self, value):
        """改变邻域半径"""
        self.network_canvas.network.neighborhood_radius = value
        self.network_canvas.network.initial_radius = value
        self.update_info()

    def change_max_iterations(self, value):
        """改变最大迭代次数"""
        self.network_canvas.network.max_iterations = value
        self.update_info()

    def change_display_mode(self, mode):
        """改变显示模式"""
        if mode == "权重颜色映射":
            self.network_canvas.set_display_mode("weights")
        elif mode == "误差显示":
            self.network_canvas.set_display_mode("error")
        else:
            self.network_canvas.set_display_mode("activation")

    def change_node_size(self, size):
        """改变节点大小"""
        self.network_canvas.node_radius = size
        self.network_canvas.update()

    def update_info(self):
        """更新网络信息"""
        network = self.network_canvas.network
        info = f"网格大小: {network.grid_size[0]}x{network.grid_size[1]}\n"
        info += f"节点数量: {len(network.nodes)}\n"
        info += f"输入维度: {network.input_dim}\n"
        info += f"当前学习率: {network.learning_rate:.3f}\n"
        info += f"当前邻域半径: {network.neighborhood_radius:.1f}\n"
        info += f"训练进度: {network.iteration}/{network.max_iterations}\n"
        info += f"训练阶段: {'排序' if network.training_phase == 0 else '收敛'}\n"
        info += f"量化误差: {network.get_quantization_error():.4f}"

        self.info_text.setText(info)


class SOFMVisualizer(QMainWindow):
    """SOFM网络可视化主窗口"""

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('SOFM自组织特征映射网络可视化工具')
        self.setGeometry(100, 100, 1200, 800)

        # 创建中心部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 创建布局
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # 创建SOFM网络和画布
        self.network = SOFMNetwork(grid_size=(10, 10), input_dim=3)
        self.network_canvas = SOFMCanvas(self.network)

        # 创建控制面板
        self.control_panel = ControlPanel(self.network_canvas)
        self.control_panel.setFixedWidth(300)

        # 添加到布局
        main_layout.addWidget(self.network_canvas)
        main_layout.addWidget(self.control_panel)

        # 状态栏
        self.statusBar().showMessage('SOFM网络可视化工具已就绪 - 点击"开始训练"观察自组织过程')

        # 创建定时器更新信息
        self.info_timer = QTimer(self)
        self.info_timer.timeout.connect(self.control_panel.update_info)
        self.info_timer.start(500)  # 每500ms更新一次信息


def main():
    
    app = QApplication(sys.argv)

    # 设置应用程序样式
    app.setStyle('Fusion')

    visualizer = SOFMVisualizer()
    visualizer.show()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
