import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

class GradientDescentVisualizer:
    def __init__(self):
        self.A = None
        self.b = None
        self.optimum = None
        self.x0 = None
        self.max_stable_lr = None
        self.input_quadratic_params()
        self.input_initial_point()
#####设置标准形式函数
    def input_quadratic_params(self):
        print("\n请输入二次函数参数：")
        print("二次函数形式：f(x) = 1/2 * x^T A x - b^T x")
        print("A 是 2x2 矩阵")
        print("b 是 2x1 向量")
        try:
            A_str = input("请输入矩阵 A（每行用；分隔，行内用，分隔）：").strip()
            rows = A_str.split('；')
            self.A = np.array([list(map(float, row.split('，'))) for row in rows], dtype=float)
            b_str = input("请输入向量 b（用，分隔）：").strip()
            self.b = np.array(list(map(float, b_str.split('，'))), dtype=float)
            self.optimum = np.linalg.solve(self.A, self.b)
            self.compute_max_stable_lr()
            print("\n二次函数设置完成。")
        except Exception as e:
            print("输入格式错误，请重新运行并按示例格式输入。")
            raise e
#####计算由Hessian矩阵确定的最大稳定学习率
    def compute_max_stable_lr(self):
        eigenvalues = np.linalg.eigvals(self.A)
        lambda_max = np.max(eigenvalues)
        self.max_stable_lr = 2.0 / lambda_max
        print(f"\nHessian 矩阵的最大特征值为：{lambda_max:.6f}")
        print(f"建议最大稳定学习率不超过：{self.max_stable_lr:.6f}")

    def input_initial_point(self):
        print("\n请输入初始猜测点 x0（用，分隔）：")
        try:
            x0_str = input().strip()
            self.x0 = np.array(list(map(float, x0_str.split('，'))))
            print(f"初始点设置为：[{self.x0[0]:.2f}, {self.x0[1]:.2f}]")
        except Exception as e:
            print("输入格式错误，请重新运行并按示例格式输入。")
            raise e

    def func(self, x):
        return 0.5 * x.T @ self.A @ x - self.b.T @ x
    def grad(self, x):
        return self.A @ x - self.b
    def hessian(self, x):
        return self.A
#####最速下降法
    def steepest_descent(self, lr=0.001, max_iter=1000, tol=1e-6):
        trajectory = [self.x0.copy()]
        function_values = [self.func(self.x0)]
        x = self.x0.copy()
        for i in range(max_iter):
            grad = self.grad(x)     ###梯度###
            grad_norm = np.linalg.norm(grad)
            if grad_norm < tol:
                print(f"最速下降法在 {i} 次迭代后收敛")
                break
            x = x - lr * grad
            trajectory.append(x.copy())
            function_values.append(self.func(x))
        return np.array(trajectory), np.array(function_values)
#####牛顿迭代法
    def newton_method(self, max_iter=100, tol=1e-6):
        trajectory = [self.x0.copy()]
        function_values = [self.func(self.x0)]
        x = self.x0.copy()
        for i in range(max_iter):
            grad = self.grad(x)
            hess = self.hessian(x)
            grad_norm = np.linalg.norm(grad)
            if grad_norm < tol:
                print(f"牛顿法在 {i} 次迭代后收敛")
                break
            try:
                delta = np.linalg.solve(hess, grad)
                x = x - delta
            except np.linalg.LinAlgError:
                print("Hessian矩阵奇异，使用梯度下降步")
                x = x - 0.001 * grad
            trajectory.append(x.copy())
            function_values.append(self.func(x))
        return np.array(trajectory), np.array(function_values)
#####共轭梯度法
    def conjugate_gradient(self, lr=0.001, max_iter=1000, tol=1e-6):
        trajectory = [self.x0.copy()]
        function_values = [self.func(self.x0)]
        x = self.x0.copy()
        g_old = self.grad(x)
        d = -g_old
        for i in range(max_iter):
            alpha = lr
            x = x + alpha * d
            g_new = self.grad(x)
            if np.linalg.norm(g_new) < tol:
                print(f"共轭梯度法在 {i} 次迭代后收敛")
                break
            if np.dot(g_old, g_old) > 1e-10:
                beta = np.dot(g_new, g_new) / np.dot(g_old, g_old)
            else:
                beta = 0.0
            d = -g_new + beta * d
            g_old = g_new.copy()
            trajectory.append(x.copy())
            function_values.append(self.func(x))
        return np.array(trajectory), np.array(function_values)
#####绘制图表
    def create_contour_plot(self, trajectory, label):
        x = np.linspace(-3, 3, 100)
        y = np.linspace(-3, 3, 100)
        X, Y = np.meshgrid(x, y)
        Z = np.zeros_like(X)
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                Z[i, j] = self.func(np.array([X[i, j], Y[i, j]]))

        plt.figure(figsize=(10, 6))
        plt.contour(X, Y, Z, levels=50, alpha=0.6)
        plt.contourf(X, Y, Z, levels=50, alpha=0.3)
        plt.plot(trajectory[:, 0], trajectory[:, 1], 'o-', color='red', label=label)
        plt.scatter(trajectory[0, 0], trajectory[0, 1], color='green', marker='*', s=200, label='起点')
        plt.scatter(trajectory[-1, 0], trajectory[-1, 1], color='blue', marker='X', s=150, label='终点')
        plt.xlabel('x1')
        plt.ylabel('x2')
        plt.title(f'{label} - 搜索轨迹')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.show()

    def create_convergence_plot(self, function_values, label):
        plt.figure(figsize=(12, 6))
        plt.plot(range(len(function_values)), function_values, 'b-o', linewidth=2, markersize=6, label=f'{label} 函数值')
        plt.scatter(0, function_values[0], color='green', marker='*', s=200, label='起点')
        plt.scatter(len(function_values)-1, function_values[-1], color='red', marker='X', s=150, label='终点')
###### 计算理论最优值
        optimal_value = -0.5 * self.b.T @ np.linalg.solve(self.A, self.b)
        plt.axhline(y=optimal_value, color='gray', linestyle='--', label=f'理论最优值（{optimal_value:.4f}）')
        for i, val in enumerate(function_values[::max(1, len(function_values)//10)]):
            plt.annotate(f'{val:.2f}', (i, val), textcoords="offset points", xytext=(0,10), ha='center')
        plt.xlabel('迭代次数')
        plt.ylabel('函数值')
        plt.title(f'{label} - 收敛曲线（线性尺度）')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.show()
#####可视化代码
def main():
    print("=== 梯度下降算法可视化工具（仅支持自定义二次函数） ===")
    visualizer = GradientDescentVisualizer()

    while True:
        print("\n请选择要运行的梯度下降算法：")
        print("1. 最速下降法")
        print("2. 牛顿法")
        print("3. 共轭梯度法")
        print("4. 更换函数或初始点")
        print("5. 退出程序")
        choice = input("请输入数字（1/2/3/4/5）：").strip()

        if choice == '5':
            print("程序已退出。")
            break

        if choice == '4':
            visualizer.input_quadratic_params()
            visualizer.input_initial_point()
            continue

        lr = 0.001
        if choice in ['1', '3']:
            lr_input = input(f"请输入学习率（建议不超过 {visualizer.max_stable_lr:.6f}）：").strip()
            lr = float(lr_input) if lr_input else 0.001

        if choice == '1':
            traj, fvals = visualizer.steepest_descent(lr=lr, max_iter=2000)
            label = "最速下降法"
        elif choice == '2':
            traj, fvals = visualizer.newton_method(max_iter=50)
            label = "牛顿法"
        elif choice == '3':
            traj, fvals = visualizer.conjugate_gradient(lr=lr, max_iter=500)
            label = "共轭梯度法"
        else:
            print("输入无效，请重新选择。")
            continue

        print("\n最终结果：")
        print(f"算法：{label}")
        print(f"最终点：[{traj[-1, 0]:.6f}, {traj[-1, 1]:.6f}]")
        print(f"最终函数值：{fvals[-1]:.10f}")
        print(f"迭代次数：{len(traj) - 1}")
        print(f"与最优解距离：{np.linalg.norm(traj[-1] - visualizer.optimum):.6f}")

        visualizer.create_contour_plot(traj, label)
        visualizer.create_convergence_plot(fvals, label)
if __name__ == "__main__":
    main()