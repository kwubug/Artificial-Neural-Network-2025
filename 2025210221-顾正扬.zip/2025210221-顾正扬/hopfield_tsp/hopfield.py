import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple, Optional, Union

# 设置matplotlib支持中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


class DiscreteHopfieldNetwork:
    """
    离散型Hopfield神经网络实现
    支持异步更新、吸引子检测和能量计算
    """

    def __init__(self, n_neurons: int):
        """
        初始化Hopfield神经网络
        
        Args:
            n_neurons: 神经元数量
        """
        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))  # 权值矩阵
        self.biases = np.zeros(n_neurons)  # 偏置向量
        self.trained = False  # 网络是否已经训练过

    def __str__(self):
        return f"DiscreteHopfieldNetwork with {self.n_neurons} neurons, trained: {self.trained}"

    def __repr__(self):
        return self.__str__()

    def train(self, patterns: Union[np.ndarray, List[np.ndarray]]):
        """
        使用Hebb学习规则训练Hopfield神经网络
        
        Args:
            patterns: 训练模式集合，可以是二维数组或列表的一维数组
                      每个模式是一个长度为n_neurons的二进制向量(0/1或-1/1)
        """
        # 确保patterns是numpy数组格式
        if isinstance(patterns, list):
            patterns = np.array(patterns)

        # 验证模式维度
        if patterns.ndim == 1:
            patterns = patterns.reshape(1, -1)

        if patterns.shape[1] != self.n_neurons:
            raise ValueError(f"每个模式的长度必须为{n_neurons}")

        # 确保模式是二进制的(-1/1)
        patterns = np.array(patterns)
        if not np.all((patterns == 1) | (patterns == -1)):
            # 如果是0/1模式，转换为-1/1模式
            if np.all((patterns == 0) | (patterns == 1)):
                patterns = 2 * patterns - 1
            else:
                raise ValueError("模式必须是二进制的(0/1或-1/1)")

        # 使用Hebb规则初始化权值矩阵
        self.weights = np.zeros((self.n_neurons, self.n_neurons))

        # 计算权值矩阵: W = (1/N) * Σ(p_i * p_i^T) - I
        # 其中N是模式数量，I是单位矩阵（对角线元素为0）
        n_patterns = patterns.shape[0]
        for pattern in patterns:
            pattern = pattern.reshape(-1, 1)  # 转换为列向量
            self.weights += np.dot(pattern, pattern.T)

        self.weights /= n_patterns  # 除以模式数量
        np.fill_diagonal(self.weights, 0)  # 设置对角线元素为0

        self.trained = True
        return self

    def reset_weights(self):
        """
        重置权值矩阵为零矩阵
        """
        self.weights = np.zeros((self.n_neurons, self.n_neurons))
        self.biases = np.zeros(self.n_neurons)
        self.trained = False
        return self

    def _update_neuron(self, state: np.ndarray, neuron_idx: int) -> int:
        """
        异步更新单个神经元的状态
        
        Args:
            state: 当前网络状态
            neuron_idx: 要更新的神经元索引
            
        Returns:
            更新后的神经元状态
        """
        # 计算输入总和：sum(w_ij * s_j) + b_i
        input_sum = np.dot(self.weights[neuron_idx], state) + self.biases[neuron_idx]

        # 使用符号函数更新状态：s_i = sign(sum)
        # 如果sum为0，返回当前状态以避免震荡
        if input_sum > 0:
            return 1
        elif input_sum < 0:
            return -1
        else:
            return state[neuron_idx]

    def update_async(self, state: Union[np.ndarray, List[int]], max_iterations: int = 1000,
                     return_history: bool = False) -> Union[np.ndarray, Tuple[np.ndarray, List[np.ndarray]]]:
        """
        异步更新网络状态，直到收敛或达到最大迭代次数
        
        Args:
            state: 初始状态向量
            max_iterations: 最大迭代次数
            return_history: 是否返回状态更新历史
            
        Returns:
            最终稳定状态，如果return_history为True，则返回(最终状态, 状态历史)
        """
        if not self.trained:
            raise ValueError("网络尚未训练，请先调用train方法")

        # 确保state是numpy数组格式
        state = np.array(state, dtype=int)

        # 验证状态维度
        if state.shape != (self.n_neurons,):
            raise ValueError(f"状态向量的长度必须为{self.n_neurons}")

        # 确保状态是二进制的(-1/1)
        if not np.all((state == 1) | (state == -1)):
            # 如果是0/1状态，转换为-1/1状态
            if np.all((state == 0) | (state == 1)):
                state = 2 * state - 1
            else:
                raise ValueError("状态必须是二进制的(0/1或-1/1)")

        # 初始化历史记录
        if return_history:
            history = [state.copy()]

        # 异步更新过程
        prev_state = state.copy()
        converged = False

        for _ in range(max_iterations):
            # 随机选择一个神经元进行更新
            neuron_idx = np.random.randint(0, self.n_neurons)

            # 更新选中的神经元
            state[neuron_idx] = self._update_neuron(state, neuron_idx)

            # 记录历史
            if return_history:
                history.append(state.copy())

            # 检查是否收敛
            if np.array_equal(state, prev_state):
                converged = True
                break

            prev_state = state.copy()

        if not converged:
            print(f"警告: 未在{max_iterations}次迭代内收敛")

        if return_history:
            return state, history
        else:
            return state

    def is_attractor(self, state: Union[np.ndarray, List[int]]) -> bool:
        """
        检查给定状态是否是网络的吸引子
        
        Args:
            state: 要检查的状态向量
            
        Returns:
            如果状态是吸引子则返回True，否则返回False
        """
        if not self.trained:
            raise ValueError("网络尚未训练，请先调用train方法")

        # 确保state是numpy数组格式
        state = np.array(state, dtype=int)

        # 验证状态维度
        if state.shape != (self.n_neurons,):
            raise ValueError(f"状态向量的长度必须为{self.n_neurons}")

        # 确保状态是二进制的(-1/1)
        if not np.all((state == 1) | (state == -1)):
            # 如果是0/1状态，转换为-1/1状态
            if np.all((state == 0) | (state == 1)):
                state = 2 * state - 1
            else:
                raise ValueError("状态必须是二进制的(0/1或-1/1)")

        # 检查每个神经元更新后是否保持不变
        for neuron_idx in range(self.n_neurons):
            if self._update_neuron(state, neuron_idx) != state[neuron_idx]:
                return False

        return True

    def find_attractors(self, start_states: Optional[Union[np.ndarray, List[np.ndarray]]] = None,
                        n_samples: int = 100) -> List[np.ndarray]:
        """
        查找网络的所有吸引子
        
        Args:
            start_states: 可选的起始状态集合，如果为None则随机生成
            n_samples: 如果start_states为None，则生成的随机起始状态数量
            
        Returns:
            所有找到的唯一吸引子列表
        """
        if not self.trained:
            raise ValueError("网络尚未训练，请先调用train方法")

        # 生成起始状态
        if start_states is None:
            # 随机生成n_samples个起始状态
            start_states = []
            for _ in range(n_samples):
                # 随机生成-1和1组成的状态向量
                state = np.random.choice([-1, 1], size=self.n_neurons)
                start_states.append(state)
        elif isinstance(start_states, list):
            # 确保每个状态是numpy数组
            start_states = [np.array(state) for state in start_states]
        elif isinstance(start_states, np.ndarray):
            if start_states.ndim == 1:
                start_states = [start_states]

        # 查找吸引子
        attractors = []
        attractor_set = set()  # 用于快速检查吸引子是否已存在

        for state in start_states:
            # 异步更新直到收敛
            final_state = self.update_async(state)

            # 验证最终状态是否为吸引子
            if self.is_attractor(final_state):
                # 将数组转换为元组以便存入集合
                state_tuple = tuple(final_state)
                if state_tuple not in attractor_set:
                    attractor_set.add(state_tuple)
                    attractors.append(final_state.copy())

        return attractors

    def energy(self, state: Union[np.ndarray, List[int]]) -> float:
        """
        计算Hopfield神经网络的能量
        
        Args:
            state: 当前网络状态向量
            
        Returns:
            系统能量值
        """
        # 确保state是numpy数组格式
        state = np.array(state, dtype=int)

        # 验证状态维度
        if state.shape != (self.n_neurons,):
            raise ValueError(f"状态向量的长度必须为{self.n_neurons}")

        # 确保状态是二进制的(-1/1)
        if not np.all((state == 1) | (state == -1)):
            # 如果是0/1状态，转换为-1/1状态
            if np.all((state == 0) | (state == 1)):
                state = 2 * state - 1
            else:
                raise ValueError("状态必须是二进制的(0/1或-1/1)")

        # 计算能量：E = -0.5 * ΣΣ w_ij * s_i * s_j - Σ b_i * s_i
        term1 = -0.5 * np.sum(self.weights * np.outer(state, state))
        term2 = -np.sum(self.biases * state)

        return term1 + term2

    def energy_landscape(self, state: Union[np.ndarray, List[int]], n_steps: int = 100,
                         plot: bool = True) -> Tuple[List[float], np.ndarray]:
        """
        计算从给定状态异步更新到吸引子过程中的能量变化
        
        Args:
            state: 初始状态向量
            n_steps: 最大更新步数
            plot: 是否绘制能量变化图
            
        Returns:
            (能量历史, 最终状态)
        """
        # 异步更新并记录历史
        final_state, history = self.update_async(state, max_iterations=n_steps, return_history=True)

        # 计算每个状态的能量
        energy_history = [self.energy(state) for state in history]

        # 绘制能量变化图
        if plot:
            plt.figure(figsize=(10, 6))
            plt.plot(energy_history, 'b-o', markersize=4, linewidth=1)
            plt.title('Hopfield神经网络能量变化')
            plt.xlabel('更新步数')
            plt.ylabel('能量')
            plt.grid(True, alpha=0.3)
            plt.show()

        return energy_history, final_state

    def get_attractor_energies(self, attractors: Optional[List[np.ndarray]] = None) -> List[Tuple[np.ndarray, float]]:
        """
        计算所有吸引子的能量
        
        Args:
            attractors: 吸引子列表，如果为None则先查找所有吸引子
            
        Returns:
            (吸引子状态, 能量)的列表
        """
        if attractors is None:
            attractors = self.find_attractors()

        # 计算每个吸引子的能量
        attractor_energies = []
        for attractor in attractors:
            e = self.energy(attractor)
            attractor_energies.append((attractor, e))

        # 按能量升序排序
        attractor_energies.sort(key=lambda x: x[1])

        return attractor_energies


# 示例代码：演示离散型Hopfield神经网络的使用
if __name__ == "__main__":
    print("=== 离散型Hopfield神经网络示例 ===")

    # 1. 创建几个简单的模式用于训练
    # 使用8个神经元的网络
    n_neurons = 8

    # 创建几个二值模式 (0/1)
    pattern1 = np.array([1, 1, 1, 1, 0, 0, 0, 0])  # 前四个神经元为1，后四个为0
    pattern2 = np.array([1, 1, 0, 0, 1, 1, 0, 0])  # 每两个神经元交替为1
    pattern3 = np.array([1, 0, 1, 0, 1, 0, 1, 0])  # 奇偶位置交替为1

    patterns = [pattern1, pattern2, pattern3]

    # 2. 创建并训练Hopfield神经网络
    print("\n1. 创建并训练网络...")
    hn = DiscreteHopfieldNetwork(n_neurons)
    print(f"初始化网络: {hn}")

    hn.train(patterns)
    print(f"训练后网络: {hn}")

    # 3. 创建带噪声的测试模式
    print("\n2. 创建带噪声的测试模式...")
    # 给pattern1添加30%的噪声
    noise_level = 0.3
    noisy_pattern = pattern1.copy()
    n_noisy_bits = int(n_neurons * noise_level)
    noisy_indices = np.random.choice(range(n_neurons), size=n_noisy_bits, replace=False)
    noisy_pattern[noisy_indices] = 1 - noisy_pattern[noisy_indices]  # 翻转选定的位

    print(f"原始模式1: {pattern1}")
    print(f"带噪声模式: {noisy_pattern}")

    # 4. 使用异步更新恢复模式
    print("\n3. 使用异步更新恢复模式...")
    # 注意：update_async方法会自动将0/1转换为-1/1
    restored_pattern, history = hn.update_async(noisy_pattern, return_history=True)

    # 转换回0/1表示以便于显示
    restored_pattern_01 = (restored_pattern + 1) // 2
    print(f"恢复后的模式: {restored_pattern_01}")
    print(f"是否成功恢复: {np.array_equal(restored_pattern_01, pattern1)}")

    # 5. 计算和显示能量变化
    print("\n4. 计算能量变化...")
    # 转换历史记录回0/1表示
    history_01 = [(state + 1) // 2 for state in history]
    print(f"更新步数: {len(history) - 1}")

    # 计算初始噪声模式和最终恢复模式的能量
    initial_energy = hn.energy(noisy_pattern)
    final_energy = hn.energy(restored_pattern)
    print(f"初始能量: {initial_energy:.4f}")
    print(f"最终能量: {final_energy:.4f}")
    print(f"能量减少: {initial_energy - final_energy:.4f}")

    # 6. 检查和查找吸引子
    print("\n5. 检测吸引子...")
    # 检查原始训练模式是否为吸引子
    for i, pattern in enumerate(patterns):
        is_attr = hn.is_attractor(pattern)
        print(f"原始模式{i + 1}是吸引子: {is_attr}")

    # 查找网络的所有吸引子
    print("\n查找网络的所有吸引子...")
    attractors = hn.find_attractors(n_samples=20)
    print(f"找到 {len(attractors)} 个吸引子:")

    for i, attractor in enumerate(attractors):
        attractor_01 = (attractor + 1) // 2
        energy = hn.energy(attractor)
        print(f"吸引子{i + 1}: {attractor_01}, 能量: {energy:.4f}")

    # 7. 绘制能量景观
    print("\n6. 绘制能量变化图...")
    print("(请在图形界面查看能量变化图)")
    hn.energy_landscape(noisy_pattern, plot=True)

    # 8. 获取所有吸引子的能量并排序
    print("\n7. 所有吸引子的能量(按升序排序):")
    attractor_energies = hn.get_attractor_energies()
    for i, (attractor, energy) in enumerate(attractor_energies):
        attractor_01 = (attractor + 1) // 2
        print(f"吸引子{i + 1}: 能量={energy:.4f}, 状态={attractor_01}")

    print("\n示例演示完成！")
