from __future__ import annotations

import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QApplication,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PyQt5.QtGui import QFont

try:
    from .bm_sandbox_visualization import (
        BMConfig,
        BoltzmannMachine,
        SandboxRunner,
        SandboxVisualizer,
    )
except ImportError:  # pragma: no cover - fallback when executed as script
    from bm_sandbox_visualization import (  # type: ignore
        BMConfig,
        BoltzmannMachine,
        SandboxRunner,
        SandboxVisualizer,
    )


class BMGuiWindow(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Boltzmann Machine 沙箱可视化")
        self.resize(1200, 720)

        self.weights = np.array(
            [[0.0, 0.9, -0.7], [0.9, 0.0, 0.5], [-0.7, 0.5, 0.0]], dtype=np.float64
        )
        self.biases = np.array([-0.3, 0.25, 0.05], dtype=np.float64)
        self.visualizer = SandboxVisualizer(output_dir=Path(__file__).parent)

        self.latest_states: np.ndarray | None = None
        self.latest_energies: np.ndarray | None = None
        self.latest_config: BMConfig | None = None
        self.latest_distribution: List[Tuple[str, float]] | None = None
        self.latest_distribution_map: Dict[str, float] | None = None
        self.latest_top_state: str | None = None
        self.latest_top_prob: float | None = None

        self._build_ui()
        self.run_simulation()

    def _build_ui(self) -> None:
        root_layout = QVBoxLayout()
        self.setLayout(root_layout)

        control_group = QGroupBox("仿真参数设置")
        control_layout = QFormLayout()
        control_group.setLayout(control_layout)

        self.steps_spin = QSpinBox()
        self.steps_spin.setRange(10, 100000)
        self.steps_spin.setSingleStep(500)
        self.steps_spin.setValue(6000)

        self.burn_in_spin = QSpinBox()
        self.burn_in_spin.setRange(0, 99999)
        self.burn_in_spin.setSingleStep(100)
        self.burn_in_spin.setValue(800)

        self.beta_min_spin = QDoubleSpinBox()
        self.beta_min_spin.setDecimals(2)
        self.beta_min_spin.setRange(0.01, 5.0)
        self.beta_min_spin.setSingleStep(0.1)
        self.beta_min_spin.setValue(0.6)

        self.beta_max_spin = QDoubleSpinBox()
        self.beta_max_spin.setDecimals(2)
        self.beta_max_spin.setRange(0.01, 5.0)
        self.beta_max_spin.setSingleStep(0.1)
        self.beta_max_spin.setValue(1.4)

        self.initial_state_combo = QComboBox()
        default_state = (0, 1, 0)
        for bits in [(0, 0, 0), (0, 0, 1), (0, 1, 0), (0, 1, 1), (1, 0, 0), (1, 0, 1), (1, 1, 0), (1, 1, 1)]:
            label = "".join(str(bit) for bit in bits)
            self.initial_state_combo.addItem(label, bits)
            if bits == default_state:
                self.initial_state_combo.setCurrentText(label)

        control_layout.addRow("总迭代步数", self.steps_spin)
        control_layout.addRow("Burn-in 步数", self.burn_in_spin)
        control_layout.addRow("β 最小值", self.beta_min_spin)
        control_layout.addRow("β 最大值", self.beta_max_spin)
        control_layout.addRow("初始状态", self.initial_state_combo)

        button_row = QHBoxLayout()
        self.run_button = QPushButton("运行仿真")
        self.run_button.clicked.connect(self.run_simulation)
        self.export_button = QPushButton("保存当前结果")
        self.export_button.setEnabled(False)
        self.export_button.clicked.connect(self.export_results)
        button_row.addWidget(self.run_button)
        button_row.addWidget(self.export_button)

        self.status_label = QLabel("")
        self.status_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.status_label.setStyleSheet("color: #1f77b4; font-weight: 600;")

        plots_layout = QHBoxLayout()

        self.energy_canvas = FigureCanvas(Figure(figsize=(6, 4), tight_layout=True))
        self.energy_ax = self.energy_canvas.figure.add_subplot(111)
        plots_layout.addWidget(self.energy_canvas, stretch=1)

        self.distribution_canvas = FigureCanvas(Figure(figsize=(6, 4), tight_layout=True))
        self.distribution_ax = self.distribution_canvas.figure.add_subplot(111)
        plots_layout.addWidget(self.distribution_canvas, stretch=1)

        self.summary_label = QLabel()
        self.summary_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet("font-family: Consolas, 'Source Code Pro', monospace;")

        bottom_layout = QHBoxLayout()
        bottom_layout.addLayout(plots_layout, stretch=3)

        summary_group = QGroupBox("统计摘要")
        summary_layout = QVBoxLayout()
        summary_layout.addWidget(self.summary_label)
        summary_group.setLayout(summary_layout)
        bottom_layout.addWidget(summary_group, stretch=2)

        root_layout.addWidget(control_group)
        root_layout.addLayout(button_row)
        root_layout.addWidget(self.status_label)
        root_layout.addLayout(bottom_layout)

    def run_simulation(self) -> None:
        steps = self.steps_spin.value()
        burn_in = min(self.burn_in_spin.value(), steps - 1)
        if burn_in != self.burn_in_spin.value():
            self.burn_in_spin.blockSignals(True)
            self.burn_in_spin.setValue(burn_in)
            self.burn_in_spin.blockSignals(False)

        beta_min = self.beta_min_spin.value()
        beta_max = self.beta_max_spin.value()
        if beta_min > beta_max:
            beta_min, beta_max = beta_max, beta_min
            self.beta_min_spin.blockSignals(True)
            self.beta_max_spin.blockSignals(True)
            self.beta_min_spin.setValue(beta_min)
            self.beta_max_spin.setValue(beta_max)
            self.beta_min_spin.blockSignals(False)
            self.beta_max_spin.blockSignals(False)

        initial_state = tuple(int(bit) for bit in self.initial_state_combo.currentData())

        config = BMConfig(
            steps=steps,
            burn_in=burn_in,
            beta_min=beta_min,
            beta_max=beta_max,
            initial_state=initial_state,
        )

        bm = BoltzmannMachine(weights=self.weights, biases=self.biases)
        runner = SandboxRunner(bm=bm, config=config)
        states, energies, _ = runner.run()

        top_state, top_prob, distribution, distribution_map = self.visualizer.analyze_distribution(
            states=states, config=config
        )

        self.latest_states = states
        self.latest_energies = energies
        self.latest_config = config
        self.latest_distribution = distribution
        self.latest_distribution_map = distribution_map
        self.latest_top_state = top_state
        self.latest_top_prob = top_prob

        self._update_energy_plot(energies, config)
        self._update_distribution_plot(distribution)
        self._update_summary(config, top_state, top_prob, distribution)

        self.status_label.setText("仿真完成，可点击“保存当前结果”导出图片与摘要。")
        self.export_button.setEnabled(True)

    def export_results(self) -> None:
        if not all(
            [
                self.latest_config,
                self.latest_energies is not None,
                self.latest_distribution is not None,
                self.latest_distribution_map is not None,
                self.latest_top_state,
                self.latest_top_prob is not None,
            ]
        ):
            self.status_label.setText("尚无可导出的仿真结果，请先运行仿真。")
            return

        assert self.latest_config is not None
        assert self.latest_energies is not None
        assert self.latest_distribution is not None
        assert self.latest_distribution_map is not None
        assert self.latest_top_state is not None
        assert self.latest_top_prob is not None

        energy_path = self.visualizer.plot_energy(
            energies=self.latest_energies, config=self.latest_config
        )
        distribution_path = self.visualizer.plot_distribution(
            distribution=self.latest_distribution
        )
        summary_path = self.visualizer.export_summary(
            config=self.latest_config,
            top_state=self.latest_top_state,
            top_prob=self.latest_top_prob,
            distribution_map=self.latest_distribution_map,
            energies=self.latest_energies,
        )

        self.status_label.setText(
            f"结果已保存：{energy_path.name}、{distribution_path.name}、{summary_path.name}"
        )

    def _update_energy_plot(self, energies: np.ndarray, config: BMConfig) -> None:
        self.energy_ax.clear()
        iterations = np.arange(1, energies.size + 1)
        self.energy_ax.plot(iterations, energies, color="#1f77b4", linewidth=1.2)
        self.energy_ax.axvline(
            config.burn_in, color="#ff7f0e", linestyle="--", linewidth=1.0, label="Burn-in"
        )
        self.energy_ax.set_xlabel("迭代步")
        self.energy_ax.set_ylabel("能量")
        self.energy_ax.set_title("BM 能量轨迹")
        self.energy_ax.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
        self.energy_ax.legend(loc="upper right")
        self.energy_canvas.draw_idle()

    def _update_distribution_plot(self, distribution: List[Tuple[str, float]]) -> None:
        self.distribution_ax.clear()
        labels = [state for state, _ in distribution]
        probs = [prob for _, prob in distribution]
        x = np.arange(len(labels))
        self.distribution_ax.bar(x, probs, color="#2ca02c")
        self.distribution_ax.set_xticks(x)
        self.distribution_ax.set_xticklabels(labels)
        self.distribution_ax.set_xlabel("状态 (二进制)")
        self.distribution_ax.set_ylabel("概率")
        self.distribution_ax.set_ylim(0, max(probs) * 1.1 if probs else 1.0)
        self.distribution_ax.set_title("热平衡状态分布")
        self.distribution_ax.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
        self.distribution_canvas.draw_idle()

    def _update_summary(
        self,
        config: BMConfig,
        top_state: str,
        top_prob: float,
        distribution: List[Tuple[str, float]],
    ) -> None:
        burn_in_mean = float(np.mean(self.latest_energies[config.burn_in :])) if self.latest_energies is not None else float("nan")
        lines = [
            "BM 沙箱仿真摘要",
            f"总迭代步数: {config.steps}",
            f"Burn-in 步数: {config.burn_in}",
            f"β 范围: [{config.beta_min:.2f}, {config.beta_max:.2f}]",
            f"最可能状态: {top_state} (概率 {top_prob:.4f})",
            f"Burn-in 后能量均值: {burn_in_mean:.4f}",
            "",
            "状态概率：",
        ]
        for state, prob in distribution:
            lines.append(f"  {state}: {prob:.4f}")
        self.summary_label.setText("\n".join(lines))


def main() -> None:
    app = QApplication(sys.argv)
    app.setFont(QFont("Microsoft YaHei"))
    window = BMGuiWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


