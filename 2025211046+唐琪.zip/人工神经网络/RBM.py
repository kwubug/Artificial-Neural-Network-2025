import matplotlib
matplotlib.use('TkAgg')
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error


p = np.array([-1, 0, 1])
t = np.array([-0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336,
              -0.2013, -0.4344, -0.5000, -0.3939, -0.1647, 0.0988, 0.3072, 0.3960,
              0.3449, 0.1816, -0.0312, -0.2189, -0.3201])
X = np.tile(p.reshape(1, -1), (len(t), 1))
y = t

class RBFNetwork:
    def __init__(self, num_centers, sigma=1.0):
        self.num_centers = num_centers
        self.sigma = sigma
        self.centers = None
        self.weights = None

    def rbf(self, x, c):
        return np.exp(-np.linalg.norm(x - c, axis=1)**2 / (2 * self.sigma**2))

    def fit(self, X, y):
        idx = np.random.choice(len(X), self.num_centers, replace=False)
        self.centers = X[idx]
        rbf_output = np.array([self.rbf(self.centers, x) for x in X])
        self.weights = np.linalg.pinv(rbf_output) @ y

    def predict(self, X):
        rbf_output = np.array([self.rbf(self.centers, x) for x in X])
        return rbf_output @ self.weights


rbf_net = RBFNetwork(num_centers=8, sigma=0.5)
rbf_net.fit(X, y)
y_pred = rbf_net.predict(X)
mse = mean_squared_error(y, y_pred)
print(f"拟合均方误差MSE: {mse:.4f}")


plt.figure(figsize=(10, 6))
plt.plot(range(len(y)), y, label="原始目标曲线", color="blue", marker="o", linestyle="--")
plt.plot(range(len(y_pred)), y_pred, label="RBF拟合曲线", color="red", marker="s", linestyle="-")
plt.title("RBF神经网络曲线拟合效果", fontsize=12)
plt.xlabel("样本序号", fontsize=10)
plt.ylabel("输出值", fontsize=10)
plt.legend()
plt.grid(alpha=0.3)
plt.show()