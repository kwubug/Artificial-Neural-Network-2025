# Hopfield 神经网络实现 — 完整逻辑架构说明

## 📋 目录

1. [系统架构](#系统架构)
2. [核心逻辑流程](#核心逻辑流程)
3. [三层分离的详细说明](#三层分离的详细说明)
4. [关键算法详解](#关键算法详解)
5. [数据流向](#数据流向)

---

## 🏗️ 系统架构

整个 Hopfield 实现分为**三层**：

```
┌─────────────────────────────────────────────────┐
│           前端层（QML UI）                        │
│  Hopfield.qml - 用户交互界面                      │
│  - Canvas 显示神经元状态                          │
│  - 按钮控制算法运行                              │
│  - 图表显示能量曲线                              │
└─────────────────────┬───────────────────────────┘
                      │ PyQt Signal/Slot
                      ▼
┌─────────────────────────────────────────────────┐
│        桥接层（HopfieldBridge）                   │
│  hopfield_bridge.py - 前后端通信                  │
│  - 转换 QML 数据 ↔ Python 数据                    │
│  - 暴露 Qt 属性和 Slots 给 QML                    │
│  - 同步后端状态到前端显示                         │
└─────────────────────┬───────────────────────────┘
                      │ 直接调用
                      ▼
┌─────────────────────────────────────────────────┐
│        后端层（HopfieldAlgorithm）                │
│  hopfield_algorithm.py - 核心算法                │
│  - 权重矩阵计算（Hebb 学习）                      │
│  - 神经元更新（同步/异步）                        │
│  - 能量函数计算                                  │
│  - 收敛检测                                      │
└─────────────────────────────────────────────────┘
```

---

## 🔄 核心逻辑流程

### 用户操作流程

```
用户操作界面
    ↓
点击按钮（如 "Store Random Pattern"）
    ↓
触发 QML Slot → hopfieldBridge.store_pattern()
    ↓
Bridge 调用后端 → algorithm.store_pattern()
    ↓
后端计算权重矩阵更新
    ↓
Bridge 同步属性变化 → self._sync_state_from_backend()
    ↓
QML 收到属性更新信号（currentStateChanged 等）
    ↓
QML 重新绘制 Canvas 和更新显示
```

### 完整的一次检索流程

```
【第一步】用户存储模式
───────────────────
1. Store Random Pattern
2. 生成随机 ±1 向量 → Pattern
3. 使用 Hebb 规则 → W = Pattern ⊗ Pattern^T
4. 权重矩阵 W 保存到后端
5. UI 显示：Stored Patterns = 1 ✓

【第二步】用户创建带噪声的初始状态
────────────────────────────────
1. Create Noisy Pattern（选择 Pattern 0，噪声 50%）
2. 从存储的 Pattern 0 复制
3. 随机翻转 50% 的神经元（× -1）
4. set_initial_state(noisy_pattern)
5. UI 显示：Canvas 中混乱的蓝/橙方块，Similarity ≈ 50%

【第三步】用户逐步观察恢复过程
──────────────────────────
1. Single Step（5 次）
   每次执行：
   a) 选择一个神经元 i
   b) 计算 input_i = Σ(W_ij × x_j)
   c) 更新 x_i = sign(input_i)
   d) 重复直到更新完一个周期（异步）或全部更新（同步）
   
   观察现象：
   - Canvas 中蓝/橙方块逐步有序化
   - Similarity 逐步上升
   - Energy 逐步下降

【第四步】用户触发自动收敛
──────────────────────
1. Retrieve
2. 重复执行 Step，直到：
   a) 网络状态连续两次不变（收敛）
   b) 或达到最大迭代次数
3. 最终状态应该 ≈ 存储的 Pattern 0
4. UI 显示：Converged = Yes ✓，Similarity = 100%
```

---

## 🔧 三层分离的详细说明

### 第 1 层：后端算法（hopfield_algorithm.py）

**职责**：纯算法实现，完全独立于 UI

**核心数据结构**：

```python
class HopfieldAlgorithm:
    def __init__(self, num_neurons=100):
        self._num_neurons = 100          # 神经元数
        self._weights = 0 matrix          # 权重矩阵 100×100
        self._state = [0] * 100           # 当前神经元状态 ±1
        self._patterns = []               # 存储的所有模式
        self._energy = 0.0                # 当前能量值
        self._iteration = 0               # 当前迭代步数
        self._converged = False           # 是否已收敛
```

**关键方法**：

```python
# 学习阶段
store_pattern(pattern)
    → W = W + pattern ⊗ pattern^T
    → 权重矩阵更新，保存新的"记忆"

clear_patterns()
    → W = 0, state = 0
    → 重置所有学习内容

# 执行阶段
set_initial_state(state)
    → 设置初始状态（通常是噪声模式）
    → 准备开始检索

step(update_rule='async')
    → 执行一次神经元更新
    → 异步：更新一个神经元
    → 同步：同时更新所有神经元
    → 返回新的 state

retrieve(max_iterations=1000, update_rule='async')
    → 循环调用 step()
    → 直到收敛或达到迭代次数限制
    → 返回最终状态

# 信息提取
get_state_vector()
    → 返回当前 state [±1, ±1, ...]
    
get_state_history()
    → 返回历史状态变化
    → 用于绘制能量曲线
```

### 第 2 层：桥接层（hopfield_bridge.py）

**职责**：连接前端 QML 和后端 Algorithm

**架构**：

```python
class HopfieldBridge(Bridge):
    # Qt 属性 - 自动与 QML 同步
    current_state = BridgeProperty([])      # 当前网络状态
    energy = BridgeProperty(0.0)            # 当前能量
    iteration = BridgeProperty(0)           # 迭代次数
    converged = BridgeProperty(False)       # 是否收敛
    similarity = BridgeProperty(0.0)        # 与最近模式的相似度
    pattern_count = BridgeProperty(0)       # 存储的模式数
    state_history = BridgeProperty([])      # 历史状态
    
    def __init__(self):
        self._hopfield_algorithm = HopfieldAlgorithm()
        
    # 暴露给 QML 的 Slots
    @pyqtSlot(list)
    def store_pattern(self, pattern):
        # 调用后端存储
        self._hopfield_algorithm.store_pattern(pattern)
        # 同步属性到 QML
        self._sync_state_from_backend()
    
    @pyqtSlot(int, float)
    def create_noisy_pattern(self, pattern_index, noise_rate):
        # 从存储的模式创建噪声版本
        pattern = self._hopfield_algorithm._patterns[pattern_index]
        # 随机翻转噪声比例的元素
        pattern = pattern.copy()
        pattern[random_indices] *= -1
        # 设置为初始状态
        self.set_initial_state(pattern)
    
    @pyqtSlot(str)
    def step(self, update_rule):
        # 执行一步更新
        self._hopfield_algorithm.step(update_rule)
        # 同步所有属性
        self._sync_state_from_backend()
    
    @pyqtSlot(int, str)
    def retrieve(self, max_iterations, update_rule):
        # 完整检索
        self._hopfield_algorithm.retrieve(max_iterations, update_rule)
        # 同步属性
        self._sync_state_from_backend()
    
    def _sync_state_from_backend(self):
        # 从后端读取所有状态
        self.current_state = self._hopfield_algorithm.get_state_vector()
        self.energy = self._hopfield_algorithm._energy
        self.iteration = self._hopfield_algorithm._iteration
        self.converged = self._hopfield_algorithm._converged
        self.similarity = self._hopfield_algorithm._similarity
        # 这里的赋值会自动触发 QML 属性更新信号
```

**数据转换**：

```
QML 数据类型          ↔  Python 数据类型
─────────────────────    ──────────────
list [1, -1, 1, ...]  ↔  numpy.array
float 0.5             ↔  np.float64
int 100               ↔  python int
bool true             ↔  python bool
```

### 第 3 层：前端 UI（Hopfield.qml）

**职责**：用户交互和可视化

**主要组件**：

```qml
Page {
    name: 'Hopfield'
    
    // 与 Bridge 连接
    HopfieldBridge { id: hopfieldBridge }
    
    // 模式管理区
    GroupBox "Pattern Management" {
        Button "Store Random Pattern"
            → 调用 hopfieldBridge.generate_random_pattern()
            → 调用 hopfieldBridge.store_pattern()
        Button "Clear All"
            → 调用 hopfieldBridge.clear_patterns()
    }
    
    // 检索配置区
    GroupBox "Retrieval Configuration" {
        ComboBox "Select Pattern" → pattern_index
        Slider "Noise Level" → noise_rate [0.0 ~ 1.0]
        ComboBox "Update Rule" → 'async' 或 'sync'
        SpinBox "Max Iterations" → max_iter
    }
    
    // 控制按钮
    RowLayout "Control Buttons" {
        Button "Create Noisy Pattern"
            → hopfieldBridge.create_noisy_pattern(pattern_index, noise_rate)
        Button "Single Step"
            → hopfieldBridge.step(update_rule)
        Button "Retrieve"
            → hopfieldBridge.retrieve(max_iterations, update_rule)
    }
    
    // 网络状态显示
    GroupBox "Network State" {
        Labels 显示：energy, iteration, converged, similarity, status
    }
    
    // 神经元状态可视化
    Canvas "State Visualization" {
        onPaint: {
            for each neuron state[i]:
                if state[i] > 0: draw blue square
                else: draw orange square
        }
        
        Connections {
            target: hopfieldBridge
            onCurrent_stateChanged: requestPaint()  // 实时更新
        }
    }
    
    // 能量曲线图
    Canvas "Energy Curve" {
        显示能量随迭代次数的变化
        blue line: 历史能量轨迹
        orange dots: 历史数据点
        green dot: 当前状态
    }
}
```

---

## 🧠 关键算法详解

### 1. Hebb 学习规则（权重计算）

当你点击 "Store Random Pattern" 时：

```
输入：一个 100 维的随机模式
Pattern = [+1, -1, +1, +1, -1, ...]

计算：权重矩阵更新
ΔW = Pattern ⊗ Pattern^T

具体公式：
W_ij = Pattern_i × Pattern_j（对于每一对神经元 i, j）

例如：
Pattern = [+1, -1, +1]
     
W = [[+1×(+1), +1×(-1), +1×(+1)],      [[+1, -1, +1],
     [-1×(+1), -1×(-1), -1×(+1)],   =   [-1, +1, -1],
     [+1×(+1), +1×(-1), +1×(+1)]]       [+1, -1, +1]]

效果：权重矩阵"记住"了模式的特征
     对于模式中相同的神经元对（都是+1 或都是-1）→ 权重正值
     对于模式中相反的神经元对（一个+1，一个-1）→ 权重负值
```

### 2. 神经元更新规则

**异步更新**（每次更新一个神经元）：

```
for neuron i:
    input_i = Σ(W_ij × x_j) for all j ≠ i
    x_i_new = sign(input_i)
    
    if input_i > 0: x_i = +1
    if input_i < 0: x_i = -1
    if input_i = 0: x_i unchanged
```

**同步更新**（所有神经元同时更新）：

```
for all neurons i simultaneously:
    input_i = Σ(W_ij × x_j_old)  # 使用旧状态
    x_i_new = sign(input_i)

x = x_new  # 同时替换所有状态
```

### 3. 能量函数

Hopfield 能量函数度量网络的"稳定性"：

```
E = -0.5 × Σ Σ W_ij × x_i × x_j

性质：
- 每次更新后，E 不增加（单调非递增）
- E 最低 = 网络最稳定
- 收敛时 E 达到局部最小值
```

**能量的物理意义**：
- 能量低 → 网络稳定，神经元不再改变
- 能量高 → 网络不稳定，还在演化中
- 能量最低的状态 = 存储的模式（理想情况）

### 4. 相似度计算

用于评估当前状态与存储模式的匹配程度：

```
Similarity = (相同的神经元数) / (总神经元数)

例如：
存储模式：     [+1, -1, +1, +1, -1, ...]
当前状态：     [+1, +1, +1, +1, -1, ...]
               ✓  ✗  ✓  ✓  ✓
相似度 = 4/5 = 80%

100% 相似 = 完全恢复存储的模式
50% 相似 = 一半相同，一半相反
```

### 5. 收敛检测

当网络满足以下条件时认为已收敛：

```
连续两次迭代后，网络状态完全相同
即：x_t == x_{t-1}

或达到最大迭代次数限制
```

---

## 📡 数据流向

### 完整的数据流程图

```
【用户操作】
用户点击 "Store Random Pattern"
    ↓
【QML → Bridge】
Button.onClicked
    → hopfieldBridge.generate_random_pattern()  [返回 list]
    → hopfieldBridge.store_pattern(list)

【Bridge → Backend】
HopfieldBridge.store_pattern(list)
    → 转换 list → numpy.array
    → self._hopfield_algorithm.store_pattern(np.array)

【Backend 计算】
HopfieldAlgorithm.store_pattern(pattern)
    → W = W + pattern ⊗ pattern^T
    → self._patterns.append(pattern)
    → self._pattern_count += 1

【Bridge 同步】
self._sync_state_from_backend()
    → self.pattern_count = algorithm._pattern_count
    → (触发 Qt 信号 patternCountChanged)

【QML 更新】
Connections { 
    target: hopfieldBridge
    onPattern_countChanged: {
        label.text = hopfieldBridge.pattern_count  // 显示更新
    }
}

【UI 变化】
用户看到：Stored Patterns = 1
```

### 单个 Step 的完整数据流

```
【输入】
Update Rule: "Async"  （来自 ComboBox）

【QML → Bridge】
Button.onClicked
    → hopfieldBridge.step(updateRuleSelector.currentText.toLowerCase())
    → hopfieldBridge.step("async")

【Bridge → Backend】
HopfieldBridge.step("async")
    → self._hopfield_algorithm.step("async")

【Backend 执行】
HopfieldAlgorithm.step("async")
    1. 选择一个随机神经元 i
    2. input = Σ(W[i][j] × state[j])
    3. state[i] = sign(input)
    4. 计算新能量：E = -0.5 × Σ Σ W × x × x
    5. 计算相似度：sim = count(state == pattern) / num_neurons
    6. 检查收敛：converged = (state_old == state_new)
    7. iteration += 1

【Bridge 同步】
self._sync_state_from_backend()
    → self.current_state = numpy.array → list
    → self.energy = algorithm._energy
    → self.iteration = algorithm._iteration
    → self.similarity = algorithm._similarity
    → self.converged = algorithm._converged
    → (触发多个 Qt 信号)

【QML 响应】
Connections {
    onCurrent_stateChanged → stateCanvas.requestPaint()
    onEnergyChanged → energyCanvas.requestPaint()
    onIterationChanged → label_iteration.text 更新
    onSimilarityChanged → label_similarity.text 更新
}

【UI 变化】
- Canvas 中部分方块颜色改变
- Energy 值更新（通常下降）
- Iteration 计数增加
- Energy Curve 图表添加新的点
- Similarity 百分比更新
```

---

## 🎯 整个系统的核心逻辑总结

```
┌──────────────────────────────────────┐
│     用户交互（QML UI）               │
│  1. 点击"Store Random Pattern"     │
│  2. 点击"Create Noisy Pattern"      │
│  3. 点击"Single Step"或"Retrieve"  │
└──────────────────────────────────────┘
             ↓ (PyQt Signals)
┌──────────────────────────────────────┐
│   数据传递（HopfieldBridge）         │
│  1. 接收 QML 输入（列表、浮点数）  │
│  2. 调用后端算法                    │
│  3. 同步属性变化到 QML              │
└──────────────────────────────────────┘
             ↓ (直接调用)
┌──────────────────────────────────────┐
│   算法执行（HopfieldAlgorithm）     │
│  1. 权重矩阵管理（学习）            │
│  2. 神经元状态更新（演化）          │
│  3. 能量计算（评估）                │
│  4. 收敛检测（停止条件）            │
└──────────────────────────────────────┘
             ↓ (属性变化)
┌──────────────────────────────────────┐
│   UI 更新（QML Canvas）              │
│  1. 显示神经元状态（蓝/橙方块）    │
│  2. 绘制能量曲线                    │
│  3. 更新数字指标                    │
└──────────────────────────────────────┘
```

---

## 🧩 设计模式应用

### 1. **观察者模式（Observer Pattern）**
- 后端 Algorithm 是 Observable
- Bridge 观察 Algorithm 的状态变化
- Algorithm 状态改变 → Bridge 自动同步 → QML 自动更新

### 2. **适配器模式（Adapter Pattern）**
- Bridge 作为适配器
- 将 QML 的列表/浮点数 ↔ 后端的 numpy 数组

### 3. **MVC 架构（Model-View-Controller）**
- **Model**（后端）：HopfieldAlgorithm - 数据和逻辑
- **View**（前端）：Hopfield.qml - UI 显示
- **Controller**（桥接）：HopfieldBridge - 逻辑控制

### 4. **信号/槽机制（Qt Signals & Slots）**
- QML UI 触发事件（信号）→ Bridge 响应（槽）→ 调用后端

---

## ✨ 这个实现的优势

✅ **完全分离**：UI 不依赖算法实现，易于扩展或替换算法

✅ **实时交互**：每次状态改变立即反映在 UI 上

✅ **可视化**：Canvas 和图表清晰展示算法执行过程

✅ **灵活控制**：支持逐步执行（Single Step）或自动执行（Retrieve）

✅ **易于演示**：非常适合教学和展示神经网络概念

---

现在你理解整个系统的逻辑了吗？有任何不清楚的地方，我可以再详细解释！ 🎉
