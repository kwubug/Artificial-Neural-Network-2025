import math
import numpy as np
import random
from matplotlib import pyplot as plt

# -------------------------------
# 随机生成城市坐标
# -------------------------------
num_cities = 10
np.random.seed(42)
longtitudes = np.random.uniform(0, 100, num_cities)
dimensionalitys = np.random.uniform(0, 100, num_cities)

# -------------------------------
# 构建距离矩阵
# -------------------------------
d = []
for i in range(num_cities):
    row = []
    for j in range(num_cities):
        x1 = longtitudes[i]
        y1 = dimensionalitys[i]
        x2 = longtitudes[j]
        y2 = dimensionalitys[j]
        dist = math.sqrt((x1-x2)**2 + (y1-y2)**2)
        row.append(dist)
    d.append(row)

# -------------------------------
# 初始路径
# -------------------------------
path = [0]
path1 = np.random.permutation(num_cities-1)+1
path.extend(path1)

current_length = sum(d[path[i]][path[i+1]] for i in range(num_cities-1))

# -------------------------------
# 模拟退火参数
# -------------------------------
T = 1000
T_min = 1e-3
alpha = 0.995
L = 50  # 每个温度循环次数
update_interval = 500  # 每500步更新一次动画

# -------------------------------
# 可视化初始化
# -------------------------------
plt.ion()
fig, ax = plt.subplots(figsize=(8,6))

def draw_path(path, length, step):
    ax.clear()
    xx = [longtitudes[i] for i in path] + [longtitudes[path[0]]]
    yy = [dimensionalitys[i] for i in path] + [dimensionalitys[path[0]]]
    ax.plot(xx, yy, 'b-o')
    for idx, city in enumerate(path):
        ax.text(longtitudes[city]+0.5, dimensionalitys[city]+0.5, str(city))
    ax.set_title(f"TSP Simulated Annealing - Step {step}, Length: {length:.2f}")
    ax.set_xlim(-5, 105)
    ax.set_ylim(-5, 105)
    ax.grid(True)
    plt.pause(0.01)

draw_path(path, current_length, 0)

# -------------------------------
# 模拟退火过程
# -------------------------------
step_count = 0
while T > T_min:
    for _ in range(L):
        a, b = sorted(random.sample(range(1, num_cities), 2))
        new_path = path[:]
        new_path[a:b+1] = new_path[a:b+1][::-1]
        new_length = sum(d[new_path[i]][new_path[i+1]] for i in range(num_cities-1))
        df = new_length - current_length

        if df < 0 or math.exp(-df/T) > random.random():
            path = new_path
            current_length = new_length

        step_count += 1
        if step_count % update_interval == 0:
            draw_path(path, current_length, step_count)

    T *= alpha

plt.ioff()
draw_path(path, current_length, step_count)
plt.show()

print("Final path:", path)
print("Final length:", current_length)
