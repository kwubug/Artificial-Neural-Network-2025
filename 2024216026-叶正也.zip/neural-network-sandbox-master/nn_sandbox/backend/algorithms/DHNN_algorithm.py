import collections
import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid

class DHNNAlgorithm(PredictiveAlgorithm):
    """Dynamic Hopfield Neural Network (DHNN) with Asynchronous Update and Attractor Energy."""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, network_shape=None):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight

        # The network shape is a single-layer DHNN (n, n) where n is the number of neurons
        self.network_shape = network_shape if network_shape else (5,)  # Single-layer

        # For momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _initialize_neurons(self):
        """ Build the neuron network for DHNN (single layer, self-recurrent). """
        self._neurons = tuple((Perceptron(sigmoid),) * size
                              for size in list(self.network_shape))

    def _iterate(self):
        # Asynchronous update: iterate over each neuron in the network
        for idx, layer in enumerate(self._neurons):
            for neuron in layer:
                self._update_neuron(neuron)

    def _update_neuron(self, neuron):
        """ Perform asynchronous update for a single neuron. """
        # Calculate the input sum for this neuron (including self-recurrent feedback)
        input_sum = np.dot(neuron.synaptic_weight, neuron.data)
        # Update the neuron's data based on the activation function
        neuron.data[1:] = sigmoid(input_sum)

    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron in the network. """
        deltas = {}
        deltas[self._neurons[-1][0]] = (expect - result) * result * (1 - result)

        for layer_idx, layer in reversed(tuple(enumerate(self._neurons[:-1]))):
            for neuron_idx, neuron in enumerate(layer):
                deltas[neuron] = (
                    sum(deltas[n] * n.synaptic_weight[neuron_idx] for n in self._neurons[layer_idx + 1])
                    * neuron.result
                    * (1 - neuron.result)
                )
        return deltas

    def _adjust_synaptic_weights(self, deltas):
        """ Adjust synaptic weights based on the deltas. """
        for neuron in deltas:
            self._synaptic_weight_diff[neuron] = (
                self._synaptic_weight_diff[neuron] * self._momentum_weight
                + self.current_learning_rate * deltas[neuron] * neuron.data
            )
            neuron.synaptic_weight += self._synaptic_weight_diff[neuron]

    def _correct_rate(self, dataset):
        """ Calculate the correct rate of the network on a given dataset. """
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < self._neurons[-1][0].result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """ Normalize the expected output. """
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))

    def _feed_forward(self, data):
        """ Forward pass for DHNN. """
        results = [None]
        for idx, layer in enumerate(self._neurons):
            if idx == 0:
                results = get_layer_results(layer, data)
                continue
            results = get_layer_results(layer, results)
        return results[0]

    def calculate_attractor_energy(self):
        """ Calculate the attractor energy of the current state. """
        energy = 0
        for layer in self._neurons:
            for neuron in layer:
                energy -= np.dot(neuron.synaptic_weight, neuron.data) * neuron.data[1]  # Energy function
        return energy

def get_layer_results(layer, data):
    """ Calculate the output of each layer. """
    for neuron in layer:
        neuron.data = data
    return np.fromiter((neuron.result for neuron in layer), dtype=float)