# Neural Network Sandbox

一个神经网络算法可视化工具集，支持多种神经网络和优化算法的实时可视化。

## 功能特性

* 后端算法与前端UI完全分离，通过`setContextProperty()`和[`BridgeProperty`](./nn_sandbox/bridges/bridge.py)实现
* 使用Qt Chart实现动态QML图表
* 后端变量变化时自动更新UI
* 模块化的UI组件
* 支持多种神经网络算法和优化算法

## 支持的算法

### 神经网络算法
- 感知机 (Perceptron)
- 多层感知机 (MLP)
- 径向基函数网络 (RBFN)
- 自组织映射 (SOM)
- BP神经网络 (BP Network)
- Hopfield网络
- 玻尔兹曼机 (Boltzmann Machine)

### 优化算法
- 最速下降法 (Steepest Descent)
- 牛顿法 (Newton's Method)
- 共轭梯度法 (Conjugate Gradient)
- 最小二乘法 (OLS)

### 其他算法
- 旅行商问题 (TSP)

## 环境要求

- **Python**: 3.7 或更高版本（推荐 3.8+）
- **操作系统**: Windows / Linux / macOS

## 安装步骤

### 方法一：使用虚拟环境（推荐）

#### Windows系统：

1. **克隆或下载项目**
   ```bash
   cd neural-network-sandbox-master
   ```

2. **创建虚拟环境**
   ```bash
   python -m venv venv
   ```

3. **激活虚拟环境**
   ```bash
   venv\Scripts\activate
   ```

4. **升级pip（可选但推荐）**
   ```bash
   python -m pip install --upgrade pip
   ```

5. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

6. **运行程序**
   ```bash
   python main.py
   ```

#### Linux/macOS系统：

1. **克隆或下载项目**
   ```bash
   cd neural-network-sandbox-master
   ```

2. **创建虚拟环境**
   ```bash
   python3 -m venv venv
   ```

3. **激活虚拟环境**
   ```bash
   source venv/bin/activate
   ```

4. **升级pip（可选但推荐）**
   ```bash
   python -m pip install --upgrade pip
   ```

5. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

6. **运行程序**
   ```bash
   python main.py
   ```

### 方法二：直接安装（不推荐）

如果不想使用虚拟环境，可以直接安装：

```bash
pip install -r requirements.txt
python main.py
```

**注意**: 直接安装可能会与系统其他Python包产生冲突，强烈建议使用虚拟环境。

## 依赖说明

项目依赖以下Python包（已包含在`requirements.txt`中）：

- **numpy** (>=1.16.4, <2.0.0): 数值计算库
- **PyQt5** (>=5.13.0): GUI框架和QML支持
- **PyQtChart** (>=5.13.0): 图表组件

所有其他依赖（如`threading`, `time`, `json`等）都是Python标准库，无需额外安装。

## 使用说明

1. 启动程序后，界面会显示多个算法标签页
2. 选择要测试的算法（如BP神经网络、梯度下降等）
3. 设置算法参数：
   - 数据集选择
   - 学习率、迭代次数等超参数
   - 网络结构（对于神经网络算法）
4. 点击"开始"按钮运行算法
5. 观察实时可视化结果：
   - 数据分布图
   - 训练过程曲线
   - 算法收敛情况

## 项目结构

```
neural-network-sandbox-master/
├── main.py                 # 程序入口
├── requirements.txt        # 依赖列表
├── README.md              # 说明文档
└── nn_sandbox/
    ├── backend/           # 后端算法实现
    │   ├── algorithms/   # 各种算法
    │   │   ├── base_algorithm.py
    │   │   ├── perceptron_algorithm.py
    │   │   ├── mlp_algorithm.py
    │   │   ├── BPnetwork_algorithm.py
    │   │   ├── gradient_descent_algorithm.py
    │   │   └── ...
    │   ├── neurons/      # 神经元实现
    │   └── utils.py      # 工具函数
    ├── bridges/          # 前后端桥接
    │   ├── bridge.py     # Bridge基类
    │   ├── observer.py   # 观察者模式
    │   └── *_bridge.py   # 各算法的Bridge
    ├── frontend/          # 前端QML界面
    │   ├── main.qml      # 主界面
    │   └── components/   # UI组件
    │       ├── dashboards/  # 各算法的仪表盘
    │       ├── DataChart.qml
    │       └── RateChart.qml
    └── assets/            # 资源文件
        └── data/          # 数据集文件
```

## 架构说明

项目采用前后端分离的架构：

1. **后端算法层** (`nn_sandbox/backend/algorithms/`): 
   - 实现各种神经网络和优化算法
   - 完全独立于UI，可以单独测试

2. **桥接层** (`nn_sandbox/bridges/`): 
   - 使用`BridgeProperty`和`Observable`模式连接后端和前端
   - 当后端属性变化时，自动通知前端更新

3. **前端UI层** (`nn_sandbox/frontend/`): 
   - 使用QML实现用户界面
   - 支持实时数据可视化

## 常见问题

### Q: 程序无法启动，提示找不到模块？

**A:** 请确保：
1. 已正确安装所有依赖：`pip install -r requirements.txt`
2. Python版本 >= 3.7
3. 已激活虚拟环境（如果使用虚拟环境）
4. 在项目根目录运行`python main.py`

### Q: 图表不显示或界面空白？

**A:** 请确保：
1. 已安装`PyQtChart`：`pip install PyQtChart`
2. PyQt5和PyQtChart版本兼容
3. 系统支持Qt5（Windows通常没问题，Linux可能需要安装Qt5库）

### Q: 在Linux上无法加载QML Chart库？

**A:** 这是已知问题，程序使用`QApplication`而不是`QGuiApplication`来解决此问题。如果仍有问题，可能需要安装系统级的Qt5库：
```bash
# Ubuntu/Debian
sudo apt-get install python3-pyqt5 python3-pyqt5.qtchart

# CentOS/RHEL
sudo yum install python3-qt5
```

### Q: 虚拟环境激活后提示找不到python命令？

**A:** 
- Windows: 使用`python`而不是`python3`
- Linux/macOS: 确保使用`python3`命令，或创建虚拟环境时指定：`python3 -m venv venv`

### Q: 安装依赖时速度很慢？

**A:** 可以使用国内镜像源加速：
```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 开发说明

### 添加新算法

1. 在`nn_sandbox/backend/algorithms/`中实现算法类
2. 在`nn_sandbox/bridges/`中创建对应的Bridge类
3. 在`nn_sandbox/frontend/components/dashboards/`中创建QML界面
4. 在`main.py`中注册Bridge
5. 在`nn_sandbox/frontend/main.qml`中添加标签页

## 许可证

请查看LICENSE文件了解详情。
