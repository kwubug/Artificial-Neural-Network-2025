import numpy as np

def sgn(x):
    return np.where(x >= 0, 1.0, -1.0)

def bipolar_continuous(x):

    return np.tanh(x)

def bipolar_continuous_deriv(y):

    return 1.0 - y**2

activation_functions = {
    "sgn": (sgn, None),
    "bipolar": (bipolar_continuous, bipolar_continuous_deriv),
}

def hebbian(w, x, y, d, lr):        return lr * y * x
def discrete(w, x, y, d, lr):       return lr * (d - y) * x
def continuous(w, x, y, d, lr, deriv=None):
    return lr * (d - y) * (deriv(y) if deriv is not None else 1) * x
def lms(w, x, y, d, lr):            return lr * (d - y) * x
def correlation(w, x, y, d, lr):    return lr * d * x
def wta(w, x, y, d, lr):
    idx = np.argmax(np.abs(x))
    delta = np.zeros_like(w)
    delta[idx] = lr * (x[idx] - w[idx])
    return delta
def alien(w, x, y, d, lr):          return lr * (d - y) * np.sign(x) * (x**2)

learning_rules = {
    "hebbian": hebbian,
    "perception": discrete,
    "continuous": continuous,
    "lms": lms,
    "correlation": correlation,
    "wta": wta,
    "outstar": alien,
}

# ====================== 用户输入训练样本 ======================
def input_dataset():

    X, D = [], []
    while True:
        line = input("样本: ").strip()
        if not line:
            break
        try:
            nums = list(map(float, line.split()))
            if len(nums) != 7:
                print("❌ 请确保每行有6个输入值 + 1个输出值！")
                continue
            X.append(nums[:6])
            D.append(nums[6])
        except ValueError:
            print("❌ 输入格式错误，请重新输入！")
    return np.array(X), np.array(D)

# ====================== 训练函数 ======================
def train(X, D, rule_name="discrete", act_name="bipolar", lr=0.1, epochs=3):
    n_samples, n_inputs = X.shape
    assert n_inputs == 6, "输入维度必须为6"

    w = np.random.randn(n_inputs) * 0.1
    f, f_deriv = activation_functions[act_name]
    rule = learning_rules[rule_name]

    print(f"\n")
    print(f"学习规则: {rule_name}")
    print(f"激活函数: {act_name}")
    print(f"学习率: {lr}\n")

    for epoch in range(epochs):
        print(f"--- Epoch {epoch + 1}/{epochs} ---")
        for i in range(n_samples):
            x, d = X[i], D[i]
            net = np.dot(w, x)
            y = f(net)
            if rule_name == "continuous":
                dw = rule(w, x, y, d, lr, deriv=f_deriv)
            else:
                dw = rule(w, x, y, d, lr)
            w_new = w + dw

            print(f"样本 {i}: net={net:.4f}, y={y:.4f}, d={d}")
            print(f"  Δw={np.round(dw,4)}")
            print(f"  w_before={np.round(w,4)}")
            print(f"  w_after ={np.round(w_new,4)}\n")

            w = w_new
    print(f"最终权值: {np.round(w,4)}")
    print("=== 训练结束 ===")
    return w

# ====================== 主程序 ======================
if __name__ == "__main__":
    print("学习规则：", list(learning_rules.keys()))
    print("变换函数：", list(activation_functions.keys()))

    rule = input("学习规则: ").strip()
    act = input("变换函数: ").strip()
    lr = float(input("学习率: ").strip())
    epochs = int(input("训练轮数: ").strip())

    X, D = input_dataset()
    train(X, D, rule_name=rule, act_name=act, lr=lr, epochs=epochs)
