import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12

import 'components'
import 'components/dashboards'

ApplicationWindow {
    id: window
    visible: true
    title: 'Neuron Network Sandbox'
    
    Pane {
        id: body
        anchors.fill: parent
        NoteBook {
            Perceptron {}
            Mlp {}
            Rbfn {}
            Som {}
            Tsp {}
        }
    }
    
    Component.onCompleted: () => {
        width = minimumWidth = body.implicitWidth
        height = minimumHeight = body.implicitHeight
    }
}