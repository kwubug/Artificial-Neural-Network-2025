import time
import PyQt5.QtCore
import numpy as np

from nn_sandbox.backend.algorithms import GdAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class GdBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.02)

    # Optimization settings
    method = BridgeProperty('sgd')            # 'sgd' | 'newton' | 'cg'
    learning_rate = BridgeProperty(0.05)
    total_epoches = BridgeProperty(200)
    function = BridgeProperty('rosenbrock')   # 'rosenbrock' | 'quadratic'
    start_x = BridgeProperty(-1.8)
    start_y = BridgeProperty(2.0)
    cg_restart_interval = BridgeProperty(50)
    newton_damping = BridgeProperty(1e-3)

    # Ranges to draw surface in QML
    x_min = BridgeProperty(-2.5)
    x_max = BridgeProperty(2.5)
    y_min = BridgeProperty(-1.5)
    y_max = BridgeProperty(3.0)

    # Live data
    current_iterations = BridgeProperty(0)
    current_point = BridgeProperty([])   # [x, y, z] (z can be filled on QML side)
    path_points = BridgeProperty([])     # [[x, y], ...]
    current_value = BridgeProperty(0.0)
    gradient_norm = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.gd_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_gd(self):
        if self.gd_algorithm and not self.has_finished:
            return
        self.gd_algorithm = ObservableGdAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=[],
            total_epoches=int(self.total_epoches),
            method=self.method,
            learning_rate=float(self.learning_rate),
            start_point=(float(self.start_x), float(self.start_y)),
            function=self.function,
            cg_restart_interval=int(self.cg_restart_interval),
            newton_damping=float(self.newton_damping),
        )
        self.gd_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_gd(self):
        if self.gd_algorithm:
            self.gd_algorithm.stop()


class ObservableGdAlgorithm(Observable, GdAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        GdAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
        elif name in ('value', 'grad_norm'):
            # map algorithm attrs to bridge property names
            pass

    def run(self):
        self.notify('has_finished', False)
        super().run()
        # final notify
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        # notify state after each iteration
        p = self.point
        self.notify('current_iterations', self.current_iterations)
        self.notify('current_point', [float(p[0]), float(p[1])])
        self.notify('path_points', self.path.tolist())
        self.notify('current_value', float(self.value))
        self.notify('gradient_norm', float(self.grad_norm))
        time.sleep(self.ui_refresh_interval)

