import numpy as np
import matplotlib.pyplot as plt

# 1. 生成训练数据
P = 100
x = np.random.uniform(-4, 4, P)  # Input samples: uniformly distributed in [-4,4]
e = np.random.normal(0, 0.1, P)  # Noise: mean 0, standard deviation 0.1
F = 1.1 * (1 - x + 2 * x ** 2) * np.exp(-x ** 2 / 2)
y = F + e  # Actual output (with noise)

# 2. Initialize RBF network parameters
M = 10
w = np.random.uniform(-0.1, 0.1, M)
c = np.random.uniform(-4.0, 4.0, M)
sigma = np.random.uniform(0.1, 0.3, M)
eta = 0.001
target_error = 0.9
max_iter = 5000
iter_count = 0
error_history = []

# 3. Gradient descent training loop
while iter_count < max_iter:
    total_error = 0
    # Update parameters for each sample
    for p in range(P):
        # Forward propagation: calculate hidden layer activation and output
        phi = np.exp(-(x[p] - c) ** 2 / (2 * sigma ** 2))
        y_hat = np.sum(w * phi)
        e_p = y[p] - y_hat
        total_error += 0.5 * e_p ** 2

        # Backward propagation: update w, c, sigma
        for j in range(M):
            # Update weight w[j]
            w[j] += eta * e_p * phi[j]
            # Update center c[j]
            delta_c = eta * e_p * w[j] * phi[j] * (x[p] - c[j]) / (sigma[j] ** 2)
            c[j] += delta_c
            # Update width sigma[j]
            delta_sigma = eta * e_p * w[j] * phi[j] * (x[p] - c[j]) ** 2 / (sigma[j] ** 3)
            sigma[j] += delta_sigma

    error_history.append(total_error)
    if total_error <= target_error:
        print(f"Target error reached, number of iterations: {iter_count}")
        break
    iter_count += 1

# 4. Result visualization (修正维度不匹配问题)
plt.figure(figsize=(10, 6))
plt.subplot(2, 1, 1)
plt.plot(x, F, 'b.', label='True F(x)')
plt.plot(x, y, 'r.', label='Training Data (with noise)')

# 计算最终预测值（使用矩阵乘法修正维度问题）
phi_all = np.array([np.exp(-(x - c[j]) ** 2 / (2 * sigma[j] ** 2)) for j in range(M)])  # 形状 (10, 100)
y_hat_final = np.dot(w, phi_all)  # 用矩阵乘法替代元素乘法，形状 (100,)

plt.plot(x, y_hat_final, 'g.', label='RBF Prediction')
plt.legend()
plt.title('RBF Network Approximation of F(x)')

plt.subplot(2, 1, 2)
plt.plot(error_history)
plt.xlabel('Iteration')
plt.ylabel('Mean Squared Error')
plt.title('Training Error History')
plt.tight_layout()
plt.show()