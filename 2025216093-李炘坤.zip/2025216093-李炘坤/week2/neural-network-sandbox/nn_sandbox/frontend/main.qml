import QtQuick 2.12
import QtQuick.Controls 2.12
import QtQuick.Layouts 1.12
import QtCharts 2.3

import 'components'
import 'components/dashboards'

ApplicationWindow {
    id: window
    visible: true
    title: "Neuron Network Sandbox"  // 确保这里有 title 属性并赋值

    Pane {
        id: body
        anchors.fill: parent

        // NoteBook 用于展示不同神经网络模型
        NoteBook {
            id: notebook
            Perceptron {}
            Mlp {}
            Rbfn {}
            Som {}
            
            // 三层前馈神经网络页面
            Page {
                // title: "三层前馈神经网络 (FFNN)"

                // 输入训练数据区域
                ColumnLayout {
                    spacing: 10

                    // 输入层大小
                    TextField {
                        id: inputField
                        placeholderText: "请输入输入层大小"
                        width: 200
                        Layout.alignment: Qt.AlignHCenter
                    }

                    // 隐藏层大小
                    TextField {
                        id: hiddenField
                        placeholderText: "请输入隐藏层大小"
                        width: 200
                        Layout.alignment: Qt.AlignHCenter
                    }

                    // 输出层大小
                    TextField {
                        id: outputField
                        placeholderText: "请输入输出层大小"
                        width: 200
                        Layout.alignment: Qt.AlignHCenter
                    }

                    // 训练轮数
                    TextField {
                        id: epochsField
                        placeholderText: "请输入训练轮数 (epochs)"
                        width: 200
                        Layout.alignment: Qt.AlignHCenter
                    }

                    // 开始训练按钮
                    Button {
                        text: "训练三层前馈神经网络"
                        onClicked: {
                            var inputSize = parseInt(inputField.text)
                            var hiddenSize = parseInt(hiddenField.text)
                            var outputSize = parseInt(outputField.text)
                            var epochs = parseInt(epochsField.text)

                            console.log("输入层大小: " + inputSize)
                            console.log("隐藏层大小: " + hiddenSize)
                            console.log("输出层大小: " + outputSize)
                            console.log("训练轮数: " + epochs)

                            if (isNaN(inputSize) || isNaN(hiddenSize) || isNaN(outputSize) || isNaN(epochs)) {
                                console.log("请输入有效的数字")
                                return
                            }

                            // 使用桥接对象训练三层前馈神经网络
                            console.log("训练三层前馈神经网络")
                            threeLayerFFNNBridge.create_model(inputSize, hiddenSize, outputSize, 0.1)
                            threeLayerFFNNBridge.train_model(epochs)
                            statusText.text = "训练中..."
                        }
                    }

                    // 显示训练状态
                    Text {
                        id: statusText
                        text: "训练状态：等待开始"
                        color: "green"
                        font.pixelSize: 16
                    }
                    
                    // 添加分割线
                    Rectangle {
                        height: 1
                        color: "lightgray"
                        Layout.fillWidth: true
                    }
                    
                    // 图表标题
                    Text {
                        text: "训练数据可视化"
                        font.pixelSize: 16
                        font.bold: true
                        Layout.alignment: Qt.AlignHCenter
                    }
                    
                    // 数据图表
                    DataChart {
                        id: dataChart
                        Layout.fillWidth: true
                        Layout.minimumHeight: 300
                        Layout.maximumHeight: 400
                    }
                }
            }
        }
    }

    // 确保应用窗口根据内容大小进行自适应
    Component.onCompleted: {
        width = minimumWidth = body.implicitWidth
        height = minimumHeight = body.implicitHeight
    }

    // 与后端桥接对象连接，监听训练完成的信号
    Connections {
        target: threeLayerFFNNBridge
        onTrainingDone: {
            console.log("训练完成信号已接收")
            statusText.text = "训练完成！"
            console.log("训练已完成，准备显示图表...")
            
            // 获取训练数据并显示在图表上
            var trainingData = threeLayerFFNNBridge.get_training_data()
            if (trainingData && trainingData.length > 0) {
                console.log("显示训练数据，数据点数量: " + trainingData.length)
                dataChart.updateDataset(trainingData)
            } else {
                console.log("没有可用的训练数据")
            }
        }
    }
}