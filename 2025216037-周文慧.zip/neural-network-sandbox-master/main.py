import os
import sys

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets

from nn_sandbox.bridges import (
    PerceptronBridge, MlpBridge, BpBridge, RbfnBridge, 
    SomBridge, OptimizationBridge, Som2Bridge, OlsBridge, 
    HopfieldBridge, BoltzmannMachineBridge, CHNNTSPBridge  
)
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    app = PyQt5.QtWidgets.QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'bpBridge': BpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'optimizationBridge': OptimizationBridge(),
        'som2Bridge': Som2Bridge(),
        'olsBridge': OlsBridge(),
        'hopfieldBridge': HopfieldBridge(),
        'bmBridge': BoltzmannMachineBridge(),
        'chnnTspBridge': CHNNTSPBridge()  
    }
    
    for name in bridges:
        # 这些不需要数据集
        if name not in ['optimizationBridge', 'hopfieldBridge', 'bmBridge', 'chnnTspBridge']:
            bridges[name].dataset_dict = nn_sandbox.backend.utils.read_data()
        engine.rootContext().setContextProperty(name, bridges[name])

    engine.load('./nn_sandbox/frontend/main.qml')
    if not engine.rootObjects():
        sys.exit(-1)
    
    # 定义清理函数：停止所有正在运行的算法
    def cleanup_bridges():
        """清理所有bridge，停止正在运行的算法"""
        cleanup_methods = {
            'chnnTspBridge': ('stop_algorithm', 'chnn_algorithm'),
            'som2Bridge': ('stop_som2_algorithm', 'som2_algorithm'),
            'bmBridge': ('stop_algorithm', 'bm_algorithm'),
            'hopfieldBridge': ('stop_algorithm', 'hopfield_algorithm'),
            'olsBridge': ('stop_fitting', None),  # OLS使用定时器，不需要算法对象检查
            'optimizationBridge': ('stop_optimization', 'optimization_algorithm'),
            'bpBridge': ('stop_bp_algorithm', 'bp_algorithm'),
            'rbfnBridge': ('stop_rbfn_algorithm', 'rbfn_algorithm'),
            'perceptronBridge': ('stop_perceptron_algorithm', 'perceptron_algorithm'),
            'mlpBridge': ('stop_mlp_algorithm', 'mlp_algorithm'),
            'somBridge': ('stop_som_algorithm', 'som_algorithm'),
        }
        
        for name, (method_name, algorithm_attr) in cleanup_methods.items():
            if name in bridges:
                bridge = bridges[name]
                if hasattr(bridge, method_name):
                    if algorithm_attr is not None:
                        if not hasattr(bridge, algorithm_attr) or getattr(bridge, algorithm_attr) is None:
                            continue
                    
                    try:
                        method = getattr(bridge, method_name)
                        method()
                    except (AttributeError, TypeError):
                        pass
                    except Exception:
                        pass
        
        # 等待所有线程完成
        import time
        time.sleep(0.3)

    app.aboutToQuit.connect(cleanup_bridges)

    exit_code = app.exec_()
    sys.exit(exit_code)