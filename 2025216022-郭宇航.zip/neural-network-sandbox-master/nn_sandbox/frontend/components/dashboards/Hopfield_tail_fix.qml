                
                        // ±1 对应不同颜色
                        ctx.fillStyle = state[i] > 0 ? '#0066FF' : '#FF6600'
                        ctx.fillRect(x + 2, y + 2, neuronSize - 4, neuronSize - 4)
                        
                        // 边框
                        ctx.strokeStyle = '#999999'
                        ctx.lineWidth = 1
                        ctx.strokeRect(x, y, neuronSize, neuronSize)
                    }
                }
            }
        }
    }
}
