import os
import sys

import PyQt5.QtQml
import PyQt5.QtCore
import PyQt5.QtWidgets

from nn_sandbox.bridges import PerceptronBridge, MlpBridge, RbfnBridge, SomBridge, BpBridge, OptimizationBridge, BmBridge, OlsBridge, HopfieldBridge, HopfieldTSPBridge
import nn_sandbox.backend.utils

if __name__ == '__main__':
    os.environ['QT_QUICK_CONTROLS_STYLE'] = 'Default'

    # XXX: Why I Have To Use QApplication instead of QGuiApplication? It seams
    # QGuiApplication cannot load QML Chart libs!
    app = PyQt5.QtWidgets.QApplication(sys.argv)
    engine = PyQt5.QtQml.QQmlApplicationEngine()

    # 确保在线OLS示例数据（若本地无则下载转换）
    try:
        nn_sandbox.backend.utils.ensure_ols_online_datasets()
    except Exception:
        # 静默失败，不阻断应用启动
        pass

    bridges = {
        'perceptronBridge': PerceptronBridge(),
        'mlpBridge': MlpBridge(),
        'rbfnBridge': RbfnBridge(),
        'somBridge': SomBridge(),
        'bpBridge': BpBridge(),
        'optimizationBridge': OptimizationBridge(),
        'bmBridge': BmBridge(),
        'olsBridge': OlsBridge(),
        'hopfieldBridge': HopfieldBridge(),
        'hopfieldTSPBridge': HopfieldTSPBridge()
    }
    for name in bridges:
        bridges[name].dataset_dict = nn_sandbox.backend.utils.read_data()
        engine.rootContext().setContextProperty(name, bridges[name])

    engine.load('./nn_sandbox/frontend/main.qml')
    if not engine.rootObjects():
        sys.exit(-1)
    sys.exit(app.exec_())
