import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from matplotlib.ticker import AutoMinorLocator

# ==========================
# 中文显示设置
# ==========================
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False


class BoltzmannMachine:
    def __init__(self, num_neurons=3):
        self.num_neurons = num_neurons
        # 对称随机权重（无自连接）
        self.weights = np.random.uniform(-1, 1, (num_neurons, num_neurons))
        self.weights = (self.weights + self.weights.T) / 2
        np.fill_diagonal(self.weights, 0)

        # 偏置与状态初始化
        self.biases = np.random.uniform(-0.5, 0.5, num_neurons)
        self.states = np.random.choice([-1, 1], size=num_neurons)

        self.energy_history = []
        self.state_history = []

    def energy(self, states=None):
        """计算系统能量"""
        states = self.states if states is None else states
        return -0.5 * np.dot(states.T, np.dot(self.weights, states)) - np.dot(self.biases, states)

    def update_neuron(self, idx, T=1.0):
        """更新单个神经元状态"""
        net_input = np.dot(self.weights[idx], self.states) + self.biases[idx]
        prob = 1 / (1 + np.exp(-np.clip(2 * net_input / T, -50, 50)))
        self.states[idx] = 1 if np.random.random() < prob else -1

    def anneal(self, initial_temp=5.0, final_temp=0.1, steps=200):
        """模拟退火"""
        temps = np.linspace(initial_temp, final_temp, steps)
        for T in temps:
            for i in np.random.permutation(self.num_neurons):
                self.update_neuron(i, T)
            self.energy_history.append(self.energy())
            self.state_history.append(self.states.copy())
        return self.states


# ==========================
# 运行模型
# ==========================
bm = BoltzmannMachine(3)
final_state = bm.anneal(steps=200)

print("最终状态:", final_state)
print("最终能量:", bm.energy())
print("权重矩阵:\n", np.round(bm.weights, 2))
print("偏置:", np.round(bm.biases, 2))

# ==========================
# 绘图
# ==========================
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

# (1) 能量变化
axes[0, 0].plot(bm.energy_history, color='purple')
axes[0, 0].set_title('能量变化过程')
axes[0, 0].set_xlabel('迭代步数')
axes[0, 0].set_ylabel('系统能量')
axes[0, 0].grid(True)

# (2) 状态变化热图
state_matrix = np.array(bm.state_history).T
sns.heatmap(state_matrix, ax=axes[0, 1], cmap='coolwarm', cbar_kws={'label': '状态 (-1/1)'})
axes[0, 1].set_title('神经元状态变化')
axes[0, 1].set_xlabel('迭代步数')
axes[0, 1].set_ylabel('神经元')

# (3) 网络结构图
G = nx.Graph()
for i in range(3):
    G.add_node(i, state=final_state[i])
for i in range(3):
    for j in range(i + 1, 3):
        if bm.weights[i, j] != 0:
            G.add_edge(i, j, weight=bm.weights[i, j])

pos = nx.spring_layout(G, seed=42)
node_colors = ['red' if final_state[i] == 1 else 'blue' for i in range(3)]
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=800, ax=axes[1, 0])
nx.draw_networkx_edges(G, pos, width=2, ax=axes[1, 0])
nx.draw_networkx_labels(G, pos, labels={i: f"{i}\n({final_state[i]})"}, font_color='white', ax=axes[1, 0])
nx.draw_networkx_edge_labels(G, pos,
    edge_labels={(i, j): f"{bm.weights[i, j]:.2f}" for i, j in G.edges()},
    ax=axes[1, 0])
axes[1, 0].set_title('网络结构 (最终状态)')
axes[1, 0].axis('off')

# (4) 热平衡状态分布 —— 改进版
final_states_count = {}
for state in bm.state_history[-20:]:  # 最后20步
    state_str = str(tuple(state))
    final_states_count[state_str] = final_states_count.get(state_str, 0) + 1

states = list(final_states_count.keys())
counts = list(final_states_count.values())

# 简化横坐标标签，例如 S1, S2, S3...
short_labels = [f"S{i+1}" for i in range(len(states))]

bars = axes[1, 1].bar(range(len(states)), counts, color='skyblue', edgecolor='black')

axes[1, 1].set_title('热平衡状态分布')
axes[1, 1].set_xlabel('状态编号')
axes[1, 1].set_ylabel('出现次数')

# 设置x轴刻度与标签
axes[1, 1].set_xticks(range(len(states)))
axes[1, 1].set_xticklabels(short_labels)

# 添加每个柱的数值标签
for bar, count in zip(bars, counts):
    height = bar.get_height()
    axes[1, 1].text(bar.get_x() + bar.get_width() / 2, height + 0.5,
                   f'{count}', ha='center', va='bottom')

# 刻度向内
axes[1, 1].tick_params(direction='in', length=5, width=1)


# 添加图例，显示状态对应关系
for label, state_str in zip(short_labels, states):
    print(f"{label}: {state_str}")

plt.tight_layout()
plt.show()

# ==========================
# 热平衡状态分析
# ==========================
print("\n=== 热平衡分析 ===")
unique_states, counts = np.unique(bm.state_history[-50:], axis=0, return_counts=True)
most_common_idx = np.argmax(counts)
thermal_state = unique_states[most_common_idx]
print(f"热平衡状态: {thermal_state}")
print(f"该状态出现概率: {counts[most_common_idx] / 50:.2%}")
