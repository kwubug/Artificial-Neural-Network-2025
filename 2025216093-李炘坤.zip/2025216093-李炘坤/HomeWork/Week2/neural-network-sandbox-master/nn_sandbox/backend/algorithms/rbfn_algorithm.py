from . import PredictiveAlgorithm
from .k_means import KMeans
from ..neurons import RbfNeuron
import numpy as np


class RbfnAlgorithm(PredictiveAlgorithm):
    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 acceptable_range=0.5, initial_learning_rate=0.8,
                 search_iteration_constant=10000, cluster_count=3,
                 test_ratio=0.3):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self.acceptable_range = acceptable_range
        self.cluster_count = cluster_count

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        self._adjust_neurons(result)

    def _initialize_neurons(self):
        self._neurons = [RbfNeuron(cluster.center, cluster.avg_distance)
                         for cluster in KMeans(self.cluster_count).fit(self.training_dataset)]
        self._neurons.insert(0, RbfNeuron(is_threshold=True))

    def _feed_forward(self, data):
        for neuron in self._neurons:
            neuron.data = data
        return sum(neuron.result for neuron in self._neurons)

    def _adjust_neurons(self, output):
        expect = self.current_data[-1]
        for neuron in self._neurons:
            new_synaptic_weight_diff = self._get_synaptic_weight_diff(
                output, expect, neuron
            )
            if not neuron.is_threshold and neuron.standard_deviation != 0:
                data_mean_diff = neuron.data - neuron.mean
                new_mean = (neuron.mean
                            + new_synaptic_weight_diff
                            * neuron.synaptic_weight
                            * data_mean_diff
                            / neuron.standard_deviation**2)
                new_standard_deviation = (neuron.standard_deviation
                                          + new_synaptic_weight_diff
                                          * neuron.synaptic_weight
                                          * data_mean_diff.dot(data_mean_diff)
                                          / neuron.standard_deviation**3)
                neuron.mean, neuron.standard_deviation = new_mean, new_standard_deviation
            neuron.synaptic_weight += new_synaptic_weight_diff
    # 伪逆法

    # def _adjust_neurons(self, output):
    #     # 获取期望输出
    #     expect = self.current_data[-1]
    #
    #     # 计算误差，确保 error 是标量
    #     error = expect - output
    #
    #     # 将每个神经元的输入数据组合成矩阵
    #     # input_matrix: shape (num_neurons, input_dim)
    #     input_matrix = np.array([neuron.data for neuron in self._neurons if not neuron.is_threshold])
    #
    #     # 检查输入矩阵是否为空
    #     if input_matrix.shape[0] == 0:
    #         raise ValueError(f"输入矩阵为空，无法进行权重更新")
    #
    #     # 转置 input_matrix 以对齐维度
    #     # input_matrix.T: shape (input_dim, num_neurons)
    #     pseudo_inverse = np.linalg.pinv(input_matrix.T)
    #
    #     # 将误差转换为与伪逆计算匹配的形状
    #     # error_vector: shape (input_dim, 1)
    #     error_vector = np.full((input_matrix.shape[1], 1), error)
    #
    #     # 计算权重更新（伪逆矩阵 * 误差向量）
    #     # weight_updates: shape (num_neurons, )
    #     weight_updates = pseudo_inverse.dot(error_vector).flatten()
    #
    #     # 更新每个神经元的权重和其他参数
    #     update_index = 0
    #     for neuron in self._neurons:
    #         if not neuron.is_threshold and neuron.standard_deviation != 0:
    #             # 确保索引与 weight_updates 的长度匹配
    #             if update_index >= len(weight_updates):
    #                 raise IndexError("更新索引超出了权重更新数组的范围")
    #
    #             # 更新神经元的权重
    #             neuron.synaptic_weight += weight_updates[update_index]
    #
    #             # 更新均值和标准差
    #             data_mean_diff = neuron.data - neuron.mean
    #             new_mean = neuron.mean + weight_updates[update_index] * data_mean_diff / neuron.standard_deviation ** 2
    #             new_standard_deviation = neuron.standard_deviation + weight_updates[update_index] * np.dot(
    #                 data_mean_diff, data_mean_diff) / neuron.standard_deviation ** 3
    #
    #             # 将新计算的值赋回神经元
    #             neuron.mean = new_mean
    #             neuron.standard_deviation = new_standard_deviation
    #
    #             # 更新索引
    #             update_index += 1

    def _get_synaptic_weight_diff(self, output, expect, neuron):
        if neuron.is_threshold:
            return self.current_learning_rate * (expect - output)
        return self.current_learning_rate * (expect - output) * neuron.activation_function(
            neuron.data, neuron.mean, neuron.standard_deviation
        )

    def _correct_rate(self, dataset):
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            if data[-1] - self.acceptable_range < result < data[-1] + self.acceptable_range:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)
