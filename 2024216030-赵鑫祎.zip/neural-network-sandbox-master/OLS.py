import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QSlider, QGroupBox)
from PyQt5.QtCore import QTimer, Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class OLSVisualizer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OLS可视化")
        self.resize(1000, 700)

        # --- 数据与模型参数 ---
        self.X_data = []
        self.y_data = []
        # 权重 (slope) 和 偏置 (intercept)
        self.w = 0.0 
        self.b = 0.0
        # 学习率
        self.learning_rate = 0.01
        self.is_learning = False

        # --- UI 初始化 ---
        self.init_ui()
        
        # --- 动画计时器 ---
        self.timer = QTimer()
        self.timer.timeout.connect(self.step_gradient_descent)
        self.timer.setInterval(20) # 20ms 刷新一次

    def init_ui(self):
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)

        # 1. Matplotlib 画布
        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)
        # 绑定鼠标点击事件
        self.canvas.mpl_connect('button_press_event', self.on_click)
        layout.addWidget(self.canvas)

        # 2. 信息面板
        info_layout = QHBoxLayout()
        self.label_equation = QLabel("当前模型: y = 0.00x + 0.00")
        self.label_loss = QLabel("MSE Loss: 0.0000")
        self.label_equation.setStyleSheet("font-size: 14px; font-weight: bold; color: blue;")
        self.label_loss.setStyleSheet("font-size: 14px; font-weight: bold; color: red;")
        info_layout.addWidget(self.label_equation)
        info_layout.addWidget(self.label_loss)
        layout.addLayout(info_layout)

        # 3. 控制面板
        control_group = QGroupBox("控制面板")
        control_layout = QHBoxLayout()

        self.btn_start = QPushButton("开始训练 (梯度下降)")
        self.btn_start.clicked.connect(self.toggle_learning)
        
        self.btn_reset_params = QPushButton("重置参数")
        self.btn_reset_params.clicked.connect(self.reset_params)

        self.btn_clear = QPushButton("清空数据")
        self.btn_clear.clicked.connect(self.clear_data)

        self.btn_random = QPushButton("生成随机数据")
        self.btn_random.clicked.connect(self.generate_random_data)

        control_layout.addWidget(self.btn_start)
        control_layout.addWidget(self.btn_reset_params)
        control_layout.addWidget(self.btn_random)
        control_layout.addWidget(self.btn_clear)
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)

        # 初始化绘图
        self.plot_graph()

    def on_click(self, event):
        """鼠标点击画布添加数据点"""
        if event.inaxes != self.ax:
            return
        if self.is_learning:
            return # 训练中禁止添加点以防干扰演示

        self.X_data.append(event.xdata)
        self.y_data.append(event.ydata)
        self.plot_graph()

    def generate_random_data(self):
        """生成一些带有噪声的线性数据"""
        self.clear_data()
        np.random.seed(42)
        X = np.random.rand(20) * 10
        # y = 2x + 5 + noise
        y = 2 * X + 5 + np.random.randn(20) * 2
        
        self.X_data = X.tolist()
        self.y_data = y.tolist()
        self.reset_params()
        self.plot_graph()

    def clear_data(self):
        self.X_data = []
        self.y_data = []
        self.stop_learning()
        self.reset_params()
        self.plot_graph()

    def reset_params(self):
        """重置权重和偏置"""
        self.w = 0.0
        self.b = 0.0
        self.update_labels()
        self.plot_graph()

    def toggle_learning(self):
        if not self.X_data:
            return
            
        if self.is_learning:
            self.stop_learning()
        else:
            self.start_learning()

    def start_learning(self):
        self.is_learning = True
        self.btn_start.setText("暂停训练")
        self.timer.start()

    def stop_learning(self):
        self.is_learning = False
        self.btn_start.setText("开始训练 (梯度下降)")
        self.timer.stop()

    def step_gradient_descent(self):
        """执行一步梯度下降"""
        if not self.X_data:
            return

        X = np.array(self.X_data)
        y = np.array(self.y_data)
        n = len(X)

        # 1. 前向传播 (预测)
        y_pred = self.w * X + self.b

        # 2. 计算梯度 (MSE Loss 对 w 和 b 的偏导数)
        # dL/dw = (-2/n) * sum(x * (y - y_pred))
        # dL/db = (-2/n) * sum(y - y_pred)
        dw = (-2/n) * np.sum(X * (y - y_pred))
        db = (-2/n) * np.sum(y - y_pred)

        # 3. 更新参数
        # 为了可视化效果平滑，我们使用较小的学习率
        # 如果数据跨度大，可能需要动态调整，这里简化处理
        self.w = self.w - self.learning_rate * dw
        self.b = self.b - self.learning_rate * db * 10 # 加速bias的学习以便视觉平衡

        # 4. 更新界面
        self.update_labels(X, y, y_pred)
        self.plot_graph()

        # 如果梯度很小，可以自动停止（可选）
        if abs(dw) < 0.001 and abs(db) < 0.001:
            # self.stop_learning()
            pass

    def update_labels(self, X=None, y=None, y_pred=None):
        self.label_equation.setText(f"当前模型: y = {self.w:.2f}x + {self.b:.2f}")
        
        if X is not None and y is not None:
            loss = np.mean((y - y_pred) ** 2)
            self.label_loss.setText(f"MSE Loss: {loss:.4f}")
        else:
            self.label_loss.setText("MSE Loss: 0.0000")

    def get_analytical_solution(self):
        """计算最小二乘法解析解 (Normal Equation) 用于对比"""
        if len(self.X_data) < 2:
            return None, None
        
        X = np.array(self.X_data)
        y = np.array(self.y_data)
        
        # y = mx + c
        # 使用 numpy 的 polyfit 计算解析解
        m, c = np.polyfit(X, y, 1)
        return m, c

    def plot_graph(self):
        self.ax.clear()
        
        # 设置坐标轴范围 (固定范围看起来更像黑板)
        self.ax.set_xlim(0, 12)
        self.ax.set_ylim(0, 30)
        self.ax.set_title("OLS Regression Interactive")
        self.ax.set_xlabel("X")
        self.ax.set_ylabel("Y")
        self.ax.grid(True, linestyle='--', alpha=0.6)

        # 1. 绘制数据点
        if self.X_data:
            self.ax.scatter(self.X_data, self.y_data, color='black', label='Data Points')

        # 2. 绘制解析解 (理想的最优线 - 绿色虚线)
        best_w, best_b = self.get_analytical_solution()
        x_range = np.array([0, 12])
        
        if best_w is not None:
            y_best = best_w * x_range + best_b
            self.ax.plot(x_range, y_best, 'g--', alpha=0.5, label='Analytical Solution (Optimal)')

        # 3. 绘制当前学习的线 (蓝色实线)
        y_current = self.w * x_range + self.b
        self.ax.plot(x_range, y_current, 'b-', linewidth=2, label='Learning Model')

        self.ax.legend()
        self.canvas.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = OLSVisualizer()
    window.show()
    sys.exit(app.exec_())