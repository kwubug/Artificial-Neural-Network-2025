import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Boltzmann Machine'

    RowLayout {
        spacing: 10
        
        // 左侧：参数设置和控制
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.25
            Layout.fillHeight: true
            spacing: 5
            
            GroupBox {
                title: '模拟退火参数'
                Layout.fillWidth: true
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 5
                    columnSpacing: 5
                    
                    Label { text: 'T₀:'; font.pixelSize: 11 }
                    DoubleSpinBox {
                        enabled: boltzmannMachineBridge.has_finished
                        value: 100
                        from: 10; to: 500
                        onValueChanged: boltzmannMachineBridge.T0 = value / 100
                        Component.onCompleted: boltzmannMachineBridge.T0 = value / 100
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'α:'; font.pixelSize: 11 }
                    DoubleSpinBox {
                        enabled: boltzmannMachineBridge.has_finished
                        value: 9950
                        from: 9900; to: 9999
                        onValueChanged: boltzmannMachineBridge.alpha = value / 10000
                        Component.onCompleted: boltzmannMachineBridge.alpha = value / 10000
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '迭代:'; font.pixelSize: 11 }
                    SpinBox {
                        enabled: boltzmannMachineBridge.has_finished
                        value: 1000
                        from: 100; to: 5000
                        onValueChanged: boltzmannMachineBridge.max_iter = value
                        Component.onCompleted: boltzmannMachineBridge.max_iter = value
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '频率:'; font.pixelSize: 11 }
                    SpinBox {
                        enabled: boltzmannMachineBridge.has_finished
                        value: 10
                        from: 1; to: 100
                        onValueChanged: boltzmannMachineBridge.update_freq = value
                        Component.onCompleted: boltzmannMachineBridge.update_freq = value
                        Layout.fillWidth: true
                    }
                }
            }
            
            GroupBox {
                title: '初始状态'
                Layout.fillWidth: true
                ColumnLayout {
                    anchors.fill: parent
                    spacing: 5
                    CheckBox {
                        text: 'V1'
                        enabled: boltzmannMachineBridge.has_finished
                        checked: false
                        onCheckedChanged: boltzmannMachineBridge.init_v1 = checked ? 1 : 0
                        Component.onCompleted: boltzmannMachineBridge.init_v1 = 0
                    }
                    CheckBox {
                        text: 'V2'
                        enabled: boltzmannMachineBridge.has_finished
                        checked: false
                        onCheckedChanged: boltzmannMachineBridge.init_v2 = checked ? 1 : 0
                        Component.onCompleted: boltzmannMachineBridge.init_v2 = 0
                    }
                    CheckBox {
                        text: 'V3'
                        enabled: boltzmannMachineBridge.has_finished
                        checked: false
                        onCheckedChanged: boltzmannMachineBridge.init_v3 = checked ? 1 : 0
                        Component.onCompleted: boltzmannMachineBridge.init_v3 = 0
                    }
                }
            }
            
            GroupBox {
                title: '控制'
                Layout.fillWidth: true
                ExecutionControls {
                    startButton.enabled: boltzmannMachineBridge.has_finished
                    startButton.text: "开始"
                    startButton.onClicked: () => {
                        energySeries.clear()
                        temperatureSeries.clear()
                        eAxisX.max = 100
                        tAxisX.max = 100
                        eAxisY.min = -2
                        eAxisY.max = 0
                        boltzmannMachineBridge.start()
                    }
                    stopButton.enabled: !boltzmannMachineBridge.has_finished
                    stopButton.onClicked: boltzmannMachineBridge.stop()
                    progressBar.from: 0
                    progressBar.to: boltzmannMachineBridge.max_iter
                    progressBar.value: boltzmannMachineBridge.current_iter
                    Layout.fillWidth: true
                }
            }
            
            Item { Layout.fillHeight: true }
        }
        
        // 中间：图表和数据表格
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.5
            Layout.fillHeight: true
            spacing: 5
            
            GroupBox {
                title: '温度变化 T(t)'
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                ChartView {
                    anchors.fill: parent
                    antialiasing: true
                    legend.visible: false
                    theme: ChartView.ChartThemeLight
                    margins.top: 0
                    margins.bottom: 0
                    margins.left: 0
                    margins.right: 0
                    
                    ValueAxis { 
                        id: tAxisX
                        min: 0
                        max: 100
                        titleText: '步数'
                        labelFormat: '%d'
                        tickCount: 5
                        labelsFont.pixelSize: 9
                    }
                    ValueAxis { 
                        id: tAxisY
                        min: 0
                        max: boltzmannMachineBridge.T0 * 1.2
                        titleText: 'T'
                        labelFormat: '%.2f'
                        tickCount: 5
                        labelsFont.pixelSize: 9
                    }
                    LineSeries {
                        id: temperatureSeries
                        axisX: tAxisX
                        axisY: tAxisY
                        color: '#ff6600'
                        width: 2
                    }
                }
            }
            
            GroupBox {
                title: '能量变化 E(t)'
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                ChartView {
                    anchors.fill: parent
                    antialiasing: true
                    legend.visible: false
                    theme: ChartView.ChartThemeLight
                    margins.top: 0
                    margins.bottom: 0
                    margins.left: 0
                    margins.right: 0
                    
                    ValueAxis { 
                        id: eAxisX
                        min: 0
                        max: 100
                        titleText: '步数'
                        labelFormat: '%d'
                        tickCount: 5
                        labelsFont.pixelSize: 9
                    }
                    ValueAxis { 
                        id: eAxisY
                        min: -2
                        max: 0
                        titleText: 'E'
                        labelFormat: '%.2f'
                        tickCount: 5
                        labelsFont.pixelSize: 9
                    }
                    LineSeries {
                        id: energySeries
                        axisX: eAxisX
                        axisY: eAxisY
                        color: '#0066cc'
                        width: 2
                    }
                }
            }
            
            GroupBox {
                title: '详细数据 (最新20步)'
                Layout.fillWidth: true
                Layout.fillHeight: true
                
                Flickable {
                    anchors.fill: parent
                    contentHeight: dataTable.implicitHeight
                    clip: true
                    
                    Column {
                        id: dataTable
                        anchors.left: parent.left
                        anchors.right: parent.right
                        spacing: 0
                        
                        Row {
                            spacing: 0
                            Repeater {
                                model: ['步', 'V1', 'V2', 'V3', '能量', '温度', '神经元', 'P', 'Net', '变化']
                                delegate: Rectangle {
                                    width: index === 0 ? 40 : (index >= 4 && index <= 5) ? 70 : 50
                                    height: 25
                                    border.color: '#888'
                                    border.width: 1
                                    color: '#e0e0e0'
                                    Text {
                                        anchors.centerIn: parent
                                        text: modelData
                                        font.bold: true
                                        font.pixelSize: 9
                                    }
                                }
                            }
                        }
                        
                        Repeater {
                            model: {
                                if (!boltzmannMachineBridge.detailed_history || 
                                    boltzmannMachineBridge.detailed_history.length === 0) {
                                    return []
                                }
                                const history = boltzmannMachineBridge.detailed_history
                                const startIdx = Math.max(0, history.length - 20)
                                return history.slice(startIdx)
                            }
                            
                            delegate: Row {
                                spacing: 0
                                property var record: modelData
                                
                                Rectangle {
                                    width: 40; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.step
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.v1
                                        font.pixelSize: 9
                                        color: record.v1 ? '#00aa00' : '#cc0000'
                                        font.bold: true
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.v2
                                        font.pixelSize: 9
                                        color: record.v2 ? '#00aa00' : '#cc0000'
                                        font.bold: true
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.v3
                                        font.pixelSize: 9
                                        color: record.v3 ? '#00aa00' : '#cc0000'
                                        font.bold: true
                                    }
                                }
                                Rectangle {
                                    width: 70; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.energy.toFixed(3)
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 70; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.temperature.toFixed(3)
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.updated_neuron
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.prob_activation.toFixed(2)
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.net_input.toFixed(2)
                                        font.pixelSize: 9
                                    }
                                }
                                Rectangle {
                                    width: 50; height: 24
                                    border.color: '#ccc'; border.width: 1
                                    color: index % 2 === 0 ? 'white' : '#f9f9f9'
                                    Text {
                                        anchors.centerIn: parent
                                        text: record.state_change
                                        font.pixelSize: 9
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // 右侧：实时状态显示
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.22
            Layout.fillHeight: true
            spacing: 5
            
            GroupBox {
                title: '实时状态'
                Layout.fillWidth: true
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 5
                    
                    Label { 
                        text: '迭代:'
                        font.pixelSize: 11
                    }
                    Label { 
                        text: boltzmannMachineBridge.current_iter
                        font.bold: true
                        font.pixelSize: 14
                        color: '#0066cc'
                        horizontalAlignment: Text.AlignRight
                        Layout.fillWidth: true
                    }
                    
                    Label { 
                        text: '温度:'
                        font.pixelSize: 11
                    }
                    Label { 
                        text: boltzmannMachineBridge.current_temperature.toFixed(4)
                        font.bold: true
                        font.pixelSize: 12
                        color: '#ff6600'
                        horizontalAlignment: Text.AlignRight
                        Layout.fillWidth: true
                    }
                    
                    Label { 
                        text: '能量:'
                        font.pixelSize: 11
                    }
                    Label { 
                        text: boltzmannMachineBridge.current_energy.toFixed(4)
                        font.bold: true
                        font.pixelSize: 12
                        color: '#0066cc'
                        horizontalAlignment: Text.AlignRight
                        Layout.fillWidth: true
                    }
                }
            }
            
            GroupBox {
                title: '神经元状态'
                Layout.fillWidth: true
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 10
                    
                    Label { 
                        text: 'V1:'
                        font.bold: true
                        font.pixelSize: 12
                    }
                    Rectangle {
                        Layout.preferredWidth: 60
                        Layout.preferredHeight: 40
                        color: (boltzmannMachineBridge.current_state[0] || 0) ? '#00aa00' : '#cc0000'
                        border.color: '#666'
                        border.width: 2
                        radius: 5
                        Text {
                            anchors.centerIn: parent
                            text: boltzmannMachineBridge.current_state[0] || 0
                            font.bold: true
                            font.pixelSize: 20
                            color: 'white'
                        }
                    }
                    
                    Label { 
                        text: 'V2:'
                        font.bold: true
                        font.pixelSize: 12
                    }
                    Rectangle {
                        Layout.preferredWidth: 60
                        Layout.preferredHeight: 40
                        color: (boltzmannMachineBridge.current_state[1] || 0) ? '#00aa00' : '#cc0000'
                        border.color: '#666'
                        border.width: 2
                        radius: 5
                        Text {
                            anchors.centerIn: parent
                            text: boltzmannMachineBridge.current_state[1] || 0
                            font.bold: true
                            font.pixelSize: 20
                            color: 'white'
                        }
                    }
                    
                    Label { 
                        text: 'V3:'
                        font.bold: true
                        font.pixelSize: 12
                    }
                    Rectangle {
                        Layout.preferredWidth: 60
                        Layout.preferredHeight: 40
                        color: (boltzmannMachineBridge.current_state[2] || 0) ? '#00aa00' : '#cc0000'
                        border.color: '#666'
                        border.width: 2
                        radius: 5
                        Text {
                            anchors.centerIn: parent
                            text: boltzmannMachineBridge.current_state[2] || 0
                            font.bold: true
                            font.pixelSize: 20
                            color: 'white'
                        }
                    }
                }
            }
            
            Item { Layout.fillHeight: true }
        }
    }
    
    Connections {
        target: boltzmannMachineBridge
        function onCurrent_iterChanged() {
            if (boltzmannMachineBridge.current_iter > 0) {
                energySeries.append(
                    boltzmannMachineBridge.current_iter, 
                    boltzmannMachineBridge.current_energy
                )
                temperatureSeries.append(
                    boltzmannMachineBridge.current_iter, 
                    boltzmannMachineBridge.current_temperature
                )
                
                if (boltzmannMachineBridge.current_iter > eAxisX.max - 20) {
                    eAxisX.max = boltzmannMachineBridge.current_iter + 50
                    tAxisX.max = boltzmannMachineBridge.current_iter + 50
                }
                
                if (boltzmannMachineBridge.current_energy < eAxisY.min) {
                    eAxisY.min = boltzmannMachineBridge.current_energy - 0.2
                }
                if (boltzmannMachineBridge.current_energy > eAxisY.max - 0.1) {
                    eAxisY.max = boltzmannMachineBridge.current_energy + 0.5
                }
            }
        }
    }
}
