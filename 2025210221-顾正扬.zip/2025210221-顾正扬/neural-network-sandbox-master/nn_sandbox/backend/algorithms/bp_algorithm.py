import numpy as np
import collections


class BatchTrainingBPAlgorithm:
    def __init__(self, dataset, total_epoches=10, learning_rate=0.1, momentum_weight=0.5,
                 error_threshold=0.01, network_shape=None, test_ratio=0.3, bipolar=False):
        self.dataset = dataset
        self.total_epoches = total_epoches
        self.learning_rate = learning_rate
        self.momentum_weight = momentum_weight
        self.error_threshold = error_threshold
        self.test_ratio = test_ratio
        self.bipolar = bipolar

        # Default network shape is (2, 4, 1) if not provided
        self.network_shape = network_shape if network_shape else (2, 4, 1)

        # Initialize weights
        self._init_weights()

    def _init_weights(self):
        print(f"Initializing weights with network shape: {self.network_shape}")
        self.V = np.random.uniform(-1, 1, (self.network_shape[1], self.network_shape[0] + 1))  # Input to hidden layer
        self.W = np.random.uniform(-1, 1, (self.network_shape[2], self.network_shape[1] + 1))  # Hidden to output layer
        self._weights = [self.V, self.W]  # Store weights in a list
        print(f"Weights initialized with shapes V: {self.V.shape}, W: {self.W.shape}")

    def _sigmoid(self, x):
        # Sigmoid activation function
        if self.bipolar:
            return (1 - np.exp(-x)) / (1 + np.exp(-x))  # Bipolar Sigmoid
        else:
            return 1 / (1 + np.exp(-x))  # Unipolar Sigmoid

    def _sigmoid_derivative(self, y):
        # Sigmoid derivative function
        if self.bipolar:
            return 0.5 * (1 + y) * (1 - y)
        else:
            return y * (1 - y)

    def _feed_forward(self, X):
        # Ensure X has the correct shape before proceeding
        print(f"Input data shape before adding bias: {X.shape}")
        Xb = np.hstack((X, np.ones((X.shape[0], 1))))  # Add bias
        print(f"Input to hidden layer shape (with bias): {Xb.shape}")  # Debugging input shape
        H_in = Xb @ self.V.T
        H_out = self._sigmoid(H_in)
        Hb = np.hstack((H_out, np.ones((H_out.shape[0], 1))))  # Add bias
        print(f"Hidden layer output shape: {Hb.shape}")  # Debugging hidden layer output
        O_in = Hb @ self.W.T
        O_out = self._sigmoid(O_in)
        print(f"Output layer output shape: {O_out.shape}")  # Debugging output layer output
        return O_out, Hb, Xb

    def train(self, X, Y):
        print(f"Training with dataset size: {len(X)}")
        print(f"Network shape: {self.network_shape}")
        for epoch in range(self.total_epoches):
            total_error = 0
            for sample in zip(X, Y):  # Use zip to iterate over both inputs and labels
                X_input, D = sample
                print(f"Input shape for current sample: {X_input.shape}")  # Debugging input data shape
                O_out, Hb, Xb = self._feed_forward(X_input)

                # Calculate error
                error = D - O_out
                total_error += np.sum(error ** 2)

                # Backpropagation
                delta_o = error * self._sigmoid_derivative(O_out)
                delta_h = (delta_o @ self.W[:, :-1]) * self._sigmoid_derivative(Hb[:, 1:])

                # Update weights
                self.W += self.learning_rate * (delta_o.T @ Hb)
                self.V += self.learning_rate * (delta_h.T @ Xb)

            # Print error for each epoch
            print(f"Epoch {epoch + 1}/{self.total_epoches}, Error: {total_error / len(X)}")

            # Check if error is below the threshold and stop early
            if total_error / len(X) < self.error_threshold:
                print(f"Training stopped early at epoch {epoch + 1} due to error threshold.")
                break

        print("Training completed.")
        print(f"Final Error: {total_error / len(X)}")

    def test(self, X, Y):
        correct = 0
        total = len(Y)
        for i in range(total):
            X_input = np.insert(X[i], 0, 1)  # Add bias
            O_out, _, _ = self._feed_forward(X_input)
            if np.round(O_out) == Y[i]:
                correct += 1
        return correct / total  # Return accuracy

