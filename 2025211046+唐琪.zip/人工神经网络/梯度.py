import matplotlib
matplotlib.use('TkAgg')
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

a, b = 3, 1
f = lambda w: 0.5 * (a * w[0]**2 + b * w[1]**2)
grad = lambda w: np.array([a * w[0], b * w[1]])
H = np.array([[a, 0], [0, b]])

def gradient_descent(w0, lr=0.2, max_iter=20):
    w = w0.copy()
    path = [w.copy()]
    for i in range(max_iter):
        w -= lr * grad(w)
        path.append(w.copy())
    return np.array(path)

def newton_method(w0, max_iter=10):
    w = w0.copy()
    path = [w.copy()]
    for i in range(max_iter):
        w -= np.linalg.inv(H) @ grad(w)
        path.append(w.copy())
    return np.array(path)

def conjugate_gradient(w0, max_iter=10):
    w = w0.copy()
    g = grad(w)
    p = -g
    path = [w.copy()]
    for i in range(max_iter):
        alpha = (g @ g) / (p @ H @ p)
        w = w + alpha * p
        g_new = grad(w)
        beta = (g_new @ g_new) / (g @ g)
        p = -g_new + beta * p
        g = g_new
        path.append(w.copy())
    return np.array(path)

w0 = np.array([2.5, 2.5])
path_gd = gradient_descent(w0)
path_newton = newton_method(w0)
path_cg = conjugate_gradient(w0)

fig = plt.figure(figsize=(10, 7))
ax = fig.add_subplot(111, projection='3d')

w1 = np.linspace(-3, 3, 100)
w2 = np.linspace(-3, 3, 100)
W1, W2 = np.meshgrid(w1, w2)
Z = 0.5 * (a * W1**2 + b * W2**2)

ax.plot_surface(W1, W2, Z, cmap='coolwarm', alpha=0.6)


paths = {
    "最速下降法": (path_gd, 'r'),
    "牛顿法": (path_newton, 'g'),
    "共轭梯度法": (path_cg, 'b'),
}

for name, (path, color) in paths.items():
    z_vals = [f(w) for w in path]
    ax.plot(path[:, 0], path[:, 1], z_vals, color=color, lw=2, label=name)
    ax.scatter(path[-1, 0], path[-1, 1], z_vals[-1], color=color, s=50, marker='o')

ax.set_xlabel('$w_1$')
ax.set_ylabel('$w_2$')
ax.set_zlabel('$E(w_1, w_2)$')
ax.set_title('三种优化算法的3D可视化')
ax.legend()
ax.view_init(elev=30, azim=45)

plt.show()