import time

import PyQt5.QtCore

from nn_sandbox.backend.algorithms import BpAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class BpBridge(Bridge):
    """
    Bridge class for BP Neural Network.
    Connects the backend BP algorithm to the QML frontend.
    """
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(10)
    most_correct_rate_checkbox = BridgeProperty(True)
    most_correct_rate = BridgeProperty(0.98)
    initial_learning_rate = BridgeProperty(0.8)
    search_iteration_constant = BridgeProperty(10000)
    momentum_weight = BridgeProperty(0.5)
    test_ratio = BridgeProperty(0.3)
    hidden_layers = BridgeProperty([5, 3])  # Two hidden layers
    acceptable_error = BridgeProperty(0.001)
    activation_type = BridgeProperty('unipolar')  # 'unipolar' or 'bipolar'
    current_iterations = BridgeProperty(0)
    current_learning_rate = BridgeProperty(0.0)
    current_error = BridgeProperty(0.0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    current_epoch = BridgeProperty(0)

    def __init__(self):
        super().__init__()
        self.bp_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bp_algorithm(self):
        """Start the BP training algorithm."""
        self.bp_algorithm = ObservableBpAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict[self.current_dataset_name],
            total_epoches=self.total_epoches,
            most_correct_rate=self._most_correct_rate,
            initial_learning_rate=self.initial_learning_rate,
            search_iteration_constant=self.search_iteration_constant,
            momentum_weight=self.momentum_weight,
            test_ratio=self.test_ratio,
            hidden_layers=self.hidden_layers,
            acceptable_error=self.acceptable_error,
            activation_type=self.activation_type
        )
        self.bp_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bp_algorithm(self):
        """Stop the BP training algorithm."""
        if self.bp_algorithm:
            self.bp_algorithm.stop()

    @property
    def _most_correct_rate(self):
        """Return the most correct rate if checkbox is enabled, else None."""
        if self.most_correct_rate_checkbox:
            return self.most_correct_rate
        return None


class ObservableBpAlgorithm(Observable, BpAlgorithm):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        BpAlgorithm.__init__(self, **kwargs)
        self.ui_refresh_interval = ui_refresh_interval

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iterations':
            self.notify(name, value)
            # 可选：每 n 次迭代更新测试正确率，避免过于频繁
            self.notify('test_correct_rate', self.test())
        elif name in ('best_correct_rate', 'current_correct_rate', 'current_error'):
            self.notify(name, value)
        elif name in ('training_dataset', 'testing_dataset') and value is not None:
            self.notify(name, value.tolist())

    def run(self):
        self.notify('has_finished', False)
        self.notify('test_correct_rate', 0)
        self.notify('current_error', 0)
        super().run()
        self.notify('test_correct_rate', self.test())
        self.notify('has_finished', True)

    def _iterate(self):
        super()._iterate()
        time.sleep(self.ui_refresh_interval)

    @property
    def current_learning_rate(self):
        ret = super().current_learning_rate
        self.notify('current_learning_rate', ret)
        return ret
