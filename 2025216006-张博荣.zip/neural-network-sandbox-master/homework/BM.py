import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.gridspec import GridSpec
import random

# 设置随机种子以保证结果可复现
np.random.seed(42)
random.seed(42)

class BoltzmannMachine:
    def __init__(self, num_neurons):
        self.num_neurons = num_neurons
        # 初始化权重矩阵（对称矩阵，对角线为0）
        self.weights = np.random.normal(0, 0.1, (num_neurons, num_neurons))
        self.weights = (self.weights + self.weights.T) / 2  # 确保对称性
        np.fill_diagonal(self.weights, 0)  # 没有自连接
        
        # 初始化偏置
        self.biases = np.random.normal(0, 0.1, num_neurons)
        
        # 神经元状态（0或1）
        self.states = np.random.randint(0, 2, num_neurons)
        
    def energy(self):
        """计算当前状态的能量"""
        energy = -0.5 * np.dot(np.dot(self.states.T, self.weights), self.states)
        energy -= np.dot(self.biases, self.states)
        return energy
    
    def probability(self, neuron_idx):
        """计算神经元处于激活状态的概率"""
        activation = self.biases[neuron_idx]
        activation += np.dot(self.weights[neuron_idx], self.states)
        return 1 / (1 + np.exp(-activation))
    
    def update_neuron(self, neuron_idx, temperature):
        """根据温度更新单个神经元的状态"""
        prob = self.probability(neuron_idx)
        # 加入温度因素，温度越高，越容易随机翻转
        prob = prob ** (1 / temperature)
        prob /= prob + (1 - prob) ** (1 / temperature)
        
        new_state = 1 if random.random() < prob else 0
        old_state = self.states[neuron_idx]
        
        if new_state != old_state:
            self.states[neuron_idx] = new_state
            return True  # 状态发生了变化
        return False  # 状态没有变化
    
    def simulate_step(self, temperature):
        """模拟一步BM运行"""
        # 随机选择一个神经元进行更新
        neuron_idx = random.randint(0, self.num_neurons - 1)
        return self.update_neuron(neuron_idx, temperature)

# 创建可视化
def visualize_boltzmann_machine():
    # 创建BM网络
    bm = BoltzmannMachine(3)
    
    # 设置模拟参数
    num_steps = 500  # 减少总步数
    temperatures = np.linspace(2.0, 0.1, num_steps)  # 温度逐渐降低
    
    # 记录数据（减少记录频率）
    states_history = []
    energy_history = []
    states_history.append(bm.states.copy())
    energy_history.append(bm.energy())
    
    # 模拟BM运行
    for i in range(num_steps):
        temperature = temperatures[i]
        changed = bm.simulate_step(temperature)
        
        # 降低记录频率，加快动画
        if i % 5 == 0 or changed:
            states_history.append(bm.states.copy())
            energy_history.append(bm.energy())
    
    # 创建图形
    fig = plt.figure(figsize=(12, 8))
    gs = GridSpec(3, 2, figure=fig)
    
    # 神经元状态可视化
    ax1 = fig.add_subplot(gs[0, :])
    ax1.set_title('Boltzmann Machine Neurons', fontsize=16)
    ax1.set_xlim(-1, 3)
    ax1.set_ylim(-1, 2)
    ax1.set_xticks(range(3))
    ax1.set_xticklabels([f'Neuron {i+1}' for i in range(3)])
    ax1.set_yticks([0, 1])
    ax1.set_yticklabels(['Inactive', 'Active'])
    
    # 绘制神经元
    neurons = []
    for i in range(3):
        neuron = ax1.scatter(i, 0, s=500, c='lightblue', edgecolors='black', zorder=2)
        neurons.append(neuron)
    
    # 绘制连接权重
    connections = []
    for i in range(3):
        for j in range(i+1, 3):
            x = [i, j]
            y = [0, 0]
            weight = bm.weights[i, j]
            color = 'red' if weight < 0 else 'blue'
            alpha = min(1, abs(weight) * 5)  # 权重越大，线条越明显
            line = ax1.plot(x, y, color=color, alpha=alpha, linewidth=2, zorder=1)[0]
            connections.append((line, weight))
    
    # 能量变化图
    ax2 = fig.add_subplot(gs[1, :])
    ax2.set_title('Energy Over Time', fontsize=16)
    ax2.set_xlabel('Step')
    ax2.set_ylabel('Energy')
    energy_line, = ax2.plot([], [], 'b-')
    ax2.set_xlim(0, len(energy_history))
    ax2.set_ylim(min(energy_history) - 1, max(energy_history) + 1)
    
    # 温度变化图
    ax3 = fig.add_subplot(gs[2, 0])
    ax3.set_title('Temperature Schedule', fontsize=16)
    ax3.set_xlabel('Step')
    ax3.set_ylabel('Temperature')
    temp_line, = ax3.plot([], [], 'r-')
    ax3.set_xlim(0, num_steps)
    ax3.set_ylim(0, 2.1)
    
    # 状态转换矩阵
    ax4 = fig.add_subplot(gs[2, 1])
    ax4.set_title('State Transition Count', fontsize=16)
    ax4.set_xlabel('From State')
    ax4.set_ylabel('To State')
    
    # 计算状态转换
    state_map = {}
    state_count = 0
    transitions = np.zeros((8, 8))
    
    for i in range(len(states_history) - 1):
        from_state = tuple(states_history[i])
        to_state = tuple(states_history[i+1])
        
        if from_state not in state_map:
            state_map[from_state] = state_count
            state_count += 1
        if to_state not in state_map:
            state_map[to_state] = state_count
            state_count += 1
        
        transitions[state_map[from_state], state_map[to_state]] += 1
    
    # 绘制转换矩阵
    im = ax4.imshow(transitions, cmap='viridis', aspect='auto')
    ax4.set_xticks(range(len(state_map)))
    ax4.set_yticks(range(len(state_map)))
    ax4.set_xticklabels([str(s) for s in state_map.keys()], rotation=45)
    ax4.set_yticklabels([str(s) for s in state_map.keys()])
    
    # 添加颜色条
    plt.colorbar(im, ax=ax4, label='Transition Count')
    
    # 动画更新函数
    def update(frame):
        if frame >= len(states_history):
            return neurons + [line for line, _ in connections] + [energy_line, temp_line, im]
        
        # 更新神经元状态
        current_states = states_history[frame]
        for i in range(3):
            color = 'red' if current_states[i] == 1 else 'lightblue'
            neurons[i].set_facecolor(color)
        
        # 更新能量曲线
        energy_line.set_data(range(frame+1), energy_history[:frame+1])
        
        # 更新温度曲线
        temp_frame = min(frame * 5, num_steps - 1)
        temp_line.set_data(range(temp_frame+1), temperatures[:temp_frame+1])
        
        # 更新权重连接的可视化
        for i, (line, weight) in enumerate(connections):
            if i == 0:
                n1, n2 = 0, 1
            elif i == 1:
                n1, n2 = 0, 2
            else:
                n1, n2 = 1, 2
            
            if current_states[n1] == 1 and current_states[n2] == 1:
                line.set_alpha(min(1, abs(weight) * 10))
            else:
                line.set_alpha(min(1, abs(weight) * 5))
        
        return neurons + [line for line, _ in connections] + [energy_line, temp_line]
    
    # 创建动画，减少interval以加快速度
    ani = animation.FuncAnimation(fig, update, frames=len(states_history) + 30, 
                                 interval=30, blit=True, repeat=True)
    
    # 添加说明文本
    fig.text(0.02, 0.02, 
             'Boltzmann Machine Simulation with 3 Neurons\n'
             'Red: Active Neuron, Blue: Inactive Neuron\n'
             'Blue connections: Excitatory, Red connections: Inhibitory\n'
             'Temperature decreases over time to reach thermal equilibrium',
             fontsize=12, verticalalignment='bottom')
    
    plt.tight_layout()
    plt.show()
    
    # 分析热平衡状态
    print("\nThermal Equilibrium Analysis:")
    print("-" * 40)
    
    # 最后20%的状态被认为是热平衡状态
    equilibrium_start = int(len(states_history) * 0.8)
    equilibrium_states = states_history[equilibrium_start:]
    
    # 计算每个状态出现的频率
    state_counts = {}
    for state in equilibrium_states:
        state_tuple = tuple(state)
        state_counts[state_tuple] = state_counts.get(state_tuple, 0) + 1
    
    # 显示平衡状态分布
    print("State Distribution at Thermal Equilibrium:")
    total = sum(state_counts.values())
    for state, count in sorted(state_counts.items(), key=lambda x: x[1], reverse=True):
        prob = count / total
        energy = -0.5 * np.dot(np.dot(np.array(state).T, bm.weights), np.array(state))
        energy -= np.dot(bm.biases, np.array(state))
        print(f"State {state}: Probability = {prob:.3f}, Energy = {energy:.3f}")
    
    # 计算平均能量
    avg_energy = np.mean([-0.5 * np.dot(np.dot(np.array(state).T, bm.weights), np.array(state)) 
                         - np.dot(bm.biases, np.array(state)) for state in equilibrium_states])
    print(f"\nAverage Energy at Equilibrium: {avg_energy:.3f}")
    
    # 计算能量波动
    energies = [-0.5 * np.dot(np.dot(np.array(state).T, bm.weights), np.array(state)) 
               - np.dot(bm.biases, np.array(state)) for state in equilibrium_states]
    energy_std = np.std(energies)
    print(f"Energy Fluctuation (Std): {energy_std:.3f}")
    
    return ani

# 运行可视化
if __name__ == "__main__":
    ani = visualize_boltzmann_machine()