#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试平滑曲线绘制
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# 设置中文字体
import matplotlib
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

def rosenbrock_function(x):
    """Rosenbrock函数"""
    return 100 * (x[1] - x[0]**2)**2 + (1 - x[0])**2

def create_smooth_path(path_points, objective_func):
    """创建平滑路径"""
    if len(path_points) < 2:
        return path_points, [objective_func(p) for p in path_points]
    
    # 计算每个点的Z坐标
    z_points = [objective_func(p) for p in path_points]
    
    # 创建参数化曲线
    t = np.linspace(0, 1, len(path_points))
    
    try:
        from scipy.interpolate import CubicSpline
        
        # 使用三次样条插值
        cs_x = CubicSpline(t, [p[0] for p in path_points])
        cs_y = CubicSpline(t, [p[1] for p in path_points])
        cs_z = CubicSpline(t, z_points)
        
        # 生成更密集的点
        t_smooth = np.linspace(0, 1, len(path_points) * 10)
        x_smooth = cs_x(t_smooth)
        y_smooth = cs_y(t_smooth)
        z_smooth = cs_z(t_smooth)
        
        return list(zip(x_smooth, y_smooth, z_smooth)), z_smooth
        
    except ImportError:
        # 使用numpy插值
        t_smooth = np.linspace(0, 1, len(path_points) * 5)
        x_smooth = np.interp(t_smooth, t, [p[0] for p in path_points])
        y_smooth = np.interp(t_smooth, t, [p[1] for p in path_points])
        z_smooth = np.interp(t_smooth, t, z_points)
        
        return list(zip(x_smooth, y_smooth, z_smooth)), z_smooth

# 创建测试路径
def test_smooth_curve():
    # 创建图形
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # 绘制函数表面
    x_range = [-2.0, 3.0]
    y_range = [-1.0, 4.0]
    X = np.linspace(x_range[0], x_range[1], 50)
    Y = np.linspace(y_range[0], y_range[1], 50)
    X, Y = np.meshgrid(X, Y)
    Z = np.zeros_like(X)
    
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            Z[i, j] = rosenbrock_function(np.array([X[i, j], Y[i, j]]))
    
    Z = np.clip(Z, 0, 1000)
    ax.plot_surface(X, Y, Z, alpha=0.6, cmap='viridis', vmin=0, vmax=1000)
    
    # 创建测试路径点
    path_points = [
        np.array([-1.5, 2.0]),
        np.array([-1.0, 1.5]),
        np.array([-0.5, 1.2]),
        np.array([0.0, 1.0]),
        np.array([0.5, 1.0]),
        np.array([1.0, 1.0])
    ]
    
    # 创建平滑路径
    smooth_path, z_smooth = create_smooth_path(path_points, rosenbrock_function)
    
    # 绘制原始路径点
    x_orig = [p[0] for p in path_points]
    y_orig = [p[1] for p in path_points]
    z_orig = [rosenbrock_function(p) for p in path_points]
    
    # 绘制平滑路径
    x_smooth = [p[0] for p in smooth_path]
    y_smooth = [p[1] for p in smooth_path]
    
    # 绘制原始路径（直线段）
    ax.plot(x_orig, y_orig, z_orig, 'r--', linewidth=2, alpha=0.7, label='原始路径（直线段）')
    ax.scatter(x_orig, y_orig, z_orig, c='red', s=50, alpha=0.8)
    
    # 绘制平滑路径
    ax.plot(x_smooth, y_smooth, z_smooth, 'b-', linewidth=3, alpha=0.9, label='平滑路径')
    
    # 标记起点和终点
    ax.scatter(x_orig[0], y_orig[0], z_orig[0], c='green', s=100, marker='o', label='起点')
    ax.scatter(x_orig[-1], y_orig[-1], z_orig[-1], c='yellow', s=100, marker='*', label='终点')
    
    # 设置标签
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('平滑曲线测试')
    
    # 设置坐标轴范围
    ax.set_xlim(x_range)
    ax.set_ylim(y_range)
    ax.set_zlim(0, 1000)
    
    plt.legend()
    plt.tight_layout()
    plt.savefig('smooth_curve_test.png', dpi=150, bbox_inches='tight')
    plt.show()
    
    print("平滑曲线测试完成，请检查smooth_curve_test.png文件")
    print(f"原始路径点数: {len(path_points)}")
    print(f"平滑路径点数: {len(smooth_path)}")

if __name__ == "__main__":
    test_smooth_curve()
