"""
BoltzmannBridge - Qt Interface for Boltzmann Machine

Provides PyQt5/PyQt6 signals and slots for bidirectional communication
between the BM backend algorithm and QML frontend.

Uses BridgeProperty metaclass for automatic signal generation when
properties change.
"""

from PyQt5.QtCore import pyqtSlot, pyqtSignal, QObject
from typing import List
import numpy as np

from nn_sandbox.bridges.bridge import Bridge, BridgeProperty
from nn_sandbox.backend.algorithms.bm_algorithm import BoltzmannMachine


class BoltzmannBridge(Bridge):
    """
    Bridge connecting Boltzmann Machine backend to QML frontend.
    
    Provides:
    - Qt Properties (auto-notify on change): temperature, energy, state, probabilities, etc.
    - PyQt Slots: parameter control, simulation control
    - State synchronization: automatic backend→frontend updates
    """
    
    # Qt Properties with automatic signals (use concrete default values)
    temperature = BridgeProperty(1.0)
    energy = BridgeProperty(0.0)
    current_state = BridgeProperty([])
    current_state_id = BridgeProperty(0)
    iteration = BridgeProperty(0)
    thermal_equilibrium = BridgeProperty(False)
    probabilities = BridgeProperty([])
    visit_counts = BridgeProperty([])
    state_history = BridgeProperty([])
    energy_history = BridgeProperty([])
    temperature_history = BridgeProperty([])
    
    # Statistics
    visited_state_count = BridgeProperty(0)
    total_visits = BridgeProperty(0)
    
    # Network configuration
    weights_matrix = BridgeProperty([])
    biases_vector = BridgeProperty([])
    
    # Energy landscape (for visualization)
    energy_landscape = BridgeProperty({})
    
    # Status signals for UI feedback
    anneal_started = pyqtSignal()
    anneal_completed = pyqtSignal()
    equilibrium_reached = pyqtSignal()
    step_completed = pyqtSignal()
    
    def __init__(self, num_neurons: int = 3):
        """
        Initialize Boltzmann Machine bridge.
        
        Args:
            num_neurons: Number of neurons (typically 3 for visualization)
        """
        super().__init__()

        # store config
        self._num_neurons = num_neurons

        # Create backend algorithm
        self._algorithm = BoltzmannMachine(num_neurons=num_neurons)

        # Synchronize initial state
        self._sync_state_from_backend()
    
    def _sync_state_from_backend(self):
        """Synchronize all properties from backend to Qt properties."""
        self.temperature = self._algorithm.get_temperature()
        self.energy = self._algorithm.get_current_energy()
        self.current_state = self._algorithm.get_state_vector()
        self.current_state_id = self._algorithm.get_state_index()
        self.iteration = self._algorithm.get_iteration_count()
        self.thermal_equilibrium = self._algorithm.get_thermal_equilibrium_status()
        
        self.probabilities = self._algorithm.get_probabilities()
        self.visit_counts = self._algorithm.get_visit_counts()
        self.state_history = self._algorithm.get_state_history()
        self.energy_history = self._algorithm.get_energy_history()
        self.temperature_history = self._algorithm.get_temperature_history()
        
        # Statistics
        stats = self._algorithm.get_statistics()
        self.visited_state_count = stats['visited_states']
        self.total_visits = stats['total_visits']
        
        self.weights_matrix = self._algorithm.get_weights_matrix()
        self.biases_vector = self._algorithm.get_biases_vector()
        
        # Energy landscape
        self.energy_landscape = self._algorithm.get_energy_landscape()
    
    def on_notify(self):
        """Called when backend algorithm state changes (observer pattern)."""
        self._sync_state_from_backend()
    
    # ==================== PyQt Slots for Control ====================
    
    @pyqtSlot()
    def step(self):
        """
        Execute one Gibbs sampling step.
        
        - Randomly select a neuron
        - Update based on Boltzmann probability
        - Emit step_completed signal
        """
        self._algorithm.step()
        self.step_completed.emit()
        self._sync_state_from_backend()
    
    @pyqtSlot(float, float, float, int)
    def anneal(self, initial_temp: float, final_temp: float, 
               cooling_rate: float, steps_per_temp: int):
        """
        Run simulated annealing from high to low temperature.
        
        This demonstrates temperature-dependent exploration:
        - High temperature: chaotic state exploration
        - Low temperature: convergence to low-energy states
        
        Args:
            initial_temp: Starting temperature (e.g., 3.0)
            final_temp: Final temperature (e.g., 0.01)
            cooling_rate: Cooling factor (e.g., 0.05)
            steps_per_temp: Gibbs steps at each temperature
        """
        self.anneal_started.emit()
        
        result = self._algorithm.anneal(
            initial_temp=initial_temp,
            final_temp=final_temp,
            cooling_rate=cooling_rate,
            steps_per_temp=steps_per_temp
        )
        
        if result['thermal_equilibrium']:
            self.equilibrium_reached.emit()
        self.anneal_completed.emit()
        self._sync_state_from_backend()
    
    @pyqtSlot(float)
    def set_temperature(self, temperature: float):
        """
        Set network temperature and update probabilities.
        
        Temperature controls the "softness" of Boltzmann distribution:
        - T > 1.0: More exploration, less deterministic
        - T = 1.0: Standard Boltzmann distribution
        - T < 1.0: More deterministic, lower entropy
        
        Args:
            temperature: New temperature (must be > 0)
        """
        if temperature > 0:
            self._algorithm.set_temperature(temperature)
            self._sync_state_from_backend()
    
    @pyqtSlot(list)
    def set_state(self, state: list):
        """
        Set the network state directly.
        
        Args:
            state: List of binary values [0 or 1, ...]
        """
        self._algorithm.set_state(state)
        self._sync_state_from_backend()
    
    @pyqtSlot()
    def randomize_state(self):
        """Randomly initialize the network state."""
        self._algorithm.randomize_state()
        self._sync_state_from_backend()
    
    @pyqtSlot()
    def randomize_weights(self):
        """Randomize weights and biases."""
        num_neurons = self._algorithm._num_neurons
        
        # Generate new symmetric random weights
        random_vals = np.random.randn(num_neurons, num_neurons) * 0.5
        weights = (random_vals + random_vals.T) / 2
        np.fill_diagonal(weights, 0)
        
        # Generate new random biases
        biases = np.random.randn(num_neurons) * 0.3
        
        self._algorithm.set_weights_and_biases(weights, biases)
        self._sync_state_from_backend()
    
    @pyqtSlot(list, list)
    def set_custom_weights(self, weights: list, biases: list):
        """
        Set custom weights and biases for network.
        
        Args:
            weights: Weight matrix as nested list
            biases: Bias vector as list
        """
        self._algorithm.set_weights_and_biases(
            np.array(weights),
            np.array(biases)
        )
        self._sync_state_from_backend()
    
    @pyqtSlot()
    def reset(self):
        """Reset entire network to initial state."""
        self._algorithm.reset()
        self._sync_state_from_backend()
    
    # ==================== Query Methods (for read-only access) ====================
    
    @pyqtSlot(result=list)
    def get_state_vector(self) -> list:
        """Get current state as list."""
        return self._algorithm.get_state_vector()
    
    @pyqtSlot(result=float)
    def get_energy(self) -> float:
        """Get current energy."""
        return self._algorithm.get_current_energy()
    
    @pyqtSlot(result=float)
    def get_temperature(self) -> float:
        """Get current temperature."""
        return self._algorithm.get_temperature()
    
    @pyqtSlot(result=list)
    def get_probabilities(self) -> list:
        """Get Boltzmann distribution probabilities."""
        return self._algorithm.get_probabilities()
    
    @pyqtSlot(result=int)
    def get_iteration_count(self) -> int:
        """Get total iterations."""
        return self._algorithm.get_iteration_count()
    
    @pyqtSlot(result=bool)
    def is_in_thermal_equilibrium(self) -> bool:
        """Check if system is in thermal equilibrium."""
        return self._algorithm.get_thermal_equilibrium_status()
    
    @pyqtSlot(result=list)
    def get_weights(self) -> list:
        """Get weight matrix."""
        return self._algorithm.get_weights_matrix()
    
    @pyqtSlot(result=list)
    def get_biases(self) -> list:
        """Get biases vector."""
        return self._algorithm.get_biases_vector()
    
    @pyqtSlot(result=dict)
    def get_statistics(self) -> dict:
        """Get comprehensive statistics."""
        return self._algorithm.get_statistics()
    
    @pyqtSlot(result=dict)
    def get_energy_landscape(self) -> dict:
        """Get energy and probability for all states."""
        return self._algorithm.get_energy_landscape()
    
    @pyqtSlot(int, result=list)
    def get_state_from_index(self, index: int) -> list:
        """Convert state index (0-7) to state vector."""
        state = self._algorithm._index_to_state(index)
        return state.tolist()
    
    @pyqtSlot(list, result=int)
    def get_state_index(self, state: list) -> int:
        """Convert state vector to state index (0-7)."""
        return self._algorithm._state_to_index(np.array(state, dtype=int))
