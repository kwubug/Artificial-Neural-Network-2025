import time
import math
import operator
from copy import deepcopy

import numpy as np

from . import TraningAlgorithm
from ..neurons import Som2Neuron
from ..utils import dist, flatten


class Som2Algorithm(TraningAlgorithm):
    """
    SOM algorithm configured to match the assignment requirements:
      - 5x5 grid
      - total steps = 10_000 (iterations)
      - learning rate: 0.5 -> 0.04 linearly in first 1000 steps, then -> 0 at 10_000
      - neighborhood radius (in nodes): sigma(0)=2, linearly -> 0 at 1000, then 0
      - keep weight snapshots every 200 steps
      - compute final BMU mapping for the given inputs
    """
    def __init__(
        self,
        dataset,
        total_epoches=10,                       # kept for compatibility with Bridge but unused for stopping
        initial_learning_rate=0.5,              # <- 题目：学习率初值 0.5
        initial_standard_deviation=2.0,         # <- 题目：初始邻域半径 2 个节点
        topology_shape=None,
        total_steps: int = 10_000,              # <- 题目：训练 10,000 步
        snapshot_interval: int = 200            # <- 题目：每 200 步保留一次权向量
    ):
        super().__init__(dataset, total_epoches)
        self._initial_learning_rate = initial_learning_rate
        self._initial_standard_deviation = initial_standard_deviation

        # default topology is 5x5 to match the assignment
        self.topology_shape = topology_shape if topology_shape else [5, 5]

        # assignment-specific runtime control
        self.total_steps = int(total_steps)
        self.snapshot_interval = int(snapshot_interval)

        # runtime states
        self.current_iterations = 0
        self.snapshots = []          # list[List[List[np.ndarray]]] -> weight grid snapshots
        self.final_mapping = []      # list of ((i, j), sample_index)

    # ---------------- core routine ----------------
    def run(self):
        self._initialize_neurons()
        n = len(self._dataset)
        for self.current_iterations in range(self.total_steps):
            if self._should_stop:
                break
            # cycle through dataset (shuffle once per pass for variety)
            if self.current_iterations % n == 0:
                np.random.shuffle(self._dataset)
            self._iterate()

            # snapshot every 200 steps (including step 0)
            if self.current_iterations % self.snapshot_interval == 0:
                self.snapshots.append(self._snapshot_weights())

        # compute BMU mapping at the end for all distinct inputs
        self.final_mapping = self._compute_final_mapping()

    # -------------- helpers --------------
    def _initialize_neurons(self):
        data_range = tuple(zip(np.amin(self._dataset[:, :-1], axis=0),
                               np.amax(self._dataset[:, :-1], axis=0)))
        self._neurons = [[Som2Neuron(data_range)
                          for _ in range(self.topology_shape[0])]
                         for _ in range(self.topology_shape[1])]

    def _iterate(self):
        self._feed_forward()
        winner = self._get_winner()
        self._adjust_synaptic_weight(winner)

    def _feed_forward(self):
        for row in self._neurons:
            for neuron in row:
                neuron.data = self.current_data[:-1]

    def _get_winner(self):
        return min(flatten(self._neurons), key=operator.attrgetter('dist'))

    def _adjust_synaptic_weight(self, winner: Som2Neuron):
        # locate winner index (i, j)
        for i, row in enumerate(self._neurons):
            if winner in row:
                winner_index = (i, row.index(winner))
                break

        sigma = self.current_standard_deviation
        eta = self.current_learning_rate

        for i, row in enumerate(self._neurons):
            for j, neuron in enumerate(row):
                # gaussian neighborhood with sigma(t) in "node units"
                h = 1.0 if sigma == 0 else math.exp(
                    -dist(winner_index, (i, j)) ** 2 / (2 * sigma ** 2)
                )
                neuron.synaptic_weight += (
                    eta * h * (self.current_data[:-1] - neuron.synaptic_weight)
                )

    # ---------- utilities ----------
    def _snapshot_weights(self):
        """Deep-copy current synaptic weights as a 2D list for persistence."""
        return [[neuron.synaptic_weight.copy() for neuron in row]
                for row in self._neurons]

    def _compute_final_mapping(self):
        """
        Return list of ((i, j), k) denoting BMU coordinate for each unique input x^(k).
        """
        # extract unique inputs (ignore label column if present)
        X = self._dataset[:, :-1]
        # keep order of first occurrence
        seen = []
        idxs = []
        for k, x in enumerate(X):
            tup = tuple(x.tolist())
            if tup not in seen:
                seen.append(tup)
                idxs.append(k)

        result = []
        for k in idxs:
            # feed once
            for row in self._neurons:
                for neuron in row:
                    neuron.data = self._dataset[k, :-1]
            w = self._get_winner()
            # winner coordinates
            for i, row in enumerate(self._neurons):
                for j, neuron in enumerate(row):
                    if neuron is w:
                        result.append(((i, j), k))
                        break
        return result

    # ---------------- properties ----------------
    @property
    def current_data(self):
        # iterate over dataset cyclically
        return self._dataset[self.current_iterations % len(self._dataset)]

    @property
    def current_learning_rate(self):
        """
        Piecewise-linear schedule:
          t in [0, 1000]: 0.5 -> 0.04
          t in (1000, 10000]: 0.04 -> 0
        """
        t = self.current_iterations
        if t <= 1000:
            # 0.5 - linear_to(0.04) over 1000 steps
            return 0.5 + (0.04 - 0.5) * (t / 1000.0)
        elif t <= 10000:
            # 0.04 -> 0 over the remaining 9000 steps
            return max(0.0, 0.04 * (1.0 - (t - 1000.0) / 9000.0))
        else:
            return 0.0

    @property
    def current_standard_deviation(self):
        """
        Neighborhood radius in node units:
          sigma(0)=2, linearly -> 0 by t=1000, then stays 0
        """
        t = self.current_iterations
        if t <= 1000:
            return max(0.0, 2.0 * (1.0 - t / 1000.0))
        else:
            return 0.0
