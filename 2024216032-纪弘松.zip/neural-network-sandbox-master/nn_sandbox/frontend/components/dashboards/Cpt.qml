import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import ".." // 修改为实际路径

Page {
    name: 'CPTNN'

    // 绑定到 Python 中的属性和方法
    property var weights: CPT.weightsList
    property int numNeurons: CPT.numNeurons
    property int classification: CPT.classification

    ColumnLayout {

        // 输入样本
        GroupBox {
            title: "Input Sample"
            Layout.fillWidth: true
            RowLayout {
                spacing: 10
                TextField {
                    id: inputSample
                    width: 250
                    placeholderText: "Enter sample (e.g., 1,0,0)"
                }
                Button {
                    text: "Classify Sample"
                    onClicked: {
                        // 将输入的文本样本转为数组
                        var sample = inputSample.text.split(",").map(function(x) { return parseInt(x.trim()); });
                        if (sample.length === CPT.inputSize) {
                            CPT.start()
                            CPT.classifySample(sample);
                        } else {
                            console.log("Invalid input sample size. Must be " + CPT.inputSize + " elements.");
                        }
                    }
                }
            }
        }

        // 网络信息
        GroupBox {
            title: "Network Information"
            Layout.fillWidth: true
            GridLayout {
                columns: 2

                Label { text: "Number of Neurons:" }
                Label { text: numNeurons }

                Label { text: "Weights:" }
                ListView {
                    id: weightsView
                    width: parent.width
                    height: 150
                    model: weights
                    delegate: Text {
                        text: modelData.join(", ")
                    }
                }
            }
        }

        // 显示分类结果
        GroupBox {
            title: "Classification Result"
            Layout.fillWidth: true
            Label {
                id: classifyResult
                text: "Result: W" + CPT.classification
                Layout.alignment: Qt.AlignHCenter
            }
        }
    }

}
