from PyQt5.QtCore import pyqtSignal, QThread, pyqtProperty,pyqtSlot
import numpy as np
import time
class DhnnBridge(QThread):
    stateUpdated = pyqtSignal(list)
    attractorFound = pyqtSignal(bool, list)
    energyCalculated = pyqtSignal(float)

    # 定义需要通知的信号
    _current_state = []
    _attractor_found = False
    _energy = 0.0

    # 用于属性变化时的信号
    currentStateChanged = pyqtSignal()
    attractorFoundChanged = pyqtSignal()
    energyChanged = pyqtSignal()
    # setInitialStateSignal = pyqtSignal(list)

    def __init__(self, initial_state=None, parent=None):
        super().__init__(parent)
        self.weights = np.array([
            [0, 1, 1, -1, 1],
            [1, 0, -1, -3, 3],
            [1, -1, 0, 1, -1],
            [-1, -3, 1, 0, -3],
            [1, 3, -1, -3, 0]
        ])
        self._initial_state = initial_state or [-1, -1, 1, 1, -1]  # 设置初始状态

    # 使用 pyqtProperty 创建可绑定属性
    @pyqtProperty(list, notify=currentStateChanged)
    def currentState(self):
        return self._current_state

    @currentState.setter
    def currentState(self, value):
        if self._current_state != value:
            self._current_state = value
            self.currentStateChanged.emit()

    @pyqtProperty(bool, notify=attractorFoundChanged)
    def attractorFound(self):
        return self._attractor_found

    @attractorFound.setter
    def attractorFound(self, value):
        if self._attractor_found != value:
            self._attractor_found = value
            self.attractorFoundChanged.emit()

    @pyqtProperty(float, notify=energyChanged)
    def energy(self):
        return self._energy

    @energy.setter
    def energy(self, value):
        if self._energy != value:
            self._energy = value
            self.energyChanged.emit()

    def update_state(self, state):
        """异步更新状态"""
        new_state = state.copy()
        steps = len(state)
        for i in range(steps):
            net_input = np.dot(self.weights[i], new_state)
            if net_input >= 0:
                new_state[i] = 1
            else:
                new_state[i] = -1

        # 更新属性并通知前端
        # self.currentState = list(new_state)
        # self.stateUpdated.emit(new_state)
        return new_state


    def find_attractor(self, state):
        """从初始状态寻找吸引子"""
        for _ in range(len(state)):
            new_state = self.update_state(state)
            if np.array_equal(new_state, state):
                self.attractorFound = True
                self.currentState = list(new_state)
                self.attractorFoundChanged.emit()
                return True, new_state
            state = new_state

        self.attractorFound = False
        return False, []

    def calculate_energy(self, state):
        """计算能量"""
        energy = -0.5 * np.dot(state, np.dot(self.weights, state))
        self.energy = energy
        self.energyCalculated.emit(energy)
        return energy

    @pyqtSlot(list)
    def setInitialState(self, state):
        print("setInitialState called with:", state)  # 调试信息
        self.initial_state = state
        print(self.initial_state)

    def run(self):
        """线程的主运行方法"""
        print("Finding attractor in thread with initial state:", self.initial_state)
        state = self.initial_state.copy()

        self.find_attractor(state)
        self.calculate_energy(state)
