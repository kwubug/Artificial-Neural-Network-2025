import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from itertools import product  # 修复第一个错误
from collections import Counter
import random

class BoltzmannMachine3N:
    """
    3-Neuron Boltzmann Machine
    States: 3 binary neurons (±1)
    Energy: E = -0.5 Σ w_ij s_i s_j - Σ b_i s_i
    """
    
    def __init__(self, weights, biases, temperature=1.0):
        self.n_neurons = 3
        self.weights = np.array(weights)
        self.biases = np.array(biases)
        self.T = temperature
        
        assert self.weights.shape == (3, 3)
        assert np.allclose(self.weights, self.weights.T)
        assert np.all(np.diag(self.weights) == 0)
        
        self.state = np.random.choice([-1, 1], size=3)
        self.all_states = np.array(list(product([-1, 1], repeat=3)))
        self.state_history = []
        self.energy_history = []
        self.step_count = 0
    
    def energy(self, state):
        return -0.5 * state @ self.weights @ state - np.dot(self.biases, state)
    
    def probability_state(self, state):
        return np.exp(-self.energy(state) / self.T)
    
    def get_equilibrium_distribution(self):
        probabilities = np.array([self.probability_state(s) for s in self.all_states])
        return probabilities / np.sum(probabilities)
    
    def update_step(self):
        i = np.random.randint(0, self.n_neurons)
        net_input = np.dot(self.weights[i, :], self.state) + self.biases[i]
        prob_on = 1 / (1 + np.exp(-net_input / self.T))
        self.state[i] = 1 if np.random.rand() < prob_on else -1
        self.step_count += 1
        return self.state.copy()
    
    def run(self, steps=5000, burn_in=1000):
        print(f"\nBM Simulation: {steps} steps (burn-in: {burn_in})")
        print(f"Initial state: {self.state}, Energy: {self.energy(self.state):.3f}")
        
        self.state_history = []
        self.energy_history = []
        
        for step in range(steps):
            current_state = self.update_step()
            current_energy = self.energy(current_state)
            
            if step >= burn_in:
                self.state_history.append(current_state.copy())
                self.energy_history.append(current_energy)
            
            if step % 2000 == 0:
                print(f"Step {step}: State={current_state}, Energy={current_energy:.3f}")
        
        print(f"Final state: {self.state}, Energy: {self.energy(self.state):.3f}")
        return np.array(self.state_history), np.array(self.energy_history)
    
    def visualize_network(self, save_path=None):
        fig, ax = plt.subplots(figsize=(8, 6))
        
        # 神经元位置
        positions = {
            0: np.array([0, 1]),
            1: np.array([-0.866, -0.5]),
            2: np.array([0.866, -0.5])
        }
        
        for i in range(self.n_neurons):
            pos = positions[i]
            color = 'red' if self.state[i] == 1 else 'blue'
            size = 3000 if self.state[i] == 1 else 2000
            ax.scatter(pos[0], pos[1], s=size, c=color, alpha=0.7, edgecolors='black')
            ax.text(pos[0], pos[1], f'N{i}\n({self.state[i]:+d})', 
                   ha='center', va='center', fontsize=12, fontweight='bold')
            ax.text(pos[0], pos[1]+0.3, f'b={self.biases[i]:.2f}', 
                   ha='center', va='center', fontsize=9)
        
        # 权重连线
        for i in range(self.n_neurons):
            for j in range(i+1, self.n_neurons):
                pos_i, pos_j = positions[i], positions[j]
                weight = self.weights[i, j]
                linewidth = abs(weight) * 3
                color = 'green' if weight > 0 else 'purple'
                alpha = min(abs(weight), 1.0)
                
                ax.plot([pos_i[0], pos_j[0]], [pos_i[1], pos_j[1]], 
                       linewidth=linewidth, color=color, alpha=alpha)
                
                mid = (pos_i + pos_j) / 2
                ax.text(mid[0], mid[1], f'{weight:.2f}', 
                       ha='center', va='center', fontsize=9, 
                       bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.5, 1.5)
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_title(f'Boltzmann Machine (T={self.T})\nEnergy: {self.energy(self.state):.3f}', 
                    fontsize=14, fontweight='bold')
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
        return fig
    
    def visualize_state_space(self, save_path=None):
        """修复：使用3D投影坐标轴"""
        theory_dist = self.get_equilibrium_distribution()
        
        if len(self.state_history) > 0:
            state_indices = np.array([self._state_to_index(s) for s in self.state_history])
            counts = Counter(state_indices)
            total = sum(counts.values())
            empirical_dist = np.array([counts.get(i, 0) / total for i in range(8)])
        else:
            empirical_dist = np.zeros(8)
        
        # 修复1：创建3D坐标轴
        fig = plt.figure(figsize=(14, 6))
        ax1 = fig.add_subplot(1, 2, 1, projection='3d')  # 3D投影
        ax2 = fig.add_subplot(1, 2, 2)
        
        # 立方体顶点
        cube_coords = np.array([
            [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
            [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]
        ])
        
        # 修复2：绘制3D散点图
        for i, (state, coord) in enumerate(zip(self.all_states, cube_coords)):
            color = plt.cm.viridis(theory_dist[i])
            ax1.scatter(coord[0], coord[1], coord[2], 
                       s=theory_dist[i]*5000+100, 
                       c=[color], alpha=0.7, edgecolors='black')
            
            state_str = f'({state[0]:+d},{state[1]:+d},{state[2]:+d})'
            ax1.text(coord[0]*1.1, coord[1]*1.1, coord[2]*1.1, 
                    state_str, fontsize=8, ha='center')
            
            energy_val = self.energy(state)
            ax1.text(coord[0]*0.8, coord[1]*0.8, coord[2]*0.8, 
                    f'E={energy_val:.2f}', fontsize=7, ha='center')
        
        # 绘制边
        edges = [(0,1), (1,2), (2,3), (3,0),
                 (4,5), (5,6), (6,7), (7,4),
                 (0,4), (1,5), (2,6), (3,7)]
        for e in edges:
            p1, p2 = cube_coords[e[0]], cube_coords[e[1]]
            ax1.plot([p1[0], p2[0]], [p1[1], p2[1]], [p1[2], p2[2]], 
                    color='gray', alpha=0.5, linewidth=0.5)
        
        ax1.set_title('State Space (3D Cube)\nSize = Probability', fontsize=12)
        ax1.set_xlabel('Neuron 1')
        ax1.set_ylabel('Neuron 2')
        ax1.set_zlabel('Neuron 3')
        
        # 概率分布对比
        states = [f'({s[0]:+d},{s[1]:+d},{s[2]:+d})' for s in self.all_states]
        x = np.arange(8)
        
        width = 0.35
        ax2.bar(x - width/2, theory_dist, width, label='Theory', alpha=0.8, color='skyblue')
        ax2.bar(x + width/2, empirical_dist, width, label='Empirical', alpha=0.8, color='coral')
        
        ax2.set_xlabel('States')
        ax2.set_ylabel('Probability')
        ax2.set_title('Equilibrium Distribution', fontsize=12)
        ax2.set_xticks(x)
        ax2.set_xticklabels(states, rotation=45, ha='right')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
        return fig
    
    def visualize_dynamics(self, save_path=None):
        if len(self.state_history) == 0: return
        
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(14, 10))
        
        steps = np.arange(len(self.energy_history))
        ax1.plot(steps, self.energy_history, 'b-', linewidth=1, alpha=0.7)
        ax1.set_xlabel('Step')
        ax1.set_ylabel('Energy')
        ax1.set_title('Energy Dynamics')
        ax1.grid(True, alpha=0.3)
        
        state_array = np.array(self.state_history)
        for i in range(3):
            ax2.plot(steps, state_array[:, i], label=f'N{i}', marker='o', markersize=2)
        ax2.set_xlabel('Step')
        ax2.set_ylabel('State')
        ax2.set_title('Neuron States')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        ax2.set_yticks([-1, 0, 1])
        
        state_indices = np.array([self._state_to_index(s) for s in self.state_history])
        ax3.hist(state_indices, bins=range(9), align='left', rwidth=0.8, 
                color='darkslateblue', alpha=0.7)
        ax3.set_xlabel('State Index')
        ax3.set_ylabel('Frequency')
        ax3.set_title('State Histogram')
        ax3.set_xticks(range(8))
        
        energies = np.array(self.energy_history)
        mean_energy = np.mean(energies)
        acf = np.correlate(energies - mean_energy, energies - mean_energy, mode='full')
        acf = acf[len(acf)//2:] / acf[len(acf)//2]
        ax4.plot(acf[:100], 'g-', linewidth=2)
        ax4.set_xlabel('Lag')
        ax4.set_ylabel('Autocorrelation')
        ax4.set_title('Energy Autocorrelation')
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
        return fig
    
    def _state_to_index(self, state):
        return int((state[0] + 1) / 2 * 4 + (state[1] + 1) / 2 * 2 + (state[2] + 1) / 2)


def demo_boltzmann_machine():
    print("="*60)
    print("3-Neuron Boltzmann Machine Simulation")
    print("="*60)
    
    weights = np.array([[0.0, 0.5, -0.3], [0.5, 0.0, 0.4], [-0.3, 0.4, 0.0]])
    biases = np.array([0.1, -0.2, 0.3])
    temperature = 1.0
    
    print(f"\nParameters:\nWeights:\n{weights}\nBiases: {biases}\nT: {temperature}")
    
    bm = BoltzmannMachine3N(weights, biases, temperature)
    
    print("\n[1] Network Structure")
    bm.visualize_network(save_path="bm_network.png")
    
    print("\n[2] Running simulation...")
    state_hist, energy_hist = bm.run(steps=5000, burn_in=1000)
    
    print("\n[3] Dynamics")
    bm.visualize_dynamics(save_path="bm_dynamics.png")
    
    print("\n[4] State Space & Equilibrium")
    bm.visualize_state_space(save_path="bm_state_space.png")
    
    print("\n" + "="*60)
    print("EQUILIBRIUM ANALYSIS")
    print("="*60)
    
    theory_dist = bm.get_equilibrium_distribution()
    
    print("\nTheoretical Distribution:")
    for i, (state, prob) in enumerate(zip(bm.all_states, theory_dist)):
        energy_val = bm.energy(state)
        print(f"State {i}: ({state[0]:+d},{state[1]:+d},{state[2]:+d})  E={energy_val:6.3f}  P={prob:.6f}")
    
    if len(state_hist) > 0:
        state_indices = np.array([bm._state_to_index(s) for s in state_hist])
        empirical_dist = np.array([np.sum(state_indices == i) / len(state_hist) for i in range(8)])
        
        print("\nEmpirical Distribution:")
        for i, (state, prob) in enumerate(zip(bm.all_states, empirical_dist)):
            print(f"State {i}: ({state[0]:+d},{state[1]:+d},{state[2]:+d})  P={prob:.6f}")
        
        kl_div = np.sum(theory_dist * np.log(theory_dist / (empirical_dist + 1e-10)))
        print(f"\nKL Divergence: {kl_div:.6f}")
        
        most_likely_idx = np.argmax(theory_dist)
        print(f"\nMost Probable State: {bm.all_states[most_likely_idx]} (P={theory_dist[most_likely_idx]:.4f})")
    
    print("\n" + "="*60)
    print("✅ Simulation Complete!")
    print("="*60)


if __name__ == "__main__":
    np.random.seed(42)
    demo_boltzmann_machine()