
import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, sigmoid_derivative


class BpAlgorithm(PredictiveAlgorithm):
    """ Backpropagation algorithm. """

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.8, search_iteration_constant=10000,
                 momentum_weight=0.5, test_ratio=0.3, hidden_layer_size=5):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        self._momentum_weight = momentum_weight
        self.hidden_layer_size = hidden_layer_size

        # for momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _iterate(self):
        result = self._feed_forward(self.current_data[:-1])
        deltas = self._pass_backward(self._normalize(self.current_data[-1]),
                                     result)
        self._adjust_synaptic_weights(deltas)

    def _initialize_neurons(self):
        """ Build the neuron network with single hidden layer and single output. """
        input_size = len(self.training_dataset[0]) - 1  # exclude label

        # Hidden layer neurons
        hidden_neurons = []
        for _ in range(self.hidden_layer_size):
            neuron = Perceptron(sigmoid)
            # Initialize with random weights
            neuron.synaptic_weight = np.random.uniform(-1, 1, input_size + 1)  # +1 for bias
            hidden_neurons.append(neuron)

        # Output layer neuron
        output_neuron = Perceptron(sigmoid)
        output_neuron.synaptic_weight = np.random.uniform(-1, 1, self.hidden_layer_size + 1)

        self._neurons = [hidden_neurons, [output_neuron]]

    def _feed_forward(self, data):
        # Input to hidden layer
        hidden_outputs = []
        for neuron in self._neurons[0]:
            neuron.data = data
            hidden_outputs.append(neuron.result)

        # Hidden to output layer
        self._neurons[1][0].data = hidden_outputs
        return self._neurons[1][0].result

    def _pass_backward(self, expect, result):
        """ Calculate the delta for each neuron using backpropagation. """
        deltas = {}

        # Output layer delta
        output_neuron = self._neurons[1][0]
        output_error = expect - result
        output_delta = output_error * sigmoid_derivative(result)
        deltas[output_neuron] = output_delta

        # Hidden layer deltas
        for i, hidden_neuron in enumerate(self._neurons[0]):
            hidden_error = output_delta * output_neuron.synaptic_weight[i + 1]  # +1 for bias
            hidden_delta = hidden_error * sigmoid_derivative(hidden_neuron.result)
            deltas[hidden_neuron] = hidden_delta

        return deltas

    def _adjust_synaptic_weights(self, deltas):
        # Update output layer weights
        output_neuron = self._neurons[1][0]
        hidden_outputs = [neuron.result for neuron in self._neurons[0]]
        hidden_with_bias = [-1] + hidden_outputs  # add bias term

        for i in range(len(output_neuron.synaptic_weight)):
            self._synaptic_weight_diff[output_neuron] = (
                    self._synaptic_weight_diff[output_neuron] * self._momentum_weight
                    + self.current_learning_rate * deltas[output_neuron] * hidden_with_bias[i]
            )
            output_neuron.synaptic_weight[i] += self._synaptic_weight_diff[output_neuron]

        # Update hidden layer weights
        current_input = self.current_data[:-1]
        input_with_bias = [-1] + list(current_input)  # add bias term

        for hidden_neuron in self._neurons[0]:
            for i in range(len(hidden_neuron.synaptic_weight)):
                self._synaptic_weight_diff[hidden_neuron] = (
                        self._synaptic_weight_diff[hidden_neuron] * self._momentum_weight
                        + self.current_learning_rate * deltas[hidden_neuron] * input_with_bias[i]
                )
                hidden_neuron.synaptic_weight[i] += self._synaptic_weight_diff[hidden_neuron]

    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0
        correct_count = 0
        for data in dataset:
            result = self._feed_forward(data[:-1])
            expect = self._normalize(data[-1])
            interval = 1 / (2 * len(self.group_types))
            if expect - interval < result < expect + interval:
                correct_count += 1
        if correct_count == 0:
            return 0
        return correct_count / len(dataset)

    def _normalize(self, value):
        """ Normalize expected output. """
        return (2 * (value - np.amin(self.group_types)) + 1) / (2 * len(self.group_types))

