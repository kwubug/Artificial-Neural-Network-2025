import math
import numpy as np

from . import PredictiveAlgorithm


class BpAlgorithm(PredictiveAlgorithm):
    """Three-layer feedforward neural network with backpropagation learning algorithm."""

    def __init__(self, dataset, total_epoches=10, most_correct_rate=None,
                 initial_learning_rate=0.5, search_iteration_constant=10000,
                 test_ratio=0.3, input_nodes=2, hidden_nodes=5, output_nodes=1,
                 sigmoid_type='unipolar'):
        super().__init__(dataset, total_epoches, most_correct_rate,
                         initial_learning_rate, search_iteration_constant,
                         test_ratio)
        
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.sigmoid_type = sigmoid_type  # 'unipolar' or 'bipolar'
        
        # Weights: W1 (input to hidden), W2 (hidden to output)
        self.W1 = None  # shape: (input_nodes, hidden_nodes)
        self.W2 = None  # shape: (hidden_nodes, output_nodes)
        
        # Biases
        self.b1 = None  # shape: (hidden_nodes,)
        self.b2 = None  # shape: (output_nodes,)
        
        # Store layer outputs for backpropagation
        self.hidden_output = None
        self.final_output = None
        self.input_data = None

    def _initialize_neurons(self):
        """Initialize weights and biases with random values in [-1, 1]."""
        # Initialize weights with random values in [-1, 1]
        self.W1 = np.random.uniform(-1, 1, (self.input_nodes, self.hidden_nodes))
        self.W2 = np.random.uniform(-1, 1, (self.hidden_nodes, self.output_nodes))
        
        # Initialize biases with random values in [-1, 1]
        self.b1 = np.random.uniform(-1, 1, self.hidden_nodes)
        self.b2 = np.random.uniform(-1, 1, self.output_nodes)

    def _sigmoid(self, x):
        """Sigmoid activation function (unipolar or bipolar)."""
        if self.sigmoid_type == 'unipolar':
            # Unipolar sigmoid: f(x) = 1 / (1 + exp(-x)), range [0, 1]
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
        elif self.sigmoid_type == 'bipolar':
            # Bipolar sigmoid: f(x) = 2 / (1 + exp(-x)) - 1, range [-1, 1]
            return 2 / (1 + np.exp(-np.clip(x, -500, 500))) - 1
        else:
            raise ValueError("sigmoid_type must be 'unipolar' or 'bipolar'")

    def _sigmoid_derivative(self, x):
        """Derivative of sigmoid function."""
        if self.sigmoid_type == 'unipolar':
            # For unipolar: f'(x) = f(x) * (1 - f(x))
            return x * (1 - x)
        elif self.sigmoid_type == 'bipolar':
            # For bipolar: f'(x) = 0.5 * (1 - f(x)^2)
            return 0.5 * (1 - x * x)
        else:
            raise ValueError("sigmoid_type must be 'unipolar' or 'bipolar'")

    def _forward_propagation(self, input_data):
        """Perform forward propagation through the three-layer network."""
        self.input_data = input_data
        
        # Hidden layer
        hidden_input = np.dot(input_data, self.W1) + self.b1
        self.hidden_output = self._sigmoid(hidden_input)
        
        # Output layer
        output_input = np.dot(self.hidden_output, self.W2) + self.b2
        self.final_output = self._sigmoid(output_input)
        
        return self.final_output

    def _backward_propagation(self, expected_output):
        """Perform backward propagation to calculate errors and update weights."""
        # Calculate output layer error
        output_error = expected_output - self.final_output
        output_delta = output_error * self._sigmoid_derivative(self.final_output)
        
        # Calculate hidden layer error
        hidden_error = np.dot(output_delta, self.W2.T)
        hidden_delta = hidden_error * self._sigmoid_derivative(self.hidden_output)
        
        # Update weights and biases using gradient descent
        # Update output layer weights and biases
        self.W2 += self.current_learning_rate * np.outer(self.hidden_output, output_delta)
        self.b2 += self.current_learning_rate * output_delta
        
        # Update hidden layer weights and biases
        self.W1 += self.current_learning_rate * np.outer(self.input_data, hidden_delta)
        self.b1 += self.current_learning_rate * hidden_delta

    def _iterate(self):
        """Single iteration of the BP learning algorithm."""
        current_data = self.current_data
        input_features = current_data[:-1]  # All columns except the last one
        expected_output = self._normalize_target(current_data[-1])  # Last column is the target
        
        # Forward propagation
        actual_output = self._forward_propagation(input_features)
        
        # Backward propagation
        self._backward_propagation(expected_output)

    def _normalize_target(self, target):
        """Normalize target value based on sigmoid type."""
        unique_targets = self.group_types.flatten()
        min_target = np.min(unique_targets)
        max_target = np.max(unique_targets)
        
        if self.sigmoid_type == 'unipolar':
            # Normalize to [0, 1] for unipolar sigmoid
            if max_target == min_target:
                return 0.5
            return (target - min_target) / (max_target - min_target)
        elif self.sigmoid_type == 'bipolar':
            # Normalize to [-1, 1] for bipolar sigmoid
            if max_target == min_target:
                return 0.0
            return 2 * (target - min_target) / (max_target - min_target) - 1
        else:
            raise ValueError("sigmoid_type must be 'unipolar' or 'bipolar'")

    def _denormalize_output(self, output):
        """Denormalize network output back to original target range."""
        unique_targets = self.group_types.flatten()
        min_target = np.min(unique_targets)
        max_target = np.max(unique_targets)
        
        if self.sigmoid_type == 'unipolar':
            # From [0, 1] back to original range
            return output * (max_target - min_target) + min_target
        elif self.sigmoid_type == 'bipolar':
            # From [-1, 1] back to original range
            return (output + 1) * (max_target - min_target) / 2 + min_target
        else:
            raise ValueError("sigmoid_type must be 'unipolar' or 'bipolar'")

    def _correct_rate(self, dataset):
        """Calculate the correct rate for given dataset."""
        if self.W1 is None or self.W2 is None:
            return 0
        
        correct_count = 0
        for data in dataset:
            input_features = data[:-1]
            expected_target = data[-1]
            
            # Forward propagation
            output = self._forward_propagation(input_features)
            predicted_target = self._denormalize_output(output[0])  # Convert back to original scale
            
            # Check if prediction is close to expected (within tolerance)
            unique_targets = self.group_types.flatten()
            tolerance = (np.max(unique_targets) - np.min(unique_targets)) / (2 * len(unique_targets))
            if abs(predicted_target - expected_target) <= tolerance:
                correct_count += 1
        
        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def predict(self, input_data):
        """Make prediction for new input data."""
        if self.W1 is None or self.W2 is None:
            raise ValueError("Network not trained yet")
        
        output = self._forward_propagation(input_data)
        return self._denormalize_output(output[0])