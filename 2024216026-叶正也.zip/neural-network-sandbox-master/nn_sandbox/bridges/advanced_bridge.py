from typing import List

import numpy as np
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import (
    BoltzmannMachineSimulator,
    HopfieldAsyncAlgorithm,
    SteepestDescentSimulator,
    NewtonMethodSimulator,
    ConjugateGradientSimulator,
    OLSAlgorithm,
    TSPSimulator,
)
from . import Bridge, BridgeProperty
from .observer import Observable


class AdvancedBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.05)

    # Ordinary Least Squares demo properties
    ols_learning_rate = BridgeProperty(0.05)
    ols_use_lr_decay = BridgeProperty(False)
    ols_lr_decay = BridgeProperty(0.0)
    ols_use_momentum = BridgeProperty(False)
    ols_momentum = BridgeProperty(0.0)
    ols_enable_early_stop = BridgeProperty(False)
    ols_early_stop_delta = BridgeProperty(1e-6)
    ols_early_stop_patience = BridgeProperty(15)
    ols_warm_start = BridgeProperty(False)
    ols_param_history = BridgeProperty([])
    ols_iterations = BridgeProperty(200)
    ols_sample_size = BridgeProperty(80)
    ols_noise_level = BridgeProperty(0.1)
    ols_target_a = BridgeProperty(0.6)
    ols_target_b = BridgeProperty(1.2)
    ols_target_c = BridgeProperty(0.2)
    ols_dataset = BridgeProperty([])
    ols_line_points = BridgeProperty([])
    ols_loss_history = BridgeProperty([])
    ols_current_iteration = BridgeProperty(0)
    ols_current_loss = BridgeProperty(0.0)
    ols_is_running = BridgeProperty(False)

    # Hopfield asynchronous demo properties
    hopfield_neuron_count = BridgeProperty(8)
    hopfield_pattern_count = BridgeProperty(3)
    hopfield_iterations = BridgeProperty(200)
    hopfield_patterns = BridgeProperty([])
    hopfield_state = BridgeProperty([])
    hopfield_energy_history = BridgeProperty([])
    hopfield_current_iteration = BridgeProperty(0)
    hopfield_current_energy = BridgeProperty(0.0)
    hopfield_last_updated_index = BridgeProperty(-1)
    hopfield_attractor_state = BridgeProperty([])
    hopfield_attractor_energy = BridgeProperty(0.0)
    hopfield_is_running = BridgeProperty(False)

    # Travelling Salesman demo properties
    tsp_city_count = BridgeProperty(12)
    tsp_iterations = BridgeProperty(400)
    tsp_cities = BridgeProperty([])
    tsp_path = BridgeProperty([])
    tsp_length_history = BridgeProperty([])
    tsp_current_length = BridgeProperty(0.0)
    tsp_current_iteration = BridgeProperty(0)
    tsp_is_running = BridgeProperty(False)

    # Boltzmann Machine demo properties
    bm_initial_temperature = BridgeProperty(2.5)
    bm_cooling_rate = BridgeProperty(0.92)
    bm_steps = BridgeProperty(240)
    bm_weights = BridgeProperty([
        [0.0, 1.0, -1.0],
        [1.0, 0.0, 0.8],
        [-1.0, 0.8, 0.0],
    ])
    bm_biases = BridgeProperty([0.0, 0.0, 0.0])
    bm_state = BridgeProperty([1, -1, 1])
    bm_energy_history = BridgeProperty([])
    bm_current_energy = BridgeProperty(0.0)
    bm_temperature = BridgeProperty(2.5)
    bm_equilibrium_state = BridgeProperty([])
    bm_current_step = BridgeProperty(0)
    bm_is_running = BridgeProperty(False)

    # Gradient methods demo properties
    gd_A = BridgeProperty([[3.0, 0.0], [0.0, 1.0]])
    gd_b = BridgeProperty([1.0, -1.0])
    gd_initial_x = BridgeProperty([2.0, 1.5])
    gd_steps = BridgeProperty(20)
    gd_learning_rate = BridgeProperty(0.1)
    gd_surface_points = BridgeProperty([])
    gd_bounds = BridgeProperty([-3.5, 3.5, -3.5, 3.5])

    # steepest descent
    sd_path = BridgeProperty([])
    sd_current_iteration = BridgeProperty(0)
    sd_is_running = BridgeProperty(False)

    # newton
    newton_path = BridgeProperty([])
    newton_current_iteration = BridgeProperty(0)
    newton_is_running = BridgeProperty(False)

    # conjugate gradient
    cg_path = BridgeProperty([])
    cg_current_iteration = BridgeProperty(0)
    cg_is_running = BridgeProperty(False)

    def __init__(self):
        super().__init__()
        self._ols_thread = None
        self._hopfield_thread = None
        self._tsp_thread = None
        self._bm_thread = None
        self._sd_thread = None
        self._newton_thread = None
        self._cg_thread = None

    # OLS demo slots
    @PyQt5.QtCore.pyqtSlot()
    def start_ols(self):
        self.stop_ols()
        dataset = self._generate_ols_dataset()
        self.ols_dataset = dataset
        self.ols_line_points = []
        self.ols_loss_history = []
        self.ols_current_iteration = 0
        self.ols_current_loss = 0.0
        # determine initial params for warm start
        init_a = init_b = init_c = 0.0
        if self.ols_warm_start and self.ols_param_history:
            try:
                last = self.ols_param_history[-1]
                init_a, init_b, init_c = float(last[1]), float(last[2]), float(last[3])
            except Exception:
                init_a = init_b = init_c = 0.0
        # reset param history for new run
        self.ols_param_history = []
        self.ols_is_running = True
        self._ols_thread = ObservableOLSAlgorithm(
            self,
            dataset=dataset,
            learning_rate=self.ols_learning_rate,
            max_iterations=self.ols_iterations,
            use_lr_decay=bool(self.ols_use_lr_decay),
            lr_decay=float(self.ols_lr_decay),
            use_momentum=bool(self.ols_use_momentum),
            momentum=float(self.ols_momentum),
            enable_early_stop=bool(self.ols_enable_early_stop),
            early_stop_delta=float(self.ols_early_stop_delta),
            early_stop_patience=int(self.ols_early_stop_patience),
            initial_a=float(init_a),
            initial_b=float(init_b),
            initial_c=float(init_c),
            refresh_interval=self.ui_refresh_interval,
        )
        self._ols_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_ols(self):
        if self._ols_thread and self._ols_thread.is_alive():
            self._ols_thread.stop()
            self._ols_thread.join(timeout=1.0)
        self._ols_thread = None
        if self.ols_is_running:
            self.ols_is_running = False

    # Hopfield demo slots
    @PyQt5.QtCore.pyqtSlot()
    def start_hopfield(self):
        self.stop_hopfield()
        patterns = self._generate_hopfield_patterns()
        self.hopfield_patterns = patterns
        self.hopfield_state = []
        self.hopfield_energy_history = []
        self.hopfield_current_iteration = 0
        self.hopfield_current_energy = 0.0
        self.hopfield_attractor_state = []
        self.hopfield_attractor_energy = 0.0
        self.hopfield_is_running = True
        self._hopfield_thread = ObservableHopfieldAlgorithm(
            self,
            patterns=patterns,
            max_iterations=self.hopfield_iterations,
            refresh_interval=self.ui_refresh_interval,
        )
        self._hopfield_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_hopfield(self):
        if self._hopfield_thread and self._hopfield_thread.is_alive():
            self._hopfield_thread.stop()
            self._hopfield_thread.join(timeout=1.0)
        self._hopfield_thread = None
        if self.hopfield_is_running:
            self.hopfield_is_running = False

    # TSP demo slots
    @PyQt5.QtCore.pyqtSlot()
    def start_tsp(self):
        self.stop_tsp()
        cities = self._generate_tsp_cities()
        self.tsp_cities = cities
        self.tsp_path = []
        self.tsp_length_history = []
        self.tsp_current_length = 0.0
        self.tsp_current_iteration = 0
        self.tsp_is_running = True
        self._tsp_thread = ObservableTSPSimulator(
            self,
            cities=cities,
            max_iterations=self.tsp_iterations,
            refresh_interval=self.ui_refresh_interval,
        )
        initial_path = self._format_tsp_path(cities, self._tsp_thread.path)
        self.tsp_path = initial_path
        initial_length = float(self._tsp_thread.best_length)
        self.tsp_length_history = [[0, initial_length]]
        self.tsp_current_length = initial_length
        self._tsp_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_tsp(self):
        if self._tsp_thread and self._tsp_thread.is_alive():
            self._tsp_thread.stop()
            self._tsp_thread.join(timeout=1.0)
        self._tsp_thread = None
        if self.tsp_is_running:
            self.tsp_is_running = False

    # Boltzmann Machine demo slots
    @PyQt5.QtCore.pyqtSlot()
    def start_boltzmann(self):
        self.stop_boltzmann()
        self.bm_energy_history = []
        self.bm_current_step = 0
        self.bm_equilibrium_state = []
        self.bm_is_running = True
        weights = np.array(self.bm_weights, dtype=float)
        biases = np.array(self.bm_biases, dtype=float)
        if weights.shape != (3, 3):
            raise ValueError("bm_weights must be 3x3")
        if biases.shape != (3,):
            raise ValueError("bm_biases must have length 3")
        self._bm_thread = ObservableBoltzmannSimulator(
            self,
            weights=weights.tolist(),
            biases=biases.tolist(),
            initial_temperature=self.bm_initial_temperature,
            cooling_rate=self.bm_cooling_rate,
            steps=self.bm_steps,
            refresh_interval=self.ui_refresh_interval,
        )
        self._bm_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_boltzmann(self):
        if self._bm_thread and self._bm_thread.is_alive():
            self._bm_thread.stop()
            self._bm_thread.join(timeout=1.0)
        self._bm_thread = None
        if self.bm_is_running:
            self.bm_is_running = False

    # Gradient demo slots
    @PyQt5.QtCore.pyqtSlot()
    def start_steepest(self):
        self.stop_steepest()
        self.sd_path = []
        self.sd_current_iteration = 0
        self.sd_is_running = True
        self._update_gradient_surface()
        self._sd_thread = ObservableSteepestDescent(
            self,
            A=self.gd_A,
            b=self.gd_b,
            initial_x=self.gd_initial_x,
            learning_rate=self.gd_learning_rate,
            steps=self.gd_steps,
            refresh_interval=self.ui_refresh_interval,
        )
        self._sd_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_steepest(self):
        if self._sd_thread and self._sd_thread.is_alive():
            self._sd_thread.stop()
            self._sd_thread.join(timeout=1.0)
        self._sd_thread = None
        if self.sd_is_running:
            self.sd_is_running = False

    @PyQt5.QtCore.pyqtSlot()
    def start_newton(self):
        self.stop_newton()
        self.newton_path = []
        self.newton_current_iteration = 0
        self.newton_is_running = True
        self._update_gradient_surface()
        self._newton_thread = ObservableNewtonMethod(
            self,
            A=self.gd_A,
            b=self.gd_b,
            initial_x=self.gd_initial_x,
            steps=self.gd_steps,
            refresh_interval=self.ui_refresh_interval,
        )
        self._newton_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_newton(self):
        if self._newton_thread and self._newton_thread.is_alive():
            self._newton_thread.stop()
            self._newton_thread.join(timeout=1.0)
        self._newton_thread = None
        if self.newton_is_running:
            self.newton_is_running = False

    @PyQt5.QtCore.pyqtSlot()
    def start_cg(self):
        self.stop_cg()
        self.cg_path = []
        self.cg_current_iteration = 0
        self.cg_is_running = True
        self._update_gradient_surface()
        self._cg_thread = ObservableConjugateGradient(
            self,
            A=self.gd_A,
            b=self.gd_b,
            initial_x=self.gd_initial_x,
            max_iterations=self.gd_steps,
            refresh_interval=self.ui_refresh_interval,
        )
        self._cg_thread.start()

    @PyQt5.QtCore.pyqtSlot()
    def refresh_gradient_surface(self):
        self._update_gradient_surface()

    @PyQt5.QtCore.pyqtSlot()
    def stop_cg(self):
        if self._cg_thread and self._cg_thread.is_alive():
            self._cg_thread.stop()
            self._cg_thread.join(timeout=1.0)
        self._cg_thread = None
        if self.cg_is_running:
            self.cg_is_running = False

    def _generate_ols_dataset(self) -> List[List[float]]:
        sample_size = max(int(self.ols_sample_size), 2)
        x = np.linspace(-1.0, 1.0, sample_size)
        noise = np.random.normal(0.0, abs(float(self.ols_noise_level)), sample_size)
        y = self.ols_target_a * x**2 + self.ols_target_b * x + self.ols_target_c + noise
        return np.stack([x, y], axis=1).tolist()

    def _generate_hopfield_patterns(self) -> List[List[int]]:
        neuron_count = max(int(self.hopfield_neuron_count), 2)
        pattern_count = max(int(self.hopfield_pattern_count), 1)
        raw = np.random.choice([-1, 1], size=(pattern_count, neuron_count))
        # keep patterns unique to better illustrate attractors
        patterns = np.unique(raw, axis=0)
        while len(patterns) < pattern_count:
            candidate = np.random.choice([-1, 1], size=(pattern_count - len(patterns), neuron_count))
            patterns = np.unique(np.concatenate([patterns, candidate], axis=0), axis=0)
        return patterns.tolist()

    def _generate_tsp_cities(self) -> List[List[float]]:
        city_count = max(int(self.tsp_city_count), 3)
        coords = np.random.rand(city_count, 2)
        return coords.tolist()

    @staticmethod
    def _format_tsp_path(cities: List[List[float]], path: List[int]) -> List[List[float]]:
        if not path:
            return []
        coords = [list(cities[idx]) for idx in path]
        coords.append(list(cities[path[0]]))
        return coords

    def _update_gradient_surface(self) -> None:
        try:
            A = np.array(self.gd_A, dtype=float)
            b = np.array(self.gd_b, dtype=float)
            initial = np.array(self.gd_initial_x, dtype=float).flatten()
        except Exception:
            return
        if A.shape != (2, 2):
            return
        if b.shape not in [(2,), (2, 1)]:
            return
        b = b.reshape(2)
        if initial.size < 2:
            initial = np.zeros(2)
        else:
            initial = initial[:2]
        limit = float(max(2.5, np.max(np.abs(initial)) + 1.5))
        grid = np.linspace(-limit, limit, 31)
        points: List[List[float]] = []
        for x in grid:
            for y in grid:
                vec = np.array([x, y])
                value = 0.5 * float(vec @ A @ vec) - float(b @ vec)
                points.append([float(x), float(y), value])
        bounds = [float(grid[0]), float(grid[-1]), float(grid[0]), float(grid[-1])]
        self.gd_bounds = bounds
        self.gd_surface_points = points


class ObservableOLSAlgorithm(Observable, OLSAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        OLSAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'current_iteration':
            self.notify('ols_current_iteration', value)
        elif name == 'loss':
            self.notify('ols_current_loss', value)
        elif name == 'loss_history':
            self.notify('ols_loss_history', value)
        elif name == 'line_points':
            self.notify('ols_line_points', value)
        elif name == 'running':
            self.notify('ols_is_running', value)
        elif name == 'param_history':
            self.notify('ols_param_history', value)


class ObservableHopfieldAlgorithm(Observable, HopfieldAsyncAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        HopfieldAsyncAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'state':
            self.notify('hopfield_state', value)
        elif name == 'energy_history':
            try:
                formatted = [[int(e[0]), float(e[1])] for e in value] if value else []
            except Exception:
                formatted = []
            self.notify('hopfield_energy_history', formatted)
        elif name == 'energy':
            self.notify('hopfield_current_energy', value)
        elif name == 'current_iteration':
            self.notify('hopfield_current_iteration', value)
        elif name == 'updated_index':
            self.notify('hopfield_last_updated_index', value)
        elif name == 'attractor_state':
            self.notify('hopfield_attractor_state', value)
        elif name == 'attractor_energy':
            self.notify('hopfield_attractor_energy', value)
        elif name == 'running':
            self.notify('hopfield_is_running', value)


class ObservableTSPSimulator(Observable, TSPSimulator):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        TSPSimulator.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'path':
            if value:
                coordinates = [self.cities[idx].tolist() for idx in value]
                coordinates.append(self.cities[value[0]].tolist())
            else:
                coordinates = []
            self.notify('tsp_path', coordinates)
        elif name == 'length_history':
            self.notify('tsp_length_history', value)
        elif name == 'best_length':
            self.notify('tsp_current_length', value)
        elif name == 'current_iteration':
            self.notify('tsp_current_iteration', value)
        elif name == 'running':
            self.notify('tsp_is_running', value)


class ObservableBoltzmannSimulator(Observable, BoltzmannMachineSimulator):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        BoltzmannMachineSimulator.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'state':
            self.notify('bm_state', value)
        elif name == 'energy_history':
            try:
                formatted = []
                if value:
                    for e in value:
                        if e is None:
                            continue
                        if isinstance(e, (list, tuple)):
                            if len(e) >= 3:
                                formatted.append([int(e[0]), float(e[1]), float(e[2])])
                            elif len(e) == 2:
                                formatted.append([int(e[0]), float(e[1])])
                        # ignore otherwise
                self.notify('bm_energy_history', formatted)
            except Exception:
                self.notify('bm_energy_history', [])
        elif name == 'energy':
            self.notify('bm_current_energy', value)
        elif name == 'temperature':
            self.notify('bm_temperature', value)
        elif name == 'equilibrium_state':
            self.notify('bm_equilibrium_state', value)
        elif name == 'current_step':
            self.notify('bm_current_step', value)
        elif name == 'running':
            self.notify('bm_is_running', value)


class ObservableSteepestDescent(Observable, SteepestDescentSimulator):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        SteepestDescentSimulator.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'path_history':
            self.notify('sd_path', value)
        elif name == 'current_iteration':
            self.notify('sd_current_iteration', value)
        elif name == 'running':
            self.notify('sd_is_running', value)


class ObservableNewtonMethod(Observable, NewtonMethodSimulator):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        NewtonMethodSimulator.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'path_history':
            self.notify('newton_path', value)
        elif name == 'current_iteration':
            self.notify('newton_current_iteration', value)
        elif name == 'running':
            self.notify('newton_is_running', value)


class ObservableConjugateGradient(Observable, ConjugateGradientSimulator):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        ConjugateGradientSimulator.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name == 'path_history':
            self.notify('cg_path', value)
        elif name == 'current_iteration':
            self.notify('cg_current_iteration', value)
        elif name == 'running':
            self.notify('cg_is_running', value)
