from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGroupBox,
                               QFormLayout, QDoubleSpinBox, QPushButton, QTextEdit,
                               QLabel, QSpinBox, QFileDialog, QMessageBox)
from PySide6.QtCore import Slot
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import os

# 确保负号显示正确（在子界面也添加一次，防止被覆盖）
plt.rcParams['axes.unicode_minus'] = False
# 设置字体（优先使用系统存在的中文字体）
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'sans-serif']


class OLSRBFNetwork:
    """使用OLS算法的RBF神经网络"""

    def __init__(self, spread=0.5):
        self.spread = spread
        self.selected_centers = []
        self.weights = []
        self.err_history = []

    def rbf_kernel(self, x, c):
        """RBF核函数"""
        return np.exp(-np.linalg.norm(x - c) ** 2 / (2 * self.spread ** 2))

    def fit(self, X, y, max_centers=None):
        """训练模型"""
        self.err_history = []
        self.selected_centers = []
        n_samples = X.shape[0]
        max_centers = max_centers if max_centers else n_samples

        # 初始误差
        residual = y.copy()
        self.err_history.append(np.mean(np.square(residual)))

        for _ in range(max_centers):
            # 选择使残差最大的样本作为中心
            errors = np.square(residual)
            idx = np.argmax(errors)
            center = X[idx]
            self.selected_centers.append(center)

            # 构建设计矩阵
            G = np.array([[self.rbf_kernel(x, c) for c in self.selected_centers] for x in X])
            # 添加偏置项
            G = np.hstack((G, np.ones((n_samples, 1))))

            # 使用OLS求解权重
            self.weights = np.linalg.pinv(G.T @ G) @ G.T @ y

            # 更新残差
            y_pred = G @ self.weights
            residual = y - y_pred
            self.err_history.append(np.mean(np.square(residual)))

            # 如果误差足够小，提前停止
            if self.err_history[-1] < 1e-6:
                break

    def predict(self, X):
        """预测"""
        if not self.selected_centers:
            return np.zeros(X.shape[0])

        G = np.array([[self.rbf_kernel(x, c) for c in self.selected_centers] for x in X])
        G = np.hstack((G, np.ones((X.shape[0], 1))))
        return G @ self.weights


class OLSRBFWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.figure = None  # 初始化绘图对象
        self.canvas = None
        self.init_ui()
        self.network = OLSRBFNetwork()
        self.X = None
        self.y = None

    def init_ui(self):
        # 主布局
        main_layout = QVBoxLayout(self)

        # 控制面板
        control_group = QGroupBox("参数设置（OLS-RBF神经网络）")
        control_layout = QFormLayout()

        # 散布参数
        self.spread_spin = QDoubleSpinBox()
        self.spread_spin.setRange(0.1, 10.0)
        self.spread_spin.setValue(0.5)
        self.spread_spin.setSingleStep(0.1)
        control_layout.addRow("散布参数（spread）:", self.spread_spin)

        # 最大中心数
        self.max_centers_spin = QSpinBox()
        self.max_centers_spin.setRange(1, 100)
        self.max_centers_spin.setValue(20)
        control_layout.addRow("最大中心数:", self.max_centers_spin)

        # 按钮布局
        button_layout = QHBoxLayout()

        # 生成测试数据按钮
        self.gen_data_btn = QPushButton("生成测试数据（sin曲线）")
        self.gen_data_btn.clicked.connect(self.generate_test_data)
        button_layout.addWidget(self.gen_data_btn)

        # 训练按钮
        self.train_btn = QPushButton("训练模型")
        self.train_btn.clicked.connect(self.train_model)
        button_layout.addWidget(self.train_btn)

        # 保存图片按钮
        self.save_btn = QPushButton("保存结果图")
        self.save_btn.clicked.connect(self.save_figure)
        button_layout.addWidget(self.save_btn)

        control_layout.addRow(button_layout)
        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)

        # 结果显示区域
        result_layout = QHBoxLayout()

        # 文本输出
        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)
        self.text_output.append("欢迎使用OLS-RBF神经网络界面！")
        self.text_output.append("步骤：1. 生成测试数据 → 2. 训练模型 → 3. 查看结果")
        result_layout.addWidget(self.text_output, 1)  # 占1份宽度

        # 图形显示（占2份宽度）
        self.initialize_plot()
        result_layout.addWidget(self.canvas, 2)

        main_layout.addLayout(result_layout, 1)  # 占1份高度

    def initialize_plot(self):
        """初始化绘图区域（被主窗口调用）"""
        if self.figure is None:
            self.figure = plt.figure(figsize=(8, 6), dpi=100)
            # 确保负号显示正确（再次强调）
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
        if self.canvas is None:
            self.canvas = FigureCanvas(self.figure)
        # 初始绘制空白图
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.set_title("等待生成数据...")
        ax.set_xlabel("X轴")
        ax.set_ylabel("Y轴")
        ax.grid(True, alpha=0.3)
        self.canvas.draw()

    @Slot()
    def generate_test_data(self):
        """生成测试数据（sin曲线+噪声）"""
        self.text_output.append("\n[步骤1] 生成测试数据...")

        # 生成非线性数据
        x = np.linspace(-1, 1, 100).reshape(-1, 1)
        y = np.sin(2 * np.pi * x) + 0.1 * np.random.randn(100, 1)

        self.X = x
        self.y = y

        self.text_output.append(f"生成 {len(x)} 个样本（X范围：[-1,1]，Y=sin(2πX)+噪声）")

        # 绘制数据
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        ax.scatter(x, y, label='训练数据', color='#1f77b4', alpha=0.6, s=30)
        ax.set_title('OLS-RBF神经网络：测试数据')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.legend()
        ax.grid(True, alpha=0.3)
        self.canvas.draw()

    @Slot()
    def train_model(self):
        """训练模型"""
        if self.X is None or self.y is None:
            self.text_output.append("\n[错误] 请先生成测试数据！")
            QMessageBox.warning(self, "警告", "请先点击「生成测试数据」按钮！")
            return

        self.text_output.append("\n[步骤2] 开始训练模型...")

        # 获取参数
        spread = self.spread_spin.value()
        max_centers = self.max_centers_spin.value()

        self.text_output.append(f"训练参数：spread={spread}，最大中心数={max_centers}")

        # 初始化网络
        self.network = OLSRBFNetwork(spread=spread)

        # 训练（记录时间）
        import time
        start_time = time.time()
        self.network.fit(self.X, self.y, max_centers=max_centers)
        end_time = time.time()

        # 预测
        y_pred = self.network.predict(self.X)

        # 输出结果
        self.text_output.append(f"训练完成！耗时：{end_time - start_time:.2f}秒")
        self.text_output.append(f"实际使用中心数：{len(self.network.selected_centers)}")
        self.text_output.append(f"最终训练误差（MSE）：{self.network.err_history[-1]:.6f}")

        # 绘制结果（双图：预测结果 + 误差变化）
        self.figure.clear()

        # 子图1：预测结果
        ax1 = self.figure.add_subplot(121)
        ax1.scatter(self.X, self.y, label='实际数据', color='#1f77b4', alpha=0.6, s=30)
        ax1.plot(self.X, y_pred, 'r-', label='预测曲线', linewidth=2)
        ax1.scatter([c[0] for c in self.network.selected_centers],
                    [0] * len(self.network.selected_centers),
                    c='g', marker='*', s=100, label='RBF中心', zorder=5)
        ax1.set_title('预测结果对比')
        ax1.set_xlabel('X')
        ax1.set_ylabel('Y')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 子图2：误差变化（对数坐标，更清晰）
        ax2 = self.figure.add_subplot(122)
        ax2.plot(self.network.err_history, 'b-', linewidth=1.5)
        ax2.set_title('训练误差变化')
        ax2.set_xlabel('迭代次数（添加中心数）')
        ax2.set_ylabel('均方误差（MSE）')
        ax2.set_yscale('log')  # 对数坐标，方便查看小误差
        ax2.grid(True, alpha=0.3)

        # 调整子图间距
        self.figure.tight_layout()
        self.canvas.draw()

    @Slot()
    def save_figure(self):
        """保存结果图到本地"""
        if self.figure is None:
            self.text_output.append("\n[错误] 没有可保存的图形！")
            QMessageBox.warning(self, "警告", "请先训练模型，生成结果图后再保存！")
            return

        # 选择保存路径
        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存结果图",
            os.path.join(os.getcwd(), "ols_rbf_result.png"),
            "图片文件 (*.png *.jpg *.jpeg *.pdf)"
        )

        if not save_path:
            self.text_output.append("\n[提示] 保存操作已取消")
            return

        # 保存图片（bbox_inches='tight' 防止标签被截断）
        try:
            self.figure.savefig(
                save_path,
                dpi=150,
                bbox_inches='tight',
                facecolor='white',
                edgecolor='none'
            )
            self.text_output.append(f"\n[成功] 结果图已保存到：{save_path}")
            QMessageBox.information(self, "成功", f"图片已保存到：\n{save_path}")
        except Exception as e:
            self.text_output.append(f"\n[错误] 保存图片失败：{str(e)}")
            QMessageBox.critical(self, "错误", f"保存失败！\n原因：{str(e)}")