import numpy as np
from PyQt5.QtCore import pyqtSignal, QThread, pyqtProperty, pyqtSlot, QVariant

class SOFMBridge(QThread):
    weightsUpdated = pyqtSignal()       # 权重更新信号
    classificationChanged = pyqtSignal()  # 分类结果信号
    trainingComplete = pyqtSignal()     # 训练完成信号
    classificationChanged1 = pyqtSignal()
    classificationChanged2 = pyqtSignal()


    def __init__(self, input_dim=2, grid_shape=(2, 3), learning_rate=0.1, radius=1.0):
        super().__init__()
        self.input_dim = input_dim
        self.grid_shape = grid_shape
        self.learning_rate = learning_rate
        self.radius = radius
        self.epochs = 100
        self._classification = [0, 0]  # Ensure it's a list, not QVariant
        print(type(self._classification))
        self.initialize_weights()
        self._classification1 = 0
        self._classification2 = 0


    def initialize_weights(self):
        """初始化随机权重"""
        self.weights = np.random.rand(self.grid_shape[0], self.grid_shape[1], self.input_dim)
        self.weightsUpdated.emit()

    # 获取权重列表
    @pyqtProperty(QVariant, notify=weightsUpdated)
    def weightsList(self):
        return [[list(map(float, neuron)) for neuron in row] for row in self.weights.tolist()]

    # 分类结果
    @pyqtProperty(QVariant, notify=classificationChanged)  # Return as a simple list
    def classification(self):
        return [self._classification[0],self._classification[1]]  # Return as a list (not a QVariant)

    @classification.setter
    def classification(self, value):
        if self._classification != value:
            self._classification = value
            self.classificationChanged.emit()


    @pyqtProperty(int, notify=classificationChanged1)
    def classification1(self):
        return self._classification1

    @classification1.setter
    def classification1(self, value):
        if self._classification1 != value:
            self._classification1 = value
            self.classificationChanged1.emit()

    @pyqtProperty(int, notify=classificationChanged2)
    def classification2(self):
        return self._classification2

    @classification2.setter
    def classification2(self, value):
        if self._classification2 != value:
            self._classification2 = value
            self.classificationChanged2.emit()


    @pyqtSlot(list)
    def classifySample(self, sample):
        """对输入样本进行分类"""
        sample = np.array(sample)
        bmu_index = self.find_bmu(sample)
        self.classification = list(bmu_index)  # Ensure it's a list when passing to QML
        self.classification1 = self.classification[0]
        self.classification2 = self.classification[1]



    def find_bmu(self, input_vector):
        """找到最佳匹配单元 (BMU)"""
        distances = np.linalg.norm(self.weights - input_vector, axis=2)
        return np.unravel_index(np.argmin(distances), distances.shape)

    @pyqtSlot(list, int)
    def trainNetwork(self, data, epochs):
        """训练 SOFM 网络"""
        data = np.array(data).T
        self.epochs = epochs
        for epoch in range(epochs):
            for input_vector in data:
                bmu_index = self.find_bmu(input_vector)
                self.update_weights(input_vector, bmu_index, epoch)
        self.weightsUpdated.emit()
        self.trainingComplete.emit()

    def update_weights(self, input_vector, bmu_index, epoch):
        """更新权重"""
        learning_rate = self.learning_rate * (1 - epoch / self.epochs)
        radius = self.radius * (1 - epoch / self.epochs)

        for i in range(self.grid_shape[0]):
            for j in range(self.grid_shape[1]):
                distance_to_bmu = np.linalg.norm(np.array([i, j]) - np.array(bmu_index))
                if distance_to_bmu <= radius:
                    self.weights[i, j] += learning_rate * (input_vector - self.weights[i, j])

    @pyqtSlot()
    def resetWeights(self):
        """重置权重"""
        self.initialize_weights()



