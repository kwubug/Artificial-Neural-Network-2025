import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'BM'
    // 左侧：控制和信息面板
    ColumnLayout {
        Layout.preferredWidth: 350
        Layout.fillHeight: true
        spacing: 10
        
        // BM算法不需要数据集，但保留此组件以保持界面一致性
        GroupBox {
            title: '说明'
            Layout.fillWidth: true
            Label {
                Layout.fillWidth: true
                text: '玻尔兹曼机（BM）算法\n实现3个神经元的随机网络\n可视化热平衡过程'
                wrapMode: Text.WordWrap
                padding: 10
            }
        }
        
        GroupBox {
            title: '设置'
            Layout.fillWidth: true
            GridLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                columns: 2
                    
                    Label {
                        text: '总训练轮数'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    SpinBox {
                        id: totalEpoches
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 100
                        from: 1
                        to: 9999
                        onValueChanged: bmBridge.total_epoches = value
                        Component.onCompleted: bmBridge.total_epoches = value
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '初始温度'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 10.0 * 100
                        from: 0.1 * 100
                        to: 100 * 100
                        onValueChanged: bmBridge.initial_temperature = value / 100
                        Component.onCompleted: bmBridge.initial_temperature = value / 100
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '冷却速率'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 0.95 * 100
                        from: 0.01 * 100
                        to: 0.99 * 100
                        onValueChanged: bmBridge.cooling_rate = value / 100
                        Component.onCompleted: bmBridge.cooling_rate = value / 100
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '最小温度'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 0.1 * 100
                        from: 0.01 * 100
                        to: 10 * 100
                        onValueChanged: bmBridge.min_temperature = value / 100
                        Component.onCompleted: bmBridge.min_temperature = value / 100
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '神经元数量'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    SpinBox {
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 3
                        from: 2
                        to: 10
                        onValueChanged: bmBridge.num_neurons = value
                        Component.onCompleted: bmBridge.num_neurons = value
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '界面刷新间隔'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    DoubleSpinBox {
                        enabled: bmBridge && bmBridge.has_finished
                        editable: true
                        value: 0.1 * 100
                        from: 0 * 100
                        to: 5 * 100
                        onValueChanged: bmBridge.ui_refresh_interval = value / 100
                        Component.onCompleted: bmBridge.ui_refresh_interval = value / 100
                        Layout.fillWidth: true
                }
            }
        }
        
        GroupBox {
            title: '信息'
            Layout.fillWidth: true
            Layout.fillHeight: true
            GridLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                columns: 2
                    
                    ExecutionControls {
                        startButton.enabled: bmBridge && bmBridge.has_finished
                        startButton.onClicked: bmBridge.start_bm_algorithm()
                        stopButton.enabled: bmBridge && !bmBridge.has_finished
                        stopButton.onClicked: bmBridge.stop_bm_algorithm()
                        progressBar.value: (bmBridge.current_iterations + 1) / totalEpoches.value
                        Layout.columnSpan: 2
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '当前迭代'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: bmBridge.current_iterations + 1
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '当前温度'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: bmBridge.current_temperature.toFixed(3)
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '当前能量'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: bmBridge.current_energy.toFixed(4)
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '热平衡状态'
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        text: bmBridge.equilibrium_reached ? '✓ 已平衡' : '× 未平衡'
                        color: bmBridge.equilibrium_reached ? 'green' : 'red'
                        horizontalAlignment: Text.AlignHCenter
                        Layout.fillWidth: true
                    }
                    
                    Label {
                        text: '神经元状态'
                        Layout.alignment: Qt.AlignHCenter
                        Layout.columnSpan: 2
                    }
                    
                    Repeater {
                        model: bmBridge.current_neuron_states.length
                        delegate: RowLayout {
                            Layout.columnSpan: 2
                            Layout.fillWidth: true
                            Label {
                                text: '神经元 ' + (index + 1) + ':'
                                Layout.preferredWidth: 80
                            }
                            Rectangle {
                                Layout.fillWidth: true
                                Layout.preferredHeight: 30
                                color: bmBridge.current_neuron_states[index] === 1 ? '#4ECDC4' : '#95A5A6'
                                border.color: '#34495E'
                                border.width: 2
                                radius: 5
                                Text {
                                    anchors.centerIn: parent
                                    text: bmBridge.current_neuron_states[index] === 1 ? '激活 (1)' : '未激活 (0)'
                                    color: 'white'
                                    font.bold: true
                                }
                            }
                        }
                }
            }
        }
    }
    
    // 右侧：可视化面板
    ColumnLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        spacing: 10
        
        // 神经元网络可视化
        GroupBox {
            title: '神经元网络可视化'
            Layout.fillWidth: true
            Layout.fillHeight: true
            
            Canvas {
                id: networkCanvas
                anchors.fill: parent
                antialiasing: true
                
                property var neuronPositions: []
                property int neuronRadius: 40
                
                function updateNetwork() {
                    if (!bmBridge) return
                    
                    requestPaint()
                }
                
                onPaint: {
                    const ctx = getContext('2d')
                    ctx.clearRect(0, 0, width, height)
                    
                    if (!bmBridge || !bmBridge.current_neuron_states || bmBridge.current_neuron_states.length === 0) {
                        return
                    }
                    
                    const numNeurons = bmBridge.current_neuron_states.length
                    const centerX = width / 2
                    const centerY = height / 2
                    const radius = Math.min(width, height) / 3
                    
                    // 计算神经元位置（圆形排列）
                    neuronPositions = []
                    for (let i = 0; i < numNeurons; i++) {
                        const angle = (2 * Math.PI * i) / numNeurons - Math.PI / 2
                        const x = centerX + radius * Math.cos(angle)
                        const y = centerY + radius * Math.sin(angle)
                        neuronPositions.push({x: x, y: y})
                    }
                    
                    // 绘制连接（权重）
                    if (bmBridge.weights && bmBridge.weights.length > 0) {
                        for (let i = 0; i < numNeurons; i++) {
                            for (let j = i + 1; j < numNeurons; j++) {
                                const weight = bmBridge.weights[i][j]
                                const pos1 = neuronPositions[i]
                                const pos2 = neuronPositions[j]
                                
                                // 根据权重值设置颜色和宽度
                                const weightAbs = Math.abs(weight)
                                const lineWidth = Math.max(1, weightAbs * 5)
                                const alpha = Math.min(1, weightAbs)
                                
                                ctx.strokeStyle = weight >= 0 ? 
                                    `rgba(78, 205, 196, ${alpha})` : 
                                    `rgba(255, 107, 107, ${alpha})`
                                ctx.lineWidth = lineWidth
                                ctx.beginPath()
                                ctx.moveTo(pos1.x, pos1.y)
                                ctx.lineTo(pos2.x, pos2.y)
                                ctx.stroke()
                                
                                // 绘制权重标签
                                const midX = (pos1.x + pos2.x) / 2
                                const midY = (pos1.y + pos2.y) / 2
                                ctx.fillStyle = '#34495E'
                                ctx.font = '12px Arial'
                                ctx.textAlign = 'center'
                                ctx.fillText(weight.toFixed(2), midX, midY - 5)
                            }
                        }
                    }
                    
                    // 绘制神经元
                    for (let i = 0; i < numNeurons; i++) {
                        const pos = neuronPositions[i]
                        const state = bmBridge.current_neuron_states[i]
                        
                        // 绘制神经元圆圈
                        ctx.beginPath()
                        ctx.arc(pos.x, pos.y, neuronRadius, 0, 2 * Math.PI)
                        ctx.fillStyle = state === 1 ? '#4ECDC4' : '#95A5A6'
                        ctx.fill()
                        ctx.strokeStyle = '#34495E'
                        ctx.lineWidth = 3
                        ctx.stroke()
                        
                        // 绘制神经元标签
                        ctx.fillStyle = 'white'
                        ctx.font = 'bold 16px Arial'
                        ctx.textAlign = 'center'
                        ctx.textBaseline = 'middle'
                        ctx.fillText('N' + (i + 1), pos.x, pos.y - 10)
                        ctx.fillText(state === 1 ? '1' : '0', pos.x, pos.y + 10)
                    }
                    
                    // 绘制偏置
                    if (bmBridge.biases && bmBridge.biases.length > 0) {
                        for (let i = 0; i < numNeurons; i++) {
                            const pos = neuronPositions[i]
                            const bias = bmBridge.biases[i]
                            
                            ctx.fillStyle = '#E74C3C'
                            ctx.font = '10px Arial'
                            ctx.textAlign = 'center'
                            ctx.fillText('b=' + bias.toFixed(2), pos.x, pos.y + neuronRadius + 15)
                        }
                    }
                }
                
                Connections {
                    target: bmBridge
                    function onCurrent_neuron_statesChanged() {
                        networkCanvas.updateNetwork()
                    }
                    function onWeightsChanged() {
                        networkCanvas.updateNetwork()
                    }
                    function onBiasesChanged() {
                        networkCanvas.updateNetwork()
                    }
                }
                
                Component.onCompleted: updateNetwork()
            }
        }
    }
}

