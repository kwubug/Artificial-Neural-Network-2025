import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.animation import FuncAnimation
from collections import Counter
import time


class BoltzmannMachine:
    def __init__(self, num_neurons, weights=None, biases=None, temperature=1.0):
        self.num_neurons = num_neurons

        # Initialize weight matrix (symmetric, diagonal 0)
        if weights is None:
            self.weights = np.random.uniform(-1, 1, (num_neurons, num_neurons))
            np.fill_diagonal(self.weights, 0)  # No self-connections
            self.weights = (self.weights + self.weights.T) / 2  # Ensure symmetry
        else:
            self.weights = weights

        # Initialize biases
        if biases is None:
            self.biases = np.random.uniform(-0.5, 0.5, num_neurons)
        else:
            self.biases = biases

        self.temperature = temperature
        self.states = np.random.choice([-1, 1], size=num_neurons)  # Initial state
        self.energy_history = []
        self.states_history = []

    def calculate_energy(self, states):
        """Calculate system energy"""
        energy = -0.5 * np.dot(states.T, np.dot(self.weights, states)) - np.dot(self.biases, states)
        return energy

    def update_neuron(self, neuron_idx):
        """Update single neuron state"""
        # Calculate input sum for this neuron
        input_sum = np.dot(self.weights[neuron_idx], self.states) + self.biases[neuron_idx]

        # Calculate probability
        prob = 1 / (1 + np.exp(-2 * input_sum / self.temperature))

        # Update state based on probability
        if np.random.random() < prob:
            self.states[neuron_idx] = 1
        else:
            self.states[neuron_idx] = -1

    def step(self):
        """Perform one update step (random neuron selection)"""
        neuron_idx = np.random.randint(self.num_neurons)
        self.update_neuron(neuron_idx)

        # Record state and energy
        energy = self.calculate_energy(self.states)
        self.energy_history.append(energy)
        self.states_history.append(self.states.copy())

        return energy

    def run_simulation(self, num_steps):
        """Run simulation"""
        print("Starting Boltzmann Machine simulation...")
        print(f"Initial state: {self.states}")
        print(f"Initial energy: {self.calculate_energy(self.states):.4f}")

        for step in range(num_steps):
            energy = self.step()

            if step % 100 == 0:
                print(f"Step {step}: Energy = {energy:.4f}, State = {self.states}")

        return self.energy_history, self.states_history

    def find_equilibrium_state(self, num_steps=1000, convergence_threshold=0.01):
        """Find thermal equilibrium state"""
        print("\nFinding thermal equilibrium state...")

        # Run sufficient steps
        self.run_simulation(num_steps)

        # Analyze last part of states to determine equilibrium
        last_100_energies = self.energy_history[-100:]
        energy_std = np.std(last_100_energies)

        # Count frequency of last 100 states
        last_100_states = [tuple(state) for state in self.states_history[-100:]]
        state_counts = Counter(last_100_states)
        most_common_state, count = state_counts.most_common(1)[0]
        frequency = count / 100

        print(f"Energy standard deviation (last 100 steps): {energy_std:.4f}")
        print(f"Most frequent state: {most_common_state}, Frequency: {frequency:.2f}")

        if energy_std < convergence_threshold and frequency > 0.5:
            print("✓ System reached thermal equilibrium")
            equilibrium_state = np.array(most_common_state)
            equilibrium_energy = self.calculate_energy(equilibrium_state)
            print(f"Equilibrium state: {equilibrium_state}")
            print(f"Equilibrium energy: {equilibrium_energy:.4f}")
            return equilibrium_state, equilibrium_energy
        else:
            print("⚠ System may not have reached complete thermal equilibrium")
            return None, None


def visualize_bm_simulation_separate(bm, num_steps=500):
    """Visualize Boltzmann Machine simulation with separate plots"""
    # Run simulation
    bm.run_simulation(num_steps)

    # 1. Energy evolution plot
    plt.figure(figsize=(10, 6))
    plt.plot(bm.energy_history, 'b-', alpha=0.7, linewidth=2)
    plt.xlabel('Iteration Step')
    plt.ylabel('System Energy')
    plt.title('Energy Evolution of Boltzmann Machine')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()

    # 2. Neuron states heatmap
    plt.figure(figsize=(12, 6))
    states_array = np.array(bm.states_history)
    plt.imshow(states_array.T, aspect='auto', cmap='coolwarm',
               interpolation='nearest', extent=[0, num_steps, 0, 3])
    plt.xlabel('Iteration Step')
    plt.ylabel('Neuron')
    plt.title('Neuron States Evolution')
    plt.yticks([0.5, 1.5, 2.5], ['Neuron 0', 'Neuron 1', 'Neuron 2'])
    plt.colorbar(label='State (-1/1)')
    plt.tight_layout()
    plt.show()

    # 3. Weight matrix visualization
    plt.figure(figsize=(8, 6))
    sns.heatmap(bm.weights, annot=True, fmt='.2f', cmap='RdYlBu', center=0,
                cbar_kws={'label': 'Weight Value'})
    plt.title('Weight Matrix')
    plt.xticks([0.5, 1.5, 2.5], ['N0', 'N1', 'N2'])
    plt.yticks([0.5, 1.5, 2.5], ['N0', 'N1', 'N2'])
    plt.tight_layout()
    plt.show()

    # 4. State distribution statistics
    plt.figure(figsize=(10, 6))
    unique_states = [tuple(state) for state in bm.states_history]
    state_counts = Counter(unique_states)

    states_labels = [f"{state}" for state in state_counts.keys()]
    counts = list(state_counts.values())

    colors = plt.cm.viridis(np.linspace(0, 1, len(counts)))
    bars = plt.bar(range(len(counts)), counts, color=colors, alpha=0.7)
    plt.xlabel('State Configuration')
    plt.ylabel('Frequency')
    plt.title('State Distribution Statistics')
    plt.xticks(range(len(states_labels)), states_labels, rotation=45)

    # Add value labels on bars
    for i, bar in enumerate(bars):
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2., height,
                 f'{height}', ha='center', va='bottom')

    plt.tight_layout()
    plt.show()


def create_interactive_demo():
    """Create interactive demonstration"""
    # Set fixed weights and biases for reproducibility
    weights = np.array([
        [0.0, 0.8, -0.5],
        [0.8, 0.0, 0.3],
        [-0.5, 0.3, 0.0]
    ])

    biases = np.array([0.2, -0.1, 0.3])

    print("=" * 60)
    print("3-Neuron Boltzmann Machine Demonstration")
    print("=" * 60)
    print(f"Weight Matrix:\n{weights}")
    print(f"Bias Vector: {biases}")
    print("=" * 60)

    # Run at different temperatures
    temperatures = [2.0, 1.0, 0.5]

    for i, temp in enumerate(temperatures):
        print(f"\n{'=' * 40}")
        print(f"Experiment {i + 1}: Temperature = {temp}")
        print(f"{'=' * 40}")

        bm = BoltzmannMachine(3, weights=weights, biases=biases, temperature=temp)

        # Find thermal equilibrium state
        equilibrium_state, equilibrium_energy = bm.find_equilibrium_state(num_steps=800)

        if equilibrium_state is not None:
            print(f"✓ Thermal equilibrium state at T={temp}: {equilibrium_state}")
            print(f"✓ Equilibrium energy: {equilibrium_energy:.4f}")
        else:
            print(f"⚠ No clear thermal equilibrium found at T={temp}")

        time.sleep(1)  # Pause for observation

    # Main visualization
    print(f"\n{'=' * 50}")
    print("Running Complete Visualization Simulation...")
    print(f"{'=' * 50}")

    bm_final = BoltzmannMachine(3, weights=weights, biases=biases, temperature=1.0)
    visualize_bm_simulation_separate(bm_final, num_steps=500)

    # Calculate energy for all possible states
    print(f"\n{'=' * 50}")
    print("Energy Analysis for All Possible States")
    print(f"{'=' * 50}")

    all_states = []
    for i in range(8):  # 3 neurons have 8 possible states
        state = []
        for j in range(3):
            if i & (1 << j):
                state.append(1)
            else:
                state.append(-1)
        all_states.append(state)

    print("State\t\tEnergy")
    print("-" * 30)
    for state in all_states:
        energy = bm_final.calculate_energy(np.array(state))
        print(f"{state}\t{energy:.4f}")

    # Find the ground state (minimum energy)
    energies = [bm_final.calculate_energy(np.array(state)) for state in all_states]
    min_energy_idx = np.argmin(energies)
    print(f"\nGround state: {all_states[min_energy_idx]}")
    print(f"Ground state energy: {energies[min_energy_idx]:.4f}")


if __name__ == "__main__":
    # Set random seed for reproducibility
    np.random.seed(42)

    create_interactive_demo()