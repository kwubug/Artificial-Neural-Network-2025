import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Hopfield'
    property int gridSize: hopfieldBridge.n_dim
    
    onGridSizeChanged: {
        if (patternModel) {
            patternModel.initializeModel()
        }
    }

    ColumnLayout {
        GroupBox {
            title: 'Pattern Drawing'
            Layout.fillWidth: true
            ColumnLayout {
                anchors.fill: parent
                Label {
                    text: 'Draw 8x8 Pattern (click cells to toggle X/.)'
                    font.bold: true
                }
                ScrollView {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 300
                    clip: true
                    Grid {
                        id: patternGrid
                        columns: gridSize
                        rows: gridSize
                        spacing: 1
                        Repeater {
                            model: patternModel
                            delegate: Rectangle {
                                width: 30
                                height: 30
                                border.color: '#888'
                                border.width: 1
                                color: model.value === 1 ? '#222' : 'white'
                                Text {
                                    anchors.centerIn: parent
                                    text: model.value === 1 ? 'X' : '.'
                                    font.pixelSize: 16
                                    color: model.value === 1 ? 'white' : 'black'
                                }
                                MouseArea {
                                    anchors.fill: parent
                                    onClicked: {
                                        const oldVal = patternModel.get(index).value
                                        patternModel.setProperty(index, 'value', oldVal === 1 ? -1 : 1)
                                    }
                                }
                            }
                        }
                    }
                }
                ListModel {
                    id: patternModel
                    Component.onCompleted: {
                        initializeModel()
                    }
                    function initializeModel() {
                        clear()
                        const size = gridSize * gridSize
                        for (let i = 0; i < size; i++) {
                            append({ value: -1 })
                        }
                    }
                }
                Button {
                    text: 'Store Pattern'
                    enabled: hopfieldBridge.has_finished
                    onClicked: {
                        const pattern = []
                        for (let i = 0; i < patternModel.count; i++) {
                            pattern.push(patternModel.get(i).value)
                        }
                        const currentPatterns = hopfieldBridge.patterns || []
                        currentPatterns.push(pattern)
                        hopfieldBridge.patterns = currentPatterns
                    }
                }
                Button {
                    text: 'Clear Pattern'
                    enabled: hopfieldBridge.has_finished
                    onClicked: {
                        for (let i = 0; i < patternModel.count; i++) {
                            patternModel.setProperty(i, 'value', -1)
                        }
                    }
                }
                Button {
                    text: 'Clear All Patterns'
                    enabled: hopfieldBridge.has_finished
                    onClicked: {
                        hopfieldBridge.patterns = []
                    }
                }
            }
        }
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label { text: 'Grid Size (N)'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    id: gridSizeSpin
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 8
                    from: 4; to: 16
                    onValueChanged: {
                        hopfieldBridge.n_dim = value
                        patternModel.initializeModel()
                    }
                    Component.onCompleted: hopfieldBridge.n_dim = value
                    Layout.fillWidth: true
                }
                Label { text: 'Select Pattern'; Layout.alignment: Qt.AlignHCenter }
                ComboBox {
                    enabled: hopfieldBridge.has_finished && hopfieldBridge.patterns && hopfieldBridge.patterns.length > 0
                    model: hopfieldBridge.patterns ? hopfieldBridge.patterns.length : 0
                    onActivated: hopfieldBridge.selected_pattern_idx = currentIndex
                    delegate: ItemDelegate {
                        text: 'Pattern ' + (index + 1)
                    }
                    Layout.fillWidth: true
                }
                Label { text: 'Noise Level'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 0.25 * 100
                    from: 0; to: 100
                    onValueChanged: hopfieldBridge.noise_level = value / 100
                    Component.onCompleted: hopfieldBridge.noise_level = value / 100
                    Layout.fillWidth: true
                }
                Label { text: 'Max Iter'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 2000
                    from: 100; to: 10000
                    onValueChanged: hopfieldBridge.max_iter = value
                    Component.onCompleted: hopfieldBridge.max_iter = value
                    Layout.fillWidth: true
                }
                Label { text: 'UI Refresh (s)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: hopfieldBridge.has_finished
                    editable: true
                    value: 1
                    onValueChanged: hopfieldBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: hopfieldBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Controls'
            Layout.fillWidth: true
            ExecutionControls {
                startButton.enabled: hopfieldBridge.has_finished && hopfieldBridge.patterns && hopfieldBridge.patterns.length > 0
                startButton.onClicked: () => {
                    energySeries.clear()
                    hopfieldBridge.start()
                }
                stopButton.enabled: !hopfieldBridge.has_finished
                stopButton.onClicked: hopfieldBridge.stop()
                progressBar.from: 0
                progressBar.to: hopfieldBridge.max_iter
                progressBar.value: hopfieldBridge.current_iter
                Layout.fillWidth: true
            }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        // Left: Pattern visualizations
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.5
            Layout.fillHeight: true
            GroupBox {
                title: 'Original Pattern'
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                Item {
                    anchors.fill: parent
                    Grid {
                        id: originalGrid
                        anchors.fill: parent
                        columns: gridSize
                        rows: gridSize
                        spacing: 1
                        Repeater {
                            model: gridSize * gridSize
                            delegate: Rectangle {
                                width: Math.floor(originalGrid.width / gridSize) - 1
                                height: Math.floor(originalGrid.height / gridSize) - 1
                                border.color: '#888'
                                border.width: 1
                                color: (hopfieldBridge.original_pattern && hopfieldBridge.original_pattern[index] === 1) ? '#222' : 'white'
                            }
                        }
                    }
                }
            }
            GroupBox {
                title: 'Corrupted Pattern'
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                Item {
                    anchors.fill: parent
                    Grid {
                        id: corruptedGrid
                        anchors.fill: parent
                        columns: gridSize
                        rows: gridSize
                        spacing: 1
                        Repeater {
                            model: gridSize * gridSize
                            delegate: Rectangle {
                                width: Math.floor(corruptedGrid.width / gridSize) - 1
                                height: Math.floor(corruptedGrid.height / gridSize) - 1
                                border.color: '#888'
                                border.width: 1
                                color: (hopfieldBridge.corrupted_state && hopfieldBridge.corrupted_state[index] === 1) ? '#222' : 'white'
                            }
                        }
                    }
                }
            }
            GroupBox {
                title: 'Current State (Recovery)'
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                Item {
                    anchors.fill: parent
                    Grid {
                        id: currentGrid
                        anchors.fill: parent
                        columns: gridSize
                        rows: gridSize
                        spacing: 1
                        Repeater {
                            model: gridSize * gridSize
                            delegate: Rectangle {
                                width: Math.floor(currentGrid.width / gridSize) - 1
                                height: Math.floor(currentGrid.height / gridSize) - 1
                                border.color: '#888'
                                border.width: 1
                                color: (hopfieldBridge.current_state && hopfieldBridge.current_state[index] === 1) ? '#222' : 'white'
                            }
                        }
                    }
                }
            }
        }
        // Right: Energy chart and info
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.5
            Layout.fillHeight: true
            ChartView {
                id: energyChart
                Layout.fillWidth: true
                Layout.fillHeight: true
                antialiasing: true
                title: 'Energy Over Iterations'
                legend.visible: true
                legend.alignment: Qt.AlignTop
                ValueAxis { id: axisX; min: 0; max: 100; titleText: 'Iteration' }
                ValueAxis { id: axisY; min: -100; max: 0; titleText: 'Energy' }
                LineSeries {
                    id: energySeries
                    name: 'Energy'
                    axisX: axisX
                    axisY: axisY
                    color: 'magenta'
                }
            }
            GroupBox {
                title: 'Info'
                Layout.fillWidth: true
                GridLayout {
                    columns: 2
                    Label { text: 'Current Iter' }
                    Label {
                        text: hopfieldBridge.current_iter
                        onTextChanged: {
                            if (hopfieldBridge.current_iter > 0) {
                                energySeries.append(hopfieldBridge.current_iter, hopfieldBridge.current_energy)
                                axisX.max = Math.max(axisX.max, hopfieldBridge.current_iter + 10)
                                axisY.min = Math.min(axisY.min, hopfieldBridge.current_energy)
                            }
                        }
                    }
                    Label { text: 'Current Energy' }
                    Label { text: hopfieldBridge.current_energy.toFixed(3) }
                    Label { text: 'Attractor Energy' }
                    Label { text: hopfieldBridge.attractor_energy.toFixed(3) }
                    Label { text: 'Stored Patterns' }
                    Label { text: hopfieldBridge.patterns ? hopfieldBridge.patterns.length : 0 }
                }
            }
        }
    }
}
