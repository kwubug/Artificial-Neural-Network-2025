import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei']
class NewtonMethod:
    def __init__(self, f, grad_f, hessian_f, learning_rate=1.0, tol=1e-6, max_iter=100):
        """
        牛顿法优化器

        参数:
        f: 目标函数
        grad_f: 梯度函数
        hessian_f: 海森矩阵函数
        learning_rate: 学习率（在牛顿法中通常为1）
        tol: 收敛容忍度
        max_iter: 最大迭代次数
        """
        self.f = f
        self.grad_f = grad_f
        self.hessian_f = hessian_f
        self.learning_rate = learning_rate
        self.tol = tol
        self.max_iter = max_iter
        self.history = []

    def optimize(self, x0):
        """
        使用牛顿法优化

        参数:
        x0: 初始点

        返回:
        x: 最优解
        history: 优化历史
        """
        x = np.array(x0, dtype=float)
        self.history = [x.copy()]

        for i in range(self.max_iter):
            # 计算梯度和海森矩阵
            grad = self.grad_f(x)
            hessian = self.hessian_f(x)

            # 检查海森矩阵是否正定，如果不是则添加正则化项
            try:
                # 解线性方程组: hessian * delta_x = -grad
                delta_x = np.linalg.solve(hessian, -grad)
            except np.linalg.LinAlgError:
                # 如果海森矩阵奇异，使用伪逆
                delta_x = -np.linalg.pinv(hessian) @ grad

            # 更新参数
            x_new = x + self.learning_rate * delta_x

            # 记录历史
            self.history.append(x_new.copy())

            # 检查收敛
            if np.linalg.norm(x_new - x) < self.tol:
                break

            x = x_new

        return x, self.history


# 示例1: 二次函数优化
def quadratic_function(x):
    """二次函数: f(x) = x^2 + 2x + 1"""
    return x[0] ** 2 + 2 * x[0] + 1


def quadratic_gradient(x):
    """二次函数的梯度"""
    return np.array([2 * x[0] + 2])


def quadratic_hessian(x):
    """二次函数的海森矩阵"""
    return np.array([[2]])


# 示例2: Rosenbrock函数（经典的测试函数）
def rosenbrock_function(x):
    """Rosenbrock函数: f(x,y) = (1-x)^2 + 100(y-x^2)^2"""
    return (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2


def rosenbrock_gradient(x):
    """Rosenbrock函数的梯度"""
    df_dx = -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2)
    df_dy = 200 * (x[1] - x[0] ** 2)
    return np.array([df_dx, df_dy])


def rosenbrock_hessian(x):
    """Rosenbrock函数的海森矩阵"""
    d2f_dx2 = 2 - 400 * x[1] + 1200 * x[0] ** 2
    d2f_dxdy = -400 * x[0]
    d2f_dydx = -400 * x[0]
    d2f_dy2 = 200
    return np.array([[d2f_dx2, d2f_dxdy], [d2f_dydx, d2f_dy2]])


# 可视化函数
def plot_optimization_1d(history, f, x_range=(-3, 1)):
    """绘制1D优化过程"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

    # 绘制函数曲线和优化路径
    x_vals = np.linspace(x_range[0], x_range[1], 100)
    y_vals = [f([x]) for x in x_vals]

    ax1.plot(x_vals, y_vals, 'b-', linewidth=2, label='f(x)')
    history_x = [point[0] for point in history]
    history_y = [f([point]) for point in history_x]

    ax1.plot(history_x, history_y, 'ro-', markersize=6, linewidth=1, label='优化路径')
    ax1.set_xlabel('x')
    ax1.set_ylabel('f(x)')
    ax1.set_title('牛顿法优化过程 (1D)')
    ax1.legend()
    ax1.grid(True)

    # 绘制收敛曲线
    iterations = range(len(history))
    function_values = [f([point[0]]) for point in history]

    ax2.semilogy(iterations, function_values, 'g-', linewidth=2)
    ax2.set_xlabel('迭代次数')
    ax2.set_ylabel('函数值 (对数尺度)')
    ax2.set_title('收敛曲线')
    ax2.grid(True)

    plt.tight_layout()
    plt.show()


def plot_optimization_2d(history, f, x_range=(-2, 2), y_range=(-1, 3)):
    """绘制2D优化过程"""
    fig = plt.figure(figsize=(15, 5))

    # 创建网格
    x = np.linspace(x_range[0], x_range[1], 100)
    y = np.linspace(y_range[0], y_range[1], 100)
    X, Y = np.meshgrid(x, y)
    Z = np.zeros_like(X)

    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            Z[i, j] = f([X[i, j], Y[i, j]])

    # 2D等高线图
    ax1 = fig.add_subplot(131)
    contour = ax1.contour(X, Y, Z, levels=50, alpha=0.6)
    ax1.clabel(contour, inline=True, fontsize=8)

    history_x = [point[0] for point in history]
    history_y = [point[1] for point in history]

    ax1.plot(history_x, history_y, 'ro-', markersize=6, linewidth=1, label='优化路径')
    ax1.plot(history_x[0], history_y[0], 'go', markersize=8, label='起点')
    ax1.plot(history_x[-1], history_y[-1], 'bo', markersize=8, label='终点')
    ax1.set_xlabel('x')
    ax1.set_ylabel('y')
    ax1.set_title('2D优化路径')
    ax1.legend()
    ax1.grid(True)

    # 3D曲面图
    ax2 = fig.add_subplot(132, projection='3d')
    surf = ax2.plot_surface(X, Y, Z, cmap='viridis', alpha=0.8)

    history_z = [f(point) for point in history]
    ax2.plot(history_x, history_y, history_z, 'ro-', linewidth=2, markersize=6)
    ax2.set_xlabel('x')
    ax2.set_ylabel('y')
    ax2.set_zlabel('f(x,y)')
    ax2.set_title('3D优化路径')

    # 收敛曲线
    ax3 = fig.add_subplot(133)
    iterations = range(len(history))
    ax3.semilogy(iterations, history_z, 'g-', linewidth=2)
    ax3.set_xlabel('迭代次数')
    ax3.set_ylabel('函数值 (对数尺度)')
    ax3.set_title('收敛曲线')
    ax3.grid(True)

    plt.tight_layout()
    plt.show()


def create_animation_2d(history, f, x_range=(-2, 2), y_range=(-1, 3)):
    """创建2D优化动画"""
    fig, ax = plt.subplots(figsize=(8, 6))

    # 创建网格
    x = np.linspace(x_range[0], x_range[1], 100)
    y = np.linspace(y_range[0], y_range[1], 100)
    X, Y = np.meshgrid(x, y)
    Z = np.zeros_like(X)

    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            Z[i, j] = f([X[i, j], Y[i, j]])

    # 绘制等高线
    contour = ax.contour(X, Y, Z, levels=20, alpha=0.6)
    ax.clabel(contour, inline=True, fontsize=8)

    line, = ax.plot([], [], 'ro-', markersize=6, linewidth=1)
    point, = ax.plot([], [], 'bo', markersize=8)
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_title('牛顿法优化过程')
    ax.grid(True)

    def animate(i):
        if i == 0:
            line.set_data([], [])
            point.set_data([], [])
        else:
            x_data = [point[0] for point in history[:i + 1]]
            y_data = [point[1] for point in history[:i + 1]]
            line.set_data(x_data, y_data)
            point.set_data([x_data[-1]], [y_data[-1]])
        return line, point

    anim = FuncAnimation(fig, animate, frames=len(history), interval=500, blit=True)
    plt.close()
    return anim


# 主函数示例
def main():
    print("牛顿法优化演示")
    print("=" * 50)

    # 示例1: 1D二次函数优化
    print("\n1. 一维二次函数优化")
    print("-" * 30)

    newton_1d = NewtonMethod(quadratic_function, quadratic_gradient, quadratic_hessian)
    x0_1d = np.array([-2.5])  # 初始点
    optimal_x, history_1d = newton_1d.optimize(x0_1d)

    print(f"初始点: x0 = {x0_1d[0]:.4f}")
    print(f"最优解: x* = {optimal_x[0]:.4f}")
    print(f"函数值: f(x*) = {quadratic_function(optimal_x):.6f}")
    print(f"迭代次数: {len(history_1d) - 1}")

    plot_optimization_1d(history_1d, quadratic_function)

    # 示例2: 2D Rosenbrock函数优化
    print("\n2. 二维Rosenbrock函数优化")
    print("-" * 30)

    newton_2d = NewtonMethod(rosenbrock_function, rosenbrock_gradient, rosenbrock_hessian)
    x0_2d = np.array([-1.5, 2.0])  # 初始点
    optimal_xy, history_2d = newton_2d.optimize(x0_2d)

    print(f"初始点: ({x0_2d[0]:.4f}, {x0_2d[1]:.4f})")
    print(f"最优解: ({optimal_xy[0]:.4f}, {optimal_xy[1]:.4f})")
    print(f"函数值: f(x*, y*) = {rosenbrock_function(optimal_xy):.6f}")
    print(f"迭代次数: {len(history_2d) - 1}")

    plot_optimization_2d(history_2d, rosenbrock_function)

    # 创建动画（可选）
    print("\n3. 生成优化动画...")
    anim = create_animation_2d(history_2d, rosenbrock_function)

    # 保存动画（需要安装ffmpeg）
    try:
        anim.save('newton_method_optimization.gif', writer='pillow', fps=2)
        print("动画已保存为 'newton_method_optimization.gif'")
    except:
        print("无法保存动画，但程序运行正常完成")

    print("\n优化完成!")


if __name__ == "__main__":
    main()