import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import matplotlib.font_manager as fm
from datetime import datetime


# -------------------------- 修复字体设置问题 --------------------------
def setup_chinese_fonts():
    """
    修复字体检测错误，确保中文正常显示
    通过字体文件路径提取字体名称，避免 AttributeError
    """
    try:
        # 获取系统中所有ttf字体文件路径
        font_files = fm.findSystemFonts(fontpaths=None, fontext='ttf')

        # 从字体文件路径中提取字体名称（修复AttributeError）
        available_fonts = []
        for font_path in font_files:
            try:
                # 尝试从字体文件中获取字体名称
                font_prop = fm.FontProperties(fname=font_path)
                font_name = font_prop.get_name()
                available_fonts.append(font_name)
            except:
                # 提取失败时尝试从文件名解析
                font_name = os.path.basename(font_path).split('.')[0]
                available_fonts.append(font_name)

        # 中文字体候选列表（按优先级排序）
        chinese_font_candidates = [
            'Microsoft YaHei',  # Windows系统默认雅黑
            'SimHei',  # 黑体
            'WenQuanYi Micro Hei',  # 文泉驿微米黑
            'Heiti TC',  # 苹果黑体
            'Arial Unicode MS',  # 跨平台Unicode字体
            'SimSun',  # 宋体
            'Microsoft JhengHei'  # 微软正黑
        ]

        # 选择系统中已安装的第一个中文字体
        selected_font = None
        for font in chinese_font_candidates:
            if font in available_fonts:
                selected_font = font
                break

        # 如果没有找到中文字体，使用默认字体
        if selected_font:
            plt.rcParams["font.family"] = [selected_font]
        else:
            plt.rcParams["font.family"] = ["Arial", "Helvetica", "sans-serif"]

        # 解决负号显示问题
        plt.rcParams["axes.unicode_minus"] = False

        # 输出使用的字体信息（便于调试）
        print(f"使用字体: {plt.rcParams['font.family'][0]}")

    except Exception as e:
        # 出现任何错误时使用最基础的字体设置
        print(f"字体设置警告: {str(e)}，使用默认字体")
        plt.rcParams["font.family"] = ["Arial", "Helvetica", "sans-serif"]
        plt.rcParams["axes.unicode_minus"] = False


# 初始化字体设置
setup_chinese_fonts()


# -------------------------- 神经网络核心类 --------------------------
class SingleNodeNN:
    """6输入单节点神经网络类"""

    def __init__(self, input_size=6, learning_rule='delta', activation='sigmoid', learning_rate=0.1, threshold=0):
        self.input_size = input_size
        # 初始化权重（包括偏置项，共7个参数：6个输入权重+1个偏置）
        self.weights = np.random.randn(input_size + 1)
        self.learning_rule = learning_rule
        self.activation = activation
        self.learning_rate = learning_rate
        self.threshold = threshold

    def activation_function(self, net_input):
        """激活函数实现"""
        if self.activation == 'sigmoid':
            return 1 / (1 + np.exp(-net_input))
        elif self.activation == 'step':
            return 1 if net_input > self.threshold else 0
        elif self.activation == 'tanh':
            return np.tanh(net_input)
        else:
            raise ValueError("激活函数仅支持：'sigmoid'、'step'、'tanh'")

    def activation_derivative(self, output):
        """激活函数导数（用于Delta规则）"""
        if self.activation == 'sigmoid':
            return output * (1 - output)
        elif self.activation == 'step':
            return 1  # 阶跃函数导数近似值
        elif self.activation == 'tanh':
            return 1 - output ** 2
        else:
            raise ValueError("激活函数仅支持：'sigmoid'、'step'、'tanh'")

    def compute_net_input(self, inputs):
        """计算净输入（包含偏置项）"""
        inputs_with_bias = np.append(inputs, 1)  # 添加偏置输入1
        return np.dot(self.weights, inputs_with_bias)

    def predict(self, inputs):
        """预测输出"""
        return self.activation_function(self.compute_net_input(inputs))

    def train_step(self, inputs, target):
        """单步训练过程"""
        output = self.predict(inputs)
        net_input = self.compute_net_input(inputs)

        # 根据学习规则计算权重变化
        if self.learning_rule == 'delta':
            error = target - output
            delta = error * self.activation_derivative(output)
            weight_change = self.learning_rate * delta * np.append(inputs, 1)
        elif self.learning_rule == 'hebb':
            weight_change = self.learning_rate * output * np.append(inputs, 1)
        else:
            raise ValueError("学习规则仅支持：'delta'、'hebb'")

        # 更新权重
        old_weights = self.weights.copy()
        self.weights += weight_change

        return net_input, old_weights, self.weights, output, target, weight_change


# -------------------------- 样本生成函数 --------------------------
def generate_sample_data(sample_type='random', num_samples=10):
    """生成不同类型的训练样本"""
    if sample_type == 'random':
        inputs = np.random.rand(num_samples, 6)  # 随机输入
        targets = np.random.randint(0, 2, size=num_samples)  # 随机目标值
    elif sample_type == 'logic_and':
        inputs = np.random.randint(0, 2, size=(num_samples, 6))  # 二进制输入
        targets = np.prod(inputs, axis=1)  # 逻辑AND：全1则1，否则0
    elif sample_type == 'logic_or':
        inputs = np.random.randint(0, 2, size=(num_samples, 6))  # 二进制输入
        targets = np.minimum(np.sum(inputs, axis=1), 1)  # 逻辑OR：至少1个1则1
    else:
        raise ValueError("样本类型仅支持：'random'、'logic_and'、'logic_or'")
    return inputs, targets


# -------------------------- Excel结果保存 --------------------------
def save_results_to_excel(results, params):
    """将训练结果保存到Excel文件"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"nn_training_results_{timestamp}.xlsx"

    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        # 保存参数设置
        params_df = pd.DataFrame(list(params.items()), columns=['参数', '值'])
        params_df.to_excel(writer, sheet_name='参数设置', index=False)

        # 保存训练详情
        results_df = pd.DataFrame(results)
        # 处理列表类型数据，便于Excel显示
        list_columns = ['输入', '更新前权重', '权重变化', '更新后权重']
        for col in list_columns:
            results_df[col] = results_df[col].apply(lambda x: [round(v, 4) for v in x])
            results_df[col] = results_df[col].astype(str)
        results_df.to_excel(writer, sheet_name='训练详情', index=False)

        # 计算并保存每轮平均误差
        epoch_errors = {}
        for res in results:
            epoch = res['轮次']
            if epoch not in epoch_errors:
                epoch_errors[epoch] = []
            epoch_errors[epoch].append(res['误差'])

        epoch_avg_errors = [
            {'轮次': epoch, '平均误差': round(np.mean(errors), 4)}
            for epoch, errors in epoch_errors.items()
        ]
        pd.DataFrame(epoch_avg_errors).to_excel(writer, sheet_name='轮次误差', index=False)

    print(f"训练结果已保存到Excel文件: {filename}")
    return filename


# -------------------------- 训练可视化 --------------------------
def plot_training_results(results, params):
    """绘制训练误差和权重变化图表"""
    # 创建保存目录
    if not os.path.exists('plots'):
        os.makedirs('plots')

    # 提取每轮平均误差
    epoch_data = {}
    for res in results:
        epoch = res['轮次']
        if epoch not in epoch_data:
            epoch_data[epoch] = []
        epoch_data[epoch].append(res['误差'])

    epochs = sorted(epoch_data.keys())
    avg_errors = [np.mean(epoch_data[e]) for e in epochs]

    # 创建图表
    plt.figure(figsize=(12, 10))

    # 误差曲线
    plt.subplot(2, 1, 1)
    plt.plot(epochs, avg_errors, 'b-', marker='o', linewidth=2)
    plt.title(f'训练误差曲线 (学习规则: {params["学习规则"]}, 激活函数: {params["激活函数"]})', fontsize=12)
    plt.xlabel('训练轮次', fontsize=10)
    plt.ylabel('平均误差', fontsize=10)
    plt.grid(True, alpha=0.3)

    # 权重变化曲线
    plt.subplot(2, 1, 2)
    weight_names = [f'输入权重{i + 1}' for i in range(6)] + ['偏置']

    # 提取每轮第一个样本的权重作为该轮的权重代表
    epoch_weights = {}
    for res in results:
        if res['样本索引'] == 1 and res['轮次'] not in epoch_weights:
            epoch_weights[res['轮次']] = res['更新后权重']

    # 按轮次排序并绘图
    sorted_epochs = sorted(epoch_weights.keys())
    for i, name in enumerate(weight_names):
        weights = [epoch_weights[e][i] for e in sorted_epochs]
        plt.plot(sorted_epochs, weights, label=name, linewidth=1.5)

    plt.title('权重变化曲线', fontsize=12)
    plt.xlabel('训练轮次', fontsize=10)
    plt.ylabel('权重值', fontsize=10)
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')  # 图例放在右侧
    plt.grid(True, alpha=0.3)

    plt.tight_layout()

    # 保存图表
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f'plots/nn_training_plot_{timestamp}.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"训练图表已保存到: {filename}")
    plt.close()  # 关闭图表，避免显示问题

    return filename


# -------------------------- 主训练函数 --------------------------
def train_network(epochs=50, sample_type='logic_and', num_samples=10, **kwargs):
    """训练神经网络的主函数"""
    # 初始化神经网络
    valid_params = ['input_size', 'learning_rule', 'activation', 'learning_rate', 'threshold']
    nn_params = {k: v for k, v in kwargs.items() if k in valid_params}
    nn = SingleNodeNN(**nn_params)

    # 生成训练样本
    inputs, targets = generate_sample_data(sample_type, num_samples)

    # 记录训练参数
    training_params = {
        '学习规则': nn.learning_rule,
        '激活函数': nn.activation,
        '学习率': nn.learning_rate,
        '阈值': nn.threshold,
        '训练轮次': epochs,
        '样本类型': sample_type,
        '样本数量': num_samples,
        '初始权重': [round(w, 4) for w in nn.weights]
    }

    print(f"初始权重: {[round(w, 4) for w in nn.weights]}")
    print(f"学习规则: {nn.learning_rule}, 激活函数: {nn.activation}, 学习率: {nn.learning_rate}")
    print("=" * 80)

    # 训练过程
    training_results = []
    for epoch in range(epochs):
        print(f"第 {epoch + 1} 轮训练:")
        total_error = 0

        for i in range(len(inputs)):
            # 单步训练
            net_input, old_weights, new_weights, output, target, weight_change = nn.train_step(inputs[i], targets[i])
            error = abs(target - output)
            total_error += error

            # 记录结果
            training_results.append({
                '轮次': epoch + 1,
                '样本索引': i + 1,
                '输入': inputs[i].tolist(),
                '净输入': round(net_input, 4),
                '输出': round(output, 4),
                '目标输出': int(target),
                '误差': round(error, 4),
                '更新前权重': old_weights.tolist(),
                '权重变化': weight_change.tolist(),
                '更新后权重': new_weights.tolist()
            })

            # 显示单步信息
            print(f"  样本 {i + 1}:")
            print(f"    输入: {inputs[i].tolist()}")
            print(f"    净输入: {round(net_input, 4)}, 输出: {round(output, 4)}, 目标: {target}")
            print(f"    误差: {round(error, 4)}")
            print(f"    权重变化: {[round(w, 4) for w in weight_change]}")
            print("  " + "-" * 70)

        avg_error = round(total_error / len(inputs), 4)
        print(f"  本轮平均误差: {avg_error}")
        print("=" * 80)

        # 提前停止条件
        if avg_error < 0.01:
            print(f"在第 {epoch + 1} 轮达到足够小的误差，提前停止训练")
            break

    # 保存结果到Excel
    excel_file = save_results_to_excel(training_results, training_params)

    # 绘制训练图表
    plot_file = plot_training_results(training_results, training_params)

    return nn, excel_file, plot_file


# -------------------------- 程序入口 --------------------------
if __name__ == "__main__":
    # 示例训练配置
    train_network(
        epochs=50,
        learning_rule='delta',  # 可选 'delta' 或 'hebb'
        activation='sigmoid',  # 可选 'sigmoid', 'step', 'tanh'
        learning_rate=0.1,
        sample_type='logic_and',  # 可选 'random', 'logic_and', 'logic_or'
        num_samples=10
    )
