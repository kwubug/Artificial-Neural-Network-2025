import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'Boltzmann Machine'

    ColumnLayout {
        GroupBox {
            title: 'Settings'
            Layout.fillWidth: true
            GridLayout {
                anchors.fill: parent
                columns: 2
                Label { text: 'Initial State x(0)'; Layout.alignment: Qt.AlignHCenter }
                TextField {
                    id: initState
                    enabled: bmBridge.has_finished
                    text: '0,0,0'
                    onEditingFinished: {
                        const parts = text.split(',').map(s => parseInt(s.trim()))
                        bmBridge.initial_state = parts
                    }
                    Component.onCompleted: {
                        const parts = text.split(',').map(s => parseInt(s.trim()))
                        bmBridge.initial_state = parts
                    }
                    Layout.fillWidth: true
                }
                
                Label { text: 'gamma'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 0.8 * 100
                    onValueChanged: bmBridge.gamma = value / 100
                    Component.onCompleted: bmBridge.gamma = value / 100
                    Layout.fillWidth: true
                }
                Label { text: 'T0'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 5.0 * 100
                    from: 100; to: 1000
                    onValueChanged: bmBridge.T0 = value / 100
                    Component.onCompleted: bmBridge.T0 = value / 100
                    Layout.fillWidth: true
                }
                Label { text: 'Steps per Temp'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 1
                    from: 1; to: 50
                    onValueChanged: bmBridge.steps_per_temp = value
                    Component.onCompleted: bmBridge.steps_per_temp = value
                    Layout.fillWidth: true
                }
                Label { text: 'Max Iter'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 200
                    from: 10; to: 5000
                    onValueChanged: bmBridge.max_iter = value
                    Component.onCompleted: bmBridge.max_iter = value
                    Layout.fillWidth: true
                }
                Label { text: 'Update Freq'; Layout.alignment: Qt.AlignHCenter }
                SpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 5
                    from: 1; to: 100
                    onValueChanged: bmBridge.update_freq = value
                    Component.onCompleted: bmBridge.update_freq = value
                    Layout.fillWidth: true
                }
                Label { text: 'UI Refresh (s)'; Layout.alignment: Qt.AlignHCenter }
                DoubleSpinBox {
                    enabled: bmBridge.has_finished
                    editable: true
                    value: 1
                    onValueChanged: bmBridge.ui_refresh_interval = value / 100
                    Component.onCompleted: bmBridge.ui_refresh_interval = value / 100
                    Layout.fillWidth: true
                }
            }
        }
        GroupBox {
            title: 'Controls'
            Layout.fillWidth: true
            ExecutionControls {
                startButton.enabled: bmBridge.has_finished
                startButton.onClicked: () => {
                    energySeries.clear()
                    tempSeries.clear()
                    x1Series.clear(); x2Series.clear(); x3Series.clear()
                    stateModel.clear()
                    bmBridge.start()
                }
                stopButton.enabled: !bmBridge.has_finished
                stopButton.onClicked: bmBridge.stop()
                progressBar.from: 0
                progressBar.to: bmBridge.max_iter
                progressBar.value: bmBridge.k
                Layout.fillWidth: true
            }
        }
    }
    RowLayout {
        Layout.fillWidth: true
        Layout.fillHeight: true
        // Left: state and energy charts stacked
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.65
            Layout.fillHeight: true
            ChartView {
                id: stateChart
                Layout.fillWidth: true
                Layout.preferredHeight: 300
                antialiasing: true
                title: 'State x(t)'
                legend.visible: true
                legend.alignment: Qt.AlignTop
                ValueAxis { id: sAxisX; min: 0; max: 10; titleText: 'k' }
                ValueAxis { id: sAxisY; min: -0.1; max: 1.1; titleText: 'x_i' }
                LineSeries { id: x1Series; name: 'x1'; axisX: sAxisX; axisY: sAxisY; color: 'red' }
                LineSeries { id: x2Series; name: 'x2'; axisX: sAxisX; axisY: sAxisY; color: 'green' }
                LineSeries { id: x3Series; name: 'x3'; axisX: sAxisX; axisY: sAxisY; color: 'blue' }
            }
            ChartView {
                id: energyChart
                Layout.fillWidth: true
                Layout.preferredHeight: 300
                antialiasing: true
                title: 'Energy and Temperature'
                legend.visible: true
                legend.alignment: Qt.AlignTop
                ValueAxis { id: eAxisX; min: 0; max: 10; titleText: 'k' }
                ValueAxis { id: eAxisY; min: 0; max: 5; titleText: 'Energy' }
                ValueAxis { id: tAxisY; min: 0; max: 5; titleText: 'T' }
                LineSeries { id: energySeries; name: 'Energy'; axisX: eAxisX; axisY: eAxisY; color: 'magenta' }
                LineSeries { id: tempSeries; name: 'T'; axisX: eAxisX; axisY: tAxisY; color: 'cyan' }
            }
        }
        // Right: minimal live list of states
        ColumnLayout {
            Layout.preferredWidth: parent.width * 0.35
            Layout.fillHeight: true
            Label {
                text: 'Live States'
                font.bold: true
                Layout.fillWidth: true
            }
            ScrollView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                ListView {
                    id: stateList
                    anchors.fill: parent
                    model: stateModel
                    delegate: Label { text: model.display }
                }
            }
        }
    }

    ListModel { id: stateModel }

    // Live updates - use Label's onTextChanged to listen to property changes
    Label {
        visible: false
        text: bmBridge.k
        onTextChanged: {
            const kVal = bmBridge.k
            if (kVal > 0) {
                // Append to charts
                sAxisX.max = Math.max(sAxisX.max, kVal + 1)
                eAxisX.max = Math.max(eAxisX.max, kVal + 1)
                if (bmBridge.x_state && bmBridge.x_state.length === 3) {
                    x1Series.append(kVal, bmBridge.x_state[0])
                    x2Series.append(kVal, bmBridge.x_state[1])
                    x3Series.append(kVal, bmBridge.x_state[2])
                }
                energySeries.append(kVal, bmBridge.energy)
                tempSeries.append(kVal, bmBridge.temperature)
                eAxisY.max = Math.max(eAxisY.max, bmBridge.energy + 0.5)
                tAxisY.max = Math.max(tAxisY.max, bmBridge.temperature + 0.5)
                // Minimal list: show k, state, and updated neuron
                const neuronIdx = bmBridge.updated_neuron
                const neuronStr = neuronIdx >= 0 ? `  neuron=x${neuronIdx + 1}` : ''
                stateModel.append({ display: `k=${kVal}  x=[${bmBridge.x_state}]${neuronStr}` })
                // Keep list length reasonable
                if (stateModel.count > 200) stateModel.remove(0)
            }
        }
    }
}


