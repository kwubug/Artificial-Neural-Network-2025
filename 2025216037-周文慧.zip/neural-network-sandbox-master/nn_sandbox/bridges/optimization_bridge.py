import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms import OptimizationAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable
from ..backend.surface_visualizer import SurfaceVisualizer


class OptimizationBridge(Bridge):
    objective_function = BridgeProperty(0)  # 新增：目标函数选择
    optimization_method = BridgeProperty(0)
    learning_rate = BridgeProperty(0.1)
    max_iterations = BridgeProperty(100)
    threshold = BridgeProperty(0.001)
    start_x = BridgeProperty(2.0)
    start_y = BridgeProperty(2.0)
    current_iteration = BridgeProperty(0)
    current_x = BridgeProperty(0.0)
    current_y = BridgeProperty(0.0)
    current_value = BridgeProperty(0.0)
    gradient_norm = BridgeProperty(0.0)
    surface_image = BridgeProperty("")  # Base64编码的3D图像
    has_finished = BridgeProperty(True)
    
    pathPointAdded = PyQt5.QtCore.pyqtSignal(float, float, float)
    surfaceUpdated = PyQt5.QtCore.pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.optimization_algorithm = None
        self.visualizer = SurfaceVisualizer()
        self.path_points = []

    @PyQt5.QtCore.pyqtSlot()
    def start_optimization(self):
        self.path_points = []
        # 生成初始3D图（根据选择的函数）
        img_base64 = self.visualizer.generate_surface(self.objective_function)
        self.surface_image = img_base64
        self.surfaceUpdated.emit(img_base64)
        
        self.optimization_algorithm = ObservableOptimizationAlgorithm(
            self,
            objective_function=self.objective_function,  # 传递函数选择
            optimization_method=self.optimization_method,
            learning_rate=self.learning_rate,
            max_iterations=self.max_iterations,
            threshold=self.threshold,
            start_x=self.start_x,
            start_y=self.start_y
        )
        self.optimization_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_optimization(self):
        if self.optimization_algorithm:
            self.optimization_algorithm.stop()
            self.optimization_algorithm.wait(1000)
            self.optimization_algorithm = None


class ObservableOptimizationAlgorithm(Observable, OptimizationAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        OptimizationAlgorithm.__init__(self, **kwargs)

    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ('current_iteration', 'current_x', 'current_y', 'current_value', 'gradient_norm'):
            self.notify(name, value)

    def run(self):
        self.notify('has_finished', False)
        try:
            super().run()
        finally:
            self._running = True
            self.notify('has_finished', True)

    def add_path_point(self, x, y, value):
        self._observer.path_points.append((x, y))
        self._observer.pathPointAdded.emit(x, y, value)
        
        # 每5个点更新一次3D图
        if len(self._observer.path_points) % 5 == 0:
            img_base64 = self._observer.visualizer.generate_surface(
                self._observer.objective_function,
                self._observer.path_points
            )
            self._observer.surface_image = img_base64
            self._observer.surfaceUpdated.emit(img_base64)
        
        time.sleep(0.05)