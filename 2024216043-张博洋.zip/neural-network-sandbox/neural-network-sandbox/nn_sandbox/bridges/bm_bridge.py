import time
import PyQt5.QtCore

from nn_sandbox.backend.algorithms.bm_algorithm import BMAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable

class BmBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.05)
    total_epoches = BridgeProperty(200)
    temperature = BridgeProperty(1.0)
    current_epoch = BridgeProperty(0)
    neuron_state = BridgeProperty([])
    current_energy = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.bm_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm_algorithm(self):
        """Start the BM algorithm."""
        self.bm_algorithm = ObservableBMAlgorithm(
            observer=self,
            ui_refresh_interval=self.ui_refresh_interval,
            total_epoches=self.total_epoches,
            temperature=self.temperature,
            num_neurons=3,  # 明确传入神经元数量
            initial_state=None,  # 可以传入初始状态，如果需要
            weights=None,  # 可以传入初始权重
            bias=None  # 可以传入偏置
        )
        self.bm_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()

class ObservableBMAlgorithm(Observable, BMAlgorithm):
    def __init__(self, observer, ui_refresh_interval, total_epoches=200,
                 temperature=1.0, num_neurons=3, initial_state=None,
                 weights=None, bias=None):
        Observable.__init__(self, observer)
        BMAlgorithm.__init__(
            self,
            total_epoches=total_epoches,
            temperature=temperature,
        )
        self.num_neurons = num_neurons
        if initial_state is not None:
            self.state = initial_state
        if weights is not None:
            self.weights = weights
        if bias is not None:
            self.bias = bias
        self.ui_refresh_interval = ui_refresh_interval

    def emit_signal(self, data: dict):
        # 通知 QML 更新
        self.notify('current_epoch', data['epoch'])
        self.notify('neuron_state', data['state'])
        self.notify('current_energy', data['energy'])

    def run(self):
        self.notify('has_finished', False)
        super().run()
        self.notify('has_finished', True)

    def _iterate(self):
        state, energy = super()._iterate()
        time.sleep(self.ui_refresh_interval)
        return state, energy
