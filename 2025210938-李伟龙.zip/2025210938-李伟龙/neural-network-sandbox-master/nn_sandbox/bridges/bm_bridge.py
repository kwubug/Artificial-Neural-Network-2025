from nn_sandbox.backend.algorithms import BmAlgorithm
from nn_sandbox.bridges.observer import Observer
from nn_sandbox.bridges.bridge import Bridge
import numpy as np


class ObservableBmAlgorithm(Observer, BmAlgorithm):
    """BM 算法的可观察版本"""

    def __init__(self, **kwargs):
        # 自动生成一个虚拟数据集（100行 × 5列，最后一列为标签）
        dataset = kwargs.get("dataset")
        if dataset is None:
            X = np.random.rand(100, 4)  # 特征
            y = np.random.randint(0, 2, (100, 1))  # 标签
            dataset = np.hstack([X, y])

        super().__init__(
            dataset=dataset,
            total_epoches=kwargs.get("total_epoches", 100),
            most_correct_rate=kwargs.get("most_correct_rate", 0.99),
            initial_learning_rate=kwargs.get("initial_learning_rate", 0.1),
            search_iteration_constant=kwargs.get("search_iteration_constant", 50),
            test_ratio=kwargs.get("test_ratio", 0.2)
        )

    def _initialize_neurons(self):
        """初始化神经元"""
        # 假设网络有4个输入神经元（对应4个特征）
        self._neurons = np.random.rand(4)
        print("[INIT] 神经元初始化完成")

    def _iterate(self):
        """执行 BM 一次迭代"""
        # 这里简单模拟学习率下降
        lr = self.current_learning_rate
        self._neurons -= lr * np.random.rand(4)
        print(f"[ITERATE] 迭代中, 学习率={lr:.4f}")

    def _correct_rate(self, dataset=None):
        """计算纠正率"""
        if dataset is None:
            dataset = self.testing_dataset
        # 简单用随机数模拟精度
        return np.random.rand()


class BmBridge(Bridge):
    """BM 的 QML 桥接层"""
    def __init__(self):
        super().__init__()
        self.bm_algorithm = ObservableBmAlgorithm()

    def run(self):
        print("[RUN] 开始运行 BM 算法")
        self.bm_algorithm.run()
        rate = self.bm_algorithm._correct_rate()
        print("BM algorithm finished, rate:", rate)
