# file: rbf_hermite_approx.py
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import matplotlib.pyplot as plt
import os
from matplotlib.colors import LinearSegmentedColormap

# ---------- data generation ----------
def F(x: np.ndarray) -> np.ndarray:
    return 1.1 * (1 - x + 2 * x**2) * np.exp(-x**2 / 2.0)

def make_dataset(P: int = 100, x_low: float = -4.0, x_high: float = 4.0,
                 noise_std: float = 0.1, seed: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    x = rng.uniform(x_low, x_high, size=P)
    y_clean = F(x)
    y = y_clean + rng.normal(0.0, noise_std, size=P)
    order = np.argsort(x)
    return x[order], y[order]

# ---------- RBF utilities ----------
def gaussian_phi(x: np.ndarray, c: np.ndarray, s: np.ndarray) -> np.ndarray:
    # x: (P,), c: (M,), s: (M,)
    x_col = x[:, None]
    return np.exp(- (x_col - c[None, :])**2 / (2.0 * (s[None, :]**2)))

def design_matrix(x: np.ndarray, c: np.ndarray, s: np.ndarray) -> np.ndarray:
    Phi = gaussian_phi(x, c, s)  # (P, M)
    return np.concatenate([Phi, np.ones((Phi.shape[0], 1))], axis=1)  # + bias

# ---------- K-Means (1D) ----------
def kmeans_1d(x: np.ndarray, K: int, init_centers: np.ndarray,
              max_iter: int = 100) -> np.ndarray:
    c = init_centers.astype(float).copy()
    for _ in range(max_iter):
        # assignment
        dist = np.abs(x[:, None] - c[None, :])
        idx = np.argmin(dist, axis=1)
        new_c = c.copy()
        for k in range(K):
            pts = x[idx == k]
            if len(pts) > 0:
                new_c[k] = np.mean(pts)
        if np.allclose(new_c, c):
            break
        c = new_c
    return np.sort(c)

def widths_from_nn(c: np.ndarray, lam: float = 1.0) -> np.ndarray:
    M = len(c)
    s = np.empty(M, dtype=float)
    for j in range(M):
        d = np.min(np.abs(c[j] - np.delete(c, j)))
        s[j] = lam * d / np.sqrt(2.0)
    # 边界情形（孤立中心）兜底
    eps = np.median(s[s > 0]) if np.any(s > 0) else 0.5
    s[s <= 1e-8] = eps
    return s

# ---------- Method (1): clustering + pseudoinverse ----------
@dataclass
class ClusterRBFResult:
    c: np.ndarray
    s: np.ndarray
    w: np.ndarray
    b: float
    rmse: float

def rbf_cluster_fit(x: np.ndarray, y: np.ndarray, M: int = 10, lam: float = 1.0) -> ClusterRBFResult:
    init_c = x[:M]  # 题意：前 10 个样本为初始中心
    c = kmeans_1d(x, M, init_c)
    s = widths_from_nn(c, lam)
    Phi_b = design_matrix(x, c, s)  # (P, M+1)
    theta = np.linalg.pinv(Phi_b) @ y  # [w;b]
    w, b = theta[:-1], float(theta[-1])
    y_hat = Phi_b @ theta
    rmse = float(np.sqrt(np.mean((y_hat - y) ** 2)))
    return ClusterRBFResult(c=c, s=s, w=w, b=b, rmse=rmse)

# ---------- Method (2): gradient descent ----------
@dataclass
class GDConfig:
    M: int = 10
    lr: float = 1e-3
    max_iter: int = 5000
    rmse_goal: float = 0.09
    seed: int = 1

@dataclass
class GDRBFResult:
    c: np.ndarray
    s: np.ndarray
    w: np.ndarray
    b: float
    rmse_hist: np.ndarray

def rbf_gd_fit(x: np.ndarray, y: np.ndarray, cfg: GDConfig = GDConfig()) -> GDRBFResult:
    rng = np.random.default_rng(cfg.seed)
    # 初始化
    w = rng.uniform(-0.1, 0.1, size=cfg.M)
    c = rng.uniform(-4.0, 4.0, size=cfg.M)
    s = rng.uniform(0.1, 0.3, size=cfg.M)
    b = 0.0

    rmse_hist = []

    for t in range(cfg.max_iter):
        Phi = gaussian_phi(x, c, s)                  # (P, M)
        y_hat = Phi @ w + b                          # (P,)
        err = y_hat - y                              # (P,)
        P = x.shape[0]
        # RMSE
        rmse = float(np.sqrt(np.mean(err**2)))
        rmse_hist.append(rmse)
        if rmse <= cfg.rmse_goal:
            break

        # 梯度（批量）
        # why: 一次性批量梯度更稳定
        grad_w = (2.0 / P) * (Phi * err[:, None]).sum(axis=0)
        # dφ/dc = φ * (x - c)/s^2
        dphi_dc = Phi * (x[:, None] - c[None, :]) / (s[None, :] ** 2)
        grad_c = (2.0 / P) * (err[:, None] * (w[None, :] * dphi_dc)).sum(axis=0)
        # dφ/ds = φ * (x - c)^2 / s^3
        dphi_ds = Phi * ((x[:, None] - c[None, :]) ** 2) / (s[None, :] ** 3)
        grad_s = (2.0 / P) * (err[:, None] * (w[None, :] * dphi_ds)).sum(axis=0)
        grad_b = float((2.0 / P) * err.sum())

        # 参数更新
        w -= cfg.lr * grad_w
        c -= cfg.lr * grad_c
        s -= cfg.lr * grad_s
        b -= cfg.lr * grad_b
        s = np.clip(s, 1e-3, 3.0)  # 宽度稳定性约束

    return GDRBFResult(c=c, s=s, w=w, b=b, rmse_hist=np.array(rmse_hist, dtype=float))

# ---------- evaluation ----------
def predict(x: np.ndarray, c: np.ndarray, s: np.ndarray, w: np.ndarray, b: float) -> np.ndarray:
    return gaussian_phi(x, c, s) @ w + b

# ---------- main experiment ----------
def main() -> None:
    # 数据
    x, y = make_dataset(P=100, seed=7)
    x_grid = np.linspace(-4, 4, 400)
    y_true = F(x_grid)

    # 方法(1)
    cl_res = rbf_cluster_fit(x, y, M=10, lam=1.0)
    y_cl = predict(x_grid, cl_res.c, cl_res.s, cl_res.w, cl_res.b)

    # 方法(2)
    gd_cfg = GDConfig(M=10, lr=1e-3, max_iter=5000, rmse_goal=0.09, seed=3)
    gd_res = rbf_gd_fit(x, y, cfg=gd_cfg)
    y_gd = predict(x_grid, gd_res.c, gd_res.s, gd_res.w, gd_res.b)

    # 创建rbf文件夹（若不存在）
    os.makedirs("rbf", exist_ok=True)

    # 定义红紫色系配色方案
    colors = {
        "true": "#8B008B",  # 深紫色：真实函数曲线
        "samples": "#FF69B4",  # 粉红色：样本点
        "cluster": "#9370DB",  # 中紫色：Cluster + pinv方法
        "gd": "#C71585",  # 紫红色：GD-trained RBF方法
        "rmse_line": "#800080",  # 深紫色：RMSE曲线
        "rmse_goal": "#DDA0DD",  # 淡紫色：目标RMSE线
        "text": "#4B0082"  # 靛蓝色：标题和标签
    }

    # --------------------------
    # 可视化：拟合曲线
    # --------------------------
    fig1, ax1 = plt.subplots(figsize=(7, 5))

    # 绘制曲线（红紫色系）
    ax1.plot(x_grid, y_true, label="True F(x)", color=colors["true"], linewidth=2)
    ax1.scatter(x, y, s=16, alpha=0.6, label="Noisy samples",
                color=colors["samples"], edgecolors='white', linewidths=0.5)  # 样本点加白边
    ax1.plot(x_grid, y_cl, linestyle="--", label="Cluster + pinv",
             color=colors["cluster"], linewidth=1.5)
    ax1.plot(x_grid, y_gd, linestyle="-.", label="GD-trained RBF",
             color=colors["gd"], linewidth=1.5)

    # 设置标题和标签
    ax1.set_title("Hermite-like function approximation with RBF (M=10)",
                  color=colors["text"], fontsize=12)
    ax1.set_xlabel("x", color=colors["text"])
    ax1.set_ylabel("y", color=colors["text"])

    # 图例和网格
    ax1.legend()
    ax1.grid(linestyle='--', color=colors["cluster"], alpha=0.3)  # 淡紫色网格线

    # 保存到rbf文件夹
    fig1.tight_layout()
    fig1.savefig(os.path.join("rbf", "rbf_approximation.png"), dpi=150)
    plt.close(fig1)

    # --------------------------
    # 可视化：损失曲线
    # --------------------------
    fig2, ax2 = plt.subplots(figsize=(6, 4))

    # 绘制损失曲线（红紫色系）
    ax2.plot(gd_res.rmse_hist, color=colors["rmse_line"], linewidth=1.5)
    ax2.axhline(gd_cfg.rmse_goal, linestyle="--", color=colors["rmse_goal"])

    # 设置标题和标签
    ax2.set_title("Gradient Descent Training RMSE", color=colors["text"], fontsize=12)
    ax2.set_xlabel("Iteration", color=colors["text"])
    ax2.set_ylabel("RMSE", color=colors["text"])

    # 网格线
    ax2.grid(linestyle='--', color=colors["cluster"], alpha=0.3)

    # 保存到rbf文件夹
    fig2.tight_layout()
    fig2.savefig(os.path.join("rbf", "rbf_gd_rmse.png"), dpi=150)
    plt.close(fig2)
    # 汇总
    rmse_cl = np.sqrt(np.mean((predict(x, cl_res.c, cl_res.s, cl_res.w, cl_res.b) - y)**2))
    rmse_gd = np.sqrt(np.mean((predict(x, gd_res.c, gd_res.s, gd_res.w, gd_res.b) - y)**2))
    print("=== Cluster + pinv ===")
    print(f"RMSE(train) = {rmse_cl:.4f}")
    print(f"Centers (sorted) = {np.round(cl_res.c, 3)}")
    print(f"Widths  = {np.round(cl_res.s, 3)}")
    print(f"Bias b  = {cl_res.b:.4f}")
    print("=== GD-trained RBF ===")
    print(f"RMSE(train) = {rmse_gd:.4f}")
    print(f"iters = {len(gd_res.rmse_hist)}")
    print(f"Centers (sorted) = {np.round(np.sort(gd_res.c), 3)}")
    print(f"Widths  = {np.round(gd_res.s, 3)}")
    print(f"Bias b  = {gd_res.b:.4f}")
    print("Saved figures: rbf_approximation.png, rbf_gd_rmse.png")


OUTPUT_DIR = "rbf"  # 输出文件夹名称
os.makedirs(OUTPUT_DIR, exist_ok=True)  # 自动创建文件夹

# 定义红紫色系配色（可自定义调整）
RED_PURPLE_CMAP = LinearSegmentedColormap.from_list(
    "red_purple",
    [(0.9, 0.1, 0.5),   # 亮粉红
     (0.7, 0.1, 0.7),   # 紫红色
     (0.5, 0.1, 0.9),   # 深紫色
     (0.3, 0.0, 0.7)]   # 暗紫色
)
COLORS = {
    "line": "#8B008B",       # 深紫色线条
    "scatter": "#FF69B4",    # 粉红色散点
    "title": "#4B0082",      # 靛蓝色标题
    "label": "#800080",      # 深紫色标签
    "grid": "#DDA0DD"        # 淡紫色网格
}

# --------------------------
# 生成示例数据和RBF函数
# --------------------------
def rbf_kernel(x, c, sigma=1.0):
    """径向基函数（高斯核）"""
    return np.exp(-np.linalg.norm(x - c, axis=-1) **2 / (2 * sigma**2))

# 生成输入数据
x = np.linspace(-5, 5, 200)
y = np.linspace(-5, 5, 200)
X, Y = np.meshgrid(x, y)
grid_points = np.stack([X.ravel(), Y.ravel()], axis=1)  # 2D网格点

# 定义3个RBF中心
centers = np.array([[-2, -2], [0, 0], [3, 2]])
sigma = 1.5  # 核宽度

# 计算RBF值（每个中心的响应）
rbf_values = np.array([rbf_kernel(grid_points, c, sigma) for c in centers])
rbf_sum = np.sum(rbf_values, axis=0)  # 多个RBF叠加结果

# --------------------------
# 可视化1：单个RBF核响应（热力图）
# --------------------------
plt.figure(figsize=(10, 8))
for i in range(3):
    plt.subplot(2, 2, i+1)
    z = rbf_values[i].reshape(X.shape)
    # 红紫色系热力图
    plt.imshow(z, extent=[-5, 5, -5, 5], origin='lower', cmap=RED_PURPLE_CMAP, alpha=0.8)
    plt.scatter(centers[i, 0], centers[i, 1], color='white', s=100, marker='*')  # 标记中心
    plt.title(f"RBF Kernel {i+1} (Center: {centers[i]})", color=COLORS["title"])
    plt.xlabel("X", color=COLORS["label"])
    plt.ylabel("Y", color=COLORS["label"])
    plt.grid(color=COLORS["grid"], linestyle='--', alpha=0.5)

plt.tight_layout()
save_path = os.path.join(OUTPUT_DIR, "rbf_kernels.png")
plt.savefig(save_path, dpi=300, bbox_inches='tight')
plt.close()

# --------------------------
# 可视化2：RBF叠加结果（等高线+散点）
# --------------------------
plt.figure(figsize=(8, 6))
# 红紫色系等高线
plt.contourf(X, Y, rbf_sum.reshape(X.shape), levels=20, cmap=RED_PURPLE_CMAP, alpha=0.7)
# 叠加等高线线条
plt.contour(X, Y, rbf_sum.reshape(X.shape), levels=10, colors=COLORS["line"], linewidths=1)
# 标记RBF中心
plt.scatter(centers[:, 0], centers[:, 1], color=COLORS["scatter"], s=150, edgecolors='white', marker='o')
plt.title("Sum of RBF Kernels", color=COLORS["title"], fontsize=14)
plt.xlabel("X Axis", color=COLORS["label"])
plt.ylabel("Y Axis", color=COLORS["label"])
plt.grid(color=COLORS["grid"], linestyle='--', alpha=0.3)
plt.colorbar(label="RBF Value")

plt.tight_layout()
save_path = os.path.join(OUTPUT_DIR, "rbf_sum.png")
plt.savefig(save_path, dpi=300, bbox_inches='tight')
plt.close()

# --------------------------
# 可视化3：1D RBF曲线
# --------------------------
x_1d = np.linspace(-5, 5, 200)
centers_1d = np.array([-3, 0, 2])  # 1D中心
rbf_1d = np.array([rbf_kernel(x_1d[:, None], c, sigma=1.0) for c in centers_1d])
rbf_1d_sum = np.sum(rbf_1d, axis=0)

plt.figure(figsize=(8, 5))
# 绘制单个RBF曲线
for i in range(3):
    plt.plot(x_1d, rbf_1d[i], color=COLORS["line"], alpha=0.5, linestyle='--')
# 绘制叠加曲线（红紫色）
plt.plot(x_1d, rbf_1d_sum, color=COLORS["scatter"], linewidth=2, label="Sum of RBFs")
# 标记中心
plt.scatter(centers_1d, np.zeros_like(centers_1d), color=COLORS["line"], s=100, zorder=5)
plt.title("1D RBF Functions", color=COLORS["title"])
plt.xlabel("X", color=COLORS["label"])
plt.ylabel("RBF Value", color=COLORS["label"])
plt.grid(color=COLORS["grid"], linestyle='--', alpha=0.5)
plt.legend()

plt.tight_layout()
save_path = os.path.join(OUTPUT_DIR, "rbf_1d.png")
plt.savefig(save_path, dpi=300, bbox_inches='tight')
plt.close()

print(f"保存至文件夹：{os.path.abspath(OUTPUT_DIR)}")
if __name__ == "__main__":
    main()