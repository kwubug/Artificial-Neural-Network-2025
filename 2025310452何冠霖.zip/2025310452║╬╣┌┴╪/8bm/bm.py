import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.patches as patches
import time
plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]

class BoltzmannMachine:
    def __init__(self, num_neurons=3, temperature=1.0):
        """初始化玻尔兹曼机"""
        self.num_neurons = num_neurons
        # 神经元状态 (0或1)
        self.states = np.random.randint(0, 2, size=num_neurons)
        # 权重矩阵 (对称矩阵，对角线为0)
        self.weights = np.random.uniform(-1, 1, size=(num_neurons, num_neurons))
        self.weights = (self.weights + self.weights.T) / 2  # 确保对称性
        np.fill_diagonal(self.weights, 0)  # 自身权重为0
        # 偏置项
        self.biases = np.random.uniform(-1, 1, size=num_neurons)
        # 温度参数
        self.temperature = temperature
        # 记录能量变化
        self.energy_history = []
        # 记录状态历史
        self.state_history = [self.states.copy()]
        
    def energy(self):
        """计算当前状态的能量"""
        energy = -0.5 * np.sum(self.weights * np.outer(self.states, self.states))
        energy -= np.sum(self.biases * self.states)
        return energy
    
    def probability(self, neuron_idx):
        """计算神经元激活的概率"""
        activation = self.biases[neuron_idx] + np.sum(self.weights[neuron_idx] * self.states)
        return 1 / (1 + np.exp(-activation / self.temperature))
    
    def update(self):
        """随机选择一个神经元并更新其状态"""
        neuron_idx = np.random.randint(self.num_neurons)
        p = self.probability(neuron_idx)
        self.states[neuron_idx] = 1 if np.random.random() < p else 0
        self.energy_history.append(self.energy())
        self.state_history.append(self.states.copy())
        return self.states.copy()
    
    def is_thermal_equilibrium(self, window=50, threshold=0.01):
        """判断是否达到热平衡状态"""
        if len(self.energy_history) < window:
            return False
        
        # 检查最近window次迭代的能量变化是否小于阈值
        recent_energies = self.energy_history[-window:]
        energy_range = max(recent_energies) - min(recent_energies)
        return energy_range < threshold


class BMVisualizer:
    def __init__(self, bm):
        """初始化可视化器"""
        self.bm = bm
        self.fig, self.ax = plt.subplots(figsize=(10, 8))
        self.fig.suptitle('三神经元玻尔兹曼机模拟', fontsize=16)
        
        # 设置神经元位置
        self.positions = np.array([
            [0, 1],    # 神经元1位置
            [-1, -0.5], # 神经元2位置
            [1, -0.5]  # 神经元3位置
        ])
        
        # 创建能量变化子图
        self.ax_energy = self.fig.add_axes([0.1, 0.05, 0.8, 0.2])
        self.ax_energy.set_title('能量变化')
        self.ax_energy.set_xlabel('迭代次数')
        self.ax_energy.set_ylabel('能量')
        
        # 神经元图形对象
        self.neurons = []
        self.neuron_labels = []
        
        # 连接线条对象
        self.connections = []
        self.weight_labels = []
        
        self.setup_visualization()
        
    def setup_visualization(self):
        """设置初始可视化元素"""
        self.ax.set_xlim(-1.5, 1.5)
        self.ax.set_ylim(-1, 1.5)
        self.ax.axis('off')
        
        # 绘制神经元
        for i, (x, y) in enumerate(self.positions):
            neuron = patches.Circle((x, y), 0.3, edgecolor='black', linewidth=2)
            self.neurons.append(self.ax.add_patch(neuron))
            label = self.ax.text(x, y, f'N{i+1}', ha='center', va='center', fontsize=12)
            self.neuron_labels.append(label)
        
        # 绘制连接和权重
        for i in range(self.bm.num_neurons):
            for j in range(i+1, self.bm.num_neurons):
                x1, y1 = self.positions[i]
                x2, y2 = self.positions[j]
                line, = self.ax.plot([x1, x2], [y1, y2], 'gray', linewidth=1)
                self.connections.append(line)
                
                # 权重标签位置
                mid_x = (x1 + x2) / 2
                mid_y = (y1 + y2) / 2
                weight_label = self.ax.text(mid_x, mid_y, f'{self.bm.weights[i,j]:.2f}', 
                                           ha='center', va='center', fontsize=10)
                self.weight_labels.append(weight_label)
        
        # 状态文本
        self.state_text = self.ax.text(0, 1.3, '', ha='center', va='center', fontsize=12)
        self.energy_text = self.ax.text(0, -1.2, '', ha='center', va='center', fontsize=12)
        self.equilibrium_text = self.ax.text(0, 1.45, '', ha='center', va='center', fontsize=12, color='red')
    
    def update_visualization(self, states):
        """更新可视化内容"""
        # 更新神经元状态（颜色表示激活状态）
        for i, state in enumerate(states):
            color = 'lightgreen' if state == 1 else 'lightcoral'
            self.neurons[i].set_facecolor(color)
        
        # 更新状态文本
        self.state_text.set_text(f'神经元状态: {states}')
        
        # 更新能量文本
        current_energy = self.bm.energy()
        self.energy_text.set_text(f'当前能量: {current_energy:.2f}')
        
        # 更新能量变化曲线
        self.ax_energy.clear()
        self.ax_energy.set_title('能量变化')
        self.ax_energy.set_xlabel('迭代次数')
        self.ax_energy.set_ylabel('能量')
        if len(self.bm.energy_history) > 0:
            self.ax_energy.plot(self.bm.energy_history)
        
        # 检查是否达到热平衡
        if self.bm.is_thermal_equilibrium():
            self.equilibrium_text.set_text('已达到热平衡状态')
        
        return self.neurons + [self.state_text, self.energy_text, self.equilibrium_text]


def simulate_bm():
    """模拟玻尔兹曼机运行过程"""
    # 创建玻尔兹曼机
    bm = BoltzmannMachine(num_neurons=3, temperature=0.8)
    
    # 创建可视化器
    visualizer = BMVisualizer(bm)
    
    # 模拟迭代次数
    max_iterations = 500
    
    # 动画更新函数
    def update(frame):
        if frame < max_iterations and not bm.is_thermal_equilibrium():
            states = bm.update()
            return visualizer.update_visualization(states)
        return visualizer.neurons + [visualizer.state_text, visualizer.energy_text, visualizer.equilibrium_text]
    
    # 创建动画
    animation = FuncAnimation(
        visualizer.fig, 
        update, 
        frames=max_iterations,
        interval=100,
        blit=True
    )
    
    plt.tight_layout()
    plt.show()
    
    # 输出最终结果
    print("模拟结束")
    print(f"最终神经元状态: {bm.states}")
    print(f"最终能量: {bm.energy():.4f}")
    print(f"是否达到热平衡: {'是' if bm.is_thermal_equilibrium() else '否'}")
    
    # 分析热平衡状态
    if bm.is_thermal_equilibrium():
        # 统计最近状态出现频率
        recent_states = bm.state_history[-100:]
        state_counts = {}
        for state in recent_states:
            state_tuple = tuple(state)
            state_counts[state_tuple] = state_counts.get(state_tuple, 0) + 1
        
        print("\n热平衡状态分布:")
        for state, count in state_counts.items():
            print(f"状态 {state}: 出现频率 {count/len(recent_states):.2f}")


if __name__ == "__main__":
    simulate_bm()