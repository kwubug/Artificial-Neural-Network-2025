# nn_sandbox/bridges/BoltzmannVisualizer.py
import numpy as np
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import random

class BoltzmannVisualizer(QWidget):
    """
    简单Boltzmann Machine 可视化
    - 支持3个神经元
    - 显示状态随迭代变化
    - 显示最后热平衡状态
    """

    def __init__(self, parent=None, n_neurons=3, temperature=1.0):
        super().__init__(parent)
        self.n = n_neurons
        self.T = temperature
        self.fig, self.ax = plt.subplots(1, 1, figsize=(5,4))
        self.canvas = FigureCanvas(self.fig)
        layout = QVBoxLayout(self)
        layout.addWidget(self.canvas)

    def initialize_weights(self, seed=None):
        """随机生成对称权重矩阵"""
        if seed is not None:
            np.random.seed(seed)
        W = np.random.randn(self.n, self.n)
        W = (W + W.T)/2  # 保证对称
        np.fill_diagonal(W, 0)
        self.W = W
        return W

    def initialize_state(self):
        """随机初始化 ±1 状态"""
        self.state = np.random.choice([-1,1], size=self.n)
        return self.state

    def energy(self, state):
        return -0.5 * state @ self.W @ state

    def sigmoid(self, x):
        return 1.0 / (1 + np.exp(-2*x/self.T))  # BM 离散二值更新

    def run_gibbs(self, n_steps=100):
        """Gibbs 采样迭代"""
        state = self.state.copy()
        energy_list = [self.energy(state)]
        state_history = [state.copy()]
        for _ in range(n_steps):
            i = random.randrange(self.n)
            net_input = np.dot(self.W[i], state)
            prob = self.sigmoid(net_input)
            state[i] = 1 if random.random() < prob else -1
            energy_list.append(self.energy(state))
            state_history.append(state.copy())
        self.state = state
        self.energy_list = energy_list
        self.state_history = state_history
        return state, energy_list

    def visualize(self):
        """可视化状态随迭代变化以及最后平衡状态"""
        self.ax.clear()
        history = np.array(self.state_history)
        # 画热力图，行：迭代步数，列：神经元
        self.ax.imshow(history, cmap='gray', vmin=-1, vmax=1, aspect='auto')
        self.ax.set_xlabel("Neuron index")
        self.ax.set_ylabel("Iteration step")
        self.ax.set_title("Boltzmann Machine State Evolution")
        self.canvas.draw()

    def refresh(self, n_steps=100):
        """初始化网络并运行"""
        self.initialize_weights()
        self.initialize_state()
        self.run_gibbs(n_steps=n_steps)
        self.visualize()
        # 最后热平衡状态
        return self.state
