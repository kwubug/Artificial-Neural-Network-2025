# -*- coding: utf-8 -*-
"""
Bridge between the Hopfield network backend and the QML frontend.

This class manages the Hopfield network instance, handles state conversions, and exposes
network operations and data to the QML interface through Qt's property and slot system.
"""
import numpy as np
from PyQt5.QtCore import QObject, pyqtProperty, pyqtSignal, pyqtSlot, QVariant

from nn_sandbox.backend.algorithms.hopfield import HopfieldNetwork

class HopfieldBridge(QObject):
    """
    Manages the Hopfield network and exposes its functionality to the QML frontend.

    Properties:
        - currentState: The current state of the network (1D list).
        - energyHistory: A history of the network's energy levels (list).
        - attractors: A list of discovered stable patterns (attractors).

    Slots:
        - getPatterns: Returns the predefined patterns.
        - resetToPattern: Resets the network to a selected pattern with optional noise.
        - step: Performs a single asynchronous update step.
        - runToStability: Runs the network until it converges.
    """

    # Signals to notify QML of property changes
    currentStateChanged = pyqtSignal()
    energyHistoryChanged = pyqtSignal()
    attractorsChanged = pyqtSignal()

    def __init__(self, parent=None):
        """Initializes the bridge and the underlying Hopfield network."""
        super().__init__(parent)
        self._rows, self._cols = 5, 5
        self._num_neurons = self._rows * self._cols
        self._network = HopfieldNetwork(self._num_neurons)

        # Predefined patterns (T, L, C)
        self._patterns = {
            'T': [1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1],
            'L': [1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, 1],
            'C': [1, 1, 1, 1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, 1, -1]
        }
        self._pattern_list = [np.array(p) for p in self._patterns.values()]
        self._network.train(self._pattern_list)

        self._state = np.copy(self._pattern_list[0])
        self._energy_history = [self._network.calculate_energy(self._state)]
        self._attractors = []

    def _to_1d(self, pattern_2d):
        """Converts a 2D pattern to 1D."""
        return np.array(pattern_2d).flatten()

    def _to_2d(self, pattern_1d):
        """Converts a 1D pattern to 2D."""
        return np.array(pattern_1d).reshape((self._rows, self._cols)).tolist()

    def _add_noise(self, pattern, noise_level):
        """Adds noise to a pattern by flipping a percentage of its bits."""
        noisy_pattern = np.copy(pattern)
        num_flips = int(noise_level * self._num_neurons)
        flip_indices = np.random.choice(self._num_neurons, num_flips, replace=False)
        noisy_pattern[flip_indices] *= -1
        return noisy_pattern

    def _log_attractor(self, state):
        """Logs a new attractor if it's unique."""
        state_tuple = tuple(state)
        if state_tuple not in [tuple(a) for a in self._attractors]:
            self._attractors.append(state)
            self.attractorsChanged.emit()

    # --- QML-accessible properties ---

    @pyqtProperty(QVariant, notify=currentStateChanged)
    def currentState(self):
        return self._state.tolist()

    @pyqtProperty(QVariant, notify=energyHistoryChanged)
    def energyHistory(self):
        return self._energy_history

    @pyqtProperty(QVariant, notify=attractorsChanged)
    def attractors(self):
        return [p.tolist() for p in self._attractors]

    # --- QML-callable slots ---

    @pyqtSlot(result=QVariant)
    def get_patterns(self):
        """Returns the dictionary of named patterns for the frontend."""
        return {name: self._to_2d(p) for name, p in self._patterns.items()}

    @pyqtSlot(str, float, result=QVariant)
    def reset_to_pattern(self, name, noise_level):
        """Resets the network to a pattern, adds noise, and returns the initial state."""
        base_pattern = np.array(self._patterns[name])
        initial_state = self._add_noise(base_pattern, noise_level)
        self._network.set_initial_state(initial_state)
        self._state = initial_state
        self._energy_history = [self._network.calculate_energy(self._state)]
        
        self.currentStateChanged.emit()
        self.energyHistoryChanged.emit()
        
        return {
            'initial_state': self._to_2d(self._state),
            'energy': self._energy_history[0]
        }

    @pyqtSlot(result=QVariant)
    def step(self):
        """Performs one async step and returns the result."""
        updated_idx = self._network.update_asynchronous()
        self._state = self._network.get_current_state()
        new_energy = self._network.calculate_energy(self._state)
        self._energy_history.append(new_energy)

        # Check for convergence
        if len(self._energy_history) > 1 and self._energy_history[-1] == self._energy_history[-2]:
            self._log_attractor(self._state)

        self.currentStateChanged.emit()
        self.energyHistoryChanged.emit()

        return {
            'updated_idx': updated_idx,
            'new_state': self._to_2d(self._state),
            'energy': new_energy,
            'is_stable': self._network.calculate_energy(self._state) == self._energy_history[-2] if len(self._energy_history) > 1 else False
        }

    @pyqtSlot(result=QVariant)
    def run_to_stability(self):
        """Runs the network until it converges and returns the final state."""
        history = self._network.run_to_convergence()
        self._state = self._network.get_current_state()
        self._energy_history.extend([self._network.calculate_energy(s) for s in history[1:]])
        self._log_attractor(self._state)

        self.currentStateChanged.emit()
        self.energyHistoryChanged.emit()

        return {
            'final_state': self._to_2d(self._state),
            'energy': self._energy_history[-1],
            'steps': len(history) - 1
        }