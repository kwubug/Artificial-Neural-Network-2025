import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

import '..'

Page {
    name: 'Hopfield'

    Flickable {
        anchors.fill: parent
        contentHeight: mainLayout.implicitHeight
        clip: true

        ColumnLayout {
            id: mainLayout
            width: parent.width
            spacing: 10
        
        // ==================== 模式管理区 ====================
        GroupBox {
            title: 'Pattern Management'
            Layout.fillWidth: true
            Layout.preferredHeight: 120

            ColumnLayout {
                spacing: 8
                Layout.fillWidth: true

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    rowSpacing: 6
                    columnSpacing: 8

                    // 已存储模式数
                    Label {
                        text: 'Stored Patterns'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.pattern_count
                        font.pixelSize: 14
                        Layout.fillWidth: true
                    }

                    // 网络容量
                    Label {
                        text: 'Network Capacity'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.calculate_pattern_capacity()
                        font.pixelSize: 14
                        Layout.fillWidth: true
                    }

                    // 神经元数
                    Label {
                        text: 'Neurons'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.num_neurons
                        Layout.fillWidth: true
                    }

                    // 网络信息
                    Label {
                        text: 'Network Info'
                        font.bold: true
                    }
                    Label {
                        text: hopfieldBridge.get_network_info()
                        wrapMode: Text.Wrap
                        font.pixelSize: 10
                        color: '#666666'
                        Layout.fillWidth: true
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    Button {
                        text: 'Store Random Pattern'
                        Layout.fillWidth: true
                        enabled: !hopfieldBridge.retrieval_in_progress
                        onClicked: {
                            var pattern = hopfieldBridge.generate_random_pattern()
                            hopfieldBridge.store_pattern(pattern)
                        }
                    }

                    Button {
                        text: 'Clear All'
                        Layout.fillWidth: true
                        enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                        onClicked: hopfieldBridge.clear_patterns()
                    }
                }
            }
        }
        
        // ==================== 检索配置区 ====================
        GroupBox {
            title: 'Retrieval Configuration'
            Layout.fillWidth: true
            Layout.preferredHeight: 160

            ColumnLayout {
                spacing: 8
                Layout.fillWidth: true

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 8

                    // 选择模式
                    Label {
                        text: 'Select Pattern'
                    }
                    ComboBox {
                        id: patternSelector
                        model: hopfieldBridge.pattern_count
                        Layout.fillWidth: true
                        enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                    }

                    // 噪声等级
                    Label {
                        text: 'Noise Level'
                    }
                    RowLayout {
                        Layout.fillWidth: true
                        Slider {
                            id: noiseSlider
                            from: 0
                            to: 1
                            value: 0.1
                            Layout.fillWidth: true
                            enabled: !hopfieldBridge.retrieval_in_progress
                        }
                        Label {
                            text: (noiseSlider.value * 100).toFixed(0) + '%'
                            width: 50
                        }
                    }

                    // 更新规则
                    Label {
                        text: 'Update Rule'
                    }
                    ComboBox {
                        id: updateRuleSelector
                        model: ['Async', 'Sync']
                        Layout.fillWidth: true
                        enabled: !hopfieldBridge.retrieval_in_progress
                    }

                    // 最大迭代次数
                    Label {
                        text: 'Max Iterations'
                    }
                    SpinBox {
                        id: maxIterInput
                        value: 1000
                        to: 100000
                        Layout.fillWidth: true
                        enabled: !hopfieldBridge.retrieval_in_progress
                        editable: true
                    }
                }
            }
        }
        
        // ==================== 控制按钮 ====================
        RowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 50
            spacing: 10

            Button {
                text: 'Create Noisy Pattern'
                Layout.fillWidth: true
                enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                onClicked: {
                    var patternIdx = patternSelector.currentIndex
                    var noiseRate = noiseSlider.value
                    hopfieldBridge.create_noisy_pattern(patternIdx, noiseRate)
                }
            }

            Button {
                text: 'Single Step'
                Layout.fillWidth: true
                enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                onClicked: {
                    var rule = updateRuleSelector.currentText.toLowerCase()
                    hopfieldBridge.step(rule)
                }
            }

            Button {
                text: 'Retrieve'
                Layout.fillWidth: true
                highlighted: true
                enabled: hopfieldBridge.pattern_count > 0 && !hopfieldBridge.retrieval_in_progress
                onClicked: {
                    var rule = updateRuleSelector.currentText.toLowerCase()
                    var maxIter = maxIterInput.value
                    hopfieldBridge.retrieve(maxIter, rule)
                }
            }
        }
        
        // ==================== 实时状态显示 ====================
        GroupBox {
            title: 'Network State'
            Layout.fillWidth: true
            Layout.preferredHeight: 140

            GridLayout {
                anchors.fill: parent
                anchors.margins: 4
                columns: 3
                rowSpacing: 8
                columnSpacing: 8

                // Energy
                Label {
                    text: 'Energy'
                    font.bold: true
                }
                Label {
                    text: hopfieldBridge.energy.toFixed(2)
                    font.pixelSize: 14
                    color: hopfieldBridge.energy < -1000 ? '#00AA00' : '#FF9900'
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 20
                    height: 20
                    radius: 10
                    color: hopfieldBridge.energy < -1000 ? '#00AA00' : '#FF9900'
                }

                // Iteration
                Label {
                    text: 'Iteration'
                    font.bold: true
                }
                Label {
                    text: hopfieldBridge.iteration
                    font.pixelSize: 14
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 20
                    height: 20
                    color: 'transparent'
                }

                // Converged
                Label {
                    text: 'Converged'
                    font.bold: true
                }
                Label {
                    text: hopfieldBridge.converged ? 'Yes ✓' : 'No'
                    font.pixelSize: 14
                    color: hopfieldBridge.converged ? '#00AA00' : '#FF0000'
                    font.bold: true
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 20
                    height: 20
                    radius: 10
                    color: hopfieldBridge.converged ? '#00AA00' : '#FF0000'
                }

                // Similarity
                Label {
                    text: 'Similarity'
                    font.bold: true
                }
                Label {
                    text: (hopfieldBridge.similarity * 100).toFixed(1) + '%'
                    font.pixelSize: 14
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 20
                    height: 20
                    color: 'transparent'
                }

                // Status
                Label {
                    text: 'Status'
                    font.bold: true
                }
                Label {
                    text: hopfieldBridge.retrieval_in_progress ? '⏳ Retrieving...' : '✓ Ready'
                    color: hopfieldBridge.retrieval_in_progress ? '#FF6600' : '#00AA00'
                    font.bold: true
                    Layout.fillWidth: true
                }
                Rectangle {
                    width: 20
                    height: 20
                    radius: 10
                    color: hopfieldBridge.retrieval_in_progress ? '#FF6600' : '#00AA00'
                }
            }
        }
        
        // ==================== 状态可视化 ====================
        GroupBox {
            title: 'State Visualization'
            Layout.fillWidth: true
            Layout.preferredHeight: 320

            Canvas {
                id: stateCanvas
                anchors.fill: parent
                anchors.margins: 4

                // 当状态改变时重绘
                Connections {
                    target: hopfieldBridge
                    function onCurrent_stateChanged() {
                        stateCanvas.requestPaint()
                    }
                }

                onPaint: {
                    var ctx = getContext('2d')
                    ctx.fillStyle = '#FFFFFF'
                    ctx.fillRect(0, 0, width, height)

                    var state = hopfieldBridge.current_state
                    if (state.length === 0) return

                    var neuronSize = Math.min(width, height) / Math.ceil(Math.sqrt(state.length))
                    var cols = Math.ceil(width / neuronSize)

                    // 绘制神经元
                    for (var i = 0; i < state.length; i++) {
                        var row = Math.floor(i / cols)
                        var col = i % cols
                        var x = col * neuronSize
                        var y = row * neuronSize

                        // ±1 对应不同颜色
                        ctx.fillStyle = state[i] > 0 ? '#0066FF' : '#FF6600'
                        ctx.fillRect(x + 2, y + 2, neuronSize - 4, neuronSize - 4)

                        // 边框
                        ctx.strokeStyle = '#999999'
                        ctx.lineWidth = 1
                        ctx.strokeRect(x, y, neuronSize, neuronSize)
                    }
                }
            }
        }

        // 占位符确保有足够空间滚动
        Item {
            Layout.fillHeight: true
        }
        }
    }
}

