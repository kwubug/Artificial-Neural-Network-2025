import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import random
import threading
import time

class BoltzmannMachine:
    def __init__(self, n_neurons=3):
        self.n_neurons = n_neurons
        # 初始化权重矩阵（对称且对角线为0）
        self.weights = np.random.normal(0, 0.1, (n_neurons, n_neurons))
        self.weights = (self.weights + self.weights.T) / 2
        np.fill_diagonal(self.weights, 0)
        # 初始化偏置
        self.biases = np.random.normal(0, 0.1, n_neurons)
        # 当前状态
        self.state = np.random.choice([1, -1], n_neurons)
        # 温度参数
        self.temperature = 1.0
        # 存储历史状态用于分析
        self.state_history = []
        self.energy_history = []
        
    def energy(self, state=None):
        """计算给定状态的能量"""
        if state is None:
            state = self.state
        # E = -1/2 * ΣΣ w_ij * s_i * s_j - Σ b_i * s_i
        interaction_energy = -0.5 * np.sum(self.weights * np.outer(state, state))
        bias_energy = -np.sum(self.biases * state)
        return interaction_energy + bias_energy
    
    def probability(self, neuron_idx, state=None):
        """计算神经元激活的概率"""
        if state is None:
            state = self.state
        # 计算局部场
        local_field = np.sum(self.weights[neuron_idx, :] * state) + self.biases[neuron_idx]
        # 使用sigmoid函数计算激活概率
        return 1 / (1 + np.exp(-2 * local_field / self.temperature))
    
    def update_neuron(self, neuron_idx):
        """更新单个神经元的状态"""
        prob = self.probability(neuron_idx)
        self.state[neuron_idx] = 1 if random.random() < prob else -1
    
    def asynchronous_update(self, n_steps=1):
        """异步更新神经元状态"""
        for _ in range(n_steps):
            # 随机选择一个神经元进行更新
            neuron_idx = random.randint(0, self.n_neurons - 1)
            self.update_neuron(neuron_idx)
            # 记录状态和能量
            self.state_history.append(self.state.copy())
            self.energy_history.append(self.energy())
    
    def get_all_states(self):
        """获取所有可能的状态"""
        states = []
        for i in range(2**self.n_neurons):
            state = []
            for j in range(self.n_neurons):
                state.append(1 if (i >> j) & 1 else -1)
            states.append(np.array(state))
        return states
    
    def find_attractors(self):
        """找到所有吸引子状态（局部能量最小值）"""
        states = self.get_all_states()
        energies = [self.energy(state) for state in states]
        attractors = []
        
        for i, state in enumerate(states):
            is_attractor = True
            current_energy = energies[i]
            
            # 检查每个神经元翻转后能量是否都增加
            for j in range(self.n_neurons):
                flipped_state = state.copy()
                flipped_state[j] = -flipped_state[j]
                flipped_energy = self.energy(flipped_state)
                
                if flipped_energy < current_energy:
                    is_attractor = False
                    break
            
            if is_attractor:
                attractors.append((state, current_energy))
        
        return attractors
    
    def thermal_equilibrium_analysis(self, n_samples=10000):
        """分析热平衡状态分布"""
        state_counts = {}
        states = self.get_all_states()
        
        # 初始化计数器
        for state in states:
            state_key = tuple(state)
            state_counts[state_key] = 0
        
        # 运行多次采样
        for _ in range(n_samples):
            # 随机初始化状态
            self.state = np.random.choice([1, -1], self.n_neurons)
            
            # 运行足够长时间达到平衡
            self.asynchronous_update(100)
            
            # 记录最终状态
            final_state = tuple(self.state)
            state_counts[final_state] += 1
        
        # 计算概率分布
        total_samples = sum(state_counts.values())
        state_probabilities = {state: count/total_samples 
                             for state, count in state_counts.items()}
        
        return state_probabilities

class BoltzmannMachineVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("三神经元玻尔兹曼机可视化")
        self.root.geometry("1200x800")
        
        # 创建玻尔兹曼机实例
        self.bm = BoltzmannMachine(3)
        
        # 控制运行的标志
        self.running = False
        self.run_thread = None
        
        self.setup_ui()
        self.update_visualization()
        
    def setup_ui(self):
        # 主框架
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 控制面板
        control_frame = tk.LabelFrame(main_frame, text="控制面板", padx=10, pady=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 参数设置
        params_frame = tk.Frame(control_frame)
        params_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # 温度设置
        tk.Label(params_frame, text="温度:").grid(row=0, column=0, sticky=tk.W)
        self.temp_var = tk.DoubleVar(value=self.bm.temperature)
        temp_scale = tk.Scale(params_frame, from_=0.1, to=5.0, resolution=0.1, 
                             orient=tk.HORIZONTAL, variable=self.temp_var,
                             command=self.update_temperature)
        temp_scale.grid(row=0, column=1, sticky=tk.EW)
        params_frame.columnconfigure(1, weight=1)
        
        # 权重设置
        weight_frame = tk.Frame(control_frame)
        weight_frame.pack(side=tk.LEFT, padx=(20, 0))
        
        tk.Label(weight_frame, text="权重:").pack(anchor=tk.W)
        self.weight_vars = []
        for i in range(3):
            for j in range(i+1, 3):
                frame = tk.Frame(weight_frame)
                frame.pack(fill=tk.X)
                tk.Label(frame, text=f"W{i+1}{j+1}:").pack(side=tk.LEFT)
                var = tk.DoubleVar(value=self.bm.weights[i, j])
                self.weight_vars.append(var)
                scale = tk.Scale(frame, from_=-2.0, to=2.0, resolution=0.1,
                                orient=tk.HORIZONTAL, variable=var,
                                command=lambda v, i=i, j=j: self.update_weight(v, i, j))
                scale.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        
        # 偏置设置
        bias_frame = tk.Frame(control_frame)
        bias_frame.pack(side=tk.LEFT, padx=(20, 0))
        
        tk.Label(bias_frame, text="偏置:").pack(anchor=tk.W)
        self.bias_vars = []
        for i in range(3):
            frame = tk.Frame(bias_frame)
            frame.pack(fill=tk.X)
            tk.Label(frame, text=f"B{i+1}:").pack(side=tk.LEFT)
            var = tk.DoubleVar(value=self.bm.biases[i])
            self.bias_vars.append(var)
            scale = tk.Scale(frame, from_=-2.0, to=2.0, resolution=0.1,
                            orient=tk.HORIZONTAL, variable=var,
                            command=lambda v, i=i: self.update_bias(v, i))
            scale.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        
        # 按钮控制
        button_frame = tk.Frame(control_frame)
        button_frame.pack(side=tk.RIGHT, padx=(20, 0))
        
        self.run_button = tk.Button(button_frame, text="开始运行", command=self.toggle_run)
        self.run_button.pack(pady=2)
        
        step_button = tk.Button(button_frame, text="单步更新", command=self.single_step)
        step_button.pack(pady=2)
        
        reset_button = tk.Button(button_frame, text="重置状态", command=self.reset_state)
        reset_button.pack(pady=2)
        
        analyze_button = tk.Button(button_frame, text="分析吸引子", command=self.analyze_attractors)
        analyze_button.pack(pady=2)
        
        equilibrium_button = tk.Button(button_frame, text="热平衡分析", command=self.analyze_equilibrium)
        equilibrium_button.pack(pady=2)
        
        # 显示面板
        display_frame = tk.Frame(main_frame)
        display_frame.pack(fill=tk.BOTH, expand=True)
        
        # 网络状态显示
        state_frame = tk.LabelFrame(display_frame, text="网络状态", padx=10, pady=10)
        state_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # 网络结构图
        self.network_fig, self.network_ax = plt.subplots(figsize=(4, 4))
        self.network_canvas = FigureCanvasTkAgg(self.network_fig, state_frame)
        self.network_canvas.get_tk_widget().pack()
        
        # 能量和状态信息
        info_frame = tk.Frame(state_frame)
        info_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.energy_label = tk.Label(info_frame, text="能量: ")
        self.energy_label.pack(anchor=tk.W)
        
        self.state_label = tk.Label(info_frame, text="状态: ")
        self.state_label.pack(anchor=tk.W)
        
        # 激活概率显示
        prob_frame = tk.LabelFrame(state_frame, text="神经元激活概率", padx=10, pady=10)
        prob_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.prob_labels = []
        for i in range(3):
            label = tk.Label(prob_frame, text=f"神经元{i+1}: ")
            label.pack(anchor=tk.W)
            self.prob_labels.append(label)
        
        # 图表显示区域
        chart_frame = tk.LabelFrame(display_frame, text="可视化图表", padx=10, pady=10)
        chart_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # 能量变化图
        self.energy_fig, self.energy_ax = plt.subplots(figsize=(5, 3))
        self.energy_canvas = FigureCanvasTkAgg(self.energy_fig, chart_frame)
        self.energy_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 状态概率分布图
        self.dist_fig, self.dist_ax = plt.subplots(figsize=(5, 3))
        self.dist_canvas = FigureCanvasTkAgg(self.dist_fig, chart_frame)
        self.dist_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 日志区域
        log_frame = tk.LabelFrame(main_frame, text="运行日志", padx=10, pady=10)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        self.log_text = tk.Text(log_frame, height=6)
        self.log_text.pack(fill=tk.BOTH, expand=True)
        scrollbar = tk.Scrollbar(log_frame, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
    
    def log_message(self, message):
        """添加日志信息"""
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
    
    def update_temperature(self, value):
        """更新温度参数"""
        self.bm.temperature = float(value)
        self.update_visualization()
    
    def update_weight(self, value, i, j):
        """更新权重"""
        self.bm.weights[i, j] = float(value)
        self.bm.weights[j, i] = float(value)  # 保持对称性
        self.update_visualization()
    
    def update_bias(self, value, i):
        """更新偏置"""
        self.bm.biases[i] = float(value)
        self.update_visualization()
    
    def update_visualization(self):
        """更新所有可视化内容"""
        # 更新网络结构图
        self.network_ax.clear()
        # 绘制神经元
        positions = {0: (0, 1), 1: (-1, -0.5), 2: (1, -0.5)}  # 三角形布局
        colors = ['red' if s == 1 else 'blue' for s in self.bm.state]
        
        for i in range(3):
            x, y = positions[i]
            self.network_ax.scatter(x, y, s=500, c=colors[i], edgecolors='black', linewidth=2)
            self.network_ax.text(x, y, f'N{i+1}\n{self.bm.state[i]}', 
                                ha='center', va='center', fontsize=12, weight='bold')
        
        # 绘制连接线和权重
        for i in range(3):
            for j in range(i+1, 3):
                x1, y1 = positions[i]
                x2, y2 = positions[j]
                self.network_ax.plot([x1, x2], [y1, y2], 'k-', linewidth=2)
                # 在连线中点显示权重
                mid_x, mid_y = (x1+x2)/2, (y1+y2)/2
                weight = self.bm.weights[i, j]
                self.network_ax.text(mid_x, mid_y, f'{weight:.1f}', 
                                    ha='center', va='center', fontsize=10,
                                    bbox=dict(boxstyle="round,pad=0.3", facecolor="white"))
        
        self.network_ax.set_xlim(-1.5, 1.5)
        self.network_ax.set_ylim(-1.5, 1.5)
        self.network_ax.set_aspect('equal')
        self.network_ax.axis('off')
        self.network_ax.set_title('网络结构')
        self.network_canvas.draw()
        
        # 更新能量和状态信息
        energy = self.bm.energy()
        self.energy_label.config(text=f"能量: {energy:.4f}")
        self.state_label.config(text=f"状态: [{', '.join(map(str, self.bm.state))}]")
        
        # 更新激活概率
        for i in range(3):
            prob = self.bm.probability(i)
            self.prob_labels[i].config(text=f"神经元{i+1}: {prob:.4f}")
        
        # 更新能量变化图
        if len(self.bm.energy_history) > 1:
            self.energy_ax.clear()
            self.energy_ax.plot(self.bm.energy_history, 'b-')
            self.energy_ax.set_xlabel('更新步数')
            self.energy_ax.set_ylabel('能量')
            self.energy_ax.set_title('能量变化')
            self.energy_ax.grid(True)
            self.energy_canvas.draw()
    
    def toggle_run(self):
        """切换运行状态"""
        if not self.running:
            self.running = True
            self.run_button.config(text="停止运行")
            self.run_thread = threading.Thread(target=self.run_continuous)
            self.run_thread.daemon = True
            self.run_thread.start()
        else:
            self.running = False
            self.run_button.config(text="开始运行")
    
    def run_continuous(self):
        """连续运行"""
        while self.running:
            self.bm.asynchronous_update(1)
            self.root.after(0, self.update_visualization)
            time.sleep(0.1)  # 控制更新速度
    
    def single_step(self):
        """单步更新"""
        self.bm.asynchronous_update(1)
        self.update_visualization()
        self.log_message(f"单步更新完成 - 状态: {self.bm.state}, 能量: {self.bm.energy():.4f}")
    
    def reset_state(self):
        """重置神经元状态"""
        self.bm.state = np.random.choice([1, -1], self.bm.n_neurons)
        self.bm.state_history = []
        self.bm.energy_history = []
        self.update_visualization()
        self.log_message("神经元状态已重置")
    
    def analyze_attractors(self):
        """分析吸引子"""
        attractors = self.bm.find_attractors()
        self.log_message("=== 吸引子分析结果 ===")
        for i, (state, energy) in enumerate(attractors):
            self.log_message(f"吸引子 {i+1}: 状态 {state}, 能量 {energy:.4f}")
        
        if not attractors:
            self.log_message("未找到吸引子")
        
        # 更新状态概率分布图
        self.dist_ax.clear()
        states = [str(a[0]) for a in attractors]
        energies = [a[1] for a in attractors]
        self.dist_ax.bar(range(len(states)), energies)
        self.dist_ax.set_xlabel('吸引子状态')
        self.dist_ax.set_ylabel('能量')
        self.dist_ax.set_title('吸引子能量')
        self.dist_ax.set_xticks(range(len(states)))
        self.dist_ax.set_xticklabels(states, rotation=45)
        self.dist_canvas.draw()
    
    def analyze_equilibrium(self):
        """分析热平衡状态"""
        self.log_message("正在进行热平衡分析...")
        # 在新线程中运行分析以避免界面冻结
        analysis_thread = threading.Thread(target=self._perform_equilibrium_analysis)
        analysis_thread.daemon = True
        analysis_thread.start()
    
    def _perform_equilibrium_analysis(self):
        """执行热平衡分析"""
        state_probs = self.bm.thermal_equilibrium_analysis(5000)
        
        # 更新UI需要在主线程中进行
        def update_ui():
            self.log_message("=== 热平衡状态分布 ===")
            for state, prob in state_probs.items():
                if prob > 0.01:  # 只显示概率大于1%的状态
                    self.log_message(f"状态 {state}: 概率 {prob:.4f}")
            
            # 更新状态概率分布图
            self.dist_ax.clear()
            states = [str(state) for state in state_probs.keys()]
            probs = [prob for prob in state_probs.values()]
            self.dist_ax.bar(range(len(states)), probs)
            self.dist_ax.set_xlabel('网络状态')
            self.dist_ax.set_ylabel('平衡概率')
            self.dist_ax.set_title('热平衡状态分布')
            self.dist_ax.set_xticks(range(len(states)))
            self.dist_ax.set_xticklabels(states, rotation=45)
            self.dist_canvas.draw()
        
        self.root.after(0, update_ui)

if __name__ == "__main__":
    root = tk.Tk()
    app = BoltzmannMachineVisualizer(root)
    root.mainloop()