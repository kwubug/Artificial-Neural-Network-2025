import time

import PyQt5.QtCore

from . import Bridge, BridgeProperty
from .observer import Observable


class BMBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.0)
    dataset_dict = BridgeProperty({})
    training_dataset = BridgeProperty([])
    testing_dataset = BridgeProperty([])
    current_dataset_name = BridgeProperty('')
    total_epoches = BridgeProperty(100)
    learning_rate = BridgeProperty(0.1)
    temperature = BridgeProperty(1.0)
    momentum = BridgeProperty(0.9)
    batch_size = BridgeProperty(10)
    num_units = BridgeProperty(20)
    visible_units = BridgeProperty(10)
    current_iterations = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    current_reconstruction_error = BridgeProperty(1.0)
    best_reconstruction_error = BridgeProperty(1.0)
    has_finished = BridgeProperty(True)

    def __init__(self):
        super().__init__()
        self.bm_algorithm = None

    @PyQt5.QtCore.pyqtSlot()
    def start_bm_algorithm(self):
        self.bm_algorithm = ObservableBMAlgorithm(
            self,
            self.ui_refresh_interval,
            dataset=self.dataset_dict.get(self.current_dataset_name, []),
            total_epoches=self.total_epoches,
            learning_rate=self.learning_rate,
            temperature=self.temperature,
            momentum=self.momentum,
            batch_size=self.batch_size,
            num_units=self.num_units,
            visible_units=self.visible_units
        )
        self.bm_algorithm.start()

    @PyQt5.QtCore.pyqtSlot()
    def stop_bm_algorithm(self):
        if self.bm_algorithm:
            self.bm_algorithm.stop()


class ObservableBMAlgorithm(Observable):
    def __init__(self, observer, ui_refresh_interval, **kwargs):
        Observable.__init__(self, observer)
        # 使用super().__setattr__设置初始值，避免递归调用
        super().__setattr__('ui_refresh_interval', ui_refresh_interval)
        super().__setattr__('dataset', kwargs.get('dataset', []))
        super().__setattr__('total_epoches', kwargs.get('total_epoches', 100))
        super().__setattr__('learning_rate', kwargs.get('learning_rate', 0.1))
        super().__setattr__('temperature', kwargs.get('temperature', 1.0))
        super().__setattr__('momentum', kwargs.get('momentum', 0.9))
        super().__setattr__('batch_size', kwargs.get('batch_size', 10))
        super().__setattr__('num_units', kwargs.get('num_units', 20))
        super().__setattr__('visible_units', kwargs.get('visible_units', 10))
        super().__setattr__('current_iterations', 0)
        super().__setattr__('current_energy', 0.0)
        super().__setattr__('current_reconstruction_error', 1.0)
        super().__setattr__('best_reconstruction_error', 1.0)
        super().__setattr__('_stop', False)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        # 通知观察者特定属性的变化
        if name in ('current_iterations', 'current_energy', 'current_reconstruction_error', 'best_reconstruction_error'):
            self.notify(name, value)

    def start(self):
        import threading
        self._thread = threading.Thread(target=self.run)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop = True

    def run(self):
        from ..backend.algorithms.bm_algorithm import BMAlgorithm
        import numpy as np
        
        self.notify('has_finished', False)
        
        # 初始化BM算法
        if self.dataset:
            # 转换数据集格式
            training_data = np.array(self.dataset)
            
            bm = BMAlgorithm(
                num_units=self.num_units,
                visible_units=self.visible_units,
                learning_rate=self.learning_rate,
                temperature=self.temperature,
                momentum=self.momentum,
                batch_size=self.batch_size
            )
            
            # 创建自定义的train方法，实时更新UI
            bm.energy_history = []
            bm.reconstruction_error_history = []
            
            # 准备数据可视化
            # 发送原始数据点
            if len(training_data) > 0:
                # 只发送前50个点用于可视化
                data_points = []
                for point in training_data[:50]:
                    data_points.append({"x": point[0], "y": point[1] if len(point) > 1 else 0})
                self.notify('training_dataset', data_points)
            
            # 分批训练并实时更新
            for epoch in range(self.total_epoches):
                if self._stop:
                    break
                    
                # 打乱数据
                np.random.shuffle(training_data)
                
                # 分批处理
                for i in range(0, len(training_data), self.batch_size):
                    batch = training_data[i:i+self.batch_size]
                    
                    # 执行一步训练（使用对比散度）
                    error = bm.contrastive_divergence(batch)
                    
                    # 计算当前能量
                    energy = 0
                    for sample in batch:
                        hidden_state, _ = bm.sample_hidden(sample)
                        energy += bm.energy(sample, hidden_state)
                    energy /= len(batch)
                    
                    # 重建一批数据用于可视化
                    reconstructed_batch = []
                    for sample in batch[:5]:  # 只重建前5个样本
                        reconstructed_batch.append(bm.reconstruct(sample))
                    
                    # 记录历史
                    bm.energy_history.append(energy)
                    bm.reconstruction_error_history.append(error)
                    
                    # 更新UI，确保数据有效
                    current_iterations_value = epoch * len(training_data) // self.batch_size + i // self.batch_size
                    current_energy_value = energy if energy is not None and not np.isnan(energy) else 0
                    current_error_value = error if error is not None and not np.isnan(error) else 0
                    
                    # 使用setattr确保触发通知
                    self.current_iterations = current_iterations_value
                    self.current_energy = current_energy_value
                    self.current_reconstruction_error = current_error_value
                    
                    # 更新最佳误差
                    if current_error_value < self.best_reconstruction_error:
                        self.best_reconstruction_error = current_error_value
                        self.notify('best_reconstruction_error', self.best_reconstruction_error)
                    
                    # 已经通过属性设置触发了通知，无需额外调用
                    
                    # 生成一些重构的数据点用于可视化
                    if len(reconstructed_batch) > 0:
                        recon_points = []
                        for point in reconstructed_batch[:20]:  # 只发送前20个重构点
                            recon_points.append({"x": point[0], "y": point[1] if len(point) > 1 else 0})
                        self.notify('testing_dataset', recon_points)
                    
                    # 模拟延迟
                    time.sleep(self.ui_refresh_interval)
        
        self.notify('has_finished', True)