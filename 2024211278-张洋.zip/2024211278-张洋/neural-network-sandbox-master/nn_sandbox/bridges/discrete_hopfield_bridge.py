import PyQt5.QtCore

from nn_sandbox.backend.algorithms.discrete_hopfield_algorithm import DiscreteHopfieldAlgorithm
from . import Bridge, BridgeProperty
from .observer import Observable


class DiscreteHopfieldBridge(Bridge):
    """
    离散型 Hopfield 神经网络的桥接类
    """
    # 训练参数
    M = BridgeProperty(4)  # 图像边长
    noise_level = BridgeProperty(0.2)  # 噪声比例
    max_iter = BridgeProperty(2000)  # 最大迭代次数
    update_freq = BridgeProperty(5)  # 更新频率
    ui_refresh_interval = BridgeProperty(0.01)  # UI刷新间隔
    initial_pattern_index = BridgeProperty(0)  # 初始模式索引 (0=P1, 1=P2, 2=P3)
    
    # 运行时状态
    has_finished = BridgeProperty(True)
    current_iteration = BridgeProperty(0)
    current_energy = BridgeProperty(0.0)
    is_stable = BridgeProperty(False)
    
    # 数据
    current_state = BridgeProperty([])
    initial_pattern = BridgeProperty([])
    initial_state = BridgeProperty([])
    stored_patterns = BridgeProperty([])
    energy_history = BridgeProperty([])
    
    @PyQt5.QtCore.pyqtSlot()
    def start(self):
        self.has_finished = False
        
        self._algo = ObservableDiscreteHopfieldAlgorithm(
            self,
            M=self.M,
            noise_level=self.noise_level,
            max_iter=self.max_iter,
            update_freq=self.update_freq,
            ui_refresh_interval=self.ui_refresh_interval,
            initial_pattern_index=self.initial_pattern_index
        )
        self._algo.start()
    
    @PyQt5.QtCore.pyqtSlot()
    def stop(self):
        if hasattr(self, '_algo') and self._algo:
            self._algo.stop()


class ObservableDiscreteHopfieldAlgorithm(Observable, DiscreteHopfieldAlgorithm):
    def __init__(self, observer, **kwargs):
        Observable.__init__(self, observer)
        DiscreteHopfieldAlgorithm.__init__(self, **kwargs)
    
    def __setattr__(self, name, value):
        super().__setattr__(name, value)
        if name in ('current_state', 'initial_pattern', 'initial_state', 
                    'stored_patterns', 'energy_history') and value is not None:
            self.notify(name, value.tolist() if hasattr(value, 'tolist') else list(value))
        elif name in ('current_iteration', 'current_energy', 'is_stable', 'has_finished'):
            self.notify(name, value)

