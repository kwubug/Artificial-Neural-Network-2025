import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import os
plt.rcParams["font.family"] = ["Microsoft YaHei"]


class SOM:
    def __init__(self, input_dim, map_size, initial_radius=2, initial_learning_rate=0.5):
        """
        初始化SOM网络
        input_dim: 输入维度
        map_size: 输出层大小，元组形式 (rows, cols)
        initial_radius: 初始邻域半径
        initial_learning_rate: 初始学习率
        """
        self.input_dim = input_dim
        self.map_rows, self.map_cols = map_size
        self.num_neurons = self.map_rows * self.map_cols

        # 初始化权重向量，范围在[0,1]之间
        self.weights = np.random.rand(self.map_rows, self.map_cols, input_dim)

        # 计算每个神经元的坐标，用于计算距离
        self.neuron_coords = np.array([[i, j] for i in range(self.map_rows)
                                       for j in range(self.map_cols)])

        self.initial_radius = initial_radius
        self.initial_learning_rate = initial_learning_rate

        # 保存训练过程中的权重
        self.weight_history = []

    def get_learning_rate(self, t, total_steps):
        """根据训练步数获取学习率"""
        if t <= 1000:
            # 前1000步从0.5线性下降至0.04
            return 0.5 - (0.5 - 0.04) * (t / 1000)
        else:
            # 1000到10000步从0.04线性下降至0
            return 0.04 - 0.04 * ((t - 1000) / (total_steps - 1000))

    def get_radius(self, t):
        """根据训练步数获取邻域半径"""
        if t <= 1000:
            # 1000步内从2线性下降至0
            return self.initial_radius - self.initial_radius * (t / 1000)
        else:
            # 1000步后保持0
            return 0

    def find_winner(self, input_vec):
        """找到与输入向量最匹配的神经元（获胜神经元）"""
        # 计算输入向量与所有神经元权重的欧氏距离
        distances = np.sqrt(np.sum((self.weights - input_vec) ** 2, axis=2))
        # 找到距离最小的神经元坐标
        winner_row, winner_col = np.unravel_index(np.argmin(distances), distances.shape)
        return winner_row, winner_col

    def update_weights(self, input_vec, winner, t, total_steps):
        """更新神经元权重"""
        learning_rate = self.get_learning_rate(t, total_steps)
        radius = self.get_radius(t)

        # 计算每个神经元到获胜神经元的距离
        for i in range(self.map_rows):
            for j in range(self.map_cols):
                # 计算网格距离
                distance = np.sqrt((i - winner[0]) ** 2 + (j - winner[1]) ** 2)

                # 如果在邻域范围内，则更新权重
                if distance <= radius:
                    # 计算邻域函数（高斯函数）
                    neighborhood = np.exp(-(distance ** 2) / (2 * (radius ** 2 + 1e-8)))

                    # 更新权重
                    self.weights[i, j] += learning_rate * neighborhood * (input_vec - self.weights[i, j])

    def train(self, input_data, num_steps):
        """训练SOM网络"""
        # 保存初始权重
        self.weight_history.append(np.copy(self.weights))

        for t in range(1, num_steps + 1):
            # 随机选择一个输入模式
            input_vec = input_data[np.random.randint(0, len(input_data))]

            # 找到获胜神经元
            winner = self.find_winner(input_vec)

            # 更新权重
            self.update_weights(input_vec, winner, t, num_steps)

            # 每200步保存一次权重
            if t % 200 == 0:
                self.weight_history.append(np.copy(self.weights))

        return self

    def get_mapping(self, input_data):
        """获取输入数据在SOM上的映射"""
        mapping = []
        for data in input_data:
            winner = self.find_winner(data)
            mapping.append(winner)
        return mapping


# 定义5个4维输入模式
input_data = np.array([
    [1, 0, 0, 0],  # X¹
    [1, 1, 0, 0],  # X²
    [1, 1, 1, 0],  # X³
    [0, 1, 0, 0],  # X⁴
    [1, 1, 1, 1]  # X⁵
])

# 创建并训练SOM网络
som = SOM(input_dim=4, map_size=(5, 5))
som.train(input_data, num_steps=10000)

# 获取每个输入模式的映射位置
mapping = som.get_mapping(input_data)

# 显示最终的映射结果
plt.figure(figsize=(8, 8))
plt.title('5个输入模式在5×5 SOM输出平面的映射')

# 绘制网格
for i in range(6):
    plt.axhline(i - 0.5, color='gray', linestyle='--', alpha=0.5)
    plt.axvline(i - 0.5, color='gray', linestyle='--', alpha=0.5)

# 标记每个输入模式的映射位置
markers = ['o', 's', 'D', '^', 'P']
labels = ['X¹', 'X²', 'X³', 'X⁴', 'X⁵']
colors = ['r', 'g', 'b', 'c', 'm']

for i, (row, col) in enumerate(mapping):
    plt.scatter(col, row, marker=markers[i], color=colors[i], s=100, label=labels[i])

plt.xlim(-0.5, 4.5)
plt.ylim(-0.5, 4.5)
plt.xticks(range(5))
plt.yticks(range(5))
plt.grid(True, alpha=0.3)
plt.legend()
plt.gca().invert_yaxis()  # 使(0,0)在左上角
plt.show()


# 可视化权重随训练步数的变化（每200步）
def plot_weight_evolution(som, input_data):
    """可视化权重随训练步数的变化"""
    num_plots = len(som.weight_history)
    cols = 5
    rows = (num_plots + cols - 1) // cols

    fig = plt.figure(figsize=(5 * cols, 5 * rows))
    gs = GridSpec(rows, cols, figure=fig)

    for i, weights in enumerate(som.weight_history):
        step = i * 200
        ax = fig.add_subplot(gs[i // cols, i % cols])
        ax.set_title(f'训练步数: {step}')

        # 绘制网格
        for j in range(6):
            ax.axhline(j - 0.5, color='gray', linestyle='--', alpha=0.5)
            ax.axvline(j - 0.5, color='gray', linestyle='--', alpha=0.5)

        # 标记每个输入模式的映射位置
        temp_som = SOM(4, (5, 5))
        temp_som.weights = weights
        mapping = temp_som.get_mapping(input_data)

        for k, (row, col) in enumerate(mapping):
            ax.scatter(col, row, marker=markers[k], color=colors[k], s=80, label=labels[k])

        ax.set_xlim(-0.5, 4.5)
        ax.set_ylim(-0.5, 4.5)
        ax.set_xticks(range(5))
        ax.set_yticks(range(5))
        ax.grid(True, alpha=0.3)
        ax.invert_yaxis()  # 使(0,0)在左上角

        if i == 0:
            ax.legend()

    plt.tight_layout()
    plt.show()


# 绘制权重随训练步数的变化（如果需要查看完整过程，可以取消下面一行的注释）
# plot_weight_evolution(som, input_data)

# 打印每个输入模式的最终映射位置
print("输入模式的最终映射位置：")
for i, (row, col) in enumerate(mapping):
    print(f"{labels[i]}: 位置 ({row}, {col})")