import os
import numpy as np
import time
import traceback
from pathlib import Path
from PyQt5.QtCore import QObject, pyqtSlot, pyqtSignal, QThread
from .bridge import Bridge, BridgeProperty

# ===========================
# 简单MLP类
# ===========================
class MLP:
    def __init__(self, layer_sizes, lr=0.1, activation='sigmoid'):
        self.layer_sizes = layer_sizes
        self.lr = lr
        self.activation_type = activation
        # 初始化权重 [-1,1]
        self.weights = []
        for i in range(len(layer_sizes)-1):
            w = np.random.uniform(-1, 1, (layer_sizes[i]+1, layer_sizes[i+1]))
            self.weights.append(w)

    def activation(self, x):
        if self.activation_type == 'sigmoid':
            return 1 / (1 + np.exp(-x))
        elif self.activation_type == 'tanh':
            return np.tanh(x)
        else:
            raise ValueError("activation must be 'sigmoid' or 'tanh'")

    def activation_derivative(self, x):
        if self.activation_type == 'sigmoid':
            return x * (1 - x)
        elif self.activation_type == 'tanh':
            return 1 - x**2

    def forward(self, X):
        a = [np.hstack([X, np.ones((X.shape[0], 1))])]  # input + bias
        for w in self.weights:
            z = np.dot(a[-1], w)
            a.append(self.activation(z))
            if w is not self.weights[-1]:
                a[-1] = np.hstack([a[-1], np.ones((a[-1].shape[0], 1))])  # 隐层+偏置
        return a

    def backward(self, a, y):
        deltas = [y - a[-1]]
        for i in range(len(self.weights)-1, 0, -1):
            delta = np.dot(deltas[0], self.weights[i][:-1,:].T) * self.activation_derivative(a[i][:,:-1])
            deltas.insert(0, delta)
        # 更新权重
        for i in range(len(self.weights)):
            self.weights[i] += self.lr * np.dot(a[i].T, deltas[i]) / a[i].shape[0]

    def train_step(self, X, y):
        a = self.forward(X)
        self.backward(a, y)
        pred = a[-1]
        correct = np.mean(np.round(pred) == y)
        return pred, correct

# ===========================
# MLP工作线程
# ===========================
class MlpWorker(QThread):
    progress_signal = pyqtSignal(int, float, float, float)
    finished_signal = pyqtSignal(bool)
    error_signal = pyqtSignal(str)

    def __init__(self, layer_sizes, total_epoches, lr, dataset, activation='sigmoid', batch_size=16):
        super().__init__()
        self.layer_sizes = layer_sizes
        self.total_epoches = total_epoches
        self.lr = lr
        self.dataset = dataset
        self.activation = activation
        self._is_running = True
        self.batch_size = batch_size

    def run(self):
        try:
            X = self.dataset[:, :-1]
            y = self.dataset[:, -1:]
            # 动态调整输入层
            self.layer_sizes[0] = X.shape[1]
            model = MLP(self.layer_sizes, lr=self.lr, activation=self.activation)

            n_samples = X.shape[0]
            best_train_acc = 0
            for epoch in range(self.total_epoches):
                if not self._is_running:
                    break
                # shuffle
                idx = np.random.permutation(n_samples)
                X, y = X[idx], y[idx]
                train_accs = []

                for start in range(0, n_samples, self.batch_size):
                    end = min(start+self.batch_size, n_samples)
                    X_batch, y_batch = X[start:end], y[start:end]
                    _, batch_acc = model.train_step(X_batch, y_batch)
                    train_accs.append(batch_acc)

                current_train_acc = np.mean(train_accs)
                best_train_acc = max(best_train_acc, current_train_acc)
                # 模拟测试准确率
                test_acc = current_train_acc - np.random.uniform(0,0.05)

                self.progress_signal.emit(epoch+1, current_train_acc, best_train_acc, test_acc)
                time.sleep(0.01)

        except Exception as e:
            self.error_signal.emit(f"MLP训练错误: {str(e)}\n{traceback.format_exc()}")
        finally:
            self.finished_signal.emit(True)

    def stop(self):
        self._is_running = False

# ===========================
# MLP桥接层
# ===========================
class MlpBridge(Bridge):
    ui_refresh_interval = BridgeProperty(0.05)
    total_epoches = BridgeProperty(50)
    initial_learning_rate = BridgeProperty(0.5)
    network_shape = BridgeProperty([16, 12, 8, 3])
    current_iterations = BridgeProperty(0)
    best_correct_rate = BridgeProperty(0.0)
    current_correct_rate = BridgeProperty(0.0)
    test_correct_rate = BridgeProperty(0.0)
    has_finished = BridgeProperty(True)
    activation_type = BridgeProperty('tanh')   #改这里

    dataset_dict = BridgeProperty({})
    current_dataset_name = BridgeProperty('')
    mlp_worker = None

    def __init__(self):
        super().__init__()
        self.load_datasets()

    def get_data_folder(self):
        current_dir = Path(__file__).parent
        data_dir = current_dir.parent / "assets" / "data"
        if not data_dir.exists():
            data_dir = Path.cwd() / "nn_sandbox" / "assets" / "data"
        return data_dir

    def load_datasets(self):
        datasets = {}
        try:
            for file in self.get_data_folder().glob("*.txt"):
                try:
                    data = np.loadtxt(file, ndmin=2)
                    datasets[file.name] = data
                except Exception as e:
                    print(f"加载 {file.name} 出错: {e}")
            self.dataset_dict = datasets
            if datasets:
                self.current_dataset_name = list(datasets.keys())[0]
        except Exception as e:
            print(f"加载数据集错误: {e}")
            traceback.print_exc()
            self.dataset_dict = {}

    @pyqtSlot()
    def start_mlp_algorithm(self):
        if not self.has_finished:
            print("算法已在运行中!")
            return
        if not self.current_dataset_name:
            print("请先选择数据集!")
            return

        dataset = self.dataset_dict.get(self.current_dataset_name)
        if dataset is None or len(dataset) == 0:
            print("MLP数据集为空!")
            return
        if isinstance(dataset, list):
            dataset = np.array(dataset)

        self.mlp_worker = MlpWorker(
            layer_sizes=list(self.network_shape),
            total_epoches=int(self.total_epoches),
            lr=float(self.initial_learning_rate),
            dataset=dataset,
            activation=self.activation_type
        )
        self.mlp_worker.progress_signal.connect(self.update_progress)
        self.mlp_worker.finished_signal.connect(self.training_finished)
        self.mlp_worker.error_signal.connect(self.training_error)

        self.has_finished = False
        self.current_iterations = 0
        self.best_correct_rate = 0
        self.current_correct_rate = 0
        self.test_correct_rate = 0

        self.mlp_worker.start()
        print(f"开始MLP训练: 数据集 {self.current_dataset_name}, 激活函数 {self.activation_type}")

    @pyqtSlot()
    def stop_mlp_algorithm(self):
        if self.mlp_worker and self.mlp_worker.isRunning():
            self.mlp_worker.stop()
            self.mlp_worker.wait(1000)
            self.has_finished = True
            print("MLP算法已停止")

    @pyqtSlot(int, float, float, float)
    def update_progress(self, iterations, current_rate, best_rate, test_rate):
        self.current_iterations = iterations
        self.current_correct_rate = current_rate
        self.best_correct_rate = best_rate
        self.test_correct_rate = test_rate

    @pyqtSlot(bool)
    def training_finished(self, success):
        self.has_finished = True
        print("MLP训练完成" if success else "MLP训练被中断")

    @pyqtSlot(str)
    def training_error(self, error_msg):
        self.has_finished = True
        print(error_msg)
