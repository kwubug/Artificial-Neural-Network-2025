import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.patches as patches

# 基础配置（避免字体警告，确保兼容性）
plt.rcParams["font.family"] = ["SimHei", "SimSun"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["animation.html"] = "jshtml"  # 兼容更多环境


class HopfieldSandbox:
    def __init__(self, num_neurons=4):
        # 1. Hopfield网络核心参数（固定权重，确保状态变化可观测）
        self.n = num_neurons
        self.weights = np.array([[0, 1, -1, 0.5],
                                 [1, 0, 0.5, -1],
                                 [-1, 0.5, 0, 1],
                                 [0.5, -1, 1, 0]])  # 对称矩阵，无自连接
        self.biases = np.array([0.2, -0.1, 0.3, -0.2])  # 偏置项
        self.state = np.array([1, -1, 1, -1])  # 初始状态（1=激活，-1=抑制）

        # 2. 记录历史数据（确保初始非空）
        self.states = [self.state.copy()]
        self.energies = [self.calculate_energy()]

        # 3. 强制稳定渲染后端（解决动画不播放问题）
        try:
            plt.switch_backend('TkAgg')
        except:
            plt.switch_backend('QtAgg')

        # 4. 创建沙箱可视化界面
        self.fig, (self.ax_state, self.ax_energy) = plt.subplots(1, 2, figsize=(14, 6))
        self.fig.suptitle('离散型Hopfield神经网络（异步更新）- 沙箱可视化', fontsize=16)

        # 5. 初始化神经元状态可视化（沙箱核心展示区）
        self.init_state_plot()

        # 6. 初始化能量收敛曲线
        self.init_energy_plot()

    def calculate_energy(self, state=None):
        """Hopfield能量函数（核心公式，能量单调不增）"""
        if state is None:
            state = self.state
        return -0.5 * np.dot(state.T, np.dot(self.weights, state)) - np.dot(self.biases, state)

    def async_update(self):
        """异步更新：随机选1个神经元，确保能量不增"""
        neuron_idx = np.random.randint(self.n)  # 随机选1个神经元
        # 计算激活值
        activation = np.dot(self.weights[neuron_idx], self.state) + self.biases[neuron_idx]
        # 符号函数更新（激活值≥0→1，否则→-1）
        old_state = self.state[neuron_idx]
        self.state[neuron_idx] = 1 if activation >= 0 else -1
        # 验证能量是否不增（Hopfield网络核心特性）
        new_energy = self.calculate_energy()
        assert new_energy <= self.energies[-1] + 1e-6, "能量不满足单调不增！"
        return self.state.copy()

    def init_state_plot(self):
        """沙箱左侧：神经元状态可视化（矩形布局，便于观察）"""
        self.neuron_pos = np.array([[1, 3], [3, 3], [3, 1], [1, 1]])  # 4个神经元矩形分布
        self.neuron_circles = [
            patches.Circle(pos, 0.8, edgecolor='black', linewidth=3, facecolor='gray')
            for pos in self.neuron_pos
        ]
        for circle in self.neuron_circles:
            self.ax_state.add_patch(circle)

        # 神经元标签（加粗放大，沙箱清晰标识）
        for i, pos in enumerate(self.neuron_pos):
            self.ax_state.text(pos[0], pos[1], f'神经元{i + 1}',
                               ha='center', va='center', fontsize=14, fontweight='bold')

        # 沙箱区域设置
        self.ax_state.set_xlim(0, 4)
        self.ax_state.set_ylim(0, 4)
        self.ax_state.set_aspect('equal')
        self.ax_state.set_title('神经元状态（红=1，蓝=-1）', fontsize=12)
        self.ax_state.axis('off')

    def init_energy_plot(self):
        """沙箱右侧：能量收敛曲线"""
        self.energy_line, = self.ax_energy.plot([0], [self.energies[0]],
                                                'b-', linewidth=2, label='网络能量')
        self.ax_energy.set_xlabel('迭代步数', fontsize=12)
        self.ax_energy.set_ylabel('能量值', fontsize=12)
        self.ax_energy.set_title('能量收敛过程（吸引子能量趋于稳定）', fontsize=12)
        self.ax_energy.legend()
        self.ax_energy.grid(alpha=0.3)
        self.ax_energy.set_xlim(0, 50)  # 固定x轴，避免闪烁

    def update_frame(self, frame):
        """动画每帧更新（沙箱动态核心）"""
        # 异步更新神经元状态
        current_state = self.async_update()
        self.states.append(current_state.copy())
        current_energy = self.calculate_energy()
        self.energies.append(current_energy)

        # 更新神经元颜色（强烈对比，沙箱直观）
        for i, circle in enumerate(self.neuron_circles):
            circle.set_facecolor('crimson' if current_state[i] == 1 else 'royalblue')

        # 更新能量曲线（强制刷新，避免卡顿）
        self.energy_line.set_data(range(len(self.energies)), self.energies)
        self.ax_energy.set_ylim(min(self.energies) - 1, max(self.energies) + 1)
        self.ax_energy.draw_artist(self.ax_energy.patch)
        self.ax_energy.draw_artist(self.energy_line)

        # 沙箱状态提示
        self.ax_state.set_title(f'迭代 {frame + 1}/50 | 状态: {current_state} | 能量: {current_energy:.2f}',
                                fontsize=11)

        # 强制画布刷新
        self.fig.canvas.draw_idle()
        return self.neuron_circles + [self.energy_line]

    def run_sandbox(self):
        """启动沙箱动画"""
        # 创建动画（优化参数，确保流畅）
        ani = FuncAnimation(
            self.fig,
            self.update_frame,
            frames=50,  # 50步迭代，足够观察收敛
            init_func=lambda: self.neuron_circles + [self.energy_line],
            interval=200,  # 200ms/帧，速度适中
            blit=False,  # 关闭blit，兼容所有环境
            repeat=False  # 不重复，停留在吸引子状态
        )

        # 布局调整
        plt.tight_layout()
        plt.subplots_adjust(top=0.9)
        plt.show()

        # 分析吸引子（沙箱结果输出）
        self.analyze_attractor()

    def analyze_attractor(self):
        """识别吸引子（能量稳定的状态）"""
        # 找到能量稳定的状态（最后10步状态一致则认为是吸引子）
        final_states = self.states[-10:]
        unique_states = [tuple(s) for s in final_states]
        if len(set(unique_states)) == 1:
            attractor = self.states[-1]
            attractor_energy = self.energies[-1]
            print("\n===== 沙箱分析结果：吸引子识别 =====")
            print(f"吸引子状态: {attractor} （1=激活，-1=抑制）")
            print(f"吸引子能量: {attractor_energy:.4f}")
            print("说明：能量趋于稳定且状态不再变化，该状态为网络吸引子（记忆态）")
        else:
            print("\n===== 沙箱分析结果：吸引子识别 =====")
            print("迭代步数不足，未完全收敛到吸引子，请增加frames参数重试")


if __name__ == "__main__":
    # 启动Hopfield沙箱
    hopfield_sandbox = HopfieldSandbox(num_neurons=4)
    hopfield_sandbox.run_sandbox()