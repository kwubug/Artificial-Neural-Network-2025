import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12

// 引入四个页面所在目录：Perceptron.qml / Mlp.qml / Rbfn.qml / Som.qml
import "components/dashboards"

ApplicationWindow {
    id: app
    title: qsTr("Neuron Network Sandbox")
    width: 1100
    height: 720
    visible: true

    // 顶部标签栏
    header: TabBar {
        id: tabbar
        currentIndex: pages.currentIndex

        TabButton { text: qsTr("Perceptron") }
        TabButton { text: qsTr("BP Network") }   // ★ 第二项标签
        TabButton { text: qsTr("RBFN") }
        TabButton { text: qsTr("SOM") }
    }

    // 页面容器，顺序与 TabBar 一一对应
    SwipeView {
        id: pages
        anchors.fill: parent
        currentIndex: tabbar.currentIndex

        Perceptron { id: perceptronPage }
        Mlp        { id: mlpPage }        // ★ 第二页就是我们的 BP Network
        Rbfn       { id: rbfnPage }
        Som        { id: somPage }
    }

    // 可选：键盘快捷键切换标签
    Shortcut { sequence: "Ctrl+Tab"; onActivated: tabbar.currentIndex = (tabbar.currentIndex + 1) % 4 }
    Shortcut { sequence: "Ctrl+Shift+Tab"; onActivated: tabbar.currentIndex = (tabbar.currentIndex + 3) % 4 }
}
