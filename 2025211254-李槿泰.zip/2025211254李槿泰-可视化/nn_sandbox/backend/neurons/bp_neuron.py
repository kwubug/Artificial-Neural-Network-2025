import numpy as np

class BPNeuron:
    def __init__(self, activation_function, activation_derivative):
        self.activation_function = activation_function
        self.activation_derivative = activation_derivative
        self.inputs = None
        self.output = None
        self.delta = None
        self.weights = None

    def activate(self):
        if self.inputs is None:
            raise ValueError("Inputs must be set before activation")
        if self.weights is None:
            self.weights = np.random.uniform(-1, 1, len(self.inputs) + 1)
        self.output = self.activation_function(np.dot(self.inputs, self.weights[:-1]) + self.weights[-1])

    def set_weights(self, weights):
        self.weights = weights