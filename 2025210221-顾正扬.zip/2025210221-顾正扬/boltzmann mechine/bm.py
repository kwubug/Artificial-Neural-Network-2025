import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import matplotlib.gridspec as gridspec

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号


class BoltzmannMachine:
    """
    实现一个简单的Boltzmann Machine（BM），包含三个神经元
    使用Metropolis-Hastings采样算法和温度退火来达到热平衡状态
    """

    def __init__(self, num_neurons=3):
        self.num_neurons = num_neurons
        # 权重矩阵（W_ij表示神经元i到j的连接权重）
        # 初始化为小的随机值，保证对称且对角线为0（无自连接）
        self.weights = np.random.uniform(-1, 1, (num_neurons, num_neurons))
        self.weights = (self.weights + self.weights.T) / 2  # 确保对称性
        np.fill_diagonal(self.weights, 0)  # 对角线为0（无自连接）

        # 偏置向量
        self.biases = np.random.uniform(-1, 1, num_neurons)

        # 神经元状态（0或1）
        self.states = np.random.choice([0, 1], num_neurons)

        # 记录训练历史
        self.state_history = []
        self.energy_history = []
        self.temperature_history = []

    def calculate_energy(self, states):
        """
        计算系统的总能量
        E = -0.5 * Σ(W_ij * s_i * s_j) - Σ(b_i * s_i)
        """
        energy = -0.5 * np.sum(self.weights * np.outer(states, states)) - np.sum(self.biases * states)
        return energy

    def metropolis_hastings_step(self, temperature):
        """
        执行一步Metropolis-Hastings采样
        随机选择一个神经元并尝试翻转其状态
        """
        # 随机选择一个神经元
        neuron_idx = np.random.randint(self.num_neurons)

        # 计算翻转前后的能量差
        old_states = self.states.copy()
        new_states = old_states.copy()
        new_states[neuron_idx] = 1 - new_states[neuron_idx]  # 翻转状态

        old_energy = self.calculate_energy(old_states)
        new_energy = self.calculate_energy(new_states)
        delta_energy = new_energy - old_energy

        # 根据Metropolis准则决定是否接受状态翻转
        if delta_energy < 0 or np.random.rand() < np.exp(-delta_energy / temperature):
            self.states = new_states
            return new_energy
        else:
            return old_energy

    def run_simulation(self, num_steps=10000, initial_temp=5.0, final_temp=0.1, cooling_rate=0.9995):
        """
        运行模拟退火过程
        """
        temperature = initial_temp

        for step in range(num_steps):
            # 执行一次Metropolis-Hastings采样
            energy = self.metropolis_hastings_step(temperature)

            # 记录当前状态和能量
            if step % 10 == 0:  # 每10步记录一次以减少数据量
                self.state_history.append(self.states.copy())
                self.energy_history.append(energy)
                self.temperature_history.append(temperature)

            # 降低温度
            temperature = max(temperature * cooling_rate, final_temp)

            # 每1000步打印进度
            if step % 1000 == 0:
                print(f"Step: {step}, Temperature: {temperature:.4f}, Energy: {energy:.4f}, States: {self.states}")

        return self.states, self.calculate_energy(self.states)

    def visualize_simulation(self):
        """
        可视化模拟过程
        1. 神经元状态随时间的变化
        2. 系统能量随时间的变化
        3. 温度随时间的变化
        4. 热平衡状态的网络连接图
        """
        fig = plt.figure(figsize=(15, 12))
        gs = gridspec.GridSpec(3, 2, height_ratios=[1, 1, 1])

        # 1. 神经元状态随时间的变化
        ax1 = fig.add_subplot(gs[0, :])
        state_history = np.array(self.state_history)
        time_steps = np.arange(0, len(self.state_history) * 10, 10)

        for i in range(self.num_neurons):
            ax1.plot(time_steps, state_history[:, i], label=f'Neuron {i + 1}')

        ax1.set_title('神经元状态随时间的变化')
        ax1.set_xlabel('时间步')
        ax1.set_ylabel('状态 (0/1)')
        ax1.set_ylim(-0.1, 1.1)
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. 系统能量随时间的变化
        ax2 = fig.add_subplot(gs[1, 0])
        ax2.plot(time_steps, self.energy_history, 'r-')
        ax2.set_title('系统能量随时间的变化')
        ax2.set_xlabel('时间步')
        ax2.set_ylabel('能量')
        ax2.grid(True, alpha=0.3)

        # 3. 温度随时间的变化
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.plot(time_steps, self.temperature_history, 'b-')
        ax3.set_title('温度随时间的变化')
        ax3.set_xlabel('时间步')
        ax3.set_ylabel('温度')
        ax3.grid(True, alpha=0.3)

        # 4. 热平衡状态的网络连接图
        ax4 = fig.add_subplot(gs[2, :])
        self._plot_network_state(ax4)

        plt.tight_layout()
        return fig

    def _plot_network_state(self, ax):
        """
        绘制网络连接图，显示神经元状态和连接权重
        """
        # 设置神经元位置
        pos = np.array([
            [np.cos(2 * np.pi * i / self.num_neurons), np.sin(2 * np.pi * i / self.num_neurons)]
            for i in range(self.num_neurons)
        ])

        # 绘制神经元
        for i, (x, y) in enumerate(pos):
            # 根据状态选择颜色（1为激活红色，0为非激活蓝色）
            color = 'red' if self.states[i] == 1 else 'blue'
            ax.scatter(x, y, s=1000, color=color, edgecolors='black', linewidths=2, alpha=0.7)
            ax.text(x, y, f'{i + 1}', fontsize=16, ha='center', va='center', color='white')

        # 绘制连接（根据权重设置线宽和颜色）
        max_weight = np.max(np.abs(self.weights))
        if max_weight > 0:
            for i in range(self.num_neurons):
                for j in range(i + 1, self.num_neurons):
                    if self.weights[i, j] != 0:
                        weight = self.weights[i, j]
                        linewidth = 3 * np.abs(weight) / max_weight  # 归一化线宽
                        color = 'red' if weight > 0 else 'blue'  # 正权重红色，负权重蓝色
                        ax.plot([pos[i, 0], pos[j, 0]], [pos[i, 1], pos[j, 1]],
                                color=color, linewidth=linewidth, alpha=0.7)
                        # 在线中间标注权重
                        mid_x = (pos[i, 0] + pos[j, 0]) / 2
                        mid_y = (pos[i, 1] + pos[j, 1]) / 2
                        ax.text(mid_x, mid_y, f'{weight:.2f}', fontsize=10,
                                ha='center', va='center', backgroundcolor='white', alpha=0.7)

        ax.set_title(f'热平衡状态的网络连接图 - 最终状态: {self.states}')
        ax.set_xlim(-1.2, 1.2)
        ax.set_ylim(-1.2, 1.2)
        ax.axis('off')

    def create_animation(self, interval=100):
        """
        创建神经元状态变化的动画
        """
        ani_fig, ani_ax = plt.subplots(figsize=(10, 8))
        ani = None  # 防止动画被垃圾回收

        def update(frame):
            ani_ax.clear()
            # 临时设置状态以绘制当前帧
            temp_states = self.state_history[frame].copy()
            original_states = self.states.copy()
            self.states = temp_states

            self._plot_network_state(ani_ax)
            ani_ax.set_title(f'神经元状态变化 - 时间步: {frame * 10}')

            # 恢复原始状态
            self.states = original_states
            return ani_ax,

        ani = FuncAnimation(ani_fig, update, frames=len(self.state_history),
                            interval=interval, blit=True)

        plt.tight_layout()
        return ani_fig, ani

    def determine_thermal_equilibrium(self, threshold=0.001, window_size=100):
        """
        通过分析能量变化来确定是否达到热平衡状态
        """
        if len(self.energy_history) < window_size:
            return False, 0

        # 计算最近window_size个能量值的标准差
        recent_energies = self.energy_history[-window_size:]
        energy_std = np.std(recent_energies)
        energy_mean = np.mean(recent_energies)

        # 归一化标准差
        normalized_std = energy_std / np.abs(energy_mean) if energy_mean != 0 else energy_std

        is_equilibrium = normalized_std < threshold

        # 找出最早达到平衡的时间点
        equilibrium_step = 0
        if is_equilibrium:
            # 从后往前查找首次满足平衡条件的位置
            for i in range(len(self.energy_history) - window_size, 0, -1):
                window_energies = self.energy_history[i:i + window_size]
                window_std = np.std(window_energies)
                window_mean = np.mean(window_energies)
                window_norm_std = window_std / np.abs(window_mean) if window_mean != 0 else window_std

                if window_norm_std >= threshold:
                    equilibrium_step = i + window_size
                    break

        return is_equilibrium, equilibrium_step


def main():
    # 创建Boltzmann Machine实例
    bm = BoltzmannMachine(num_neurons=3)

    print("初始权重矩阵:")
    print(bm.weights)
    print("初始偏置向量:")
    print(bm.biases)
    print("初始神经元状态:")
    print(bm.states)

    # 运行模拟
    print("\n开始模拟退火过程...")
    final_states, final_energy = bm.run_simulation(
        num_steps=20000,
        initial_temp=10.0,
        final_temp=0.01,
        cooling_rate=0.999
    )

    # 确定热平衡状态
    is_equilibrium, equilibrium_step = bm.determine_thermal_equilibrium()

    print("\n模拟完成!")
    print(f"最终神经元状态: {final_states}")
    print(f"最终系统能量: {final_energy:.4f}")
    print(f"是否达到热平衡: {is_equilibrium}")
    if is_equilibrium:
        print(f"达到热平衡的时间步: {equilibrium_step * 10}")

    # 可视化模拟结果
    print("\n生成可视化...")
    fig = bm.visualize_simulation()

    # 创建动画
    print("生成动画...")
    ani_fig, ani = bm.create_animation(interval=50)

    # 显示所有图形
    plt.show()


if __name__ == "__main__":
    main()
