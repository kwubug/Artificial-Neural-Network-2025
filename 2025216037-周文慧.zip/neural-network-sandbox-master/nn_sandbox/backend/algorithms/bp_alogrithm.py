import numpy as np
from threading import Thread


class BpAlgorithm(Thread):
    """
    Three-layer feedforward neural network with BP learning algorithm
    """

    def __init__(self, dataset, total_epoches, initial_learning_rate,
                 test_ratio, activation_function, network_shape,
                 initial_weight=0.5):
        super().__init__()
        self.dataset = np.array(dataset)
        self.total_epoches = total_epoches
        self.initial_learning_rate = initial_learning_rate
        self.test_ratio = test_ratio
        self.activation_function = activation_function
        self.network_shape = network_shape
        self.initial_weight = initial_weight

        self._split_dataset()
        self._initialize_network()

        self.current_iterations = 0
        self.best_correct_rate = 0.0
        self.current_correct_rate = 0.0
        self._running = True

    def _split_dataset(self):
        """Split dataset into training and testing sets"""
        np.random.shuffle(self.dataset)
        split_idx = int(len(self.dataset) * (1 - self.test_ratio))
        self.training_dataset = self.dataset[:split_idx]
        self.testing_dataset = self.dataset[split_idx:]

    def _initialize_network(self):
        """Initialize weights with random values in [-1, 1]"""
        input_size, hidden_size, output_size = self.network_shape

        # 使用[-1, 1]区间随机数初始化
        self.w_input_hidden = np.random.uniform(-1, 1, (input_size, hidden_size))
        self.w_hidden_output = np.random.uniform(-1, 1, (hidden_size, output_size))
        self.b_hidden = np.random.uniform(-1, 1, hidden_size)
        self.b_output = np.random.uniform(-1, 1, output_size)

    def _activation(self, x):
        """Apply activation function"""
        if self.activation_function == 0:
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
        else:
            return np.tanh(x)

    def _activation_derivative(self, y):
        """Derivative of activation function"""
        if self.activation_function == 0:
            return y * (1 - y)
        else:
            return 1 - y ** 2

    def _forward(self, x):
        """Forward propagation"""
        self.hidden_input = np.dot(x, self.w_input_hidden) + self.b_hidden
        self.hidden_output = self._activation(self.hidden_input)
        self.output_input = np.dot(self.hidden_output, self.w_hidden_output) + self.b_output
        self.output = self._activation(self.output_input)
        return self.output

    def _backward(self, x, y, output):
        """Backward propagation"""
        output_error = y - output
        output_delta = output_error * self._activation_derivative(output)
        hidden_error = np.dot(output_delta, self.w_hidden_output.T)
        hidden_delta = hidden_error * self._activation_derivative(self.hidden_output)

        self.w_hidden_output += self.current_learning_rate * np.outer(self.hidden_output, output_delta)
        self.w_input_hidden += self.current_learning_rate * np.outer(x, hidden_delta)
        self.b_output += self.current_learning_rate * output_delta
        self.b_hidden += self.current_learning_rate * hidden_delta

    def _calculate_accuracy(self, dataset, threshold=0.5):
        """Calculate classification accuracy"""
        if len(dataset) == 0:
            return 0.0
        
        correct = 0
        for i, data in enumerate(dataset):
            # 每处理10个样本检查一次停止标志，加快响应
            # 使用getattr安全检查_running属性
            if i % 10 == 0 and not getattr(self, '_running', True):
                return correct / max(i, 1)  # 返回当前的部分准确率
            
            x = data[:-1]
            y = data[-1:]
            output = self._forward(x)

            if len(output) == 1:
                predicted = 1 if output[0] > threshold else 0
                actual = 1 if y[0] > threshold else 0
            else:
                predicted = np.argmax(output)
                actual = np.argmax(y) if len(y) > 1 else int(y[0])

            if predicted == actual:
                correct += 1
        return correct / len(dataset)

    def _iterate(self):
        """Single training iteration"""
        for data in self.training_dataset:
            # 每个样本前检查停止标志（使用getattr安全检查）
            if not getattr(self, '_running', True):
                return  # 直接返回，不抛异常
            
            x = data[:-1]
            y = data[-1:]
            output = self._forward(x)
            self._backward(x, y, output)
            self.current_iterations += 1

            # 每10次迭代才计算一次准确率，避免计算过于频繁阻塞停止信号
            if self.current_iterations % 10 == 0:
                self.current_correct_rate = self._calculate_accuracy(self.training_dataset)
                if self.current_correct_rate > self.best_correct_rate:
                    self.best_correct_rate = self.current_correct_rate

    @property
    def current_learning_rate(self):
        """Calculate current learning rate (fixed for BP)"""
        return self.initial_learning_rate

    def run(self):
        """Main training loop"""
        try:
            for epoch in range(self.total_epoches):
                if not getattr(self, '_running', True):
                    break
                self._iterate()
                if not getattr(self, '_running', True):
                    break
        except Exception as e:
            # 捕获异常但不打印，避免污染输出
            pass

    def stop(self):
        """Stop the training"""
        self._running = False

    def test(self):
        """Test the network on testing dataset"""
        if not hasattr(self, 'testing_dataset') or len(self.testing_dataset) == 0:
            return 0.0
        return self._calculate_accuracy(self.testing_dataset)