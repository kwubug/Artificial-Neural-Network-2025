import numpy as np
import copy
import threading
import time
from collections import defaultdict


class HopfieldAlgorithm:
    """离散Hopfield神经网络实现"""
    
    def __init__(self, patterns=None, asynchronous_update=True):
        """
        初始化Hopfield网络
        
        Args:
            patterns: 训练模式列表，每个模式是一个二进制向量（1/-1）
            asynchronous_update: 是否使用异步更新
        """
        self.patterns = np.array(patterns) if patterns else None
        self.asynchronous_update = asynchronous_update
        self.weights = None
        self.biases = None
        self.energy_history = []
        self.state_history = []
        self._should_stop = False
        
        # 如果提供了模式，初始化权重
        if patterns:
            self._initialize_weights()
    
    def stop(self):
        """停止模拟"""
        self._should_stop = True
    
    def _initialize_weights(self):
        """使用Hebb学习规则初始化权重矩阵"""
        num_patterns, num_neurons = self.patterns.shape
        self.weights = np.zeros((num_neurons, num_neurons))
        self.biases = np.zeros(num_neurons)
        
        # Hebb学习规则
        for pattern in self.patterns:
            pattern = pattern.reshape(-1, 1)
            self.weights += np.dot(pattern, pattern.T)
        
        # 确保对角线为0（无自连接）
        np.fill_diagonal(self.weights, 0)
        
        # 标准化权重
        self.weights /= num_patterns
    
    def energy(self, state):
        """计算网络能量
        
        E = -1/2 * sum(weights[i,j] * state[i] * state[j]) - sum(biases[i] * state[i])
        """
        state = np.array(state)
        return -0.5 * np.dot(np.dot(state, self.weights), state) - np.dot(self.biases, state)
    
    def update_sync(self, state):
        """同步更新所有神经元"""
        return np.sign(np.dot(self.weights, state) + self.biases)
    
    def update_async(self, state):
        """异步随机更新单个神经元"""
        new_state = copy.copy(state)
        # 随机选择一个神经元进行更新
        neuron_idx = np.random.randint(0, len(state))
        activation = np.dot(self.weights[neuron_idx], new_state) + self.biases[neuron_idx]
        new_state[neuron_idx] = 1 if activation >= 0 else -1
        return new_state
    
    def recall(self, initial_state, max_iterations=1000, tolerance=1e-6):
        """从初始状态开始回忆，直到收敛或达到最大迭代次数
        
        Args:
            initial_state: 初始状态向量
            max_iterations: 最大迭代次数
            tolerance: 收敛容差
            
        Returns:
            final_state: 最终状态
            converged: 是否收敛
        """
        current_state = np.array(initial_state)
        self.state_history = [copy.copy(current_state)]
        self.energy_history = [self.energy(current_state)]
        
        for i in range(max_iterations):
            if self._should_stop:
                break
            
            # 根据设置选择更新方式
            if self.asynchronous_update:
                new_state = self.update_async(current_state)
            else:
                new_state = self.update_sync(current_state)
            
            # 计算能量变化
            new_energy = self.energy(new_state)
            
            # 记录状态和能量
            self.state_history.append(copy.copy(new_state))
            self.energy_history.append(new_energy)
            
            # 检查是否收敛
            if np.array_equal(new_state, current_state) or abs(new_energy - self.energy_history[-2]) < tolerance:
                return new_state, True
            
            current_state = new_state
            
            # 添加小延迟以支持实时可视化
            time.sleep(0.01)
        
        return current_state, False
    
    def find_attractors(self, max_iterations=100):
        """寻找网络的所有吸引子
        
        Returns:
            attractors: 吸引子及其能量的字典
        """
        attractors = {}
        visited_states = set()
        
        # 从每个训练模式开始寻找吸引子
        if self.patterns is not None:
            for pattern in self.patterns:
                state_tuple = tuple(pattern)
                if state_tuple not in visited_states:
                    final_state, _ = self.recall(pattern, max_iterations)
                    final_state_tuple = tuple(final_state)
                    if final_state_tuple not in attractors:
                        energy = self.energy(final_state)
                        attractors[final_state_tuple] = energy
                        
                    # 标记这个路径上的所有状态为已访问
                    for state in self.state_history:
                        visited_states.add(tuple(state))
        
        # 也可以尝试随机初始状态来寻找更多吸引子
        num_neurons = len(self.weights)
        for _ in range(min(100, 2**num_neurons)):  # 限制尝试次数
            if len(attractors) >= 2**num_neurons:  # 已经找到所有可能的吸引子
                break
                
            # 生成随机初始状态
            random_state = np.random.choice([-1, 1], size=num_neurons)
            state_tuple = tuple(random_state)
            
            if state_tuple not in visited_states:
                final_state, _ = self.recall(random_state, max_iterations)
                final_state_tuple = tuple(final_state)
                
                if final_state_tuple not in attractors:
                    energy = self.energy(final_state)
                    attractors[final_state_tuple] = energy
                
                # 标记这个路径上的所有状态为已访问
                for state in self.state_history:
                    visited_states.add(tuple(state))
        
        return attractors
    
    def get_visualization_data(self):
        """获取可视化数据
        
        Returns:
            dict: 包含状态历史、能量历史等可视化所需数据
        """
        return {
            'state_history': self.state_history,
            'energy_history': self.energy_history,
            'weights': self.weights,
            'current_state': self.state_history[-1] if self.state_history else None
        }