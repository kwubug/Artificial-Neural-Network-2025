import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt

torch.manual_seed(42)
# train dataset
p = np.arange(-1, 1.1, 0.1)  # -1到1，步长0.1
t = np.array([-0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609,
              0.1336, -0.2013, -0.4344, -0.5000, -0.3939, 0, -0.1647,
              0.0988, 0.3072, 0.3960, 0.3449, 0.1816, -0.0312, -0.2189])
p_tensor = torch.FloatTensor(p).reshape(-1, 1)  # shape(21, 1)
t_tensor = torch.FloatTensor(t).reshape(-1, 1)  # shape(21, 1)

class RBFNet(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(RBFNet, self).__init__()
        self.hidden_dim = hidden_dim
        # RBF中心点
        centers_init = torch.linspace(-1, 1, hidden_dim).reshape(-1, 1)
        self.centers = nn.Parameter(centers_init)

        # RBF宽度参数
        self.sigmas = nn.Parameter(torch.ones(hidden_dim) * 0.5)
        # 输出层权重
        self.linear = nn.Linear(hidden_dim, output_dim, bias=True)

    def rbf_function(self, x):
        # 计算输入x与所有中心点的欧氏距离
        # x形状: (batch_size, 1), centers形状: (hidden_dim, 1)
        distances = torch.cdist(x, self.centers)  # 形状: (batch_size, hidden_dim)

        # 应用高斯径向基函数
        return torch.exp(-distances.pow(2) / (2 * self.sigmas.pow(2)))

    def forward(self, x):
        # RBF层
        rbf_out = self.rbf_function(x)  # 形状: (batch_size, hidden_dim)

        # 线性输出层
        output = self.linear(rbf_out)  # 形状: (batch_size, 1)
        return output


# 网络参数
input_dim = 1
hidden_dim = 15  # RBF神经元数量
output_dim = 1

# 创建模型
model = RBFNet(input_dim, hidden_dim, output_dim)

# 损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

epochs = 2000
losses = []

# train model
for epoch in range(epochs):
    # 前向传播
    outputs = model(p_tensor)
    loss = criterion(outputs, t_tensor)

    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    losses.append(loss.item())

    if epoch % 400 == 0:
        print(f'Epoch [{epoch}/{epochs}], Loss: {loss.item():.6f}')

# 测试和可视化
model.eval()
with torch.no_grad():
    predictions = model(p_tensor)
    final_loss = criterion(predictions, t_tensor)
    print(f'\n最终损失: {final_loss.item():.6f}')

# 确保预测结果维度正确
predictions_np = predictions.squeeze().numpy()

# 绘制结果
plt.figure(figsize=(15, 5))

# 损失曲线
plt.subplot(1, 3, 1)
plt.plot(losses, 'g-', linewidth=2)
plt.title('Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.yscale('log')

# 拟合结果
plt.subplot(1, 3, 2)
plt.scatter(p, t, color='red', label='true', s=60, alpha=0.7, edgecolors='black')
plt.plot(p, predictions_np, 'b-', label='RBF', linewidth=2.5)
plt.title('RBF')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()

# 误差分析
plt.subplot(1, 3, 3)
errors = np.abs(predictions_np - t)
plt.bar(range(len(errors)), errors, alpha=0.7, color='orange')
plt.title('abs error')
plt.xlabel('indx')
plt.ylabel('error')

plt.tight_layout()
plt.show()

print(f"\n=== RBF神经网络训练结果总结 ===")
print(f"输入数据点数量: {len(p)}")
print(f"RBF神经元数量: {hidden_dim}")
print(f"训练轮数: {epochs}")
print(f"最终MSE损失: {final_loss.item():.8f}")

print(f"\n=== 预测结果对比 (前10个点) ===")
print("x值\t真实y值\t\t预测y值\t\t绝对误差")
print("-" * 55)
for i in range(min(10, len(p))):
    true_val = t[i]
    pred_val = predictions_np[i]
    error = abs(true_val - pred_val)
    print(f"{p[i]:.1f}\t{true_val:.4f}\t\t{pred_val:.4f}\t\t{error:.4f}")

mean_error = np.mean(np.abs(predictions_np - t))
max_error = np.max(np.abs(predictions_np - t))
print(f"\n误差统计:")
print(f"平均绝对误差: {mean_error:.6f}")
print(f"最大绝对误差: {max_error:.6f}")
