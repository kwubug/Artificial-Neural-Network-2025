import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import os

# 设置环境变量以消除警告
os.environ["OMP_NUM_THREADS"] = "1"  # 避免 KMeans 内存泄漏警告
os.environ["LOKY_MAX_CPU_COUNT"] = "4"  # 设置使用的核心数，避免 joblib 警告

# 生成输入向量 P，从 -1 到 1，步长为 0.1，共21个样本
P = np.arange(-1.0, 1.1, 0.1)

# 目标向量 t，根据题目提供的值，共有21个目标值
t = np.array([
    -0.9602, -0.5770, -0.0729, 0.3771, 0.6405, 0.6600, 0.4609, 0.1336, -0.2013,
    -0.4344, -0.5000, -0.3939, -0.1647, 0.0988, 0.3072, 0.3960, 0.3449, 0.1816,
    -0.0312, -0.2189, -0.3201
])

# 任务：设计RBF神经网络
# 1. 使用KMeans初始化隐节点中心
M = 10  # 隐节点数
kmeans = KMeans(n_clusters=M, n_init=10, max_iter=500)
kmeans.fit(P.reshape(-1, 1))  # 聚类并找到聚类中心
centers = kmeans.cluster_centers_.flatten()  # 获取聚类中心

# 2. 设置扩展常数 sigma（这里设置为 1，确保隐节点重叠系数为 1）
sigma = 1.0

# 3. 计算 RBF 网络的输出（高斯核函数）
def rbf_kernel(x, centers, sigma):
    # 计算每个输入与中心之间的RBF距离
    return np.exp(-np.square(x - centers) / (2 * sigma**2))

# 计算所有样本的RBF输出
X = np.array([rbf_kernel(p, centers, sigma) for p in P])

# 4. 通过伪逆方法计算输出层权重
X_ = np.vstack([np.ones(len(P)), X.T]).T  # 添加偏置项（即常数1）
W = np.linalg.pinv(X_) @ t  # 使用伪逆法求解权重

# 5. 计算网络的预测输出
t_pred = X_ @ W  # 计算预测值

# 6. 可视化原始目标和预测结果
plt.figure(figsize=(10, 6))
plt.plot(P, t, label="True Target", marker='o', color='blue')
plt.plot(P, t_pred, label="RBF Network Prediction", marker='x', color='red')
plt.xlabel("P (Input)")
plt.ylabel("t (Output)")
plt.title("RBF Network Fitting")
plt.legend()
plt.grid(True)
plt.show()

# 输出预测结果
print("Predicted values (t_pred):", t_pred)
