import sys
import numpy as np
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget,
                             QVBoxLayout, QHBoxLayout, QPushButton,
                             QLabel, QSlider, QSpinBox)
from PyQt5.QtCore import Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline


class PolynomialRegressionVisualization(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OLS多项式回归可视化")
        self.setGeometry(100, 100, 800, 600)

        # 创建主部件和布局
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # 创建matplotlib图形
        self.figure = Figure(figsize=(8, 5), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)

        # 生成带有曲线特征的随机数据
        np.random.seed(42)
        self.X = np.random.rand(30) * 10
        self.y = 0.5 * self.X ** 2 - 2 * self.X + 3 + np.random.randn(30) * 3

        # 绘制初始数据点
        self.scatter = self.ax.scatter(self.X, self.y, c='blue', label='数据点')

        # 添加拟合曲线
        self.curve, = self.ax.plot([], [], 'r-', linewidth=2, label='拟合曲线')

        # 设置图形属性
        self.ax.set_xlim(0, 10)
        self.ax.set_ylim(min(self.y) - 2, max(self.y) + 2)
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('y')
        self.ax.set_title('普通最小二乘法(OLS)多项式回归')
        self.ax.legend()
        self.ax.grid(True)

        # 添加控制面板
        control_panel = QWidget()
        control_layout = QHBoxLayout(control_panel)

        # 添加多项式次数选择器
        degree_label = QLabel("多项式次数:")
        self.degree_spin = QSpinBox()
        self.degree_spin.setRange(1, 5)
        self.degree_spin.setValue(2)
        self.degree_spin.valueChanged.connect(self.fit_curve)

        # 添加拟合按钮
        self.fit_button = QPushButton("拟合曲线")
        self.fit_button.clicked.connect(self.fit_curve)

        # 添加重置按钮
        self.reset_button = QPushButton("重置")
        self.reset_button.clicked.connect(self.reset_plot)

        # 添加控件到面板
        control_layout.addWidget(degree_label)
        control_layout.addWidget(self.degree_spin)
        control_layout.addWidget(self.fit_button)
        control_layout.addWidget(self.reset_button)

        main_layout.addWidget(self.canvas)
        main_layout.addWidget(control_panel)

        # 初始拟合
        self.fit_curve()

    def fit_curve(self):
        """多项式回归拟合数据"""
        degree = self.degree_spin.value()

        # 创建多项式回归模型
        model = make_pipeline(
            PolynomialFeatures(degree),
            LinearRegression()
        )

        # 拟合数据
        model.fit(self.X.reshape(-1, 1), self.y)

        # 生成拟合曲线数据
        x_curve = np.linspace(0, 10, 100)
        y_curve = model.predict(x_curve.reshape(-1, 1))

        # 更新曲线
        self.curve.set_data(x_curve, y_curve)
        self.ax.set_title(f'多项式回归 (次数={degree})')
        self.canvas.draw()

    def reset_plot(self):
        """重置图形"""
        self.degree_spin.setValue(2)
        self.fit_curve()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PolynomialRegressionVisualization()
    window.show()
    sys.exit(app.exec_())
