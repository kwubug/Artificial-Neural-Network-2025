# hopfield_async_fixed.py
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import copy

np.random.seed(0)

class Hopfield:
    def __init__(self, n_units):
        self.n = n_units
        self.W = np.zeros((n_units, n_units))

    def hebbian_train(self, patterns, normalize=True):
        P = len(patterns)
        W = np.zeros((self.n, self.n))
        for p in patterns:
            p = p.reshape(self.n, 1)
            W += p @ p.T
        np.fill_diagonal(W, 0)
        if normalize:
            W = W / self.n
        self.W = (W + W.T) / 2.0

    def energy(self, s):
        s = s.reshape(self.n)
        return -0.5 * s.dot(self.W).dot(s)

    def async_update(self, init_state, max_steps=1000, record_energy=True, detect_cycle=True):
        s = init_state.copy().astype(int)
        energies = []
        seen = dict()
        for step in range(max_steps):
            i = np.random.randint(0, self.n)
            total = self.W[i].dot(s)
            new_val = 1 if total >= 0 else -1
            s[i] = new_val

            if record_energy:
                energies.append(self.energy(s))

            if detect_cycle:
                key = tuple(s.tolist())
                if key in seen:
                    return s.copy(), energies, step+1, "cycle"
                seen[key] = step
        return s.copy(), energies, max_steps, "max_steps"

    def is_stable(self, state):
        s = state.copy()
        for i in range(self.n):
            total = self.W[i].dot(s)
            new_val = 1 if total >= 0 else -1
            if new_val != s[i]:
                return False
        return True

def find_attractors(hop, trials=200, max_steps=2000):
    attractor_map = {}
    for t in range(trials):
        init = np.random.choice([1, -1], size=hop.n)
        final, energies, steps, status = hop.async_update(init, max_steps=max_steps, record_energy=True, detect_cycle=False)
        key = tuple(final.tolist())
        if key not in attractor_map:
            attractor_map[key] = {"count": 0, "energy": hop.energy(final), "example_energies": energies, "example_init": init}
        attractor_map[key]["count"] += 1
    return attractor_map

def plot_energy_traces(sample_energies, filename=None):
    plt.figure(figsize=(8,4))
    for e in sample_energies:
        plt.plot(e, alpha=0.8)
    plt.xlabel("异步更新步数")
    plt.ylabel("能量 E")
    plt.title("示例能量轨迹（异步更新）")
    plt.grid(True)
    if filename:
        plt.savefig(filename, dpi=200)
        print("Saved:", filename)
    else:
        plt.show()

def plot_attractors(attractor_map, ncols=5, filename=None):
    keys = list(attractor_map.keys())
    n = len(keys)
    ncols = min(ncols, n) if n>0 else 1
    nrows = int(np.ceil(n / ncols)) if n>0 else 1
    plt.figure(figsize=(ncols*2, nrows*2))
    for idx, key in enumerate(keys):
        ax = plt.subplot(nrows, ncols, idx+1)
        arr = np.array(key)
        k = len(arr)
        rows = int(np.round(np.sqrt(k)))
        if rows*rows == k:
            img = arr.reshape((rows, rows))
            ax.imshow((img+1)/2, cmap="gray", vmin=0, vmax=1)
        else:
            ax.bar(range(k), arr)
            ax.set_ylim(-1.1, 1.1)
        ax.set_title(f"count={attractor_map[key]['count']}\nE={attractor_map[key]['energy']:.2f}")
        ax.axis('off')
    plt.suptitle("找到的吸引子（每个子图显示吸引子及其计数/能量）")
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    if filename:
        plt.savefig(filename, dpi=200)
        print("Saved:", filename)
    else:
        plt.show()

def plot_basin_hist(attractor_map, filename=None):
    counts = [v["count"] for v in attractor_map.values()]
    plt.figure(figsize=(6,4))
    plt.bar(range(len(counts)), counts)
    plt.xlabel("吸引子编号")
    plt.ylabel("基域大小（命中次数）")
    plt.title("吸引子基域大小分布")
    if filename:
        plt.savefig(filename, dpi=200)
        print("Saved:", filename)
    else:
        plt.show()

def demo():
    n_units = 16
    hop = Hopfield(n_units)

    p1 = np.ones(n_units, dtype=int)

    # ---- 这里是修正后的 p2：vertical stripes (每列前两行为 +1) ----
    p2 = np.array([1 if (i % 4) < 2 else -1 for i in range(n_units)])

    # 原来的棋盘模式 p3（保留）
    p3 = np.array([1 if ((i//4 + i%4)%2==0) else -1 for i in range(n_units)])

    patterns = np.vstack([p1, p2, p3])

    print("Training patterns (rows):")
    print(patterns)
    hop.hebbian_train(patterns, normalize=True)
    print("Weight matrix sample (first row):", hop.W[0,:5])

    trials = 300
    attractors = find_attractors(hop, trials=trials, max_steps=1000)
    print(f"Ran {trials} trials. Found {len(attractors)} unique attractors.")

    sample_energies = []
    for k, v in list(attractors.items())[:6]:
        sample_energies.append(v["example_energies"])
    if len(sample_energies) > 0:
        plot_energy_traces(sample_energies, filename="energy_traces.png")

    plot_attractors(attractors, ncols=3, filename="attractors.png")
    plot_basin_hist(attractors, filename="basin_hist.png")

    print("\nAttractors summary (first 6):")
    for i, (k,v) in enumerate(attractors.items()):
        print(f"{i}: count={v['count']}, energy={v['energy']:.4f}, state (first 16): {k}")

    print("\nSaved plots: energy_traces.png, attractors.png, basin_hist.png")

if __name__ == "__main__":
    demo()
