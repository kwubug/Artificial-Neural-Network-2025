import collections

import numpy as np

from . import PredictiveAlgorithm
from ..neurons import Perceptron
from ..utils import sigmoid, bi_sigmoid


class BpAlgorithm(PredictiveAlgorithm):
    def __init__(
        self,
        dataset,
        total_epoches=10,
        most_correct_rate=None,
        initial_learning_rate=0.8,
        search_iteration_constant=10000,
        momentum_weight=0.5,
        test_ratio=0.3,
        hidden_layers=None,
        activation_type='uni_sigmoid'
    ):
        super().__init__(
            dataset,
            total_epoches,
            most_correct_rate,
            initial_learning_rate,
            search_iteration_constant,
            test_ratio
        )
        self._momentum_weight = momentum_weight
        self._activation_type = activation_type

        self.current_error = 0.0
        self.epoch_errors = []
        self.hidden_layers = hidden_layers if hidden_layers else [5]

        # for momentum
        self._synaptic_weight_diff = collections.defaultdict(lambda: 0)

    def _iterate(self):
        # Forward propagation
        result = self._feed_forward(self.current_data[:-1])

        values = self._normalize(self.current_data[-1])
        self.current_error = 0.5 * (values - result) ** 2

        # Backward propagation
        deltas = self._backpropagation(values, result)

        self._update_weights(deltas)

    def _initialize_neurons(self):
        input_size = len(self.training_dataset[0]) - 1

        activation_func = sigmoid if self._activation_type == 'uni_sigmoid' else bi_sigmoid

        self._neurons = []

        for layer_size in self.hidden_layers:  # Hidden layers
            layer = tuple(Perceptron(activation_func) for _ in range(layer_size))
            self._neurons.append(layer)

        output_layer = (Perceptron(activation_func),)  # Output layer
        self._neurons.append(output_layer)

        self._neurons = tuple(self._neurons)

    def _feed_forward(self, data):
        results = None

        for layer_idx, layer in enumerate(self._neurons):
            if layer_idx == 0:
                results = self._get_layer_output(layer, data)
            else:
                results = self._get_layer_output(layer, results)

        return results[0]

    def _get_layer_output(self, layer, input_data):
        results = []
        for neuron in layer:
            neuron.data = input_data
            results.append(neuron.result)
        return np.array(results)

    def _backpropagation(self, expected, actual_output):
        deltas = {}

        output_neuron = self._neurons[-1][0]
        output_error = expected - actual_output

        if self._activation_type == 'uni_sigmoid':
            # 单极性Sigmoid derivative:
            deltas[output_neuron] = output_error * actual_output * (1 - actual_output)
        else:
            # 双极性Sigmoid derivative:
            deltas[output_neuron] = output_error * (1 - actual_output**2) / 2

        for layer_idx in range(len(self._neurons) - 2, -1, -1):
            layer = self._neurons[layer_idx]
            next_layer = self._neurons[layer_idx + 1]

            for neuron_idx, neuron in enumerate(layer):
                error_sum = sum(
                    deltas[next_neuron] * next_neuron.synaptic_weight[neuron_idx]
                    for next_neuron in next_layer
                )

                if self._activation_type == 'uni_sigmoid':
                    # 单极性Sigmoid derivative
                    deltas[neuron] = neuron.result * (1 - neuron.result) * error_sum
                else:
                    # 双极性Sigmoid derivative
                    deltas[neuron] = (1 - neuron.result**2) / 2 * error_sum

        return deltas

    def _update_weights(self, deltas):
        for neuron in deltas:
            # Calculate weight change with momentum
            weight_change = (
                self._momentum_weight * self._synaptic_weight_diff[neuron] +
                self.current_learning_rate * deltas[neuron] * neuron.data
            )

            # Store for next iteration (momentum)
            self._synaptic_weight_diff[neuron] = weight_change

            # Update weights
            neuron.synaptic_weight += weight_change

    def _correct_rate(self, dataset):
        if not self._neurons:
            return 0

        correct_count = 0
        for data in dataset:
            output = self._feed_forward(data[:-1])
            expected = self._normalize(data[-1])

            # Classification threshold: ±1/(2*num_classes)
            threshold = 1.0 / (2 * len(self.group_types))

            if abs(expected - output) < threshold:
                correct_count += 1

        return correct_count / len(dataset) if len(dataset) > 0 else 0

    def _normalize(self, value):
        min_value = np.amin(self.group_types)
        max_value = np.amax(self.group_types)
        num_classes = len(self.group_types)

        if self._activation_type == 'uni_sigmoid':
            return (value - min_value) / (max_value - min_value) if max_value != min_value else 0.5
        else:
            if max_value == min_value:
                return 0.0
            return 2 * (value - min_value) / (max_value - min_value) - 1

    def run(self):
        self._initialize_neurons()

        for epoch in range(self._total_epoches):
            if self._should_stop:
                break

            np.random.shuffle(self.training_dataset)
            epoch_error = 0.0

            # one sample
            for sample_idx in range(len(self.training_dataset)):
                self.current_iterations = epoch * len(self.training_dataset) + sample_idx
                self._iterate()
                epoch_error += self.current_error
                self._save_best_neurons()

                if self._should_stop:
                    break

            # average error
            avg_error = epoch_error / len(self.training_dataset)
            self.epoch_errors.append(avg_error)

            if self._most_correct_rate and self.best_correct_rate >= self._most_correct_rate:
                break

        self._load_best_neurons()