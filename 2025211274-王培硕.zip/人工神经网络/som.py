# -*- coding: UTF-8 -*-
import numpy as np
import pylab as pl

def draw(C):  # 画图函数
    colValue = ['r', 'y', 'g', 'b', 'c', 'k', 'm']
    for i in range(len(C)):
        coo_X, coo_Y = [], []
        for j in range(len(C[i])):
            coo_X.append(C[i][j][0])
            coo_Y.append(C[i][j][1])
        pl.scatter(coo_X, coo_Y, marker='x', color=colValue[i % len(colValue)], label=i)
    pl.legend(loc='upper right')
    pl.show()

def normal_X(X):  # 输入归一化处理
    N, D = X.shape
    for i in range(N):
        temp = float(np.sum(np.multiply(X[i], X[i])))
        if temp > 0:
            X[i] /= np.sqrt(temp)
    return X

def normal_W(W):  # 初始权值归一化处理
    for i in range(W.shape[1]):
        temp = float(np.sum(np.multiply(W[:, i], W[:, i])))
        if temp > 0:
            W[:, i] /= np.sqrt(temp)
    return W

class myson(object):
    def __init__(self, X, output, times, size):
        """
        X: (N, D) 样本
        output: (a, b) 输出平面大小
        times: 迭代次数
        size: 每次随机抽样的样本数
        """
        self.X = np.array(X)        # (N, D)
        self.output = tuple(output) # (a, b)
        self.times = int(times)
        self.size = int(size)
        self.W = np.random.rand(self.X.shape[1], output[0] * output[1])  # (D, a*b)
        print(self.W.shape)  # (D, 25)

    def reE(self, t, n):
        # 学习率项（示例：随 t 递减，随邻域距离 n 衰减）
        return np.exp(-n) / (t + 2)

    def reN(self, t):  # 返回拓扑距离（Chebyshev 半径）
        a = min(self.output)
        # 从 a 线性降到 0
        N = int(a - float(a) * t / max(1, self.times))
        return max(0, N)

    def _grid_ij(self, idx):
        a, b = self.output
        return idx // b, idx % b

    def dis(self, index1, index2):  # 网格 Chebyshev 距离的两个轴向差
        a, b = self.output
        i1_a, i1_b = index1 // b, index1 % b
        i2_a, i2_b = index2 // b, index2 % b
        return abs(i1_a - i2_a), abs(i1_b - i2_b)

    def nei(self, index, N):
        """
        返回一个长度为 N+1 的列表，nei[d] 为与 index 的 Chebyshev 距离==d 的所有节点索引集合；
        其中 d=0 包含 index 自身。
        """
        a, b = self.output
        length = a * b
        ans = [set() for _ in range(N + 1)]
        for i in range(length):
            da, db = self.dis(i, index)
            d = max(da, db)
            if d <= N:
                ans[d].add(i)
        return ans

    def upW(self, Xbatch, t, winner):
        """
        Xbatch: (B, D)
        winner: 长度为 B 的 BMU 索引（0..a*b-1）
        """
        N = self.reN(t)
        for x, idx in enumerate(winner):
            to_update = self.nei(idx, N)  # 现在返回的是列表(长度 N+1)
            for j in range(N + 1):
                e = self.reE(t, j)
                for w in to_update[j]:
                    # W[:, w] 形状 (D,)
                    self.W[:, w] = self.W[:, w] + e * (Xbatch[x, :] - self.W[:, w])

    def train(self):
        count = 0
        while count < self.times:
            # 随机抽样一批
            choose = np.random.choice(self.X.shape[0], self.size)
            train_X = self.X[choose].copy()
            # 归一化
            normal_W(self.W)
            normal_X(train_X)
            # 前向求 BMU
            train_Y = train_X.dot(self.W)  # (B, a*b)
            winner = np.argmax(train_Y, axis=1).tolist()  # list[int]
            # 更新权值
            self.upW(train_X, count, winner)
            count += 1
        return self.W

    def af_train(self):
        normal_X(self.X)
        normal_W(self.W)
        train_Y = self.X.dot(self.W)
        winner = np.argmax(train_Y, axis=1).tolist()
        print(winner)
        return winner

if __name__ == '__main__':
    data = """1,0,0,0, 1,1,0,0, 1,1,1,0, 0,1,0,0, 1,1,1,1"""
    a = [s for s in data.split(',')]
    a = [float(s) for s in a]
    dataset = np.array([[a[i], a[i+1], a[i+2], a[i+3]] for i in range(0, len(a), 4)], dtype=float)
    dataset_old = dataset.copy()

    som = myson(dataset, (5, 5), times=1000, size=min(5, len(dataset)))
    som.train()
    res = som.af_train()  # list[int]，每个样本对应的BMU索引

    # 将样本按BMU分组
    classify = {}
    for i, win in enumerate(res):
        classify.setdefault(win, []).append(i)

    A, B = [], []
    for idx_list in classify.values():
        A.append(dataset_old[idx_list].tolist())
        B.append(dataset[idx_list].tolist())

    draw(A)  # 未归一化
    draw(B)  # 归一化
