# Boltzmann Machine Architecture (玻尔兹曼机架构文档)

## 概述

本项目中的 Boltzmann Machine (BM) 实现采用**三层架构**：
- **Backend Algorithm** (`bm_algorithm.py`) - 核心神经网络算法
- **Qt Bridge** (`bm_bridge.py`) - 与 QML 的通信桥梁
- **QML Frontend** (`BoltzmannMachine.qml`) - 用户界面和可视化

这种分离保证了**算法独立性**、**可测试性**和**UI 灵活性**。

---

## 1. 系统架构图

```
┌─────────────────────────────────────────────────────────┐
│                   QML Frontend                          │
│          (BoltzmannMachine.qml - 用户界面)              │
├─────────────────────────────────────────────────────────┤
│  Canvas(网络图) │ Canvas(能量图) │ 热力图 │ 按钮 │ 统计  │
│                Qt 属性绑定 ↔ PyQt 信号槽             │
├─────────────────────────────────────────────────────────┤
│                   Qt Bridge                             │
│              (BoltzmannBridge - 数据桥梁)              │
│  • Properties: temperature, energy, state, ...          │
│  • Slots: step(), anneal(), set_temperature(), ...      │
│  • State sync: _sync_state_from_backend()              │
├─────────────────────────────────────────────────────────┤
│                Backend Algorithm                        │
│         (BoltzmannMachine - 核心网络算法)              │
│  • Gibbs sampling with temperature control             │
│  • Energy calculation & probability distribution       │
│  • Thermal equilibrium detection                       │
│  • Simulated annealing                                 │
└─────────────────────────────────────────────────────────┘
```

---

## 2. 后端算法层 (`bm_algorithm.py`)

### 2.1 类：`BoltzmannMachine`

**参数：**
- `num_neurons` (int): 神经元数量，默认为 3

**核心属性：**

| 属性 | 类型 | 说明 |
|------|------|------|
| `_weights` | np.ndarray (n×n) | 对称权重矩阵，无自连接 |
| `_biases` | np.ndarray (n,) | 偏置向量 |
| `_state` | np.ndarray (n,) | 当前状态（0 或 1） |
| `_temperature` | float | 温度参数 T |
| `_energy` | float | 当前能量 E(x) |
| `_probabilities` | np.ndarray (2^n,) | Boltzmann 分布 |
| `_iteration` | int | 总迭代次数 |
| `_thermal_equilibrium` | bool | 是否达到热平衡 |

### 2.2 核心算法

#### Gibbs 采样 (`gibbs_step`)

每一步执行以下流程：

```
1. 随机选择神经元 i ∈ {0, 1, ..., n-1}
2. 计算输入和：h_i = Σⱼ W_ij x_j + b_i
3. 计算激活概率：P(x_i = 1) = sigmoid(2h_i / T)
   其中 sigmoid(z) = 1 / (1 + exp(-z))
4. 按伯努利分布采样新状态：x_i ~ Bernoulli(P(x_i = 1))
5. 更新能量、统计信息、迭代计数
```

**数值稳定性处理：**
- 输入和被 clip 到 [-500, 500] 以避免 exp() 溢出
- 概率被 clip 到 [0, 1]

**关键代码：**
```python
scaled_input = np.clip(2.0 * input_sum / self._temperature, -500, 500)
prob = 1.0 / (1.0 + np.exp(-scaled_input))
prob = np.clip(prob, 0.0, 1.0)
self._state[neuron_idx] = 1 if np.random.random() < prob else 0
```

#### 能量函数

$$E(x) = -\frac{1}{2} \sum_{i,j} W_{ij} x_i x_j - \sum_i b_i x_i$$

**性质：**
- 网络自动收敛到**低能量状态**（稳定吸引子）
- 更新规则保证能量单调不增（在足够低温下）

**实现：**
```python
energy = -0.5 * np.dot(state, np.dot(self._weights, state))
energy -= np.dot(self._biases, state)
```

#### Boltzmann 分布

在热平衡状态，状态 s 的概率为：

$$P(s) = \frac{e^{-E(s)/T}}{Z}$$

其中 $Z = \sum_s e^{-E(s)/T}$ 是分配函数（配分函数）。

**数值稳定性：** 对所有能量减去最小能量，避免数值溢出：

```python
min_energy = np.min(energies)
exp_energies = np.exp(-(energies - min_energy) / self._temperature)
partition_function = np.sum(exp_energies)
probabilities = exp_energies / partition_function
```

#### 热平衡检测

**策略：** 比较最近 50 步的状态访问分布与理论 Boltzmann 分布的 KL 散度。

$$KL(P_{recent} || P_{Boltzmann}) = \sum_s P_{recent}(s) \log \frac{P_{recent}(s)}{P_{Boltzmann}(s)}$$

**判断标准：**
- KL 散度 < 0.1 → 认为达到热平衡
- KL 散度 > 0.2 → 认为离开热平衡

**数值处理：**
```python
with np.errstate(divide='ignore', invalid='ignore'):
    kl_div = np.sum(
        np.where(
            (recent_dist > epsilon) & (theoretical_dist > epsilon),
            recent_dist * np.log((recent_dist + epsilon) / (theoretical_dist + epsilon)),
            0
        )
    )
if np.isnan(kl_div):
    kl_div = float('inf')
```

#### 模拟退火 (`anneal`)

从高温逐步冷却到低温，使系统逃脱局部最小值并收敛到全局最优。

**步骤：**

```
初始温度 T = T_init
while T > T_final:
    for _ in range(steps_per_temp):
        执行 Gibbs 采样步
    冷却：T = T / (1 + cooling_rate)
```

**参数建议：**
- `initial_temp=3.0` - 允许充分探索
- `final_temp=0.01` - 接近确定性
- `cooling_rate=0.05` - 缓慢冷却
- `steps_per_temp=5-10` - 每温度充分采样

### 2.3 数据访问接口

所有 getter 方法返回数据副本以保证封装：

| 方法 | 返回类型 | 说明 |
|------|---------|------|
| `get_state_vector()` | List[int] | 当前状态 [0/1, 0/1, 0/1] |
| `get_current_energy()` | float | 当前能量 |
| `get_temperature()` | float | 当前温度 |
| `get_probabilities()` | List[float] | Boltzmann 分布概率 |
| `get_state_index()` | int | 状态索引 0-7 |
| `get_visit_counts()` | List[int] | 每个状态被访问次数 |
| `get_energy_landscape()` | dict | 所有状态的能量与概率 |
| `get_thermal_equilibrium_status()` | bool | 热平衡状态 |

---

## 3. Qt 桥梁层 (`bm_bridge.py`)

### 3.1 目的

在后端算法和 QML 前端之间提供**双向通信**：
- **前端→后端**：通过 PyQt Slots 接收用户输入
- **后端→前端**：通过 Qt Properties 和 Signals 更新 UI

### 3.2 类：`BoltzmannBridge` (继承 Bridge)

**Qt 属性** (自动触发信号当值改变)：

```python
temperature = BridgeProperty(1.0)
energy = BridgeProperty(0.0)
current_state = BridgeProperty([])
current_state_id = BridgeProperty(0)
iteration = BridgeProperty(0)
thermal_equilibrium = BridgeProperty(False)
probabilities = BridgeProperty([])
visit_counts = BridgeProperty([])
state_history = BridgeProperty([])
energy_history = BridgeProperty([])
temperature_history = BridgeProperty([])
visited_state_count = BridgeProperty(0)
total_visits = BridgeProperty(0)
weights_matrix = BridgeProperty([])
biases_vector = BridgeProperty([])
energy_landscape = BridgeProperty({})
```

**使用 BridgeProperty 的好处：**
- 自动生成 Qt 信号（`onPropertyNameChanged`）
- QML 可直接绑定属性
- 更改自动触发 QML 更新

### 3.3 状态同步机制

关键方法：`_sync_state_from_backend()`

```python
def _sync_state_from_backend(self):
    """同步后端所有状态到 Qt 属性"""
    self.temperature = self._algorithm.get_temperature()
    self.energy = self._algorithm.get_current_energy()
    self.current_state = self._algorithm.get_state_vector()
    # ... 同步所有其他属性
```

**调用时机：**
- 初始化后 (`__init__`)
- 每个用户操作后 (step, anneal, set_temperature 等)

**模式：后端更改 → 同步属性 → QML 自动更新**

### 3.4 PyQt Slots (可从 QML 调用)

| Slot | 参数 | 说明 |
|------|------|------|
| `step()` | - | 执行一步 Gibbs 采样 |
| `anneal(T_init, T_final, cool_rate, steps)` | float × 3, int | 温度退火 |
| `set_temperature(T)` | float | 设置温度 |
| `randomize_state()` | - | 随机初始化状态 |
| `randomize_weights()` | - | 随机初始化权重 |
| `set_custom_weights(w, b)` | List[List[float]], List[float] | 设置自定义权重 |
| `reset()` | - | 重置到初始状态 |

**示例 - 从 QML 调用：**
```javascript
Button {
    onClicked: boltzmannBridge.step()
}
Slider {
    onMoved: boltzmannBridge.set_temperature(value)
}
```

---

## 4. 前端界面层 (`BoltzmannMachine.qml`)

### 4.1 结构

```
Page (name: 'BoltzmannMachine')
└── Flickable
    └── ColumnLayout (主布局)
        ├── GroupBox (温度控制)
        ├── GroupBox (三神经元网络可视化) ← Canvas 绘图
        ├── GroupBox (状态空间热力图)
        ├── GroupBox (控制按钮)
        ├── GroupBox (能量分布图) ← Canvas 绘图
        └── GroupBox (统计信息)
```

### 4.2 关键 QML 元素

#### Canvas 绘图 - 网络可视化

```javascript
Canvas {
    id: neuronCanvas
    anchors.fill: parent
    
    onPaint: {
        var ctx = getContext('2d')
        
        // 三个神经元位置（等边三角形）
        var positions = [
            {x: w/2, y: 30},           // 顶部
            {x: 40, y: h - 30},        // 左下
            {x: w - 40, y: h - 30}     // 右下
        ]
        
        // 绘制连接（权重）
        for (var i = 0; i < 3; i++) {
            for (var j = i + 1; j < 3; j++) {
                var w_ij = weights[i][j]
                // 线宽 = 权重强度，颜色 = 权重符号
            }
        }
        
        // 绘制神经元圆
        for (var i = 0; i < 3; i++) {
            var color = state[i] === 1 ? '#0066FF' : '#CCCCCC'
            // 绘制圆形，标记为 x1, x2, x3
        }
    }
    
    Connections {
        target: boltzmannBridge
        function onCurrent_stateChanged() {
            neuronCanvas.requestPaint()  // 状态改变时重绘
        }
        function onWeights_matrixChanged() {
            neuronCanvas.requestPaint()  // 权重改变时重绘
        }
    }
}
```

#### Canvas 绘图 - 能量分布

```javascript
Canvas {
    id: energyCanvas
    
    onPaint: {
        var landscape = boltzmannBridge.energy_landscape
        var energies = landscape.energies  // 8 个值
        var probs = landscape.probabilities  // 8 个值
        
        // 对每个状态绘制两个柱子
        for (var i = 0; i < 8; i++) {
            // 蓝色柱：能量值
            ctx.fillStyle = '#0066FF'
            ctx.fillRect(x, y, width, energyHeight)
            
            // 橙色柱：概率值
            ctx.fillStyle = '#FF9900'
            ctx.fillRect(x + width/2, y, width/2, probHeight)
        }
    }
}
```

### 4.3 数据绑定

**单向绑定（后端→前端）：**

```javascript
Text {
    text: boltzmannBridge.temperature.toFixed(2)
    // 自动更新当 temperature property 改变
}

Text {
    text: boltzmannBridge.current_state[0]  // 数组访问
}
```

**双向交互（前端→后端）：**

```javascript
Slider {
    onMoved: boltzmannBridge.set_temperature(value)
    // 用户拖动 → 调用后端 slot → 后端更改算法 → 同步属性 → UI 更新
}
```

### 4.4 布局注意事项

**正确做法**（参考 Hopfield.qml）：

```javascript
Flickable {
    anchors.fill: parent
    contentHeight: columnLayout.implicitHeight
    
    ColumnLayout {
        width: parent.width
        spacing: 15
        
        GroupBox {
            Layout.fillWidth: true
            Layout.preferredHeight: 200
            
            ColumnLayout {
                anchors.fill: parent      // ✓ 在 GroupBox 内填充
                anchors.margins: 5        // ✓ 添加边距
                width: parent.width
                spacing: 8
                
                Rectangle {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    // ...
                }
            }
        }
    }
}
```

**常见错误：**
- ❌ ColumnLayout 同时设置 `anchors` 和布局属性
- ❌ Flickable 中的 ColumnLayout 使用 `x/y` 定位
- ❌ GroupBox 内 ColumnLayout 无 `anchors.fill`

---

## 5. 数据流

### 5.1 初始化流程

```
App启动
  ↓
main.py: BoltzmannBridge() 创建实例
  ↓
BoltzmannBridge.__init__()
  ├─ 创建 BoltzmannMachine 后端
  ├─ 调用 _sync_state_from_backend()
  └─ 所有 Qt 属性初始化
  ↓
main.qml: 注册 boltzmannBridge 到 rootContext
  ↓
BoltzmannMachine.qml: 绑定到 boltzmannBridge 属性
  ↓
UI 显示初始状态（随机权重、随机状态）
```

### 5.2 用户点击 "Single Step" 按钮

```
QML 按钮点击事件
  ↓
onClicked: boltzmannBridge.step()
  ↓
BoltzmannBridge.step()
  ├─ 调用 self._algorithm.gibbs_step()
  │   ├─ 随机选择神经元
  │   ├─ 计算 Boltzmann 概率
  │   ├─ 采样新状态
  │   └─ 更新能量、统计
  │
  └─ 调用 self._sync_state_from_backend()
     ├─ self.current_state = [新状态]
     ├─ self.iteration += 1
     ├─ self.energy = [新能量]
     └─ ... 所有属性
  ↓
Qt 信号 onCurrent_stateChanged() 触发
  ↓
QML Connections 接收信号
  ├─ neuronCanvas.requestPaint()
  ├─ energyCanvas.requestPaint()
  └─ 所有绑定的 Text 元素自动更新
  ↓
Canvas onPaint 事件
  ├─ 重新绘制网络图（状态→颜色）
  └─ 重新绘制能量图
  ↓
UI 显示更新
```

### 5.3 用户移动温度滑块

```
QML Slider 移动
  ↓
onMoved: boltzmannBridge.set_temperature(value)
  ↓
BoltzmannBridge.set_temperature(T)
  ├─ self._algorithm.set_temperature(T)
  │   ├─ self._temperature = T
  │   └─ self._update_all_probabilities()  // 重新计算 Boltzmann 分布
  │
  └─ self._sync_state_from_backend()
     ├─ self.temperature = T
     └─ self.probabilities = [新概率]
  ↓
Qt 信号 onTemperatureChanged() 和 onProbabilitiesChanged() 触发
  ↓
QML 元素自动更新
  ├─ Text 显示新温度
  ├─ State Space 热力图重新着色（颜色 ∝ 概率）
  └─ Energy Distribution 重新绘制
```

---

## 6. 关键设计决策

| 决策 | 理由 |
|------|------|
| **3 神经元** | 足以展示所有概念，易于可视化（8 个可能状态）|
| **Gibbs 采样** | 简单、收敛性有保证、符合 Boltzmann 分布 |
| **温度控制** | 直观展示探索-利用权衡，易于交互 |
| **拉动同步** | Bridge 主动从后端拉取状态，避免耦合 |
| **Canvas 绘图** | 灵活、高效，支持复杂可视化 |
| **BridgeProperty** | 自动信号生成，减少样板代码 |

---

## 7. 性能考虑

### 时间复杂度

| 操作 | 复杂度 | 说明 |
|------|--------|------|
| 单步 Gibbs | O(n²) | 矩阵向量乘积 |
| 概率更新 | O(2ⁿ) | 遍历所有可能状态 |
| 退火 N 步 | O(N·n²) | N = 温度数量 × 每温度步数 |
| 热平衡检测 | O(2ⁿ) | KL 散度计算 |

**对于 n=3：** 所有操作毫秒级完成，实时响应

### 空间复杂度

| 数据结构 | 大小 | 说明 |
|---------|------|------|
| 权重矩阵 | O(n²) | 3×3 = 9 个浮数 |
| 概率数组 | O(2ⁿ) | 8 个浮数 |
| 历史记录 | O(迭代数) | 根据使用情况增长 |

**对于 n=3：** 内存使用极小，可安全累积数百万次迭代

---

## 8. 扩展性

### 增加神经元数量

要将其改为 n > 3 神经元：

```python
# 修改 main.py
boltzmannBridge = BoltzmannBridge(num_neurons=5)

# 修改 BoltzmannMachine.qml
// State Space Grid: 改为 32 个方块 (2^5)
Grid {
    columns: 8  // 改为合适的列数
    Repeater {
        model: 32  // 从 8 改为 2^n
```

**注意：**
- 概率计算从 O(8) 变成 O(2ⁿ)
- Canvas 绘图需要扩展到任意数量神经元
- State Space 热力图需要重新设计（可能用滚动或分页）

---

## 9. 故障排除

### 常见问题

**Q: Canvas 显示空白**  
A: 检查 GroupBox 内 ColumnLayout 是否有 `anchors.fill: parent`

**Q: 温度改变后概率不更新**  
A: 确认 Bridge 中 `set_temperature()` 调用了 `_sync_state_from_backend()`

**Q: 热平衡一直是 NO**  
A: 增加采样步数或降低温度；热平衡检测需要充分采样

**Q: 状态总是不变**  
A: 温度太低（T < 0.1）导致转移概率接近 0；提高温度

---

## 10. 测试

### 单元测试点

```python
def test_energy_calculation():
    bm = BoltzmannMachine(num_neurons=3)
    state = np.array([1, 0, 1])
    energy = bm._calculate_energy(state)
    # 验证公式: E = -0.5*x·W·x - b·x
    assert isinstance(energy, float)

def test_gibbs_step():
    bm = BoltzmannMachine(num_neurons=3)
    for _ in range(1000):
        bm.gibbs_step()
    # 验证：最终状态应该在概率高的地方
    dist = bm._visit_count / np.sum(bm._visit_count)
    assert np.allclose(dist, bm._probabilities, atol=0.1)

def test_thermal_equilibrium():
    bm = BoltzmannMachine(num_neurons=3)
    for _ in range(100):
        bm.gibbs_step()
    status = bm.get_thermal_equilibrium_status()
    # 验证：足够步数后应该达到热平衡
    assert isinstance(status, bool)
```

---

## 总结

Boltzmann Machine 实现通过**清晰的分层架构**和**数值稳定的算法**，提供了对概率性神经网络的直观理解。交互式可视化使用户能够：

✓ 观察温度如何影响状态转移  
✓ 理解 Boltzmann 分布的物理意义  
✓ 体验从高温探索到低温收敛的过程  
✓ 实时监控网络的热平衡状态  

这对于学习和教学**统计物理**、**机器学习基础**和**神经网络原理**非常有价值。
