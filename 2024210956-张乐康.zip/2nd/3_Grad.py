import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import torch
import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

class DynamicOptimizationVisualizer:
    def __init__(self):
        #  F(x) = x₁² + 2x₂²
        self.A = torch.tensor([[2.0, 0.0], [0.0, 4.0]], dtype=torch.float32)
        self.b = torch.tensor([0.0, 0.0], dtype=torch.float32)
        self.x_min = torch.tensor([0.0, 0.0], dtype=torch.float32)

    def quadratic_function(self, x):
        return 0.5 * x @ self.A @ x + self.b @ x

    def gradient(self, x):
        return self.A @ x + self.b

    def hessian(self, x):
        return self.A

    def create_contour_data(self, x_range=(-3, 3), y_range=(-3, 3), n_points=100):
        x1 = np.linspace(x_range[0], x_range[1], n_points)
        x2 = np.linspace(y_range[0], y_range[1], n_points)
        X1, X2 = np.meshgrid(x1, x2)

        Z = np.zeros_like(X1)
        for i in range(X1.shape[0]):
            for j in range(X1.shape[1]):
                x = torch.tensor([X1[i, j], X2[i, j]], dtype=torch.float32)
                Z[i, j] = self.quadratic_function(x)

        return X1, X2, Z

    def steepest_descent_dynamic(self, x0, alpha=0.01, max_iter=100):
        x = x0.clone()
        trajectory = [x.clone()]

        for i in range(max_iter):
            g = self.gradient(x)
            x_new = x - alpha * g
            trajectory.append(x_new.clone())
            x = x_new
            if torch.norm(g) < 1e-6:
                break
        return torch.stack(trajectory)

    def steepest_descent_line_search(self, x0, max_iter=100):
        x = x0.clone()
        trajectory = [x.clone()]

        for i in range(max_iter):
            g = self.gradient(x)
            p = -g
            alpha = - (g @ p) / (p @ self.A @ p)
            x_new = x + alpha * p
            trajectory.append(x_new.clone())
            x = x_new
            if torch.norm(g) < 1e-6:
                break
        return torch.stack(trajectory)

    def newton_method_dynamic(self, x0, max_iter=10):
        x = x0.clone()
        trajectory = [x.clone()]

        for i in range(max_iter):
            g = self.gradient(x)
            H = self.hessian(x)
            delta_x = -torch.inverse(H) @ g
            x_new = x + delta_x
            trajectory.append(x_new.clone())
            x = x_new
            if torch.norm(g) < 1e-6:
                break
        return torch.stack(trajectory)

    def conjugate_gradient_dynamic(self, x0, max_iter=10):
        x = x0.clone()
        trajectory = [x.clone()]

        g = self.gradient(x)
        p = -g

        for i in range(max_iter):
            alpha = - (g @ p) / (p @ self.A @ p)
            x_new = x + alpha * p
            g_new = self.gradient(x_new)
            beta = (g_new @ g_new) / (g @ g)
            p_new = -g_new + beta * p

            trajectory.append(x_new.clone())
            x = x_new
            g = g_new
            p = p_new
            if torch.norm(g) < 1e-6:
                break
        return torch.stack(trajectory)


def create_comprehensive_visualization(x0=torch.tensor([2.0, 2.0])):
    viz = DynamicOptimizationVisualizer()
    trajectories = {
        'Steepest Descent (α=0.01)': viz.steepest_descent_dynamic(x0),
        'Steepest Descent (Line Search)': viz.steepest_descent_line_search(x0),
        'Newton\'s Method': viz.newton_method_dynamic(x0),
        'Conjugate Gradient': viz.conjugate_gradient_dynamic(x0)
    }

    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    axes = axes.flatten()

    X1, X2, Z = viz.create_contour_data()

    methods_list = list(trajectories.items())
    for idx in range(4):
        ax = axes[idx]
        method, traj = methods_list[idx]
        traj_np = traj.detach().numpy()

        # Contour plot
        contour = ax.contour(X1, X2, Z, levels=15, colors='gray', alpha=0.6)

        # Trajectory with red current point and blue other points
        ax.plot(traj_np[:, 0], traj_np[:, 1], 'b-', linewidth=2, alpha=0.7)  # Blue line
        ax.plot(traj_np[:, 0], traj_np[:, 1], 'bo', markersize=4, alpha=0.6)  # Blue points

        # Start and end points
        ax.plot(x0[0], x0[1], 'go', markersize=8, label='Start')
        ax.plot(0, 0, 'r*', markersize=12, label='Optimum')

        ax.set_xlabel('x₁')
        ax.set_ylabel('x₂')
        ax.set_title(f'{method}\n(Iterations: {len(traj)})')
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal')

    ax = axes[4]
    for method, traj in trajectories.items():
        function_values = []
        for point in traj:
            function_values.append(viz.quadratic_function(point).item())
        ax.semilogy(range(len(function_values)), function_values,
                    'o-', linewidth=2, markersize=4, label=method)

    ax.set_xlabel('Iteration')
    ax.set_ylabel('Function Value (log scale)')
    ax.set_title('Convergence Comparison')
    ax.legend()
    ax.grid(True, alpha=0.3)

    ax = axes[5]
    for method, traj in trajectories.items():
        gradient_norms = []
        for point in traj:
            grad = viz.gradient(point)
            gradient_norms.append(torch.norm(grad).item())
        ax.semilogy(range(len(gradient_norms)), gradient_norms,
                    'o-', linewidth=2, markersize=4, label=method)

    ax.set_xlabel('Iteration')
    ax.set_ylabel('Gradient Norm (log scale)')
    ax.set_title('Gradient Norm Convergence')
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.show()

    return trajectories


def create_animation_with_blue_points(x0=torch.tensor([2.0, 2.0])):
    viz = DynamicOptimizationVisualizer()
    trajectories = {
        'Steepest Descent (α=0.01)': viz.steepest_descent_dynamic(x0),
        'Steepest Descent (Line Search)': viz.steepest_descent_line_search(x0),
        'Newton\'s Method': viz.newton_method_dynamic(x0),
        'Conjugate Gradient': viz.conjugate_gradient_dynamic(x0)
    }

    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    axes = axes.flatten()

    X1, X2, Z = viz.create_contour_data()

    for i, (method, traj) in enumerate(trajectories.items()):
        ax = axes[i]
        contour = ax.contour(X1, X2, Z, levels=15, colors='gray', alpha=0.6)
        ax.set_xlabel('x₁')
        ax.set_ylabel('x₂')
        ax.set_title(method)
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal')

    def update(frame):
        for i, (method, traj) in enumerate(trajectories.items()):
            ax = axes[i]
            for artist in ax.lines + ax.collections:
                if artist not in ax.containers:  # Keep contour lines
                    artist.remove()

            current_frame = min(frame, len(traj) - 1)
            traj_np = traj[:current_frame + 1].detach().numpy()

            if len(traj_np) > 1:
                ax.plot(traj_np[:, 0], traj_np[:, 1], 'b-', linewidth=2, alpha=0.8)
                ax.plot(traj_np[:, 0], traj_np[:, 1], 'bo', markersize=5, alpha=0.7)

            current_point = traj_np[-1]
            ax.plot(current_point[0], current_point[1], 'ro', markersize=8)

            ax.plot(x0[0], x0[1], 'go', markersize=8)
            ax.plot(0, 0, 'r*', markersize=12)

            current_val = viz.quadratic_function(torch.tensor(current_point)).item()
            ax.text(0.05, 0.95, f'Iter: {current_frame}\nValue: {current_val:.4f}',
                    transform=ax.transAxes, fontsize=9,
                    bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))

        return []

    max_frames = max(len(traj) for traj in trajectories.values())
    anim = animation.FuncAnimation(fig, update, frames=range(max_frames),
                                   interval=500, blit=False, repeat=True)

    plt.tight_layout()
    return anim


def main():
    viz = DynamicOptimizationVisualizer()
    x0 = torch.tensor([2.0, 2.0])

    eigenvalues, eigenvectors = torch.linalg.eig(viz.A)
    lambda_max = torch.max(eigenvalues.real).item()
    lambda_min = torch.min(eigenvalues.real).item()

    print(f"• Hessian matrix eigenvalues: {eigenvalues.real.numpy()}")
    print(f"• Maximum stable learning rate: {2 / lambda_max:.4f}")
    print(f"• Condition number: {lambda_max / lambda_min:.2f}")

    trajectories = create_comprehensive_visualization(x0)

    for method, traj in trajectories.items():
        final_value = viz.quadratic_function(traj[-1]).item()
        iterations = len(traj)
        print(f"• {method}: {iterations} iterations, final value: {final_value:.6f}")

    return trajectories


if __name__ == "__main__":
    results = main()

    try:
        anim = create_animation_with_blue_points()
        plt.show()
    except Exception as e:
        print(f"Animation generation skipped: {e}")