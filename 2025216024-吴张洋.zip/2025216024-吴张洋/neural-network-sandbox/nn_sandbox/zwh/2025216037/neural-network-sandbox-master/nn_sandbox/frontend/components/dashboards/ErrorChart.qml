import QtQuick 2.12
import QtCharts 2.3

ChartView {
    id: chart
    title: "Training & Testing Error"
    antialiasing: true
    legend.alignment: Qt.AlignBottom

    property alias trainingError: trainingErrorSeries
    property alias testingError: testingErrorSeries

    ValueAxis {
        id: axisX
        titleText: "Iterations"
        min: 0
        max: 100
    }

    ValueAxis {
        id: axisY
        titleText: "Error (MSE)"
        min: 0
        max: 1.0
    }

    LineSeries {
        id: trainingErrorSeries
        name: "Training Error"
        axisX: axisX
        axisY: axisY
        color: "#3498db"
        width: 2
    }

    LineSeries {
        id: testingErrorSeries
        name: "Testing Error"
        axisX: axisX
        axisY: axisY
        color: "#e74c3c"
        width: 2
    }

    function reset() {
        trainingErrorSeries.removePoints(0, trainingErrorSeries.count)
        testingErrorSeries.removePoints(0, testingErrorSeries.count)
        axisX.min = 0
        axisX.max = 100
        axisY.min = 0
        axisY.max = 1.0
    }

    Connections {
        target: trainingErrorSeries
        function onPointAdded(index) {
            updateAxes()
        }
    }

    Connections {
        target: testingErrorSeries
        function onPointAdded(index) {
            updateAxes()
        }
    }

    function updateAxes() {
        // Update X axis
        var maxX = Math.max(
            trainingErrorSeries.count > 0 ? trainingErrorSeries.at(trainingErrorSeries.count - 1).x : 0,
            testingErrorSeries.count > 0 ? testingErrorSeries.at(testingErrorSeries.count - 1).x : 0
        )
        if (maxX > axisX.max) {
            axisX.max = maxX
        }

        // Update Y axis
        var maxY = 0
        for (var i = 0; i < trainingErrorSeries.count; i++) {
            maxY = Math.max(maxY, trainingErrorSeries.at(i).y)
        }
        for (var j = 0; j < testingErrorSeries.count; j++) {
            maxY = Math.max(maxY, testingErrorSeries.at(j).y)
        }
        if (maxY > axisY.max) {
            axisY.max = maxY * 1.1
        }
    }
}
