import numpy as np
import matplotlib.pyplot as plt
import itertools
from typing import List, Tuple, Dict
import warnings

warnings.filterwarnings("ignore")

# 设置全局字体为 SimHei（黑体）
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


class DiscreteHopfieldNetwork:

    def __init__(self, n_neurons: int):

        self.n_neurons = n_neurons
        self.weights = np.zeros((n_neurons, n_neurons))
        self.state = np.random.choice([-1, 1], size=n_neurons)

    def train(self, patterns: List[np.ndarray]) -> None:

        self.weights = np.zeros((self.n_neurons, self.n_neurons))

        for pattern in patterns:
            # 使用外积规则，但不对角线元素置零
            self.weights += np.outer(pattern, pattern)

        # 对角线元素置零（神经元不与自身连接）
        np.fill_diagonal(self.weights, 0)

        # 归一化权重
        self.weights = self.weights / len(patterns)

    def asynchronous_update(self, initial_state: np.ndarray = None, max_iter: int = 100) -> np.ndarray:

        if initial_state is not None:
            self.state = initial_state.copy()

        previous_state = self.state.copy()

        for _ in range(max_iter):
            # 随机选择更新顺序
            update_order = np.random.permutation(self.n_neurons)

            # 异步更新
            for i in update_order:
                # 计算净输入
                net_input = np.dot(self.weights[i], self.state)

                # 更新神经元状态
                if net_input > 0:
                    self.state[i] = 1
                elif net_input < 0:
                    self.state[i] = -1
                # 如果net_input == 0，保持状态不变

            # 检查是否收敛
            if np.array_equal(self.state, previous_state):
                break

            previous_state = self.state.copy()

        return self.state

    def energy(self, state: np.ndarray = None) -> float:

        if state is None:
            state = self.state

        energy = 0
        for i in range(self.n_neurons):
            for j in range(self.n_neurons):
                if i != j:
                    energy -= self.weights[i, j] * state[i] * state[j]

        return energy / 2  # 除以2因为每对(i,j)被计算了两次

    def find_attractors(self, patterns: List[np.ndarray] = None, max_tests: int = 1000) -> Dict[Tuple, float]:

        attractors = {}

        # 首先检查已知模式是否为吸引子
        if patterns is not None:
            for pattern in patterns:
                pattern_tuple = tuple(pattern)
                # 从该模式开始更新，看是否收敛到自身
                final_state = self.asynchronous_update(pattern.copy())
                final_tuple = tuple(final_state)

                if np.array_equal(pattern, final_state):
                    energy = self.energy(pattern)
                    attractors[pattern_tuple] = energy

        # 随机生成初始状态进行测试
        tested_states = set()

        for _ in range(max_tests):
            # 生成随机初始状态
            initial_state = np.random.choice([-1, 1], size=self.n_neurons)
            initial_tuple = tuple(initial_state)

            # 如果已经测试过，跳过
            if initial_tuple in tested_states:
                continue

            tested_states.add(initial_tuple)

            # 异步更新
            final_state = self.asynchronous_update(initial_state.copy())
            final_tuple = tuple(final_state)

            # 如果收敛到一个新状态，记录为吸引子
            if final_tuple not in attractors:
                # 验证是否为稳定状态
                test_state = self.asynchronous_update(final_state.copy())
                if np.array_equal(final_state, test_state):
                    energy = self.energy(final_state)
                    attractors[final_tuple] = energy

        return attractors

    def recall(self, pattern: np.ndarray, noise_level: float = 0.3) -> Tuple[np.ndarray, float, float]:

        # 添加噪声
        noisy_pattern = pattern.copy()
        flip_indices = np.random.random(self.n_neurons) < noise_level
        noisy_pattern[flip_indices] *= -1

        # 计算初始能量
        initial_energy = self.energy(noisy_pattern)

        # 异步更新
        recalled_pattern = self.asynchronous_update(noisy_pattern.copy())

        # 计算最终能量
        final_energy = self.energy(recalled_pattern)

        return recalled_pattern, initial_energy, final_energy


def visualize_patterns(patterns: List[np.ndarray], title: str = "Patterns") -> None:
    """
    可视化模式（假设模式可以排列为正方形）
    """
    n_patterns = len(patterns)
    n_neurons = len(patterns[0])
    side_length = int(np.sqrt(n_neurons))

    fig, axes = plt.subplots(1, n_patterns, figsize=(3 * n_patterns, 3))

    if n_patterns == 1:
        axes = [axes]

    for i, (pattern, ax) in enumerate(zip(patterns, axes)):
        ax.imshow(pattern.reshape(side_length, side_length), cmap='binary')
        ax.set_title(f'Pattern {i + 1}')
        ax.axis('off')

    plt.suptitle(title)
    plt.tight_layout()
    plt.show()


def energy_landscape_analysis(network: DiscreteHopfieldNetwork, patterns: List[np.ndarray]) -> None:
    """
    分析能量景观
    """
    print("=== 能量景观分析 ===")

    # 计算所有存储模式的能量
    for i, pattern in enumerate(patterns):
        energy = network.energy(pattern)
        print(f"模式 {i + 1} 能量: {energy:.4f}")

    # 寻找吸引子
    attractors = network.find_attractors(patterns, max_tests=500)
    print(f"\n发现的吸引子数量: {len(attractors)}")

    # 打印吸引子及其能量
    for i, (attractor, energy) in enumerate(attractors.items()):
        print(f"吸引子 {i + 1}: 能量 = {energy:.4f}")

    print("\n=== 回忆测试 ===")
    # 测试回忆能力
    for i, pattern in enumerate(patterns):
        recalled, init_energy, final_energy = network.recall(pattern, noise_level=0.2)
        accuracy = np.mean(recalled == pattern)
        print(f"模式 {i + 1}: 初始能量={init_energy:.4f}, 最终能量={final_energy:.4f}, 准确率={accuracy:.2%}")


# 示例使用
if __name__ == "__main__":
    # 创建一些简单的模式（例如字母）
    # 假设是5x5的网格，所以有25个神经元
    n_neurons = 25

    # 定义几个简单模式
    pattern1 = np.array([
        -1, -1, 1, -1, -1,
        -1, 1, -1, 1, -1,
        -1, 1, 1, 1, -1,
        -1, 1, -1, 1, -1,
        -1, 1, -1, 1, -1
    ])

    pattern2 = np.array([
        -1, 1, 1, 1, -1,
        -1, 1, -1, -1, -1,
        -1, 1, 1, 1, -1,
        -1, 1, -1, -1, -1,
        -1, 1, 1, 1, -1
    ])

    pattern3 = np.array([
        -1, 1, 1, 1, -1,
        -1, -1, 1, -1, -1,
        -1, -1, 1, -1, -1,
        -1, -1, 1, -1, -1,
        -1, 1, 1, 1, -1
    ])

    patterns = [pattern1, pattern2, pattern3]

    # 可视化原始模式
    visualize_patterns(patterns, "存储的模式")

    # 创建并训练Hopfield网络
    network = DiscreteHopfieldNetwork(n_neurons)
    network.train(patterns)

    # 分析能量景观
    energy_landscape_analysis(network, patterns)

    # 演示异步更新过程
    print("\n=== 异步更新演示 ===")
    test_pattern = patterns[0].copy()
    # 添加更多噪声
    noisy_pattern = test_pattern.copy()
    flip_indices = np.random.choice(n_neurons, size=8, replace=False)
    noisy_pattern[flip_indices] *= -1

    print("原始模式:")
    print(test_pattern.reshape(5, 5))
    print("\n添加噪声后的模式:")
    print(noisy_pattern.reshape(5, 5))

    # 异步更新恢复
    recalled = network.asynchronous_update(noisy_pattern.copy())
    print("\n回忆后的模式:")
    print(recalled.reshape(5, 5))

    accuracy = np.mean(recalled == test_pattern)
    print(f"\n回忆准确率: {accuracy:.2%}")

    # 可视化回忆过程
    visualize_patterns([test_pattern, noisy_pattern, recalled],
                       "原始模式 -> 噪声模式 -> 回忆模式")