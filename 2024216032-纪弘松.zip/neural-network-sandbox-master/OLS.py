import sys
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton,
    QLabel, QLineEdit, QHBoxLayout, QGroupBox, QSpacerItem, QSizePolicy
)
from PyQt5.QtCore import QTimer, Qt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# 确保 Matplotlib 后端正确设置为 Qt5Agg
matplotlib.use('Qt5Agg')


# --- 1. OLS 梯度下降算法实现 ---
class OLSGradientDescent:
    def __init__(self, X, y, learning_rate=0.01):
        # 增加一列偏置项（b），修复一维数组处理逻辑
        if X.ndim == 1:
            # 对于一维数组，先转换为二维数组再插入偏置项







            self.X = np.insert(X.reshape(-1, 1), 0, 1, axis=1)
        else:
            self.X = np.insert(X, 0, 1, axis=1)

        self.y = y.reshape(-1, 1) if y.ndim == 1 else y
        self.lr = learning_rate
        # 初始化权重 (w0, w1)
        self.weights = np.zeros((self.X.shape[1], 1))
        self.loss_history = []
        self.iteration = 0

    def calculate_loss(self):
        # 均方误差 (Mean Squared Error) 损失
        m = len(self.y)
        predictions = self.X.dot(self.weights)
        error = predictions - self.y
        J = (1 / (2 * m)) * np.sum(error ** 2)
        return J

    def step(self):
        """执行一次梯度下降迭代"""
        m = len(self.y)
        predictions = self.X.dot(self.weights)
        error = predictions - self.y
        # 计算梯度
        gradient = (1 / m) * self.X.T.dot(error)
        # 更新权重
        self.weights = self.weights - self.lr * gradient
        # 记录损失
        loss = self.calculate_loss()
        self.loss_history.append(loss)
        self.iteration += 1
        return self.weights[0, 0], self.weights[1, 0], loss


# --- 2. Matplotlib 画布组件 ---
class MplCanvas(FigureCanvas):
    """一个 Matplotlib 图表组件，用于嵌入到 PyQt 窗口中"""

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super().__init__(self.fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

        self.ax_fit = self.fig.add_subplot(121)  # 拟合图
        self.ax_loss = self.fig.add_subplot(122)  # 损失图
        self.fig.tight_layout(pad=3.0)  # 自动调整子图参数，使之填充整个图像区域

    def setup_plots(self, X_data, y_data):
        # 拟合图初始化
        self.ax_fit.clear()
        self.ax_fit.scatter(X_data, y_data, marker='o', s=20, label='Data')
        self.ax_fit.set_title('OLS Fitting Process')
        self.ax_fit.set_xlabel('X')
        self.ax_fit.set_ylabel('y')
        self.line_fit, = self.ax_fit.plot([], [], 'r-', label='Regression Line')
        self.ax_fit.legend()
        self.ax_fit.grid(True)

        # 损失图初始化
        self.ax_loss.clear()
        self.ax_loss.set_title('Loss History (MSE)')
        self.ax_loss.set_xlabel('Iteration')
        self.ax_loss.set_ylabel('Loss')
        self.line_loss, = self.ax_loss.plot([], [], 'b-')
        self.ax_loss.grid(True)

        self.fig.canvas.draw()

    def update_fit_plot(self, X_data, w0, w1):
        """更新拟合图中的回归直线"""
        x_min, x_max = np.min(X_data), np.max(X_data)
        x_plot = np.array([x_min - 1, x_max + 1])  # 延长拟合直线
        y_plot = w0 + w1 * x_plot
        self.line_fit.set_data(x_plot, y_plot)
        self.ax_fit.set_xlim(x_plot[0], x_plot[1])  # 确保 X 轴范围合适
        self.ax_fit.set_ylim(min(y_plot.min(), self.ax_fit.get_ylim()[0]), max(y_plot.max(), self.ax_fit.get_ylim()[1]))

    def update_loss_plot(self, loss_history):
        """更新损失图"""
        iterations = np.arange(len(loss_history))
        self.line_loss.set_data(iterations, loss_history)
        self.ax_loss.set_xlim(0, len(loss_history) + 1)
        # 避免损失为 0 导致 Y 轴范围过小
        y_max = max(1, max(loss_history)) if loss_history else 1
        self.ax_loss.set_ylim(0, y_max * 1.1)

    def redraw(self):
        self.fig.canvas.draw_idle()


# --- 3. 主窗口应用 ---
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyQt OLS Gradient Descent Visualization")
        self.setGeometry(100, 100, 1000, 700)  # 设置窗口初始大小

        # 模拟数据
        self.X_data = np.linspace(0, 10, 50)
        self.true_w0 = 1.5
        self.true_w1 = 2.0
        self.noise = np.random.normal(0, 2.0, size=self.X_data.shape)
        self.y_data = self.true_w0 + self.true_w1 * self.X_data + self.noise
        self.max_iterations = 200  # 最大迭代次数

        # OLS 实例
        self.ols_gd = None

        # 定时器用于控制迭代速度
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.run_iteration)

        # 界面布局
        self.setup_ui()
        self.initialize_ols()

    def setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # --- Matplotlib 图表部分 ---
        self.canvas = MplCanvas(self, width=7, height=6)
        main_layout.addWidget(self.canvas, 3)  # 占据更多空间

        # --- 控制面板部分 ---
        control_panel = QWidget()
        control_layout = QVBoxLayout(control_panel)
        main_layout.addWidget(control_panel, 1)  # 占据较少空间

        # 参数设置组
        param_group = QGroupBox("Parameters")
        param_layout = QVBoxLayout(param_group)

        # 学习率
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_input = QLineEdit("0.01")
        lr_layout.addWidget(self.lr_input)
        param_layout.addLayout(lr_layout)

        # 迭代间隔 (ms)
        delay_layout = QHBoxLayout()
        delay_layout.addWidget(QLabel("Interval (ms):"))
        self.delay_input = QLineEdit("100")
        delay_layout.addWidget(self.delay_input)
        param_layout.addLayout(delay_layout)

        control_layout.addWidget(param_group)

        # 控制按钮
        self.start_button = QPushButton("Start/Resume")
        self.start_button.clicked.connect(self.start_or_resume_training)

        self.pause_button = QPushButton("Pause")
        self.pause_button.clicked.connect(self.pause_training)
        self.pause_button.setEnabled(False)

        self.reset_button = QPushButton("Reset")
        self.reset_button.clicked.connect(self.initialize_ols)

        control_layout.addWidget(self.start_button)
        control_layout.addWidget(self.pause_button)
        control_layout.addWidget(self.reset_button)

        # 结果显示
        result_group = QGroupBox("Current Status")
        result_layout = QVBoxLayout(result_group)

        self.iter_label = QLabel("Iteration: 0")
        self.w0_label = QLabel(f"w0 (Intercept): 0.0000")
        self.w1_label = QLabel(f"w1 (Slope): 0.0000")
        self.loss_label = QLabel("Loss (MSE): 0.0000")

        result_layout.addWidget(self.iter_label)
        result_layout.addWidget(self.w0_label)
        result_layout.addWidget(self.w1_label)
        result_layout.addWidget(self.loss_label)

        control_layout.addWidget(result_group)

        # 增加伸缩空间，将组件推到顶部
        control_layout.addItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

    def initialize_ols(self):
        """初始化 OLS 算法和图表"""
        try:
            lr = float(self.lr_input.text())
        except ValueError:
            lr = 0.01
            self.lr_input.setText("0.01")

        self.ols_gd = OLSGradientDescent(self.X_data, self.y_data, lr)

        # 初始化图表
        self.canvas.setup_plots(self.X_data, self.y_data)

        # 初始权重和损失
        w0, w1 = self.ols_gd.weights[0, 0], self.ols_gd.weights[1, 0]
        loss = self.ols_gd.calculate_loss()

        self.update_ui_status(self.ols_gd.iteration, w0, w1, loss, [])

        self.timer.stop()
        self.start_button.setEnabled(True)
        self.start_button.setText("Start/Resume")
        self.pause_button.setEnabled(False)

    def start_or_resume_training(self):
        """开始或恢复训练"""
        try:
            delay_ms = int(self.delay_input.text())
        except ValueError:
            delay_ms = 100
            self.delay_input.setText("100")

        if self.ols_gd.iteration >= self.max_iterations:
            self.iter_label.setText(f"Iteration: {self.max_iterations} (Max Reached)")
            return

        self.timer.start(delay_ms)
        self.start_button.setEnabled(False)
        self.pause_button.setEnabled(True)

    def pause_training(self):
        """暂停训练"""
        self.timer.stop()
        self.start_button.setEnabled(True)
        self.pause_button.setEnabled(False)

    def run_iteration(self):
        """执行一次迭代并更新视图"""
        if self.ols_gd.iteration < self.max_iterations:
            w0, w1, loss = self.ols_gd.step()
            self.update_ui_status(self.ols_gd.iteration, w0, w1, loss, self.ols_gd.loss_history)
        else:
            self.timer.stop()
            self.start_button.setEnabled(False)
            self.pause_button.setEnabled(False)
            self.iter_label.setText(f"Iteration: {self.max_iterations} (Max Reached)")

    def update_ui_status(self, iteration, w0, w1, loss, loss_history):
        """更新 UI 元素和图表"""
        self.iter_label.setText(f"Iteration: {iteration}")
        self.w0_label.setText(f"w0 (Intercept): {w0:.4f}")
        self.w1_label.setText(f"w1 (Slope): {w1:.4f}")
        self.loss_label.setText(f"Loss (MSE): {loss:.4f}")

        # 更新图表
        self.canvas.update_fit_plot(self.X_data, w0, w1)
        self.canvas.update_loss_plot(loss_history)
        self.canvas.redraw()


# --- 4. 运行应用 ---
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())