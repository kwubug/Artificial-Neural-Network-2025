import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
class SOM:
    def __init__(self, input_dim, map_size=(5, 5)):
        self.input_dim = input_dim
        self.map_size = map_size
        self.weights = np.random.rand(map_size[0], map_size[1], input_dim)
        self.weights_history = [] 
        
    def find_bmu(self, x):
        distances = np.sqrt(np.sum((self.weights - x) ** 2, axis=2))
        bmu_idx = np.unravel_index(np.argmin(distances), self.map_size)
        return bmu_idx
    
    def gaussian_neighborhood(self, bmu_idx, radius, map_size):
        i, j = np.indices(map_size)
        dist_sq = (i - bmu_idx[0]) ** 2 + (j - bmu_idx[1]) ** 2
        return np.exp(-dist_sq / (2 * radius ** 2))
    
    def train(self, X, total_steps=10000, eta_start=0.5, eta_end_1=0.04, step_1=1000, eta_end_2=0.0, 
              radius_start=2, radius_end=0, step_radius=1000, save_interval=200):
        num_samples = X.shape[0]
        for step in range(total_steps):
            idx = np.random.randint(0, num_samples)
            x = X[idx]
            if step < step_1:
                eta = eta_start - (eta_start - eta_end_1) * step / step_1
            else:
                eta = eta_end_1 - (eta_end_1 - eta_end_2) * (step - step_1) / (total_steps - step_1)
            if step < step_radius:
                radius = radius_start - (radius_start - radius_end) * step / step_radius
            else:
                radius = 0.0 
            bmu_idx = self.find_bmu(x)
            neighborhood = self.gaussian_neighborhood(bmu_idx, radius, self.map_size)
            
            for i in range(self.map_size[0]):
                for j in range(self.map_size[1]):
                    self.weights[i, j] += eta * neighborhood[i, j] * (x - self.weights[i, j])
            
            if step % save_interval == 0:
                self.weights_history.append(self.weights.copy())
        
        return self.weights_history
    
    def map_inputs(self, X):
        mappings = []
        for x in X:
            bmu_idx = self.find_bmu(x)
            mappings.append(bmu_idx)
        return mappings
X = np.array([
    [1, 0, 0, 0],  
    [1, 1, 0, 0],  
    [1, 1, 1, 0], 
    [0, 1, 0, 0], 
    [1, 1, 1, 1]  
])

som = SOM(input_dim=4, map_size=(5, 5))

weights_history = som.train(
    X, 
    total_steps=10000, 
    eta_start=0.5, eta_end_1=0.04, step_1=1000, 
    radius_start=2, radius_end=0, step_radius=1000, 
    save_interval=200
)

mappings = som.map_inputs(X)

plt.figure(figsize=(15, 10))
for i, weights in enumerate(weights_history):
    plt.subplot(5, 10, i + 1)
    plt.imshow(weights[:, :, 0], cmap='viridis', vmin=0, vmax=1)
    plt.title(f'Step {i*200}')
    plt.axis('off')
plt.suptitle('SOM Weight Evolution (Dimension 0)')
plt.tight_layout()
plt.show()
plt.figure(figsize=(8, 6))
plt.imshow(np.zeros(som.map_size), cmap='white')  
for i, (x, y) in enumerate(mappings):
    plt.text(y, x, f'X{i+1}', ha='center', va='center', fontsize=12, color='red')
plt.title('Input Patterns Mapping on SOM Output Plane')
plt.xlabel('Column')
plt.ylabel('Row')
plt.grid(True)
plt.show()
