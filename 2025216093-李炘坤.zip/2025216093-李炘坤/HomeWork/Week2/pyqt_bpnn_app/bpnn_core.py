import numpy as np

class Activation:
    @staticmethod
    def sigmoid_unipolar(x):
        # 0..1
        return 1.0 / (1.0 + np.exp(-x))

    @staticmethod
    def d_sigmoid_unipolar_from_y(y):
        # derivative using output y
        return y * (1.0 - y)

    @staticmethod
    def sigmoid_bipolar(x):
        # -1..1 (tanh)
        return np.tanh(x)

    @staticmethod
    def d_sigmoid_bipolar_from_y(y):
        # derivative using output y = tanh(x)
        return 1.0 - y**2


class ThreeLayerBP:
    """
    A classic three-layer feedforward neural network (input-hidden-output)
    with backpropagation using MSE loss.
    """
    def __init__(self, n_in, n_hidden, n_out, activation="unipolar", lr_ih=0.1, lr_ho=0.1, seed=None):
        self.n_in = int(n_in)
        self.n_hidden = int(n_hidden)
        self.n_out = int(n_out)
        self.set_learning_rates(lr_ih, lr_ho)
        self.set_activation(activation)
        self.rng = np.random.default_rng(seed)
        self.initialize_weights()

    def set_activation(self, activation):
        activation = activation.lower()
        if activation in ("unipolar", "sigmoid", "sigmoid_unipolar"):
            self.activation_name = "unipolar"
            self.f = Activation.sigmoid_unipolar
            self.df_from_y = Activation.d_sigmoid_unipolar_from_y
            self.output_range = (0.0, 1.0)
        elif activation in ("bipolar", "tanh", "sigmoid_bipolar"):
            self.activation_name = "bipolar"
            self.f = Activation.sigmoid_bipolar
            self.df_from_y = Activation.d_sigmoid_bipolar_from_y
            self.output_range = (-1.0, 1.0)
        else:
            raise ValueError("activation must be 'unipolar' or 'bipolar'")

    def set_learning_rates(self, lr_ih, lr_ho):
        self.lr_ih = float(lr_ih)
        self.lr_ho = float(lr_ho)

    def initialize_weights(self):
        # Uniform in [-1, 1]
        self.W1 = self.rng.uniform(-1.0, 1.0, size=(self.n_hidden, self.n_in))
        self.b1 = self.rng.uniform(-1.0, 1.0, size=(self.n_hidden, 1))
        self.W2 = self.rng.uniform(-1.0, 1.0, size=(self.n_out, self.n_hidden))
        self.b2 = self.rng.uniform(-1.0, 1.0, size=(self.n_out, 1))

    # ---------- Forward/Backward ----------
    def forward(self, X):
        # X: (n_in, batch)
        Z1 = self.W1 @ X + self.b1  # (n_hidden, batch)
        A1 = self.f(Z1)
        Z2 = self.W2 @ A1 + self.b2  # (n_out, batch)
        A2 = self.f(Z2)
        cache = {"X": X, "Z1": Z1, "A1": A1, "Z2": Z2, "A2": A2}
        return A2, cache

    @staticmethod
    def mse_loss(y_hat, y):
        # Mean squared error over batch
        return np.mean((y_hat - y) ** 2.0)

    def backward(self, cache, y):
        # y: (n_out, batch)
        X, A1, A2 = cache["X"], cache["A1"], cache["A2"]
        batch = y.shape[1]

        # deltas
        dA2 = (A2 - y) * (2.0 / batch)  # derivative of MSE wrt y_hat
        dZ2 = dA2 * self.df_from_y(A2)  # (n_out, batch)

        dW2 = dZ2 @ A1.T                 # (n_out, n_hidden)
        db2 = np.sum(dZ2, axis=1, keepdims=True)

        dA1 = self.W2.T @ dZ2            # (n_hidden, batch)
        dZ1 = dA1 * self.df_from_y(A1)   # (n_hidden, batch)

        dW1 = dZ1 @ X.T                  # (n_hidden, n_in)
        db1 = np.sum(dZ1, axis=1, keepdims=True)

        grads = {"dW1": dW1, "db1": db1, "dW2": dW2, "db2": db2}
        return grads

    def step(self, grads):
        self.W1 -= self.lr_ih * grads["dW1"]
        self.b1 -= self.lr_ih * grads["db1"]
        self.W2 -= self.lr_ho * grads["dW2"]
        self.b2 -= self.lr_ho * grads["db2"]

    # ---------- Training Helper ----------
    def fit_epoch(self, X, Y, shuffle=True):
        """
        One full-batch epoch (for simplicity). X: (n_in, N), Y: (n_out, N)
        Returns the loss of this epoch.
        """
        if shuffle:
            idx = self.rng.permutation(X.shape[1])
            X = X[:, idx]
            Y = Y[:, idx]

        y_hat, cache = self.forward(X)
        loss = self.mse_loss(y_hat, Y)
        grads = self.backward(cache, Y)
        self.step(grads)
        return float(loss)

    def predict(self, X):
        y_hat, _ = self.forward(X)
        return y_hat

    # ---------- Utilities ----------
    def normalize_labels(self, y_raw):
        """Map raw labels {0,1,...} to the activation range."""
        ymin, ymax = self.output_range
        y_raw = np.asarray(y_raw, dtype=float)
        # Scale each label k to evenly spaced values in [ymin,ymax]
        uniq = np.unique(y_raw)
        mapping = {k: ymin + (i/(len(uniq)-1) if len(uniq)>1 else 0.5)*(ymax - ymin) for i, k in enumerate(sorted(uniq))}
        return np.vectorize(mapping.get)(y_raw), mapping