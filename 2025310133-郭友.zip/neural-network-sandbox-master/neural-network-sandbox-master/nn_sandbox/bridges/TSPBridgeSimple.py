import numpy as np
import itertools
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QLabel
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

class TSPBridgeSimple(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        # ===== Matplotlib 图 =====
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.fig)

        # ===== 控件 =====
        self.city_combo = QComboBox()
        self.city_combo.addItems([str(i) for i in range(3, 21)])  # 城市数量 3~20
        self.city_combo.setCurrentText("8")

        self.refresh_btn = QPushButton("刷新 TSP")

        # 控件布局
        ctrl_layout = QHBoxLayout()
        ctrl_layout.addWidget(QLabel("城市数量:"))
        ctrl_layout.addWidget(self.city_combo)
        ctrl_layout.addWidget(self.refresh_btn)

        # 总布局
        layout = QVBoxLayout(self)
        layout.addLayout(ctrl_layout)
        layout.addWidget(self.canvas)

        # 按钮绑定
        self.refresh_btn.clicked.connect(self.on_refresh)

        # 初始绘制
        self.refresh(n=int(self.city_combo.currentText()))

    def generate_cities(self, n=8, seed=None):
        if seed is not None:
            np.random.seed(seed)
        self.cities = np.random.rand(n, 2)
        return self.cities

    def total_distance(self, order):
        dist = 0
        for i in range(len(order)):
            a, b = self.cities[order[i]], self.cities[order[(i + 1) % len(order)]]
            dist += np.linalg.norm(a - b)
        return dist

    def solve_tsp_bruteforce(self):
        n = len(self.cities)
        best_order = None
        best_dist = float("inf")
        for order in itertools.permutations(range(n)):
            d = self.total_distance(order)
            if d < best_dist:
                best_dist = d
                best_order = order
        self.best_order = best_order
        self.best_distance = best_dist
        return best_order, best_dist

    def visualize(self):
        if not hasattr(self, "cities"):
            raise RuntimeError("请先调用 generate_cities() 生成城市。")
        if not hasattr(self, "best_order"):
            self.solve_tsp_bruteforce()
        order = self.best_order
        cities = self.cities
        ordered_cities = cities[list(order) + [order[0]]]
        self.ax.clear()
        self.ax.plot(ordered_cities[:, 0], ordered_cities[:, 1], '-o', color='tab:blue')
        for i, (x, y) in enumerate(cities):
            self.ax.text(x, y, str(i), fontsize=12, ha='right', va='bottom')
        self.ax.set_title(f"TSP Visualization\nTotal distance: {self.best_distance:.3f}")
        self.ax.axis('equal')
        self.canvas.draw()

    def refresh(self, n=6):
        """随机生成城市并重新绘制"""
        self.generate_cities(n=n)
        self.solve_tsp_bruteforce()
        self.visualize()

    def on_refresh(self):
        n = int(self.city_combo.currentText())
        self.refresh(n=n)
