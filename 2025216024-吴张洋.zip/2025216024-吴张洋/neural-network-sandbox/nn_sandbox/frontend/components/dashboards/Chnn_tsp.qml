import QtQml 2.12
import QtQuick 2.12
import QtQuick.Controls 2.5
import QtQuick.Layouts 1.12
import QtCharts 2.3

import '..'

Page {
    name: 'CHNN_TSP'
    
    property bool bridgeReady: typeof chnnTspBridge !== 'undefined' && chnnTspBridge !== null
    
    // 使用上下布局，与参考实现的左右布局不同
    ColumnLayout {
        spacing: 10
        
        // 顶部：控制面板（紧凑设计）
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            
            // 左侧：参数设置
            GroupBox {
                title: '⚙️ 参数设置'
                Layout.fillWidth: true
                Layout.preferredHeight: 200
                
                GridLayout {
                    anchors.fill: parent
                    columns: 2
                    columnSpacing: 8
                    rowSpacing: 8
                    
                    Label { text: '城市数量' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 8
                        from: 4
                        to: 15
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_n_cities(value) }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'A (行约束)' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_A(value) }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'B (列约束)' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_B(value) }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'C (数量约束)' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 200
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_C(value) }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: 'D (距离权重)' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 500
                        from: 100
                        to: 1000
                        stepSize: 50
                        onValueChanged: { if (bridgeReady) chnnTspBridge.set_D(value) }
                        Layout.fillWidth: true
                    }
                    
                    Label { text: '最大迭代' }
                    SpinBox {
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        value: 5000
                        from: 1000
                        to: 20000
                        stepSize: 1000
                        onValueChanged: { if (bridgeReady) chnnTspBridge.max_iterations = value }
                        Layout.fillWidth: true
                    }
                }
            }
            
            // 中间：操作按钮和状态信息
            GroupBox {
                title: '🎮 控制与状态'
                Layout.preferredWidth: 250
                Layout.preferredHeight: 200
                
                ColumnLayout {
                    anchors.fill: parent
                    spacing: 8
                    
                    Button {
                        text: '🎲 生成随机城市'
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        onClicked: { if (bridgeReady) chnnTspBridge.generate_random_cities() }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '🚀 开始求解'
                        enabled: bridgeReady ? chnnTspBridge.has_finished : false
                        onClicked: { 
                            if (bridgeReady) {
                                // 清空图表数据
                                distanceChart.clearSeries()
                                cityCanvas.requestPaint()
                                chnnTspBridge.start_solving()
                            }
                        }
                        Layout.fillWidth: true
                    }
                    
                    Button {
                        text: '⏹️ 停止'
                        enabled: bridgeReady ? !chnnTspBridge.has_finished : false
                        onClicked: { if (bridgeReady) chnnTspBridge.stop_algorithm() }
                        Layout.fillWidth: true
                    }
                    
                    Rectangle {
                        Layout.fillWidth: true
                        height: 1
                        color: "#CCCCCC"
                    }
                    
                    GridLayout {
                        Layout.fillWidth: true
                        columns: 2
                        columnSpacing: 5
                        
                        Label { text: '迭代:' }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_iterations : '0'
                            font.bold: true
                            Layout.fillWidth: true
                        }
                        
                        Label { text: '能量:' }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_energy.toFixed(2) : '0.00'
                            font.bold: true
                            Layout.fillWidth: true
                        }
                        
                        Label { text: '路径长度:' }
                        Label { 
                            text: bridgeReady ? chnnTspBridge.current_distance.toFixed(4) : '0.0000'
                            font.bold: true
                            color: bridgeReady && chnnTspBridge.is_valid_solution ? 'green' : 'orange'
                            Layout.fillWidth: true
                        }
                        
                        Label { text: '最优长度:' }
                        Label { 
                            text: {
                                if (!bridgeReady) return '∞'
                                if (chnnTspBridge.best_distance === Infinity) return '∞'
                                return chnnTspBridge.best_distance.toFixed(4)
                            }
                            font.bold: true
                            color: 'green'
                            font.pixelSize: 14
                            Layout.fillWidth: true
                        }
                    }
                }
            }
        }
        
        // 中间：Tab切换视图（与参考实现不同）
        TabBar {
            id: tabBar
            Layout.fillWidth: true
            
            TabButton { text: '🗺️ 路径可视化' }
            TabButton { text: '📊 数据图表' }
            TabButton { text: '🧠 神经元矩阵' }
        }
        
        StackLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 400
            currentIndex: tabBar.currentIndex
            
            // Tab 1: 路径可视化（使用Canvas，不同颜色方案）
            GroupBox {
                title: '城市分布与路径'
                
                Rectangle {
                    anchors.fill: parent
                    color: "#F5F5F5"
                    border.color: "#2196F3"
                    border.width: 2
                    
                    Canvas {
                        id: cityCanvas
                        anchors.fill: parent
                        anchors.margins: 20
                        
                        onPaint: {
                            var ctx = getContext("2d")
                            ctx.clearRect(0, 0, width, height)
                            
                            if (!bridgeReady || !chnnTspBridge.city_positions || 
                                chnnTspBridge.city_positions.length === 0) {
                                return
                            }
                            
                            var cities = chnnTspBridge.city_positions
                            
                            var scale = Math.min(width, height) * 0.85
                            var offsetX = (width - scale) / 2
                            var offsetY = (height - scale) / 2
                            
                            // 优先显示当前路径（实时），用橙色表示正在计算
                            var showCurrentTour = chnnTspBridge.current_tour && 
                                                 chnnTspBridge.current_tour.length === cities.length &&
                                                 !chnnTspBridge.has_finished
                            
                            // 如果有当前路径且未完成，显示当前路径；否则显示最优路径
                            var tour = showCurrentTour ? chnnTspBridge.current_tour : 
                                      (chnnTspBridge.best_tour && chnnTspBridge.best_tour.length === cities.length ? 
                                       chnnTspBridge.best_tour : null)
                            
                            // 绘制路径（使用不同颜色，与参考实现不同）
                            if (tour && tour.length === cities.length) {
                                var useCurrentPath = showCurrentTour
                                ctx.strokeStyle = useCurrentPath ? "#FF9800" : "#4CAF50"  // 橙色/绿色
                                ctx.lineWidth = useCurrentPath ? 3 : 4
                                ctx.lineCap = "round"
                                ctx.lineJoin = "round"
                                ctx.beginPath()
                                
                                for (var i = 0; i < tour.length; i++) {
                                    var cityIdx = tour[i]
                                    if (cityIdx >= 0 && cityIdx < cities.length) {
                                        var x = cities[cityIdx][0] * scale + offsetX
                                        var y = cities[cityIdx][1] * scale + offsetY
                                        
                                        if (i === 0) {
                                            ctx.moveTo(x, y)
                                        } else {
                                            ctx.lineTo(x, y)
                                        }
                                    }
                                }
                                
                                // 连接回起点
                                if (tour.length > 0 && tour[0] >= 0 && tour[0] < cities.length) {
                                    var x0 = cities[tour[0]][0] * scale + offsetX
                                    var y0 = cities[tour[0]][1] * scale + offsetY
                                    ctx.lineTo(x0, y0)
                                }
                                
                                ctx.stroke()
                            }
                            
                            // 绘制城市（使用不同样式）
                            for (var i = 0; i < cities.length; i++) {
                                var x = cities[i][0] * scale + offsetX
                                var y = cities[i][1] * scale + offsetY
                                
                                // 城市圆点（使用渐变色效果）
                                var gradient = ctx.createLinearGradient(x-10, y-10, x+10, y+10)
                                gradient.addColorStop(0, "#E91E63")
                                gradient.addColorStop(1, "#C2185B")
                                ctx.fillStyle = gradient
                                ctx.beginPath()
                                ctx.arc(x, y, 12, 0, 2 * Math.PI)
                                ctx.fill()
                                
                                // 城市编号
                                ctx.fillStyle = "white"
                                ctx.font = "bold 14px sans-serif"
                                ctx.textAlign = "center"
                                ctx.textBaseline = "middle"
                                ctx.fillText(i.toString(), x, y)
                                
                                // 外圈
                                ctx.strokeStyle = "#880E4F"
                                ctx.lineWidth = 2
                                ctx.beginPath()
                                ctx.arc(x, y, 12, 0, 2 * Math.PI)
                                ctx.stroke()
                            }
                        }
                    }
                }
            }
            
            // Tab 2: 数据图表（使用面积图，与参考实现的折线图不同）
            GroupBox {
                title: '路径长度变化'
                
                ChartView {
                    id: distanceChart
                    anchors.fill: parent
                    antialiasing: true
                    legend.visible: false
                    
                    ValueAxis {
                        id: distanceXAxis
                        titleText: "迭代次数"
                        min: 0
                        max: 5000
                    }
                    
                    ValueAxis {
                        id: distanceYAxis
                        titleText: "路径长度"
                        min: 0
                        max: 5
                    }
                    
                    property var distanceSeries: null
                    
                    Component.onCompleted: {
                        distanceSeries = createSeries(ChartView.SeriesTypeArea, "路径长度", distanceXAxis, distanceYAxis)
                        if (distanceSeries) {
                            distanceSeries.borderWidth = 2
                            distanceSeries.borderColor = "#4CAF50"
                            distanceSeries.color = "#C8E6C9"
                            distanceSeries.useOpenGL = true
                        }
                    }
                    
                    function clearSeries() {
                        if (distanceSeries) {
                            removeSeries(distanceSeries)
                            distanceSeries = createSeries(ChartView.SeriesTypeArea, "路径长度", distanceXAxis, distanceYAxis)
                            if (distanceSeries) {
                                distanceSeries.borderWidth = 2
                                distanceSeries.borderColor = "#4CAF50"
                                distanceSeries.color = "#C8E6C9"
                                distanceSeries.useOpenGL = true
                            }
                        }
                    }
                }
            }
            
            // Tab 3: 神经元矩阵（使用热力图风格，与参考实现不同）
            GroupBox {
                title: '神经元状态矩阵'
                
                ScrollView {
                    anchors.fill: parent
                    clip: true
                    
                    Grid {
                        id: neuronGrid
                        anchors.centerIn: parent
                        columns: bridgeReady ? chnnTspBridge.n_cities : 8
                        spacing: 2
                        
                        Repeater {
                            model: bridgeReady && chnnTspBridge.neuron_matrix ? 
                                   chnnTspBridge.neuron_matrix.length * chnnTspBridge.neuron_matrix.length : 0
                            
                            Rectangle {
                                width: 40
                                height: 40
                                
                                // 使用热力图颜色方案（红色到蓝色）
                                color: {
                                    if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                        return "lightgray"
                                    
                                    var row = Math.floor(index / chnnTspBridge.n_cities)
                                    var col = index % chnnTspBridge.n_cities
                                    var value = chnnTspBridge.neuron_matrix[row][col]
                                    
                                    // 红色（低值）到蓝色（高值）
                                    var r = Math.floor((1 - value) * 255)
                                    var b = Math.floor(value * 255)
                                    return Qt.rgba(r/255, 0, b/255, 1)
                                }
                                
                                border.color: "#333333"
                                border.width: 1
                                radius: 3
                                
                                Label {
                                    anchors.centerIn: parent
                                    text: {
                                        if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                            return ""
                                        
                                        var row = Math.floor(index / chnnTspBridge.n_cities)
                                        var col = index % chnnTspBridge.n_cities
                                        return chnnTspBridge.neuron_matrix[row][col].toFixed(2)
                                    }
                                    font.pixelSize: 9
                                    font.bold: true
                                    color: {
                                        if (!bridgeReady || !chnnTspBridge.neuron_matrix)
                                            return "black"
                                        var row = Math.floor(index / chnnTspBridge.n_cities)
                                        var col = index % chnnTspBridge.n_cities
                                        var value = chnnTspBridge.neuron_matrix[row][col]
                                        return value > 0.5 ? "white" : "black"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    Connections {
        target: bridgeReady ? chnnTspBridge : null
        enabled: bridgeReady
        
        function onCity_positionsChanged() {
            cityCanvas.requestPaint()
        }
        
        function onBest_tourChanged() {
            cityCanvas.requestPaint()
        }
        
        function onCurrent_tourChanged() {
            cityCanvas.requestPaint()
        }
        
        function onCurrent_distanceChanged() {
            cityCanvas.requestPaint()
        }
        
        function onDistance_historyChanged() {
            if (!bridgeReady || !chnnTspBridge.distance_history)
                return
            
            var history = chnnTspBridge.distance_history
            
            if (history.length === 0) {
                if (distanceChart.distanceSeries) {
                    distanceChart.clearSeries()
                }
                return
            }
            
            // 实时更新：只添加新的数据点
            var currentCount = distanceChart.distanceSeries ? distanceChart.distanceSeries.count : 0
            var newPointsCount = history.length - currentCount
            
            if (newPointsCount > 0) {
                var validCount = 0
                var minD = 999999
                var maxD = 0
                
                for (var i = currentCount; i < history.length; i++) {
                    var val = history[i]
                    
                    if (val !== undefined && val !== null && 
                        val !== Infinity && val !== -Infinity && 
                        !isNaN(val) && val > 0 && val < 1000) {
                        
                        if (distanceChart.distanceSeries) {
                            distanceChart.distanceSeries.append(i, val)
                        }
                        validCount++
                        if (val < minD) minD = val
                        if (val > maxD) maxD = val
                    }
                }
                
                // 动态调整Y轴范围
                if (validCount > 0 && distanceChart.distanceSeries) {
                    var allMin = minD
                    var allMax = maxD
                    for (var j = 0; j < currentCount; j++) {
                        if (distanceChart.distanceSeries.at(j)) {
                            var yVal = distanceChart.distanceSeries.at(j).y
                            if (yVal < allMin) allMin = yVal
                            if (yVal > allMax) allMax = yVal
                        }
                    }
                    
                    var margin = (allMax - allMin) * 0.1
                    distanceYAxis.min = Math.max(0, allMin - margin)
                    distanceYAxis.max = allMax + margin
                }
            } else if (newPointsCount < 0) {
                // 如果历史长度减少（重新开始），清空并重绘
                if (distanceChart.distanceSeries) {
                    distanceChart.clearSeries()
                }
                var validCount = 0
                var minD = 999999
                var maxD = 0
                
                for (var i = 0; i < history.length; i++) {
                    var val = history[i]
                    
                    if (val !== undefined && val !== null && 
                        val !== Infinity && val !== -Infinity && 
                        !isNaN(val) && val > 0 && val < 1000) {
                        
                        if (distanceChart.distanceSeries) {
                            distanceChart.distanceSeries.append(i, val)
                        }
                        validCount++
                        if (val < minD) minD = val
                        if (val > maxD) maxD = val
                    }
                }
                
                if (validCount > 0) {
                    var margin = (maxD - minD) * 0.1
                    distanceYAxis.min = Math.max(0, minD - margin)
                    distanceYAxis.max = maxD + margin
                }
            }
            
            // 更新X轴范围
            distanceXAxis.max = Math.max(5000, history.length + 500)
        }
        
        function onNeuron_matrixChanged() {
            neuronGrid.columns = bridgeReady ? chnnTspBridge.n_cities : 8
        }
    }
}

