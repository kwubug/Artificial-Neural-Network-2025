@echo off
setlocal
set "ROOT=%~dp0"
set "VENV=%ROOT%.venv"
set "QML2_IMPORT_PATH=%VENV%\Lib\site-packages\PyQt5\Qt5\qml"
set "QT_QPA_PLATFORM_PLUGIN_PATH=%VENV%\Lib\site-packages\PyQt5\Qt5\plugins\platforms"
"%VENV%\Scripts\python.exe" "%ROOT%main.py"
endlocal
pause