import numpy as np
import threading
from typing import Callable, Tuple, List


class OptimizationAlgorithm(threading.Thread):
    """优化算法基类，用于实现各种梯度下降方法"""
    
    def __init__(self, objective_func: Callable, gradient_func: Callable, 
                 hessian_func: Callable = None, initial_point: np.ndarray = None,
                 max_iterations: int = 100, tolerance: float = 1e-6,
                 method: str = 'steepest'):
        """
        初始化优化算法
        
        Args:
            objective_func: 目标函数 f(x)
            gradient_func: 梯度函数 ∇f(x)
            hessian_func: Hessian矩阵函数 (仅牛顿法需要)
            initial_point: 初始点
            max_iterations: 最大迭代次数
            tolerance: 收敛容差
            method: 优化方法 ('steepest', 'newton', 'conjugate')
        """
        super().__init__()
        self.objective_func = objective_func
        self.gradient_func = gradient_func
        self.hessian_func = hessian_func
        self.initial_point = initial_point if initial_point is not None else np.array([1.2, 1.2])
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.method = method
        self._should_stop = False
        
        # 记录优化过程
        self.trajectory: List[np.ndarray] = []
        self.loss_history: List[float] = []
        self.gradient_norm_history: List[float] = []
        self.current_iteration = 0
        self.current_point = None
        self.current_loss = 0.0
        self.current_gradient_norm = 0.0
        self.has_converged = False
        
    def stop(self):
        """停止优化"""
        self._should_stop = True
        
    def run(self):
        """运行优化算法"""
        if self.method == 'steepest':
            self._steepest_descent()
        elif self.method == 'newton':
            self._newton_method()
        elif self.method == 'conjugate':
            self._conjugate_gradient()
        else:
            raise ValueError(f"Unknown method: {self.method}")
    
    def _steepest_descent(self):
        """最速下降法（梯度下降）"""
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            # 计算梯度
            grad = self.gradient_func(x)
            grad_norm = np.linalg.norm(grad)
            
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            # 检查收敛
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            # 使用Armijo线搜索确定步长
            alpha = self._armijo_line_search(x, -grad)
            
            # 更新点
            x = x - alpha * grad
            
            # 记录
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
    
    def _newton_method(self):
        """牛顿下降法"""
        if self.hessian_func is None:
            raise ValueError("Newton method requires hessian function")
            
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            # 计算梯度和Hessian矩阵
            grad = self.gradient_func(x)
            hess = self.hessian_func(x)
            
            grad_norm = np.linalg.norm(grad)
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            # 检查收敛
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            # 求解 Hess * d = -grad
            try:
                # 添加正则化以确保Hessian矩阵正定
                hess_reg = hess + 1e-6 * np.eye(len(x))
                direction = -np.linalg.solve(hess_reg, grad)
            except np.linalg.LinAlgError:
                # 如果Hessian矩阵奇异，退化为梯度下降
                direction = -grad
            
            # 使用线搜索确定步长
            alpha = self._armijo_line_search(x, direction)
            
            # 更新点
            x = x + alpha * direction
            
            # 记录
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
    
    def _conjugate_gradient(self):
        """共轭梯度法 (Fletcher-Reeves方法)"""
        x = self.initial_point.copy()
        self.trajectory = [x.copy()]
        self.loss_history = [self.objective_func(x)]
        
        # 初始搜索方向为负梯度
        grad = self.gradient_func(x)
        direction = -grad.copy()
        
        for i in range(self.max_iterations):
            if self._should_stop:
                break
                
            self.current_iteration = i
            self.current_point = x.copy()
            
            grad_norm = np.linalg.norm(grad)
            self.current_gradient_norm = grad_norm
            self.gradient_norm_history.append(grad_norm)
            
            # 检查收敛
            if grad_norm < self.tolerance:
                self.has_converged = True
                break
            
            # 线搜索确定步长
            alpha = self._armijo_line_search(x, direction)
            
            # 更新点
            x_new = x + alpha * direction
            grad_new = self.gradient_func(x_new)
            
            # Fletcher-Reeves公式计算beta
            beta = np.dot(grad_new, grad_new) / (np.dot(grad, grad) + 1e-10)
            
            # 更新搜索方向
            direction = -grad_new + beta * direction
            
            # 准备下一次迭代
            x = x_new
            grad = grad_new
            
            # 记录
            self.trajectory.append(x.copy())
            loss = self.objective_func(x)
            self.loss_history.append(loss)
            self.current_loss = loss
    
    def _armijo_line_search(self, x: np.ndarray, direction: np.ndarray, 
                           c: float = 0.1, rho: float = 0.5, 
                           max_iter: int = 50) -> float:
        """
        Armijo线搜索
        
        Args:
            x: 当前点
            direction: 搜索方向
            c: Armijo条件参数
            rho: 步长缩减因子
            max_iter: 最大迭代次数
        
        Returns:
            步长alpha
        """
        alpha = 1.0
        fx = self.objective_func(x)
        grad = self.gradient_func(x)
        
        for _ in range(max_iter):
            if self.objective_func(x + alpha * direction) <= fx + c * alpha * np.dot(grad, direction):
                break
            alpha *= rho
        
        return alpha


class TestFunctions:
    """常用的优化测试函数"""
    
    @staticmethod
    def rosenbrock(x: np.ndarray) -> float:
        """Rosenbrock函数: f(x,y) = (1-x)^2 + 100(y-x^2)^2"""
        return (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2
    
    @staticmethod
    def rosenbrock_gradient(x: np.ndarray) -> np.ndarray:
        """Rosenbrock函数的梯度"""
        df_dx = -2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0]**2)
        df_dy = 200 * (x[1] - x[0]**2)
        return np.array([df_dx, df_dy])
    
    @staticmethod
    def rosenbrock_hessian(x: np.ndarray) -> np.ndarray:
        """Rosenbrock函数的Hessian矩阵"""
        h11 = 2 - 400 * x[1] + 1200 * x[0]**2
        h12 = -400 * x[0]
        h21 = -400 * x[0]
        h22 = 200
        return np.array([[h11, h12], [h21, h22]])
    
    @staticmethod
    def sphere(x: np.ndarray) -> float:
        """球函数: f(x) = x^2 + y^2"""
        return np.sum(x**2)
    
    @staticmethod
    def sphere_gradient(x: np.ndarray) -> np.ndarray:
        """球函数的梯度"""
        return 2 * x
    
    @staticmethod
    def sphere_hessian(x: np.ndarray) -> np.ndarray:
        """球函数的Hessian矩阵"""
        n = len(x)
        return 2 * np.eye(n)
    
    @staticmethod
    def beale(x: np.ndarray) -> float:
        """Beale函数"""
        return ((1.5 - x[0] + x[0]*x[1])**2 + 
                (2.25 - x[0] + x[0]*x[1]**2)**2 + 
                (2.625 - x[0] + x[0]*x[1]**3)**2)
    
    @staticmethod
    def beale_gradient(x: np.ndarray) -> np.ndarray:
        """Beale函数的梯度"""
        t1 = 1.5 - x[0] + x[0]*x[1]
        t2 = 2.25 - x[0] + x[0]*x[1]**2
        t3 = 2.625 - x[0] + x[0]*x[1]**3
        
        df_dx = (2*t1*(-1 + x[1]) + 
                 2*t2*(-1 + x[1]**2) + 
                 2*t3*(-1 + x[1]**3))
        df_dy = (2*t1*x[0] + 
                 2*t2*x[0]*2*x[1] + 
                 2*t3*x[0]*3*x[1]**2)
        
        return np.array([df_dx, df_dy])
    
    @staticmethod
    def beale_hessian(x: np.ndarray) -> np.ndarray:
        """Beale函数的Hessian矩阵（数值近似）"""
        eps = 1e-5
        n = len(x)
        H = np.zeros((n, n))
        
        grad_at_x = TestFunctions.beale_gradient(x)
        
        for i in range(n):
            x_plus = x.copy()
            x_plus[i] += eps
            grad_plus = TestFunctions.beale_gradient(x_plus)
            H[:, i] = (grad_plus - grad_at_x) / eps
        
        return H
    
    @staticmethod
    def booth(x: np.ndarray) -> float:
        """Booth函数"""
        return (x[0] + 2*x[1] - 7)**2 + (2*x[0] + x[1] - 5)**2
    
    @staticmethod
    def booth_gradient(x: np.ndarray) -> np.ndarray:
        """Booth函数的梯度"""
        df_dx = 2*(x[0] + 2*x[1] - 7) + 4*(2*x[0] + x[1] - 5)
        df_dy = 4*(x[0] + 2*x[1] - 7) + 2*(2*x[0] + x[1] - 5)
        return np.array([df_dx, df_dy])
    
    @staticmethod
    def booth_hessian(x: np.ndarray) -> np.ndarray:
        """Booth函数的Hessian矩阵"""
        return np.array([[10, 8], [8, 10]])



