import time
import numpy as np

from . import TraningAlgorithm


class OlsAlgorithm(TraningAlgorithm):
    """
    普通最小二乘(OLS)一次线性回归：y ≈ w0 + w1 * x
    使用小批量/全量梯度下降进行可视化迭代。
    数据约定：dataset 的每行形如 [x, y, label]，仅使用前两列参与回归。
    """

    def __init__(
        self,
        dataset,
        total_epoches=20,
        learning_rate=0.05,
        batch_size=None,
        ui_refresh_interval=0.0,
        normalize_data=True,
    ):
        super().__init__(dataset=dataset, total_epoches=total_epoches)
        self._lr = float(learning_rate)
        self._batch_size = int(batch_size) if batch_size else None
        self._ui_refresh = float(ui_refresh_interval)
        self._normalize = bool(normalize_data)

        # 原尺度下的回归参数（用于显示/绘图） w0(截距), w1(斜率)
        self.w0 = 0.0
        self.w1 = 0.0

        # 规范化空间中的参数（训练用）
        self._theta0 = 0.0
        self._theta1 = 0.0

        # 标准化统计量
        self._x_mean = 0.0
        self._x_std = 1.0
        self._y_mean = 0.0
        self._y_std = 1.0

        # 可视化指标
        self.current_epoch = 0
        self.current_iteration = 0
        self.current_loss = 0.0

    def run(self):
        x = self._dataset[:, 0].astype(float)
        y = self._dataset[:, 1].astype(float)
        n = len(x)

        # 标准化
        if self._normalize:
            self._x_mean = float(np.mean(x))
            self._x_std = float(np.std(x)) or 1.0
            self._y_mean = float(np.mean(y))
            self._y_std = float(np.std(y)) or 1.0
            x_train = (x - self._x_mean) / self._x_std
            y_train = (y - self._y_mean) / self._y_std
        else:
            x_train = x
            y_train = y

        indices = np.arange(n)
        for epoch in range(self._total_epoches):
            if self._should_stop:
                break
            self.current_epoch = epoch + 1

            np.random.shuffle(indices)
            x_shuf = x_train[indices]
            y_shuf = y_train[indices]

            if self._batch_size is None or self._batch_size >= n:
                batches = [(x_shuf, y_shuf)]
            else:
                batches = [
                    (x_shuf[i:i + self._batch_size], y_shuf[i:i + self._batch_size])
                    for i in range(0, n, self._batch_size)
                ]

            for xb, yb in batches:
                if self._should_stop:
                    break
                # 预测
                y_pred = self._theta0 + self._theta1 * xb
                # 损失 (MSE)
                loss = np.mean((y_pred - yb) ** 2)
                # 梯度
                dw0 = 2.0 * np.mean(y_pred - yb)
                dw1 = 2.0 * np.mean((y_pred - yb) * xb)
                # 更新
                self._theta0 -= self._lr * dw0
                self._theta1 -= self._lr * dw1

                # 将规范化空间参数映射回原尺度，便于可视化/显示
                # 若 y = (y' * y_std + y_mean), x = (x' * x_std + x_mean), 且 y' = theta0 + theta1 * x'
                # 则 y = (theta0*y_std + y_mean) + (theta1*y_std/x_std) * (x - x_mean)
                # 展开得：w1 = theta1 * y_std / x_std
                #        w0 = y_mean + y_std*theta0 - w1 * x_mean
                if self._normalize:
                    w1 = self._theta1 * (self._y_std / self._x_std)
                    w0 = self._y_mean + self._y_std * self._theta0 - w1 * self._x_mean
                else:
                    w0 = self._theta0
                    w1 = self._theta1
                self.w0 = float(w0)
                self.w1 = float(w1)

                # 在原尺度上计算可视化损失
                y_pred_orig = self.w0 + self.w1 * x
                self.current_loss = float(np.mean((y_pred_orig - y) ** 2))

                self.current_iteration += 1
                if self._ui_refresh > 0:
                    remaining = self._ui_refresh
                    # 分片睡眠，提升停止响应
                    while remaining > 0 and not self._should_stop:
                        step = 0.01 if remaining > 0.01 else remaining
                        time.sleep(step)
                        remaining -= step


