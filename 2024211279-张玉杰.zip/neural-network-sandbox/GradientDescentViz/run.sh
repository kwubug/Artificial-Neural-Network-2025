#!/bin/bash
cd "$(dirname "$0")"

# 激活 conda 环境
source ~/miniconda3/etc/profile.d/conda.sh
conda activate tvm

# 运行应用
python main.py

