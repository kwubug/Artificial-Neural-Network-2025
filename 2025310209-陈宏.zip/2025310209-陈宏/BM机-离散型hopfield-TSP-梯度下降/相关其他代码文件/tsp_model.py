import numpy as np
import random
import math
from PyQt5.QtCore import QObject, pyqtSignal, pyqtProperty, pyqtSlot, QTimer  # 添加pyqtSlot导入


class TSPSolver(QObject):
    """旅行商问题(TSP)求解器模型"""

    # 信号定义
    citiesChanged = pyqtSignal()
    pathChanged = pyqtSignal()
    bestPathChanged = pyqtSignal()
    iterationChanged = pyqtSignal()
    distanceChanged = pyqtSignal()
    updateLog = pyqtSignal(str)

    def __init__(self, num_cities=10):
        super().__init__()
        self.num_cities = num_cities
        self.cities = self.generate_random_cities()
        self.current_path = list(range(num_cities))
        self.best_path = self.current_path.copy()
        self.best_distance = float('inf')
        self.iteration = 0
        self.is_running = False
        self.algorithm = "simulated_annealing"  # 默认模拟退火

        # 算法参数
        self.temperature = 1000.0
        self.cooling_rate = 0.995
        self.min_temperature = 1.0

        self.timer = QTimer()
        self.timer.timeout.connect(self.optimize_step)

    def generate_random_cities(self, width=800, height=600):
        """生成随机城市坐标"""
        return [(random.randint(50, width - 50), random.randint(50, height - 50))
                for _ in range(self.num_cities)]

    def calculate_distance(self, path):
        """计算路径总距离"""
        total_distance = 0
        for i in range(len(path)):
            x1, y1 = self.cities[path[i]]
            x2, y2 = self.cities[path[(i + 1) % len(path)]]
            total_distance += math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        return total_distance

    def get_neighbor(self, path):
        """生成邻域解（2-opt交换）"""
        new_path = path.copy()
        i, j = random.sample(range(len(new_path)), 2)
        i, j = min(i, j), max(i, j)
        new_path[i:j + 1] = reversed(new_path[i:j + 1])
        return new_path

    def optimize_step(self):
        """优化步骤（模拟退火）"""
        if not self.is_running:
            return

        if self.algorithm == "simulated_annealing":
            self.simulated_annealing_step()
        elif self.algorithm == "genetic":
            self.genetic_algorithm_step()

        self.iteration += 1
        self.iterationChanged.emit()
        self.updateLog.emit(f"迭代 {self.iteration}: 距离 {self.best_distance:.2f}")

    def simulated_annealing_step(self):
        """模拟退火算法步骤"""
        # 生成新解
        new_path = self.get_neighbor(self.current_path)
        new_distance = self.calculate_distance(new_path)
        current_distance = self.calculate_distance(self.current_path)

        # 计算能量差
        delta = new_distance - current_distance

        # 接受准则
        if delta < 0 or random.random() < math.exp(-delta / self.temperature):
            self.current_path = new_path
            current_distance = new_distance

            # 更新最优解
            if current_distance < self.best_distance:
                self.best_path = new_path.copy()
                self.best_distance = current_distance
                self.bestPathChanged.emit()
                self.distanceChanged.emit()

        # 降温
        if self.temperature > self.min_temperature:
            self.temperature *= self.cooling_rate

        self.pathChanged.emit()

    @pyqtSlot()
    def start_optimization(self):
        """开始优化"""
        self.is_running = True
        self.timer.start(100)
        self.updateLog.emit("🚀 开始TSP优化")

    @pyqtSlot()
    def stop_optimization(self):
        """停止优化"""
        self.is_running = False
        self.timer.stop()
        self.updateLog.emit("⏹️ 优化停止")

    @pyqtSlot()
    def reset_problem(self):
        """重置问题"""
        self.stop_optimization()
        self.cities = self.generate_random_cities()
        self.current_path = list(range(self.num_cities))
        self.best_path = self.current_path.copy()
        self.best_distance = float('inf')
        self.iteration = 0
        self.temperature = 1000.0

        self.citiesChanged.emit()
        self.pathChanged.emit()
        self.bestPathChanged.emit()
        self.iterationChanged.emit()
        self.distanceChanged.emit()
        self.updateLog.emit("🔄 问题已重置")

    @pyqtSlot(int)
    def set_num_cities(self, num):
        """设置城市数量"""
        self.num_cities = num
        self.reset_problem()

    @pyqtProperty(list)
    def cities_positions(self):
        return self.cities

    @pyqtProperty(list)
    def current_path_indices(self):
        return self.current_path

    @pyqtProperty(list)
    def best_path_indices(self):
        return self.best_path

    @pyqtProperty(float)
    def current_distance(self):
        return self.calculate_distance(self.current_path)

    @pyqtProperty(float)
    def best_path_distance(self):
        return self.best_distance

    @pyqtProperty(int)
    def current_iteration(self):
        return self.iteration

    @pyqtProperty(bool)
    def running(self):
        return self.is_running