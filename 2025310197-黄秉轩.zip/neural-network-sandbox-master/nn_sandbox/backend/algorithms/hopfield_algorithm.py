import numpy as np

class HopfieldAlgorithm:
    def __init__(self):
        self.weights = None
        self.patterns = []

    def train(self, patterns):
        """
        Train the Hopfield network with given patterns.
        Patterns should be a list of 1D numpy arrays with values in {-1, 1}.
        """
        if not patterns:
            return
        
        self.patterns = patterns
        num_neurons = len(patterns[0])
        self.weights = np.zeros((num_neurons, num_neurons))

        for p in patterns:
            self.weights += np.outer(p, p)
        
        # Set diagonal to zero
        np.fill_diagonal(self.weights, 0)

    def predict(self, initial_state, max_iters=100):
        """
        Run asynchronous update to find an attractor.
        """
        if self.weights is None:
            raise RuntimeError("The network has not been trained yet.")

        current_state = np.copy(initial_state)
        num_neurons = len(current_state)
        
        for i in range(max_iters):
            # Choose a random neuron to update
            neuron_idx = np.random.randint(0, num_neurons)
            
            # Update the neuron's state
            activation = np.dot(self.weights[neuron_idx], current_state)
            new_state_neuron = 1 if activation >= 0 else -1
            
            if new_state_neuron == current_state[neuron_idx]:
                # If the state of the chosen neuron doesn't change,
                # we can check for convergence. A full pass without changes
                # means we have converged. For simplicity here, we'll just
                # assume that if we do a few iterations with no change, we're stable.
                # A more robust check would be to track changes over a full sweep.
                if self._is_stable(current_state):
                    break
            
            current_state[neuron_idx] = new_state_neuron
            
            # Yield intermediate state for visualization
            yield {
                'state': np.copy(current_state),
                'energy': self.calculate_energy(current_state)
            }

        return {
            'state': current_state,
            'energy': self.calculate_energy(current_state)
        }

    def calculate_energy(self, state):
        """
        Calculate the energy of a given state.
        """
        if self.weights is None:
            return 0
        return -0.5 * np.dot(state.T, np.dot(self.weights, state))

    def _is_stable(self, state):
        """
        Check if the current state is a stable point (an attractor).
        """
        activations = np.dot(self.weights, state)
        new_state = np.where(activations >= 0, 1, -1)
        return np.array_equal(state, new_state)

    def run(self, train_data, train_labels, test_data, test_labels):
        # This method is part of the BaseAlgorithm interface, but not directly
        # used for Hopfield network's typical use case. We can adapt it if needed.
        pass
