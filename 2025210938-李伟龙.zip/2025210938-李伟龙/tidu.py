import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.animation import FFMpegWriter
import os
import shutil
import subprocess
import platform
# ============ 2️⃣ 定义目标函数及梯度 ============
def f(x, y):
    return (1 - x) ** 2 + 100 * (y - x ** 2) ** 2

def grad(x, y):
    dfdx = -2 * (1 - x) - 400 * x * (y - x ** 2)
    dfdy = 200 * (y - x ** 2)
    return np.array([dfdx, dfdy])

def hessian(x, y):
    dxx = 2 - 400 * y + 1200 * x ** 2
    dxy = -400 * x
    dyy = 200
    return np.array([[dxx, dxy], [dxy, dyy]])

# ============ 3️⃣ 三种优化算法 ============
def gradient_descent(start, lr=0.001, steps=100):
    x = np.array(start)
    path = [x.copy()]
    for _ in range(steps):
        g = grad(*x)
        x -= lr * g
        path.append(x.copy())
    return np.array(path)

def newton_method(start, steps=20):
    x = np.array(start)
    path = [x.copy()]
    for _ in range(steps):
        g = grad(*x)
        H = hessian(*x)
        try:
            delta = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        x -= delta
        path.append(x.copy())
    return np.array(path)

def conjugate_gradient(start, steps=50):
    x = np.array(start)
    path = [x.copy()]
    r = -grad(*x)
    p = r
    for _ in range(steps):
        alpha = np.dot(r, r) / np.dot(p, grad(*(x + 1e-3 * p)))  # 简化近似
        x = x + alpha * p
        new_r = -grad(*x)
        beta = np.dot(new_r, new_r) / np.dot(r, r)
        p = new_r + beta * p
        r = new_r
        path.append(x.copy())
    return np.array(path)

# ============ 4️⃣ 绘图准备 ============
x = np.linspace(-2, 2, 200)
y = np.linspace(-1, 3, 200)
X, Y = np.meshgrid(x, y)
Z = f(X, Y)

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z, cmap='viridis', alpha=0.6)

# 计算三条路径
path_gd = gradient_descent(start=(-1.5, 1.5), lr=0.002, steps=80)
path_newton = newton_method(start=(-1.5, 1.5), steps=20)
path_cg = conjugate_gradient(start=(-1.5, 1.5), steps=40)

# 绘制初始化点
gd_line, = ax.plot([], [], [], 'r-', label='Gradient Descent', lw=2)
nt_line, = ax.plot([], [], [], 'g-', label='Newton Method', lw=2)
cg_line, = ax.plot([], [], [], 'b-', label='Conjugate Gradient', lw=2)

gd_point, = ax.plot([], [], [], 'ro')
nt_point, = ax.plot([], [], [], 'go')
cg_point, = ax.plot([], [], [], 'bo')

ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_zlabel("f(x, y)")
ax.legend()

# ============ 5️⃣ 动画函数 ============
def init():
    for line, point in [(gd_line, gd_point), (nt_line, nt_point), (cg_line, cg_point)]:
        line.set_data([], [])
        line.set_3d_properties([])
        point.set_data([], [])
        point.set_3d_properties([])
    return gd_line, nt_line, cg_line, gd_point, nt_point, cg_point

def update(i):
    if i < len(path_gd):
        gd_line.set_data(path_gd[:i, 0], path_gd[:i, 1])
        gd_line.set_3d_properties(f(path_gd[:i, 0], path_gd[:i, 1]))
        gd_point.set_data([path_gd[i, 0]], [path_gd[i, 1]])
        gd_point.set_3d_properties([f(path_gd[i, 0], path_gd[i, 1])])
    if i < len(path_newton):
        nt_line.set_data(path_newton[:i, 0], path_newton[:i, 1])
        nt_line.set_3d_properties(f(path_newton[:i, 0], path_newton[:i, 1]))
        nt_point.set_data([path_newton[i, 0]], [path_newton[i, 1]])
        nt_point.set_3d_properties([f(path_newton[i, 0], path_newton[i, 1])])
    if i < len(path_cg):
        cg_line.set_data(path_cg[:i, 0], path_cg[:i, 1])
        cg_line.set_3d_properties(f(path_cg[:i, 0], path_cg[:i, 1]))
        cg_point.set_data([path_cg[i, 0]], [path_cg[i, 1]])
        cg_point.set_3d_properties([f(path_cg[i, 0], path_cg[i, 1])])
    return gd_line, nt_line, cg_line, gd_point, nt_point, cg_point

ani = animation.FuncAnimation(
    fig, update, init_func=init,
    frames=100, interval=120, blit=False
)

# ============ 6️⃣ 保存动画并自动打开 ============
output_path = os.path.abspath("gradient_methods_comparison.mp4")
writer = FFMpegWriter(fps=20, bitrate=2000)

print(" 开始生成视频，请稍等...")
ani.save(output_path, writer=writer, dpi=150)
print(f" 动画生成完成！文件位置：\n{output_path}")

# 自动打开视频
if platform.system() == "Windows":
    os.startfile(output_path)
elif platform.system() == "Darwin":
    subprocess.call(["open", output_path])
else:
    subprocess.call(["xdg-open", output_path])

plt.show()
