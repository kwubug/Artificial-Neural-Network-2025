import numpy as np
import matplotlib.pyplot as plt
from IPython.display import clear_output
import time

np.random.seed(0)
x = np.linspace(-3, 3, 30)
y_true = 1.5 * x - 0.5
y = y_true + np.random.randn(*x.shape) * 0.8
X = np.vstack([np.ones_like(x), x]).T

# 初始化权重
w = np.zeros(2)
eta = 0.01   # 学习率
epochs = 50  # 迭代次数

for epoch in range(epochs):
    # 预测与误差
    y_pred = X @ w
    grad = -2 * X.T @ (y - y_pred) / len(x)
    w -= eta * grad

    # 动态绘图
    clear_output(wait=True)
    plt.figure(figsize=(8,5))
    plt.scatter(x, y, color='blue', label='Data')
    plt.plot(x, y_true, 'g--', label='True line')
    plt.plot(x, X @ w, 'r-', label=f'OLS Iter {epoch+1}')
    plt.title(f'OLS Gradient Descent (Iter {epoch+1})')
    plt.xlabel('x'); plt.ylabel('y'); plt.legend(); plt.grid(True)
    plt.show()
    time.sleep(0.1)

print(f"最终拟合结果: y = {w[1]:.3f}x + {w[0]:.3f}")
