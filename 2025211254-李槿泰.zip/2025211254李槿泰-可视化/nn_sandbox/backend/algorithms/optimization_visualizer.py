import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import threading
import time
from typing import List, Tuple, Callable


class OptimizationVisualizer:
    """优化算法3D可视化器"""
    
    def __init__(self, objective_function: Callable, 
                 x_range: Tuple[float, float] = (-3, 3),
                 y_range: Tuple[float, float] = (-3, 3),
                 resolution: int = 50):
        self.objective_function = objective_function
        self.x_range = x_range
        self.y_range = y_range
        self.resolution = resolution
        
        # 创建网格
        self.x = np.linspace(x_range[0], x_range[1], resolution)
        self.y = np.linspace(y_range[0], y_range[1], resolution)
        self.X, self.Y = np.meshgrid(self.x, self.y)
        
        # 计算函数值
        self.Z = np.zeros_like(self.X)
        for i in range(self.resolution):
            for j in range(self.resolution):
                self.Z[i, j] = self.objective_function(np.array([self.X[i, j], self.Y[i, j]]))
        
        self.fig = None
        self.ax = None
        self.animation = None
        
    def create_static_plot(self, paths: List[List[np.ndarray]], 
                          algorithm_names: List[str],
                          colors: List[str] = ['red', 'blue', 'green'],
                          title: str = "优化算法收敛路径"):
        """创建静态3D图"""
        self.fig = plt.figure(figsize=(12, 8))
        self.ax = self.fig.add_subplot(111, projection='3d')
        
        # 绘制目标函数表面
        surf = self.ax.plot_surface(self.X, self.Y, self.Z, alpha=0.6, 
                                  cmap='viridis', linewidth=0, antialiased=True)
        
        # 绘制优化路径
        for i, (path, name, color) in enumerate(zip(paths, algorithm_names, colors)):
            if len(path) > 0:
                path_array = np.array(path)
                x_path = path_array[:, 0]
                y_path = path_array[:, 1]
                z_path = [self.objective_function(point) for point in path]
                
                # 绘制路径线
                self.ax.plot(x_path, y_path, z_path, color=color, linewidth=2, 
                           label=f'{name}路径', alpha=0.8)
                
                # 标记起点
                self.ax.scatter([x_path[0]], [y_path[0]], [z_path[0]], 
                              color=color, s=100, marker='o', label=f'{name}起点')
                
                # 标记终点
                self.ax.scatter([x_path[-1]], [y_path[-1]], [z_path[-1]], 
                              color=color, s=100, marker='*', label=f'{name}终点')
        
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('目标函数值')
        self.ax.set_title(title)
        self.ax.legend()
        
        plt.tight_layout()
        return self.fig
        
    def create_animated_plot(self, paths: List[List[np.ndarray]], 
                           algorithm_names: List[str],
                           colors: List[str] = ['red', 'blue', 'green'],
                           interval: int = 100):
        """创建动画3D图"""
        self.fig = plt.figure(figsize=(12, 8))
        self.ax = self.fig.add_subplot(111, projection='3d')
        
        # 绘制目标函数表面
        surf = self.ax.plot_surface(self.X, self.Y, self.Z, alpha=0.6, 
                                  cmap='viridis', linewidth=0, antialiased=True)
        
        # 初始化路径线
        lines = []
        points = []
        for i, (path, name, color) in enumerate(zip(paths, algorithm_names, colors)):
            if len(path) > 0:
                line, = self.ax.plot([], [], [], color=color, linewidth=2, 
                                   label=f'{name}路径', alpha=0.8)
                point, = self.ax.plot([], [], [], color=color, marker='o', 
                                    markersize=8, linestyle='None')
                lines.append(line)
                points.append(point)
        
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('目标函数值')
        self.ax.set_title("优化算法收敛过程")
        self.ax.legend()
        
        # 计算最大路径长度
        max_length = max(len(path) for path in paths if len(path) > 0)
        
        def animate(frame):
            for i, (path, line, point) in enumerate(zip(paths, lines, points)):
                if len(path) > 0 and frame < len(path):
                    current_path = path[:frame+1]
                    path_array = np.array(current_path)
                    x_path = path_array[:, 0]
                    y_path = path_array[:, 1]
                    z_path = [self.objective_function(point) for point in current_path]
                    
                    line.set_data_3d(x_path, y_path, z_path)
                    if len(x_path) > 0:
                        point.set_data_3d([x_path[-1]], [y_path[-1]], [z_path[-1]])
            
            return lines + points
        
        self.animation = FuncAnimation(self.fig, animate, frames=max_length, 
                                     interval=interval, blit=False, repeat=True)
        
        plt.tight_layout()
        return self.fig, self.animation
        
    def save_animation(self, filename: str, fps: int = 10):
        """保存动画为GIF文件"""
        if self.animation:
            self.animation.save(filename, writer='pillow', fps=fps)
            
    def show(self):
        """显示图形"""
        if self.fig:
            plt.show()
            
    def close(self):
        """关闭图形"""
        if self.fig:
            plt.close(self.fig)


class OptimizationComparison:
    """优化算法比较器"""
    
    def __init__(self, objective_function: Callable, gradient_function: Callable,
                 hessian_function: Callable = None):
        self.objective_function = objective_function
        self.gradient_function = gradient_function
        self.hessian_function = hessian_function
        self.visualizer = OptimizationVisualizer(objective_function)
        
    def compare_algorithms(self, initial_point: np.ndarray, 
                          learning_rate: float = 0.01,
                          max_iterations: int = 100):
        """比较三种优化算法"""
        from .optimization_algorithms import GradientDescent, NewtonMethod, ConjugateGradient
        
        # 创建算法实例
        algorithms = {
            '梯度下降法': GradientDescent(self.objective_function, self.gradient_function,
                                       learning_rate=learning_rate, max_iterations=max_iterations),
            '牛顿法': NewtonMethod(self.objective_function, self.gradient_function,
                                self.hessian_function, max_iterations=max_iterations),
            '共轭梯度法': ConjugateGradient(self.objective_function, self.gradient_function,
                                        max_iterations=max_iterations)
        }
        
        # 运行优化
        results = {}
        paths = []
        algorithm_names = []
        
        for name, algorithm in algorithms.items():
            try:
                optimal_point, path, function_values = algorithm.optimize(initial_point.copy())
                results[name] = {
                    'optimal_point': optimal_point,
                    'path': path,
                    'function_values': function_values,
                    'iterations': len(path) - 1,
                    'final_value': function_values[-1]
                }
                paths.append(path)
                algorithm_names.append(name)
            except Exception as e:
                print(f"算法 {name} 执行失败: {e}")
                results[name] = None
        
        return results, paths, algorithm_names
        
    def visualize_comparison(self, initial_point: np.ndarray, 
                           learning_rate: float = 0.01,
                           max_iterations: int = 100,
                           save_path: str = None):
        """可视化比较结果"""
        results, paths, algorithm_names = self.compare_algorithms(
            initial_point, learning_rate, max_iterations)
        
        # 创建静态图
        fig = self.visualizer.create_static_plot(paths, algorithm_names)
        
        if save_path:
            fig.savefig(save_path, dpi=300, bbox_inches='tight')
            
        return fig, results
