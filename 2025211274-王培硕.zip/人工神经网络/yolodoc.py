# -*- coding: utf-8 -*-
"""
一键生成 YOLO-FireAD 课程作业综述文档
运行后得到：YOLO-FireAD_综述.docx
"""
from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn

# 在文件头部增加
import io
from PIL import Image

# --------------------------------------------------
# 自动生成一张 1×1 空白 PNG
# --------------------------------------------------
def blank_png_stream():
    """返回一张 1×1 白色 PNG 的字节流"""
    img = Image.new('RGB', (1, 1), color='white')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf

# --------------------------------------------------
# 插图占位函数（不会报错）
# --------------------------------------------------
def add_pic_placeholder(caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # 直接传字节流，省去文件
    doc.add_picture(blank_png_stream(), width=Cm(12))
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f'图 {caption}')
    set_font(run, '宋体', Pt(9))
# --------------------------------------------------
# 工具：快速设置中文字体
# --------------------------------------------------
def set_font(run, name, size=Pt(10.5)):
    run.font.name = name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), name)
    run.font.size = size

# --------------------------------------------------
# 新建文档
# --------------------------------------------------
doc = Document()

# 全局默认字体
doc.styles['Normal'].font.name = '宋体'
doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
doc.styles['Normal'].font.size = Pt(10.5)

# --------------------------------------------------
# 封面
# --------------------------------------------------
def add_cover():
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run('\n\n\nYOLO-FireAD 文献综述与设计实现\n（课程作业）')
    set_font(run, '黑体', Pt(22))
    run.bold = True

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run('\n\n\n\n\n\n\n姓名：XXX\n学号：XXXXXXXX\n日期：2025 年 11 月')
    set_font(run, '宋体', Pt(14))

add_cover()
doc.add_page_break()

# --------------------------------------------------
# 目录占位（Word 中按 F9 自动生成）
# --------------------------------------------------
p = doc.add_paragraph()
run = p.add_run('目录')
set_font(run, '黑体', Pt(16))
run.bold = True
doc.add_paragraph('（此处留空，在 Word 中“引用-目录-自动目录”一键生成）')
doc.add_page_break()

# --------------------------------------------------
# 正文辅助：快速添加标题&正文
# --------------------------------------------------
def add_heading(text, level=1):
    p = doc.add_heading('', level=level)
    run = p.add_run(text)
    set_font(run, '黑体' if level <= 2 else '宋体', Pt(14) if level == 1 else Pt(12))
    return p

def add_para(text):
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_font(run, '宋体')
    return p

def add_pic_placeholder(caption):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # 这里用 1×1 像素的占位图，你可右键“更改图片”替换
    doc.add_picture('placeholder.png', width=Cm(12))   # 文件不存在时会报错，可提前放一张空白 png
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f'图 {caption}')
    set_font(run, '宋体', Pt(9))
    return p

# --------------------------------------------------
# 1 中文摘要
# --------------------------------------------------
add_heading('一、中文摘要（约 300 字）')
add_para('针对火焰/烟雾在复杂场景下形变大、外观多样、尺度跨度大、背景干扰强等问题，YOLO-FireAD 在 YOLOv8n 基线上提出两项改进：Attention-Guided Inverted Residual（AIR）与 Dual-Pooling Downscale Fusion（DPDF）。'
         'AIR 将通道/空间注意力注入倒残差结构，在轻量计算下增强火焰相关特征、抑制背景噪声；DPDF 以最大池化+平均池化的双分支下采样保留纹理与边缘，同时通过可学习融合减小小目标在降采样中的信息损失。'
         '论文在公开火焰/烟雾数据集上与多代 YOLO（v8/9/10/11 等轻量模型）对比，报告在相近或更低参数量与 FLOPs 下取得更高的 mAP、并保持实时推理。'
         '该方法优势在于：对小目标与复杂光照具有更好鲁棒性、结构改动可无缝嵌入 YOLO 框架、部署友好；不足在于：对极端弱纹理烟雾/高反光火焰仍可能漏检，双池化带来少量额外开销，且对训练数据的多域覆盖仍敏感。')

# --------------------------------------------------
# 2 相关研究现状
# --------------------------------------------------
add_heading('二、相关研究现状与方向')
add_para('经典 YOLO 系方法：从 v3/v5 的锚框检测到 v8 的锚点自由（anchor-free）与分布焦点损失（DFL），侧重端到端实时检测；'
         '近期工作多在注意力（CBAM/SimAM/EMA）、Neck 设计（BiFPN/PANeck 变体）、小目标增强（高分辨率/多尺度/超分支）、轻量化（Rep结构、蒸馏、剪枝、量化）等方向改进。')
add_para('火焰/烟雾场景特点：形状不稳定、颜色不确定（受白平衡/曝光/传感器影响）、烟雾边界模糊，且与夕阳、灯光、云雾等干扰相似；'
         '研究普遍采用时空信息或频域/纹理先验辅助。')
add_para('FireAD 的定位：在轻量实时前提下，针对“下采样丢失细节 + 背景噪声”痛点做结构级改进（AIR、DPDF），属于“结构增强 + 信息保留”路线，部署成本较低。')

add_heading('2.1 优点（对照课堂知识点）', level=2)
add_para('1. 注意力引导的倒残差（AIR）：在浅层/中层增强显著性区域的通道与空间权重，相当于对有效特征的前馈权重初始化与梯度路由进行引导，有助于提高梯度利用效率与收敛速度。')
add_para('2. 双池化下采样（DPDF）：最大池化保边缘、平均池化保纹理，学习式融合减小小目标在下采样的信息瓶颈；等价于对特征金字塔的信息通量做保真。')
add_para('3. 与 YOLOv8 生态兼容：保留训练/导出/部署流水线，复现与扩展成本低。')

add_heading('2.2 不足与改进空间', level=2)
add_para('• 对极低对比度/半透明烟雾仍难；可结合时序一致性或光流先验缓解。')
add_para('• 双池化虽轻量但仍有额外算子；在超边缘设备上需配合剪枝/INT8 量化。')
add_para('• 对数据域依赖仍在；需更强的数据增强（光照、雾化、背景替换）与难例挖掘。')

# --------------------------------------------------
# 3 网络设计说明
# --------------------------------------------------
add_heading('三、网络设计说明（按作业条目）')
add_para('注：以下以 YOLO-FireAD（基于 YOLOv8n）为主模型，任务为火焰/烟雾目标检测（2 类；若只做火焰则为 1 类）。')

add_heading('3.1 问题基本分析', level=2)
add_para('影响火焰/烟雾检测的关键因素：尺度与形变、光照与颜色、背景干扰、成像质量、数据域差异。')

add_heading('3.2 输入变量的选择与设计', level=2)
add_para('必选：RGB 图像，默认 640×640 letterbox 到方形，像素归一化到 [0,1]。'
         '可选增强输入：加入热像/红外或时序帧拼接作为多通道输入。')

add_heading('3.3 输出变量的选择与设计', level=2)
add_para('YOLO 头（anchor-free）：每个网格点输出 cls(2)、bbox(cx,cy,w,h)、obj；评价指标：mAP@0.5 与 mAP@0.5:0.95。')

add_heading('3.4 网络类型的选择', level=2)
add_para('主体为 YOLOv8n + AIR + DPDF。如需 BP 网作业对照，可在检测框特征上搭建一个 BP 全连接小网络做二分类对比。')

add_heading('3.5 网络初始参数设定原则', level=2)
add_para('权重初始化：沿用 Ultralytics 默认；正则化：权重衰减 5e-4；BatchNorm/EMA：保持 BN 同步，启用 EMA 平滑权重。')

# --------------------------------------------------
# 4 训练集的设计与预处理
# --------------------------------------------------
add_heading('四、训练集的设计与预处理')
add_para('（以下内容已在你给定的 DBA-YOLO 数据脚本中实现，此处仅作说明）')

add_heading('4.1 训练样本的选择', level=2)
add_para('使用 DBA-YOLO 数据为主，按 8:2 划分 train/val；为增强泛化，建议混入少量室内/夜间样本或做相应数据增强。')

add_heading('4.2 归一化', level=2)
add_para('像素归一化到 [0,1]；标注为 YOLO txt：class cx cy w h（相对宽高）。')

add_heading('4.3 数据规整与剔除', level=2)
add_para('剔除严重模糊/错标/无标签样本；检查 bbox 是否越界/长宽比极端。')

add_heading('4.4 连续变量离散化', level=2)
add_para('将目标面积占比离散为小/中/大三档，用于重采样或可视化分析。')

add_heading('4.5 相关度分析', level=2)
add_para('统计类别占比、目标面积/长宽比分布、光照场景比例与 mAP 的关系；小目标和强光场景若召回低，可提高输入分辨率、加重小目标增强和 DPDF 层权重。')

# --------------------------------------------------
# 5 算法说明
# --------------------------------------------------
add_heading('五、算法说明（超参/优化器等）')
add_para('• 冲量：SGD 动量 0.9~0.95；或使用 AdamW（β1=0.9, β2=0.999）。')
add_para('• 学习率：基础 lr0=0.01（SGD）或 2e-3~3e-3（AdamW），warmup 3~5 epoch，cosine 或 one-cycle 调度。')
add_para('• 陡度：通过损失权重、IoU 变体与 Label Smoothing 控制。')
add_para('• 其它技术：EMA、TTA、Copy-Paste/MixUp、蒸馏、INT8 量化、注意力替换消融、下采样策略消融。')

# --------------------------------------------------
# 6 程序流程图、源代码与运行方法
# --------------------------------------------------
add_heading('六、程序流程图、源代码与运行方法')



add_heading('6.2 关键源码', level=2)
add_para('train.py / val.py / infer.py 已在前文给出，此处不再赘述。')

add_heading('6.3 运行方法', level=2)
add_para('环境：Python 3.10；pip install "ultralytics>=8.2,<9" opencv-python matplotlib')
add_para('参数：imgsz=640，epochs=100，batch=16，lr0=0.01（SGD），momentum=0.937')
add_para('数据格式：images/{train,val} 与 labels/{train,val}，标签：class cx cy w h（相对 0~1）')
add_para('输出：runs/detect/train/（权重、曲线、PR、混淆矩阵、结果图）')

# --------------------------------------------------
# 7 网络的训练与测试
# --------------------------------------------------
add_heading('七、网络的训练与测试（报告要点）')
add_para('数据与设置：说明数据规模、划分、图像尺寸、增强策略、优化器与 lr 调度。')
add_para('主要指标：mAP@0.5、mAP@0.5:0.95、Precision/Recall、FPS。')

add_heading('7.1 可视化', level=2)


add_heading('7.2 消融实验', level=2)
add_para('• 去掉 AIR 或 DPDF；')
add_para('• 分辨率 640 vs 800；')
add_para('• 优化器 SGD vs AdamW；')
add_para('• TTA on/off。')

add_heading('7.3 运行结果说明', level=2)
add_para('（示例）在 DBA-YOLO 数据上，FireAD（640，SGD，100e）相较 v8n 基线，mAP@0.5 提升 X%，小目标召回提升 Y%，FPS 下降 Z%（主要由 DPDF 引起）；'
         '在强光/反光场景下误检仍存在，推测由颜色分布与反射纹理相似导致。')

add_heading('7.4 存在问题与改进', level=2)
add_para('• 夜间/强背光下对烟雾感知弱 → 增加暗光增强/去雾增强样本；')
add_para('• 极小目标召回不足 → 提高输入分辨率或在 P3 层前增加 DPDF/AIR；')
add_para('• 部署算力敏感 → 进行通道剪枝 + INT8 量化，或切换到 FireAD-Nano 配置。')

add_heading('7.5 结论', level=2)
add_para('YOLO-FireAD 在轻量实时框架内，通过 AIR 与 DPDF 针对火焰/烟雾的显著性增强与下采样保真做了有效改进，'
         '能在不显著增加计算量的情况下提升检测性能；在极端低对比度与强反光场景仍有改进空间，'
         '未来可结合时序信息与多模态（红外/热像）进一步提升鲁棒性。')

# --------------------------------------------------
# 8 参考文献（示例）
# --------------------------------------------------
add_heading('八、参考文献')
add_para('[1]  Redmon J., Farhadi A. YOLOv3: An Incremental Improvement. arXiv 2018.')
add_para('[2]  Wang C. Y., Bochkovskiy A., Liao H. Y. M. YOLOv7: Trainable bag-of-freebies sets new state-of-the-art for real-time object detectors. CVPR 2022.')
add_para('[3]  Ge Z., Liu S., Wang F., et al. YOLOX: Exceeding YOLO Series in 2021. arXiv 2021.')
add_para('[4]  Ultralytics. YOLOv8 Docs. https://github.com/ultralytics/ultralytics 2023.')
add_para('[5]  作者团队. YOLO-FireAD: Efficient Fire Detection via Attention-Guided Inverted Residual Learning and Dual-Pooling Feature Preservation. 2025.')

# --------------------------------------------------
# 保存
# --------------------------------------------------
doc.save('YOLO-FireAD_综述.docx')
print('已生成 YOLO-FireAD_综述.docx，祝作业顺利！')